﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import time
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, unquote_plus  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else: 
	from urllib.parse import urlencode, unquote_plus  # Python 3.X
	from urllib.request import urlopen  # Python 3.X
	from functools import reduce  # Python 3.X

from .common import *


def mainMenu():
	i = 1
	while i <= 5:
		WU = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
		WT = (datetime.now() - timedelta(days=i)).strftime('%w~%d.%m.%Y')
		MD = WT.split('~')[0].replace('1', translation(30601)).replace('2', translation(30602)).replace('3', translation(30603)).replace('4', translation(30604)).replace('5', translation(30605)).replace('6', translation(30606)).replace('0', translation(30607))
		addDir(translation(30608).format(MD, WT.split('~')[1]), icon, {'mode': 'listVideos_HighDayChannel', 'url': BASE_URL+'/mediathek/nach-datum/?date='+WU})
		i += 1
	addDir(translation(30609), icon, {'mode': 'listChannel', 'url': BASE_URL+'/mediathek/nach-sender/'})
	addDir(translation(30610), icon, {'mode': 'listVideos_HighDayChannel', 'url': BASE_URL+'/mediathek/'})
	addDir(translation(30611), icon, {'mode': 'listVideos_Genre', 'url': 'Spielfilm'})
	addDir(translation(30612), icon, {'mode': 'listVideos_Genre', 'url': 'Serie'})
	addDir(translation(30613), icon, {'mode': 'listVideos_Genre', 'url': 'Report'})
	addDir(translation(30614), icon, {'mode': 'listVideos_Genre', 'url': 'Unterhaltung'})
	addDir(translation(30615), icon, {'mode': 'listVideos_Genre', 'url': 'Kinder'})
	addDir(translation(30616), icon, {'mode': 'listVideos_Genre', 'url': 'Sport'})
	if enableADJUSTMENT:
		addDir(translation(30617), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30618), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listChannel(url):
	debug_MS("(navigator.listChannel) -------------------------------------------------- START = listChannel --------------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listChannel) SENDER-SORTIERUNG : Alle Sender in TV-Spielfilm")
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listChannel) --- RTLPLUS (TVNOW) - Sender {0} ---".format(STATUS))
	html = getUrl(url)
	content = html[html.find('<section class="mediathek-channels">'):]
	content = content[:content.find('</section>')]
	spl = content.split('<a title=')
	for i in range(1, len(spl), 1):
		entry = spl[i]
		urlFW = re.compile(r'href="(https?://.*?mediathek/.*?)">', re.S).findall(entry)[0]
		channel = urlFW.split('sender/')[1].replace('/', '').strip()# https://www.tvspielfilm.de/mediathek/nach-sender/ZDF/
		channelID, name = cleanStation(channel)
		if showNOW is False:
			if name.upper() in ['NITRO', 'RTL', 'RTL2', 'VOX', 'SRTL']: continue
		debug_MS("(navigator.listChannel) Link : {0}{1}".format(urlFW, channelID))
		addDir('[COLOR lime]'+name+'[/COLOR]', artpic+name.lower().replace(' ', '')+'.png', {'mode': 'listVideos_HighDayChannel', 'url': urlFW}, studio=name)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos_HighDayChannel(url):
	debug_MS("(navigator.listVideos_HighDayChannel) -------------------------------------------------- START = listVideos_HighDayChannel --------------------------------------------------")
	debug_MS("(navigator.listVideos_HighDayChannel) MEDIATHEK : {0}".format(url))
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listVideos_HighDayChannel) --- RTLPLUS (TVNOW) - Sender {0} ---".format(STATUS))
	content = getUrl(url)
	if '?date=' in url or 'nach-sender' in url:
		results = re.findall('<section class="teaser-section">(.+?)</section>', content, re.S)
	else:
		results = re.findall('<div class="swiper-container"(.+?)<div class="swiper-button-prev"></div>', content, re.S)
	for chtml in results:
		spl = chtml.split('<div class="content-teaser') if '?date=' in url or 'nach-sender' in url else chtml.split('<div class="swiper-slide">')
		for i in range(1,len(spl),1):
			entry = spl[i]
			title = re.compile(r'<span class="headline">(.*?)</span>', re.S).findall(entry)
			subtitle = re.compile(r'target="_self" title="(.*?)"', re.S).findall(entry)
			special= re.compile(r'<span class="subline.+?>(.*?)</span>', re.S).findall(entry)
			added = ""
			if (title and subtitle and not special):
				FIRST, SECOND = title[0].replace('…', '').replace('...', '').strip(), subtitle[0].replace('…', '').replace('...', '').strip()
				name = cleaning(FIRST) if FIRST == SECOND else cleaning(FIRST)+" - "+cleaning(SECOND.replace(FIRST, ""))
				channel = url.split('sender/')[1].replace('/', '').strip()
			elif (title and not subtitle and special):
				name = cleaning(title[0])+" - "+cleaning(special[0].split('|')[-1])
				added = special[0].split('|')[0].strip()
				channel = cleaning(special[0].split('|')[1])
			elif (title and subtitle and special):
				FIRST, SECOND = title[0].replace('…', '').replace('...', '').strip(), subtitle[0].replace('…', '').replace('...', '').strip()
				if FIRST == SECOND: name = cleaning(FIRST)
				else:
					test_SUB = cleaning(SECOND.replace(FIRST, ""))
					name = cleaning(FIRST) if test_SUB == "" else cleaning(FIRST)+" - "+test_SUB
				added = special[0].split('|')[0].strip()
				channel = cleaning(special[0].split('|')[1])
			channelID, studio = cleanStation(channel)
			if showDATE and added != "":
				name = added.strip()+"  "+name
			urlFW = re.compile(r'<a href="(https?://.*?mediathek/.*?)"', re.S).findall(entry)[0]
			img = re.compile(r'src="(https://a2.tvspielfilm.de/imedia/.*?.jpg)"', re.S).findall(entry)
			photo = img[0] if img else ""
			# 964 x 510 px = ,kpQ8aJYzw6ynhaO4Y2_vH8a7z2Do1GgrS8XBm_WNST4qVJPG6q9MH034hLE201uS129d8PUi_w_DKV5EjyOMMA==.jpg || 1280 x 720 px = ,dim:1280x720,mode:exact,center:640x254,thumb:1.jpg
			photo = photo.split(',')[0].rstrip()+',dim:1280x720,mode:exact,center:640x360,thumb:1.jpg' if ',' in photo else photo
			if showCHANNEL and studio != "":
				name += channelID
			if showNOW is False:
				if studio.upper() in ['NITRO', 'RTL', 'RTL2', 'VOX', 'SRTL']: continue
			debug_MS("(navigator.listVideos_HighDayChannel) Name : {0}".format(name))
			debug_MS("(navigator.listVideos_HighDayChannel) Link : {0}".format(urlFW))
			debug_MS("(navigator.listVideos_HighDayChannel) Icon : {0}".format(photo))
			addLink(name, photo, {'mode': 'playVideo', 'url': urlFW}, studio)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos_Genre(category):
	debug_MS("(navigator.listVideos_Genre) -------------------------------------------------- START = listVideos_Genre --------------------------------------------------")
	debug_MS("(navigator.listVideos_Genre) MEDIATHEK : {0}/mediathek/ - Genre = *{1}*".format(BASE_URL, category.upper()))
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listVideos_Genre) --- RTLPLUS (TVNOW) - Sender {0} ---".format(STATUS))
	content = getUrl(BASE_URL+'/mediathek/')
	results = re.findall('<span>'+category+'</span>(.+?)<div class="scroll-box">', content, re.S)
	for chtml in results:
		spl = chtml.split('<li>')
		for i in range(1,len(spl),1):
			entry = spl[i]
			name = ""
			all_TITLES = re.compile(r'<div class="text-holder">(.*?)</a>', re.S).findall(entry)[0]
			title = re.compile(r'<strong>(.*?)</strong>', re.S).findall(all_TITLES)
			subtitle = re.compile(r'<span>(.*?)</span>', re.S).findall(all_TITLES)
			reserve = re.compile(r'class="aholder" title="(.*?)">', re.S).findall(entry)
			if title and subtitle and reserve:
				FIRST, SECOND, THIRD = title[0].strip(), subtitle[0].strip(), reserve[0].strip()
				if FIRST.lower() == THIRD.lower(): name = cleaning(THIRD)
				elif ('...' in FIRST and not '...' in SECOND):
					name = cleaning(THIRD.replace(SECOND, ""))+" - "+cleaning(SECOND)
				elif ('...' in FIRST and '...' in SECOND):
					name = cleaning(FIRST)
				else:
					checking = FIRST.lower()+' '+SECOND.lower()
					name = cleaning(FIRST) if checking == THIRD.lower() else cleaning(FIRST)+" - "+cleaning(THIRD.replace(FIRST, ""))
			elif title and subtitle and not reserve:
				FIRST, SECOND = title[0].strip(), subtitle[0].strip()
				name = cleaning(FIRST) if FIRST.lower() == SECOND.lower() else cleaning(FIRST)+" - "+cleaning(SECOND.replace(FIRST, ""))
			else: name = cleaning(title[0])
			added = re.compile(r'<div class="col">(.*?)</div>', re.S).findall(entry)[0]
			if showDATE and added != "":
				name = added.strip()+"  "+name
			all_CHANNELS = re.compile(r'<span class="logotype">(.*?)</span>', re.S).findall(entry)[0]
			channel = re.compile(r'title="(.*?)" loading=', re.S).findall(all_CHANNELS)[0]
			channelID, studio = cleanStation(channel)
			urlFW = re.compile(r'<a href="(https?://.*?mediathek/.*?)"', re.S).findall(entry)[0]
			img = re.compile(r'src="(https://a2.tvspielfilm.de/imedia/.*?.jpg)"', re.S).findall(entry)
			photo = img[0] if img else ""
			# 964 x 510 px = ,kpQ8aJYzw6ynhaO4Y2_vH8a7z2Do1GgrS8XBm_WNST4qVJPG6q9MH034hLE201uS129d8PUi_w_DKV5EjyOMMA==.jpg || 1280 x 720 px = ,dim:1280x720,mode:exact,center:640x254,thumb:1.jpg
			photo = photo.split(',')[0].rstrip()+',dim:1280x720,mode:exact,center:640x360,thumb:1.jpg' if ',' in photo else photo
			if showCHANNEL and studio != "":
				name += channelID
			if showNOW is False:
				if studio.upper() in ['NITRO', 'RTL', 'RTL2', 'VOX', 'SRTL']: continue
			debug_MS("(navigator.listVideos_Genre) Name : {0}".format(name))
			debug_MS("(navigator.listVideos_Genre) Link : {0}".format(urlFW))
			debug_MS("(navigator.listVideos_Genre) Icon : {0}".format(photo))
			addLink(name, photo, {'mode': 'playVideo', 'url': urlFW}, studio)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url):
	ARD_SCHEMES = ('http://www.ardmediathek.de', 'https://www.ardmediathek.de', 'http://mediathek.daserste.de', 'https://mediathek.daserste.de')
	RTL_SCHEMES = ('http://www.nowtv.de', 'https://www.nowtv.de', 'http://www.tvnow.de', 'https://www.tvnow.de')
	log("(navigator.playVideo) --- START WIEDERGABE ANFORDERUNG ---")
	log("(navigator.playVideo) frei")
	finalURL = False
	LINK = ""
	try:
		content = getUrl(url)
		LINK = re.compile('<header class="broadcast-detail__header">.+?<a href="([^"]+)" class="mediathek-open col-hover-thek', re.S).findall(content)[0]
		log("(navigator.playVideo) AbspielLink (Original) : {0}".format(LINK))
	except:
		log("(navigator.playVideo) MediathekLink-00 : MediathekLink der Sendung in TV-Spielfilm NICHT gefunden !!!")
		return dialog.notification(translation(30521), translation(30522), icon, 8000)
	log("(navigator.playVideo) frei")
	if LINK.startswith('https://www.arte.tv'):
		try:
			videoID = re.compile('arte.tv/de/videos/([^/]+?)/', re.S).findall(LINK)[0]
			if xbmc.getCondVisibility('System.HasAddon(plugin.video.tyl0re.arte)'):
				finalURL = 'plugin://plugin.video.tyl0re.arte/?mode=playVideo&url='+str(videoID)
				log("(navigator.playVideo) AbspielLink-1 (ARTE-TV) : {0}".format(finalURL))
			elif xbmc.getCondVisibility('System.HasAddon(plugin.video.arteplussept)'):
				finalURL = 'plugin://plugin.video.arteplussept/play/SHOW/'+str(videoID)
				log("(navigator.playVideo) AbspielLink-2 (ARTE-plussept) : {0}".format(finalURL))
			if not finalURL:
				log("(navigator.playVideo) AbspielLink-00 (ARTE) : KEIN *ARTE-Addon* zur Wiedergabe vorhanden !!!")
				dialog.notification(translation(30523).format('ARTE - Addon'), translation(30524).format('ARTE-Addon'), icon, 8000)
			else:
				listitem = xbmcgui.ListItem(path=finalURL)
				xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
		except:
			log("(navigator.playVideo) AbspielLink-00 (ARTE) : *ARTE-Plugin* Der angeforderte -VideoLink- existiert NICHT !!!")
			dialog.notification(translation(30523).format('ARTE - Plugin'), translation(30525), icon, 8000)
	elif LINK.startswith(ARD_SCHEMES):
		videoURL = LINK
		return ArdGetVideo(videoURL)
	elif LINK.startswith('https://www.zdf.de'):
		videoURL = LINK[:LINK.find('.html')]+'.html'
		return ZdfGetVideo(videoURL)
	elif LINK.startswith(RTL_SCHEMES):
		LINK = LINK.replace('http://', 'https://').replace('www.nowtv.de/', 'www.tvnow.de/').replace('list/aktuell/', '').replace('/player', '')
		videoEP = LINK.split('-')[-1].strip()
		videoSE = LINK.split('/')[4].replace('-tvnow-', '').replace(videoEP, '').strip()
		log("(navigator.playVideo) --- RTL-Daten : ### Serie [{0}] ### Episode [{1}] ### ---".format(videoSE, videoEP))
		return RtlGetVideo(videoSE, videoEP, LINK)
	log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")

def ArdGetVideo(videoURL):
	debug_MS("(navigator.ArdGetVideo) ------------------------------------------------ START = ArdGetVideo -----------------------------------------------")
	MEDIAS = []
	player_PAGE, STREAM, finalURL = (False for _ in range(3))
	All_QUALITIES = ['auto', 5, 4, 3, 2, 1, 0]
	docuID = re.compile('ardmediathek.de/video/([A-Za-z0-9_]+)', re.S).findall(videoURL)# https://www.ardmediathek.de/video/Y3JpZDovL2Rhc2Vyc3RlLmRlL3RhdG9ydC9kYzYwZGU0Zi0zYzRlLTRiNjQtOTgxYi02ZWIwYjYzY2MyOTA
	if docuID:# https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL2Rhc2Vyc3RlLmRlL3RhdG9ydC9kYzYwZGU0Zi0zYzRlLTRiNjQtOTgxYi02ZWIwYjYzY2MyOTA?devicetype=pc&embedded=false
		player_PAGE = '{0}ard/item/{1}?devicetype=pc&embedded=false'.format(API_ARD, docuID[0])
	else:
		req_FIRST = getUrl(videoURL)
		docuLINK = re.compile(r'<script id="fetchedContextValue" type="application/json">.+?"href":"(https?://.*?/item/.*?)".+?</script>', re.S).findall(req_FIRST)
		player_PAGE = docuLINK[0] if docuLINK else False
	debug_MS("(navigator.ArdGetVideo) ##### videoPAGE : {0} #####".format(str(player_PAGE)))
	if player_PAGE:
		content = getUrl(player_PAGE)
		debug_MS("++++++++++++++++++++++++")
		debug_MS("(navigator.ArdGetVideo) XXXXX CONTENT : {0} XXXXX".format(str(content)))
		debug_MS("++++++++++++++++++++++++")
		DATA = json.loads(content)
		if 'widgets' in DATA and len(DATA['widgets']) > 0:
			for elem in DATA['widgets']:
				if elem.get('type', '') == 'player_ondemand' and elem.get('mediaCollection', ''):
					SHORT = elem['mediaCollection']['embedded']['_mediaArray'][1] if len(elem['mediaCollection']['embedded']['_mediaArray']) > 1 else elem['mediaCollection']['embedded']['_mediaArray'][0]
					for found in All_QUALITIES:
						for quality in SHORT.get('_mediaStreamArray', []):
							if quality['_quality'] == found and '_stream' in quality and quality['_stream']:
								if (enableINPUTSTREAM or prefSTREAM == '0') and quality['_quality'] == 'auto' and 'm3u8' in quality['_stream']:
									STREAM = 'M3U8'
									finalURL = 'https:'+quality['_stream'] if quality['_stream'][:4] != 'http' else quality['_stream']
									log("(navigator.ArdGetVideo) Auswahl vom *m3u8-Stream* (ARD+3) : {0}".format(finalURL))
								if quality['_quality'] != 'auto' and '.mp4' in quality['_stream']:
									MEDIAS.append({'url': quality['_stream'], 'quality': quality['_quality'], 'mimeType': 'mp4', 'height': (quality.get('_height', 'Unknown') or 'Unknown')})
				elif elem.get('blockedByFsk', '') is True:
					log("(navigator.ArdGetVideo) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Alterbeschränkungen geblockt !!!")
					return dialog.notification(translation(30526), translation(30527), icon, 8000)
				elif elem.get('geoblocked', '') is True:
					log("(navigator.ArdGetVideo) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Geo-Sperren geblockt !!!")
					return dialog.notification(translation(30526), translation(30528), icon, 8000)
	if not finalURL and MEDIAS:
		STREAM = 'MP4'
		ARD_Url = 'https:'+MEDIAS[0]['url'] if MEDIAS[0]['url'][:4] != 'http' else MEDIAS[0]['url']
		debug_MS("(navigator.ArdGetVideo) SORTED_LIST | MP4 ### MEDIAS : {0} ###".format(str(MEDIAS)))
		log("(navigator.ArdGetVideo) Auswahl vom *mp4-Stream* (ARD+3) : {0}".format(ARD_Url))
		finalURL = VideoBEST(ARD_Url, improve='ard-YES') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	if finalURL and STREAM:
		listitem = xbmcgui.ListItem(path=finalURL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and STREAM == 'M3U8':
			listitem.setMimeType('application/vnd.apple.mpegurl')
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
		log("(navigator.ArdGetVideo) END-Qualität (ARD+3) : {0}_stream : {1}".format(STREAM, finalURL))
	else:
		failing("(navigator.ArdGetVideo) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
		dialog.notification(translation(30523).format('ARD - Intern'), translation(30525), icon, 8000)
	log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")

def RtlGetVideo(SERIES, EPISODE, REFERER):
	if xbmc.getCondVisibility('System.HasAddon(plugin.video.rtlgroup.de)'):
		# OLD = http://api.tvnow.de/v3/movies/shopping-queen/2361-lisa-marie-nuernberg-flower-power-praesentiere-dich-in-deinem-neuen-bluetenkleid?fields=manifest,isDrm,free,payed
		# NEW = https://api.tvnow.de/v3/movies?filter={%22FormatId%22:%2219022%22}&fields=manifest,id,isDrm,free,payed
		try: # https://bff.apigw.tvnow.de/module/player/%d" % int(assetID)
			StreamID = SERIES.split('-')[-1].strip() if len(EPISODE) > 6 else EPISODE
			content = getUrl('https://api.tvnow.de/v3/movies?filter={%22FormatId%22:%22'+StreamID+'%22}&fields=manifest,id,isDrm,free,payed&maxPerPage=500')
			DATA = json.loads(content)
			MoreThanOne = (True if len(DATA['items']) > 1 else False)
			for item in DATA['items']:
				videoFREE, videoHD = ("" for _ in range(2))
				if (MoreThanOne is True and str(item.get('id', '0')) == EPISODE) or MoreThanOne is False:
					EPnumber = (str(item.get('id', '0')) or '0')
					PayType = (item.get('payed', True) or item.get('free', True))
					protected = (item.get('isDrm', False) or False)
					log("(navigator.RtlGetVideo) ~~~ Ist dieses Video DRM - geschützt ??? = {0} ~~~".format(str(protected)))
					if item.get('manifest', '') and item.get('manifest', {}).get('dash', ''): # Normal-Play without Account
						videoFREE = item['manifest']['dash'].replace('dash.secure.footprint.net', 'dash-a.akamaihd.net')
						debug_MS("(navigator.RtlGetVideo) videoFREE : {0}".format(videoFREE))
					if item.get('manifest', '') and item.get('manifest', {}).get('dashhd', ''): # HD-Play with Pay-Account
						videoHD = item['manifest']['dashhd'].replace('dash.secure.footprint.net', 'dash-a.akamaihd.net').split('.mpd')[0]+'.mpd'
						debug_MS("(navigator.RtlGetVideo) videoHD : {0}".format(videoHD))
					listitem = xbmcgui.ListItem(path='{0}?{1}'.format('plugin://plugin.video.rtlgroup.de/', urlencode({'mode': 'playDash', 'xnormSD': videoFREE, 'xhighHD': videoHD, 'xcode': EPnumber, 'xlink': REFERER, 'xdrm': protected, 'xstat': PayType})))
					xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
		except:
			failing("(RtlGetVideo) AbspielLink-00 (RTLPLUS (TVNOW)) : *RTLPLUS-Plugin* Der angeforderte -VideoLink- existiert NICHT !!!")
			dialog.notification(translation(30523).format('RTLPLUS (TVNOW) - Plugin'), translation(30525), icon, 8000)
	else:
		failing("(navigator.RtlGetVideo) AbspielLink-00 (RTLPLUS (TVNOW)) : KEIN *RTLPLUS - V.3 - Addon* zur Wiedergabe vorhanden !!!")
		dialog.notification(translation(30523).format('RTLPLUS (TVNOW) - Addon'), translation(30524).format('RTLPLUS - V.3'), icon, 8000)
	log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")

def ZdfGetVideo(videoURL):
	debug_MS("(navigator.ZdfGetVideo) ------------------------------------------------ START = ZdfGetVideo -----------------------------------------------")
	videoFOUND = False
	req_FIRST = getUrl(videoURL)
	docuLINK = re.compile(r'(?s)data-zdfplayer-jsb=["\'](?P<json>{.+?})["\']', re.S).findall(req_FIRST)
	target_PAGE = docuLINK[0] if docuLINK else False
	debug_MS("(navigator.ZdfGetVideo) ##### targetLINKS : {0} #####".format(str(target_PAGE)))
	if target_PAGE:
		firstURL = json.loads(target_PAGE)
		teaser = firstURL['content']
		secret = firstURL['apiToken']
		headerfields = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0'), ('Api-Auth', 'Bearer '+secret)]
		log("(navigator.ZdfGetVideo) SECRET gefunden (ZDF+3) : ***** {0} *****".format(str(secret)))
		teaser = API_ZDF+teaser if teaser[:4] != 'http' else teaser
		debug_MS("(navigator.ZdfGetVideo) ##### TEASER : {0} #####".format(teaser))
		content = getUrl(teaser, header=headerfields)
		DATA_ONE = json.loads(content)
		if DATA_ONE.get('profile') == 'http://zdf.de/rels/not-found' or not ('contentType' in DATA_ONE):
			videoFOUND = False
		else:
			if DATA_ONE.get('contentType') in ['clip', 'episode']:
				videoFOUND = API_ZDF+DATA_ONE['mainVideoContent']['http://zdf.de/rels/target']['http://zdf.de/rels/streams/ptmd-template'].replace('{playerId}', 'ngplayer_2_4').replace('\/', '/')
				debug_MS("(navigator.ZdfGetVideo) ##### videoFOUND : {0} #####".format(videoFOUND))
				req_THIRD = getUrl(videoFOUND, header=headerfields)
				return ZdfExtractQuality(req_THIRD)
	if not target_PAGE or not videoFOUND:
		failing("(ZdfGetVideo) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
		log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")
		dialog.notification(translation(30523).format('ZDF - Intern'), translation(30525), icon, 8000)

def ZdfExtractQuality(req_THIRD):
	debug_MS("(navigator.ZdfExtractQuality) ------------------------------------------------ START = ZdfExtractQuality -----------------------------------------------")
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.ZdfExtractQuality) XXXXX CONTENT : {0} XXXXX".format(str(req_THIRD)))
	debug_MS("++++++++++++++++++++++++")
	DATA_TWO = json.loads(req_THIRD)
	MEDIAS = []
	STREAM, finalURL = (False for _ in range(2))
	m3u8_QUALITIES = ['auto', 'veryhigh', 'high', 'med']
	mp4_QUALITIES = ['hd', 'veryhigh', 'high', 'low']
	if 'attributes' in DATA_TWO and DATA_TWO['attributes']:
		#if DATA_TWO.get('attributes', '') and DATA_TWO.get('attributes', {}).get('fsk', '') and DATA_TWO.get('attributes', []).get('fsk', {}).get('value', ''):
			#if DATA_TWO['attributes']['fsk']['value'] != 'none':
				#log("(navigator.ZdfExtractQuality) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Der angeforderte -VideoLink- wurde auf Grund von Alterbeschränkungen geblockt !!!")
				#return dialog.notification(translation(30526), translation(30527), icon, 8000)
		if DATA_TWO.get('attributes', '') and DATA_TWO.get('attributes', {}).get('geoLocation', '') and DATA_TWO.get('attributes', []).get('geoLocation', {}).get('value', ''):
			if DATA_TWO['attributes']['geoLocation']['value'] != 'none':
				try: 
					req_FOURTH = getUrl('http://ip-api.com/json/')
					countryCode = re.compile('"status":"success","country":".+?","countryCode":"([^"]+?)",', re.S).findall(req_FOURTH)
					if countryCode and countryCode[0].upper() != DATA_TWO['attributes']['geoLocation']['value'].upper():
						log("(navigator.ZdfExtractQuality) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Der angeforderte -VideoLink- wurde auf Grund von Geo-Sperren geblockt !!!")
						return dialog.notification(translation(30526), translation(30528), icon, 8000)
				except: pass
	for each in DATA_TWO.get('priorityList', []):
		formitaeten = each.get('formitaeten')
		if not isinstance(formitaeten, list):
			continue
		for item in formitaeten:
			if (enableINPUTSTREAM or prefSTREAM == '0') and item.get('type') == 'h264_aac_ts_http_m3u8_http' and item.get('mimeType').lower() == 'application/x-mpegurl':
				for found in m3u8_QUALITIES:
					for quality in item.get('qualities'):
						if quality['quality'] == found and 'mil/master.m3u8' in quality['audio']['tracks'][0]['uri']:
							MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': item.get('mimeType').lower(), 'language': quality['audio']['tracks'][0]['language']})
				debug_MS("(navigator.ZdfExtractQuality) SORTED_LIST | M3U8 ### MEDIAS : {0} ###".format(str(MEDIAS)))
				log("(navigator.ZdfExtractQuality) Auswahl vom *m3u8-Stream* (ZDF+3) : {0}".format(MEDIAS[0]['url']))
				STREAM = 'M3U8'
				finalURL = MEDIAS[0]['url']
			if not finalURL and item.get('type') == 'h264_aac_mp4_http_na_na' and 'progressive' in item.get('facets', []) and item.get('mimeType').lower() == 'video/mp4':
				for found in mp4_QUALITIES:
					for quality in item.get('qualities'):
						if quality['quality'] == found:
							MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': item.get('mimeType').lower(), 'language': quality['audio']['tracks'][0]['language']})
				debug_MS("(navigator.ZdfExtractQuality) SORTED_LIST | MP4 ### MEDIAS : {0} ###".format(str(MEDIAS)))
				log("(navigator.ZdfExtractQuality) Auswahl vom *mp4-Stream* (ZDF+3) : {0}".format(MEDIAS[0]['url']))
				STREAM = 'MP4'
				finalURL = VideoBEST(MEDIAS[0]['url'], improve='zdf-YES') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	if finalURL and STREAM:
		listitem = xbmcgui.ListItem(path=finalURL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and STREAM == 'M3U8':
			listitem.setMimeType('application/vnd.apple.mpegurl')
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
		log("(navigator.ZdfExtractQuality) END-Qualität (ZDF+3) : {0}_stream : {1}".format(STREAM, finalURL))
	else:
		failing("(navigator.ZdfExtractQuality) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Fehler bei Anforderung des AbspielLinks !!!")
		dialog.notification(translation(30523).format('ZDF - Intern'), translation(30525), icon, 8000)
	log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")

def VideoBEST(best_url, improve=False):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	standards = [best_url, "", ""]
	if improve == 'ard-YES':
		first_repls = (('/960', '/1280'), ('.hq.mp4', '.hd.mp4'), ('.l.mp4', '.xl.mp4'), ('_C.mp4', '_X.mp4'))
		second_repls = (('/1280', '/1920'), ('.xl.mp4', '.xxl.mp4'))
	elif improve == 'zdf-YES':
		first_repls = (('808k_p11v15', '2360k_p35v15'), ('1628k_p13v15', '2360k_p35v15'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'),
								('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
		second_repls = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'))
	standards[1] = reduce(lambda a, kv: a.replace(*kv), first_repls, standards[0])
	standards[2] = reduce(lambda b, kv: b.replace(*kv), second_repls, standards[1])
	for element in reversed(standards):
		if len(element) > 0:
			try:
				code = urlopen(element, timeout=6).getcode()
				if str(code) == '200':
					return element
			except: pass
	return best_url

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, studio=None, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': studio})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, studio=None, plot=None, duration=None, seriesname=None, genre=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Tvshowtitle'] = seriesname
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Genre'] = genre
	info['Studio'] = studio
	info['Mediatype'] = 'tvshow'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
