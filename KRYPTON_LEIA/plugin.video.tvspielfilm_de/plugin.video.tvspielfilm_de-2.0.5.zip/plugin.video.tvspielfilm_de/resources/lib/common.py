﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import time
from datetime import datetime, timedelta
import requests
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus, unquote_plus  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
	from urlparse import urljoin, urlparse  # Python 2.X
	from .external.concurrent.futures import *
	TRANS_PATH, LOG_MESSAGE, INPUT_APP = xbmc.translatePath, xbmc.LOGNOTICE, 'inputstreamaddon' # Stand: 05.12.20 / Python 2.X
else:
	from urllib.parse import urljoin, urlparse, urlencode, quote_plus, unquote_plus  # Python 3.X
	from urllib.request import urlopen  # Python 3.X
	from functools import reduce  # Python 3.X
	from concurrent.futures import *
	TRANS_PATH, LOG_MESSAGE, INPUT_APP = xbmcvfs.translatePath, xbmc.LOGINFO, 'inputstream' # Stand: 05.12.20  / Python 3.X
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


socket.setdefaulttimeout(30)
HOST_AND_PATH                 = sys.argv[0]
ADDON_HANDLE                  = int(sys.argv[1])
dialog                                      = xbmcgui.Dialog()
addon                                     = xbmcaddon.Addon()
addon_id                                = addon.getAddonInfo('id')
addon_name                         = addon.getAddonInfo('name')
addon_version                      = addon.getAddonInfo('version')
addonPath                             = TRANS_PATH(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                                = TRANS_PATH(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
defaultFanart                        = (os.path.join(addonPath, 'fanart.jpg') if PY2 else os.path.join(addonPath, 'resources', 'media', 'fanart.jpg'))
icon                                         = (os.path.join(addonPath, 'icon.png') if PY2 else os.path.join(addonPath, 'resources', 'media', 'icon.png'))
artpic                                      = os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
enableINPUTSTREAM          = addon.getSetting('useInputstream') == 'true'
prefSTREAM                           = addon.getSetting('prefer_stream')
showDATE                              = addon.getSetting('show_dates') == 'true'
showCHANNEL                      = addon.getSetting('show_channel') == 'true'
showARTE                              = (True if addon.getSetting('show_ARTE') == 'true' else False)
showJOYN                             = (True if addon.getSetting('show_JOYN') == 'true' else False)
showSERVUS                         = (True if addon.getSetting('show_SERVUS') == 'true' else False)
showTELE                               = (True if addon.getSetting('show_TELE5') == 'true' else False)
showNOW                              = (True if addon.getSetting('show_TVNOW') == 'true' else False)
useThumbAsFanart              = addon.getSetting('useThumbAsFanart') == 'true'
enableADJUSTMENT            = addon.getSetting('show_settings') == 'true'
DEB_LEVEL                             = (LOG_MESSAGE if addon.getSetting('enableDebug') == 'true' else xbmc.LOGDEBUG) # kompatibel mit Python-2 und Python-3
ARTEEX                                   = ['ARTE']
JOYNEX                                  = ['DMAX', 'KABEL 1', 'PROSIEBEN', 'PROSIEBEN MAXX', 'SAT.1', 'SAT.1 GOLD', 'SIXX']
SERVUSEX                              = ['SERVUSTV DEUTSCHLAND']
TELEEX                                    = ['TELE 5']
NOWEX                                   = ['NITRO', 'RTL', 'RTL 2', 'RTLUP', 'VOX', 'SRTL', 'TOGGO PLUS']
KODI_ov20                            = int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
BASE_URL                              = 'https://www.tvspielfilm.de'
API_ARD                                = 'https://api.ardmediathek.de/page-gateway/pages/'
API_ZDF                                 = 'https://api.zdf.de'

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py2_enc(s, nom='utf-8', ign='ignore'):
	if PY2:
		if not isinstance(s, basestring):
			s = str(s)
		s = s.encode(nom, ign) if isinstance(s, unicode) else s
	return s

def py2_uni(s, nom='utf-8', ign='ignore'):
	if PY2 and isinstance(s, str):
		s = unicode(s, nom, ign)
	return s

def py3_dec(d, nom='utf-8', ign='ignore'):
	if not PY2 and isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return py2_enc(addon.getLocalizedString(id))

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=LOG_MESSAGE): # kompatibel mit Python-2 und Python-3
	msg = py2_enc(msg)
	return xbmc.log('[{0} v.{1}]{2}'.format(addon_id, addon_version, msg), level)

def get_userAgent():
	base = 'Mozilla/5.0 {0} AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36'
	if xbmc.getCondVisibility('System.Platform.Android'):
		if 'arm' in os.uname()[4]: return base.format('(X11; CrOS armv7l 7647.78.0)') # ARM based Linux
		return base.format('(X11; Linux x86_64)') # x86 Linux
	elif xbmc.getCondVisibility('System.Platform.Windows'):
		return base.format('(Windows NT 10.0; WOW64)') # Windows
	elif xbmc.getCondVisibility('System.Platform.IOS'):
		return base.format('(iPhone; CPU iPhone OS 10_3 like Mac OS X)') # iOS iPhone/iPad
	elif xbmc.getCondVisibility('System.Platform.Darwin'):
		return base.format('(Macintosh; Intel Mac OS X 10_10_1)') # Mac OSX
	return base.format('(X11; Linux x86_64)') # x86 Linux

def _header(REFERRER=None, CODE=None, USERTOKEN=None):
	header = {}
	header['Pragma'] = 'no-cache'
	header['User-Agent'] = get_userAgent()
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	header['Accept-Language'] = 'en-US,en;q=0.8,de;q=0.7'
	if REFERRER:
		header['Referer'] = REFERRER
	if CODE and USERTOKEN:
		header[CODE] = USERTOKEN
	return header

def getMultiData(MURLS, method='GET', REF=None, WAY=None, AUTH=None, fields=None):
	COMBI_NEW = []
	number = len(MURLS)
	counter = 0
	def download(pos, url, cmanager):
		response = cmanager.request(method, url, fields, headers=_header(REF, WAY, AUTH), timeout=5, retries=2)
		if response and response.status == 200:
			debug_MS("(common.getMultiData) === URL that wanted : {0} ===".format(url))
			return [pos, url, py3_dec(response.data)]
		else:
			failing("(common.getMultiData) ERROR - ERROR - ERROR : ##### pos: {0} === status: {1} === url: {2} #####".format(str(pos), str(response.status), url))
			return [pos, url, None]
	with ThreadPoolExecutor() as executor:
		conn_mgr = urllib3.PoolManager(maxsize=10, block=True)
		future_connect = [executor.submit(download, pos, url, conn_mgr) for pos, url in MURLS]
		wait(future_connect, timeout=30, return_when=ALL_COMPLETED)
		for ii, future in enumerate(as_completed(future_connect), 1):
			try:
				COMBI_NEW.append(future.result())
				if ii == number:
					for item in COMBI_NEW:
						if item[2] is None: counter += 1
					if counter == number:
						dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 10000)
			except Exception as e:
				failing("(common.getMultiData) ERROR - ERROR - ERROR : ##### no: {0} === url: {1} === error: {2} #####".format(str(ii), url, str(e)))
				dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(str(e)), icon, 10000)
				executor.shutdown()
				return sys.exit(0)
		return COMBI_NEW

def getUrl(url, method='GET', REF=None, WAY=None, AUTH=None, headers=None, cookies=None, allow_redirects=True, verify=True, stream=None, data=None, json=None):
	simple = requests.Session()
	ANSWER = None
	try:
		response = simple.get(url, headers=_header(REF, WAY, AUTH), allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=30)
		ANSWER = response.json() if method in ['GET', 'POST'] else py2_enc(response.text) if method == 'LOAD' else response
		debug_MS("(common.getUrl) === CALLBACK === status : {} || url : {} || header : {} ===".format(str(response.status_code), response.url, _header(REF, WAY, AUTH)))
	except requests.exceptions.RequestException as e:
		failing("(common.getUrl) ERROR - ERROR - ERROR : ##### url: {0} === error: {1} #####".format(url, str(e)))
		dialog.notification(translation(30521).format('URL'), translation(30523).format(str(e)), icon, 10000)
		return sys.exit(0)
	return ANSWER

def ADDON_operate(IDD):
	js_query = xbmc.executeJSONRPC('{{"jsonrpc":"2.0", "id":1, "method":"Addons.GetAddonDetails", "params":{{"addonid":"{}", "properties":["enabled"]}}}}'.format(IDD))
	if '"enabled":false' in js_query:
		try:
			xbmc.executeJSONRPC('{{"jsonrpc":"2.0", "id":1, "method":"Addons.SetAddonEnabled", "params":{{"addonid":"{}", "enabled":true}}}}'.format(IDD))
			failing("(common.ADDON_operate) ERROR - ERROR - ERROR :\n##### Das benötigte Addon : *{0}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####".format(IDD))
		except: pass
	if '"error":' in js_query:
		dialog.ok(addon_id, translation(30501).format(IDD))
		failing("(common.ADDON_operate) ERROR - ERROR - ERROR :\n##### Das benötigte Addon : *{0}* ist NICHT installiert !!! #####".format(IDD))
		return False
	if '"enabled":true' in js_query:
		return True

def cleaning(text):
	if text is not None:
		text = py2_enc(text)
		for n in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\xc2\xb7', '-'),
					("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''),
					('&#xC4;', 'Ä'), ('&#xE4;', 'ä'), ('&#xD6;', 'Ö'), ('&#xF6;', 'ö'), ('&#xDC;', 'Ü'), ('&#xFC;', 'ü'), ('&#xDF;', 'ß'), ('&#x201E;', '„'), ('&#xB4;', '´'), ('&#x2013;', '-'), ('&#xA0;', ' '),
					('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
					('&agrave;', 'à'), ('&Agrave;', 'À'), ('&aacute;', 'á'), ('&Aacute;', 'Á'), ('&acirc;', 'â'), ('&Acirc;', 'Â'), ('&egrave;', 'è'), ('&Egrave;', 'È'), ('&eacute;', 'é'), ('&Eacute;', 'É'), ('&ecirc;', 'ê'), ('&Ecirc;', 'Ê'),
					('&igrave;', 'ì'), ('&Igrave;', 'Ì'), ('&iacute;', 'í'), ('&Iacute;', 'Í'), ('&icirc;', 'î'), ('&Icirc;', 'Î'), ('&ograve;', 'ò'), ('&Ograve;', 'Ò'), ('&oacute;', 'ó'), ('&Oacute;', 'Ó'), ('&ocirc;', 'ô'), ('&Ocirc;', 'Ô'),
					('&ugrave;', 'ù'), ('&Ugrave;', 'Ù'), ('&uacute;', 'ú'), ('&Uacute;', 'Ú'), ('&ucirc;', 'û'), ('&Ucirc;', 'Û'), ('&yacute;', 'ý'), ('&Yacute;', 'Ý'),
					('&atilde;', 'ã'), ('&Atilde;', 'Ã'), ('&ntilde;', 'ñ'), ('&Ntilde;', 'Ñ'), ('&otilde;', 'õ'), ('&Otilde;', 'Õ'), ('&Scaron;', 'Š'), ('&scaron;', 'š'), ('&ccedil;', 'ç'), ('&Ccedil;', 'Ç'),
					("\\'", "'"), ('<br/> ', '[CR]'), ('<br/>', '[CR]'), ('Ã¶', 'ö')):
					text = text.replace(*n)
		text = text.strip()
	return text

def cleanStation(channelID):
	# ARD, ZDF, RTL, SAT1, PRO7, K1, RTL2, VOX, TELE5, 3SAT, ARTE, 2NEO, FES, SERVU, RTL-N, DMAX, SIXX, SAT1G, PRO7M, RTLPL, WDR, N3, BR, SWR, HR, MDR, RBB, ALPHA, ZINFO, SUPER, KIKA
	channelID = py2_enc(channelID).replace(' Programm', '').replace(' programm', '').replace(' Mediathek', '')
	ChannelCode = ('ARD','Das Erste','ONE','FES','ZDF','2NEO','ZNEO','2INFO','ZINFO','3SAT','ALPHA','Arte','ARTE','BR','DMAX','HR','kabel eins','K1','KIKA','KiKA','MDR','NDR','N3','ORF','PHOEN',\
								'PRO7','PRO7M','RBB','SAT1','SAT1G','SAT.1G','SERVU','SIXX','SR','SWR','SWR/SR','WDR','RTL','RTL2','RTL II','RTLPL','RTL-N','SRTL','SUPER RTL','SUPER','TOGGO','TELE5','WELT','VOX')
	if channelID in ChannelCode and channelID != "":
		for n in ((' ', ''), ('ARD', 'Das Erste'), ('DasErste', 'Das Erste'), ('FES', 'ONE'), ('Arte', 'ARTE'), ('K1', 'Kabel 1'), ('kabeleins', 'Kabel 1'), ('KIKA', 'KiKA'), ('2INFO', 'ZDFinfo'), ('ZINFO', 'ZDFinfo'),\
					('2NEO', 'ZDFneo'), ('ZNEO', 'ZDFneo'), ('3SAT', '3sat'), ('N3', 'NDR'), ('PHOEN', 'PHOENIX'), ('PRO7M', 'ProSieben MAXX'), ('PRO7', 'ProSieben'), ('RTLII', 'RTL 2'), ('RTL-N', 'NITRO'), ('RTLPL', 'RTLup'),\
					('SAT.1G', 'SAT.1 Gold'), ('SAT1G', 'SAT.1 Gold'), ('SAT1', 'SAT.1'), ('SERVU', 'ServusTV Deutschland'), ('SUPERRTL', 'SRTL'), ('SUPER', 'SRTL'), ('TELE5', 'TELE 5'), ('TOGGO', 'TOGGO plus')):
					channelID = channelID.replace(*n)
	if channelID in ['ARD-alpha', 'ALPHA']: channelID = 'ARD alpha'
	if channelID in ['SWR', 'SR', 'SWR/SR']: channelID = 'SWR'
	channelID = '  ('+channelID+')' if channelID != "" else channelID
	studio = channelID.replace('(', '').replace(')', '').replace('  ', '')
	return (channelID, studio)

def parameters_string_to_dict(parameters):
	paramDict = {}
	if parameters:
		paramPairs = parameters[1:].split('&')
		for paramsPair in paramPairs:
			paramSplits = paramsPair.split('=')
			if (len(paramSplits)) == 2:
				paramDict[paramSplits[0]] = paramSplits[1]
	return paramDict

params = parameters_string_to_dict(sys.argv[2])
url = unquote_plus(params.get('url', ''))
mode = unquote_plus(params.get('mode', 'root'))
extras = unquote_plus(params.get('extras', '')) if params.get('extras') not in ['None', None] else None
