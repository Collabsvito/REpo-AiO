﻿# -*- coding: utf-8 -*-

import sys
import os
import platform
import xbmc
import xbmcaddon
import xbmcvfs
import time
from datetime import datetime, timedelta
import sqlite3
PY2 = sys.version_info[0] == 2


global debuging
addon                                = xbmcaddon.Addon()
addon_id                           = addon.getAddonInfo('id')
addon_name                    = addon.getAddonInfo('name')
addon_version                 = addon.getAddonInfo('version')
addonPath                        = xbmc.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                            = xbmc.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
temp                                   = xbmc.translatePath(os.path.join(dataPath, 'temp', '')).encode('utf-8').decode('utf-8')
Database                           = os.path.join(temp, 'MyTimeOrders.db')

wait_time = 180  # 180 seconds = 3 minutes - wait at KODI start
loop_time = 3600  # 3600 seconds = 1 hour - time when the process started again

def py2_enc(s, encoding='utf-8'):
	if PY2:
		if not isinstance(s, basestring):
			s = str(s)
		s = s.encode(encoding) if isinstance(s, unicode) else s
	return s

def py2_uni(s, encoding='utf-8'):
	if PY2 and isinstance(s, str):
		s = unicode(s, encoding)
	return s

def translation(id):
	return py2_enc(addon.getLocalizedString(id))

def special(msg, level=xbmc.LOGNOTICE):
	xbmc.log(msg, level)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug(content):
	log(content, xbmc.LOGDEBUG)

def log(msg, level=xbmc.LOGNOTICE):
	msg = py2_enc(msg)
	return xbmc.log('[{0} v.{1}]{2}'.format(addon_id, addon_version, msg), level)

if __name__ == '__main__':
	special("#############################################################################################")
	special("########## RUNNING: "+addon_id+" VERSION "+addon_version+" / ON PLATFORM: "+platform.system()+" ##########")
	special("################# Start the Service in 3 minutes - wait for other Instances to close #######################")
	special("#############################################################################################")
	time.sleep(wait_time)
	log("########## START SERVICE ##########")
	MAX_ERRORS = 10
	errors = 0
	monitor = xbmc.Monitor()
	while not monitor.abortRequested():
		if not xbmc.getCondVisibility('Library.IsScanningVideo'):
			debug("(service) ########## START LOOP ... ##########")
			try:
				conn = sqlite3.connect(Database)
				cur = conn.cursor()
				cur.execute('SELECT * FROM stocks')
				r = list(cur)
				conn.commit()
				cur.close()
				conn.close()
				for member in r:
					stunden = member[0]
					url = member[1]
					name = py2_uni(member[2])
					name += '  ('+url.split('@@')[1].split('&')[0]+')' if '@@' in url else '  (Serie)'
					updated = member[3]
					debug("(service) ###### Control-Session for TITLE = {0} || LASTUPDATE: {1} ##########".format(name, updated))
					now = datetime.now()
					previous = datetime(*(time.strptime(updated, '%Y{0}%m{0}%d %H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2019-06-23 14:10:00
					if now > previous + timedelta(hours=stunden):
						log("########## start ACTION for TITLE = {0} || LASTUPDATE: {1} ##########".format(name, updated))
						conn = sqlite3.connect(Database)
						cur = conn.cursor()
						cur.execute('UPDATE stocks SET last = {0} WHERE url = \"{1}\"'.format("datetime('now', 'localtime')", url))
						conn.commit()
						cur.close()
						conn.close()
						xbmc.executebuiltin('RunPlugin('+url+')')
			except Exception as e:
				failure = str(e)
				errors += 1
				if errors >= MAX_ERRORS:
					failing("(service) ERROR - ERROR - ERROR : ########## ({0}) received... (Number: {1}/{2}) ...Ending Service ##########".format(failure, errors, MAX_ERRORS))
					break
				else:
					failing("(service) ERROR - ERROR - ERROR : ########## ({0}) received... (Number: {1}/{2}) ...Continuing Service ##########".format(failure, errors, MAX_ERRORS))
			else:
				errors = 0
			debug("(service) ########## ... END LOOP ##########")
			if monitor.waitForAbort(loop_time):
				break
