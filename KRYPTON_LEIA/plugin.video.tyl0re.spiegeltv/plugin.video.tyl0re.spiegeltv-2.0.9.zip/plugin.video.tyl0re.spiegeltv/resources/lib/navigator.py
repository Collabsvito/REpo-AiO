﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus  # Python 2.X
else:
	from urllib.parse import urlencode, quote_plus  # Python 3.X

from .common import *


def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listThemes', 'url': BASE_URL+'/video/', 'limit': '2'})
	addDir(translation(30602), icon, {'mode': 'listThemes', 'url': BASE_URL+'/thema/spiegel-tv/'})
	addDir(translation(30603), icon, {'mode': 'listThemes', 'url': BASE_URL+'/thema/der-spiegel-liest-live/'})
	addDir(translation(30604), icon, {'mode': 'listThemes', 'url': BASE_URL+'/panorama/', 'limit': '10'})
	addDir(translation(30605), icon, {'mode': 'listThemes', 'url': BASE_URL+'/politik/ausland/', 'limit': '8'})
	addDir(translation(30606), icon, {'mode': 'listThemes', 'url': BASE_URL+'/politik/deutschland/', 'limit': '8'})
	addDir(translation(30610), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'UU1w6pNGiiLdZgyNpXUnA4Zw'})
	addDir(translation(30611), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PL54B134AD9A7A86C8', 'extras': 'lowQ'})
	addDir(translation(30612), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PLuiYhcgFTmqD24gcCDlpmGK75hIgjJXfl'})
	addDir(translation(30613), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PL8B9FDFC553E79FC6'})
	addDir(translation(30614), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PLuiYhcgFTmqDTfN9kw9H3u_lqBymi_kop'})
	addDir(translation(30615), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PLuiYhcgFTmqBmHD5Rnvu2IWdW3ZNlyF6N'})
	addDir(translation(30616), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PLuiYhcgFTmqCqURWOR9LfQPAIHkc9mRDv'})
	addDir(translation(30617), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PU1w6pNGiiLdZgyNpXUnA4Zw', 'extras': 'lowQ'})
	addDir(translation(30618), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PLuiYhcgFTmqCMQU0Tk7jXA8jp-Z7k1koZ', 'extras': 'lowQ'})
	addDir(translation(30619), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PLuiYhcgFTmqA72mlhLUzweIGU8Bk3oub8', 'extras': 'lowQ'})
	addDir(translation(30620), icon, {'mode': 'listYTcategories', 'url': BASE_YT+'PLuiYhcgFTmqCEzEfAa9eAoxQzEEmQW5XH'})
	if enableADJUSTMENT:
		addDir(translation(30631), artpic+'settings.png', {'mode': 'aSettings'})
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30632), artpic+'settings.png', {'mode': 'iSettings'})
		else:
			addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listThemes(url, plusLIMIT):
	debug_MS("(navigator.listThemes) -------------------------------------------------- START = listThemes --------------------------------------------------")
	debug_MS("(navigator.listThemes) ### URL = {0} ### plusLIMIT = {1} ### PAGINATION = {2} ###".format(url, plusLIMIT, str(Pagination)))
	Isolated = set()
	pageNUMBER = 1
	position = 0
	total = 1
	while total > 0 and pageNUMBER <= Pagination + int(plusLIMIT):
		try:
			PGurl = url+'p'+str(pageNUMBER)+'/' if int(pageNUMBER) > 1 else url
			debug_MS("(navigator.listThemes) ### START GET THE pageURL : {0} ###".format(str(PGurl)))
			content = getUrl(PGurl)
			results = re.findall(r'(?:<section class="relative flex flex-wrap w-full" data-size="full" data-first="true" data-area="block>topic|<section data-area="article-teaser-list">)(.+?)data-area="footer"', content, re.S)
			for chtml in results:
				debug_MS("(navigator.listThemes) no.1 XXXXX CHTML : {0} XXXXX".format(str(chtml)))
				part = chtml.split('data-block-el="articleTeaser"')
				for i in range(1, len(part), 1):
					entry = part[i]
					Note_1, Note_2 = ("" for _ in range(2))
					title = re.compile('<article aria-label="([^"]+?)"', re.S).findall(entry)[0]
					title = cleaning(title)
					if title in Isolated:
						continue
					Isolated.add(title)
					link = re.compile('<a href="([^"]+?)" target=', re.S).findall(entry)[0].strip()
					img = re.compile('<img data-image-el="img".*?src="([^"]+?)" srcset=', re.S).findall(entry) #.replace('_w488_', '_w1200_')
					photo = img[0] if img else ""
					photo = photo.split('_fd')[0]+'.jpg' if '_fd' in photo else photo
					tag = re.compile(r'(?:text-primary-dark font-sansUI font-bold text-base">|text-primary-base font-sansUI font-bold text-base">)([^<]+?)</span>', re.S).findall(entry)
					tagline = cleaning(tag[0]) if tag else ""
					desc1 = re.compile('<footer class="font-sansUI text-shade-dark text-s">(.+?)</span>', re.S).findall(entry)
					Note_1 = translation(30633).format(cleaning(re.sub(r'\<.*?\>', '', desc1[0]))) if desc1 else ""
					desc2 = re.compile('class="font-serifUI font-normal text-base leading-loose mr-6">(.+?)</a>', re.S).findall(entry)
					Note_2 = cleaning(re.sub(r'\<.*?\>', '', desc2[0])) if desc2 else ""
					plot = Note_1+Note_2
					try: duration = get_Seconds(re.compile('<span class="text-white font-sansUI text-s font-bold">([^<]+?)</span>', re.S).findall(entry)[0].strip())
					except: duration = '0'
					debug_MS("(navigator.listThemes) no.2 ### TITLE = {0} || LINK = {1} || DURATION = {2} ###".format(title, link, str(duration)))
					debug_MS("(navigator.listThemes) no.2 ### FOTO = {0} || TAGLINE = {1} ###".format(photo, tagline))
					if duration != '0':
						addLink(title, photo, {'mode': 'playVideo', 'url': link}, plot, duration, tagline=tagline)
				position += 1
				debug_MS("(navigator.listThemes) ### END OF ENTRIES - pagePOSITION : {0} ###".format(str(position)))
		except: total = 0
		pageNUMBER += 1
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listYTcategories(url, QUALITY):
	debug_MS("(navigator.listYTcategories) -------------------------------------------------- START = listYTcategories --------------------------------------------------")
	debug_MS("(navigator.listYTcategories) ### URL = {0} ### QUALITY = {1} ###".format(url, QUALITY))
	response = getUrl(url)
	DATA = json.loads(response)
	for item in DATA['video']:
		debug_MS("(navigator.listYTcategories) no.1 XXXXX FOLGE : {0} XXXXX".format(str(item)))
		Note_1, Note_2 = ("" for _ in range(2))
		startTIMES, year, begins = (None for _ in range(3))
		xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
		xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
		xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_DURATION)
		title = cleaning(item.get('title', ''))
		if str(item.get('time_created', '')).isdigit():
			LOCALstart = datetime.fromtimestamp(item.get('time_created'))
			startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('-', '•', ':')
			year = LOCALstart.strftime('%Y')
			begins = LOCALstart.strftime('%d{0}%m{0}%Y').format('.')
		if startTIMES:
			xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_DATE)
			Note_1 = translation(30634).format(str(startTIMES))
		Note_2 = get_Description(item)
		plot = Note_1+Note_2
		if QUALITY == 'lowQ':
			photo = (item.get('thumbnail', '').replace('/default.jpg', '/hqdefault.jpg') or "")
		else: photo = (item.get('thumbnail', '').replace('/default.jpg', '/maxresdefault.jpg') or "")
		videoId = (str(item.get('encrypted_id', '')) or "")
		duration = (item.get('length_seconds', '0') or '0')
		rating = (str(item.get('rating', '')) or "")
		votes = (str(item.get('likes', '')) or "")
		debug_MS("(navigator.listYTcategories) no.2 ### TITLE = {0} || videoID = {1} || DURATION = {2} ###".format(title, videoId, str(duration)))
		debug_MS("(navigator.listYTcategories) no.2 ### FOTO = {0} || startTIMES = {1} || VOTES = {2} ###".format(photo, str(startTIMES), votes))
		addLink(title, photo, {'mode': 'playVideo', 'url': videoId, 'extras': 'YTstream'}, plot, duration, rating, votes, year, begins)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)  

def playVideo(url, TYPE):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL = {0} ### TYPE = {1} ###".format(url, TYPE))
	if TYPE == 'YTstream':
		finalURL = 'plugin://plugin.video.youtube/play/?video_id='+url
		listitem = xbmcgui.ListItem(path=finalURL)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else: # https://cdn.jwplayer.com/v2/media/Ks1yAFoQ?sources=hls,dash,mp4
		MEDIAS = []
		finalURL = False
		streamTYPE = False
		try:
			content = getUrl(url).replace('&#34;', '"')
			IDD = re.compile('"mediaId":"(.+?)",', re.DOTALL).findall(content)[0].strip()
		except:
			failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *spiegel.de* gefunden !!! ##########".format(url))
			return dialog.notification(translation(30521).format('Play 1'), translation(30526), icon, 8000)
		response = getUrl('https://vcdn01.spiegel.de/v2/media/'+str(IDD)+'?sources=hls,dash,mp4')
		debug_MS("++++++++++++++++++++++++")
		debug_MS("(navigator.playVideo) RESPONSE : {0}".format(str(response)))
		debug_MS("++++++++++++++++++++++++")
		DATA = json.loads(response)
		for elem in DATA['playlist'][0]['sources']:
			type = elem['type']
			vid = elem['file']
			if type.lower() == 'video/mp4':
				height = elem['height'] if 'height' in elem else '0'
				MEDIAS.append({'url': vid, 'mimeType': type.lower(), 'height': height})
				MEDIAS = sorted(MEDIAS, key=lambda b:b['height'], reverse=True)
				debug_MS("(navigator.playVideo) listing_1_MEDIAS ### HEIGHT = "+str(height)+" || URL = "+vid+" || mimeTYPE = "+str(type)+" ###")
			if type.lower() == 'application/vnd.apple.mpegurl':
				if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
					finalURL = vid
					streamTYPE = 'HLS'
					debug_MS("(navigator.playVideo) listing_2_HLS ### finalURL = "+finalURL+" || mimeTYPE = "+str(type)+" || streamTYPE = "+streamTYPE+" ###")
				elif not enableINPUTSTREAM and prefSTREAM == '0':
					finalURL = vid
					streamTYPE = 'M3U8'
					debug_MS("(navigator.playVideo) listing_2_M3U8 ### finalURL = "+finalURL+" || mimeTYPE = "+str(type)+" || streamTYPE = "+streamTYPE+" ###")
		if not finalURL and MEDIAS:
			for item in MEDIAS:
				if prefSTREAM == '1' and item['height'] == prefQUALITY:
					finalURL = item['url']
					streamTYPE = 'MP4'
					debug_MS("(navigator.playVideo) listing_2_MP4 ### HEIGHT = "+str(item['height'])+" || finalURL = "+finalURL+" || mimeTYPE = "+str(item['mimeType'])+" || streamTYPE = "+streamTYPE+" ###")
		if not finalURL and MEDIAS:
			finalURL = MEDIAS[0]['url']
			streamTYPE = 'MP4'
			log("(navigator.playVideo) !!!!! KEINEN passenden Stream gefunden --- nehme jetzt den Reserve-Stream-MP4 !!!!!")
			debug_MS("(navigator.playVideo) listing_2_RESERVE ### HEIGHT = "+str(MEDIAS[0]['height'])+" || finalURL = "+finalURL+" || mimeTYPE = "+str(MEDIAS[0]['mimeType'])+" || streamTYPE = "+streamTYPE+" ###")
		if finalURL and streamTYPE:
			log("(navigator.playVideo) {0}_stream : {1}".format(streamTYPE, finalURL))
			listitem = xbmcgui.ListItem(path=finalURL)
			if streamTYPE == 'HLS':
				listitem.setMimeType('application/x-mpegURL')
				listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
				listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
		else: 
			failing("(navigator.playVideo) ##### Die angeforderte Video-Url wurde leider NICHT gefunden !!! #####")
			return dialog.notification(translation(30521).format('PLAY 2'), translation(30526), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)

def addLink(name, image, params={}, plot=None, duration=None, rating=None, votes=None, year=None, begins=None, episode=None, tagline=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Episode'] = episode
	info['Tvshowtitle'] = None
	info['Title'] = name
	info['Tagline'] = tagline
	info['Plot'] = plot
	info['Duration'] = duration
	if begins is not None:
		info['Date'] = begins
	info['Year'] = year
	info['Genre'] = 'News'
	info['Rating'] = rating
	info['Votes'] = votes
	info['Studio'] = 'Der Spiegel'
	info['Mediatype'] = 'tvshow'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
