﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
else: 
	from urllib.parse import urlencode  # Python 3.X

from .common import *


def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listThemes', 'url': BASE_URL+'/video/', 'limit': '4'})
	addDir(translation(30602), icon, {'mode': 'listThemes', 'url': BASE_URL+'/thema/spiegel-tv/'})
	addDir(translation(30603), icon, {'mode': 'listThemes', 'url': BASE_URL+'/panorama/', 'limit': '15'})
	addDir(translation(30604), icon, {'mode': 'listThemes', 'url': BASE_URL+'/ausland/', 'limit': '15'})
	addDir(translation(30605), icon, {'mode': 'listThemes', 'url': BASE_URL+'/politik/deutschland/', 'limit': '8'})
	addDir(translation(30606), icon, {'mode': 'listThemes', 'url': BASE_URL+'/thema/der-spiegel-liest-live/'})
	addDir(translation(30607), icon, {'mode': 'listThemes', 'url': BASE_URL+'/thema/spitzengespraech-der-talk-mit-markus-feldenkirchen/'})
	addDir(translation(30608), icon, {'mode': 'listThemes', 'url': BASE_URL+'/thema/spitzentitel-die-buechershow-mit-volker-weidermann/'})
	addDir(translation(30609), icon, {'mode': 'listThemes', 'url': BASE_URL+'/thema/auto-tests-im-video/'})
	addDir(translation(30610), icon, {'mode': 'listThemes', 'url': BASE_URL+'/thema/coronavirus-videos/', 'limit': '3'})
	if enableYOUTUBE:
		addDir(translation(30621), icon, {'mode': 'listYTcategories'})
	if enableADJUSTMENT:
		addDir(translation(30622), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30623), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listThemes(url, plusLIMIT):
	debug_MS("(navigator.listThemes) -------------------------------------------------- START = listThemes --------------------------------------------------")
	debug_MS("(navigator.listThemes) ### URL = {0} ### plusLIMIT = {1} ### PAGINATION = {2} ###".format(url, plusLIMIT, str(Pagination)))
	Isolated = set()
	pageNUMBER = 1
	position = 0
	total = 1
	while total > 0 and pageNUMBER <= Pagination + int(plusLIMIT):
		try:
			PGurl = '{0}p{1}/'.format(url, str(pageNUMBER)) if int(pageNUMBER) > 1 else url
			debug_MS("(navigator.listThemes) ### START GET THE pageURL : {0} ###".format(str(PGurl)))
			content = getUrl(PGurl)
			if url.endswith('/video/'):
				results = re.findall(r'(?:<section class="relative flex flex-wrap w-full" data-size="full" data-first="true" data-area="block>topic|data-area="article-teaser-list")(.+?)(?:data-area="footer"|<section class="relative flex flex-wrap w-full")', content, re.S)
			else:
				results = re.findall(r'(?:<section class="relative flex flex-wrap w-full" data-size="full" data-first="true" data-area="block>topic|data-area="article-teaser-list")(.+?)data-area="footer"', content, re.S)
			for chtml in results:
				debug_MS("(navigator.listThemes[1]) XXXXX CHTML : {0} XXXXX".format(str(chtml)))
				part = chtml.split('data-block-el="articleTeaser"')
				for i in range(1, len(part), 1):
					entry = part[i]
					tagline, NOTE_1, NOTE_2, NOTE_3, description = ("" for _ in range(5))
					link = None
					title = re.compile(r'(?:<article aria-label|loading="lazy" title)="([^"]+?)"', re.S).findall(entry)[0]
					title = cleaning(title)
					STREAM = re.compile('<a href="([^"]+?)" target=', re.S).findall(entry)
					if STREAM and len(STREAM) > 1:
						perfect = [s for s in STREAM if not 'thema' in s]
						if perfect: link = perfect[0]
					elif STREAM and len(STREAM) == 1:
						link = STREAM[0]
					if link is None or (link and link in Isolated):
						continue
					Isolated.add(link)
					# <img data-image-el="img" class="block lazyload h-full mx-auto" src= || <img data-video-el="poster" class="block lazyload h-full mx-auto" src=
					img = re.compile('<img data-(?:image|video)-el=".*?src="(https://cdn.prod.www.spiegel.de/images[^"]+?)"', re.S).findall(entry)
					photo = img[-1].replace('_w300_r1.778_', '_w1200_r1.77_').replace('_w488_r1.778_', '_w1200_r1.77_') if img else ""
					photo = photo.split('_fd')[0]+'.jpg' if '_fd' in photo else photo
					# <span class="block text-primary-base focus:text-primary-darker hover:text-primary-dark font-sansUI font-bold text-base">
					# <span class="focus:text-primary-darker font-sansUI font-bold hover:text-primary-dark text-base mb-4 text-primary-base">
					caption = re.compile(r'(?:text-primary-(?:base|dark|darker) font-sansUI font-bold.*?text-base(?: mb-4 text-primary-base)?)">([^<]+?)</', re.S).findall(entry)
					if caption: tagline = cleaning(caption[0]) # Lauterbach und das Scholz-Team
					# <footer class="font-sansUI text-shade-dark text-s"> || <span class="font-sansUI font-normal text-s text-shade-dark"> || <span class="font-sansUI font-normal text-s text-shade-dark dark:text-shade-light">
					# <span class="font-sansUI font-normal lg:text-base md:text-s sm:text-s text-shade-dark"> || <span class="font-sansUI text-s text-shade-dark font-normal mt-2">
					DESC_1 = re.compile(r'(?:class="font-sansUI text-shade-dark text-s|class="font-sansUI font-normal.*?text-s text-shade-dark(?: dark:text-shade-light)?|class="font-sansUI text-s text-shade-dark font-normal mt-2)">(.+?)</', re.S).findall(entry) # Ein Video von Janita Hämäläinen
					DESC_2 = re.compile(r'<span data-auxiliary>(.+?Uhr)</', re.S).findall(entry) # 8. Dezember 2021, 12.50 Uhr
					if DESC_1 and not 'spitzengespraech' in url and not 'spitzentitel' in url:
						NOTE_1 = translation(30624).format(cleaning(re.sub(r'\<.*?\>', '', DESC_1[0])))
					if DESC_2:
						NOTE_2 = translation(30625).format(cleaning(DESC_2[0]))
					if DESC_1 or DESC_2: NOTE_3 = '[CR]'
					# <span class="font-serifUI font-normal text-base leading-loose mr-6"> || <span class="font-serifUI font-normal lg:text-l md:text-base sm:text-base leading-loose mr-6">
					# <span class="font-serifUI text-base leading-loose"> || <span class="block font-serifUI text-base leading-loose sm:mr-16 mb-12"> 
					DESC_3 = re.compile(r'(?:class="font-serifUI font-normal.*?text-base leading-loose mr-6|class="(?:block )?font-serifUI text-base leading-loose(?: sm:mr-16 mb-12)?)">(.+?)</', re.S).findall(entry) # Beschreibung long
					if DESC_3: description = cleaning(re.sub(r'\<.*?\>', '', DESC_3[0]))
					plot = NOTE_1+NOTE_2+NOTE_3+description
					# </svg>\n</span>\n<span class="text-white dark:text-shade-lightest font-sansUI text-s font-bold">27:09</span>\n</span> || </svg>\n</span>\n<span>7 Min</span>\n</span>
					duration = get_Seconds(re.compile('</svg>\s*</span>\s*<spa.+?>([^<]+?)</span>\s*</span>', re.S).findall(entry)[0].strip())
					VIDEO = re.search(r'<span data-icon-auxiliary="Video">', entry)
					debug_MS("(navigator.listThemes[2]) ### TITLE = {0} || LINK = {1} || DURATION = {2} ###".format(title, str(link), str(duration)))
					debug_MS("(navigator.listThemes[2]) ### FOTO = {0} || TAGLINE = {1} ###".format(photo, tagline))
					if VIDEO:
						addLink(title, photo, {'mode': 'playVideo', 'url': link}, plot, duration, tagline)
				position += 1
				debug_MS("(navigator.listThemes) ### END OF ENTRIES - pagePOSITION : {0} ###".format(str(position)))
		except: total = 0
		pageNUMBER += 1
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listYTcategories():
	debug_MS("(navigator.listYTcategories) -------------------------------------------------- START = listYTcategories --------------------------------------------------")
	addDir(translation(30631), icon, {'url': BASE_YT.format('UU1w6pNGiiLdZgyNpXUnA4Zw'), 'extras': 'YT_FOLDER'})
	addDir(translation(30632), icon, {'url': BASE_YT.format('PL54B134AD9A7A86C8'), 'extras': 'YT_FOLDER'})
	addDir(translation(30633), icon, {'url': BASE_YT.format('PLuiYhcgFTmqD24gcCDlpmGK75hIgjJXfl'), 'extras': 'YT_FOLDER'})
	addDir(translation(30634), icon, {'url': BASE_YT.format('PL8B9FDFC553E79FC6'), 'extras': 'YT_FOLDER'})
	addDir(translation(30635), icon, {'url': BASE_YT.format('PLuiYhcgFTmqDTfN9kw9H3u_lqBymi_kop'), 'extras': 'YT_FOLDER'})
	addDir(translation(30636), icon, {'url': BASE_YT.format('PLuiYhcgFTmqBmHD5Rnvu2IWdW3ZNlyF6N'), 'extras': 'YT_FOLDER'})
	addDir(translation(30637), icon, {'url': BASE_YT.format('PLuiYhcgFTmqCqURWOR9LfQPAIHkc9mRDv'), 'extras': 'YT_FOLDER'})
	addDir(translation(30638), icon, {'url': BASE_YT.format('PU1w6pNGiiLdZgyNpXUnA4Zw'), 'extras': 'YT_FOLDER'})
	addDir(translation(30639), icon, {'url': BASE_YT.format('PLuiYhcgFTmqCMQU0Tk7jXA8jp-Z7k1koZ'), 'extras': 'YT_FOLDER'})
	addDir(translation(30640), icon, {'url': BASE_YT.format('PLuiYhcgFTmqA72mlhLUzweIGU8Bk3oub8'), 'extras': 'YT_FOLDER'})
	addDir(translation(30641), icon, {'url': BASE_YT.format('PLuiYhcgFTmqCEzEfAa9eAoxQzEEmQW5XH'), 'extras': 'YT_FOLDER'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL = {0} ###".format(url))
	MEDIAS = [] # https://cdn.jwplayer.com/v2/media/Ks1yAFoQ?sources=hls,dash,mp4
	finalURL, streamTYPE = (False for _ in range(2))
	try:
		content = getUrl(url).replace('&#34;', '"')
		IDD = re.compile('"mediaId":"(.+?)",', re.DOTALL).findall(content)[0].strip()
	except:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *spiegel.de* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('Play 1'), translation(30526), icon, 8000)
	response = getUrl('https://vcdn01.spiegel.de/v2/media/'+str(IDD)+'?sources=hls,dash,mp4')
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.playVideo) RESPONSE : {0}".format(str(response)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(response)
	for elem in DATA['playlist'][0]['sources']:
		type = elem['type']
		vid = elem['file']
		if type.lower() == 'video/mp4':
			height = elem['height'] if 'height' in elem else '0'
			MEDIAS.append({'url': vid, 'mimeType': type.lower(), 'height': height})
			MEDIAS = sorted(MEDIAS, key=lambda h:h['height'], reverse=True)
			debug_MS("(navigator.playVideo[1]) SORTED_LIST | MP4 ### sorted_LIST : {0} ###".format(str(MEDIAS)))
		if (prefSTREAM == '0' or enableINPUTSTREAM) and type.lower() == 'application/vnd.apple.mpegurl':
				debug_MS("(navigator.playVideo[2]) ~~~~~ TRY NUMBER ONE TO GET THE FINALURL (m3u8) ~~~~~")
				finalURL = vid
				streamTYPE = 'M3U8/HLS'
				debug_MS("(navigator.playVideo[2]) TAKE M3U8/HLS ### finalURL = {0} || mimeTYPE = {1} || streamTYPE = {2} ###".format(finalURL, str(type), streamTYPE))
	if not finalURL and MEDIAS:
		for item in MEDIAS:
			if prefSTREAM == '1' and not enableINPUTSTREAM and item['height'] == prefQUALITY:
				debug_MS("(navigator.playVideo[3]) ~~~~~ TRY NUMBER TWO TO GET THE FINALURL (mp4) ~~~~~")
				finalURL = item['url']
				streamTYPE = 'MP4'
				debug_MS("(navigator.playVideo[3]) TAKE MP4 ### HEIGHT = {0} || finalURL = {1} || mimeTYPE = {2} || streamTYPE = {3} ###".format(str(item['height']), finalURL, str(item['mimeType']), streamTYPE))
	if not finalURL and MEDIAS:
		finalURL = MEDIAS[0]['url']
		streamTYPE = 'MP4'
		log("(navigator.playVideo[4]) !!!!! KEINEN passenden Stream gefunden --- nehme jetzt den Reserve-Stream-MP4 !!!!!")
		debug_MS("(navigator.playVideo[4]) TAKE RESERVE ### HEIGHT = {0} || finalURL = {1} || mimeTYPE = {2} || streamTYPE = {3} ###".format(str(MEDIAS[0]['height']), finalURL, str(MEDIAS[0]['mimeType']), streamTYPE))
	if finalURL and streamTYPE:
		log("(navigator.playVideo) {0}_stream : {1}".format(streamTYPE, finalURL))
		listitem = xbmcgui.ListItem(path=finalURL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and streamTYPE == 'M3U8/HLS':
			listitem.setMimeType('application/vnd.apple.mpegurl')
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else: 
		failing("(navigator.playVideo) ##### Die angeforderte Video-Url wurde leider NICHT gefunden !!! #####")
		return dialog.notification(translation(30521).format('PLAY 2'), translation(30526), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, folder=True):
	if params.get('extras') == 'YT_FOLDER': u = params.get('url')
	else: u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None, tagline=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Tvshowtitle'] = None
	info['Title'] = name
	info['Tagline'] = tagline
	info['Plot'] = plot
	info['Duration'] = duration
	info['Year'] = None
	info['Genre'] = 'News'
	info['Studio'] = 'Der Spiegel'
	info['Mediatype'] = 'tvshow'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
