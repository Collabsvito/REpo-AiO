﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
else:
	from urllib.parse import urlencode  # Python 3.X

from .common import *


def mainMenu():
	addDir(translation(30601), icon, {'mode': 'trailer'})
	addDir(translation(30602), icon, {'mode': 'kino'})
	addDir(translation(30603), icon, {'mode': 'series'})
	addDir(translation(30604), icon, {'mode': 'news'})
	if enableADJUSTMENT:
		addDir(translation(30608), artpic+'settings.png', {'mode': 'aSettings'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def trailer():
	addDir(translation(30620), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/beliebteste.html'})
	addDir(translation(30621), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/imkino/'})
	addDir(translation(30622), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/bald/'})
	addDir(translation(30623), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/neu/'})
	addDir(translation(30624), icon, {'mode': 'filtertrailer', 'url': BASE_URL+'/trailer/archiv/'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def kino():
	addDir(translation(30630), icon, {'mode': 'listKino_small', 'url': BASE_URL+'/filme-imkino/vorpremiere/'})
	addDir(translation(30631), icon, {'mode': 'listKino_big', 'url': BASE_URL+'/filme-imkino/kinostart/'})
	addDir(translation(30632), icon, {'mode': 'listKino_big', 'url': BASE_URL+'/filme-imkino/neu/'})
	addDir(translation(30633), icon, {'mode': 'listKino_big', 'url': BASE_URL+'/filme-imkino/besten-filme/user-wertung/'})
	addDir(translation(30634), icon, {'mode': 'selectionWeek', 'url': BASE_URL+'/filme-vorschau/de/'})
	addDir(translation(30635), icon, {'mode': 'filterkino', 'url': BASE_URL+'/filme/besten/user-wertung/'})
	addDir(translation(30636), icon, {'mode': 'filterkino', 'url': BASE_URL+'/filme/schlechtesten/user-wertung/'})
	addDir(translation(30637), icon, {'mode': 'filterkino', 'url': BASE_URL+'/filme/kinderfilme/'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def series():
	addDir(translation(30650), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/top/'})
	addDir(translation(30651), icon, {'mode': 'filterserien', 'url': BASE_URL+'/serien/beste/'})
	addDir(translation(30652), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/top/populaerste/'})
	addDir(translation(30653), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/kommende-staffeln/meisterwartete/'})
	addDir(translation(30654), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/kommende-staffeln/'})
	addDir(translation(30655), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/kommende-staffeln/demnaechst/'})
	addDir(translation(30656), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/neue/'})
	addDir(translation(30657), icon, {'mode': 'listSpecial_Series_Trailer', 'url': BASE_URL+'/trailer/serien/neueste/'})
	addDir(translation(30658), icon, {'mode': 'filterserien', 'url': BASE_URL+'/serien-archiv/'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def news():
	addDir(translation(30670), icon, {'mode': 'listNews', 'url': BASE_URL+'/videos/shows/funf-sterne/'})
	addDir(translation(30671), icon, {'mode': 'listNews', 'url': BASE_URL+'/videos/shows/filmstarts-fehlerteufel/'})
	addDir(translation(30672), icon, {'mode': 'listNews', 'url': BASE_URL+'/trailer/interviews/'})
	addDir(translation(30673), icon, {'mode': 'listNews', 'url': BASE_URL+'/videos/shows/meine-lieblings-filmszene/'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def filtertrailer(url):
	debug_MS("(navigator.filtertrailer) -------------------------------------------------- START = filtertrailer --------------------------------------------------")
	debug_MS("(navigator.filtertrailer) ##### URL = {0} #####".format(url))
	if not "genre-" in url:
		addDir(translation(30801), icon, {'mode': 'selectionCategories', 'url': url, 'type': 'filtertrailer', 'extras': 'Nach Genre'})
	if not "sprache-" in url:
		addDir(translation(30802), icon, {'mode': 'selectionCategories', 'url': url, 'type': 'filtertrailer', 'extras': 'Nach Sprache'})
	if not "format-" in url:
		addDir(translation(30803), icon, {'mode': 'selectionCategories', 'url': url, 'type': 'filtertrailer', 'extras': 'Nach Typ'})
	addDir(translation(30810), icon, {'mode': 'listSpecial_Series_Trailer', 'url': url})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def filterkino(url):
	debug_MS("(navigator.filterkino) -------------------------------------------------- START = filterkino --------------------------------------------------")
	debug_MS("(navigator.filterkino) ##### URL = {0} #####".format(url))
	if not "genre-" in url:
		addDir(translation(30801), icon, {'mode': 'selectionCategories', 'url': url, 'type': 'filterkino', 'extras': 'Alle Genres'})
	if not "jahrzehnt" in url:
		addDir(translation(30804), icon, {'mode': 'selectionCategories', 'url': url, 'type': 'filterkino', 'extras': 'Alle Jahre'})
	if not "produktionsland-" in url:
		addDir(translation(30805), icon, {'mode': 'selectionCategories', 'url': url, 'type': 'filterkino', 'extras': 'Alle Länder'})
	addDir(translation(30810), icon, {'mode': 'listKino_small', 'url': url})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def filterserien(url):
	debug_MS("(navigator.filterserien) -------------------------------------------------- START = filterserien --------------------------------------------------")
	debug_MS("(navigator.filterserien) ##### URL = {0} #####".format(url))
	LINKING = ['serien-archiv', 'serien/beste']
	if not "genre-" in url:
		CATEGORY = 'Nach Genre' if any(x in url for x in LINKING) else 'Alle Genres'
		addDir(translation(30801), icon, {'mode': 'selectionCategories', 'url': url, 'type': 'filterserien', 'extras': CATEGORY})
	if not "jahrzehnt" in url:
		CATEGORY = 'Nach Produktionsjahr' if any(x in url for x in LINKING) else 'Alle Jahre'
		addDir(translation(30804), icon, {'mode': 'selectionCategories', 'url': url, 'type': 'filterserien', 'extras': CATEGORY})
	if not "produktionsland-" in url:
		CATEGORY = 'Nach Land' if any(x in url for x in LINKING) else 'Alle Länder'
		addDir(translation(30805), icon, {'mode': 'selectionCategories', 'url': url, 'type': 'filterserien', 'extras': CATEGORY})
	if any(x in url for x in LINKING):
		addDir(translation(30810), icon, {'mode': 'listSeries_big', 'url': url})
	else:
		addDir(translation(30810), icon, {'mode': 'listSeries_small', 'url': url})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selectionCategories(url, type, CATEGORY):
	debug_MS("(navigator.selectionCategories) -------------------------------------------------- START = selectionCategories --------------------------------------------------")
	debug_MS("(navigator.selectionCategories) ##### URL = {0} ##### TYPE = {1} ##### CATEGORY = {2} #####".format(url, type, CATEGORY))
	LINKING = ['archiv/', 'serien/beste']
	content = getUrl(url)
	if any(d in url for d in LINKING):
		result = content[content.find('data-name="'+CATEGORY+'"')+1:]
		result = result[:result.find('</ul>')]
		part = result.split('class="filter-entity-item"')
	else:
		result = content[content.find(CATEGORY+'</span>')+1:]
		result = result[:result.find('</li></ul>')]
		part = result.split('</li><li')
	for i in range(1,len(part),1):  
		element=part[i]
		element = element.replace('<strong>', '').replace('</strong>', '')
		try:
			try: number = re.compile(r'<span class=["\'](?:light|lighten)["\']>\(([^<]+?)\)</span>', re.DOTALL).findall(element)[0].strip() 
			except: number = ""
			if 'href=' in element:
				matchUN = re.compile(r'href=["\']([^"]+)["\'](?: title=.+?["\']>|>)([^<]+?)</a>', re.DOTALL).findall(element)
				link = matchUN[0][0]
				name = matchUN[0][1].strip()
			else:
				try:
					matchUN = re.compile(r'<span class=["\']ACr([^"]+) item-content["\'] title=.+?["\']>([^<]+?)</span>', re.DOTALL).findall(element)
					link = convert64(matchUN[0][0])
					name = matchUN[0][1].strip()
				except:
					matchUN = re.compile(r'<span class=["\']acLnk ([^"]+)["\']>([^<]+?)</span>', re.DOTALL).findall(element)  
					link = decodeURL(matchUN[0][0])
					name = matchUN[0][1].strip()
			if number != "": name += "   ("+str(number)+")"
			addDir(name, icon, {'mode': type, 'url': BASE_URL+link})
			debug_MS("(navigator.selectionCategories) Name : {0}".format(name))
			debug_MS("(navigator.selectionCategories) Link : {0}".format(BASE_URL+link))
		except:
			failing("..... EXCEPTION .....")
			failing("(navigator.selectionCategories) Fehler-Eintrag : {0} #####".format(str(element)))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selectionWeek(url):
	debug_MS("(navigator.selectionWeek) -------------------------------------------------- START = selectionWeek --------------------------------------------------")
	debug_MS("(navigator.selectionWeek) ##### URL = {0} #####".format(url))
	content = getUrl(url)
	result = content[content.find('<div class="pagination pagination-select">')+1:]
	result = result[:result.find('<span class="txt">Nächste</span><i class="icon icon-right icon-arrow-right-a">')]
	matchUN = re.compile(r'<option value=["\']ACr([^"]+)["\']([^<]+)</option>', re.DOTALL).findall(result)
	for link, title in matchUN:
		link = convert64(link)
		xDate = str(link.replace('filme-vorschau/de/week-', '').replace('/', ''))
		title = title.replace('>', '')
		if "selected" in title:
			title = title.replace('selected', '')
			name = translation(30831).format(cleaning(title))
		else: name = cleaning(title)
		debug_MS("(navigator.selectionWeek) Name : {0}".format(name))
		debug_MS("(navigator.selectionWeek) Datum : {0}".format(xDate))
		addDir(name, icon, {'mode': 'listKino_big', 'url': BASE_URL+link, 'extras': xDate})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTrailer(url, PAGE):
	debug_MS("(navigator.listTrailer) -------------------------------------------------- START = listTrailer --------------------------------------------------")
	NEPVurl = url
	PGurl = url+"?page="+str(PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listTrailer) ##### URL = {0} ##### PAGE = {1} #####".format(PGurl, str(PAGE)))
	content = getUrl(PGurl)
	selection = re.findall('<div class="card video-card-trailer(.+?)<span class="thumbnail-count">', content, re.S)
	for chtml in selection:
		try:
			image = re.compile(r'src=["\'](https?://.+?(?:[0-9]+\.png|[a-z]+\.png|[0-9]+\.jpg|[a-z]+\.jpg|[0-9]+\.gif|[a-z]+\.gif))["\'\?]', re.DOTALL|re.IGNORECASE).findall(chtml)[0]
			photo = enlargeIMG(image)
			matchUN = re.compile('<a href=["\']([^"]+)["\'] class=["\']layer-link["\']>([^<]+)</a>', re.DOTALL).findall(chtml)
			link = matchUN[0][0]
			name = cleaning(matchUN[0][1])
			debug_MS("(navigator.listTrailer) Name : {0}".format(name))
			debug_MS("(navigator.listTrailer) Link : {0}".format(BASE_URL+link))
			debug_MS("(navigator.listTrailer) Icon : {0}".format(photo))
			addLink(name, photo, {'mode': 'playVideo', 'url': BASE_URL+link, 'extras': url})
		except:
			failing("..... EXCEPTION .....")
			failing("(navigator.listTrailer) Fehler-Eintrag : {0} #####".format(str(chtml)))
	try:
		nextPG = re.compile(r'class=["\']((?:ACr[^<]+</span></div></nav>    </section>|button button-md item["\'] href=[^<]+</a></div></nav>    </section>))', re.DOTALL).findall(content)[0]
		debug_MS("(navigator.listTrailer) Now show NextPage ...")
		addDir(translation(30832), artpic+'nextpage.png', {'mode': 'listTrailer', 'url': NEPVurl, 'page': int(PAGE)+1})
	except: pass
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSpecial_Series_Trailer(url, PAGE, POS):
	debug_MS("(navigator.listSpecial_Series_Trailer) -------------------------------------------------- START = listSpecial_Series_Trailer --------------------------------------------------")
	NEPVurl = url
	PGurl = url+"?page="+str(PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listSpecial_Series_Trailer) ##### URL = {0} ##### PAGE = {1} #####".format(PGurl, str(PAGE)))
	content = getUrl(PGurl)
	if int(POS) == 0:
		try:
			POS = re.compile('<a class=["\']button button-md item["\'] href=.+?page=[0-9]+["\']>([0-9]+)</a></div></nav>', re.DOTALL).findall(content)[0]
			debug_MS("(navigator.listSpecial_Series_Trailer) *FOUND-1* Pages-Maximum : {0}".format(str(POS)))
		except:
			try:
				POS = re.compile('<span class=["\']ACr.+?button-md item["\']>([0-9]+)</span></div></nav>', re.DOTALL).findall(content)[0]
				debug_MS("(navigator.listSpecial_Series_Trailer) *FOUND-2* Pages-Maximum : {0}".format(str(POS)))
			except: pass
	result = content[content.find('<main id="content-layout" class="content-layout cf">')+1:]
	result = result[:result.find('<div class="rc-content">')]
	part = result.split('<figure class="thumbnail ">')
	for i in range(1,len(part),1):
		element = part[i]
		element = element.replace('<strong>', '').replace('</strong>', '')
		try:
			try:
				image = re.compile(r'src=["\'](https?://.+?(?:[0-9]+\.png|[a-z]+\.png|[0-9]+\.jpg|[a-z]+\.jpg|[0-9]+\.gif|[a-z]+\.gif))["\'\?]', re.DOTALL|re.IGNORECASE).findall(element)[0]
			except:
				image = re.compile(r'["\']src["\']:["\'](https?://.+?(?:[0-9]+\.png|[a-z]+\.png|[0-9]+\.jpg|[a-z]+\.jpg|[0-9]+\.gif|[a-z]+\.gif))["\'\?]', re.DOTALL|re.IGNORECASE).findall(element)[0]
			photo = enlargeIMG(image)
			try:
				RuTi = re.compile('class=["\']thumbnail-count["\']>(.+?)</span>', re.DOTALL).findall(element)[0].strip()
				if ":" in RuTi:
					running = re.compile('([0-9]+):([0-9]+)', re.DOTALL).findall(RuTi)
					duration = int(running[0][0])*60+int(running[0][1])
				elif not ":" in RuTi:
					duration = int(RuTi)
			except: duration = '0'
			matchUN = re.compile(r'class=["\']meta-title-link["\'] href=["\']([^"]+?)["\']([^<]+)</a>', re.DOTALL).findall(element)
			link = matchUN[0][0]
			name = matchUN[0][1].replace(' >', '').replace('>', '')
			name = cleaning(name)
			debug_MS("(navigator.listSpecial_Series_Trailer) Name : {0}".format(name))
			debug_MS("(navigator.listSpecial_Series_Trailer) Link : {0}".format(BASE_URL+link))
			debug_MS("(navigator.listSpecial_Series_Trailer) Icon : {0}".format(photo))
			if link !="" and not "En savoir plus" in name:
				addLink(name, photo, {'mode': 'playVideo', 'url': BASE_URL+link, 'extras': url}, duration=duration)
		except:
			failing("..... EXCEPTION .....")
			failing("(navigator.listSpecial_Series_Trailer) Fehler-Eintrag : {0} #####".format(str(element)))
	if int(POS) > int(PAGE):
		debug_MS("(navigator.listSpecial_Series_Trailer) Now show NextPage ...")
		addDir(translation(30832), artpic+'nextpage.png', {'mode': 'listSpecial_Series_Trailer', 'url': NEPVurl, 'page': int(PAGE)+1, 'position': int(POS)})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listKino_big(url, PAGE, POS):
	debug_MS("(navigator.listKino_big) -------------------------------------------------- START = listKino_big --------------------------------------------------")
	FOUND = False
	NEPVurl = url
	PGurl = url+"?page="+str(PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listKino_big) ##### URL = {0} ##### PAGE = {1} #####".format(PGurl, str(PAGE)))
	content = getUrl(PGurl)
	if int(POS) == 0:
		try:
			POS = re.compile('<a class=["\']button button-md item["\'] href=.+?page=[0-9]+["\']>([0-9]+)</a></div></nav>', re.DOTALL).findall(content)[0]
			debug_MS("(navigator.listKino_big) *FOUND-1* Pages-Maximum : {0}".format(str(POS)))
		except:
			try:
				POS = re.compile('<span class=["\']ACr.+?button-md item["\']>([0-9]+)</span></div></nav>', re.DOTALL).findall(content)[0]
				debug_MS("(navigator.listKino_big) *FOUND-2* Pages-Maximum : {0}".format(str(POS)))
			except: pass
	result = content[content.find('<main id="content-layout" class="content-layout cf">')+1:]
	result = result[:result.find('<div class="rc-content">')]
	part = result.split('<figure class="thumbnail ">')
	for i in range(1,len(part),1):
		element=part[i]
		try:
			matchUN = re.compile('class=["\']ACr([^ "]+) thumbnail-container thumbnail-link["\'] title=["\'](.+?)["\']>', re.DOTALL).findall(element)
			link = convert64(matchUN[0][0])
			name = cleaning(matchUN[0][1])
			image = re.compile(r'src=["\'](https?://.+?(?:[0-9]+\.png|[a-z]+\.png|[0-9]+\.jpg|[a-z]+\.jpg|[0-9]+\.gif|[a-z]+\.gif))["\'\?]', re.DOTALL|re.IGNORECASE).findall(element)[0]
			photo = enlargeIMG(image)
			if "/serien" in PGurl:
				try: movieDATE = re.compile('<div class=["\']meta-body-item meta-body-info["\']>([^<]+?)<span class=["\']spacer["\']>/</span>', re.DOTALL).findall(element)[0]
				except: movieDATE =""
			else:
				try: movieDATE = re.compile('<span class=["\']date["\']>.*?([a-zA-Z]+ [0-9]+)</span>', re.DOTALL).findall(element)[0]
				except: movieDATE =""
			if movieDATE != "" and "/serien" in PGurl:
				name = name+"   ("+str(movieDATE.replace('\n', '').replace(' - ', '~').replace('läuft seit', 'ab').strip())+")"
			elif movieDATE != "" and "besten-filme/user-wertung" in PGurl:
				newDATE = cleanMonth(movieDATE.lower())
				name = name+"   ("+str(newDATE)+")"
			try: # Grab - Genres
				result_1 = re.compile('<span class=["\']spacer["\']>/</span>(.+?)</div>', re.DOTALL).findall(element)[-1]
				matchG = re.compile('<span class=["\']ACr.*?["\']>(.+?)</span>', re.DOTALL).findall(result_1)
				genres = []
				for gNames in matchG:
					gNames = cleaning(gNames)
					genres.append(gNames)
				gGenre =", ".join(genres)
			except: gGenre =""
			try: # Grab - Directors
				result_2 = re.compile('<div class=["\']meta-body-item meta-body-direction light["\']>(.+?)</div>', re.DOTALL).findall(element)[-1]
				matchD = re.compile('<span class=["\']ACr.*?["\']>(.+?)</span>', re.DOTALL).findall(result_2)
				directors = []
				for dNames in matchD:
					dNames = cleaning(dNames)
					directors.append(dNames)
				dDirector =", ".join(directors)
			except: dDirector =""
			try: # Grab - Plot
				desc = re.compile('<div class=["\']synopsis["\']>(.+?)</div>', re.DOTALL).findall(element)[0]
				plot = re.sub(r'\<.*?\>', '', desc)
				plot = cleaning(plot)
			except: plot=""
			try: # Grab - Rating
				result_3 = element[element.find('User-Wertung')+1:]
				rRating = re.compile('class=["\']stareval-note["\']>([^<]+?)</span></div>', re.DOTALL).findall(result_3)[0].strip().replace(',', '.')
			except:
				try:
					result_3 = element[element.find('Pressekritiken')+1:]
					rRating = re.compile('class=["\']stareval-note["\']>([^<]+?)</span></div>', re.DOTALL).findall(result_3)[0].strip().replace(',', '.')
				except: rRating =""
			matchTT = re.compile('<div class=["\']buttons-holder["\']>(.+?)</div>', re.DOTALL).findall(element)
			TRAILER = True if matchTT and ("Trailer" in matchTT[0] or "Teaser" in matchTT[0]) else False
			debug_MS("(navigator.listKino_big) Name : {0}".format(name))
			debug_MS("(navigator.listKino_big) Link : {0}".format(BASE_URL+link))
			debug_MS("(navigator.listKino_big) Icon : {0}".format(photo))
			debug_MS("(navigator.listKino_big) Regie : {0}".format(dDirector))
			debug_MS("(navigator.listKino_big) Genre : {0}".format(gGenre))
			if 'filme-vorschau/' in PGurl:
				FOUND = True
				addLink(name, photo, {'mode': 'playVideo', 'url': BASE_URL+link, 'type': 'filtervorschau', 'extras': url}, plot, gGenre, dDirector, rRating)
			else:
				if (TRAILER or '<span class="ico-play-inner"></span>' in element) and not 'button btn-disabled' in element:
					FOUND = True
					addLink(name, photo, {'mode': 'playVideo', 'url': BASE_URL+link, 'extras': url}, plot, gGenre, dDirector, rRating)
				else:
					FOUND = True
					addDir(translation(30835).format(name), photo, {'mode': 'listKino_big', 'url': NEPVurl}, plot, gGenre, dDirector, rRating)
		except:
			failing("..... EXCEPTION .....")
			failing("(navigator.listKino_big) Fehler-Eintrag : {0} #####".format(str(element)))
	if not FOUND:
		return dialog.notification(translation(30523), translation(30524), icon, 8000)
	if NEXT_BEFORE_PAGE and 'filme-vorschau/' in PGurl:
		try:
			LEFT = re.compile(r'<span class=["\']ACr([^ "]+) button button-md button-primary-full button-left["\']>.*?span class=["\']txt["\']>Vorherige</span>', re.DOTALL).findall(result)[0]
			LINK_L = convert64(LEFT)
			BeforeDAY = str(LINK_L.replace('filme-vorschau/de/week-', '').replace('/', ''))
			before = datetime(*(time.strptime(BeforeDAY, '%Y-%m-%d')[0:6]))
			bxORG = before.strftime('%Y-%m-%d')
			bxNEW = before.strftime('%d.%m.%Y')
			RIGHT = re.compile(r'<span class=["\']ACr([^ "]+) button button-md button-primary-full button-right["\']>.*?span class=["\']txt["\']>Nächste</span>', re.DOTALL).findall(result)[0]
			LINK_R = convert64(RIGHT)
			NextDAY = str(LINK_R.replace('filme-vorschau/de/week-', '').replace('/', ''))
			next = datetime(*(time.strptime(NextDAY, '%Y-%m-%d')[0:6]))
			nxORG = next.strftime('%Y-%m-%d')
			nxNEW = next.strftime('%d.%m.%Y')
			addDir(translation(30833).format(str(nxNEW)), icon, {'mode': 'listKino_big', 'url': BASE_URL+LINK_R, 'extras': nxORG})
			addDir(translation(30834).format(str(bxNEW)), icon, {'mode': 'listKino_big', 'url': BASE_URL+LINK_L, 'extras': bxORG})
		except: pass
	if int(POS) > int(PAGE) and not 'filme-vorschau/' in PGurl:
		debug_MS("(navigator.listKino_big) Now show NextPage ...")
		addDir(translation(30832), artpic+'nextpage.png', {'mode': 'listKino_big', 'url': NEPVurl, 'page': int(PAGE)+1, 'position': int(POS)})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listKino_small(url, PAGE):
	debug_MS("(navigator.listKino_small) -------------------------------------------------- START = listKino_small --------------------------------------------------")
	FOUND = False
	NEPVurl = url
	PGurl = url+"?page="+str(PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listKino_small) ##### URL = {0} ##### PAGE = {1} #####".format(PGurl, str(PAGE)))
	content = getUrl(PGurl)
	part = content.split('<div class="data_box">')
	for i in range(1,len(part),1):
		element = part[i]
		try:
			try:
				link = re.compile('button btn-primary ["\'] href=["\']([^"]+?)["\']', re.DOTALL).findall(element)[0]
			except:
				try:
					matchU = re.compile('class=["\']acLnk ([^ ]+?) button btn-primary', re.DOTALL).findall(element)[0]
					link = decodeURL(matchU)
				except: link =""
			image = re.compile(r'src=["\'](https?://.+?(?:[0-9]+\.png|[a-z]+\.png|[0-9]+\.jpg|[a-z]+\.jpg|[0-9]+\.gif|[a-z]+\.gif))["\'\?]', re.DOTALL|re.IGNORECASE).findall(element)[0]
			photo = enlargeIMG(image)
			title = re.compile('alt=["\'](.+?)["\'\" \' ]\s+title=', re.DOTALL).findall(element)[0]
			name = cleaning(title)
			try:
				movieDATE = re.compile('<span class=["\']film_info lighten fl["\']>Starttermin(.+?)</div>', re.DOTALL).findall(element)[0]
				newDATE = re.sub(r'\<.*?\>', '', movieDATE)
			except: newDATE =""
			if newDATE != "" and not "unbekannt" in newDATE.lower():
				name = name+"   ("+newDATE.replace('\n', '').replace('.', '-').strip()[0:10]+")"
			try: # Grab - Directors
				result_1 = re.compile('<span class=["\']film_info lighten fl["\']>Von </span>(.+?)</div>', re.DOTALL).findall(element)[-1]
				matchD = re.compile(r'(?:<span title=|<a title=)["\'](.+?)["\'] (?:class=|href=)', re.DOTALL).findall(result_1)
				directors = []
				for dNames in matchD:
					dNames = cleaning(dNames)
					directors.append(dNames)
				dDirector =", ".join(directors)
			except: dDirector =""
			try: # Grab - Genres
				result_2 = re.compile('<span class=["\']film_info lighten fl["\']>Genre</span>(.+?)</div>', re.DOTALL).findall(element)[-1]
				matchG = re.compile('<span itemprop=["\']genre["\']>([^<]+?)</span>', re.DOTALL).findall(result_2)
				genres = []
				for gNames in matchG:
					gNames = cleaning(gNames)
					genres.append(gNames)
				gGenre =", ".join(genres)
			except: gGenre =""
			try: # Grab - Plot
				desc = re.compile("<p[^>]*>([^<]+)<", re.DOTALL).findall(element)[0]
				plot = desc.replace('&nbsp;', '')
				plot = cleaning(plot)
			except: plot=""
			try: # Grab - Rating
				result_3 = element[element.find('User-Wertung')+1:]
				result_3 = result_3[:result_3.find('</TrueTemplate>')]
				rRating = re.compile('<span class=["\']note["\']>([^<]+?)</span></span>', re.DOTALL).findall(result_3)[0].strip().replace(',', '.')
			except:
				try:
					result_3 = element[element.find('Pressekritiken')+1:]
					result_3 = result_3[:result_3.find('User-Wertung')]
					rRating = re.compile('<span class=["\']note["\']>([^<]+?)</span></span>', re.DOTALL).findall(result_3)[0].strip().replace(',', '.')
				except: rRating=""
			debug_MS("(navigator.listKino_small) Name : {0}".format(name))
			debug_MS("(navigator.listKino_small) Link : {0}".format(BASE_URL+link))
			debug_MS("(navigator.listKino_small) Icon : {0}".format(photo))
			debug_MS("(navigator.listKino_small) Regie : {0}".format(dDirector))
			debug_MS("(navigator.listKino_small) Genre : {0}".format(gGenre))
			if link !="" and not 'button btn-disabled' in element:
				FOUND = True
				addLink(name, photo, {'mode': 'playVideo', 'url': BASE_URL+link, 'extras': url}, plot, gGenre, dDirector, rRating)
			else:
				FOUND = True
				addDir(translation(30835).format(name), photo, {'mode': 'listKino_small', 'url': NEPVurl}, plot, gGenre, dDirector, rRating)
		except:
			failing("..... EXCEPTION .....")
			failing("(navigator.listKino_small) Fehler-Eintrag : {0} #####".format(str(element)))
	if not FOUND:
		return dialog.notification(translation(30523), translation(30524), icon, 8000)
	if 'fr">Nächste<i class="icon-arrow-right">' in content:
		debug_MS("(navigator.listKino_small) Now show NextPage ...")
		addDir(translation(30832), artpic+'nextpage.png', {'mode': 'listKino_small', 'url': NEPVurl, 'page': int(PAGE)+1})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeries_small(url, PAGE):
	debug_MS("(navigator.listSeries_small) -------------------------------------------------- START = listSeries_small --------------------------------------------------")
	FOUND = False
	NEPVurl = url
	PGurl = url+"?page="+str(PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listSeries_small) ##### URL = {0} ##### PAGE = {1} #####".format(PGurl, str(PAGE)))
	content = getUrl(PGurl)
	part = content.split('<div class="data_box">')
	for i in range(1,len(part),1):
		element = part[i]
		try:
			try:
				link = re.compile('button btn-primary ["\'] href=["\']([^"]+?)["\']', re.DOTALL).findall(element)[0]
			except:
				try:
					matchU = re.compile('class=["\']acLnk ([^ ]+?) button btn-primary', re.DOTALL).findall(element)[0]
					link = decodeURL(matchU)
				except: link =""
			image = re.compile(r'src=["\'](https?://.+?(?:[0-9]+\.png|[a-z]+\.png|[0-9]+\.jpg|[a-z]+\.jpg|[0-9]+\.gif|[a-z]+\.gif))["\'\?]', re.DOTALL|re.IGNORECASE).findall(element)[0]
			photo = enlargeIMG(image)
			title =re.compile('<h2 class=["\']tt_18 d_inlin[^>]*>(.+?)</h2>', re.DOTALL).findall(element)[0]
			name = re.sub(r'\<.*?\>', '', title)
			name = cleaning(name)
			try:
				movieDATE = re.compile('<span class=["\']lighten(?:\">|\'>)\s+Produktionszeitraum(.+?)</tr>', re.DOTALL).findall(element)[0]
				newDATE = re.sub(r'\<.*?\>', '', movieDATE)
			except: newDATE =""
			if newDATE != "" and not "unbekannt" in newDATE:
				name = name+'   ('+newDATE.replace('\n', '').replace(' ', '').replace('-', '~').strip()+')'
			try: # Grab - Directors
				result_1 = re.compile('<span class=["\']lighten["\']>mit</span>(.+?)</tr>', re.DOTALL).findall(element)[-1]
				matchD = re.compile(r'(?:<span title=|<a title=)["\'](.+?)["\'] (?:class=|href=)', re.DOTALL).findall(result_1)
				directors = []
				for dNames in matchD:
					dNames = cleaning(dNames)
					directors.append(dNames)
				dDirector =", ".join(directors)
			except: dDirector =""
			try: # Grab - Genres
				result_2 = re.compile('<span class=["\']lighten["\']>Genre(.+?)</tr>', re.DOTALL).findall(element)[-1]
				matchG = re.compile('<span itemprop=["\']genre["\']>([^<]+?)</span>', re.DOTALL).findall(result_2)
				genres = []
				for gNames in matchG:
					gNames = cleaning(gNames)
					genres.append(gNames)
				gGenre =", ".join(genres)
			except: gGenre =""
			try: # Grab - Plot
				desc = re.compile("<p[^>]*>([^<]+)<", re.DOTALL).findall(element)[0]
				plot = desc.replace('&nbsp;', '')
				plot = cleaning(plot)
			except: plot=""
			try: # Grab - Rating
				rRating = re.compile('<span class=["\']note["\']><span class=["\']acLnk.*?["\']>([^<]+?)</span></span>', re.DOTALL).findall(element)[0].strip().replace(',', '.')
			except: rRating=""
			debug_MS("(navigator.listSeries_small) Name : {0}".format(name))
			debug_MS("(navigator.listSeries_small) Link : {0}".format(BASE_URL+link))
			debug_MS("(navigator.listSeries_small) Icon : {0}".format(photo))
			debug_MS("(navigator.listSeries_small) Regie : {0}".format(dDirector))
			debug_MS("(navigator.listSeries_small) Genre : {0}".format(gGenre))
			if link !="" and not 'button btn-disabled' in element:
				FOUND = True
				addLink(name, photo, {'mode': 'playVideo', 'url': BASE_URL+link, 'extras': url}, plot, gGenre, dDirector, rRating)
			else:
				FOUND = True
				addDir(translation(30835).format(name), photo, {'mode': 'listSeries_small', 'url': NEPVurl}, plot, gGenre, dDirector, rRating)
		except:
			failing("..... EXCEPTION .....")
			failing("(navigator.listSeries_small) Fehler-Eintrag : {0} #####".format(str(element)))
	if not FOUND:
		return dialog.notification(translation(30523), translation(30524), icon, 8000)
	if 'fr">Nächste<i class="icon-arrow-right">' in content:
		debug_MS("(navigator.listSeries_small) Now show NextPage ...")
		addDir(translation(30832), artpic+'nextpage.png', {'mode': 'listSeries_small', 'url': NEPVurl, 'page': int(PAGE)+1})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listNews(url, PAGE):
	debug_MS("(navigator.listNews) -------------------------------------------------- START = listNews --------------------------------------------------")
	NEPVurl = url
	PGurl = url+"?page="+str(PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listNews) ##### URL = {0} ##### PAGE = {1} #####".format(PGurl, str(PAGE)))
	content = getUrl(PGurl)
	result = content[content.find('<div class="colcontent">')+1:]
	result = result[:result.find('class="centeringtable">')]
	part = result.split('<div class="datablock')
	for i in range(1,len(part),1):
		element = part[i]
		try:
			image = re.compile(r'src=["\'](https?://.+?(?:[0-9]+\.png|[a-z]+\.png|[0-9]+\.jpg|[a-z]+\.jpg|[0-9]+\.gif|[a-z]+\.gif))["\'\?]', re.DOTALL|re.IGNORECASE).findall(element)[0]
			photo = enlargeIMG(image)
			try:
				matchUN = re.compile('href=["\'](.+?)["\'] class=.*?</strong>([^<]+?)</', re.DOTALL).findall(element)
				link = matchUN[0][0]
				title = matchUN[0][1]
			except:
				matchUN = re.compile('href=["\'](.+?)["\']>(.+?)</a>', re.DOTALL).findall(element)
				link = matchUN[0][0]
				title = matchUN[0][1].replace('\n', '')
				title = re.sub(r'\<.*?\>', '', title)
			name = cleaning(title)
			try: # Grab - Plot
				desc = re.compile('class=["\']fs11 purehtml["\']>(.+?)<div class=["\']spacer["\']></div>', re.DOTALL).findall(element)[0]
				plot = re.sub(r'\<.*?\>', '', desc)
				plot = cleaning(plot)
			except: plot = name
			debug_MS("(navigator.listNews) Name : {0}".format(name))
			debug_MS("(navigator.listNews) Link : {0}".format(BASE_URL+link))
			debug_MS("(navigator.listNews) Icon : {0}".format(photo))
			addLink(name, photo, {'mode': 'playVideo', 'url': BASE_URL+link, 'extras': url}, plot)
		except:
			failing("..... EXCEPTION .....")
			failing("(navigator.listNews) Fehler-Eintrag : {0} #####".format(str(element)))
	try:
		nextPG = re.compile('(<li class="navnextbtn">[^<]+<span class="acLnk)', re.DOTALL).findall(content)[0]
		debug_MS("(navigator.listNews) Now show NextPage ...")
		addDir(translation(30832), artpic+'nextpage.png', {'mode': 'listNews', 'url': NEPVurl, 'page': int(PAGE)+1})
	except: pass
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url, type, REF):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS("(navigator.playVideo) ##### URL = {0} ##### TYPE = {1} ##### REFERER = {2} ##### ".format(url, type, REF))
	FIRST = False
	finalURL = False
	link = ""
	if type == 'filtervorschau':
		html = getUrl(url)
		try: # <a class="trailer item"   href="/kritiken/278374/trailer/19576405.html" title="Trailer"
			link = re.compile('class=["\']trailer item["\']   href=["\']([^"]+?)["\'] title=["\']Trailer["\']>', re.DOTALL).findall(html)[0]
			FIRST = True
		except:
			try:
				selection = re.findall('<main id="content-layout" class="content-layout entity movie cf(.+?)<div class="rc-content">', html, re.S)
				for chtml in selection:
					matchU = re.compile(r'<span class=["\']ACr([^ ]+?) button button-sm button-primary-full["\']>', re.DOTALL).findall(chtml)[0]
					link = convert64(matchU)
					FIRST = True
			except: pass
	content = getUrl(BASE_URL+link, referer=url) if FIRST else getUrl(url, referer=REF)
	try:
		LINK = re.compile("<iframe[^>]+?src=['\"](.+?)['\"]", re.DOTALL).findall(content)
		debug_MS("(navigator.playVideo) *FOUND-1* Extra-Content : {0}".format(LINK))
		if "_video" in LINK[1]:
			newURL = BASE_URL+LINK[1]
			content = getUrl(newURL, referer=url)
		elif "youtube.com" in LINK[0]:
			youtubeID = LINK[0].split('/')[-1].strip()
			debug_MS("(navigator.playVideo) *FOUND-2* Extern-Video auf Youtube [ID] : {0}".format(youtubeID))
			finalURL = 'plugin://plugin.video.youtube/play/?video_id='+youtubeID
	except: pass
	if not finalURL:
		MEDIAS = []
		mp4_QUALITIES = ['high', 'medium']
		try:
			response = re.compile(r'(?:class=["\']player  js-player["\']|class=["\']player player-auto-play js-player["\']|<div id=["\']btn-export-player["\'].*?) data-model=["\'](.+?),&quot;disablePostroll&quot;:false', re.DOTALL).findall(content)[0].replace('&quot;', '"')+"}"
			debug_MS("(navigator.playVideo) ##### Extraction of Stream-Links : {0} #####".format(response))
			DATA = json.loads(response)
			for item in DATA['videos']:
				vidQualities = item['sources']
				for found in mp4_QUALITIES:
					for quality in vidQualities:
						if quality == found:
							MEDIAS.append({'url': vidQualities[quality], 'quality': quality, 'mimeType': 'video/mp4'})
				finalURL = MEDIAS[0]['url']
		except: pass
	if finalURL:
		finalURL = finalURL.replace(' ', '%20')
		if not "youtube" in finalURL and finalURL[:4] != "http":
			finalURL ="http:"+finalURL
		log("(navigator.playVideo) StreamURL : {0}".format(finalURL))
		listitem = xbmcgui.ListItem(path=finalURL)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playVideo) ##### Die angeforderte Video-Url wurde leider NICHT gefunden !!! #####\n   ##### URL : {0} #####".format(url))
		return dialog.notification(translation(30521).format('PLAY'), translation(30525), icon, 8000)

def addDir(name, image, params={}, plot=None, genre=None, director=None, rating=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': genre, 'Director': director, 'Rating': rating})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)

def addLink(name, image, params={}, plot=None, genre=None, director=None, rating=None, duration=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Season'] = None
	info['Episode'] = None
	info['Tvshowtitle'] = None
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Year'] = None
	info['Genre'] = genre
	info['Director'] = director
	info['Writer'] = None
	info['Rating'] = rating
	info['Mpaa'] = None
	info['Mediatype'] = 'movie'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
