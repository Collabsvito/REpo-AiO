﻿# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import hashlib
import time
from datetime import datetime
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else: 
	from urllib.parse import urlencode  # Python 3.X
	from urllib.request import urlopen  # Python 3+

from .common import *


def mainMenu():
	if Newest: addDir(translation(30601), icon, {'mode': 'listEpisodes', 'url': 'https://prod.kinderplayer.cdn.tvnext.tv/api/videos?offset=0&limit=80&orderBy=appearDate&orderDirection=DESC', 'extras': 'experimental'})
	if Mostviewed: addDir(translation(30602), icon, {'mode': 'listEpisodes', 'url': 'https://prod.kinderplayer.cdn.tvnext.tv/api/videos?offset=0&limit=50&orderBy=viewCount&orderDirection=DESC', 'extras': 'experimental'})
	if kikaninchen: addDir(translation(30603), icon, {'mode': 'listAlphabet', 'url': BASE_URL+'/kikaninchen/sendungen/videos-kikaninchen-100.html'})
	if sesamstrasse: addDir(translation(30604), icon, {'mode': 'listEpisodes', 'url': BASE_URL+'/sesamstrasse/sendungen/videos-sesamstrasse-100.html'})
	if since03: addDir(translation(30605), icon, {'mode': 'listAlphabet', 'url': BASE_URL+'/videos/abdrei/videos-ab-drei-buendel100.html'})
	if since06: addDir(translation(30606), icon, {'mode': 'listAlphabet', 'url': BASE_URL+'/videos/absechs/videosabsechs-buendel100.html'})
	if since10: addDir(translation(30607), icon, {'mode': 'listAlphabet', 'url': BASE_URL+'/videos/abzehn/videosabzehn-buendel102.html'})
	if sinceAll: addDir(translation(30608), icon, {'mode': 'listAlphabet', 'url': BASE_URL+'/videos/allevideos/allevideos-buendelgruppen100.html'})
	addDir(translation(30609), artpic+'livestream.png', {'mode': 'playLIVE', 'url': BASE_URL+'/resources/player/xml/kika/hls-livestream.xml'}, folder=False)
	if Adjustment: addDir(translation(30610), artpic+'settings.png', {'mode': 'aSettings', 'url': ''})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listAlphabet(url):
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(listAlphabet) ------------------------------------------------ START = listAlphabet -----------------------------------------------")
	debug_MS("(listAlphabet) ### URL : {0} ###".format(url))
	html = getUrl(url, 'GET', url)
	content = re.findall(r'class="bundleNaviWrapper"(.+?)class="modCon"', html, re.S)[0]
	match = re.findall(r'<a href="([^"]+)" class="pageItem".*?>(.+?)</a>', content, re.S)
	for endURL, title in match:
		if endURL[:4] != 'http': endURL = BASE_URL+endURL
		if title == '...': title = '#'
		debug_MS("(listAlphabet) XXX TITLE = {0} || endURL = {1} XXX".format(str(title), endURL))
		if '/kikaninchen/' in url:
			addDir(title, artpic+title.title()+'.png', {'mode': 'listEpisodes', 'url': endURL})
		else:
			addDir(title, artpic+title.title()+'.png', {'mode': 'listShows', 'url': endURL})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDAlphabet+')')

def listShows(url):
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(listShows) ------------------------------------------------ START = listShows -----------------------------------------------")
	debug_MS("(listShows) ### URL : {0} ###".format(url))
	content = getUrl(url, 'GET', url)
	part = content.split('class="teaser teaserStandard  teaserMultigroup')
	for i in range(1, len(part), 1):
		entry = part[i]
		image = re.findall(r"data-ctrl-image=.*?'urlScheme':'(.+?)'}", entry, re.S)[0].split('-resimage_v-')[0]+"-resimage_v-tlarge169_w-1280.jpg"
		if image[:4] != 'http': image = BASE_URL+image
		match = re.findall(r'<h4 class="headline">.*?href="([^"]+)" title="">(.+?)</a>', entry, re.S)
		url2 = match[0][0]
		if url2[:4] != 'http': url2 = BASE_URL+url2
		title = cleaning(match[0][1])
		if not 'kikaninchen' in title.lower():
			endURL = url2
			if '/sendungen/videos' in url2:
				try:
					shorten = url2.split('/sendungen/videos')[0]+'/index.html'
					debug_MS("(listShows) XXX shortURL = {0} XXX".format(shorten))
					result = getUrl(shorten, 'GET', url2)
					endURL = re.findall(r'<a href=".+?(/[a-z-]+/buendelgruppe[0-9]+.html)" title="">',result,re.S)[0]
					if endURL[:4] != 'http': endURL = BASE_URL+endURL
				except: pass
			debug_MS("(listShows) XXX TITLE = {0} || endURL = {1} || PHOTO = {2} XXX".format(str(title), endURL, image))
			addDir(title, image, {'mode': 'listEpisodes', 'url': endURL}, seriesname=title)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDShows+')')

def listEpisodes(url, extras):
	debug_MS("(listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS("(listEpisodes) ### URL : {0} ###".format(url))
	COMBI_PAGE = []
	COMBI_EPISODE = []
	uno_LIST = []
	Isolated = set()
	startTIMES = None
	views = None
	pos = 0
	pos2 = 0
	pos3 = 0
	pos4 = 0
	if extras == 'experimental':
		html = getUrl(url, 'GET')
		DATA = json.loads(html)
		for item in DATA['_embedded']['items']:
			debug_MS("(listEpisodes) no.01 ### ITEM : {0} ###".format(str(item)))
			name = cleaning(item['title'])
			title1 = name
			seriesname = ""
			if '_embedded' in item and 'brand' in item['_embedded'] and item['_embedded']['brand'] != "" and item['_embedded']['brand'] != None:
				name = cleaning(item['_embedded']['brand']['title']) + ' - ' + name
				seriesname = cleaning(item['_embedded']['brand']['title'])
			endURL = 'https://prod.kinderplayer.cdn.tvnext.tv/api/videos/{0}/player-assets'.format(str(item['id']))
			image = item['largeTeaserImageUrl']
			plot = '[COLOR yellow]'+seriesname+'[/COLOR][CR]'
			appeared = item.get('appearDate', None)
			views = item.get('viewCount', None)
			if appeared: # 2020-05-08T07:45:00+02:00
				startDates = datetime(*(time.strptime(item['appearDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2019-06-13T13:30:00Z
				startTIMES = startDates.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('.', '•', ':')
			if startTIMES and views: plot += "Sendetermin: [COLOR chartreuse]{0}[/COLOR] | Views: [COLOR deepskyblue]{1}[/COLOR][CR]".format(str(startTIMES), str(views))
			if startTIMES and views is None: plot += "Sendetermin: [COLOR chartreuse]{0}[/COLOR][CR]".format(str(startTIMES))
			plot += '[CR]'+cleaning(item['description'])
			duration = str(item['duration'])
			episode = item['episodeNumber']
			if episode is None: episode = '0'
			pos4 += 1
			COMBI_EPISODE.append([episode, endURL, image, title1, name, plot, duration, seriesname, pos2, pos3, pos4])
	else:
		html = getUrl(url, 'GET', url)
		if '<div class="bundleNaviItem' in html and not 'kikaninchen' in url:
			NaviItem = re.findall(r'<div class="bundleNaviItem.*?href="([^"]+)" class="pageItem" title="">(.+?)</a>', html, re.S)
			for link, name in NaviItem:
				if link in Isolated:
					continue
				Isolated.add(link)
				pos += 1
				url2 = link
				if url2[:4] != 'http': url2 = BASE_URL+url2
				debug_MS("(listEpisodes) FIRST XXX POS = {0} || URL-2 = {1} XXX".format(str(pos), url2))
				if pos == Pagination: break
				COMBI_PAGE.append([pos, url2])
		else:
			pos += 1
			url2 = url
			debug_MS("(listEpisodes) SECOND XXX POS = {0} || URL-2 = {1} XXX".format(str(pos), url2))
			COMBI_PAGE.append([pos, url2])
		for pos, url2 in COMBI_PAGE:
			debug_MS("(listEpisodes) THIRD XXX POS = {0} || URL-2 = {1} XXX".format(str(pos), url2))
			startURL = url2
			result = getUrl(url2, 'GET', url2)
			if not 'index' in startURL:
				content = re.findall(r'<!--Header Area for the Multigroup -->(.+?)<!--The bottom navigation -->', result, re.S)[0]
			else:
				content = re.findall(r'<h2 class="conHeadline">Neue Videos</h2>(.+?)<span class="linktext">Alle Videos</span>', result, re.S)[0]
			part = content.split('class="teaser teaserStandard')
			for i in range(1, len(part), 1):
				entry = part[i]
				debug_MS("(listEpisodes) no.02 ### ENTRY : {0} ###".format(str(entry)))
				image = re.findall(r"data-ctrl-image=.*?'urlScheme':'(.+?)'}", entry, re.S)[0].split('-resimage_v-')[0]+'-resimage_v-tlarge169_w-1280.jpg'
				if image[:4] != 'http': image = BASE_URL+image
				endURL = re.findall(r'<h4 class="headline">.*?href="([^"]+)" title=', entry, re.S)[0].replace('sendereihe', 'buendelgruppe')
				if endURL[:4] != 'http': endURL = BASE_URL+endURL
				try: duration = get_sec(re.compile('<span class="icon-duration">(.+?)</span>', re.S).findall(entry)[0])
				except: duration = 0
				plot = ""
				seriesname = ""
				if not 'index' in startURL:
					if '<meta property="og:title" content=' in result:
						Note_1 = re.compile('<meta property="og:title" content="(.+?)"/>', re.S).findall(result)[0]
						plot = '[COLOR yellow]'+cleaning(Note_1)+'[/COLOR]'
						if 'Filme' in Note_1:
							seriesname = 'Filme'
						else: seriesname = cleaning(Note_1)
					if '<meta property="og:description" content' in result:
						Note_2 = re.compile('<meta property="og:description" content="(.+?)"/>', re.S).findall(result)[0]
						plot += '[CR][CR]'+cleaning(Note_2)
				first = ""
				second = ""
				text = ""
				if '<h4 class="headline">' in entry: first = re.findall(r'<h4 class="headline">.*?title="">([^<]+)</a>', entry, re.S)[0]
				if '<p class="dachzeile">' in entry: second = re.findall(r'<p class="dachzeile">.*?title="">([^<]+)</a>', entry, re.S)[0]
				if '<img title=' in entry: text = re.compile(r'<img title=.*?alt="([^"]+?)"', re.S).findall(entry)[0]
				if first.strip() !="" and second.strip() !="" and text.strip() !="":
					title1 = cleaning(first)
					if not 'index' in startURL:
						plot += '[CR][CR]'+cleaning(text)
						name = cleaning(first)
						if Dating and ('Folge' in second or 'buendelgruppe' in startURL):
							name = cleaning(first)+'   [COLOR deepskyblue]('+cleaning(second).split(',')[0]+')[/COLOR]'
					else:
						name = cleaning(second)+' - '+cleaning(first)
						plot = '[COLOR yellow]'+cleaning(second)+'[/COLOR][CR][CR]'+cleaning(text)
						if 'Filme' in second:
							seriesname = 'Filme'
						seriesname = cleaning(second)
				elif first.strip() !="" and second.strip() =="":
					title1 = cleaning(first)
				elif first.strip() =="" and second.strip() !="":
					title1 = cleaning(second)
				else:
					title1 = cleaning(text)
				pos2 += 1
				episode = '0'
				if title1[:1].isdigit() or 'Folge ' in title1:
					try:
						episode = re.findall('([0-9]+)', title1, re.S)[0].strip().zfill(4)
						pos3 += 1
					except: pass
				else: pos4 += 1
				COMBI_EPISODE.append([episode, endURL, image, title1, name, plot, duration, seriesname, pos2, pos3, pos4])
	if COMBI_EPISODE:
		if pos4 <= 5:
			COMBI_EPISODE = sorted(COMBI_EPISODE, key=lambda no:no[0], reverse=True)
		for episode, endURL, image, title1, name, plot, duration, seriesname, pos2, pos3, pos4 in COMBI_EPISODE:
			HLnom = hashlib.md5(seriesname+'-'+title1).hexdigest()
			EP_entry = py2_enc(str(HLnom)+'###'+str(endURL)+'###'+str(seriesname)+'###'+str(name)+'###'+str(image)+'###'+str(duration)+'###'+str(episode)+'###')
			if EP_entry not in uno_LIST:
				uno_LIST.append(EP_entry)
			listitem = xbmcgui.ListItem(name, path=HOST_AND_PATH+'?IDENTiTY='+HLnom+'&mode=playCODE')
			ilabels = {}
			ilabels['Episode'] = episode
			ilabels['Tvshowtitle'] = seriesname
			ilabels['Title'] = name
			ilabels['Tagline'] = None
			ilabels['Plot'] = plot
			ilabels['Duration'] = duration
			ilabels['Year'] = None
			ilabels['Genre'] = 'Kinder'
			ilabels['Director'] = None
			ilabels['Writer'] = None
			ilabels['Studio'] = 'KiKA'
			ilabels['Mpaa'] = None
			ilabels['Mediatype'] = 'episode'
			listitem.setInfo(type='Video', infoLabels=ilabels)
			listitem.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
			if useThumbAsFanart and image != icon and not artpic in image:
				listitem.setArt({'fanart': image})
			listitem.addStreamInfo('Video', {'Duration':duration})
			listitem.setProperty('IsPlayable', 'true')
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+HLnom+'&mode=playCODE', listitem=listitem)
			with open(WORKFILE, 'w') as input:
				input.write('\n'.join(uno_LIST))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')

def getXmlUrlForEpisode(url):
	xmlUrl = '0'
	content = '0'
	try:
		content = getUrl(url, 'GET', url)
		xmlUrl = re.compile('dataURL:\'([^\']*)\'', re.S).findall(content)[0]
	except: pass
	if xmlUrl != '0':
		content = getUrl(xmlUrl, 'GET', xmlUrl)
	return content

def getStreamEntry(entry):
	qTitle = ""
	uStream = ""
	qTitle = py2_enc(re.findall(r'<profileName>([^<]+)</profileName>', entry, re.S)[0])
	try: qTitle = qTitle.split('|')[-1].replace('quality =', '').strip()
	except: qTitle = qTitle
	uStream = re.findall(r'<progressiveDownloadUrl>([^<]+)</progressive', entry, re.S)[0]
	return qTitle, uStream

def playCODE(IDD):
	debug_MS("(playCODE) ------------------------------------------------ START = playCODE -----------------------------------------------")
	debug_MS("(playCODE) ### IDD : {0} ###".format(str(IDD)))
	Xml_QUALITIES = ['1920x1080', '1280x720', '960x540', '720x576', '512x288', '320x180']
	All_QUALITIES = [4, 3, 2, 1, 0, 'veryhigh', 'high', 'med', 'low', '1920x1080', '1280x720', '960x540', '720x576', '512x288', '320x180']
	BestLISTING = ""
	ZDF_Url = ""
	convToNumbers = resToAutoSelect.replace('1280x720', '3').replace('960x540', '2').replace('720x576', '1').replace('512x288', '0').replace('320x180', '0')
	convToNames = resToAutoSelect.replace('1280x720', 'veryhigh').replace('960x540', 'high').replace('720x576', 'med').replace('512x288', 'low').replace('320x180', 'low')
	TV = {}
	TV['media'] = []
	finalURL = False
	with open(WORKFILE, 'r') as output:
		lines = output.readlines()
		for line in lines:
			field = line.split('###')
			if field[0]==IDD:
				endURL = field[1]
				seriesname = field[2]
				name = field[3]
				image = field[4]
				duration = field[5] 
				episode = field[6]
	if 'api/videos' in endURL:
		debug_MS("(playCODE) ### [API] apiUrl : {0} ###".format(endURL))
		content = getUrl(endURL, 'GET')
		DATA = json.loads(content)
		for item in DATA['hbbtvAssets']:
			uStream = item['url']
			delivery = item.get('delivery', None)
			if delivery:
				dType = item['delivery']
			else: dType = 'Unknown'
			try: qTitle = item['quality'].split('|')[-1].strip()
			except: qTitle = item['quality']
			TV['media'].append({'url': uStream, 'deliveryType': dType, 'quality': qTitle})
		debug_MS("(playCODE) ORIGINAL_TV['media'] ### unsorted_LIST : {0} ###".format(str(TV['media'])))
		order_dict = {qual: index for index, qual in enumerate(All_QUALITIES)}
		BestLISTING = sorted(TV['media'], key=lambda x: order_dict.get(x['quality'], float('inf')))
		debug_MS("(playCODE) SORTED_BestLISTING ### sorted_LIST : {0} ###".format(str(BestLISTING)))
		if BestLISTING != "" and resToAutoSelect != 'BESTEVER':
			for elem in BestLISTING:
				if ((resToAutoSelect == str(elem['quality'])) or (convToNumbers == str(elem['quality'])) or (convToNames == str(elem['quality']))):
					debug_MS("(playCODE) XXX [API] qTitle = {0} || bevorzugte-URL = {1} XXX".format(str(elem['quality']), elem['url']))
					ZDF_Url = elem['url']
					if ZDF_Url[:4] != "http": ZDF_Url = 'https:'+ZDF_Url
					finalURL = VideoBEST(ZDF_Url) # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
		if not finalURL and BestLISTING != "":
			ZDF_Url = BestLISTING[0]['url']
			if ZDF_Url[:4] != "http": ZDF_Url = 'https:'+ZDF_Url
			debug_MS("(playCODE) XXX [API] Highest-Quality = {0} || Highest-URL = {1} XXX".format(str(BestLISTING[0]['quality']), ZDF_Url))
			finalURL = VideoBEST(ZDF_Url) # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	else:
		xmlUrl = getXmlUrlForEpisode(endURL)
		debug_MS("(playCODE) ### [XML] xmlUrl : {0} ###".format(xmlUrl))
		if xmlUrl != '0':
			part = xmlUrl.split('<asset>')
			for i in range(1, len(part), 1):
				entry = part[i]
				qTitle, uStream = getStreamEntry(entry)
				if resToAutoSelect != 'BESTEVER' and ((resToAutoSelect == str(qTitle)) or (convToNumbers == str(qTitle)) or (convToNames == str(qTitle))):
					debug_MS("(playCODE) XXX [XML] qTitle = {0} || bevorzugte-URL = {1} XXX".format(str(qTitle), uStream))
					finalURL = VideoBEST(uStream) # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
			if not finalURL:
				for found in Xml_QUALITIES:
					for i in range(1, len(part), 1):
						entry = part[i]
						qTitle, uStream = getStreamEntry(entry)
						if found in qTitle:
							TV['media'].append({'url': uStream, 'mimeType': 'mp4', 'quality': found})
				debug_MS("(playCODE) XXX [XML] Stream-URLs : {0} XXX".format(str(TV['media'])))
				finalURL = VideoBEST(TV['media'][0]['url']) # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	if finalURL:
		log("(playCODE) StreamURL : {0}".format(finalURL))
		listitem = xbmcgui.ListItem(path=finalURL)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE,True, listitem)
	else:
		failing("(playCODE) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *kika.de* gefunden !!! ##########".format(endURL))
		return dialog.notification(translation(30521).format('STREAM'), translation(30523), icon, 8000)

def playLIVE(url):
	debug_MS("(playLIVE) ------------------------------------------------ START = playLIVE -----------------------------------------------")
	live_url = False
	TV = {}
	TV['media'] = []
	try:
		content = getUrl(url, 'GET', url)
		part = content.split('<asset>')
		for i in range(1, len(part), 1):
			entry = part[i]
			if '<geoZone>DE</geoZone>' in entry:
				live_url = re.findall(r'<adaptiveHttpStreamingRedirectorUrl>([^<]+)</adaptive', entry, re.S)[0]
	except: pass
	if live_url:
		firstRESULT = re.sub(r'(?:chunklist.m3u8|playlist.m3u8|index.m3u8|master.m3u8)', '', live_url)
		STREAMTEXT = getUrl(live_url, 'GET')
		STREAMS = STREAMTEXT.splitlines()
		for i in range(0, len(STREAMS)):
			infoSTREAM = STREAMS[i]
			if 'INF:BANDWIDTH=' in infoSTREAM:
				try: 	the_Bandwith = re.findall(r'AVERAGE-BANDWIDTH=([0-9]+),', infoSTREAM, re.S)[0]
				except: the_Bandwith = re.findall(r'INF:BANDWIDTH=([0-9]+),', infoSTREAM, re.S)[0]
				converted_BW = str(int(the_Bandwith)/1024).zfill(5)
				newSTREAM = STREAMS[i + 1]
				TV['media'].append({'url': newSTREAM, 'bandwith': converted_BW, 'type': 'hls-m3u8'})
		debug_MS("(playLIVE) DATA['media'] ### unsorted_LIST = {0} ###".format(str(TV['media'])))
		TV['media'] = sorted(TV['media'], key=lambda k: k['bandwith'], reverse=True)
		finalURL = firstRESULT+TV['media'][0]['url']
		log("(playLIVE) liveURL : {0}".format(finalURL))
		listitem = xbmcgui.ListItem(path=finalURL, label=translation(30609))
		listitem.setMimeType('application/vnd.apple.mpegurl')
		xbmc.Player().play(item=finalURL, listitem=listitem)
	else:
		failing("(liveTV) ##### Abspielen des Live-Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Live-Stream-Eintrag auf der Webseite von *kika.de* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('LIVE'), translation(30524), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def VideoBEST(best_url):
	standards = [best_url, "", ""]
	first_repls = (('808k_p11v15', '2360k_p35v15'), ('1628k_p13v15', '2360k_p35v15'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'),
							('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
	second_repls = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'))
	standards[1] = reduce(lambda a, kv: a.replace(*kv), first_repls, standards[0])
	standards[2] = reduce(lambda b, kv: b.replace(*kv), second_repls, standards[1])
	for element in reversed(standards):
		if len(element) > 0:
			try:
				code = urlopen(element).getcode()
				if str(code) == "200":
					return element
			except: pass
	return best_url

def addDir(name, image, params={}, plot=None, seriesname="", folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Tvshowtitle': seriesname, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
