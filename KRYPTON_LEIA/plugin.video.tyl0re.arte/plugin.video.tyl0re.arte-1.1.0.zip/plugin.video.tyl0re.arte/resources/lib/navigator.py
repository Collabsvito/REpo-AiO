﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
from collections import OrderedDict, defaultdict
from functools import partial
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote  # Python 2.X
else:
	from urllib.parse import urlencode, quote  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	config = traversing.get_config()
	for pick in config['picks']:
		title = pick['title_de'] if COUNTRY == 'de' else pick['title_fr']
		action = pick['action']
		INLAY = API_URL if pick.get('action') != 'listThemes' else COUNTRY
		url = pick.get('url').format(INLAY) if pick.get('url') is not None else '00'
		img = pick.get('img').format(artpic) if pick.get('img') is not None else icon
		if action not in ['aConfigs', 'iConfigs']:
			addDir(title, img, {'mode': action, 'url': url})
		if enableADJUSTMENT and action == 'aConfigs':
			addDir(title, img, {'mode': 'aConfigs'}, folder=False)
			if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and action == 'iConfigs':
				addDir(title, img, {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listThemes(url):
	debug_MS("(navigator.listThemes) ------------------------------------------------ START = listThemes -----------------------------------------------")
	result = getUrl(url, AUTH=OPA_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listThemes) RESULT : {0}".format(str(result)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(result, object_pairs_hook=OrderedDict)
	for themeITEM in DATA['categories']:
		Cat = str(themeITEM['code'])
		title = cleaning(themeITEM['label'])
		tagline = (cleaning(themeITEM.get('description', '') or ""))
		if title.lower() != 'andere':
			sublist = json.dumps(themeITEM['subcategories'])
			debug_MS("(navigator.listThemes) ### NAME = {0} || CATEGORY = {1} ###".format(title, Cat))
			addDir(title, thepic+Cat+'.png', {'mode': 'listSubThemes', 'url': sublist, 'extras': Cat}, tagline)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

# https://www.arte.tv/guide/api/emac/v3/de/web/pages/ARTE_CONCERT_CLASSIC/
# https://www.arte.tv/guide/api/emac/v3/de/web/pages/ARTE_CONCERT/?category=ARS&subcategories
def listSubThemes(Xurl, nomCat):
	debug_MS("(navigator.listSubThemes) ------------------------------------------------ START = listSubThemes -----------------------------------------------")
	config = traversing.get_config()
	subcategories = json.loads(Xurl, object_pairs_hook=OrderedDict)
	if nomCat == "ARS":
		special_title = translation(30641) if COUNTRY == 'de' else translation(30642)
		addDir(special_title, icon, {'mode': 'listEpisodes', 'url': config['subthemes_one'].format(API_URL, nomCat)})
	for subITEM in subcategories:
		subCat = str(subITEM['code'])
		title = cleaning(subITEM['label'])
		tagline = (cleaning(subITEM.get('description', '') or ""))
		debug_MS("(navigator.listSubThemes) ### CAT = {0} || subCAT = {1} || NAME = {2} ###".format(nomCat, subCat, title))
		# https://api-cdn.arte.tv/api/emac/v3/de/web/data/VIDEO_LISTING/?category=ARS&imageFormats=landscape&subcategories=MUA&videoType=MOST_RECENT&page=2&limit=20
		if subCat in ['CHU', 'SES']:
			addDir(title, thepic+nomCat+'.png', {'mode': 'listMagazines', 'url': config['subthemes_two'].format(API_URL, subCat)}, tagline)
		else:
			addDir(title, thepic+nomCat+'.png', {'mode': 'listEpisodes', 'url': config['subthemes_three'].format(API_URL, nomCat, subCat), 'name': title}, tagline)
	xbmcplugin.endOfDirectory(ADDON_HANDLE) 

def listMagazines(url):
	debug_MS("(navigator.listMagazines) ------------------------------------------------ START = listMagazines -----------------------------------------------")
	config = traversing.get_config()
	Isolated = set()
	special_title = translation(30643) if COUNTRY == 'de' else translation(30644)
	if 'CHU/' in url:
		prefer = ['kurz und witzig', 'courts humoristiques']
		addDir(special_title, icon, {'mode': 'listEpisodes', 'url': config['magazines'].format(API_URL, 'CHU')})
	elif 'SES/' in url:
		prefer = ['serien', 'les séries']
		addDir(special_title, icon, {'mode': 'listEpisodes', 'url': config['magazines'].format(API_URL, 'SES')})
	else:
		prefer = ['derzeit im trend', 'les incontournables', 'gesellschaft', 'société', 'highlights', 'en ce moment', 'playlists']
	result = 	getUrl(url.replace('SES/', 'HOME/').replace('CHU/', 'SER/'), AUTH=EMAC_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listMagazines) RESULT : {0}".format(str(result)))
	debug_MS("++++++++++++++++++++++++")
	CON = json.loads(result, object_pairs_hook=OrderedDict)
	DATA = CON['zones'] if 'CHU/' in url or 'HOME/' in url or 'SES/' in url else CON['data']
	for magITEM in DATA:
		if any(x in py2_enc(magITEM['title'].lower()) for x in prefer):
			for teaser in magITEM['data']:
				if not 'CHU/' in url and not 'SES/' in url and 'kind' in teaser and 'isCollection' in teaser['kind'] and teaser['kind']['isCollection'] == False and str(teaser.get('duration')) not in ['', 'None', '0']:
					if teaser['url'] in Isolated:
						continue
					Isolated.add(teaser['url'])
					if str(teaser.get('duration')) not in ['', 'None', '0']:
						debug_MS("(listMagazines[1]) ### CATEGORY = {0} ###".format(cleaning(magITEM['title'].lower())))
						LINKING(teaser, '(listMagazines)')
				elif 'kind' in teaser and 'isCollection' in teaser['kind'] and teaser['kind']['isCollection'] == True:
					if ('CHU/' in url or 'SES' in url) and ('kind' in teaser and 'code' in teaser['kind'] and teaser['kind']['code'] == 'TV_SERIES'):
						PID = str(teaser['programId'])
						title = cleaning(teaser['title'])
						plot = get_Description(teaser)
						image, fotoBIG = get_Picture(teaser)
						backdrop = 'true' if fotoBIG is True else 'false'
						debug_MS("(navigator.listMagazines[2]) ready ### NAME = {0} || PID = {1} ###".format(title, PID))
						addDir(title, image, {'mode': 'listCollections', 'url': PID, 'name': title, 'extras': image, 'backdrop': backdrop}, plot=plot, background=fotoBIG)
		elif not 'CHU/' in url and not 'HOME/' in url and not 'SES/' in url:
			PID = str(magITEM['programId'])
			title = cleaning(magITEM['title'])
			plot = get_Description(magITEM)
			image, fotoBIG = get_Picture(magITEM)
			backdrop = 'true' if fotoBIG is True else 'false'
			debug_MS("(navigator.listMagazines[3]) ready ### NAME = {0} || PID = {1} ###".format(title, PID))
			addDir(title, image, {'mode': 'listCollections', 'url': PID, 'name': title, 'extras': image, 'backdrop': backdrop}, plot=plot, background=fotoBIG)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

# COLLECTION_PROGRAM, COLLECTION_UPCOMING, COLLECTION_ARTICLE
# https://www.arte.tv/guide/api/emac/v3/de/web/data/MANUAL_TEASERS/?code=collections_SER&zone=07b776c7-8cc5-41e7-a16f-e4a5b51730cb&page=1&limit=6 || RUBRIK - kurz und witzig unter Serien
# https://api-internal.arte.tv/api/emac/v3/de/web/data/MANUAL_TEASERS/?imageFormats=landscape&authorizedAreas=DE_FR%2CEUR_DE_FR%2CSAT%2CALL&code=collections_DEC&zone=94d2d049-5860-42ba-9175-c07e856ef10f&page=2&limit=6
def listCollections(url, NAME, THUMB, fotoBIG):
	config = traversing.get_config()
	COMBI = []
	prefer = ['collection_videos', 'collection_subcollection']
	result = getUrl(API_URL+url, AUTH=EMAC_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listCollections) CONTENT : {0}".format(str(result)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(result, object_pairs_hook=OrderedDict)
	FOUND = 0
	FILTER = filter(lambda item: item['data'] and item['title'] != None and any(x in item['code']['name'].lower() for x in prefer), DATA['zones'])
	for zone in FILTER:
		title = cleaning(zone['title'])
		collection = zone['code']['name'].upper()
		CID = str(zone['code']['id'])
		newURL = config['collections_one'].format(API_URL, collection, CID) # https://api-cdn.arte.tv/api/emac/v3/de/web/data/COLLECTION_SUBCOLLECTION/?collectionId=RC-014035&subCollectionId=RC-017486&page=2
		if collection == 'COLLECTION_SUBCOLLECTION':
			newURL = config['collections_two'].format(API_URL, collection, CID.split('_')[0], CID.split('_')[1])
		debug_MS("(navigator.listCollections) ### NAME = {0} || COLLECTION = {1} || CID = {2} ###".format(title, collection, CID))
		FOUND += 1
		COMBI.append([title, collection, newURL])
	if COMBI and FOUND == 1:
		listEpisodes(newURL, title, page)
		debug_MS("(navigator.listCollections) ----- Nothing FOUND - goto = listEpisodes -----")
	elif COMBI and FOUND > 1:
		for title, collection, newURL in COMBI:
			largeIMG = True if fotoBIG == 'true' else False
			addDir(title, THUMB, {'mode': 'listEpisodes', 'url': newURL, 'name': title}, background=largeIMG)
	else:
		return dialog.notification(translation(30522).format('Einträge'), translation(30525).format(NAME), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE) 

def listSelection(START):
	config = traversing.get_config()
	i = -20
	while i <= 20:
		END = (datetime.now() - timedelta(days=i)).strftime('%Y{0}%m{0}%d'.format('-'))
		week_day = (datetime.now() - timedelta(days=i)).strftime('%w{0}%d{1} %m'.format('~', '.'))
		NUM = week_day.split('~')[1].split('. ')[0]
		DAY = [obj for obj in config['days'] if obj.get('route') == week_day.split('~')[0]]
		DD = DAY[0]['title_de'] if COUNTRY == 'de' else DAY[0]['title_fr']
		MONTH = [obj for obj in config['months'] if obj.get('route') == week_day.split('. ')[1]]
		MM = MONTH[0]['title_de'] if COUNTRY == 'de' else MONTH[0]['title_fr']
		if i == 0: addDir("[COLOR lime]"+NUM+MM+DD+"[/COLOR]", icon, {'mode': 'videosByDate', 'url': START+END})
		else: addDir(NUM+MM+DD, icon, {'mode': 'videosByDate', 'url': START+END})
		i += 1
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def videosByDate(url):
	debug_MS("(navigator.videosByDate) ------------------------------------------------ START = videosByDate -----------------------------------------------")
	debug_MS("(navigator.videosByDate) URL : {0}".format(url)) # URL-Tag = https://api-cdn.arte.tv/api/emac/v3/de/web/pages/TV_GUIDE/?day=2019-12-08
	result = getUrl(url, AUTH=EMAC_token)
	DATA = json.loads(result, object_pairs_hook=OrderedDict)
	for movie in DATA['zones'][-1]['data']:
		if "FULL_VIDEO" in str(movie.get('stickers')) and str(movie.get('duration')) not in ['', 'None', '0']:
			LINKING(movie, '(videosByDate)')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listRunTime(url):
	debug_MS("(navigator.listRunTime) ------------------------------------------------ START = listRunTime -----------------------------------------------")
	config = traversing.get_config()
	for item in config['times']:
		title = item['title_de'] if COUNTRY == 'de' else item['title_fr']
		newURL = item.get('suffix').format(url)
		addDir(title, icon, {'mode': 'listEpisodes', 'url': newURL})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, NAME, PAGE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### URL : {0} || PAGE : {1} ###".format(url, PAGE))
	FOUND = 0
	url = '{0}&page={1}&limit=50'.format(url.replace(' ', '%20'), str(PAGE)) if int(PAGE) == 1 else url
	# DURATION = https://api-cdn.arte.tv/api/emac/v3/de/web/data/VIDEO_LISTING/?videoType=LONGER_DURATION&page=2&limit=20 || SEARCH = https://api-cdn.arte.tv/api/emac/v3/de/web/data/SEARCH_LISTING/?query=europe&page=2&limit=20
	# STANDARD =  https://api-cdn.arte.tv/api/emac/v3/de/web/data/VIDEO_LISTING/?videoType=MOST_VIEWED&page=1&limit=20
	result = getUrl(url, AUTH=EMAC_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listEpisodes) RESULT : {0}".format(str(result)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(result, object_pairs_hook=OrderedDict)
	for movie in DATA['data']:
		if str(movie.get('duration')) not in ['', 'None', '0']:
			FOUND += 1
			LINKING(movie, '(listEpisodes)')
	# NEXTPAGE = https://api-cdn.arte.tv/api/emac/v3/de/web/data/COLLECTION_SUBCOLLECTION/?collectionId=RC-014035&subCollectionId=RC-015171&page=2&limit=20
	if str(DATA.get('nextPage'))[:4] == "http":
		debug_MS("(navigator.listEpisodes) This is NextPage : {0}".format(DATA.get('nextPage')))
		debug_MS("(navigator.listEpisodes) Now show NextPage ...")
		special_title = translation(30723) if COUNTRY == 'de' else translation(30724)
		addDir(special_title, artpic+'nextpage.png', {'mode': 'listEpisodes', 'url': DATA.get('nextPage'), 'page': int(PAGE)+1})
	if FOUND >= 1:
		for method in getSorting():
			xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	else:
		message = translation(30525).format(NAME) if NAME != "" else translation(30524)
		return dialog.notification(translation(30522).format('Ergebnisse'), message, icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchARTE():
	debug_MS("(navigator.SearchARTE) ------------------------------------------------ START = SearchARTE -----------------------------------------------")
	config = traversing.get_config()
	keyword = None
	if xbmcvfs.exists(searchHackFile):
		with open(searchHackFile, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		special_title = translation(30721) if COUNTRY == 'de' else translation(30722)
		keyword = dialog.input(heading=special_title, type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
		if keyword:
			keyword = quote(keyword)
			with open(searchHackFile, 'w') as record:
				record.write(keyword)
	if keyword: return listEpisodes(config['search_query'].format(API_URL, keyword), name, page)
	return None

def playVideo(url):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	""" 
	Übergabe des Abspiellinks von anderem Video-ADDON: plugin://plugin.video.tyl0re.arte/?mode=playVideo&url=048256-000-A oder: plugin://plugin.video.tyl0re.arte/?mode=playVideo&url=https://www.arte.tv/de/videos/048256-000-A/wir-waren-koenige/
	DEUTSCH:::"DE" = Original deutsch | "OmU" = Original mit deutschen Untertiteln | "OV" = Stumm oder Originalversion
	FRANCE::: "VOF" = Original französisch | "VF" = französisch vertont | "VOSTF" = Stumm oder Original mit französischen Untertiteln
	"""
	config = traversing.get_config()
	MASTERS, MEDIAS, BestMASTERS, BestMEDIAS = ([] for _ in range(4))
	finalURL, streamINDEX, streamTYPE = (False for _ in range(3))
	PLID = re.compile('/videos/(.+?)/', re.DOTALL).findall(url)[0] if url[:4] == "http" else url
	debug_MS("(navigator.playVideo[1]) ### Original-URL : {0} || PLID : {1} ###".format(str(url), str(PLID)))
	QUALITIES = [1080, 720, 406, 360, 216]
	SHORTCUTS = ['DE', 'OmU', 'OV', 'VO'] if COUNTRY == 'de' else ['VOF', 'VF', 'VOSTF', 'VO']
	if (prefSTREAM == '0' or enableINPUTSTREAM):
		try:
			content_HLS = getUrl(config['streaming_hls'].format(COUNTRY, str(PLID)), AUTH=PLAY_token) # Für HLS- und m3u8- Streams
			FACTS = json.loads(content_HLS, object_pairs_hook=OrderedDict)
			if len(FACTS['data']['attributes']['streams']) >= 1:
				PRESENT = True
		except: PRESENT = False
		if PRESENT:
			for elem in FACTS['data']['attributes']['streams']:
				quality, version = (0 for _ in range(2))
				stream = (elem.get('url') or "")
				if elem.get('versions', ''):
					name = (elem.get('versions', {})[0].get('label', '') or "")
					lang = (elem.get('versions', {})[0].get('shortLabel', '') or "")
				if elem.get('mainQuality', ''):
					quality = (elem.get('mainQuality', {}).get('label', '') or "")
					quality = quality.replace('p', '') if not isinstance(quality, int) else 0
				version = (elem.get('slot') or 0)
				if version == 1 and '.m3u8' in stream and int(quality) > 404:
					MASTERS.append({'url': stream, 'quality': int(quality), 'name': name, 'language': lang})
			xbmc.sleep(1000)
	content_MP4 = getUrl(config['streaming_mp4'].format(COUNTRY, str(PLID)))
	DATA = json.loads(content_MP4, object_pairs_hook=partial(defaultdict, lambda: None))
	DATA = DATA['videoJsonPlayer']['VSR']
	for key, val in DATA.items():
		quality, version = (0 for _ in range(2))
		quality  = val.get('height') if isinstance(val.get('height'), int) else 0
		media   = (val.get('mediaType', '') or "")
		mime    = (val.get('mimeType', '') or "")
		stream  = (val.get('url') or "")
		version = val.get('versionProg') if isinstance(val.get('versionProg'), int) else 0
		lang      = (val.get('versionShortLibelle', '') or "")
		if version == 1 and media and media.lower() == 'hls' and 'mil/master.m3u8' in stream and quality > 404:
			MASTERS.append({'url': stream, 'quality': quality, 'mimeType': mime, 'language': lang})
		if version == 1 and media and media.lower() == 'mp4' and quality > 358 and 'mp4' in stream:
			MEDIAS.append({'url': stream, 'quality': quality, 'mimeType': mime, 'language': lang})
	if MASTERS:
		debug_MS("(navigator.playVideo[3]) ORIGINAL_M3U8 ##### unsorted_LIST : {0} ###".format(str(MASTERS)))
		order_dict = {qual: index for index, qual in enumerate(QUALITIES)}
		BestMASTERS = sorted(MASTERS, key=lambda m: order_dict.get(m['quality'], float('inf')))
		debug_MS("(navigator.playVideo[3]) SORTED_LIST | M3U8 ### sorted_LIST : {0} ###".format(str(BestMASTERS)))
	if MEDIAS:
		debug_MS("(navigator.playVideo[3]) ORIGINAL_MP4 ##### unsorted_LIST : {0} ###".format(str(MEDIAS)))
		order_dict = {qual: index for index, qual in enumerate(QUALITIES)}
		BestMEDIAS = sorted(MEDIAS, key=lambda x: order_dict.get(x['quality'], float('inf')))
		debug_MS("(navigator.playVideo[3]) SORTED_LIST | MP4 ### sorted_LIST : {0} ###".format(str(BestMEDIAS)))
	if (prefSTREAM == '0' or enableINPUTSTREAM) and BestMASTERS:
		debug_MS("(navigator.playVideo[4]) ~~~~~ TRY NUMBER ONE TO GET THE FINALURL (m3u8) ~~~~~")
		finalURL = BestMASTERS[0]['url']
		streamINDEX = BestMASTERS[0]['quality']
		streamTYPE = 'M3U8/HLS'
	if not finalURL and BestMEDIAS:
		debug_MS("(navigator.playVideo[5]) ~~~~~ TRY NUMBER TWO TO GET THE FINALURL (mp4) ~~~~~")
		finalURL = BestMEDIAS[0]['url']
		streamINDEX = BestMEDIAS[0]['quality']
		streamTYPE = 'MP4'
	if finalURL and streamTYPE:
		log("(navigator.playVideo) [{0}p] {1}_stream : {2} ".format(str(streamINDEX), streamTYPE, finalURL))
		debug_MS("(navigator.playVideo[6]) ++++++++++++++++++++")
		listitem = xbmcgui.ListItem(path=finalURL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and streamTYPE == 'M3U8/HLS':
			listitem.setMimeType('application/vnd.apple.mpegurl')
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(playVideo) ##### Die angeforderte Video-Url wurde leider NICHT gefunden !!! #####")
		return dialog.notification(translation(30521).format('PLAY'), translation(30526), icon, 8000)

def playLive(url, name):
	listitem = xbmcgui.ListItem(path=url, label=name)
	listitem.setMimeType('application/vnd.apple.mpegurl')
	xbmc.Player().play(item=url, listitem=listitem)

def liveTV():
	debug_MS("(navigator.liveTV) ------------------------------------------------ START = liveTV -----------------------------------------------")
	config = traversing.get_config()
	for item in config['transmission']:
		if COUNTRY == 'de' and not 'Event' in item.get('description') and not 'Germany' in item.get('description'): continue
		elif COUNTRY == 'fr' and not 'Event' in item.get('description') and not 'France' in item.get('description'): continue
		img = item.get('img').format(evepic) if item.get('img') is not None else icon
		listitem = xbmcgui.ListItem(path=item['url'], label=item['title'])
		listitem.setArt({'icon': icon, 'thumb': img, 'poster': img, 'fanart': defaultFanart})
		xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url='{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playLive', 'url': item['url'], 'name': item['title']})), listitem=listitem)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def LINKING(info, extras=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playVideo', 'url': info['url']}))
	liz = get_ListItem(info, extras)
	if liz is None: return
	liz.addContextMenuItems([(translation(32154), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)

def addDir(name, image, params={}, tagline=None, plot=None, folder=True, background=False):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Tagline': tagline})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
