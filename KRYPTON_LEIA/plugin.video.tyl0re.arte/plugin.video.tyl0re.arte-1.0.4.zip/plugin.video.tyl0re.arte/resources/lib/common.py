﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import platform
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
import requests
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus, unquote_plus  # Python 2.X
else:
	from urllib.parse import urlencode, quote_plus, unquote_plus  # Python 3.X
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


global debuging
HOST_AND_PATH        = sys.argv[0]
ADDON_HANDLE         = int(sys.argv[1])
dialog                             = xbmcgui.Dialog()
addon                             = xbmcaddon.Addon()
addon_id                        = addon.getAddonInfo('id')
addon_name                 = addon.getAddonInfo('name')
addon_version              = addon.getAddonInfo('version')
addonPath                     = xbmc.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                        = xbmc.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
defaultFanart                = os.path.join(addonPath, 'fanart.jpg')
icon                                 = os.path.join(addonPath, 'icon.png')
artpic                              = os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
COUNTRY                       = {0: 'de', 1: 'fr'}[int(addon.getSetting('language'))]
prefQUALITY                 = {0: 720, 1: 406, 2: 360, 3: 216}[int(addon.getSetting('prefResolution'))]
enableADJUSTMENT    = addon.getSetting('show_settings') == 'true'
DEB_LEVEL                    = (xbmc.LOGNOTICE if addon.getSetting('enableDebug') == 'true' else xbmc.LOGDEBUG)
BASE_URL                      = "https://www.arte.tv/"
API_URL                         = "https://api-cdn.arte.tv/api/emac/v3/"+COUNTRY+"/web/"
OPA_token                     = "AOwImM4EGZ2gjYjRGZzEzYxMTNxMWOjJDO4gDO3UWN3UmN5IjNzAzMlRmMwEWM2I2NhFWN1kjYkJjZ1cjY1czN reraeB"
EMAC_token                  = "wYxYGNiBjNwQjZzIjMhRDOllDMwEjM2MDN3MjY4U2M1ATYkVWOkZTM5QzM4YzN2ITM0E2MxgDO1EjN5kjZmZWM reraeB"
PLAY_token                   = "QMjZTOkF2NwQDZlFTOmJDOiFGN1QGM4EjY5QWOhBzN4YzM4YGMiRTNjZjZyImMjFWZlRWZ3Q2Y1MmYyYDZyYzM reraeB"
response                         = requests.Session()

xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
xbmcplugin.setContent(ADDON_HANDLE, 'movies')

def py2_enc(s, encoding='utf-8'):
	if PY2:
		if not isinstance(s, basestring):
			s = str(s)
		s = s.encode(encoding) if isinstance(s, unicode) else s
	return s

def py2_uni(s, encoding='utf-8'):
	if PY2 and isinstance(s, str):
		s = unicode(s, encoding)
	return s

def py3_dec(d, encoding='utf-8'):
	if not PY2 and isinstance(d, bytes):
		d = d.decode(encoding)
	return d

def translation(id):
	return py2_enc(addon.getLocalizedString(id))

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGNOTICE):
	msg = py2_enc(msg)
	return xbmc.log('[{0} v.{1}]{2}'.format(addon_id, addon_version, msg), level)

def get_Description(info):
	depl = ""
	if 'fullDescription' in info and info['fullDescription'] and len(info['fullDescription']) > 10:
		depl = cleaning(info['fullDescription'])
	if depl == "" and 'description' in info and info['description'] and len(info['description']) > 10:
		depl = cleaning(info['description'])
	if depl == "" and 'shortDescription' in info and info['shortDescription'] and len(info['shortDescription']) > 10:
		depl = cleaning(info['shortDescription'])
	return depl

def get_ListItem(info, extras):
	Note_1 = ("" for _ in range(1))
	duration = ('0' for _ in range(1))
	seriesname, tagline, startTIMES, begins, endTIMES = (None for _ in range(5))
	title = cleaning(info['title'])
	if 'subtitle' in info and info['subtitle']:
		title += " - {0}".format(cleaning(info['subtitle']))
	if 'teaserText' in info and info['teaserText']:
		tagline = cleaning(info['teaserText'])
	max_res = max(info['images']['landscape']['resolutions'], key=lambda item: item['w'])
	image = max_res['url']
	duration = info['duration']
	if 'broadcastDates' in info and info['broadcastDates']:
		airedtime = datetime(*(time.strptime(info['broadcastDates'][0], '%Y{0}%m{0}%dT%H{1}%M{1}%SZ'.format('-', ':'))[0:6])) # 2019-06-13T13:30:00Z
		LOCALTIME = utc_to_local(airedtime)
		title = "[COLOR orangered]{0}[/COLOR]  {1}".format(LOCALTIME.strftime('%H:%M'), title)
	if 'availability' in info and info['availability'] != None:
		if 'start' in info['availability'] and info['availability']['start']:
			startDates = datetime(*(time.strptime(info['availability']['start'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2019-06-13T13:30:00Z
			LOCALstart = utc_to_local(startDates)
			startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			begins =  LOCALstart.strftime('%d{0}%m{0}%Y').format('.')
		if 'end' in info['availability'] and info['availability']['end']:
			endDates = datetime(*(time.strptime(info['availability']['end'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2020-05-30T21:59:00Z
			LOCALend = utc_to_local(endDates)
			endTIMES =  LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
	if startTIMES and endTIMES: Note_1 = translation(30670).format(str(startTIMES), str(endTIMES))
	elif startTIMES and endTIMES is None: Note_1 = translation(30671).format(str(startTIMES))
	if begins: xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_DATE)
	if duration != '0': xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_DURATION)
	liz = xbmcgui.ListItem(title)
	ilabels = {}
	ilabels['Episode'] = None
	ilabels['Season'] = None
	ilabels['Tvshowtitle'] = seriesname
	ilabels['Title'] = title
	ilabels['Tagline'] = tagline
	ilabels['Plot'] = Note_1+get_Description(info)
	ilabels['Duration'] = duration
	if begins != None:
		ilabels['Date'] = begins
	ilabels['Year'] = None
	ilabels['Genre'] = None
	ilabels['Director'] = None
	ilabels['Writer'] = None
	ilabels['Studio'] = 'ARTE'
	ilabels['Mpaa'] = None
	ilabels['Mediatype'] = 'video'
	liz.setInfo(type='Video', infoLabels=ilabels)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': image})
	if image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	if extras:
		debug_MS(extras+" ### Title = {0} ###".format(title))
		debug_MS(extras+" ### vidURL = {0} ###".format(info['url']))
		debug_MS(extras+" ### Duration = {0} ###".format(str(duration)))
		debug_MS(extras+" ### Thumb = {0} ###".format(image))
	return liz

def build_url(query):
	return '{0}?{1}'.format(HOST_AND_PATH, urlencode(query))

def load_header(REF, CALL_PRO):
	if REF is 'Unknown':
		HEADERS = response.headers.update({'User-Agent': get_userAgent(), 'Accept-Encoding': 'gzip, identity'})
	else:
		HEADERS = response.headers.update({'User-Agent': get_userAgent(), 'Accept-Encoding': 'gzip, identity', 'Referer': REF})
	if CALL_PRO != 'Standard':
		HEADERS = response.headers.update({'Authorization': '{}'.format(CALL_PRO[::-1])})
	return HEADERS

def get_userAgent():
	base = 'Mozilla/5.0 {0} AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
	system = platform.system()
	# Mac OSX
	if system == 'Darwin':
		return base.format('(Macintosh; Intel Mac OS X 10_10_1)')
	# Windows
	if system == 'Windows':
		return base.format('(Windows NT 10.0; WOW64)')
	# ARM based Linux
	if platform.machine().startswith('arm'):
		return base.format('(X11; CrOS armv7l 7647.78.0)')
	# x86 Linux
	return base.format('(X11; Linux x86_64)')

def getUrl(url, method='GET', CALL_PRO='Standard', REF='Unknown', headers=None, cookies=None, allow_redirects=False, verify=False, stream=None, data=None):
	if headers is None:
		headers = load_header(REF, CALL_PRO)
	if method == 'GET':
		content = response.get(url, headers=headers, allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=30).text
		content = py2_enc(content)
	elif method == 'POST':
		content = response.post(url, headers=headers, allow_redirects=allow_redirects, verify=verify, data=data, timeout=30)
	debug_MS("(common.getUrl) send url-HEADERS : {0}".format(str(response.headers)))
	return content

def utc_to_local(dt):
	if time.localtime().tm_isdst: return dt - timedelta(seconds=time.altzone)
	else: return dt - timedelta(seconds=time.timezone)

def cleaning(text):
	text = py2_enc(text)
	for n in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''),
				('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''), ('\xc2\xb7', '-'),
				('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&ouml;', 'ö'), ('&uuml;', 'ü'),
				('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
				('&agrave;', 'à'), ('&Agrave;', 'À'), ('&aacute;', 'á'), ('&Aacute;', 'Á'), ('&acirc;', 'â'), ('&Acirc;', 'Â'), ('&egrave;', 'è'), ('&Egrave;', 'È'), ('&eacute;', 'é'), ('&Eacute;', 'É'), ('&ecirc;', 'ê'), ('&Ecirc;', 'Ê'),
				('&igrave;', 'ì'), ('&Igrave;', 'Ì'), ('&iacute;', 'í'), ('&Iacute;', 'Í'), ('&icirc;', 'î'), ('&Icirc;', 'Î'), ('&ograve;', 'ò'), ('&Ograve;', 'Ò'), ('&oacute;', 'ó'), ('&Oacute;', 'ó'), ('&ocirc;', 'ô'), ('&Ocirc;', 'Ô'),
				('&ugrave;', 'ù'), ('&Ugrave;', 'Ù'), ('&uacute;', 'ú'), ('&Uacute;', 'Ú'), ('&ucirc;', 'û'), ('&Ucirc;', 'Û'), ('&yacute;', 'ý'), ('&Yacute;', 'Ý'),
				('&atilde;', 'ã'), ('&Atilde;', 'Ã'), ('&ntilde;', 'ñ'), ('&Ntilde;', 'Ñ'), ('&otilde;', 'õ'), ('&Otilde;', 'Õ'), ('&Scaron;', 'Š'), ('&scaron;', 'š'), ('&ccedil;', 'ç'), ('&Ccedil;', 'Ç'),
				('&alpha;', 'a'), ('&Alpha;', 'A'), ('&aring;', 'å'), ('&Aring;', 'Å'), ('&aelig;', 'æ'), ('&AElig;', 'Æ'), ('&epsilon;', 'e'), ('&Epsilon;', 'Ε'), ('&eth;', 'ð'), ('&ETH;', 'Ð'), ('&gamma;', 'g'), ('&Gamma;', 'G'),
				('&oslash;', 'ø'), ('&Oslash;', 'Ø'), ('&theta;', 'θ'), ('&thorn;', 'þ'), ('&THORN;', 'Þ'), ('&bull;', '•'), ('&iexcl;', '¡'), ('&iquest;', '¿'), ('&copy;', '(c)'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\n', ''), ('\t', ''), ('<br />', ' - '),
				("\\'", "'"), ("&rsquo;", "’"), ("&lsquo;", "‘"), ("&sbquo;", "’"), ('&rdquo;', '”'), ('&ldquo;', '“'), ('&bdquo;', '”'), ('&rsaquo;', '›'), ('lsaquo;', '‹'), ('&raquo;', '»'), ('&laquo;', '«')):
				text = text.replace(*n)
	return text.strip()

def parameters_string_to_dict(parameters):
	paramDict = {}
	if parameters:
		paramPairs = parameters[1:].split('&')
		for paramsPair in paramPairs:
			paramSplits = paramsPair.split('=')
			if (len(paramSplits)) == 2:
				paramDict[paramSplits[0]] = paramSplits[1]
	return paramDict

params = parameters_string_to_dict(sys.argv[2])
name = unquote_plus(params.get('name', ''))
url = unquote_plus(params.get('url', ''))
mode = unquote_plus(params.get('mode', 'root'))
image = unquote_plus(params.get('image', ''))
page = unquote_plus(params.get('page', '1'))
extras = unquote_plus(params.get('extras', 'standard'))
