﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2020 realvito

    ARTE.TV

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib.common import *
from resources.lib import navigator


def run():
	if mode == 'root':
		navigator.mainMenu()
	elif mode == 'listThemes':
		navigator.listThemes(url)
	elif mode == 'listSubThemes':
		navigator.listSubThemes(url, extras)
	elif mode == 'listMagazines':
		navigator.listMagazines(url)
	elif mode == 'listCollections':
		navigator.listCollections(url, extras)
	elif mode == 'listSelection':
		navigator.listSelection()
	elif mode == 'videosByDate':
		navigator.videosByDate(url)
	elif mode == 'listRunTime':
		navigator.listRunTime()
	elif mode == 'SearchArte':
		navigator.SearchArte()
	elif mode == 'listEpisodes':
		navigator.listEpisodes(url, page)
	elif mode == 'playVideo':
		navigator.playVideo(url)
	elif mode == 'playLive':
		navigator.playLive(url, name)
	elif mode == 'liveTV':
		navigator.liveTV()
	elif mode == 'aSettings':
		navigator.addon.openSettings()

run()
