﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import json
import xbmcvfs
import shutil
import time
import io
from datetime import datetime, timedelta
from collections import OrderedDict
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import quote_plus  # Python 2.X
else: 
	from urllib.parse import quote_plus  # Python 3.X

from .common import *


class Organize(object):

	def __init__(self):
		self.lib_go = addon.getSetting('dmax_library')
		self.media_folder = addon.getSetting('mediapath')

	def tolibrary(self, vid):
		debug_MS("(database.tolibrary) -------------------------------------------------- START = tolibrary --------------------------------------------------")
		if self.media_folder =="":
			dialog.ok(addon_id, translation(30502))
		elif self.media_folder !="" and ADDON_operate('service.cron.autobiblio'):
			LIBe = vid[vid.find('###START'):]
			LIBe = LIBe[:LIBe.find('END###')]
			name = LIBe.split('###')[2]
			url = LIBe.split('###')[3]
			stunden = LIBe.split('###')[4]
			title = name+'  (Serie)'
			newSOURCE = quote_plus(self.media_folder+fixPathSymbols(name))
			newURL = '{0}?mode=generatefiles&url={1}&name={2}'.format(sys.argv[0], url, quote_plus(name))
			newURL = quote_plus(newURL)
			newNAME = quote_plus(name)
			debug_MS("(database.tolibrary) ### newNAME : {0} ###".format(str(newNAME)))
			debug_MS("(database.tolibrary) ### newURL : {0} ###".format(str(newURL)))
			debug_MS("(database.tolibrary) ### newSOURCE : {0} ###".format(str(newSOURCE)))
			xbmc.executebuiltin('RunPlugin(plugin://service.cron.autobiblio/?mode=adddata&name={0}&stunden={1}&url={2}&source={3})'.format(newNAME, stunden, newURL, newSOURCE))
			dialog.notification(translation(30528), translation(30529).format(title, str(stunden)), icon, 15000)

	def generatefiles(self, url, name):
		from threading import Thread
		debug_MS("(database.generatefiles) -------------------------------------------------- START = generatefiles --------------------------------------------------")
		threads = []
		th = Thread(target=self.LIBRARY_Worker, args=[url, name])
		if hasattr(th, 'daemon'): th.daemon = True
		else: th.setDaemon()
		threads.append(th)
		for th in threads: th.start()

	def LIBRARY_Worker(self, BroadCast_Idd, BroadCast_Name):
		debug_MS("(database.LIBRARY_Worker) ### BroadCast_Idd = {0} ### BroadCast_Name = {1} ###".format(BroadCast_Idd, BroadCast_Name))
		if self.lib_go == 'false' or self.media_folder =="":
			return
		COMBINATION = []
		pos_ESP = 0
		EP_PAGE = int(1)
		url_1 = '{0}/content/shows?include=genres,images,seasons&sort=name&filter[id]={1}'.format(BASE_API, BroadCast_Idd)
		debug_MS("(database.LIBRARY_Worker) ##### URL-01 : {0} #####".format(str(url_1)))
		EP_Path = os.path.join(py2_uni(self.media_folder), py2_uni(fixPathSymbols(BroadCast_Name)))
		debug_MS("(database.LIBRARY_Worker) ##### EP_Path : {0} #####".format(str(EP_Path)))
		if os.path.isdir(EP_Path):
			shutil.rmtree(EP_Path, ignore_errors=True)
			xbmc.sleep(500)
		os.makedirs(EP_Path)
		try:
			content_1 = getUrl(url_1)
			SHOW_DATA = json.loads(content_1, object_pairs_hook=OrderedDict)
			TVS_title = cleaning(SHOW_DATA['data'][0]['attributes']['name'])
		except: return
		for elem in SHOW_DATA['data']:
			TVS_season, TVS_episode, TVS_plot, TVS_image = ("" for _ in range(4))
			if 'attributes' in elem:
				elem = elem['attributes']
			if 'seasonNumbers' in elem and elem['seasonNumbers'] != "" and elem['seasonNumbers'] is not None:
				TVS_season = str(elem['seasonNumbers'])
			if 'episodeCount' in elem and elem['episodeCount'] != "" and elem['episodeCount'] is not None:
				TVS_episode = str(elem['episodeCount'])
			if 'description' in elem and elem['description'] != "" and elem['description'] is not None:
				TVS_plot = cleaning(elem['description']).replace('\n\n\n', '\n\n')
			for attr in SHOW_DATA['included']:
				if 'attributes' in attr and 'src' in attr['attributes'] and attr['attributes']['src'] != "" and attr['attributes']['src'] is not None:
					if 'show-'+BroadCast_Idd+'-' in attr['attributes']['src']:
						TVS_image = attr['attributes']['src']
			try: TVS_airdate = elem['latestVideo']['airDate'][:10]
			except: TVS_airdate = elem['newestEpisodePublishStart'][:10]
			try: TVS_yeardate = elem['latestVideo']['airDate'][:4]
			except: TVS_yeardate = elem['newestEpisodePublishStart'][:4]
		while EP_PAGE < int(5):
			url_2 = '{0}/content/videos?include=images&sort=name&filter[show.id]={1}&filter[videoType]=EPISODE,STANDALONE&page[number]={2}&page[size]=100'.format(BASE_API, BroadCast_Idd, str(EP_PAGE))
			content_2 = getUrl(url_2)
			EPIS_DATA = json.loads(content_2, object_pairs_hook=OrderedDict)
			details = len(EPIS_DATA['data'])
			if details > 0:
				EP_PAGE += int(1)
			else:
				EP_PAGE += int(4)
			debug_MS("(database.LIBRARY_Worker) ### URL-2 : {0} ### EP_PAGE : {1} ### origSERIE : {2} ###".format(url_2, str(EP_PAGE-1), str(BroadCast_Name)))
			for vid in EPIS_DATA['data']:
				EP_idd, EP_SUFFIX, EP_type, Note_1, Note_2, Note_3, EP_image = ("" for _ in range(7))
				EP_season, EP_episode, EP_duration = ('0' for _ in range(3))
				startTIMES, endTIMES = (None for _ in range(2))
				genreLIST=[]
				if 'relationships' in vid and 'genres' in vid['relationships'] and 'data' in vid['relationships']['genres'] and vid['relationships']['genres']['data'] != "" and vid['relationships']['genres']['data'] is not None:
					for item in vid['relationships']['genres']['data']:
						try: gNames = convert(str(item['id']))
						except: gNames = ""
						genreLIST.append(gNames)
				try: EP_genre1 = genreLIST[0]
				except: EP_genre1 = ""
				try: EP_genre2 = genreLIST[1]
				except: EP_genre2 = ""
				try: EP_genre3 = genreLIST[2]
				except: EP_genre3 = ""
				if 'id' in vid and vid['id'] != "" and vid['id'] is not None:
					EP_idd = str(vid['id'])
				if 'attributes' in vid:
					vid = vid['attributes']
				if 'clearkeyEnabled' in vid and vid['clearkeyEnabled'] is True:
					debug_MS("(database.LIBRARY_Worker) ##### ELEMENT : {0} #####".format(str(vid)))
					if 'name' in vid and vid['name'] != "" and vid['name'] is not None:
						EP_name = cleaning(vid['name'])
					else: continue
					if ('isExpiring' in vid and vid['isExpiring'] is True) or ('isNew' in vid and vid['isNew'] is True):
						EP_SUFFIX = translation(30624) if ('isNew' in vid and vid['isNew'] is True) else translation(30625)
					if 'seasonNumber' in vid and vid['seasonNumber'] != "" and str(vid['seasonNumber']) != "0" and vid['seasonNumber'] is not None:
						EP_season = str(vid['seasonNumber']).zfill(2)
					if 'episodeNumber' in vid and vid['episodeNumber'] != "" and str(vid['episodeNumber']) != "0" and vid['episodeNumber'] is not None:
						EP_episode = str(vid['episodeNumber']).zfill(2)
					if 'videoType' in vid and vid['videoType'] != "" and vid['videoType'] is not None:
						EP_type = vid['videoType']
						if EP_type.upper() == 'STANDALONE' and EP_episode == '0':
							pos_ESP += 1
					if EP_season != '0' and EP_episode != '0':
						EP_name = 'S'+EP_season+'E'+EP_episode+': '+EP_name
					else:
						if EP_type.upper() == 'STANDALONE':
							EP_episode = str(pos_ESP).zfill(2)
							EP_name = 'S00E'+EP_episode+': '+EP_name
					if 'publishStart' in vid and vid['publishStart'] != "" and vid['publishStart'] is not None and not str(vid['publishStart']).startswith('1970'):
						try:
							startDATES = datetime(*(time.strptime(vid['publishStart'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2019-06-23T14:10:00Z
							LOCALstart = utc_to_local(startDATES)
							startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
							begins =  LOCALstart.strftime('%d{0}%m{0}%Y').format('.')
						except: pass
					if 'publishEnd' in vid and vid['publishEnd'] != "" and vid['publishEnd'] is not None and not str(vid['publishEnd']).startswith('1970'):
						try:
							endDATES = datetime(*(time.strptime(vid['publishEnd'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2019-06-23T14:10:00Z
							LOCALend = utc_to_local(endDATES)
							endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						except: pass
					if startTIMES and endTIMES: Note_1 = translation(30629).format(str(startTIMES), str(endTIMES))
					elif startTIMES and endTIMES is None: Note_1 = translation(30630).format(str(startTIMES))
					if 'description' in vid and vid['description'] != "" and vid['description'] is not None:
						Note_2 = cleaning(vid['description']).replace('\n\n\n', '\n\n')
					EP_plot = BroadCast_Name+'[CR]'+Note_1+Note_2
					if 'videoDuration' in vid and vid['videoDuration'] != "" and vid['videoDuration'] is not None:
						EP_duration = get_Time(vid['videoDuration'], 'MINUTES')
					for attr in EPIS_DATA['included']:
						if 'attributes' in attr and 'src' in attr['attributes'] and attr['attributes']['src'] != "" and attr['attributes']['src'] is not None:
							if 'id' in attr and attr['id'] is not None and 'video-'+EP_idd in attr['id']:
								EP_image = attr['attributes']['src']
					try: EP_airdate = vid['airDate'][:10]
					except: EP_airdate = vid['publishStart'][:10]
					try: EP_yeardate = vid['airDate'][:4]
					except: EP_yeardate = vid['publishStart'][:4]
					episodeFILE = py2_uni(fixPathSymbols(EP_name)) # NAME=STANDARD OHNE HINWEIS (neu|endet bald) !!!
					EP_LONG_title = EP_name+EP_SUFFIX # NAME=LONVERSION MIT SUFFIX=HINWEIS (neu|endet bald) !!!
					COMBINATION.append([episodeFILE, EP_LONG_title, TVS_title, EP_idd, EP_season, EP_episode, EP_plot, EP_duration, EP_image, EP_genre1, EP_genre2, EP_genre3, EP_yeardate, EP_airdate])
		if not COMBINATION: return
		for episodeFILE, EP_LONG_title, TVS_title, EP_idd, EP_season, EP_episode, EP_plot, EP_duration, EP_image, EP_genre1, EP_genre2, EP_genre3, EP_yeardate, EP_airdate in COMBINATION:
			nfo_EPISODE_string = os.path.join(EP_Path, episodeFILE+'.nfo')
			with io.open(nfo_EPISODE_string, 'w', encoding='utf-8') as textobj_EP:
				textobj_EP.write(py2_uni(
'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<episodedetails>
    <title>{0}</title>
    <showtitle>{1}</showtitle>
    <season>{2}</season>
    <episode>{3}</episode>
    <plot>{4}</plot>
    <runtime>{5}</runtime>
    <thumb>{6}</thumb>
    <genre clear="true">{7}</genre>
    <genre>{8}</genre>
    <genre>{9}</genre>
    <year>{10}</year>
    <aired>{11}</aired>
    <studio clear="true">DMAX</studio>
</episodedetails>'''.format(EP_LONG_title, TVS_title, EP_season, EP_episode, EP_plot, EP_duration, EP_image, EP_genre1, EP_genre2, EP_genre3, EP_yeardate, EP_airdate)))
			streamfile = os.path.join(EP_Path, episodeFILE+'.strm')
			debug_MS("(database.LIBRARY_Worker) ##### streamFILE : {0} #####".format(cleaning(streamfile)))
			file = xbmcvfs.File(streamfile, 'w')
			file.write('plugin://'+addon_id+'/?mode=playVideo&url='+str(EP_idd))
			file.close()
		nfo_SERIE_string = os.path.join(EP_Path, 'tvshow.nfo')
		with io.open(nfo_SERIE_string, 'w', encoding='utf-8') as textobj_TVS:
			textobj_TVS.write(py2_uni(
'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<tvshow>
    <title>{0}</title>
    <showtitle>{0}</showtitle>
    <season>{1}</season>
    <episode>{2}</episode>
    <plot>{3}</plot>
    <thumb aspect="landscape" type="" season="">{4}</thumb>
    <fanart url="">
        <thumb dim="1280x720" colors="" preview="{4}">{4}</thumb>
    </fanart>
    <genre clear="true">{5}</genre>
    <genre>{6}</genre>
    <genre>{7}</genre>
    <year>{8}</year>
    <aired>{9}</aired>
    <studio clear="true">DMAX</studio>
</tvshow>'''.format(TVS_title, TVS_season, TVS_episode, TVS_plot, TVS_image, EP_genre1, EP_genre2, EP_genre3, TVS_yeardate, TVS_airdate)))
		debug_MS("(database.LIBRARY_Worker) XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  ENDE = LIBRARY_Worker  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
