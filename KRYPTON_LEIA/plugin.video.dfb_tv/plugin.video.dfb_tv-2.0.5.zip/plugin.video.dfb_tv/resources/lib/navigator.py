﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote, unquote  # Python 2.X
else: 
	from urllib.parse import urlencode, quote, unquote  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu(): # Auflistung der Kategorien zur Überprüfung: https://search.dfb.de/categories.json?
	addDir(translation(30601), icon, {'mode': 'listBroadcasts'})
	addDir(translation(30602), icon, {'mode': 'listSports_Men'})
	addDir(translation(30603), icon, {'mode': 'listSports_Women'})
	addDir(translation(30604), icon, {'mode': 'listBroadcasts', 'category': 'Amateurfußball'})
	addDir(translation(30605), icon, {'mode': 'listBroadcasts', 'category': 'Futsal'})
	addDir(translation(30606), icon, {'mode': 'listBroadcasts', 'category': 'Fan Club'})
	addDir(translation(30607), icon, {'mode': 'listBroadcasts', 'category': 'English Videos'})
	addDir(translation(30608), icon, {'mode': 'listBroadcasts', 'category': 'DFB-Akademie'})
	addDir(translation(30609), icon, {'mode': 'listBroadcasts', 'category': 'Sportliche Strukturen'})
	addDir(translation(30610), icon, {'mode': 'listBroadcasts', 'category': 'Talentförderung'})
	addDir(translation(30611), artpic+'basesearch.png', {'mode': 'SearchDFBTV'})
	addDir(translation(30612), artpic+'livestream.png', {'mode': 'listLivestreams'})
	if enableADJUSTMENT:
		addDir(translation(30613), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30614), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSports_Men():
	debug_MS("(navigator.listSports_Men) -------------------------------------------------- START = listSports_Men --------------------------------------------------")
	addDir(translation(30621), icon, {'mode': 'listBroadcasts', 'category': 'Männer'})
	addDir(translation(30622), icon, {'mode': 'listBroadcasts', 'category': 'Die Mannschaft'})
	addDir(translation(30623), icon, {'mode': 'listBroadcasts', 'category': 'Bundesliga'})
	addDir(translation(30624), icon, {'mode': 'listBroadcasts', 'category': '3. Liga'})
	addDir(translation(30625), icon, {'mode': 'listBroadcasts', 'category': 'A-Junioren-Bundesliga'})
	addDir(translation(30626), icon, {'mode': 'listBroadcasts', 'category': 'B-Junioren-Bundesliga'})
	addDir(translation(30627), icon, {'mode': 'listBroadcasts', 'category': 'DFB-Pokal'})
	addDir(translation(30628), icon, {'mode': 'listBroadcasts', 'category': 'U 21-Männer'})
	addDir(translation(30629), icon, {'mode': 'listBroadcasts', 'category': 'U20-Männer'})
	addDir(translation(30630), icon, {'mode': 'listBroadcasts', 'searching': 'junioren'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSports_Women():
	debug_MS("(navigator.listSports_Women) -------------------------------------------------- START = listSports_Women --------------------------------------------------")
	addDir(translation(30631), icon, {'mode': 'listBroadcasts', 'category': 'Frauen'})
	addDir(translation(30632), icon, {'mode': 'listBroadcasts', 'category': 'Frauen Nationalmannschaft'})
	addDir(translation(30633), icon, {'mode': 'listBroadcasts', 'category': 'Allianz Frauen-Bundesliga'})
	addDir(translation(30634), icon, {'mode': 'listBroadcasts', 'category': 'FLYERALARM Frauen-Bundesliga'})
	addDir(translation(30635), icon, {'mode': 'listBroadcasts', 'category': 'DFB-Pokal der Frauen'})
	addDir(translation(30636), icon, {'mode': 'listBroadcasts', 'searching': 'juniorinnen'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(QUERY, CAT, PAGE, LIMIT):
	debug_MS("(navigator.listBroadcasts) -------------------------------------------------- START = listBroadcasts --------------------------------------------------")
	SWAPPED = 'q={0}&'.format(QUERY) if QUERY != 'None' else 'categories={0}&'.format(quote(CAT))
	NEW_URL = 'https://search.dfb.de/search/videos.json?{0}page={1}'.format(SWAPPED, PAGE)
	content = getUrl(NEW_URL)
	debug_MS("(navigator.listBroadcasts) ### NEW_URL : {0} ###".format(NEW_URL))
	DATA = json.loads(content)
	if len(DATA['results']) > 0:
		for item in DATA['results']:
			debug_MS("(navigator.listBroadcasts) ### ENTRY : {0} ###".format(str(item)))
			title = cleaning(item['title'])
			episID = (str(item.get('guid', '').replace('video-', '')) or "")
			plot = (cleaning(item.get('description', '')) or "")
			thumb = (unquote(item.get('image_url', '')) or icon)
			photo = thumb[thumb.find('url=')+4:] if thumb != icon else thumb
			if str(item.get('pub_date'))[7:10].isdigit():
				title = py2_enc(item.get('pub_date'))+' - '+title
			debug_MS("(navigator.listBroadcasts) ##### TITLE : {0} || episID : {1} || FOTO : {2} #####".format(str(title), episID, photo))
			addLink(title, photo, {'mode': 'playVideo', 'vidid': episID}, plot)
		if DATA.get('total', ''):
			if isinstance(DATA['total'], int) and int(DATA['total']) > int(LIMIT)*int(PAGE):
				debug_MS("(navigator.listBroadcasts) Now show NextPage ...")
				addDir(translation(30640).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listBroadcasts', 'searching': QUERY, 'category': CAT, 'page': int(PAGE)+1})
	else:
		return dialog.notification(translation(30522).format('Ergebnisse'), translation(30525), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchDFBTV():
	debug_MS("(navigator.SearchDFBTV) ------------------------------------------------ START = SearchDFBTV -----------------------------------------------")
	keyword = None
	if xbmcvfs.exists(searchHackFile):
		with open(searchHackFile, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading="Search DfB.TV ...", type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
		if keyword:
			keyword = quote(keyword)
			with open(searchHackFile, 'w') as record:
				record.write(keyword)
	if keyword: return listBroadcasts(keyword, category, page, limit)
	return None

def listLivestreams():
	debug_MS("(navigator.listLivestreams) ------------------------------------------------ START = listLivestreams -----------------------------------------------")
	FOUND = 0
	content = getUrl('https://tv.dfb.de/static/livestreams/')
	index_RESULT = re.search(r'Derzeit keine Livestreams vorhanden', content)
	if not index_RESULT:
		match = re.findall(r'<div class="video-teaser.*?<img src=".*?/images/(.+?)_.*?subline">(.+?)</.*?-headline">(.+?)</', content, re.S)
		for episID, subTITLE, nomTITLE in match:
			startCOMPLETE, startDATE, startTIME = (None for _ in range(3))
			FOUND += 1
			episID = episID.strip()
			subTITLE, nomTITLE = cleaning(subTITLE), cleaning(nomTITLE)
			photo = 'https://tv.dfb.de/images/{0}_1360x760.jpg'.format(episID)
			relevance = subTITLE[:subTITLE.find('//')].strip()
			debug_MS("(navigator.listLivestreams) TITLE : {0} • {1}".format(str(relevance), str(nomTITLE)))
			debug_MS("(navigator.listLivestreams) IDD : {0}".format(str(episID)))
			debug_MS("(navigator.listLivestreams) FOTO : {0}".format(photo))
			if str(relevance)[7:10].isdigit():
				aired = datetime(*(time.strptime(relevance, '%d{0}%m{0}%Y {1} %H{2}%M'.format('.', '-', ':'))[0:6]))
				startCOMPLETE = aired.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				startDATE = aired.strftime('%d{0}%m{0}%Y').format('.')
				startTIME = aired.strftime('%H{0}%M').format(':')
			name = startDATE+" - "+nomTITLE if startDATE else nomTITLE
			if 'jetzt live' in nomTITLE.lower() and startTIME:
				name = translation(30641).format(startTIME, nomTITLE)
			elif not 'jetzt live' in nomTITLE.lower() and startCOMPLETE:
				name = startCOMPLETE+" - "+nomTITLE
			addLink(name, photo, {'mode': 'playVideo', 'vidid': episID, 'extras': 'LIVE'}, plot=nomTITLE+'[CR]'+subTITLE)
	if FOUND == 0: 
		return dialog.notification(translation(30522).format('VIDEOS'), translation(30524).format('LIVESTREAMS'), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def playVideo(Xidd, FILTER):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	finalURL = getVideo(Xidd, FILTER)
	if finalURL:
		log("(navigator.playVideo) FILTER : {0} || StreamURL : {1}".format(FILTER, finalURL))
		listitem = xbmcgui.ListItem(path=finalURL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'm3u8' in finalURL:
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
			listitem.setMimeType('application/vnd.apple.mpegurl')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### IDD : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *dfb.de* gefunden !!! ##########".format(Xidd))
		return dialog.notification(translation(30521).format('VIDEO'), translation(30526), icon, 8000)

def getVideo(Xidd, FILTER):
	debug_MS("(navigator.getVideo) ------------------------------------------------ START = getVideo -----------------------------------------------")
	tokenURL = None
	wanted = [',1200', ',800', ',500']
	# https://tv.dfb.de/server/streamAccess.php?videoId=22862&target=17&partner=2180&label=web_dfbtv&area=testarea&format=iphone
	# testen: URL_1 = https://tv.dfb.de/server/videoConfig.php?videoid=25612&partnerid=2180&format=iphone
	URL_1 = 'https://tv.dfb.de/server/hd_video.php?play='+Xidd
	debug_MS("(navigator.getVideo) ### URL_1 : {0} ### FILTER : {1} ###".format(URL_1, FILTER))
	try:
		DATA_1 = getUrl(URL_1)
		if FILTER == 'LIVE' and '<live>true</live>' in DATA_1:
			if not ('<islive>true</islive>' in DATA_1):
				debug_MS("(navigator.getVideo) ### TRY TO GET LIVE-URL = NO-<islive>-FOUND ###")
				return False
		URL_2 = 'https:'+cleaning(re.findall('<url>(.+?)</url>', DATA_1, re.S)[0]).split('?')[0]+'?format=iphone'
		debug_MS("(navigator.getVideo) ### URL_2 : {0} ###".format(URL_2))
		DATA_2 = getUrl(URL_2)
		videoURL = re.findall('url="([^"]+?)"', DATA_2, re.S)[0].replace('&amp;', '&')
		debug_MS("(navigator.getVideo) ### Video-URL : {0} ###".format(videoURL))
		tokenURL = re.findall('auth="([^"]+?)"', DATA_2, re.S)[0].replace('&amp;', '&')
		debug_MS("(navigator.getVideo) ### Token-URL : {0} ###".format(tokenURL))
	except: return False
	startURL = videoURL[:videoURL.find('_,')+2]
	endURL = '?hdnea='+tokenURL if tokenURL else ""
	if FILTER == 'LIVE' and videoURL.endswith('.m3u8'):
		debug_MS("(navigator.getVideo) ### LIVE-URL : {0} ###".format(videoURL+endURL))
		return videoURL+endURL
	else: debug_MS("(navigator.getVideo) ### VIDEO-URL : {0} XXX,.mp4.csmil/index_0_av.m3u8{1} ###".format(startURL, endURL))
	if not any(x in videoURL for x in wanted):
		return False
	elif ',1200' in videoURL and enableINPUTSTREAM:
		return startURL+'1200,.mp4.csmil/index_0_av.m3u8'+endURL
	elif ',1200' in videoURL and prefQUALITY == 720:
		return startURL+'1200,.mp4.csmil/index_0_av.m3u8'+endURL
	elif ',800' in videoURL and prefQUALITY == 480:
		return startURL+'800,.mp4.csmil/index_0_av.m3u8'+endURL
	elif ',500' in videoURL and prefQUALITY == 360:
		return startURL+'500,.mp4.csmil/index_0_av.m3u8'+endURL

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Genre'] = 'Sport'
	info['Studio'] = 'DFB.de'
	info['Mediatype'] = 'tvshow'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
