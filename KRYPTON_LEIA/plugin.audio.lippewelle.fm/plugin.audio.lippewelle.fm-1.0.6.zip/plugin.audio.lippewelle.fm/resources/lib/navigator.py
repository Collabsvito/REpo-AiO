﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
import _strptime
from datetime import datetime, timedelta
import threading
import traceback
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus  # Python 2.X
else:
	from urllib.parse import urlencode, quote_plus  # Python 3.X

from .common import *
from .provider import Client


def mainMenu():
	addDir(translation(30601), artpic+'radio.jpg', {'mode': 'listRadio', 'type': 'audio'})
	addDir(translation(30602), artpic+'podcast.jpg', {'mode': 'listPodcasts', 'url': BASE_URL+'/mediathek/podcasts/euer-tag-kompakt.html', 'type': 'audio'})
	addDir(translation(30603), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/heimspiel-musik-von-hier-5182.rss', 'type': 'audio'})
	addDir(translation(30604), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/corona-update-der-podcast-4830.rss', 'type': 'audio'})
	addDir(translation(30605), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/hammer-geschichten-1548.rss', 'type': 'audio'})
	addDir(translation(30606), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/sommer-bei-uns-4393.rss', 'type': 'audio'})
	addDir(translation(30607), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/addon-der-gaming-news-podcast-4610.rss', 'type': 'audio'})
	addDir(translation(30608), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/guter-stoff-3953.rss', 'type': 'audio'})
	addDir(translation(30609), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/comedy-1593.rss', 'type': 'audio'})
	addDir(translation(30610), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/midlife-party-4868.rss', 'type': 'audio'})
	addDir(translation(30611), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/die-expertenrunde-reloaded-5046.rss', 'type': 'audio'})
	addDir(translation(30612), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/beste-gaeste-3923.rss', 'type': 'audio'})
	addDir(translation(30613), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/interviews-und-serien-1762.rss', 'type': 'audio'})
	addDir(translation(30614), artpic+'podcast.jpg', {'mode': 'listPodcasts', 'url': BASE_URL+'/artikel/serie-schuetzenfest-abc-105422.html', 'type': 'audio'})
	if enableADJUSTMENT:
		addDir(translation(30630), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listRadio():
	debug_MS("(navigator.listRadio) -------------------------------------------------- START = listRadio --------------------------------------------------")
	traversing = Client(Client.SUPPORTED_STATIONS)
	config = traversing.get_config()
	for pick in config['picks']:
		ID = str(pick['rpID'])
		name = cleaning(pick['label'])
		plot = cleaning(pick['description'])
		audio_url = pick['audio_url']
		thumb = pick['thumb']
		addition = 'DIRECTstream@@'+name+'@@'+artpic+thumb+'@@'
		debug_MS("(navigator.listRadio) ### TITLE = {0} || IDD = {1} || AUDIO-URL = {2} ###".format(name, ID, str(audio_url)))
		addLink(name, artpic+thumb, {'mode': 'playVideo', 'url': audio_url, 'extras': addition}, plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listFeedsRSS(url):
	debug_MS("(navigator.listFeedsRSS) -------------------------------------------------- START = listFeedsRSS --------------------------------------------------")
	debug_MS("(navigator.listFeedsRSS) ### URL = {0} ###".format(url))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND = ([] for _ in range(3))
	counter = 0
	startURL = url
	html = getUrl(url)
	articles = re.findall('<item>(.*?)</item>', html, re.S)
	for item in articles:
		debug_MS("(navigator.listFeedsRSS) no.02 ##### FOLGE : {0} #####".format(str(item)))
		title, photo, Note_1, Note_2 = ("" for _ in range(4))
		startTIMES, mp3 = (None for _ in range(2))
		duration = '0'
		counter += 1
		link = re.compile('<link>([^<]+)</link>', re.S).findall(item)[0]
		link = link if link[:4] == 'http' else BASE_URL+link
		title = re.compile('<title>([^<]+)</title>', re.S).findall(item)[0]
		title = cleaning(title)
		published = re.compile('<pubDate>([^<]+)</pubDate>', re.S).findall(item)[0]
		try:
			startDATES = datetime(*(time.strptime(published[5:25], '%d{0}%b{0}%Y{0}%H{1}%M{1}%S'.format(' ', ':'))[0:6])) # Mon, 04 Nov 2019 02:00:00 GMT
			startTIMES = startDATES.strftime('%d{0}%m{0}%Y').format('-')
		except: pass
		if startTIMES: Note_1 = '[COLOR chartreuse]'+str(startTIMES)+'[/COLOR][CR]'
		desc = re.compile('<description>([^<]+)</description>', re.S).findall(item)
		Note_2 = cleaning(desc[0])+'[CR][CR]' if desc else '[CR]' if startTIMES and not desc else ""
		COMBI_FIRST.append([int(counter), title, Note_1, Note_2, startURL, link])
		COMBI_LINKS.append(str(counter)+'@@'+link+'@@'+title+'@@'+startURL+'@@')
	if COMBI_LINKS:
		debug_MS("(navigator.listFeedsRSS) no.03 ### COMBI_FIRST = {0} ###".format(str(COMBI_FIRST)))
		COMBI_SECOND = getMultiData(COMBI_LINKS)
		if COMBI_FIRST and COMBI_SECOND:
			debug_MS("~~~~~~~~~~~~~~~~~~~~~~~~~")
			RESULT = [a + [b[0]] + [b[1]] + [b[2]] + [b[3]] + [b[4]] + [b[5]] for a in COMBI_FIRST for b in COMBI_SECOND if a[0] == b[0]]
			RESULT = sorted(RESULT, key=lambda k: (k[0], k[5]), reverse=False)
			for da in RESULT:
				NUM1, TITLE1, DATE1, DESC1, START1, LINK1, NUM2, TITLE2, PIC2, AUD2, DUR2, DESC2 = da[0], da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10], da[11]
				if (AUD2 and not 'serien-1762' in START1) or (AUD2 and 'serien-1762' in START1 and ('heusener-hoheneder' in LINK1 or 'hausbesuch-' in LINK1)):
					name = TITLE2 if TITLE2 else TITLE1
					SAME = True if DESC1.replace('[CR][CR]', '') in DESC2 else False
					plot = DATE1+DESC1 if len(DESC1) > 90 and SAME else DATE1+DESC1+DESC2
					debug_MS("(navigator.listFeedsRSS) no.04 ### TITLE = {0} || audioURL = {1} || PHOTO = {2} ###".format(name, AUD2, PIC2))
					addLink(name, PIC2, {'mode': 'playVideo', 'url': AUD2, 'extras': 'standard'}, plot, DUR2)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPodcasts(url):
	debug_MS("(navigator.listPodcasts) -------------------------------------------------- START = listPodcasts --------------------------------------------------")
	debug_MS("(navigator.listPodcasts) ### URL = {0} ###".format(url))
	html = getUrl(url)
	if 'programm' in url or 'mediathek' in url: # https://www.lippewelle.de/mediathek/podcasts/euer-tag-kompakt.html
		spl = html.split('<div id="podlovePlayer')
		for i in range(1, len(spl), 1):
			entry = spl[i]
			title = re.compile('title: "([^"]+?)"', re.S).findall(entry)[-2]
			title = cleaning(title)
			# "https://www.lippewelle.de/files/mp316/traumberufe_1220.mp3" oder "https://podcasts.podcastmaker.de/14/0/5864/latest"
			link = re.compile('url: "(http.*?(?:latest|.mp3))"', re.S).findall(entry)[0]
			debug_MS("(navigator.listPodcasts) no.01 ### TITLE = {0} || LINK = {1} ###".format(title, link))
			addLink(title, artpic+'podcast.jpg', {'mode': 'playVideo', 'url': link, 'extras': 'standard'})
	else: # https://www.lippewelle.de/artikel/serie-schuetzenfest-abc-105422.html
		podcast = re.findall('<article class="article__details">(.*?)</div></article></div>', html, re.S)[0]
		spl = podcast.split('<h2')
		for i in range(1, len(spl), 1):
			entry = spl[i]
			debug_MS("(navigator.listPodcasts) no.02 ##### FOLGE : {0} #####".format(str(entry)))
			title = re.compile('>([^<]+?)</h2>', re.S).findall(entry)[0]
			title = cleaning(title)
			desc = re.compile('<p[^>]*>(.*?)</p>', re.S).findall(entry)
			plot = cleaning(re.sub('\<.*?\>', '', desc[0])) if desc else ""
			DATA = re.compile('data-audio=["\']{([^<]+)}["\']></div>', re.S).findall(entry)
			for element in DATA:
				element = element.replace('&quot;', '"').replace('&amp;', '&').replace('[{', '')
				debug_MS("(navigator.listPodcasts) no.03 ##### ELEMENT : {0} #####".format(str(element)))
				img = re.compile('"poster":"(.+?(?:\.png|\.jpg|\.jpeg))"', re.S).findall(element)
				photo = img[0].replace(' ', '%20') if img and img[0][:4] == 'http' else BASE_URL+img[0] if img and img[0][:6] == '/files' else artpic+'podcast.jpg'
				audio = re.compile('"url":"(https?://.+?)","mimeType"', re.S).findall(element)
				mp3 = audio[0] if audio else None
				running = re.compile('"duration":"([^"]+?)","alwaysShowHours"', re.S).findall(element)
				duration = get_Seconds(running[0]) if running else '0'
				if mp3: addLink(title, photo, {'mode': 'playVideo', 'url': mp3, 'extras': 'standard'}, plot, duration)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

COMBI_OUTPUT = []
pill2kill = threading.Event()
def listSubstances(parts, pill2kill, course):
	num = parts.split('@@')[0]
	elem = parts.split('@@')[1]
	firstTI = parts.split('@@')[2] if course=='FEEDS' else ""
	firstUL = parts.split('@@')[3] if course=='FEEDS' else ""
	if not pill2kill.is_set():
		try:
			Supported = ['1548.rss', '3953.rss', '3923.rss', '1762.rss'] # hammer-geschichten-1548.rss, guter-stoff-3953.rss, beste-gaeste-3923.rss, interviews-und-serien-1762.rss #
			if course == 'FEEDS':
				content = getUrl(elem)
				podcast = re.findall('<article class="article__details">(.*?)</div></article></div>', content, re.S)[0]
				DATA1 = re.compile('<div class="podlovePlayer" data-audio="{([^<]+)}"></div>', re.S).findall(podcast)
				if DATA1:
					multiPODS = len(DATA1)
					for item in DATA1:
						photo, plot = ("" for _ in range(2))
						title, subtitle, mp3 = (None for _ in range(3))
						duration = '0'
						plot = get_Description(podcast, item)
						item = item.replace('&quot;', '"').replace('&amp;', '&').replace('[{', '')
						if multiPODS == 1 and plot == "":
							desc2 = re.compile('podlovePlayer\\(this, options\\).then\\(function\\(store\\).*?<p[^>]*>(.*?)</p>', re.S).findall(podcast)
							plot = cleaning(re.sub('\<.*?\>', '', desc2[0])) if desc2 else ""
						img1 = re.compile('"poster":"(.+?(?:\.png|\.jpg|\.jpeg))"', re.S).findall(item)
						photo = img1[0].replace(' ', '%20') if img1 and img1[0][:4] == 'http' else BASE_URL+img1[0] if img1 and img1[0][:6] == '/files' else ""
						if photo == "" or 'sendercovers/neutrales' in photo:
							img2 = re.compile('<div class="card-image"><img.*?src="([^"]+?)" data-size', re.S).findall(podcast)
							photo = BASE_URL+'/files/'+img2[0].split('source=')[1].split('&amp;')[0] if img2 and 'source=' in img2[0] else artpic+'podcast.jpg'
						audio = re.compile('"url":"(https?://.+?)","mimeType"', re.S).findall(item)
						mp3 = audio[0] if audio else None
						subtext = re.compile('"title":"(.*?)","summary"', re.S).findall(item)
						subtitle = cleaning(subtext[0]) if subtext else None
						if firstTI !="" and subtitle and subtitle not in firstTI and any(x in firstUL for x in Supported):
							title = firstTI+' - '+subtitle
						running = re.compile('"duration":"([^"]+?)","alwaysShowHours"', re.S).findall(item)
						duration = get_Seconds(running[0]) if running else '0'
						COMBI_OUTPUT.append([int(num), title, photo, mp3, duration, plot])
				else:
					photo, plot = ("" for _ in range(2))
					title, subtitle, mp3 = (None for _ in range(3))
					duration = '0'
					img = re.compile('<div class="card-image"><img.*?src="([^"]+?)" data-size', re.S).findall(podcast)
					photo = BASE_URL+'/files/'+img[0].split('source=')[1].split('&amp;')[0] if img and 'source=' in img[0] else artpic+'podcast.jpg'
					desc = re.compile('</header><div class="row">.*?<p[^>]*>(.*?)</p>', re.S).findall(podcast)
					plot = cleaning(re.sub('\<.*?\>', '', desc[0])) if desc else ""
					audio = re.compile('document.write\\(httpGet\\("(https://podcasts.+?)/podcast.html"', re.S).findall(podcast)
					mp3 = audio[0] if audio else None
					subtext = re.compile('<p>(.*?)</p>', re.S).findall(podcast)
					subtitle = cleaning(re.sub('\<.*?\>', '', subtext[0])) if subtext and desc else None
					if firstTI !="" and subtitle and subtitle not in firstTI and any(x in firstUL for x in Supported):
						title = firstTI+' - '+subtitle
					COMBI_OUTPUT.append([int(num), title, photo, mp3, duration, plot])
			elif course == 'VIDEOS':
				content = getUrl(elem)
				spl = content.split('<article class="article__details">')
				for i in range(1, len(spl), 1):
					item = spl[i]
					desc1 = re.compile('<p[^>]*>(.*?)</p>', re.S).findall(item)[0][:-6]
					desc1 = re.sub('\<.*?\>', '', desc1)
					desc2 = re.compile('<p[^>]*>(.*?)</p>', re.S).findall(item)[2]
					desc2 = re.sub('\<.*?\>', '', desc2)
					matching = re.search(r'\b(\d{2})\.(\d{2})\.(\d{4})\b', desc1)
					dt = matching.group() if matching else 'NDF'
					plot = '[COLOR yellow]'+cleaning(desc1)+'[/COLOR][CR][CR]'+cleaning(desc2)
					video = re.compile(r'<iframe.+?src=["\']([^"]+?)["\'] (?:width|frameborder)', re.S).findall(item)[0].replace('&amp;', '&').replace('%3A', ':').replace('%2F', '/')
					if not 'youtube' in video.lower():
						thirdRE = getUrl(video)
						photo = re.compile('<img class=["\']_1p6f _3fnw img["\'] src=["\']([^"]+?)["\']', re.S).findall(thirdRE)[0].replace('&amp;', '&')
						try: vidURL = re.compile('"hd_src":"([^"]+)",', re.S).findall(thirdRE)[0].replace('\/', '/').replace('\u00253F', '%3F').replace('\u00253D', '%3D').replace('\u00257E', '%7E').replace('\u00252A', '%2A')
						except:
							try: vidURL = re.compile('"sd_src":([^"]+)",', re.S).findall(thirdRE)[0].replace('\/', '/').replace('\u00253F', '%3F').replace('\u00253D', '%3D').replace('\u00257E', '%7E').replace('\u00252A', '%2A')
							except: vidURL = None
						TYPE = 'standard'
					else:
						photo = re.compile('<div class=["\']card-image["\']><img alt=.*?src=["\']([^"]+?)["\']', re.S).findall(item)[0]
						photo = BASE_URL+'/files/'+photo.split('source=')[1].split('&amp;')[0]
						vidURL = video.split('/')[-1]
						TYPE = 'YTstream'
					COMBI_OUTPUT.append([int(num), dt, vidURL, photo, plot, TYPE])
		except:
			stopping()
			if enableWARNINGS:
				dialog.notification(translation(30521).format(course), translation(30523), icon, 10000)
			failing("(navigator.listSubstances) ERROR - ERROR - ERROR : {0} || {1}".format(course, traceback.format_exc()))

def stopping():
	pill2kill.set()

def getMultiData(simultan, event='FEEDS'):
	debug_MS("(navigator.getMultiData) ------------------------------------------------ START = getMultiData -----------------------------------------------")
	threads = []
	debug_MS("(navigator.getMultiData) ganze LISTE XXXXX {0} XXXXX".format(' || '.join(simultan)))
	for article in simultan:
		th = threading.Thread(target=listSubstances, args=[article, pill2kill, event])
		if hasattr(th, 'daemon'): th.daemon = True
		else: th.setDaemon()
		threads.append(th)
	[th.start() for th in threads]
	threading.Timer(25, after_timeout, [threads, pill2kill]).start()
	[th.join(3) for th in threads]
	if COMBI_OUTPUT:
		debug_MS("+++++++++++++++++++++++++")
		debug_MS("(navigator.listSubstances) Ergebnis XXXXX COMBI_OUTPUT = {0} XXXXX".format(str(COMBI_OUTPUT)))
	return COMBI_OUTPUT

def after_timeout(threads, pill2kill):
	counter = 0
	for th in threads:
		if th.is_alive() and counter == 0:
			counter += 1
			failing("(navigator.getMultiData) ##### TIMEOUT FOR RUNNING THREADS IS REACHED - KILLING THEM ALL !!! #####")
			stopping()
	return

def playVideo(url, TYPE):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL = {0} ### TYPE = {1} ###".format(url, TYPE))
	action = TYPE.split('@@')[0] if '@@' in TYPE else TYPE
	log("(navigator.playVideo) StreamURL : {0} || TYPE : {1}".format(url, action))
	if xbmc.Player().isPlaying():
		xbmc.Player().stop()
	if action == 'DIRECTstream':
		field = TYPE.split('@@')
		listitem = xbmcgui.ListItem(field[1])
		listitem.setArt({'icon': field[2], 'thumb': field[2], 'poster': field[2], 'fanart': defaultFanart})
		xbmc.Player().play(item=url, listitem=listitem)
	else:
		listitem = xbmcgui.ListItem(path=url)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)

def addDir(name, image, params={}, plot=None, folder=True):
	exclusion = ('podcast.jpg', 'radio.jpg', 'video.jpg')
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and (not artpic in image or image.endswith(exclusion)):
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None, rating=None, votes=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Duration': duration, 'Rating': rating, 'Votes': votes})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	if not 'DIRECTstream' in params.get('extras'):
		liz.setProperty('IsPlayable', 'true')
		liz.setContentLookup(False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
