﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
from collections import OrderedDict
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote  # Python 2.X
else:
	from urllib.parse import urlencode, quote  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	counter = 0
	newURL = BASE_API+'assets/next_live?access_token=true&page=1&per_page='+MAX_VIDS
	try:
		content = getUrl(newURL)
		DATA = json.loads(content, object_pairs_hook=OrderedDict)
		for item in DATA['items']:
			if 'duration' in item and item['duration'] == 'LIVE':
				if ('contents_freely_accessible' in item and item['contents_freely_accessible'] == True) or (not 'contents_freely_accessible' in item):
					counter += 1
	except: pass
	if counter > 0:
		addDir(translation(30601).format(str(counter)), artpic+'livestream.png', {'mode': 'listVideos', 'url': BASE_API+'assets/next_live?access_token=true', 'extras': 'allowed'})
	addDir(translation(30602), icon, {'mode': 'listVideos', 'url': BASE_API+'assets/next_live?access_token=true', 'extras': 'undesired'})
	addDir(translation(30603), icon, {'mode': 'listVideos', 'url': BASE_API+'assets?access_token=true', 'extras': 'undesired'})
	addDir(translation(30604), icon, {'mode': 'listVideos', 'url': BASE_API+'sections/5a51bcb03e990137757d7054d2ab776f/assets?access_token=true', 'extras': 'undesired'})
	addDir(translation(30605), icon, {'mode': 'listVideos', 'url': BASE_API+'sections/4c7be7c03e990137757c7054d2ab776f/assets?access_token=true', 'extras': 'undesired'})
	addDir(translation(30606), icon, {'mode': 'listVideos', 'url': BASE_API+'sections/493581c0154c013683077054d2ab776f/assets?access_token=true', 'extras': 'undesired'})
	addDir(translation(30607), icon, {'mode': 'listSports', 'url': BASE_API+'sections?access_token=true', 'extras': 'allowed'})
	addDir(translation(30608), icon, {'mode': 'listSports', 'url': BASE_API+'playlists?access_token=true', 'extras': 'allowed'})
	addDir(translation(30609), artpic+'basesearch.png', {'mode': 'SearchSDTV'})
	if enableADJUSTMENT:
		addDir(translation(30610), artpic+'settings.png', {'mode': 'aSettings'})
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30611), artpic+'settings.png', {'mode': 'iSettings'})
		else:
			addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSports(url, PAGE):
	debug_MS("(navigator.listSports) -------------------------------------------------- START = listSports --------------------------------------------------")
	debug_MS("(navigator.listSports) ### URL : {0} ### PAGE : {1} ###".format(url, PAGE))
	counter = 0
	startURL = url+'&page='+PAGE+'&per_page='+MAX_CATS
	content = getUrl(startURL)
	DATA = json.loads(content, object_pairs_hook=OrderedDict)
	DATA = sorted(DATA['items'], key = lambda k: (k.get('title', '') or k.get('label', '')), reverse=False)
	for item in DATA:
		counter += 1
		title = (item.get('title', '') or item.get('label', ''))
		title = cleaning(title)
		if 'opener' in title.lower() or 'playlist' in title.lower(): continue
		uuid = str(item['uuid'])
		if 'playlists?' in url:
			newURL = BASE_API+'playlists/'+uuid+'?access_token=true'
		else: newURL = BASE_API+'sections/'+uuid+'/assets?access_token=true'
		plot = (cleaning(item.get('seo_description', '')) or "")
		photo = (item.get('image', '') or icon)
		debug_MS("(navigator.listSports) ##### TITLE = {0} || LINK = {1} || IMAGE = {2} #####".format(str(title), newURL, photo))
		addDir(title, photo, {'mode': 'listVideos', 'url': newURL, 'extras': 'allowed', 'background': 'KEIN HINTERGRUND'}, plot)
	if counter > 398:
		try: # NEXTPAGE 
			debug_MS("(navigator.listVideos) Now show NextPage ...")
			addDir(translation(30624), artpic+'nextpage.png', {'mode': 'listSports', 'url': url, 'page': int(PAGE)+1})
		except: pass
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchSDTV():
	debug_MS("(navigator.SearchSDTV) ------------------------------------------------ START = SearchSDTV -----------------------------------------------")
	word = None
	word = dialog.input("Suche auf Sportdeutschland ...", type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
	if not word: return
	newURL = BASE_API+'search?access_token=true&q='+quote(word)
	return listVideos(newURL, '1', 'allowed')

def listVideos(url, PAGE, SCENE):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS("(navigator.listVideos) ### URL : {0} ### PAGE : {1} ### showLIVE : {2} ###".format(url, PAGE, SCENE))
	FOUND = 0
	counter = 0
	uno_LIST = []
	startURL = url+'&page='+PAGE+'&per_page='+MAX_VIDS
	content = getUrl(startURL)
	DATA = json.loads(content, object_pairs_hook=OrderedDict)
	if 'next_live?' in url:
		DATA = sorted(DATA['items'], key=lambda k:k.get('live_at', k.get('published_at', '')))
	elif 'playlists/' in url:
		DATA = DATA['assets']
	else: DATA = DATA['items']
	for each in DATA:
		debug_MS("(navigator.listVideos) no.01 ##### ENTRY = {0} #####".format(str(each)))
		photos, videos, plot, genre, Note_1, Note_2, Note_3, Note_4, image = ("" for _ in range(9))
		PUBLISHED, startCOMPLETE, startDATE, startTIME, CITY, TEASER = (None for _ in range(6))
		imgLIST, vidLIST = ([] for _ in range(2))
		duration = 0
		counter += 1
		UUID = str(each['uuid'])
		title = (each.get('title', '') or each.get('label', ''))
		title = cleaning(title)
		PUBLISHED = (each.get('live_at', '') or each.get('published_at', ''))
		if PUBLISHED and PUBLISHED[:10].replace('.', '').replace('-', '').replace('/', '').isdigit():
			LOCALstart = utc_to_local(datetime(*(time.strptime(PUBLISHED[:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))) # 2019-08-11T07:00:00Z
			startCOMPLETE = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			startDATE = LOCALstart.strftime('%d{0}%m{0}%Y').format('.')
			startTIME = LOCALstart.strftime('%H{0}%M').format(':')
		name = startDATE+" - "+title if startDATE and not '1970' in startDATE else title
		if 'images' in each and len(each['images']) > 0:
			try: imgLIST = [img.get('url', []).replace('_1024x576.jpg', '.jpg', 1) for img in each.get('images', '')]
			except: pass
			if imgLIST: photos = '@@'.join(imgLIST)
		if 'contents_freely_accessible' in each and each['contents_freely_accessible'] == False:
			continue
		if each.get('duration', '') == 'LIVE' and SCENE == 'undesired':
			debug_MS("(navigator.listVideos) ~~~~~ ES WURDE EIN LIVESTREAM GEFUNDEN - JETZT GEHTS WEITER ~~~~~")
			continue
		elif each.get('duration', '') != 'LIVE' and SCENE == 'allowed' and 'next_live?' in url:
			continue
		if 'videos' in each and len(each['videos']) > 0:
			vidLIST = [vid.get('url', []).replace('.smil', '.m3u8', 1) for vid in each.get('videos', '')]
			if vidLIST:
				videos = '@@'.join(vidLIST)
				if startTIME and each.get('duration', '') == 'LIVE':
					name = translation(30620).format(startTIME, title)
			for item in each['videos']:
				if each.get('duration', '') != 'LIVE' and str(item.get('duration', '')).replace('.', '').replace('-', '').isdigit():
					duration = int(duration)+int(item.get('duration', '0') or '0')
					duration = "{0:.0f}".format(duration)
		if 'tags' in each and len(each['tags']) > 0:
			for elem in each['tags']:
				if elem.get('label') == 'Sportart' and len(elem.get('values')) > 0:
					genre = cleaning(elem['values'][0])
				if elem.get('label') == 'Wettbewerb, Event' and len(elem.get('values')) > 0:
					Note_1 = cleaning(elem['values'][0])
				if elem.get('label') == 'Stadt' and len(elem.get('values')) > 0:
					CITY = cleaning(elem['values'][0])
				elif elem.get('label') == 'Austragungsort' and len(elem.get('values')) > 0:
					CITY = cleaning(elem['values'][0])
			if CITY: Note_2 = '  ('+cleaning(CITY)+')[CR]'
			if Note_1 != "" and Note_2 == "": Note_2 = '[CR]'
		if startCOMPLETE and len(vidLIST) in [0, 1]:
			Note_3 = translation(30621).format(str(startCOMPLETE))
		elif startCOMPLETE and len(vidLIST) > 1:
			Note_3 = translation(30622).format(str(startCOMPLETE), str(len(vidLIST)))
		elif not startCOMPLETE and len(vidLIST) > 1:
			Note_3 = translation(30623).format(str(len(vidLIST)))
		else: Note_3 = '[CR]'
		TEASER = (each.get('body', '') or each.get('teaser', ''))
		if TEASER: Note_4 = cleaning(TEASER)
		plot = Note_1+Note_2+Note_3+Note_4
		if imgLIST: image = imgLIST[0]
		if vidLIST or 'next_live?' in url or 'search?' in url:
			FOUND += 1
			if not vidLIST:
				UUID = 'nothing'+UUID
			if ((vidLIST and SCENE == 'allowed' and 'next_live?' in url) or (not vidLIST)) and startCOMPLETE:
				if LOCALstart > datetime.now():
					name = startCOMPLETE+" - "+title
			EP_entry = UUID+'###'+str(videos)+'###'+str(title)+'###'+str(name)+'###'+str(photos)+'###'+str(plot.replace('\n', '#n#').strip())+'###'+str(genre)+'###'+str(duration)+'###'
			if EP_entry not in uno_LIST:
				uno_LIST.append(EP_entry)
			listitem = xbmcgui.ListItem(name, path=HOST_AND_PATH+'?IDENTiTY='+UUID+'&mode=playCODE')
			info = {}
			info['Tvshowtitle'] = None
			info['Title'] = name
			info['Tagline'] = None
			info['Plot'] = plot
			info['Duration'] = duration
			info['Year'] = None
			info['Genre'] = genre
			info['Studio'] = 'Sportdeutschland.tv'
			info['Mpaa'] = None
			info['Mediatype'] = 'video'
			listitem.setInfo(type='Video', infoLabels=info)
			listitem.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
			if image != icon and not artpic in image:
				listitem.setArt({'fanart': image})
			listitem.addStreamInfo('Video', {'Duration':duration})
			listitem.setProperty('IsPlayable', 'true')
			listitem.setContentLookup(False)
			listitem.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+UUID+'&mode=playCODE', listitem=listitem)
	with open(WORKFILE, 'w') as input:
		input.write('\n'.join(uno_LIST))
	if not 'next_live?' in url and not 'playlists/' in url and FOUND > 0 and counter > 99:
		try: # NEXTPAGE 
			debug_MS("(navigator.listVideos) Now show NextPage ...")
			addDir(translation(30624), artpic+'nextpage.png', {'mode': 'listVideos', 'url': url, 'page': int(PAGE)+1, 'extras': SCENE})
		except: pass
	elif FOUND == 0:
		return dialog.notification(translation(30522).format('Einträge'), translation(30524), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS("(navigator.playCODE) ### IDD : {0} ###".format(str(IDD)))
	pos_LISTE = 0
	Special = False
	endURL = False
	photoURL = False
	PL = xbmc.PlayList(1)
	with open(WORKFILE, 'r') as output:
		lines = output.readlines()
		for line in lines:
			field = line.split('###')
			if field[0]==IDD:
				endURL = field[1]
				title = field[2]
				try: title = title.split('[/COLOR]')[1].strip()
				except: pass
				name = field[3]
				image = field[4]
				if '@@' in image:
					photoURL = image.split('@@')
				plot = field[5].replace('#n#', '\n').strip()
				genre = field[6]
				duration = field[7]
				if '@@' in endURL:
					Special = True
					videoURL = endURL.split('@@')
					complete = '/'+str(len(videoURL))
					for single in videoURL:
						log("(navigator.playCODE) PlaylistURL : {0} ".format(str(single)))
						pos_LISTE += 1
						NRS_title = translation(30625).format(name, str(pos_LISTE)+complete)
						try: SNAP_Shot = str(photoURL[pos_LISTE]) if photoURL else image
						except: SNAP_Shot = image
						listitem = xbmcgui.ListItem(name)
						listitem.setInfo(type='Video', infoLabels={'Title': NRS_title, 'Plot': plot, 'Duration': duration, 'Studio': 'Sportdeutschland.tv', 'Genre': genre, 'mediatype': 'video'})
						listitem.setArt({'icon': icon, 'thumb': SNAP_Shot, 'poster': SNAP_Shot})
						xbmc.sleep(50)
						PL.add(url=single, listitem=listitem, index=pos_LISTE)
				else:
					SNAP_Shot = str(photoURL[0]) if photoURL else image
					log("(navigator.playCODE) StreamURL : {0} ".format(str(endURL)))
					listitem = xbmcgui.ListItem(path=endURL)
					listitem.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Duration': duration, 'Studio': 'Sportdeutschland.tv', 'Genre': genre, 'mediatype': 'video'})
					listitem.setArt({'icon': icon, 'thumb': SNAP_Shot, 'poster': SNAP_Shot})
					if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'm3u8' in endURL:
						listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
						listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
						listitem.setMimeType('application/vnd.apple.mpegurl')
	if endURL and Special:
		return PL
	elif endURL and not Special:
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playCODE) AbspielLink-00 : *SPORTDEUTSCHLAND* Der angeforderte -VideoLink- wurde NICHT gefunden !!!")
		return dialog.notification(translation(30521).format('Video'), translation(30526), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'Sportdeutschland.tv'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image != icon and not artpic in image and params.get('background') != 'KEIN HINTERGRUND':
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
