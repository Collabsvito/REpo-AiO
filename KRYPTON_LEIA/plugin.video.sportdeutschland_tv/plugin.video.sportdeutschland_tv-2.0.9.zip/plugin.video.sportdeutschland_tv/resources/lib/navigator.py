﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else:
	from urllib.parse import urlencode, quote  # Python 3.X
	from urllib.request import urlopen  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	counter = 0
	DATA = getUrl(API_BASE+'upcoming-live-assets')
	if DATA and len(DATA) > 0:
		for item in DATA:
			if item.get('currently_live', '') is True:
				payContent = [euro for euro in item.get('monetizations', '')]
				if not str(item.get('price_in_cents', '')).isdigit() and len(payContent) == 0:
					counter += 1
	if counter > 0:
		addDir(translation(30601).format(str(counter)), artpic+'livestream.png', {'mode': 'listVideos', 'url': API_BASE+'upcoming-live-assets?', 'limit': '50', 'wanted': '2', 'extras': 'allowed'})
	addDir(translation(30602), icon, {'mode': 'listVideos', 'url': API_BASE+'upcoming-live-assets?', 'limit': '50', 'wanted': '2', 'extras': 'undesired'})
	addDir(translation(30603), artpic+'favourites.png', {'mode': 'listShowsFavs'})
	addDir(translation(30604), icon, {'mode': 'listVideos', 'url': API_BASE+'home/top-assets?', 'limit': '10', 'wanted': '11', 'extras': 'undesired'})
	addDir(translation(30605), icon, {'mode': 'listVideos', 'url': API_BASE+'tags/badminton/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30606), icon, {'mode': 'listVideos', 'url': API_BASE+'tags/basketball/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30607), icon, {'mode': 'listVideos', 'url': API_BASE+'tags/eishockey/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30608), icon, {'mode': 'listVideos', 'url': API_BASE+'tags/handball/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30609), icon, {'mode': 'listVideos', 'url': API_BASE+'tags/leichtathletik/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30610), icon, {'mode': 'listVideos', 'url': API_BASE+'tags/tischtennis/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30611), icon, {'mode': 'listVideos', 'url': API_BASE+'tags/turnen/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30612), icon, {'mode': 'listSports', 'url': API_BASE+'home/tags?', 'limit': '10', 'wanted': '34', 'extras': 'allowed'})
	addDir(translation(30613), icon, {'mode': 'listSports', 'url': API_SEARCH+'profiles/popular?', 'limit': '10', 'wanted': '56', 'extras': 'allowed'})
	addDir(translation(30614), artpic+'basesearch.png', {'mode': 'SearchSDTV', 'extras': 'TEAMS'})
	addDir(translation(30615), artpic+'basesearch.png', {'mode': 'SearchSDTV', 'extras': 'VIDEOS'})
	if enableADJUSTMENT:
		addDir(translation(30616), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30617), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def listSports(url, PAGE, LIMIT, WANTED):
	debug_MS("(navigator.listSports) -------------------------------------------------- START = listSports --------------------------------------------------")
	PAGE, MAXIMUM = int(PAGE), int(PAGE) + int(WANTED)-1
	debug_MS("(navigator.listSports) ### URL : {0} ### PAGE : {1} ### LIMIT : {2} ### maxPAGES : {3} ###".format(url, str(PAGE), LIMIT, str(MAXIMUM)))
	COMBI_CATS = []
	UNIKAT = set()
	while PAGE < MAXIMUM:
		newURL = '{0}page={1}&per_page={2}'.format(url, str(PAGE), LIMIT)
		debug_MS("(navigator.listSports) newURL : {0}".format(str(newURL)))
		DATA = getUrl(newURL)
		debug_MS("++++++++++++++++++++++++")
		debug_MS("(navigator.listSports) XXXXX CONTENT : {0} XXXXX".format(str(DATA)))
		debug_MS("++++++++++++++++++++++++")
		if 'data' in DATA and len(DATA['data']) > 0:
			PAGE += 1
		else:
			PAGE += MAXIMUM
		for item in DATA['data']:
			genre, Note_1, Note_3, plot = ("" for _ in range(4))
			Note_2 = '[CR]'
			SPID = (item.get('id', '0') or '0')
			if SPID == '0' or SPID in UNIKAT:
				continue
			UNIKAT.add(SPID)
			title = cleaning(item['name'])
			SLUG = item['slug']
			if 'home/' in url:
				newURL = API_BASE+'tags/'+SLUG+'/assets?'
				newLIMIT, newWANTED, Note_1 = '20', '4', translation(30630)
			else: 
				newURL = API_BASE+'profiles/'+SLUG+'/assets?'
				newLIMIT, newWANTED, Note_1 = '18', '4', translation(30631)
			if item.get('sport_type', '') and item.get('sport_type', {}).get('name', ''):
				genre = cleaning(item['sport_type']['name'])
				Note_2 = translation(30632).format(cleaning(item['sport_type']['name']))
			Note_3 = (cleaning(item.get('description', '')) or "")
			plot = Note_1+Note_2+Note_3
			imgID = (item.get('image_url', None) or None)
			if imgID is None and item.get('assets_top_20', '') and len(item.get('assets_top_20', '')) > 0:
				imgID = (item.get('assets_top_20', {})[0].get('image_url', None) or None)
			photo = IMG_assets.format(imgID) if imgID else icon
			COMBI_CATS.append([title, SPID, newURL, newLIMIT, newWANTED, photo, plot])
	if COMBI_CATS:
		for title, SPID, newURL, newLIMIT, newWANTED, photo, plot in sorted(COMBI_CATS):
			if ('profiles' in url and (title[0].isupper() or title[0].isdigit())) or ('home/' in url and len(title) > 5):
				debug_MS("(navigator.listSports) ##### TITLE = {0} || LINK = {1} || IMAGE = {2} #####".format(str(title), newURL, photo))
				addType = 1
				if xbmcvfs.exists(channelFavsFile):
					with open(channelFavsFile, 'r') as fp:
						watch = json.load(fp)
						for item in watch.get('items', []):
							if item.get('url') == newURL: addType = 2
				addDir(title, photo, {'mode': 'listVideos', 'url': newURL, 'limit': newLIMIT, 'wanted': newWANTED, 'extras': 'undesired'}, plot, genre, addType, background=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchSDTV(CAT):
	debug_MS("(navigator.SearchSDTV) ------------------------------------------------ START = SearchSDTV -----------------------------------------------")
	keyword = None
	if xbmcvfs.exists(searchHackFile):
		with open(searchHackFile, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30633).format(CAT), type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
		if keyword:
			keyword = quote(keyword)
			with open(searchHackFile, 'w') as record:
				record.write(keyword)
	if keyword:
		if CAT == 'TEAMS': return listSports(API_SEARCH+'search/profiles?q='+keyword+'&', page, '10', '31')
		elif CAT == 'VIDEOS': return listVideos(API_SEARCH+'search/assets?q='+keyword+'&', page, '10', position, excluded, '11', 'undesired')
	return None

def listVideos(url, PAGE, LIMIT, POS, FILTER, WANTED, SCENE):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	counterTWO, disqualifiedTWO, PAGE, MAXIMUM = int(POS), int(FILTER), int(PAGE), int(PAGE) + int(WANTED)-1
	counterONE, disqualifiedONE, number = (0 for _ in range(3))
	debug_MS("(navigator.listVideos) ### URL : {0} ### PAGE : {1} ### LIMIT : {2} ### POSITION : {3} ### EXCLUDED : {4} ### maxPAGES : {5} ### showLIVE : {6} ###".format(url, str(PAGE), LIMIT, str(counterTWO), str(disqualifiedTWO), str(MAXIMUM), SCENE))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_THIRD = ([] for _ in range(4))
	UNIKAT = set()
	while PAGE < MAXIMUM:
		newURL = '{0}page={1}&per_page={2}'.format(url, str(PAGE), LIMIT)
		debug_MS("(navigator.listVideos) newURL : {0}".format(str(newURL)))
		DATA_ONE = getUrl(newURL)
		debug_MS("++++++++++++++++++++++++")
		debug_MS("(navigator.listVideos) XXXXX CONTENT : {0} XXXXX".format(str(DATA_ONE)))
		debug_MS("++++++++++++++++++++++++")
		if ('data' in DATA_ONE and len(DATA_ONE['data']) > 0) or ('assets' in DATA_ONE and len(DATA_ONE['assets']) > 0) or (DATA_ONE and 'upcoming-live-assets' in url):
			elements = DATA_ONE['data'] if ('data' in DATA_ONE and len(DATA_ONE['data']) > 0) else DATA_ONE['assets'] if ('assets' in DATA_ONE and len(DATA_ONE['assets']) > 0) else DATA_ONE
			PAGE += 1
		else:
			elements = ""
			PAGE += MAXIMUM
		for each in elements:
			debug_MS("(navigator.listVideos) no.01 xxxxx EACH-01 : {0} xxxxx".format(str(each)))
			GENRE_1, NOTE_1, NOTE_2, DESC_1 = ("" for _ in range(4))
			startCOMPLETE, startSORTING_1, startDATE, AIRED_1, startTIME, slugONE, TEASER = (None for _ in range(7))
			counterONE += 1
			counterTWO += 1
			episID_1 = (each.get('id', '0') or '0')
			if episID_1 == '0' or episID_1 in UNIKAT:
				disqualifiedONE += 1
				disqualifiedTWO += 1
				continue
			UNIKAT.add(episID_1)
			TITLE_1 = cleaning(each['name'])
			PUBLISHED = (each.get('content_start_date', None) or None)
			if PUBLISHED and PUBLISHED[:10].replace('.', '').replace('-', '').replace('/', '').isdigit():
				LOCALstart = get_Local_DT(PUBLISHED[:19])
				startCOMPLETE = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				startSORTING_1 = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('.', ':')
				startDATE, AIRED_1 = LOCALstart.strftime('%d{0}%m{0}%Y').format('.'), LOCALstart.strftime('%d{0}%m{0}%Y').format('.')
				startTIME = LOCALstart.strftime('%H{0}%M').format(':')
			imgID = (each.get('image_url', '') or '')
			THUMB_1 = IMG_assets.format(imgID)
			payCONTENT = [euro for euro in each.get('monetizations', '')]
			if str(each.get('price_in_cents', '')).isdigit() or len(payCONTENT) > 0:
				disqualifiedONE += 1
				disqualifiedTWO += 1
				continue
			if (each.get('currently_live', '') is True and SCENE == 'undesired') or (each.get('currently_live', '') is False and SCENE == 'allowed'):
				disqualifiedONE += 1
				disqualifiedTWO += 1
				continue
			VIDEO_1 = (each.get('video_url', None) or None)
			NAME_1 = startDATE+" - "+TITLE_1 if startDATE and not '1970' in startDATE else TITLE_1
			if startTIME and each.get('currently_live', '') is True:
				NAME_1 = translation(30634).format(startTIME, TITLE_1)
			if SCENE == 'undesired' and startCOMPLETE:
				if LOCALstart > datetime.now():
					NAME_1 = startCOMPLETE+" - "+TITLE_1
			DURATION_1 = "{0:.0f}".format(each.get('video_duration')) if str(each.get('video_duration')).isdigit() else 0
			if each.get('profile', ''):
				if each.get('profile', {}).get('sport_type', '') and each.get('profile', []).get('sport_type', {}).get('name', ''):
					GENRE_1 = cleaning(each['profile']['sport_type']['name'])
				if each.get('profile', {}).get('name', ''):
					NOTE_1 = cleaning(each['profile']['name'])+'[CR]'
				if each.get('profile', {}).get('slug', ''):
					slugONE = each['profile']['slug']+'/'
			slugTWO = (each.get('slug', None) or None)
			NOTE_2 = translation(30635).format(str(startCOMPLETE)) if startCOMPLETE else '[CR]'
			TEASER = (each.get('description', '') or each.get('teaser', ''))
			if TEASER: DESC_1 = cleaning(TEASER, True).replace('\n', '[CR]')
			number += 1
			COMBI_FIRST.append([int(number), episID_1, TITLE_1, NAME_1, startSORTING_1, VIDEO_1, THUMB_1, DURATION_1, GENRE_1, AIRED_1, NOTE_1, NOTE_2, DESC_1])
			if slugONE and slugTWO:
				URL_TWO = API_BASE+'assets/'+slugONE+slugTWO
				COMBI_LINKS.append([int(number), URL_TWO])
	if COMBI_FIRST:
		COMBI_SECOND = getMultiData(COMBI_LINKS)
		if COMBI_SECOND:
			DATA_TWO = json.loads(COMBI_SECOND)
			#log("++++++++++++++++++++++++")
			#log("(navigator.listVideos) no.02 XXXXX CONTENT-02 : {0} XXXXX".format(str(DATA_TWO)))
			#log("++++++++++++++++++++++++")
			for elem in DATA_TWO:
				if elem is not None and ((elem.get('videos', '') and len(elem.get('videos')) > 0) or (elem.get('livestream', '') and elem.get('livestream', {}).get('src', ''))):
					DESC_2 = ""
					DURATION_2 = 0
					debug_MS("(navigator.listVideos) no.02 xxxxx ELEM-02 : {0} xxxxx".format(str(elem)))
					markID_2 = (elem.get('uuid', '') or elem.get('id', ''))
					if elem.get('videos', '') and len(elem.get('videos')) > 0:
						VIDEO_2 = (elem.get('videos', {})[0].get('src', None) or None)
						TYPE_2 = (elem.get('videos', {})[0].get('type', None) or None)
						DURATION_2 = int(elem.get('videos', {})[0].get('duration')) if str(elem.get('videos', {})[0].get('duration')).isdigit() else 0
					elif elem.get('livestream', '') and elem.get('livestream', {}).get('src', ''):
						VIDEO_2 = (elem.get('livestream', {}).get('src', None) or None)
						TYPE_2 = (elem.get('livestream', {}).get('type', None) or None)
					TEASER = (elem.get('description', '') or elem.get('teaser', ''))
					if TEASER: DESC_2 = cleaning(TEASER, True).replace('\n', '[CR]')
					elif not TEASER and elem.get('home_team', '') and elem.get('home_team', {}).get('name', '') and elem.get('guest_team', '') and elem.get('guest_team', {}).get('name', ''):
						DESC_2 = cleaning(elem['home_team']['name'])+' vs. '+cleaning(elem['guest_team']['name'])
					COMBI_THIRD.append([markID_2, VIDEO_2, TYPE_2, DURATION_2, DESC_2])
	if COMBI_THIRD or (not COMBI_THIRD and COMBI_FIRST):
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_THIRD if a[1] == b[0]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		RESULT += [c for c in COMBI_FIRST if all(d[0] != c[1] for d in COMBI_THIRD)] # Der übriggebliebene Rest von Liste1 - wenn die ID nicht in der Liste2 vorkommt !!!
		#log("++++++++++++++++++++++++")
		#log("(navigator.listVideos) no.03 XXXXX RESULT-03 : {0} XXXXX".format(str(RESULT)))
		#log("++++++++++++++++++++++++")
		RESULT = sorted(RESULT, key=lambda d:d[4], reverse=True) if 'search/assets?' in url else sorted(RESULT, key=lambda k: int(k[0]), reverse=False)
		for da in RESULT: # 0-12 = Liste1 || 13-17 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS("(navigator.listVideos) no.03 ### Anzahl = {0} || Eintrag : {1} ###".format(str(len(da)), str(da)))
			if len(da) > 13: ### Liste2 beginnt mit Nummer:13 ###
				episID, name, startSORTING, video_1, photo, duration_1, genre, aired, Note_1, Note_2, DESC_1 = da[1], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10], da[11], da[12]
				video_2, type_2, duration_2, DESC_2 = da[14], da[15], da[16], da[17]
				COMP_DESC = da[17] if len(da[17]) > 20 else da[12]
			else:
				episID, name, startSORTING, video_1, photo, duration_1, genre, aired, Note_1, Note_2, COMP_DESC = da[1], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10], da[11], da[12]
				video_2, type_2, duration_2, DESC_2 = None, None, 0, ""
			duration = duration_2 if duration_2 != 0 else duration_1 if duration_1 != 0 else 0
			plot = Note_1+Note_2+COMP_DESC
			EXTRA = video_2 if video_2 else video_1 if video_1 else None
			TRANSFER = type_2 if type_2 else None
			debug_MS("(navigator.listVideos) no.04 ##### NAME : {0} || IDD : {1} || GENRE : {2} #####".format(name, episID, genre))
			debug_MS("(navigator.listVideos) no.04 ##### THUMB : {0} || VIDEO : {1} || TYPE : {2} #####".format(photo, str(EXTRA), str(TRANSFER)))
			addLink(name, photo, {'mode': 'playVideo', 'url': episID, 'extras': EXTRA, 'transmit': TRANSFER}, plot, duration, genre, aired)
		debug_MS("(navigator.listVideos) NUMBERING ### current_RESULT : {0} // all_RESULT : {1} ### current_EXCLUDED : {2} // all_EXCLUDED : {3} ###".format(str(counterONE), str(counterTWO), str(disqualifiedONE), str(disqualifiedTWO)))
		if 'meta' in DATA_ONE and DATA_ONE['meta'] and not (SCENE == 'allowed' and 'upcoming-live-assets' in url):
			if DATA_ONE.get('meta', {}).get('total', '') and isinstance(DATA_ONE['meta']['total'], int) and int(DATA_ONE['meta']['total']) > int(LIMIT)*int(PAGE):
				debug_MS("(navigator.listVideos) NUMBERING ### totalRESULTS : {0} ###".format(str(DATA_ONE['meta']['total'])))
				debug_MS("(navigator.listVideos) Now show NextPage ... No.{0} ... ###".format(PAGE))
				addDir(translation(30636), artpic+'nextpage.png', {'mode': 'listVideos', 'url': url, 'page': PAGE, 'limit': LIMIT, 'position': counterTWO, 'excluded': disqualifiedTWO, 'wanted': WANTED, 'extras': SCENE})
	else:
		debug_MS("(navigator.listEpisodes) ##### Keine COMBI_EPISODE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525).format('Einträge'), translation(30526), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(IDD, VIDEO, TYPE):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS("(navigator.playVideo) ### IDD : {0} ### VIDEO : {1} ### TYPE : {2} ###".format(str(IDD), str(VIDEO), str(TYPE)))
	FINAL_URL, STREAM, TEST_URL = (False for _ in range(3))
	VIDEO = None if VIDEO in ['None', 'standard'] else VIDEO
	TYPE = None if TYPE in ['None', 'standard'] else TYPE
	if VIDEO and 'vidibus.net/live' in VIDEO:
		FINAL_URL = VIDEO.replace('.smil', '.m3u8', 1)
		STREAM = 'M3U8'
	else:
		### 1. extract = "profile.slug": "tv-05-07-huettenberg", "slug": "2hbl-tv-05-07-huettenberg-vs-hsc-2000-coburg"
		### 2. getUrl = https://api.sportdeutschland.tv/api/stateless/frontend/assets/tv-05-07-huettenberg/2hbl-tv-05-07-huettenberg-vs-hsc-2000-coburg
		### 3.1. extract = videos[0]src: "https://chess.dosbnewmedia.de//mediafiles/e4dd01b062fc49018225e251a577726d.smil", videos[0]type: "smil"
		### 3.2. extract = videos[0]src: "EEEgCpavynMYqLSwWFPGHShDnEu68Tfq6TymVzmRiOA", videos[0]type: "mux_vod"
		###     oder extract = "livestream.src": null
		### 4.1. getUrl = https://api.sportdeutschland.tv/api/frontend/asset-token/958f1bc4-0bbc-4a32-b5fa-ca5f380d7d81?type=legacy
		### 4.2. getUrl = https://api.sportdeutschland.tv/api/frontend/asset-token/95fd4975-646b-48d6-b422-ebe5ce9ebc11?type=mux_vod&playback_id=EEEgCpavynMYqLSwWFPGHShDnEu68Tfq6TymVzmRiOA
		### 5. extract = token if token else ""
		### 6.1. Video = https://chess.dosbnewmedia.de//mediafiles/e4dd01b062fc49018225e251a577726d.smil?token=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJFRUVnQ3BhdnluTVlxTFN3V0ZQR0hTaERuRXU2OFRmcTZUeW1Wem1SaU9BIiwiYXVkIjoidiIsImV4cCI6MTY1MDYzMjg1NCwia2lkIjoiOXMxUG5YcGpwYlNQdldHMDJWWmoxakhNUHY5SHFqVEdJeGxlRGNiZzAwNDAyOCJ9.NAeFSuurX8aHN14Ej4jjPS0bXOu5tiV1PNR7R3Neamuaj8Gb5w8-C5K5DxOoh2om2A4UwNybAMBmXyilzdd_MY3gL1F-BBrZ15o4UiYNlQljlnjiSgzaW9VXHfmE97caNoc9PyQUiPGOVWmBEvv39fJERQaW4tIoqSzMlZX6YKJLspBkw4f9oDNZVyka8W9UeOTnHqv0vfTfNy7Y9jVemglkT4rZhm9QscOcF_dGDNpLRRsAHXci1T0g1e1uJ7wE8WduFdX1EUS7BC210GN94lojyzYjQh3QscO98GvYbm5pekZVWcJWE11kmolA3Ug-Wj9ZPz0H8Lny-2EPuV5DXQ
		### 6.2. Video = https://stream.mux.com/EEEgCpavynMYqLSwWFPGHShDnEu68Tfq6TymVzmRiOA.m3u8?token=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJFRUVnQ3BhdnluTVlxTFN3V0ZQR0hTaERuRXU2OFRmcTZUeW1Wem1SaU9BIiwiYXVkIjoidiIsImV4cCI6MTY1MDYzMjg1NCwia2lkIjoiOXMxUG5YcGpwYlNQdldHMDJWWmoxakhNUHY5SHFqVEdJeGxlRGNiZzAwNDAyOCJ9.NAeFSuurX8aHN14Ej4jjPS0bXOu5tiV1PNR7R3Neamuaj8Gb5w8-C5K5DxOoh2om2A4UwNybAMBmXyilzdd_MY3gL1F-BBrZ15o4UiYNlQljlnjiSgzaW9VXHfmE97caNoc9PyQUiPGOVWmBEvv39fJERQaW4tIoqSzMlZX6YKJLspBkw4f9oDNZVyka8W9UeOTnHqv0vfTfNy7Y9jVemglkT4rZhm9QscOcF_dGDNpLRRsAHXci1T0g1e1uJ7wE8WduFdX1EUS7BC210GN94lojyzYjQh3QscO98GvYbm5pekZVWcJWE11kmolA3Ug-Wj9ZPz0H8Lny-2EPuV5DXQ
		tokenURL = '{0}{1}?type={2}&playback_id={3}'.format(API_PLAYER, IDD, TYPE, VIDEO) if VIDEO and TYPE and TYPE.startswith('mux') else '{0}{1}?type=legacy'.format(API_PLAYER, IDD) if VIDEO and TYPE and not TYPE.startswith('mux') else None
		if tokenURL:
			tokenTRACK = getUrl(tokenURL, method='LOAD')
			staticTOKEN = re.compile('\\{"token":"(eyJ.*?)"\\}', re.S).findall(tokenTRACK)
			startURL = VIDEO.replace('.mp4', '.smil', 1) if VIDEO and VIDEO.endswith('.mp4') else 'https://stream.mux.com/'+VIDEO+'.m3u8' if VIDEO and VIDEO[:4] != 'http' else VIDEO
			endURL = '?token='+staticTOKEN[0] if staticTOKEN else ""
			debug_MS("(navigator.playVideo) XXXXX startURL+Token : {0} XXXXX".format(str(startURL+endURL)))
			if startURL and startURL.startswith('https://stream.mux.com/'):
				FINAL_URL = startURL+endURL
				STREAM = 'HLS'
			elif startURL and not startURL.startswith('https://stream.mux.com/'):
				result = getUrl(startURL+endURL, method='LOAD')
				debug_MS("(navigator.playVideo) XXXXX RESULT : {0} XXXXX".format(str(result)))
				SOURCE = re.compile('<video src="(.*?)" type=', re.S).findall(result)
				MIME = re.compile('" type="([^"]+?)"', re.S).findall(result)
				FINAL_URL = SOURCE[0] if SOURCE else False
				STREAM = 'MP4' if MIME and MIME[0] == 'video/mp4' else 'HLS' if MIME and MIME[0].startswith('application') else 'M3U8'
	if not FINAL_URL:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich #####\n ##### QUERY : {0}{1} || VIDEO : {2} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *sportdeutschland.tv* gefunden !!! ##########".format(API_PLAYER, IDD, str(VIDEO)))
		return dialog.notification(translation(30521).format('URL-1'), translation(30528), icon, 8000)
	try:
		codeVID = urlopen(FINAL_URL, timeout=6).getcode()
		if str(codeVID) == '200': TEST_URL = True
	except: pass
	if FINAL_URL and STREAM and TEST_URL:
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		if enableINPUTSTREAM and STREAM in ['HLS', 'M3U8'] and ADDON_operate('inputstream.adaptive'):
			LSM.setMimeType('application/vnd.apple.mpegurl')
			LSM.setProperty(INPUT_APP, 'inputstream.adaptive')
			LSM.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log("(navigator.playVideo) {0}_stream : {1}".format(STREAM, FINAL_URL))
	else:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich #####\n ##### QUERY : {0}{1} || VIDEO : {2} #####\n ########## Die Stream-Url auf der Webseite von *sportdeutschland.tv* ist OFFLINE !!! ##########".format(API_PLAYER, IDD, str(VIDEO)))
		return dialog.notification(translation(30521).format('URL-2'), translation(30529), icon, 8000)

def listShowsFavs():
	debug_MS("(navigator.listShowsFavs) ------------------------------------------------ START = listShowsFavs -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as fp:
			watch = json.load(fp)
			for item in watch.get('items', []):
				name = cleaning(item.get('name'))
				logo = icon if item.get('pict', 'None') == 'None' else item.get('pict')
				urlFW = item.get('url').replace('api/frontend/', 'api/stateless/frontend/') if 'api/frontend/' in item.get('url') else item.get('url')
				desc = None if item.get('plot', 'None') == 'None' else cleaning(item.get('plot'))
				debug_MS("(navigator.listShowsFavs) ### NAME : {0} || URL : {1} || IMAGE : {2} ###".format(name, urlFW, logo))
				addDir(name, logo, {'mode': 'listVideos', 'url': urlFW, 'limit': item.get('limit'), 'wanted': item.get('wanted'), 'extras': item.get('extras')}, desc, FAVclear=True, background=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(*args):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'name': name, 'pict': pict, 'url': url, 'limit': limit, 'wanted': wanted, 'extras': extras, 'plot': plot})
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30530), translation(30531).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('url') != url]
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30530), translation(30532).format(name), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, genre=None, addType=0, FAVclear=False, folder=True, background=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': genre, 'Studio': 'Sportdeutschland.tv'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	entries = []
	if addType == 1 and FAVclear is False:
		entries.append([translation(30651), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'action': 'ADD', 'name': name, 'pict': 'None' if image == icon else image,\
			'url': params.get('url'), 'limit': params.get('limit'), 'wanted': params.get('wanted'), 'extras': params.get('extras'), 'plot': 'None' if plot == None else plot.replace('\n', '[CR]')}))])
	if FAVclear is True:
		entries.append([translation(30652), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'action': 'DEL', 'name': name, 'pict': image,\
			'url': params.get('url'), 'limit': params.get('limit'), 'wanted': params.get('wanted'), 'extras': params.get('extras'), 'plot': plot}))])
	liz.addContextMenuItems(entries, replaceItems=False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None, genre=None, aired=None, year=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Tvshowtitle'] = None
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Aired'] = aired
	info['Year'] = year
	info['Genre'] = [genre]
	info['Studio'] = ['Sportdeutschland.tv']
	info['Mediatype'] = 'movie'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, 'mode=AddToQueue'))])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
