﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import platform
import json
import xbmcvfs
import socket
import time
from datetime import datetime, timedelta
import requests
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus, unquote_plus  # Python 2.X
	from HTMLParser import HTMLParser  # Python 2.X
else:
	from urllib.parse import urlencode, quote_plus, unquote_plus  # Python 3.X
	from html.parser import HTMLParser  # Python 3.X
try: import StorageServer
except: from . import storageserverdummy as StorageServer
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


global debuging
socket.setdefaulttimeout(40)
HOST_AND_PATH         = sys.argv[0]
ADDON_HANDLE          = int(sys.argv[1])
dialog                              = xbmcgui.Dialog()
addon                              = xbmcaddon.Addon()
addon_id                         = addon.getAddonInfo('id')
addon_name                  = addon.getAddonInfo('name')
addon_version               = addon.getAddonInfo('version')
addonPath                      = xbmc.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                         = xbmc.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
defaultFanart                 = os.path.join(addonPath, 'fanart.jpg')
icon                                  = os.path.join(addonPath, 'icon.png')
artpic                                = os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
prefSTREAM                    = addon.getSetting('streamSelection')
prefTECHNIQUE             = addon.getSetting('play_technique')
CompleteEPISODES       = addon.getSetting('show.all_episodes') == 'true'
StreamMESSAGE             = addon.getSetting('show.stream_message') == 'true'
cachePERIOD                 = int(addon.getSetting('cache_rhythm'))
cache                                = StorageServer.StorageServer(addon_id, cachePERIOD) # (Your plugin name, Cache time in hours)
enableADJUSTMENT      = addon.getSetting('show_settings') == 'true'
DEB_LEVEL                      = (xbmc.LOGNOTICE if addon.getSetting('enableDebug') == 'true' else xbmc.LOGDEBUG)
BASE_URL                        = 'https://www.atv.at'
START_URL                      = 'https://www.atv.at/'
response                          = requests.Session()

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py2_enc(s, encoding='utf-8'):
	if PY2:
		if not isinstance(s, basestring):
			s = str(s)
		s = s.encode(encoding) if isinstance(s, unicode) else s
	return s

def py2_uni(s, encoding='utf-8'):
	if PY2 and isinstance(s, str):
		s = unicode(s, encoding)
	return s

def py3_dec(d, encoding='utf-8'):
	if not PY2 and isinstance(d, bytes):
		d = d.decode(encoding)
	return d

def translation(id):
	return py2_enc(addon.getLocalizedString(id))

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGNOTICE):
	msg = py2_enc(msg)
	return xbmc.log('[{0} v.{1}]{2}'.format(addon_id, addon_version, msg), level)

def clearCache():
	debug_MS("(clearCache) -------------------------------------------------- START = clearCache --------------------------------------------------")
	debug_MS("(clearCache) ========== Lösche jetzt den Addon-Cache ==========")
	cache.delete('%')
	xbmc.sleep(1000)
	dialog.ok(addon_id, translation(30501))

def makeREQUEST(url, REFERER='Unknown'):
	content = cache.cacheFunction(getUrl, url, 'GET', REFERER)
	return content

def build_url(query):
	return '{0}?{1}'.format(HOST_AND_PATH, urlencode(query))

def load_header(REF):
	if REF is 'Unknown':
		HEADERS = response.headers.update({'User-Agent': get_userAgent(), 'Accept-Encoding': 'gzip, identity'})
	else:
		HEADERS = response.headers.update({'User-Agent': get_userAgent(), 'Accept-Encoding': 'gzip, identity', 'Referer': REF})
	return HEADERS

def get_userAgent():
	base = 'Mozilla/5.0 {0} AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
	system = platform.system()
	# Mac OSX
	if system == 'Darwin':
		return base.format('(Macintosh; Intel Mac OS X 10_10_1)')
	# Windows
	if system == 'Windows':
		return base.format('(Windows NT 10.0; WOW64)')
	# ARM based Linux
	if platform.machine().startswith('arm'):
		return base.format('(X11; CrOS armv7l 7647.78.0)')
	# x86 Linux
	return base.format('(X11; Linux x86_64)')

def getUrl(url, method='GET', REF='Unknown', headers=None, cookies=None, allow_redirects=False, verify=False, stream=None, data=None):
	if headers is None:
		headers = load_header(REF)
	if method == 'GET':
		content = response.get(url, headers=headers, allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=30).text
		content = py2_enc(content)
	elif method == 'POST':
		content = response.post(url, headers=headers, allow_redirects=allow_redirects, verify=verify, data=data, timeout=30)
	return content

def utc_to_local(dt):
	if time.localtime().tm_isdst: return dt - timedelta(seconds=time.altzone)
	else: return dt - timedelta(seconds=time.timezone)

def cleanTEXT(s, encoding='utf-8'):
	parser = HTMLParser()
	s = s.replace("  ", " ").encode(encoding).decode(encoding)
	return parser.unescape(s)

def parameters_string_to_dict(parameters):
	paramDict = {}
	if parameters:
		paramPairs = parameters[1:].split('&')
		for paramsPair in paramPairs:
			paramSplits = paramsPair.split('=')
			if (len(paramSplits)) == 2:
				paramDict[paramSplits[0]] = paramSplits[1]
	return paramDict

params = parameters_string_to_dict(sys.argv[2])
name = unquote_plus(params.get('name', ''))
url = unquote_plus(params.get('url', ''))
mode = unquote_plus(params.get('mode', 'root'))
image = unquote_plus(params.get('image', ''))
extras = unquote_plus(params.get('extras', 'standard'))
