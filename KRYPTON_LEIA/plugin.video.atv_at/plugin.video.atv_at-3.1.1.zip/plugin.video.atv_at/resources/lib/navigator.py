﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
import _strptime
from datetime import datetime, timedelta
import threading
import traceback
from collections import OrderedDict
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, unquote  # Python 2.X
else:
	from urllib.parse import urlencode, unquote  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def USER_from_austria():
	try:
		return 'window.is_not_geo_ip_blocked = true' in getUrl('https://blocked-multiscreen.atv.cdn.tvnext.tv/detect.js')
	except:
		return False

def mainMenu():
	addDir(translation(30601), artpic+'favourites.png', {'mode': 'listShowsFavs'})
	addDir(translation(30602), icon, {'mode': 'listSeries', 'url': BASE_URL+'/mediathek/neue-folgen/'})
	addDir(translation(30603), icon, {'mode': 'listSeries', 'url': BASE_URL+'/mediathek/wien/'})
	addDir(translation(30604), icon, {'mode': 'listSeries', 'url': BASE_URL+'/mediathek/imeinsatz/'})
	addDir(translation(30605), icon, {'mode': 'listSeries', 'url': BASE_URL+'/mediathek/liebe/'})
	addDir(translation(30606), icon, {'mode': 'listSeries', 'url': BASE_URL+'/mediathek/'})
	if enableADJUSTMENT:
		addDir(translation(30607), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeries(url):
	debug_MS("(navigator.listSeries) ------------------------------------------------ START = listSeries -----------------------------------------------")
	html = getUrl(url)
	clusters = re.findall('<li class="program">(.*?)</li>', html, re.S)
	for cluster in clusters:
		if '<div class="video_indicator">' in cluster:
			url2 = re.compile('href="([^"]+?)"', re.DOTALL).findall(cluster)[0]
			img = re.compile('<img src="(.*?)teaser_image_file(.*?)" alt=', re.DOTALL).findall(cluster)
			pic1, pic2 = img[0][0], img[0][1]
			prefixes = ['https://static.atv.cdn.tvnext.tv', 'https://atv.at', 'https://www.atv.at']
			if pic1.startswith(tuple(s+'/dynamic/get_asset_resized.php' for s in prefixes)) and 'path=format_pages%252F' in pic1:
				image = BASE_URL+"/static/assets/cms/format_pages/teaser_image_file"+pic2.split('&amp;percent')[0].replace('%252F', '/')
			else:
				image = artpic+"empty.jpg"
			title = re.compile('<h3 class="program_title">([^<]+?)</h3>', re.DOTALL).findall(cluster)[0]
			title = cleaning(title)
			debug_MS("(navigator.listSeries) ### NAME = {0} || URL2 = {1} ###".format(title, url2))
			addType = 1
			if xbmcvfs.exists(channelFavsFile):
				with open(channelFavsFile, 'r') as fp:
					watch = json.load(fp)
					for item in watch.get('items', []):
						if item.get('url') == url2: addType = 2
			addDir(title, image, {'mode': 'listCluster', 'url': url2, 'extras': image}, addType=addType)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listCluster(url, photo):
	url = url if url[:4] == "http" else BASE_URL+url
	html = getUrl(url)
	if not listSeasons(html, photo):
		listVideos(html, origSERIE, origDESC)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(html, photo):
	debug_MS("(navigator.listSeasons) ------------------------------------------------ START = listSeasons -----------------------------------------------")
	season_SELECTOR = re.search('<select class="select jsb_ jsb_Select" data-jsb=(.*?)</select>', html, re.S)
	if season_SELECTOR:
		plot = ""
		matchDESC = re.search('<h2 class="title">(.*?)<div class="mod_teasers four all_rows jsb_ jsb_ExpandableTeaser"', html, re.S)
		if matchDESC and '<p>' in matchDESC.group(1):
			desc = cleanSUB(matchDESC.group(1))
			plot = "[B]"+cleaning(re.sub('\<.*?\>', '', desc.split('</h2>')[0])).upper()+'[/B]'+cleaning(re.sub('\<.*?\>', '', desc.split('</h2>')[1].split('</div>')[0]))
		all_SEASONS = re.findall('<option.*?value="(.*?)">(.*?)</option>', season_SELECTOR.group(1), re.S)
		for url2, title in all_SEASONS:
			title = cleaning(title)
			seriesname = title if not 'staffel' in title.lower() else ""
			debug_MS("(navigator.listSeasons) ### NAME = {0} || URL2 = {1} ###".format(title, url2))
			addDir(title, photo, {'mode': 'listEpisodes', 'url': url2, 'origSERIE': seriesname}, plot)
		return True
	else:
		debug_MS("(navigator.listSeasons) season_SELECTOR ##### - KEINE STAFFELN GEFUNDEN - GEHE WEITER ZU EPISODEN - #####")
		return False

def listEpisodes(url, seriesname, plot):
	url = url if url[:4] == "http" else BASE_URL+url
	html = getUrl(url)
	listVideos(html, seriesname, plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(html, seriesname, plot):
	debug_MS("(navigator.listVideos) ------------------------------------------------ START = listVideos -----------------------------------------------")
	Isolated_EINS = set()
	Isolated_ZWEI = set()
	COMBI_FIRST, COMBI_SECOND = ([] for _ in range(2))
	count = 0
	RESULTS = re.findall('<li class="teaser">(.*?)</li>', html, re.S)
	matchSHOW = re.search('<h3 class="title uppercase one_line">.+?">(.*?)</a></h3>', html, re.S)
	if matchSHOW:
		seriesname = cleaning(matchSHOW.group(1))
	matchDESC = re.search('<h2 class="title">(.*?)<div class="mod_teasers four all_rows jsb_ jsb_ExpandableTeaser"', html, re.S)
	if matchDESC and '<p>' in matchDESC.group(1):
		desc = cleanSUB(matchDESC.group(1))
		plot = "[B]"+cleaning(re.sub('\<.*?\>', '', desc.split('</h2>')[0])).upper()+'[/B]'+cleaning(re.sub('\<.*?\>', '', desc.split('</h2>')[1].split('</div>')[0]))
	seriesID = "##### - ALLE EPISODEN AUF EINER SEITE - NICHT EINGESCHALTET - #####"
	if CompleteEPISODES:
		pageID_1 = re.search('<div class="more jsb_ jsb_MoreTeasersButton" data-jsb="([^"]+?)"', html, re.S)
		if pageID_1:
			seriesID = re.findall('(\d+)', unquote(pageID_1.group(1)))[0]
		else:
			pageID_2 = re.search('<section id="pi_(\d+)" ><!-- mod_teasers -->', html, re.S)
			if pageID_2:
				seriesID = pageID_2.group(1)
			else: seriesID = "##### ES WURDE KEINE ~seriesID~ AUF DER SEITE GEFUNDEN ! #####"
	debug_MS("(navigator.listVideos[0]) seriesID : {0}".format(str(seriesID)))
	if not "#####" in seriesID:
		for i in range(19):
			url2 = BASE_URL+"/uri/fepe/"+seriesID+"/?page="+str(int(i)+1)
			COMBI_FIRST.append(str(int(i)+1)+'@@'+url2)
		if COMBI_FIRST:
			COMBI_SECOND = getMultiData(COMBI_FIRST, 'EPISODES')
			if COMBI_SECOND:
				for m in sorted(COMBI_SECOND, key=lambda k: k[0], reverse=False):
					if m[2] in Isolated_EINS:
						continue
					Isolated_EINS.add(m[2])
					debug_MS("(navigator.listVideos[1]) ++++++++++++++++++++")
					debug_MS("(navigator.listVideos[1]) ##### Serie : {0} #####".format(seriesname))
					debug_MS("(navigator.listVideos[1]) ##### Titel : {0} #####".format(m[1]))
					debug_MS("(navigator.listVideos[1]) ##### Season : {0} / Episode : {1} #####".format(str(m[4]), str(m[5])))
					debug_MS("(navigator.listVideos[1]) ##### Thumb : {0} #####".format(m[3]))
					addLink(m[1], m[3], {'mode': 'playVideo', 'url': m[2], 'extras': m[3], 'season': m[4], 'episode': m[5]}, plot, seriesname, m[4], m[5])
	if RESULTS:
		for video in RESULTS:
			if '<div class="video_indicator">' in video:
				season, episode = ('0' for _ in range(2))
				count += 1
				link = re.compile('href="([^"]+?)" ', re.DOTALL).findall(video)[0]
				img = re.compile('<img src="(.*?)teaser_image_file(.*?)" width=', re.DOTALL).findall(video)
				pic1, pic2 = img[0][0], img[0][1]
				prefixes = ['https://static.atv.cdn.tvnext.tv', 'https://atv.at', 'https://www.atv.at']
				if pic1.startswith(tuple(s+'/dynamic/get_asset_resized.php' for s in prefixes)):
					if 'path=detail_pages%252F' in pic1:
						image = BASE_URL+"/static/assets/cms/detail_pages/teaser_image_file"+pic2.split('&amp;percent')[0].replace('%252F', '/')
					elif 'path=media_items%252F' in pic1:
						image = BASE_URL+"/static/assets/cms/media_items/teaser_image_file"+pic2.split('&amp;percent')[0].replace('%252F', '/')
				else:
					image = pic1+'teaser_image_file'+pic2.split('?cb=')[0]
				title = re.compile('class="title">([^<]+?)</', re.DOTALL).findall(video)[0]
				title = cleaning(title)
				matchSE = re.search('(season|staffel)\-(\d+)', link) # https://www.atv.at/bauer-sucht-frau-staffel-14/die-hofwochen-folge-12/d1958945/
				if matchSE: season = int(matchSE.group(2))
				matchEP = re.search('(-episode|/episode|-folge|/folge)\-(\d+)', link) # https://www.atv.at/bauer-sucht-frau-staffel-2/folge-13/v1642204/
				if matchEP: episode = int(matchEP.group(2)) # https://www.atv.at/bauer-sucht-frau-staffel-3/episode-14-event-teil-1/v1640552/
				if count == 1:
					Wanted = link.split(START_URL)[1].split('/')[0][:6]
				if (link in Isolated_EINS or 'aufruf' in link.lower()):
					continue
				if link in Isolated_ZWEI or not Wanted in link:
					continue
				Isolated_ZWEI.add(link)
				debug_MS("(navigator.listVideos[2]) ++++++++++++++++++++")
				debug_MS("(navigator.listVideos[2]) ##### Wanted-URL : "+Wanted+" #####")
				debug_MS("(navigator.listVideos[2]) ##### Serie : {0} #####".format(seriesname))
				debug_MS("(navigator.listVideos[2]) ##### Titel : {0} #####".format(title))
				debug_MS("(navigator.listVideos[2]) ##### Season : {0} / Episode : {1} #####".format(str(season), str(episode)))
				debug_MS("(navigator.listVideos[2]) ##### Thumb : {0} #####".format(image))
				addLink(title, image, {'mode': 'playVideo', 'url': link, 'extras': image, 'season': season, 'episode': episode}, plot, seriesname, season, episode)
	# now look for more videos button
	more_VIDS = re.search('<div class="more jsb_ jsb_MoreTeasersButton" data-jsb="([^"]+?)"', html, re.S)
	if "#####" in seriesID and more_VIDS:
		next_PAGE = unquote(more_VIDS.group(1).replace('url=', ''))
		debug_MS("(navigator.listVideos[3]) >>>>> next_PAGE : {0} >>>>>".format(next_PAGE))
		addDir(translation(30620), artpic+'nextpage.png', {'mode': 'listEpisodes', 'url': next_PAGE, 'origSERIE': seriesname, 'origDESC': plot})

def playVideo(url, photo, SEAS, EPIS):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL : {0} ###".format(url))
	Isolated_M3U8 = set()
	Isolated_MP4 = set()
	book, COMBI_FIRST, COMBI_SECOND, ASSEMBLY = ([] for _ in range(4))
	lastCODE = ['_2.mp4', '_3.mp4', '_4.mp4', '_5.mp4', '_6.mp4', '_7.mp4', '_8.mp4', '_9.mp4']
	html = getUrl(url)
	plot = ""
	matchDESC = re.search('<div class="js_expandable">.+?<p[^>]*>(.*?)</p>', html, re.S)
	if matchDESC:
		plot = cleaning(re.sub('\<.*?\>', '', matchDESC.group(1)))
	matching = re.search('class="mod_player js_html5_player ">(.*?)</script>', html, re.S)
	if matching:
		result = cleaning(matching.group(1))
		content = re.compile('var playlist = (.*?);', re.S).findall(result)[0]
		parts = json.loads(content, object_pairs_hook=OrderedDict)
		debug_MS("(navigator.playVideo[1]) ##### PLAYLISTE : {0} #####".format(parts))
		firstURL, M3U8_Url, MP4_Url, pos_M3U8, pos_MP4, MP4_Old, ENDnum_MP4 = ("" for _ in range(7))
		geoblock_M3U8, geoblock_MP4, found_M3U8, found_MP4, number_M3U8, number_MP4, count2, count3 = (0 for _ in range(8))
		single_videoURL = None
		for part in parts:
			count2 += 1
			title = cleaning(part['title']) # Bauer sucht Frau Die Hofwoche - Folge 5
			tvshowtitle = cleaning(part['tvShowTitle']) # Bauer sucht Frau
			duration = (part.get('duration', '0') or '0')
			if not title in book and count3 < 1:
				count3 += 1
				log("(navigator.playVideo[1]) -------------------- VideoTitel : {0} --------------------".format(title))
				debug_MS("(navigator.playVideo[1]) ##### Serie : {0} #####".format(tvshowtitle))
				debug_MS("(navigator.playVideo[1]) ##### Season : {0} / Episode : {1} #####".format(str(SEAS), str(EPIS)))
			debug_MS("(navigator.playVideo[1]) ##### Teil : {0} #####".format(str(count2)))
			debug_MS("(navigator.playVideo[1]) ##### Dauer (seconds) : {0} #####".format(str(duration)))
			debug_MS("(navigator.playVideo[1]) ##### Photo : {0} #####".format(photo))
			M3U8_Part = part['sources'][0]['url']
			if not M3U8_Part:
				continue
			if M3U8_Part:
				if M3U8_Part in Isolated_M3U8:
					continue
				Isolated_M3U8.add(M3U8_Part)
				number_M3U8 += 1
				pos_M3U8 = str(number_M3U8)+": "
				debug_MS("(navigator.playVideo[1]) ##### M3U8_Part : {0} #####".format(M3U8_Part))
				if not 'chunklist' in M3U8_Part:
					try:
						bestQuality = getUrl(M3U8_Part)
						newM3U8 = re.compile('(https?://.*?.m3u8)', re.DOTALL).findall(bestQuality)[0]
						if 'blocked-' in newM3U8:
							geoblock_M3U8 += 1
						M3U8_Url = newM3U8.replace('blocked-', '')
						found_M3U8 += 1
					except: pass
				else:
					M3U8_Url = M3U8_Part
					found_M3U8 += 1
			else:
				number_M3U8 += 1
				pos_M3U8 = str(number_M3U8)+": "
				debug_MS("(navigator.playVideo[1]) -------------------- M3U8_Url : KEINE passende ~m3u8~ gefunden !!! --------------------")
			MP4_Part = part['sources'][1]['url']
			if not MP4_Part:
				continue
			if MP4_Part:
				if 'blocked-' in MP4_Part:
					geoblock_MP4 += 1
				MP4_Part = MP4_Part.replace('blocked-', '')
				if any(x in MP4_Part for x in lastCODE):
					firstURL = MP4_Part[:-6]
				elif MP4_Part.startswith('https://multiscreen.atv.cdn.tvnext.tv'):
					firstURL = MP4_Part.split('.mp4')[0]
				if MP4_Part in Isolated_MP4:
					continue
				Isolated_MP4.add(MP4_Part)
				number_MP4 += 1
				pos_MP4 = str(number_MP4)+": "
				MP4_Old = str(pos_MP4)+MP4_Part
				ENDnum_MP4 = str(pos_MP4).split(':')[0]
				debug_MS("(navigator.playVideo[1]) ##### MP4_Part : {0} #####".format(MP4_Part))
			else:
				number_MP4 += 1
				pos_MP4 = str(number_MP4)+": "
				debug_MS("(navigator.playVideo[1]) -------------------- MP4_Url : KEINE passende ~mp4~ gefunden !!! --------------------")
			debug_MS("(navigator.playVideo[1]) * * * * * * * * * * * * * * * * * * * *")
			COMBI_FIRST.append([pos_MP4, MP4_Old, ENDnum_MP4, pos_M3U8, M3U8_Url, tvshowtitle, title, SEAS, EPIS, photo, duration])
		for pos_MP4, MP4_Old, ENDnum_MP4, pos_M3U8, M3U8_Url, tvshowtitle, title, SEAS, EPIS, photo, duration in COMBI_FIRST:
			if MP4_Old[:8] == "1: rtsp:" and "https://multiscreen.atv.cdn.tvnext.tv" in firstURL:
				debug_MS("(navigator.playVideo[2]) ##### MP4_Old-1 [1: rtsp:] : {0} #####".format(MP4_Old))
				MP4_Url = firstURL+".mp4"
				found_MP4 += 1
			elif MP4_Old[:8] != "1: rtsp:" and "rtsp://" in MP4_Old and "https://multiscreen.atv.cdn.tvnext.tv" in firstURL:
				debug_MS("(navigator.playVideo[2]) ##### MP4_Old-2 [rtsp://] : {0} #####".format(MP4_Old))
				MP4_Url = firstURL+"_"+ENDnum_MP4+".mp4"
				found_MP4 += 1
			elif not "rtsp:" in MP4_Old and "https://multiscreen.atv.cdn.tvnext.tv" in firstURL:
				MP4_Url = MP4_Old.split(': ')[1]
				found_MP4 += 1
			COMBI_SECOND.append([pos_MP4, MP4_Url, pos_M3U8, M3U8_Url, tvshowtitle, title, SEAS, EPIS, photo, duration])
		for pos_MP4, MP4_Url, pos_M3U8, M3U8_Url, tvshowtitle, title, SEAS, EPIS, photo, duration in COMBI_SECOND:
			MP4_Video = str(pos_MP4)+MP4_Url
			M3U8_Video = str(pos_M3U8)+M3U8_Url
			#log("(navigator.playVideo[3]) Video  -  MP4 = {0}".format(MP4_Video))
			#log("(navigator.playVideo[3]) Video - M3U8 = {0}".format(M3U8_Video))
			if (firstURL == "" or prefSTREAM == "1" or found_MP4 != len(parts)) and M3U8_Url != "" and found_M3U8 == len(parts):
				single_videoURL = M3U8_Url
			elif (M3U8_Url == "" or prefSTREAM == "0" or found_M3U8 != len(parts)) and MP4_Url != "" and found_MP4 == len(parts):
				single_videoURL = MP4_Url
			ASSEMBLY.append([single_videoURL, tvshowtitle, title, SEAS, EPIS, plot, photo, duration])
		if (geoblock_M3U8 == len(parts) or geoblock_MP4 == len(parts)) and not USER_from_austria():
			log("(navigator.playVideo[3]) FALSCHE IP ##### DIESE STREAMS SIND NUR MIT EINER IP-ADRESSE IN ÖSTERREICH VERFÜGBAR #####")
			return dialog.notification(translation(30523), translation(30524), icon, 10000)
		log("(navigator.playVideo[3]) FIND  -   MP4 = {0} - Streams".format(str(found_MP4)))
		log("(navigator.playVideo[3]) FIND -  M3U8 = {0} - Streams".format(str(found_M3U8)))
		if single_videoURL and (found_M3U8 == len(parts) or found_MP4 == len(parts)):
			PL = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
			combined_videoURL = ""
			pos_LISTE = 0
			if prefTECHNIQUE == "1" and StreamMESSAGE:
				dialog.notification(translation(30527), translation(30528).format(title), icon, 5000)
				xbmc.sleep(500)
			for single_videoURL, tvshowtitle, title, SEAS, EPIS, plot, photo, duration in ASSEMBLY:
				pos_LISTE += 1
				combined_videoURL += single_videoURL+" , "
				if prefTECHNIQUE in ['0', '1']:
					stacked_videoURL = 'stack://'+combined_videoURL[0:-3]
					listitem = xbmcgui.ListItem(path=stacked_videoURL)
					listitem.setInfo(type="Video", infoLabels={'TVShowTitle': tvshowtitle, 'Title': title, 'Season': SEAS, 'Episode': EPIS, 'Plot': plot, 'Duration': duration, 'Studio': 'ATV.at', 'Genre': 'Unterhaltung', 'Mediatype': 'episode'})
					listitem.setArt({'thumb': photo, 'poster': photo, 'fanart': photo})
					listitem.setMimeType("mime/x-type")
				else:
					NRS_title = translation(30621).format(title, str(pos_LISTE), str(len(parts))) # Die Hofwochen - Folge 5 1/7
					listitem = xbmcgui.ListItem(path=single_videoURL)
					listitem.setInfo(type="Video", infoLabels={'TVShowTitle': tvshowtitle, 'Title': NRS_title, 'Season': SEAS, 'Episode': EPIS, 'Plot': plot, 'Duration': duration, 'Studio': 'ATV.at', 'Genre': 'Unterhaltung', 'Mediatype': 'episode'})
					listitem.setArt({'thumb': photo, 'poster': photo, 'fanart': photo})
					xbmc.sleep(50)
					PL.add(url=single_videoURL, listitem=listitem, index=pos_LISTE)
			if prefTECHNIQUE == "0":
				log("(navigator.playSTANDARD-1) combined_videoURL : {0}".format(combined_videoURL))
				log("(navigator.playSTANDARD-1) -------------------- Meldung: *Standard-Abspielen [1]* in den Settings eingestellt --------------------")
				xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
			if prefTECHNIQUE == "1":
				log("(navigator.playSTANDARD-2) combined_videoURL : {0}".format(combined_videoURL))
				log("(navigator.playSTANDARD-2) -------------------- Meldung: *Standard-Abspielen [2]* in den Settings eingestellt --------------------")
				xbmc.Player().play(item=stacked_videoURL, listitem=listitem)
			if prefTECHNIQUE == "2":
				log("(navigator.playPLAYLIST-3) combined_videoURL : {0}".format(combined_videoURL))
				log("(navigator.playPLAYLIST-3) -------------------- Meldung: Nur *Playliste-Abspielen [3]* in den Settings eingestellt --------------------")
				return PL
		else:
			return dialog.notification(translation(30525), translation(30526), icon, 10000)
	else:
		return dialog.notification(translation(30525), translation(30526), icon, 10000)

COMBI_OUTPUT = []
pill2kill = threading.Event()
def listSubstances(parts, pill2kill, course):
	num = parts.split('@@')[0]
	position = int(num)
	elem = parts.split('@@')[1]
	Isolated = set()
	while not pill2kill.is_set() and position < 20:
		try:
			if course == 'EPISODES':
				content = getUrl(elem)
				if 'mod_teasers four all_rows jsb_ jsb_ExpandableTeaser' in content:
					debug_MS("(navigator.listSubstances) ### Inhalt gefunden auf Seite = {0} ###".format(str(elem)))
					FIRST = re.findall('<li class="teaser">(.*?)</li>', content, re.S)
					for video in FIRST:
						if '<div class="video_indicator">' in video:
							season, episode = ('0' for _ in range(2))
							link = re.compile('href="([^"]+?)" ', re.DOTALL).findall(video)[0]
							img = re.compile('<img src="(.*?)teaser_image_file(.*?)" width=', re.DOTALL).findall(video)
							pic1, pic2 = img[0][0], img[0][1]
							prefixes = ['https://static.atv.cdn.tvnext.tv', 'https://atv.at', 'https://www.atv.at']
							if pic1.startswith(tuple(s+'/dynamic/get_asset_resized.php' for s in prefixes)):
								if 'path=detail_pages%252F' in pic1:
									photo = BASE_URL+"/static/assets/cms/detail_pages/teaser_image_file"+pic2.split('&amp;percent')[0].replace('%252F', '/')
								elif 'path=media_items%252F' in pic1:
									photo = BASE_URL+"/static/assets/cms/media_items/teaser_image_file"+pic2.split('&amp;percent')[0].replace('%252F', '/')
							else:
								photo = pic1+'teaser_image_file'+pic2.split('?cb=')[0]
							title = re.compile('class="title">([^<]+?)</', re.DOTALL).findall(video)[0]
							title = cleaning(title)
							matchSE = re.search('(season|staffel)\-(\d+)', link) # https://www.atv.at/bauer-sucht-frau-staffel-14/die-hofwochen-folge-12/d1958945/
							if matchSE: season = int(matchSE.group(2))
							matchEP = re.search('(-episode|/episode|-folge|/folge)\-(\d+)', link) # https://www.atv.at/bauer-sucht-frau-staffel-2/folge-13/v1642204/
							if matchEP: episode = int(matchEP.group(2)) # https://www.atv.at/bauer-sucht-frau-staffel-3/episode-14-event-teil-1/v1640552/
							if link in Isolated:
								continue
							Isolated.add(link)
							COMBI_OUTPUT.append([int(num), title, link, photo, season, episode])
				elif num == '1' and 'Oh, ein 404er-Fehler. Wir müssen dir leider sagen: es gibt die Seite nicht, die du suchst' in content:
					debug_MS("(navigator.listSubstances) ERROR 404 ##### !!! FEHLER IN DER COMBI-LISTE - GEHE ZURÜCK ZU EPISODEN !!! #####")
					position = 20
					stopping()
				else:
					position = 20
					stopping()
		except:
			position = 20
			stopping()
			formatted_lines = traceback.format_exc().splitlines()
			failing("(navigator.listSubstances) ERROR - ERROR - ERROR :\n{0} \n{1} \n{2}".format(formatted_lines[1], formatted_lines[2], formatted_lines[3]))

def stopping():
	pill2kill.set()

def getMultiData(simultan, event='VIDEOS'):
	debug_MS("(navigator.getMultiData) ------------------------------------------------ START = getMultiData -----------------------------------------------")
	threads = []
	debug_MS("(navigator.getMultiData) ganze LISTE XXXXX {0} XXXXX".format(' || '.join(simultan)))
	for article in simultan:
		th = threading.Thread(target=listSubstances, args=[article, pill2kill, event])
		if hasattr(th, 'daemon'): th.daemon = True
		else: th.setDaemon()
		threads.append(th)
	[th.start() for th in threads]
	threading.Timer(25, after_timeout, [threads, pill2kill]).start()
	[th.join(3) for th in threads]
	if COMBI_OUTPUT:
		debug_MS("(navigator.listSubstances) Ergebnis XXXXX COMBI_OUTPUT = {0} XXXXX".format(str(COMBI_OUTPUT)))
	return COMBI_OUTPUT

def after_timeout(threads, pill2kill):
	pos1 = 0
	for th in threads:
		if th.is_alive() and pos1 == 0:
			pos1 += 1
			failing("(navigator.after_timeout) TIMEOUT ##### !!! DIE MAX. ZEIT FÜR THREADS IST ABGELAUFEN - KILLING THEM ALL !!! #####")
			stopping()
	return

def listShowsFavs():
	debug_MS("(navigator.listShowsFavs) ------------------------------------------------ START = listShowsFavs -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as fp:
			watch = json.load(fp)
			for item in watch.get('items', []):
				name = cleaning(item.get('name'))
				logo = icon if item.get('pict', 'None') == 'None' else item.get('pict')
				desc = None if item.get('plot', 'None') == 'None' else cleaning(item.get('plot'))
				debug_MS("(navigator.listShowsFavs) ### NAME : {0} || URL : {1} || IMAGE : {2} ###".format(name, item.get('url'), logo))
				addDir(name, logo, {'mode': 'listCluster', 'url': item.get('url'), 'extras': logo}, desc, FAVclear=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(*args):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'name': name, 'pict': pict, 'url': url, 'plot': plot})
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30529), translation(30530).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('url') != url]
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30529), translation(30531).format(name), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, addType=0, FAVclear=False, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'ATV.at'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	entries = []
	if addType == 1 and FAVclear is False:
		entries.append([translation(30651), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'action': 'ADD', 'name': name, 'pict': 'None' if image == icon else image,
			'url': params.get('url'), 'plot': 'None' if plot is None else plot.replace('\n', '[CR]')}))])
	if FAVclear is True:
		entries.append([translation(30652), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'action': 'DEL', 'name': name, 'pict': image, 'url': params.get('url'), 'plot': plot}))])
	liz.addContextMenuItems(entries, replaceItems=False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, seriesname=None, season=None, episode=None, duration=None, genre=None, year=None, begins=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	if season is not None and season != '0':
		info['Season'] = season
	info['Episode'] = episode
	info['Tvshowtitle'] = seriesname
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	if begins is not None:
		info['Date'] = begins
	info['Year'] = year
	info['Genre'] = 'Unterhaltung'
	info['Studio'] = 'ATV.at'
	info['Mpaa'] = None
	info['Mediatype'] = 'episode'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	if prefTECHNIQUE in ['0', '2']:
		liz.setProperty('IsPlayable', 'true')
		liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
