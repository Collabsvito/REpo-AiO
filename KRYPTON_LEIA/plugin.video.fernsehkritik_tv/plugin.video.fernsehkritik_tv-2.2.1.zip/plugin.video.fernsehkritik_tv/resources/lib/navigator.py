﻿# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
else: 
	from urllib.parse import urlencode  # Python 3.X

from .common import *


def mainMenu():
	if xbmcvfs.exists(target_DIR): addDir(translation(30621), icon, {'mode': 'listStored', 'url': ''})
	addDir(translation(30601), icon, {'mode': 'listShows', 'url': BASE_URL+'/mag/1'})
	addDir(translation(30602), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'UUj089h5WsDdh1q8t54K3ZCw'})
	addDir(translation(30603), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ2s-Qchjp4Th4UdjeUnvZEZ'})
	addDir(translation(30604), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ3hsqfybfFBwA9Q34er0cqq'})
	addDir(translation(30605), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ1IMXNJphxxrng9cDc9I52S'})
	addDir(translation(30606), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ1MCHW4qv6jI0tvcJ9KWRaa'})
	addDir(translation(30607), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ0QXyvHlCc2Q-7rB5E0tNjS'})
	addDir(translation(30608), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ1b6at_tZBLWX5mgQZfwH9x'})
	addDir(translation(30609), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ2s7TYjZvf_Pzo0BkRRaRyO'})
	addDir(translation(30610), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ3TGilJSiLloC_sb75Taeq7'})
	addDir(translation(30611), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ0VtaJKNb8RBW0EIC0AAaVz'})
	addDir(translation(30612), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ2zjUQe3He-qkIk6oHL-AVT'})
	addDir(translation(30613), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ37ha_85phsaNuqleodCUK7'})
	addDir(translation(30614), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ3yp06m-JJ2Hgc_mL4n86Hm'})
	addDir(translation(30615), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ0Ew2inhQE7OEPdUirdYsNH'})
	addDir(translation(30616), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ1XWSjrAmVX1hAmWqYY4VCn'})
	addDir(translation(30617), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ2LoCcoJ3lGzLorDVQFo5_t'})
	addDir(translation(30618), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ2kUtgvYWQoJwKcgWqIT49-'})
	addDir(translation(30619), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ1zvG4KPm0edK78s8aLsDRh'})
	addDir(translation(30620), icon, {'mode': 'YOUT_channel', 'url': BASE_YT+'PLqh6lroBRtJ22STc80jUwywSwhLiqY7po'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listShows(url):
	debug("(listShows) -------------------------------------------------- START = listShows --------------------------------------------------")
	html = getUrl(url, 'GET', url)
	content = html[html.find('<li id="mag-button" class="nav-item">')+1:]
	content = content[:content.find('<li class="nav-item"><a href="https://forum.massengeschmack.tv/" class="nav-link">Forum</a>')]
	selection = re.findall(r'<a href="([^"]+?)">([^<]+?)</a></div>', content, re.S)
	for endURL, name in selection:
		endURL = py2_enc(BASE_URL+endURL)
		name = cleaning(name)
		debug("(listShows) ### endURL : {0} ### NAME : {1} ###".format(url, str(name)))
		if not any(x in name.lower() for x in ['massengeschnack', 'premium', 'live']):
			addDir(name, icon, {'mode': 'listEpisodes', 'url': endURL, 'origSERIE': name})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, origSERIE):
	debug("(listEpisodes) -------------------------------------------------- START = listEpisodes --------------------------------------------------")
	debug("(listEpisodes) ### URL = {0} ### origSERIE = {1} ###".format(url, str(origSERIE)))
	COMBI = []
	content = getUrl(url, 'GET', url)
	PID = re.compile('MAG_PID = ([0-9]+?);', re.DOTALL).findall(content)[0]
	try: SID = re.compile('MAG_SPID = ([0-9,]+?);', re.DOTALL).findall(content)[0]
	except: SID = ""
	FOUND = 0
	offset = 0
	count = 100
	total = 1
	while (total > 0):
		# https://massengeschmack.tv/api/v2/feed/filter?offset=6&count=18&filter=%7B%22mag%22%3A%7B%2223%22%3A%5B%5D%7D%7D
		JS_url = BASE_URL+'/api/v2/feed/filter?offset={0}&count={1}&filter=%7B%22mag%22%3A%7B%22{2}%22%3A%5B{3}%5D%7D%7D'.format(str(offset), str(count), str(PID), str(SID))
		try:
			result = getUrl(JS_url, 'GET', url)
			DATA = json.loads(result)
			if 'clips' in DATA and len(DATA['clips']) < 10:
				total = 0
			for item in DATA['clips']:
				debug("(listEpisodes) ##### FOLGE : {0} #####".format(str(item)))
				video = ""
				if 'teaserFile' in item and item['teaserFile'] != "" and item['teaserFile'] != None:
					video = item['teaserFile']
				if video == "" and 'hasDownload' in item and item['hasDownload'] == True:
					video = BASE_URL+'/play/'+item['id']
				title = cleaning(item['title'])
				episode = ""
				if 'seqNr' in item and item['seqNr'] != "" and item['seqNr'] != None:
					episode = str(item['seqNr']).zfill(4)
				logo = ""
				if 'image' in item and item['image'] != "" and item['image'] != None:
					logo = item['image']
				plot = '[COLOR yellow]'+origSERIE+'[/COLOR][CR][CR]'
				plot += get_desc(item)
				duration = get_sec(item['duration'])
				COMBI.append([episode, video, logo, title, plot, duration, origSERIE])
				if episode != "": COMBI = sorted(COMBI, key=lambda num:num[0], reverse=True)
		except: total = 0
		offset += 100
		xbmc.sleep(1000)
	if COMBI and total == 0:
		for episode, video, logo, title, plot, duration, origSERIE in COMBI:
			if video != "":
				FOUND = 1
				addLink(title, logo, {'mode': 'playVideo', 'url': video, 'origSERIE': origSERIE, 'extras': 'DIRECTstream', 'cineType': 'episode'}, plot, episode=episode)
	if FOUND == 0:
		return dialog.notification(translation(30522), translation(30528).format(origSERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def YOUT_channel(url):
	debug("(YOUT_channel) -------------------------------------------------- START = YOUT_channel --------------------------------------------------")
	debug("(YOUT_channel) ### URL = {0} ###".format(url))
	response = getUrl(url, 'GET', url)
	DATA = json.loads(response)
	for item in DATA['video']:
		debug("(YOUT_channel) ##### FOLGE : {0} #####".format(str(item)))
		title = cleaning(item['title'])
		plot =""
		if 'added' in item and item['added'] !="" and item['added'] != None:
			plot = '[COLOR yellow]'+str(item['added'])+'[/COLOR][CR]'
		if 'description' in item and item['description'] !="" and item['description'] != None:
			plot += cleaning(item['description'])
		try: photo = item['thumbnail'].replace('/default.jpg', '/maxresdefault.jpg')
		except: photo = ""
		videoId = ""
		if 'encrypted_id' in item and item['encrypted_id'] !="" and item['encrypted_id'] != None:
			videoId = str(item['encrypted_id'])
		duration = ""
		if 'length_seconds' in item and item['length_seconds'] !="" and item['length_seconds'] != None:
			duration = item['length_seconds']
		rating = ""
		if 'rating' in item and item['rating'] !="" and item['rating'] != None:
			rating = str(item['rating'])
		votes = ""
		if 'likes' in item and item['likes'] !="" and item['likes'] != None:
			votes = str(item['likes'])
		addLink(title, photo, {'mode': 'playVideo', 'url': videoId, 'extras': 'YTstream', 'cineType': 'movie'}, plot, duration, rating, votes)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def getVideo(url):
	debug("(getVideo) -------------------------------------------------- START = getVideo --------------------------------------------------")
	content = getUrl(url, 'GET', url)
	debug("++++++++++++++++++++++++")
	debug("(getVideo) XXXXX CONTENT : {0} XXXXX".format(str(content)))
	debug("++++++++++++++++++++++++")
	match1 = re.findall('src: "(//massengeschmack.+?)" }', content, re.S)
	match2 = re.findall('type: "video/mp4", src: "([^"]+)"', content, re.S)
	if match1:
		return 'https:'+match1[0]
	elif match2:
		return match2[0]
	else:
		return dialog.notification(translation(30521).format('PLAY'), translation(30529), icon, 8000)

def MULTI_download(name, element):
	from threading import Thread
	threads = []
	thread = Thread(target=getDownload, args=[name, element])
	if hasattr(thread, 'daemon'): thread.daemon = True
	else: thread.setDaemon()
	threads.append(thread)
	for thread in threads: thread.start()

def getDownload(name, element):
	debug("(getDownload) -------------------------------------------------- START = getDownload --------------------------------------------------")
	now = str(time.strftime ('%d-%m-%Y'))
	url = element.split('###')[0]
	type = element.split('###')[1]
	debug("(getDownload) ### URL : {0} || Name : {1} || Type : {2} ###".format(url, name, type))
	if target_DIR is None or target_DIR is '':
		dialog.notification(translation(30521).format('DOWNLOAD'), translation(30523), icon, 8000)
		return addon.openSettings(HOST_AND_PATH)
	if not xbmcvfs.exists(target_DIR):
		xbmcvfs.mkdirs(target_DIR)
	dialog.notification(translation(30524), translation(30526).format(name), icon, 8000)
	from youtube_dl import YoutubeDL
	fields = {'forceurl': True, 'forcetitle': True, 'quiet': True, 'no_warnings': True, 'noplaylist': True, 'format': 'best', 'outtmpl': os.path.join(target_DIR, '%(title)s ['+now+'].%(ext)s')}
	with YoutubeDL(fields) as ydl:
		meta = ydl.extract_info(url, download=True)
		try:
			if 'entries' in meta: Vinfo = meta['entries'][0]
			else:
				Vinfo = meta
			if 'url' in Vinfo: media = Vinfo['url']
			else:
				if 'formats' in Vinfo and len(Vinfo['formats']) > 0:
					media = Vinfo['formats'][-1]['url']
			log("(getDownload) DOWNLOAD-VIDEO : {0}".format(media))
		except: pass
	xbmc.sleep(2000)
	dialog.notification(translation(30525), translation(30526).format(name), icon, 12000)

def listStored():
	debug("(listStored) -------------------------------------------------- START = listStored --------------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	for item in os.listdir(target_DIR):
		full_Path = os.path.join(target_DIR, item)
		name = editing(item).replace('.mp4', '').replace('_', ' ')
		addLink(name, icon, {'mode': 'playVideo', 'url': full_Path, 'extras': 'DOWNstream', 'cineType': 'movie'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url, type):
	debug("(playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	if type == 'YTstream':
		finalURL = 'plugin://plugin.video.youtube/play/?video_id='+url
	elif type == 'DIRECTstream' and '/play/' in url:
		finalURL = getVideo(url)
	else:
		finalURL = url
	log("(playVideo) StreamURL : "+finalURL)
	listitem=xbmcgui.ListItem(path=finalURL)
	xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)

def addDir(name, image, params={}, plot=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Tvshowtitle': params.get('origSERIE'), 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)

def addLink(name, image, params={}, plot=None, duration=None, episode=None, rating=None, votes=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Episode'] = episode
	info['Tvshowtitle'] = params.get('origSERIE')
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Genre'] = None
	info['Rating'] = rating
	info['Votes'] = votes
	info['Studio'] = 'Massengeschmack.TV'
	info['Mediatype'] = params.get('cineType')
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	entries = []
	if params.get('extras') in ['DIRECTstream', 'YTstream']:
		entries.append([translation(30655), 'RunPlugin({0}?name={1}&{2})'.format(HOST_AND_PATH, name, urlencode({'mode': 'MULTI_download', 'url': params.get('url')+'###'+params.get('extras')+'###'}))])
	if params.get('extras') == 'DOWNstream':
		entries.append([translation(30656), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'GotoTrash', 'url': params.get('url')}))])
	liz.addContextMenuItems(entries, replaceItems=False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
