﻿# -*- coding: utf-8 -*-


class Client(object):
	SUPPORTED_GENRES = {
		'specifications': [
		{
			'name': 'Andacht',
			'kalturaId': 540,
			'entriesCount': 28,
			'api_id': 2,
			'href': 'https://api.bibeltv.de/v1/genres/2'
		},
		{
			'name': 'Aufbrüche in der Kirche',
			'kalturaId': 900357,
			'entriesCount': 9,
			'api_id': 71,
			'href': 'https://api.bibeltv.de/v1/genres/71'
		},
		{
			'name': 'Bibelverse',
			'kalturaId': 900355,
			'entriesCount': 44,
			'api_id': 69,
			'href': 'https://api.bibeltv.de/v1/genres/69'
		},
		{
			'name': 'Big Church Day Out Magazin',
			'kalturaId': 900349,
			'entriesCount': 10,
			'api_id': 63,
			'href': 'https://api.bibeltv.de/v1/genres/63'
		},
		{
			'name': 'Credo unplugged',
			'kalturaId': 900356,
			'entriesCount': 9,
			'api_id': 70,
			'href': 'https://api.bibeltv.de/v1/genres/70'
		},
		{
			'name': 'Das Johannes-Evangelium in 21 Teilen',
			'kalturaId': 900348,
			'entriesCount': 21,
			'api_id': 62,
			'href': 'https://api.bibeltv.de/v1/genres/62'
		},
		{
			'name': 'Doku-Reihe',
			'kalturaId': 1815,
			'entriesCount': 13,
			'api_id': 33,
			'href': 'https://api.bibeltv.de/v1/genres/33'
		},
		{
			'name': 'Doku-Soap',
			'kalturaId': 2060,
			'entriesCount': 19,
			'api_id': 49,
			'href': 'https://api.bibeltv.de/v1/genres/49'
		},
		{
			'name': 'Dokumentation',
			'kalturaId': 542,
			'entriesCount': 221,
			'api_id': 3,
			'href': 'https://api.bibeltv.de/v1/genres/3'
		},
		{
			'name': 'English Originals',
			'kalturaId': 1561,
			'entriesCount': 4,
			'api_id': 22,
			'href': 'https://api.bibeltv.de/v1/genres/22'
		},
		{
			'name': 'Event',
			'kalturaId': 2037,
			'entriesCount': 1,
			'api_id': 46,
			'href': 'https://api.bibeltv.de/v1/genres/46'
		},
		{
			'name': 'Gottesdienst',
			'kalturaId': 583,
			'entriesCount': 3,
			'api_id': 9,
			'href': 'https://api.bibeltv.de/v1/genres/9'
		},
		{
			'name': 'ICF: Story of Christmas',
			'kalturaId': 900361,
			'entriesCount': 2,
			'api_id': 75,
			'href': 'https://api.bibeltv.de/v1/genres/75'
		},
		{
			'name': 'Il Diamante - Partner gesucht',
			'kalturaId': 900350,
			'entriesCount': 1,
			'api_id': 64,
			'href': 'https://api.bibeltv.de/v1/genres/64'
		},
		{
			'name': 'Joyce Meyer - Kurzimpulse',
			'kalturaId': 900352,
			'entriesCount': 41,
			'api_id': 66,
			'href': 'https://api.bibeltv.de/v1/genres/66'
		},
		{
			'name': 'Kinder',
			'kalturaId': 561,
			'entriesCount': 352,
			'api_id': 6,
			'href': 'https://api.bibeltv.de/v1/genres/6'
		},
		{
			'name': 'Konzert',
			'kalturaId': 1176,
			'entriesCount': 2,
			'api_id': 19,
			'href': 'https://api.bibeltv.de/v1/genres/19'
		},
		{
			'name': 'Kraftvoll leben',
			'kalturaId': 900346,
			'entriesCount': 10,
			'api_id': 60,
			'href': 'https://api.bibeltv.de/v1/genres/60'
		},
		{
			'name': 'Kultur',
			'kalturaId': 2069,
			'entriesCount': 658,
			'api_id': 50,
			'href': 'https://api.bibeltv.de/v1/genres/50'
		},
		{
			'name': 'Lutherbibel 2017',
			'kalturaId': 900359,
			'entriesCount': 13,
			'api_id': 73,
			'href': 'https://api.bibeltv.de/v1/genres/73'
		},
		{
			'name': 'Magazin',
			'kalturaId': 549,
			'entriesCount': 891,
			'api_id': 5,
			'href': 'https://api.bibeltv.de/v1/genres/5'
		},
		{
			'name': 'Meine Geschichte (Die Gideons)',
			'kalturaId': 900358,
			'entriesCount': 5,
			'api_id': 72,
			'href': 'https://api.bibeltv.de/v1/genres/72'
		},
		{
			'name': 'Musical',
			'kalturaId': 2050,
			'entriesCount': 2,
			'api_id': 48,
			'href': 'https://api.bibeltv.de/v1/genres/48'
		},
		{
			'name': 'Musik',
			'kalturaId': 992,
			'entriesCount': 242,
			'api_id': 17,
			'href': 'https://api.bibeltv.de/v1/genres/17'
		},
		{
			'name': 'Nachrichten',
			'kalturaId': 596,
			'entriesCount': 4,
			'api_id': 12,
			'href': 'https://api.bibeltv.de/v1/genres/12'
		},
		{
			'name': 'PROCHRIST 2019',
			'kalturaId': 900351,
			'entriesCount': 1,
			'api_id': 65,
			'href': 'https://api.bibeltv.de/v1/genres/65'
		},
		{
			'name': 'Passionsspiele St. Margarethen',
			'kalturaId': 900360,
			'entriesCount': 1,
			'api_id': 74,
			'href': 'https://api.bibeltv.de/v1/genres/74'
		},
		{
			'name': 'Portrait',
			'kalturaId': 1614,
			'entriesCount': 7,
			'api_id': 23,
			'href': 'https://api.bibeltv.de/v1/genres/23'
		},
		{
			'name': 'Ratgeber',
			'kalturaId': 2071,
			'entriesCount': 1969,
			'api_id': 51,
			'href': 'https://api.bibeltv.de/v1/genres/51'
		},
		{
			'name': 'Report',
			'kalturaId': 2073,
			'entriesCount': 7,
			'api_id': 52,
			'href': 'https://api.bibeltv.de/v1/genres/52'
		},
		{
			'name': 'Reportage',
			'kalturaId': 646,
			'entriesCount': 9,
			'api_id': 16,
			'href': 'https://api.bibeltv.de/v1/genres/16'
		},
		{
			'name': 'Serie',
			'kalturaId': 641,
			'entriesCount': 140,
			'api_id': 15,
			'href': 'https://api.bibeltv.de/v1/genres/15'
		},
		{
			'name': 'Spielfilm',
			'kalturaId': 616,
			'entriesCount': 19,
			'api_id': 14,
			'href': 'https://api.bibeltv.de/v1/genres/14'
		},
		{
			'name': 'Talk',
			'kalturaId': 533,
			'entriesCount': 1297,
			'api_id': 1,
			'href': 'https://api.bibeltv.de/v1/genres/1'
		},
		{
			'name': 'Vishal Mangalwadi - Fundamente',
			'kalturaId': 900362,
			'entriesCount': 10,
			'api_id': 76,
			'href': 'https://api.bibeltv.de/v1/genres/76'
		},
		{
			'name': 'Wissen',
			'kalturaId': 604,
			'entriesCount': 9,
			'api_id': 13,
			'href': 'https://api.bibeltv.de/v1/genres/13'
		}]
	}

	def __init__(self, records):
		self._records = records

	def get_records(self):
		return self._records
