# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus  # Python 2.X
else: 
	from urllib.parse import urlencode, quote_plus  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listShowsFavs'})
	addDir(translation(30602), icon, {'mode': 'listBroadcasts', 'url': BASE_API+'/series'})
	addDir(translation(30603), icon, {'mode': 'listTopics', 'url': BASE_API+'/topics'})
	addDir(translation(30604), icon, {'mode': 'listStartpage', 'url': BASE_API+'/videolists?start&broadcast_limit=10', 'extras': '130828'})
	addDir(translation(30605), icon, {'mode': 'listStartpage', 'url': BASE_API+'/videolists?start&broadcast_limit=10', 'extras': '130824'})
	addDir(translation(30606), icon, {'mode': 'listStartpage', 'url': BASE_API+'/videolists?start&broadcast_limit=10', 'extras': '130826'})
	addDir(translation(30607), icon, {'mode': 'listStartpage', 'url': BASE_API+'/videolists?start&broadcast_limit=10', 'extras': '130827'})
	addDir(translation(30608), icon, {'mode': 'listStartpage', 'url': BASE_API+'/videolists?start&broadcast_limit=10', 'extras': '130825'})
	addDir(translation(30609), icon, {'mode': 'listStartpage', 'url': BASE_API+'/videolists?start&broadcast_limit=10', 'extras': 'complete'})
	addDir(translation(30610), artpic+'livestream.png', {'mode': 'playLIVE'}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30611), artpic+'settings.png', {'mode': 'aSettings'})
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30612), artpic+'settings.png', {'mode': 'iSettings'})
		else:
			addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(url):
	debug_MS("(navigator.listBroadcasts) ------------------------------------------------ START = listBroadcasts -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	content = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listBroadcasts) CONTENT : {0}".format(str(content)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(content) 
	for elem in DATA['series']:
		if 'broadcast_count' in elem and int(elem['broadcast_count']) >= 1:
			TVS_idd = str(elem['id'])
			title = cleaning(elem['title'])
			thumb = icon
			if elem.get('images', None):
				max_res = max(elem['images'], key=lambda d: d['resolution'])
				thumb = max_res['url']
			addType = 1
			if os.path.exists(channelFavsFile):
				with open(channelFavsFile, 'r') as output:
					lines = output.readlines()
					for line in lines:
						if line.startswith('###START'):
							part = line.split('###')
							if TVS_idd == part[2]: addType = 2
			debug_MS("(navigator.listBroadcasts) ### TITLE = {0} || IDD = {1} || PHOTO = {2} ###".format(title, TVS_idd, thumb))
			addDir(title, thumb, {'mode': 'listEpisodes', 'url': TVS_idd, 'origSERIE': title}, addType=addType)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)  

def listTopics(url):
	debug_MS("(navigator.listTopics) ------------------------------------------------ START = listTopics -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	content = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listTopics) CONTENT : {0}".format(str(content)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(content)
	for element in DATA['topics']:
		TP_idd = str(element['id'])
		title = cleaning(element['title'])
		debug_MS("(navigator.listTopics) ### TITLE = {0} || IDD = {1} ###".format(title, TP_idd))
		addDir(title, icon, {'mode': 'listSubTopics', 'url': TP_idd})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSubTopics(Xidd):
	debug_MS("(navigator.listSubTopics) ------------------------------------------------ START = listSubTopics -----------------------------------------------")
	url_1 = BASE_API+'/topics/'+Xidd+'/series?vod_only&broadcast_limit=50&limit=500'
	content1 = getUrl(url_1)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listSubTopics) CONTENT-01 : {0}".format(str(content1)))
	debug_MS("++++++++++++++++++++++++")
	DATA_1 = json.loads(content1)
	for elem in DATA_1['series']:
		if 'broadcast_count' in elem and int(elem['broadcast_count']) >= 1:
			xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
			TVS_idd = str(elem['id'])
			title = cleaning(elem['title'])
			thumb = icon
			if elem.get('images', None):
				max_res = max(elem['images'], key=lambda d: d['resolution'])
				thumb = max_res['url']
			addType = 1
			if os.path.exists(channelFavsFile):
				with open(channelFavsFile, 'r') as output:
					lines = output.readlines()
					for line in lines:
						if line.startswith('###START'):
							part = line.split('###')
							if TVS_idd == part[2]: addType = 2
			debug_MS("(navigator.listSubTopics) ### TITLE-1 = {0} || IDD-1 = {1} || PHOTO-1 = {2} ###".format(title, TVS_idd, thumb))
			addDir(title, thumb, {'mode': 'listEpisodes', 'url': TVS_idd, 'origSERIE': title}, addType=addType)
	url_2 = BASE_API+'/topics/'+Xidd+'/broadcasts?vod_only&no_series=&broadcast_limit=5'
	content2 = getUrl(url_2)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listSubTopics) CONTENT-02 : {0}".format(str(content2)))
	debug_MS("++++++++++++++++++++++++")
	DATA_2 = json.loads(content2)
	for vid in DATA_2['broadcasts']:
		if 'has_video' in vid and vid['has_video'] == True:
			EP_idd = str(vid['id'])
			name = cleaning(vid['title'])
			if 'subtitle' in vid and vid['subtitle'] != "" and vid['subtitle'] != None and vid['subtitle'] not in vid['title']:
				name += ' - '+cleaning(vid['subtitle'])
			duration = (vid.get('vod_duration', '0') or '0')
			photo = icon
			if vid.get('images', None):
				max_res = max(vid['images'], key=lambda d: d['resolution'])
				photo = max_res['url']
			genre = None
			genreLIST = []
			if vid.get('genres', None):
				genreLIST = [cleaning(genid.get('title', [])) for genid in vid.get('genres', '')]
				if genreLIST: genre = ' / '.join(sorted(genreLIST))
			debug_MS("(navigator.listSubTopics) ### TITLE-2 = {0} || IDD-2 = {1} || PHOTO-2 = {2} ###".format(name, EP_idd, photo))
			addLink(name, photo, {'mode': 'playVideo', 'url': EP_idd}, duration, genre=genre)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listStartpage(url, extras):
	debug_MS("(navigator.listStartpage) ------------------------------------------------ START = listStartpage -----------------------------------------------")
	content = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listStartpage) CONTENT : {0}".format(str(content)))
	debug_MS("++++++++++++++++++++++++")
	ISOLATED = set()
	DATA = json.loads(content) 
	for elem in DATA['videolists']:
		debug_MS("(navigator.listStartpage) ### ELEMENT : {0} ###".format(str(elem)))
		title = cleaning(elem['title'])
		TVS_idd = str(elem['id'])
		debug_MS("(navigator.listStartpage) ### TITLE = {0} || TYPE = {1} ###".format(title, str(extras)))
		if extras == "complete" or extras == TVS_idd:
			for vid in elem['broadcasts']:
				if 'has_video' in vid and vid['has_video'] is True:
					EP_idd = str(vid['id'])
					if EP_idd in ISOLATED:
						continue
					ISOLATED.add(EP_idd)
					name = cleaning(vid['title'])
					if 'subtitle' in vid and vid['subtitle'] != "" and vid['subtitle'] != None and vid['subtitle'] not in vid['title']:
						name += ' - '+cleaning(vid['subtitle'])
					duration = (vid.get('vod_duration', '0') or '0')
					photo = icon
					if vid.get('images', None):
						max_res = max(vid['images'], key=lambda d: d['resolution'])
						photo = max_res['url']
					genre = None
					genreLIST = []
					if vid.get('genres', None):
						genreLIST = [cleaning(genid.get('title', [])) for genid in vid.get('genres', '')]
						if genreLIST: genre = ' / '.join(sorted(genreLIST))
					addLink(name, photo, {'mode': 'playVideo', 'url': EP_idd}, duration, genre=genre)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(Xidd, origSERIE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	url = BASE_API+'/series/'+Xidd+'?vod_only&broadcast_limit=500'
	content = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listEpisodes) CONTENT : {0}".format(str(content)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(content)
	FOUND = False
	for vid in DATA['series']['broadcasts']:
		if 'has_video' in vid and vid['has_video'] == True:
			genre, mpaa = (None for _ in range(2))
			Note_1 = ""
			photo = icon
			FOUND = True
			EP_idd = str(vid['id'])
			name = cleaning(vid['title'])
			if 'subtitle' in vid and vid['subtitle'] != "" and vid['subtitle'] != None and vid['subtitle'] not in vid['title']:
				name = cleaning(vid['subtitle'])
			duration = (vid.get('vod_duration', '0') or '0')
			if vid.get('images', None):
				max_res = max(vid['images'], key=lambda d: d['resolution'])
				photo = max_res['url']
			genreLIST = []
			if vid.get('genres', None):
				genreLIST = [cleaning(genid.get('title', [])) for genid in vid.get('genres', '')]
				if genreLIST: genre = ' / '.join(sorted(genreLIST))
			if str(vid.get('fsk')) not in ['None', '0', 'nicht definiert']:
				mpaa = translation(30613).format(str(vid.get('fsk')))
			if origSERIE != "": Note_1 = origSERIE+'[CR][CR]'
			desc = (cleaning(vid.get('description', '')) or "")
			plot = Note_1+desc
			debug_MS("(navigator.listEpisodes) ### TITLE = {0} || IDD = {1} || PHOTO = {2} ###".format(name, EP_idd, photo))
			addLink(name, photo, {'mode': 'playVideo', 'url': EP_idd}, duration, plot, genre, mpaa, origSERIE)
	if not FOUND:
		debug_MS("(navigator.listepisodes) ##### Keine Episode in der Liste - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30523), translation(30524).format(origSERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE) 

def playVideo(Xidd):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	url = BASE_API+'/broadcasts/'+Xidd
	content = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.playVideo) CONTENT : {0}".format(str(content)))
	debug_MS("++++++++++++++++++++++++")
	finalURL = json.loads(content)['broadcast']['vod_hls_link']
	log("(playVideo) HLS_stream : {0}".format(finalURL))
	listitem = xbmcgui.ListItem(path=finalURL)
	if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'm3u8' in finalURL:
		listitem.setMimeType('application/vnd.apple.mpegurl')
		listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
		listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
	xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)

def playLIVE():
	debug_MS("(navigator.playLIVE) ------------------------------------------------ START = playLIVE -----------------------------------------------")
	# https://rbmn-live.akamaized.net/hls/live/2002830/geoSTVDEmob/master.m3u8
	# https://rbmn-live.akamaized.net/hls/live/2002825/geoSTVATmob/master.m3u8
	live_url = 'https://rbmn-live.akamaized.net/hls/live/2002830/geoSTVDEweb/master.m3u8'
	title = translation(30614)
	if siteVersion == 'de-at':
		live_url = 'https://rbmn-live.akamaized.net/hls/live/2002825/geoSTVATweb/master.m3u8'
		title = translation(30615)
	debug_MS("(navigator.playLIVE) ### LIVEurl : {0} ###".format(live_url))
	listitem = xbmcgui.ListItem(path=live_url, label=title)
	listitem.setMimeType('application/vnd.apple.mpegurl')
	xbmc.Player().play(item=live_url, listitem=listitem)

def listShowsFavs():
	debug_MS("(navigator.listShowsFavs) ------------------------------------------------ START = listShowsFavs -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if os.path.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as textobj:
			lines = textobj.readlines()
			for line in lines:
				if line.startswith('###START'):
					part = line.split('###')
					addDir(name=part[3], image=part[4], params={'mode': 'listEpisodes', 'url': part[2], 'origSERIE': part[3]}, FAVdel=True)
					debug_MS("(navigator.listShowsFavs) ### TITLE = {0} || IDD = {1} || PHOTO = {2} ###".format(str(part[3]), str(part[2]), str(part[4])))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(elem):
	modus = elem[elem.find('MODE=')+5:+8]
	TVSe = elem[elem.find('###START'):]
	TVSe = TVSe[:TVSe.find('END###')]
	url = TVSe.split('###')[2]
	name = TVSe.split('###')[3]
	if modus == 'ADD':
		NORMAL = declare_Open(channelFavsFile, 'NORMAL')
		PLUS = declare_Open(channelFavsFile, 'PLUS')
		if os.path.exists(channelFavsFile):
			with PLUS as textobj:
				content = textobj.read()
				if content.find(TVSe) == -1:
					textobj.seek(0,2) # change is here (for Windows-Error = "IOError: [Errno 0] Error") - because Windows don't like switching between reading and writing at same time !!!
					textobj.write(py2_uni(TVSe+'END###\n'))
		else:
			with NORMAL as textobj:
				textobj.write(TVSe+'END###\n')
		xbmc.sleep(500)
		dialog.notification(translation(30525), translation(30526).format(name), icon, 8000)
	elif modus == 'DEL':
		with open(channelFavsFile, 'r') as output:
			lines = output.readlines()
		with open(channelFavsFile, 'w') as input:
			for line in lines:
				if url not in line:
					input.write(line)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30525), translation(30527).format(name), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, folder=True, addType=0, FAVdel=False):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	entries = []
	if addType == 1 and FAVdel == False:
		FAVInfos_1 = 'MODE=ADD###START###{0}###{1}###{2}###END###'.format(params.get('url'), params.get('origSERIE'), image)
		entries.append([translation(30651), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'url': str(FAVInfos_1)}))])
	if FAVdel is True:
		FAVInfos_2 = 'MODE=DEL###START###{0}###{1}###{2}###END###'.format(params.get('url'), name, image)
		entries.append([translation(30652), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'url': str(FAVInfos_2)}))])
	liz.addContextMenuItems(entries, replaceItems=False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, duration=None, plot=None, genre=None, mpaa=None, seriesname=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Tvshowtitle'] = seriesname
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Genre'] = genre
	info['Studio'] = 'ServusTV'
	info['Mpaa'] = mpaa
	info['Mediatype'] = 'movie'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
