﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2021 realvito

    Anime on Demand

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
'''

import xbmcaddon
from datetime import datetime
from resources.lib.common import *
from resources.lib import navigator


def run():
	if mode == 'root':
		if addon.getSetting('service_startWINDOW') == 'true':
			lastHM = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
			addon.setSetting('last_starttime', lastHM+' / 01')
			if navigator.Callonce().call_registration(lastHM) is True:
				addon.setSetting('service_startWINDOW', 'false')
			debug_MS("(default.run) ### settings_service_startWINDOW is now = {0} ###".format(str(addon.getSetting('service_startWINDOW'))))
		navigator.mainMenu()
	elif mode == 'unsubscribe':
		navigator.unsubscribe()
	elif mode == 'newsCategory':
		navigator.newsCategory()
	elif mode == 'listAnimeNews':
		navigator.listAnimeNews(url)
	elif mode == 'listArticle':
		navigator.listArticle(url)
	elif mode == 'newOverview':
		navigator.newOverview(url)
	elif mode == 'listAlphabet':
		navigator.listAlphabet()
	elif mode == 'listGenres':
		navigator.listGenres(url)
	elif mode == 'listLanguages':
		navigator.listLanguages()
	elif mode == 'listSeries':
		navigator.listSeries(url)
	elif mode == 'listSimilar':
		navigator.listSimilar(url)
	elif mode == 'listEpisodes':
		navigator.listEpisodes(url, type, origSERIE)
	elif mode == 'playCODE':
		navigator.playCODE(IDENTiTY)
	elif mode == 'listShowsFavs':
		navigator.listShowsFavs()
	elif mode == 'favs':
		navigator.favs(action, name, pict, url, plot, type)
	elif mode == 'blankFUNC':
		pass # do nothing
	elif mode == 'AddToQueue':
		navigator.AddToQueue()
	elif mode == 'aConfigs':
		addon.openSettings()
	elif mode == 'iConfigs':
		xbmcaddon.Addon('inputstream.adaptive').openSettings()

run()
