﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import hashlib
import time
import _strptime
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, unquote_plus  # Python 2.X
else: 
	from urllib.parse import urlencode, unquote_plus  # Python 3.X

from .common import *
from .config import Registration
from .utilities import Transmission
from .visions import Infowindow


class Callonce(object):

	def __init__(self):
		self.config = Registration
		self.utilities = Transmission
		self.called = False

	def login_answer(self):
		if self.config().has_credentials() is True:
			USER, PWD = self.config().get_credentials()
		else:
			USER, PWD = self.config().save_credentials()
		if self.utilities().login(USER, PWD) is True:
			debug_MS("(navigator.login_answer) ##### Alles gefunden - Anmeldung Erfolg #####")
			dialog.notification(translation(30526).format('LOGIN'), translation(30527), icon, 8000)
			xbmc.executebuiltin('Container.Refresh')
			return True
		else:
			debug_MS("(navigator.login_answer) ##### NICHTS gefunden - ErrorMeldung #####")
			dialog.notification(translation(30521).format('Login'), translation(30528), icon, 12000)
		return False

	def call_registration(self, lastHM):
		nowHM = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
		if lastHM != nowHM:
			addon.setSetting('last_starttime', nowHM+' / 02')
		if not self.called:
			addon.setSetting('without_Account', 'true')
			self.called = True
			if START_MODUS == '0':
				choose = dialog.yesno(addon_id, translation(30502).format(addon_name), nolabel=translation(30503), yeslabel=translation(30504))
				if choose == -1: return False
				if choose:
					debug_MS("(navigator.call_registration) ### START_MODUS = NULL - eins ###")
					addon.setSetting('select_start', '0')
					if self.login_answer() is True:
						addon.setSetting('without_Account', 'false')
						return True
				else:
					debug_MS("(navigator.call_registration) ### START_MODUS = NULL - zwei ###")
					addon.setSetting('select_start', '0')
					addon.setSetting('without_Account', 'true')
					addon.setSetting('login_successfully', 'false')
					addon.setSetting('show_teaser', 'true')
					return True
			if START_MODUS == '1':
				debug_MS("(navigator.call_registration) ### START_MODUS = EINS ###")
				if self.login_answer() is True:
					addon.setSetting('without_Account', 'false')
					return True
			if START_MODUS == '2':
				debug_MS("(navigator.call_registration) ### START_MODUS = ZWEI ###")
				addon.setSetting('without_Account', 'true')
				addon.setSetting('login_successfully', 'false')
				addon.setSetting('show_teaser', 'true')
				return True
			return False
		xbmcplugin.endOfDirectory(ADDON_HANDLE)

def getUrl(url, way='Standard', REFERER='Unknown'):
	content = Transmission().retrieveContent(url, 'GET', way, REFERER)
	return content

def mainMenu():
	addDir(translation(30601), artpic+'favourites.png', {'mode': 'listShowsFavs'})
	addDir(translation(30602), icon, {'mode': 'newsCategory'})
	addDir(translation(30603), icon, {'mode': 'newOverview', 'url': 'Neue Episoden'})
	addDir(translation(30604), icon, {'mode': 'newOverview', 'url': 'Neue Simulcasts'})
	addDir(translation(30605), icon, {'mode': 'newOverview', 'url': 'Neue Anime-Titel'})
	addDir(translation(30606), icon, {'mode': 'newOverview', 'url': 'Anime Top 10'})
	addDir(translation(30607), icon, {'mode': 'listSeries', 'url': BASE_URL+'/animes'})
	addDir(translation(30608), icon, {'mode': 'listAlphabet'})
	addDir(translation(30609), icon, {'mode': 'listGenres', 'url': BASE_URL+'/animes'})
	addDir(translation(30610), icon, {'mode': 'listLanguages'})
	TEXTBOX = ""
	if addon.getSetting('login_successfully') == 'true':
		TEXTBOX = translation(30631).format(addon.getSetting('username'))
	else:
		TEXTBOX = translation(30632)
	if enableADJUSTMENT:
		addDir(translation(30611)+TEXTBOX, artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30612), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	else:
		addDir(TEXTBOX, icon, {'mode': 'None'})
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def unsubscribe():
	if xbmcvfs.exists(cookieFile) and Transmission().logout() is True:
		dialog.notification(translation(30526).format('Neue SESSION'), translation(30527), icon, 8000)
		return True
	return False

def newsCategory():
	debug_MS("(navigator.newsCategory) ------------------------------------------------ START = newsCategory -----------------------------------------------")
	addDir(translation(30613), icon, {'mode': 'listAnimeNews', 'url': BASE_URL+'/articles/category/3/1'})
	addDir(translation(30614), icon, {'mode': 'listAnimeNews', 'url': BASE_URL+'/articles/category/2/1'})
	addDir(translation(30615), icon, {'mode': 'listAnimeNews', 'url': BASE_URL+'/articles/category/1/1'})
	addDir(translation(30616), icon, {'mode': 'listAnimeNews', 'url': BASE_URL+'/articles/category/4/1'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listAnimeNews(url):
	debug_MS("(navigator.listAnimeNews) ------------------------------------------------ START = listAnimeNews -----------------------------------------------")
	debug_MS("(navigator.listAnimeNews) ~~~~~ URL : {0} ~~~~~".format(url))
	content = getUrl(url, 'Standard', url)
	spl = content.split('<div class="category-item">') 
	for i in range(1, len(spl), 1):
		entry = spl[i]
		debug_MS("(navigator.listAnimeNews) ### ENTRY : {0} ###".format(str(entry)))
		match = re.compile('<a href="(.+?)">(.+?)</a>', re.S).findall(entry)
		link = match[0][0]
		name = cleaning(match[0][1])
		link = BASE_URL+link if link[:4] != "http" else link
		photo = re.compile('src="([^"]+)"', re.S).findall(entry)[0]
		photo = BASE_URL+photo if photo[:4] != "http" else photo
		try: plot = cleaning(re.compile('alt=".*?></a>(.+?)<br />', re.S).findall(entry)[0])
		except: plot = ""
		if not "aod auf der" in name.lower():
			addDir(name, photo, {'mode': 'listArticle', 'url': link}, plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listArticle(url):
	debug_MS("(navigator.listArticle) ------------------------------------------------ START = listArticle -----------------------------------------------")
	content = getUrl(url, 'Standard', url)
	window = Infowindow(content)
	window.doModal()
	del window

def newOverview(elem):
	debug_MS("(navigator.newOverview) ------------------------------------------------ START = newOverview -----------------------------------------------")
	debug_MS("(navigator.newOverview) ~~~~~ ELEMENT : {0} ~~~~~".format(elem))
	content = getUrl(BASE_URL, 'Standard', BASE_URL)
	results = re.findall('<h2>{0}</h2>(.+?)</ul>'.format(elem), content, re.S)
	for chtml in results:
		spl = chtml.split('<li>')
		for i in range(1, len(spl), 1):
			entry = spl[i]
			debug_MS("(navigator.newOverview) ### ENTRY : {0} ###".format(str(entry)))
			photo = re.compile('src="([^"]+)"', re.S).findall(entry)[0]
			photo = BASE_URL+photo if photo[:4] != "http" else photo
			match = re.compile('<a href="(.+?)">(.+?)</a>', re.S).findall(entry)
			link = match[0][0]
			name = cleaning(match[0][1])
			origSERIE = name
			cineType = 'episode'
			if '/films' in photo:
				cineType = 'movie'
				name = "[I]"+name+"[/I]"
				if no_Movies: continue
			link = BASE_URL+link if link[:4] != "http" else link
			try :
				EP = re.compile('<span class="neweps">(.+?)</span>', re.S).findall(entry)[0]
				name +="  ("+cleaning(EP)+")"
			except: pass
			name = re.sub(r'\<.*?\>', '', name)
			if sel_CAT == '0' or (checking(name) is False and sel_CAT == '1') or (checking(name) is True and sel_CAT == '2'):
				addDir(name, photo, {'mode': 'listEpisodes', 'url': link, 'type': cineType, 'origSERIE': origSERIE})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listAlphabet():
	debug_MS("(navigator.listAlphabet) ------------------------------------------------ START = listAlphabet -----------------------------------------------")
	for letter in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
		addDir(letter, icon, {'mode': 'listSeries', 'url': BASE_URL+'/animes/begins_with/'+letter.replace('#', '0-9')})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGenres(url):
	debug_MS("(navigator.listGenres) ------------------------------------------------ START = listGenres -----------------------------------------------")
	debug_MS("(navigator.listGenres) ~~~~~ URL : {0} ~~~~~".format(url))
	content = getUrl(url, 'Standard', url)
	match = re.findall('<a href="(/animes/genre/[^"]+)">([^<]+)</a>', content, re.S)
	for link, name in match:
		debug_MS("(navigator.listGenres) XXX NAME = {0} || LINK = {1} XXX".format(cleaning(name), BASE_URL+link))
		addDir(cleaning(name).title(), icon, {'mode': 'listSeries', 'url': BASE_URL+link})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
 
def listLanguages():
	debug_MS("(navigator.listLanguages) ------------------------------------------------ START = listLanguages -----------------------------------------------")
	addDir(translation(30617), icon, {'mode': 'listSeries', 'url': BASE_URL+'/animes/nonomu'})
	addDir(translation(30618), icon, {'mode': 'listSeries', 'url': BASE_URL+'/animes/omu'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeries(url):
	debug_MS("(navigator.listSeries) ------------------------------------------------ START = listSeries -----------------------------------------------")
	debug_MS("(navigator.listSeries) ~~~~~ URL : {0} ~~~~~".format(url))
	content = getUrl(url, 'Standard', url)
	results = re.findall('<div class="three-box-container">(.+?)<div class="l-contentcontainer l-navigationscontainer">', content, re.S)
	for chtml in results:
		spl = chtml.split('<div class="three-box animebox">')
		for i in range(1,len(spl),1):
			entry=spl[i]
			debug_MS("(navigator.listSeries) ### ENTRY : {0} ###".format(str(entry)))
			title = re.compile('<h3 class="animebox-title">([^<]+)</h3>', re.S).findall(entry)[0]
			name = cleaning(title)
			photo = re.compile('<img src="([^"]+)"', re.S).findall(entry)[0]
			photo = BASE_URL+photo if photo[:4] != "http" else photo
			cineType = 'episode'
			if '/films' in photo or 'zum Film' in entry:
				cineType = 'movie'
				name = "[I]"+name+"[/I]"
				if no_Movies: continue
			SE_link = re.compile('<a href="([^"]+)">', re.S).findall(entry)[0]
			SE_link = BASE_URL+SE_link if SE_link[:4] != "http" else SE_link
			try: 
				desc = re.compile('<p class="animebox-shorttext[^>]*>(.*?)</div>', re.S).findall(entry)[0]
				desc = re.sub('\<.*?\>', '', desc)
				plot = cleaning(desc)
			except: plot = ""
			addType = 1
			if xbmcvfs.exists(channelFavsFile):
				with open(channelFavsFile, 'r') as fp:
					favorites = json.load(fp)
					for item in favorites['items']:
						if item['url'] == SE_link: addType = 2
			if sel_CAT == '0' or (checking(name) is False and sel_CAT == '1') or (checking(name) is True and sel_CAT == '2'):
				addDir(name, photo, {'mode': 'listEpisodes', 'url': SE_link, 'type': cineType, 'origSERIE': name}, plot, addType)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSimilar(url):
	debug_MS("(navigator.listSimilar) ------------------------------------------------ START = listSimilar -----------------------------------------------")
	debug_MS("(navigator.listSimilar) ~~~~~ URL : {0} ~~~~~".format(url))
	content = url[url.find('<div class="jcarousel">')+1:]
	content = content[:content.find('</div>')]
	match = re.compile('<img height=".+?" src="([^"]+)".+?<a href="([^"]+)">([^<]+)</a>', re.S).findall(content)
	for photo, link, title in match:
		photo = BASE_URL+photo if photo[:4] != "http" else photo
		name = cleaning(title)
		cineType = 'episode'
		if '/films' in photo:
			cineType = 'movie'
			name = "[I]"+name+"[/I]"
			if no_Movies: continue
		debug_MS("(navigator.listSimilar) XXX NAME = {0} || LINK = {1} || PHOTO = {2} XXX".format(name, BASE_URL+link, photo))
		addDir(name, photo, {'mode': 'listEpisodes', 'url': BASE_URL+link, 'type': cineType, 'origSERIE': name})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, type, origSERIE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS("(navigator.listEpisodes) ~~~~~ URL : {0} || cineType : {1} || origSERIE : {2} ~~~~~".format(params.get('url'), params.get('type'), params.get('origSERIE')))
	COMBI_EPISODE, COMBI_TEASER, MISC_RESULT = ([] for _ in range(3))
	pos1 = 0
	pos2 = 0
	old_REF = url
	seriesname = unquote_plus(origSERIE)
	content = getUrl(url, 'Standard', url)
	new_csrftoken = re.compile('<meta name="csrf-token" content="([^"]+)"', re.S).findall(content)[0]
	debug_MS("(navigator.listEpisodes) ### CSRF_Token = {0} ###".format(new_csrftoken))
	addon.setSetting('csrftoken', new_csrftoken)
	results = re.findall('<div class="l-mainsection ">(.+?)<div class="l-contentcontainer l-navigationscontainer">', content, re.S)
	for chtml in results:
		debug_MS("(navigator.listEpisodes) ### CONTENT : {0} ###".format(str(chtml)))
		year, country, genre, mpaa = (None for _ in range(4))
		try:
			table = re.compile('<table class="vertical-table">(.+?)<th>Mehr Infos auf</th>', re.S).findall(chtml)[0]
			specials = re.findall('<th>([^<]+)</th.*?<td>([^<]+)</td>', table, re.S)
			for CAT, WORDS in specials:
				CAT = cleaning(re.sub('[{@$%#^\\/;,:*?!\"+<>|}]\n', '', CAT))
				WORDS = cleaning(re.sub('[{@$%#^\\/;,:*?!\"+<>|}]\n', '', WORDS))
				if 'produktion' in CAT.lower():
					year = WORDS
				elif 'sprache' in CAT.lower():
					country = WORDS
				elif 'genre' in CAT.lower():
					genre = WORDS
				elif 'fsk' in CAT.lower() and str(WORDS) != '0':
					mpaa = 'Ab '+str(WORDS)+' Jahren'
		except: pass
		if '<h2>&Auml;hnliche Animes</h2>' in chtml:
			addDir(translation(30619), icon, {'mode': 'listSimilar', 'url': chtml})
		if 'alert alert-danger alert-hideable">Anime nicht gefunden' in chtml:
			return dialog.notification(translation(30522).format('Einträge'), translation(30525).format(origSERIE), icon, 8000)
		if '<div class="three-box episodebox flip-container">' in chtml and type == 'episode':
			part = chtml.split('<div class="three-box episodebox flip-container">')
		else:
			part = chtml.split('<div class="l-maincontent l-contentcontainer">')
		for i in range(1, len(part), 1):
			entry = part[i]
			debug_MS("(navigator.listEpisodes) ### ENTRY : {0} ###".format(str(entry)))
			plot, title = ("" for _ in range(2))
			episode = '0'
			if type == 'episode':
				title_1 = re.findall('<h3 class="episodebox-title" title.*?>(.+?)</h3>', entry, re.S)
				title_2 = re.findall('<h4>(.+?)</h4>', entry, re.S)
				if title_1: title = title_1[0]
				if title == "" and title_2: title = title_2[0]
				image = re.compile('src="([^"]+)"', re.S).findall(entry)[0]
				try: plot = re.compile('<p class="episodebox-shorttext[^>]*>(.*?)</div>', re.S).findall(entry)[0]
				except: pass
			else:
				title = re.compile('<h1 itemprop="name">(.+?)</h1>', re.S).findall(entry)[0]
				image = re.compile('itemprop="image" src="([^"]+)"', re.S).findall(entry)[0]
				try: plot = re.compile('<div itemprop="description[^>]*>(.*?)</div>', re.S).findall(entry)[0]
				except: pass
			name = cleaning(title)
			if 'Episode' or 'Folge' in name:
				try:
					episode = re.findall('([0-9]+)', name, re.S)[0].strip().zfill(4)
					pos1 += 1
				except: pass
			else: pos2 += 1
			image = BASE_URL+image if image[:4] != "http" else image
			if plot != "":
				plot = cleaning(re.sub('\<.*?\>', '', plot))
			data_STREAMS = re.search(r'title=["\'](?:Japanischen Stream|Deutschen Stream).*?data-playlist=', entry)
			if data_STREAMS and LOGIN_STATUS == 'true':
				debug_MS("(navigator.listEpisodes) ##### data_STREAMS = GEFUNDEN und LOGIN_STATUS = TRUE || Liste jetzt die gefundenen Episoden #####")
				EP_found = re.findall('title="([^"]+)" data-playlist="([^"]+)"', entry, re.S)
				for EP_type, EP_link in EP_found:
					if 'Deutschen Stream' in EP_type:
						CPL = name+'  [COLOR lime](Dub)[/COLOR]'
					if 'Japanischen Stream' in EP_type:
						CPL = name+'  [COLOR lime](OmU)[/COLOR]'
					if type == 'movie': CPL = '[I]'+CPL+'[/I]'
					endURL = BASE_URL+EP_link
					extras = old_REF
					COMBI_EPISODE.append([episode, CPL, image, endURL, plot, seriesname, genre, year, country, mpaa, type, extras, pos1, pos2])
			if '<a class="streamstarter" data-stream=' in entry and enableTEASER:
				debug_MS("(navigator.listEpisodes) ##### streamstarter = GEFUNDEN und enableTEASER = TRUE || Liste jetzt die gefundenen Teaser #####")
				teaser = re.findall('<a class="streamstarter" data-stream="([^"]+)"', entry, re.S)[0]
				CPL = name+'  [COLOR orangered](Teaser)[/COLOR]'
				endURL = unquote_plus(BASE_URL+teaser)
				extras = 'Teaser'
				COMBI_TEASER.append([episode, CPL, image, endURL, plot, seriesname, genre, year, country, mpaa, type, extras, pos1, pos2])
	if COMBI_EPISODE or COMBI_TEASER:
		MISC_RESULT = COMBI_EPISODE + COMBI_TEASER
		if pos2 <= 5 and (SORTING == '1' or SORTING == '2'):
			COURSE = False if SORTING == '2' else True
			MISC_RESULT = sorted(MISC_RESULT, key=lambda d:d[0], reverse=COURSE)
		SEND = {}
		SEND['videos'] = []
		for episode, CPL, image, endURL, plot, seriesname, genre, year, country, mpaa, type, extras, pos1, pos2 in MISC_RESULT:
			if sel_CAT == '0' or (checking(CPL) is False and sel_CAT == '1') or (checking(CPL) is True and sel_CAT == '2'):
				HLnom = hashlib.md5(py2_uni(endURL.split('/')[-1]+'-'+CPL).encode('utf-8')).hexdigest()
				listitem = xbmcgui.ListItem(CPL, path=HOST_AND_PATH+'?IDENTiTY='+HLnom+'&mode=playCODE')
				info = {}
				info['Episode'] = episode
				if seriesname is not None:
					info['Tvshowtitle'] = seriesname
				if CPL is not None:
					info['Title'] = CPL
				info['Tagline'] = None
				if plot is not None:
					info['Plot'] = plot
				info['Duration'] = '0'
				info['Year'] = year
				info['Country'] = country
				info['Genre'] = genre
				info['Director'] = None
				info['Writer'] = None
				info['Studio'] = 'AoD'
				info['Mpaa'] = mpaa
				info['Mediatype'] = type
				listitem.setInfo(type='Video', infoLabels=info)
				listitem.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
				if image and useThumbAsFanart and image != icon and not artpic in image:
					listitem.setArt({'fanart': image})
				listitem.setProperty('IsPlayable', 'true')
				listitem.setContentLookup(False)
				listitem.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
				xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+HLnom+'&mode=playCODE', listitem=listitem)
				SEND['videos'].append({'url': endURL, 'tvshow': seriesname, 'filter': HLnom, 'name': CPL, 'pict': image, 'episode': episode, 'extras': extras})
				with open(WORKFILE, 'w') as ground:
					json.dump(SEND, ground, indent=4, sort_keys=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def get_newTOKEN(url, STREAMFILE):
	content = getUrl(url, 'Standard', url)
	new_csrftoken = re.compile('<meta name="csrf-token" content="([^"]+)"', re.S).findall(content)[0]
	addon.setSetting('csrftoken', new_csrftoken)
	xbmc.sleep(1000)
	STREAMTEXT = getUrl(STREAMFILE, 'playCODE', url)
	STREAMS = STREAMTEXT.splitlines()
	debug_MS("(navigator.get_newTOKEN) ### cacheData for STREAMS = {0} ###".format(STREAMS))
	return STREAMS

def playCODE(IDD):
	debug_MS("(navigator.playCODE) ------------------------------------------------ START = playCODE -----------------------------------------------")
	finalURL = False
	manifest_type = False
	MEDIAS, file_Names, file_Streams = ([] for _ in range(3))
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] == IDD:
				endURL = elem['url']
				seriesname = cleaning(elem['tvshow'])
				name = cleaning(elem['name'])
				image = elem['pict']
				episode = elem['episode']
				extras = cleaning(elem['extras'])
	if extras == 'Teaser':
		finalURL = endURL.replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%2D','-').replace('%5F','_').replace('%3B',';').split('url=')[1]
	else:
		oldURL = extras
		content = getUrl(endURL, 'playCODE', oldURL)
		js = json.loads(content)
		STREAMFILE = js['playlist'][0]['sources'][0]['file'].replace("\\u0026","&")
		debug_MS("(navigator.playCODE) ### This is the STREAM-ADRESS = {0} ###".format(STREAMFILE))
		firstURL = STREAMFILE.replace('chunklist', '.m3u8').replace('playlist', '.m3u8').split('.m3u8', 1)[0]
		firstRESULT = re.sub(r'(?:chunklist.m3u8|playlist.m3u8|index|master)', '', firstURL)
		if ('Original' in QUALITY or enableINPUTSTREAM):
			debug_MS("(navigator.playCODE) ### MODUS = Original ###")
			finalURL = STREAMFILE
		if not finalURL and QUALITY.split('-')[1] in ['1081', '1080', '720', '576', '540', '480', '360']:
			debug_MS("(navigator.playCODE) ### MODUS = Selected Quality-Step ###")
			STREAMS = get_newTOKEN(oldURL, STREAMFILE)
			for i in range(0, len(STREAMS)):
				infoSTREAM_2 = STREAMS[i]
				firstTEXT = QUALITY.split('-')[0]
				secondTEXT = QUALITY.split('-')[1]
				index_Bandwith = re.search(r'INF:BANDWIDTH={0},'.format(firstTEXT), infoSTREAM_2)
				index_Resolution = re.search(r'RESOLUTION=[0-9]+x{0},?'.format(secondTEXT), infoSTREAM_2)
				if index_Bandwith or index_Resolution:
					newSTREAM_2 = STREAMS[i + 1]
					finalURL = firstRESULT+newSTREAM_2
					debug_MS("(navigator.playCODE) XXX AUSWAHL = {0} || LINE = {1} || STREAM = {2} XXX".format(QUALITY, infoSTREAM_2, newSTREAM_2))
		if not finalURL and ('Highest' in QUALITY or QUALITY.split('-')[0] not in ['Original', 'Select']):
			debug_MS("(navigator.playCODE) ### MODUS = Highest Quality ###")
			STREAMS = get_newTOKEN(oldURL, STREAMFILE)
			for i in range(0, len(STREAMS)):
				infoSTREAM_3 = STREAMS[i]
				if 'INF:BANDWIDTH=' in infoSTREAM_3:
					try: 	the_Bandwith = re.findall('AVERAGE-BANDWIDTH=([0-9]+),?', infoSTREAM_3, re.S)[0]
					except: the_Bandwith = re.findall('INF:BANDWIDTH=([0-9]+),', infoSTREAM_3, re.S)[0]
					converted_BW = int(the_Bandwith)/1024
					onlyLeft_BW = "{0:.0f}".format(converted_BW).zfill(5)
					newSTREAM_3 = STREAMS[i + 1]
					MEDIAS.append({'url': newSTREAM_3, 'bandwith': str(onlyLeft_BW), 'type': 'm3u8'})
			debug_MS("(navigator.playCODE) ### MEDIAS-[UNSORTED] = {0} ###".format(str(MEDIAS)))
			MEDIAS = sorted(MEDIAS, key=lambda k: k['bandwith'], reverse=True)
			debug_MS("(navigator.playCODE) ### MEDIAS-[SORTED] = {0} ###".format(str(MEDIAS)))
			finalURL = firstRESULT+MEDIAS[0]['url']
		if not finalURL:
			debug_MS("(navigator.playCODE) ### last MODUS = Other not found or Manual-Select-Quality ###")
			STREAMS = get_newTOKEN(oldURL, STREAMFILE)
			for i in range(0, len(STREAMS)):
				infoSTREAM_4 = STREAMS[i]
				if 'INF:BANDWIDTH=' in infoSTREAM_4:
					match = re.compile(r'INF:BANDWIDTH=([0-9]+),(?:AVERAGE-BANDWIDTH=[0-9]+,)?RESOLUTION=([0-9]+x[0-9]+)(?:,FRAME-RATE=)?', re.S).findall(infoSTREAM_4)
					for bandWT, RES in match:
						converted_BW = int(bandWT)/1024
						onlyLeft_BW = "{0:.0f}".format(converted_BW)
						file_Names.append('Source:  Auflösung '+str(RES)+'  [COLOR yellow](Geschw. '+str(onlyLeft_BW)+' kb/s)[/COLOR]')
				if any(x in infoSTREAM_4 for x in ['Signature=', 'Policy=', 'chunklist']):
						file_Streams.append(infoSTREAM_4)
			getNF = dialog.select('Wählen Sie die bevorzugte Qualität', file_Names, preselect=0)
			if getNF == -1: return
			resURL = str(file_Streams[getNF])
			finalURL = firstRESULT+resURL
			debug_MS("(navigator.playCODE) XXX NAME : {0} || STREAM-Selected : {1} XXX".format(resURL, finalURL))
	log("(navigator.playCODE) ### THIS IS THE FINALURL = {0} ###".format(str(finalURL)))
	if finalURL:
		listitem=xbmcgui.ListItem(path=finalURL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			if 'dash' in finalURL or '.mpd' in finalURL:
				manifest_type = 'mpd'
				mime_type = 'application/dash+xml'
			elif 'hls' in finalURL or '.m3u8' in finalURL:
				manifest_type = 'hls'
				mime_type = 'application/x-mpegURL'
		if manifest_type:
			listitem.setMimeType(mime_type)
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', manifest_type)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playCODE) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *kika.de* gefunden !!! ##########".format(endURL))
		return dialog.notification(translation(30521).format('STREAM'), translation(30530), icon, 8000)

def listShowsFavs():
	debug_MS("(navigator.listShowsFavs) ------------------------------------------------ START = listShowsFavs -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as fp:
			favorites = json.load(fp)
			for item in favorites['items']:
				name = cleaning(item['name'])
				logo = icon if item['pict'] == 'None' else item['pict']
				desc = None if item['plot'] == 'None' else cleaning(item['plot'].replace('#n#', '\n'))
				debug_MS("(navigator.listShowsFavs) ### NAME : {0} || URL : {1} || IMAGE : {2} || cineType : {3} ###".format(name, item['url'], logo, item['type']))
				addDir(name, logo, {'mode': 'listEpisodes', 'url': item['url'], 'type': item['type'], 'origSERIE': name}, desc, FAVdel=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(action, name, pict, url, plot, type):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'name': name, 'pict': pict, 'url': url, 'plot': plot, 'type': type})
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30531), translation(30532).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('url') != url]
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30531), translation(30533).format(name), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, addType=0, FAVdel=False, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	entries = []
	if addType == 1 and FAVdel is False:
		entries.append([translation(30651), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'action': 'ADD', 'name': params.get('origSERIE'), 'pict': 'None' if image == icon else image, 'url': params.get('url'), 'plot': 'None' if plot == None else plot.replace('\n', '#n#'), 'type': params.get('type')}))])
	if FAVdel is True:
		entries.append([translation(30652), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'action': 'DEL', 'name': name, 'pict': image, 'url': params.get('url'), 'plot': plot, 'type': params.get('type')}))])
	liz.addContextMenuItems(entries, replaceItems=False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
