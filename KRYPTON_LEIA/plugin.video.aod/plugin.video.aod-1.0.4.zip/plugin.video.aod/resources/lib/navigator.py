﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import hashlib
import io
from datetime import datetime
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, unquote_plus  # Python 2.X
else: 
	from urllib.parse import urlencode, unquote_plus  # Python 3.X

from .common import *
from .config import Registration
from .session_helper import Transmission
from .visions import Infowindow


class Callonce(object):

	def __init__(self):
		self.config = Registration
		self.session_helper = Transmission
		self.called = False

	def login_answer(self):
		if self.config().has_credentials():
			USER, PWD = self.config().get_credentials()
		else:
			USER, PWD = self.config().save_credentials()
		if self.session_helper().login(USER, PWD) is False:
			debug_MS("(navigator.login_answer) ##### NICHTS gefunden - ErrorMeldung #####")
			dialog.notification(translation(30521).format('Login'), translation(30528), icon, 12000)
			return False
		else:
			debug_MS("(navigator.login_answer) ##### Alles gefunden - Anmeldung Erfolg #####")
			dialog.notification(translation(30526).format('LOGIN'), translation(30527), icon, 8000)
		return True

	def call_registration(self, lastHM):
		nowHM = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
		if lastHM != nowHM:
			addon.setSetting('last_starttime', nowHM+' / 02')
		if not self.called:
			addon.setSetting('without_Account', 'true')
			self.called = True
			if START_MODUS == '0':
				choose = dialog.yesno(addon_id, translation(30502).format(addon_name), nolabel=translation(30503), yeslabel=translation(30504))
				if choose == -1: return False
				if choose:
					debug_MS("(navigator.call_registration) ### START_MODUS = NULL - eins ###")
					addon.setSetting('select_start', '0')
					processed = self.login_answer()
					if processed is True:
						addon.setSetting('without_Account', 'false')
						return True
				else:
					debug_MS("(navigator.call_registration) ### START_MODUS = NULL - zwei ###")
					addon.setSetting('select_start', '0')
					addon.setSetting('without_Account', 'true')
					addon.setSetting('login_successfully', 'false')
					addon.setSetting('show_teaser', 'true')
					return True
			elif START_MODUS == '1':
				debug_MS("(navigator.call_registration) ### START_MODUS = EINS ###")
				processed = self.login_answer()
				if processed is True:
					addon.setSetting('without_Account', 'false')
					return True
			elif START_MODUS == '2':
				debug_MS("(navigator.call_registration) ### START_MODUS = ZWEI ###")
				addon.setSetting('without_Account', 'true')
				addon.setSetting('login_successfully', 'false')
				addon.setSetting('show_teaser', 'true')
				return True
		return False
		xbmcplugin.endOfDirectory(ADDON_HANDLE)


def getUrl(url, way='Standard', REFERER='Unknown'):
	content = Transmission().retrieveContent(url, 'GET', True, way, REFERER)
	return content

def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listShowsFavs'})
	addDir(translation(30602), icon, {'mode': 'newsCategory'})
	addDir(translation(30603), icon, {'mode': 'newOverview', 'url': 'Neue Episoden'})
	addDir(translation(30604), icon, {'mode': 'newOverview', 'url': 'Neue Simulcasts'})
	addDir(translation(30605), icon, {'mode': 'newOverview', 'url': 'Neue Anime-Titel'})
	addDir(translation(30606), icon, {'mode': 'newOverview', 'url': 'Anime Top 10'})
	addDir(translation(30607), icon, {'mode': 'listSeries', 'url': BASE_URL+'/animes'})
	addDir(translation(30608), icon, {'mode': 'listAlphabet'})
	addDir(translation(30609), icon, {'mode': 'listGenres', 'url': BASE_URL+'/animes'})
	addDir(translation(30610), icon, {'mode': 'listLanguages'})
	TEXTBOX = ""
	if addon.getSetting('login_successfully') == 'true':
		TEXTBOX = translation(30631).format(addon.getSetting('username'))
	else:
		TEXTBOX = translation(30632)
	if enableADJUSTMENT:
		addDir(translation(30611)+TEXTBOX, artpic+'settings.png', {'mode': 'aSettings'})
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30612), artpic+'settings.png', {'mode': 'iSettings'})
		else:
			addon.setSetting('useInputstream', 'false')
	else:
		addDir(TEXTBOX, icon, {'mode': 'None'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def want_Logout():
	if params.get('mode') == 'logout':
		if xbmcvfs.exists(cookieFile) and Transmission().logout() is True:
			dialog.notification(translation(30526).format('Neue SESSION'), translation(30527), icon, 8000)
			return True
	return False

def newsCategory():
	debug_MS("(navigator.newsCategory) ------------------------------------------------ START = newsCategory -----------------------------------------------")
	addDir(translation(30613), icon, {'mode': 'listAnimeNews', 'url': BASE_URL+'/articles/category/3/1'})
	addDir(translation(30614), icon, {'mode': 'listAnimeNews', 'url': BASE_URL+'/articles/category/2/1'})
	addDir(translation(30615), icon, {'mode': 'listAnimeNews', 'url': BASE_URL+'/articles/category/1/1'})
	addDir(translation(30616), icon, {'mode': 'listAnimeNews', 'url': BASE_URL+'/articles/category/4/1'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listAnimeNews(url):
	debug_MS("(navigator.listAnimeNews) ------------------------------------------------ START = listAnimeNews -----------------------------------------------")
	debug_MS("(navigator.listAnimeNews) ~~~~~ URL : {0} ~~~~~".format(url))
	content = getUrl(url, 'Standard', url)
	spl = content.split('<div class="category-item">') 
	for i in range(1, len(spl), 1):
		entry = spl[i]
		debug_MS("(navigator.listAnimeNews) ### ENTRY : {0} ###".format(str(entry)))
		match = re.compile('<a href="(.+?)">(.+?)</a>', re.DOTALL).findall(entry)
		link = match[0][0]
		name = cleaning(match[0][1])
		link = BASE_URL+link if link[:4] != "http" else link
		photo = re.compile('src="([^"]+)"', re.DOTALL).findall(entry)[0]
		photo = BASE_URL+photo if photo[:4] != "http" else photo
		if not "aod auf der" in name.lower():
			addDir(name, photo, {'mode': 'listArticle', 'url': link})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listArticle(url):
	debug_MS("(navigator.listArticle) ------------------------------------------------ START = listArticle -----------------------------------------------")
	content = getUrl(url, 'Standard', url)
	window = Infowindow(text=content)
	window.doModal()
	del window

def newOverview(elem):
	debug_MS("(navigator.newOverview) ------------------------------------------------ START = newOverview -----------------------------------------------")
	debug_MS("(navigator.newOverview) ~~~~~ ELEMENT : {0} ~~~~~".format(elem))
	content = getUrl(BASE_URL, 'Standard', BASE_URL)
	results = re.findall('<h2>{0}</h2>(.+?)</ul>'.format(elem), content, re.S)
	for chtml in results:
		spl = chtml.split('<li>')
		for i in range(1, len(spl), 1):
			entry = spl[i]
			debug_MS("(navigator.newOverview) ### ENTRY : {0} ###".format(str(entry)))
			photo = re.compile('src="([^"]+)"', re.DOTALL).findall(entry)[0]
			photo = BASE_URL+photo if photo[:4] != "http" else photo
			match = re.compile('<a href="(.+?)">(.+?)</a>', re.DOTALL).findall(entry)
			link = match[0][0]
			name = cleaning(match[0][1])
			origSERIE = name
			cineType = 'episode'
			if '/films' in photo:
				cineType = 'movie'
				name = "[I]"+name+"[/I]"
				if no_Movies: continue
			link = BASE_URL+link if link[:4] != "http" else link
			try :
				EP = re.compile('<span class="neweps">(.+?)</span>', re.DOTALL).findall(entry)[0]
				name +="  ("+cleaning(EP)+")"
			except: pass
			name = re.sub(r'\<.*?\>', '', name)
			if sel_CAT == '0' or (checking(name) is False and sel_CAT == '1') or (checking(name) is True and sel_CAT == '2'):
				addDir(name, photo, {'mode': 'listEpisodes', 'url': link, 'cineType': cineType, 'origSERIE': origSERIE})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listAlphabet():
	debug_MS("(navigator.listAlphabet) ------------------------------------------------ START = listAlphabet -----------------------------------------------")
	for letter in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
		addDir(letter, icon, {'mode': 'listSeries', 'url': BASE_URL+'/animes/begins_with/'+letter.replace('#', '0-9')})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGenres(url):
	debug_MS("(navigator.listGenres) ------------------------------------------------ START = listGenres -----------------------------------------------")
	debug_MS("(navigator.listGenres) ~~~~~ URL : {0} ~~~~~".format(url))
	content = getUrl(url, 'Standard', url)
	match = re.findall('<a href="(/animes/genre/[^"]+)">([^<]+)</a>', content, re.S)
	for link, name in match:
		debug_MS("(navigator.listGenres) XXX NAME = {0} || LINK = {1} XXX".format(cleaning(name), BASE_URL+link))
		addDir(cleaning(name).title(), icon, {'mode': 'listSeries', 'url': BASE_URL+link})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
 
def listLanguages():
	debug_MS("(navigator.listLanguages) ------------------------------------------------ START = listLanguages -----------------------------------------------")
	addDir(translation(30617), icon, {'mode': 'listSeries', 'url': BASE_URL+'/animes/nonomu'})
	addDir(translation(30618), icon, {'mode': 'listSeries', 'url': BASE_URL+'/animes/omu'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeries(url):
	debug_MS("(navigator.listSeries) ------------------------------------------------ START = listSeries -----------------------------------------------")
	debug_MS("(navigator.listSeries) ~~~~~ URL : {0} ~~~~~".format(url))
	content = getUrl(url, 'Standard', url)
	results = re.findall('<div class="three-box-container">(.+?)<div class="l-contentcontainer l-navigationscontainer">', content, re.S)
	for chtml in results:
		spl = chtml.split('<div class="three-box animebox">')
		for i in range(1,len(spl),1):
			entry=spl[i]
			debug_MS("(navigator.listSeries) ### ENTRY : {0} ###".format(str(entry)))
			title = re.compile('<h3 class="animebox-title">([^<]+)</h3>', re.DOTALL).findall(entry)[0]
			name = cleaning(title)
			photo = re.compile('<img src="([^"]+)"', re.DOTALL).findall(entry)[0]
			photo = BASE_URL+photo if photo[:4] != "http" else photo
			cineType = 'episode'
			if '/films' in photo or 'zum Film' in entry:
				cineType = 'movie'
				name = "[I]"+name+"[/I]"
				if no_Movies: continue
			SE_link = re.compile('<a href="([^"]+)">', re.DOTALL).findall(entry)[0]
			SE_link = BASE_URL+SE_link if SE_link[:4] != "http" else SE_link
			try: 
				desc = re.compile('<p class="animebox-shorttext[^>]*>(.*?)</div>', re.DOTALL).findall(entry)[0]
				desc = re.sub('\<.*?\>', '', desc)
				plot = cleaning(desc)
			except: plot = ""
			addType = 1
			if os.path.exists(channelFavsFile):
				with io.open(channelFavsFile, 'r', encoding='utf-8') as output:
					lines = output.readlines()
					for line in lines:
						if line.startswith('###START'):
							part = line.split('###')
							link_FV = part[2]
							if SE_link == link_FV: addType = 2
			if sel_CAT == '0' or (checking(name) is False and sel_CAT == '1') or (checking(name) is True and sel_CAT == '2'):
				addDir(name, photo, {'mode': 'listEpisodes', 'url': SE_link, 'cineType': cineType, 'origSERIE': name}, plot, addType)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSimilar(url):
	debug_MS("(navigator.listSimilar) ------------------------------------------------ START = listSimilar -----------------------------------------------")
	debug_MS("(navigator.listSimilar) ~~~~~ URL : {0} ~~~~~".format(url))
	content = url[url.find('<div class="jcarousel">')+1:]
	content = content[:content.find('</div>')]
	match = re.compile('<img height=".+?" src="([^"]+)".+?<a href="([^"]+)">([^<]+)</a>', re.DOTALL).findall(content)
	for photo, link, title in match:
		photo = BASE_URL+photo if photo[:4] != "http" else photo
		name = cleaning(title)
		cineType = 'episode'
		if '/films' in photo:
			cineType = 'movie'
			name = "[I]"+name+"[/I]"
			if no_Movies: continue
		debug_MS("(navigator.listSimilar) XXX NAME = {0} || LINK = {1} || PHOTO = {2} XXX".format(name, BASE_URL+link, photo))
		addDir(name, photo, {'mode': 'listEpisodes', 'url': BASE_URL+link, 'cineType': cineType, 'origSERIE': name})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, cineType, origSERIE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS("(navigator.listEpisodes) ~~~~~ URL : {0} || cineType : {1} || origSERIE : {2} ~~~~~".format(params.get('url'), params.get('cineType'), params.get('origSERIE')))
	nones = lambda n: [None for _ in range(n)]
	genre, year, country, mpaa = nones(4)
	COMBI_EPISODE = []
	COMBI_TEASER = []
	uno_LIST = []
	pos1 = 0
	pos2 = 0
	old_REF = url
	seriesname = unquote_plus(origSERIE)
	content = getUrl(url, 'Standard', url)
	new_csrftoken = re.compile('<meta name="csrf-token" content="([^"]+)"', re.DOTALL).findall(content)[0]
	debug_MS("(navigator.listEpisodes) ### CSRF_Token = {0} ###".format(new_csrftoken))
	addon.setSetting('csrftoken', new_csrftoken)
	results = re.findall('<div class="l-mainsection ">(.+?)<div class="l-contentcontainer l-navigationscontainer">', content, re.S)
	for chtml in results:
		debug_MS("(navigator.listEpisodes) ### CONTENT : {0} ###".format(str(chtml)))
		try:
			table = re.compile('<table class="vertical-table">(.+?)<th>Mehr Infos auf</th>', re.DOTALL).findall(chtml)[0]
			specials = re.findall('<th>([^<]+)</th.*?<td>([^<]+)</td>', table, re.S)
			for CAT, WORDS in specials:
				CAT = cleaning(re.sub('[{@$%#^\\/;,:*?!\"+<>|}]\n', '', CAT))
				WORDS = cleaning(re.sub('[{@$%#^\\/;,:*?!\"+<>|}]\n', '', WORDS))
				if 'produktion' in CAT.lower():
					year = WORDS
				elif 'sprache' in CAT.lower():
					country = WORDS
				elif 'genre' in CAT.lower():
					genre = WORDS
				elif 'fsk' in CAT.lower() and str(WORDS) != '0':
					mpaa = 'Ab '+str(WORDS)+' Jahren'
		except: pass
		if '<h2>&Auml;hnliche Animes</h2>' in chtml:
			addDir(translation(30619), icon, {'mode': 'listSimilar', 'url': chtml})
		if 'Das Virtual Ticket steht nicht länger zur Verfügung' in chtml:
			addDir(translation(30620).format(origSERIE), icon, {'mode': 'None'})
		if '<div class="three-box episodebox flip-container">' in chtml and cineType == 'episode':
			part = chtml.split('<div class="three-box episodebox flip-container">')
		else:
			part = chtml.split('<div class="l-maincontent l-contentcontainer">')
		for i in range(1, len(part), 1):
			entry = part[i]
			debug_MS("(navigator.listEpisodes) ### ENTRY : {0} ###".format(str(entry)))
			plot = ""
			if cineType == 'episode':
				title = ""
				match1 = re.findall('<h3 class="episodebox-title" title.*?>(.+?)</h3>', entry, re.S)
				match2 = re.findall('<h4>(.+?)</h4>', entry, re.S)
				if match1:
					title = match1[0]
				if title == "" and match2:
					title = match2[0]
				image = re.compile('src="([^"]+)"', re.DOTALL).findall(entry)[0]
				try: plot = re.compile('<p class="episodebox-shorttext[^>]*>(.*?)</div>', re.DOTALL).findall(entry)[0]
				except: pass
			else:
				title = re.compile('<h1 itemprop="name">(.+?)</h1>', re.DOTALL).findall(entry)[0]
				image = re.compile('itemprop="image" src="([^"]+)"', re.DOTALL).findall(entry)[0]
				try: plot = re.compile('<div itemprop="description[^>]*>(.*?)</div>', re.DOTALL).findall(entry)[0]
				except: pass
			name = cleaning(title)
			episode = '0'
			if 'Episode' or 'Folge' in name:
				try:
					episode = re.findall('([0-9]+)', name, re.S)[0].strip().zfill(4)
					pos1 += 1
				except: pass
			else: pos2 += 1
			image = BASE_URL+image if image[:4] != "http" else image
			if plot != "":
				plot = cleaning(re.sub('\<.*?\>', '', plot))
			data_STREAMS = re.search(r'title=["\'](?:Japanischen Stream|Deutschen Stream).*?data-playlist=', entry)
			if data_STREAMS and LOGIN_STATUS == 'true':
				debug_MS("(navigator.listEpisodes) ##### data_STREAMS = GEFUNDEN und LOGIN_STATUS = TRUE || Liste jetzt die gefundenen Episoden #####")
				EP_found = re.findall('title="([^"]+)" data-playlist="([^"]+)"', entry, re.S)
				for EP_type, EP_link in EP_found:
					if 'Deutschen Stream' in EP_type:
						CPL = name+'  [COLOR lime](Dub)[/COLOR]'
					if 'Japanischen Stream' in EP_type:
						CPL = name+'  [COLOR lime](OmU)[/COLOR]'
					if cineType == 'movie': CPL = '[I]'+CPL+'[/I]'
					endURL = BASE_URL+EP_link
					extras = old_REF
					COMBI_EPISODE.append([episode, CPL, image, endURL, plot, seriesname, genre, year, country, mpaa, cineType, extras, pos1, pos2])
			if '<a class="streamstarter" data-stream=' in entry and enableTEASER:
				debug_MS("(navigator.listEpisodes) ##### streamstarter = GEFUNDEN und enableTEASER = TRUE || Liste jetzt die gefundenen Teaser #####")
				teaser = re.findall('<a class="streamstarter" data-stream="([^"]+)"', entry, re.S)[0]
				CPL = name+'  [COLOR orangered](Teaser)[/COLOR]'
				endURL = unquote_plus(BASE_URL+teaser)
				extras = 'Teaser'
				COMBI_TEASER.append([episode, CPL, image, endURL, plot, seriesname, genre, year, country, mpaa, cineType, extras, pos1, pos2])
	if COMBI_EPISODE or COMBI_TEASER:
		new_COMBI = COMBI_EPISODE + COMBI_TEASER
		if pos2 <= 5:
			new_COMBI = sorted(new_COMBI, key=lambda d:d[0], reverse=True)
		for episode, CPL, image, endURL, plot, seriesname, genre, year, country, mpaa, cineType, extras, pos1, pos2 in new_COMBI:
			if sel_CAT == '0' or (checking(CPL) is False and sel_CAT == '1') or (checking(CPL) is True and sel_CAT == '2'):
				HLnom = hashlib.md5(py2_uni(endURL.split('/')[-1]+'-'+CPL).encode('utf-8')).hexdigest()
				EP_entry = str(HLnom)+'###'+str(endURL)+'###'+str(seriesname)+'###'+str(CPL)+'###'+str(image)+'###'+str(episode)+'###'+str(extras)+'###'
				if EP_entry not in uno_LIST:
					uno_LIST.append(EP_entry)
				listitem = xbmcgui.ListItem(CPL, path=HOST_AND_PATH+'?IDENTiTY='+HLnom+'&mode=playCODE')
				info = {}
				info['Episode'] = episode
				if seriesname is not None:
					info['Tvshowtitle'] = seriesname
				if CPL is not None:
					info['Title'] = CPL
				info['Tagline'] = None
				if plot is not None:
					info['Plot'] = plot
				info['Duration'] = '0'
				info['Year'] = year
				info['Country'] = country
				info['Genre'] = genre
				info['Director'] = None
				info['Writer'] = None
				info['Studio'] = 'AoD'
				info['Mpaa'] = mpaa
				info['Mediatype'] = cineType
				listitem.setInfo(type='Video', infoLabels=info)
				listitem.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
				if useThumbAsFanart and image != icon and not artpic in image:
					listitem.setArt({'fanart': image})
				listitem.setProperty('IsPlayable', 'true')
				listitem.setContentLookup(False)
				xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+HLnom+'&mode=playCODE', listitem=listitem)
				with io.open(WORKFILE, 'w', encoding='utf-8') as input:
					input.write(py2_uni('\n'.join(uno_LIST)))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def get_newTOKEN(url, STREAMFILE):
	content = getUrl(url, 'Standard', url)
	new_csrftoken = re.compile('<meta name="csrf-token" content="([^"]+)"', re.DOTALL).findall(content)[0]
	addon.setSetting('csrftoken', new_csrftoken)
	xbmc.sleep(1000)
	STREAMTEXT = getUrl(STREAMFILE, 'playCODE', url)
	STREAMS = STREAMTEXT.splitlines()
	debug_MS("(navigator.get_newTOKEN) ### cacheData for STREAMS = {0} ###".format(STREAMS))
	return STREAMS

def playCODE(IDD):
	debug_MS("(navigator.playCODE) ------------------------------------------------ START = playCODE -----------------------------------------------")
	finalURL = False
	manifest_type = False
	media_M3U8 = []
	with io.open(WORKFILE, 'r', encoding='utf-8') as output:
		lines = output.readlines()
		for line in lines:
			field = line.split('###')
			if field[0]==IDD:
				endURL = field[1]
				seriesname = field[2]
				name = field[3]
				image = field[4]
				episode = field[5]
				extras = field[6]
	if extras == 'Teaser':
		finalURL = endURL.replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%2D','-').replace('%5F','_').replace('%3B',';').split('url=')[1]
	else:
		oldURL = extras
		content = getUrl(endURL, 'playCODE', oldURL)
		js = json.loads(content)
		STREAMFILE = js['playlist'][0]['sources'][0]['file'].replace("\\u0026","&")
		debug_MS("(navigator.playCODE) ### This is the STREAM-ADRESS = {0} ###".format(STREAMFILE))
		firstURL = STREAMFILE.replace('chunklist', '.m3u8').replace('playlist', '.m3u8').split('.m3u8', 1)[0]
		firstRESULT = re.sub(r'(?:chunklist.m3u8|playlist.m3u8|index|master)', '', firstURL)
		if 'Original' in QUALITY:
			debug_MS("(navigator.playCODE) ### MODUS = Original ###")
			finalURL = STREAMFILE
		if not finalURL and QUALITY.split('-')[1] in ['1081', '1080', '720', '576', '540', '480', '360']:
			debug_MS("(navigator.playCODE) ### MODUS = Selected Quality-Step ###")
			STREAMS = get_newTOKEN(oldURL, STREAMFILE)
			for i in range(0, len(STREAMS)):
				infoSTREAM_2 = STREAMS[i]
				firstTEXT = QUALITY.split('-')[0]
				secondTEXT = QUALITY.split('-')[1]
				index_Bandwith = re.search(r'INF:BANDWIDTH={0},'.format(firstTEXT), infoSTREAM_2)
				index_Resolution = re.search(r'RESOLUTION=[0-9]+x{0},?'.format(secondTEXT), infoSTREAM_2)
				if index_Bandwith or index_Resolution:
					newSTREAM_2 = STREAMS[i + 1]
					finalURL = firstRESULT+newSTREAM_2
					debug_MS("(navigator.playCODE) XXX AUSWAHL = {0} || LINE = {1} || STREAM = {2} XXX".format(QUALITY, infoSTREAM_2, newSTREAM_2))
		if not finalURL and ('Highest' in QUALITY or QUALITY.split('-')[0] not in ['Original', 'Select']):
			debug_MS("(navigator.playCODE) ### MODUS = Highest Quality ###")
			STREAMS = get_newTOKEN(oldURL, STREAMFILE)
			for i in range(0, len(STREAMS)):
				infoSTREAM_3 = STREAMS[i]
				if 'INF:BANDWIDTH=' in infoSTREAM_3:
					try: 	the_Bandwith = re.findall('AVERAGE-BANDWIDTH=([0-9]+),?', infoSTREAM_3, re.S)[0]
					except: the_Bandwith = re.findall('INF:BANDWIDTH=([0-9]+),', infoSTREAM_3, re.S)[0]
					converted_BW = int(the_Bandwith)/1024
					onlyLeft_BW = "{0:.0f}".format(converted_BW).zfill(5)
					newSTREAM_3 = STREAMS[i + 1]
					media_M3U8.append({'url': newSTREAM_3, 'bandwith': str(onlyLeft_BW), 'type': 'm3u8'})
			debug_MS("(navigator.playCODE) ### DATA['media']-UNSORTED = {0} ###".format(str(DATA['media'])))
			media_M3U8 = sorted(media_M3U8, key=lambda k: k['bandwith'], reverse=True)
			debug_MS("(navigator.playCODE) ### DATA['media']-SORTED = {0} ###".format(str(DATA['media'])))
			finalURL = firstRESULT+media_M3U8[0:1]
		if not finalURL:
			debug_MS("(navigator.playCODE) ### last MODUS = Other not found or Manual-Select-Quality ###")
			file_Names = []
			file_Streams = []
			STREAMS = get_newTOKEN(oldURL, STREAMFILE)
			for i in range(0, len(STREAMS)):
				infoSTREAM_4 = STREAMS[i]
				if 'INF:BANDWIDTH=' in infoSTREAM_4:
					match = re.compile(r'INF:BANDWIDTH=([0-9]+),(?:AVERAGE-BANDWIDTH=[0-9]+,)?RESOLUTION=([0-9]+x[0-9]+)(?:,FRAME-RATE=)?', re.DOTALL).findall(infoSTREAM_4)
					for bandWT, RES in match:
						converted_BW = int(bandWT)/1024
						onlyLeft_BW = "{0:.0f}".format(converted_BW)
						file_Names.append('Source:  Auflösung '+str(RES)+'  [COLOR yellow](Geschw. '+str(onlyLeft_BW)+' kb/s)[/COLOR]')
				if any(x in infoSTREAM_4 for x in ['Signature=', 'Policy=', 'chunklist']):
						file_Streams.append(infoSTREAM_4)
			getNF = dialog.select('Wählen Sie die bevorzugte Qualität', file_Names, preselect=0)
			if getNF == -1: return
			resURL = str(file_Streams[getNF])
			finalURL = firstRESULT+resURL
			debug_MS("(navigator.playCODE) XXX NAME : {0} || STREAM-Selected : {1} XXX".format(resURL, finalURL))
	log("(navigator.playCODE) ### THIS IS THE FINALURL = {0} ###".format(str(finalURL)))
	if finalURL:
		listitem=xbmcgui.ListItem(path=finalURL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			if 'dash' in finalURL or '.mpd' in finalURL:
				manifest_type = 'mpd'
				mime_type = 'application/dash+xml'
			elif 'hls' in finalURL or '.m3u8' in finalURL:
				manifest_type = 'hls'
				mime_type = 'application/x-mpegURL'
		if manifest_type:
			listitem.setMimeType(mime_type)
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', manifest_type)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playCODE) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *kika.de* gefunden !!! ##########".format(endURL))
		return dialog.notification(translation(30521).format('STREAM'), translation(30533), icon, 8000)

def listShowsFavs():
	debug_MS("(navigator.listShowsFavs) ------------------------------------------------ START = listShowsFavs -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
	if os.path.exists(channelFavsFile):
		with io.open(channelFavsFile, 'r', encoding='utf-8') as textobj:
			lines = textobj.readlines()
			for line in lines:
				if line.startswith('###START'):
					part = line.split('###')
					debug_MS("(navigator.listShowsFavs) ### NAME : {0} || URL : {1} || IMAGE : {2} || cineType : {3} ###".format(str(part[2]), str(part[3]), part[4].strip(), part[6]))
					addDir(name=part[2], image=part[4].strip(), params={'mode': 'listEpisodes', 'url': part[3], 'cineType': part[6], 'origSERIE': part[2]}, plot=part[5].replace('#n#', '\n').strip(), FAVdel=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(elem):
	modus = elem[elem.find('MODE=')+5:+8]
	TVSe = elem[elem.find('###START'):]
	TVSe = TVSe[:TVSe.find('END###')]
	name = TVSe.split('###')[2]
	url = TVSe.split('###')[3]
	if modus == 'ADD':
		if os.path.exists(channelFavsFile):
			with io.open(channelFavsFile, 'a+', encoding='utf-8') as textobj:
				content = textobj.read()
				if content.find(TVSe) == -1:
					textobj.seek(0,2) # change is here (for Windows-Error = "IOError: [Errno 0] Error") - because Windows don't like switching between reading and writing at same time !!!
					textobj.write(py2_uni(TVSe+'END###\n'))
		else:
			with io.open(channelFavsFile, 'a', encoding='utf-8') as textobj:
				textobj.write(py2_uni(TVSe+'END###\n'))
		xbmc.sleep(500)
		dialog.notification(translation(30534), translation(30535).format(name), icon, 8000)
	elif modus == 'DEL':
		with io.open(channelFavsFile, 'r', encoding='utf-8') as output:
			lines = output.readlines()
		with io.open(channelFavsFile, 'w', encoding='utf-8') as input:
			for line in lines:
				if url not in line:
					input.write(py2_uni(line))
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30534), translation(30536).format(name), icon, 8000)

def addDir(name, image, params={}, plot=None, addType=0, FAVdel=False):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	entries = []
	if addType == 1 and FAVdel == False:
		FAVInfos_1 = 'MODE=ADD###START###{0}###{1}###{2}###{3}###{4}###END###'.format(params.get('origSERIE'), params.get('url'), image, "" if plot is None else plot.replace('\n', '#n#'), params.get('cineType'))
		entries.append([translation(30651), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'url': str(FAVInfos_1)}))])
	if FAVdel == True:
		FAVInfos_2 = 'MODE=DEL###START###{0}###{1}###{2}###{3}###{4}###END###'.format(name, params.get('url'), image, plot, params.get('cineType'))
		entries.append([translation(30652), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'url': str(FAVInfos_2)}))])
	liz.addContextMenuItems(entries, replaceItems=False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)
