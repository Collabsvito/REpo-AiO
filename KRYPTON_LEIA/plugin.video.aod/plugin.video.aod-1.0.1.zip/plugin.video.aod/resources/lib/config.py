﻿# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import xbmc
import xbmcgui
import base64
import hashlib
import uuid
from .external import Random
from .external.Cipher import AES
from .external.Util.Padding import pad, unpad

from .common import *
BLOCK_SIZE = 16


class Config(object):

	def get_personal_key(self):
		debug_MS("(config.get_personal_key) ### START get_personal_key ###")
		count = 0
		try:
			while count < 3:
				xbmc.getInfoLabel('Network.MacAddress')
				xbmc.sleep(500)
				mac_addr = xbmc.getInfoLabel('Network.MacAddress')
				if py2_enc(':') in mac_addr:
					count += 3
					MAC_UUID = str(uuid.uuid3(uuid.NAMESPACE_DNS, mac_addr))
					my_key = hashlib.sha256(py2_enc(MAC_UUID)).digest()
					return my_key
				else:
					count +=1
		except: 
			failing("(confi.get_personal_key) ERROR - ERROR - ERROR : ({0})".format(str(mac_addr)))
			dialog.notification(translation(30521).format('MAC'), "ERROR = [COLOR red]failed to get device id {0}[/COLOR]".format(str(mac_addr)), icon, 12000)

	def vers_encrypt(self, data):
		private_key = self.get_personal_key()
		data = pad(data, BLOCK_SIZE)
		iv = Random.new().read(AES.block_size)
		cipher = AES.new(private_key, AES.MODE_CBC, iv)
		return base64.b64encode(iv + cipher.encrypt(data))

	def vers_decrypt(self, data):
		private_key = self.get_personal_key()
		data = base64.b64decode(data)
		iv = data[:BLOCK_SIZE]
		cipher = AES.new(private_key, AES.MODE_CBC, iv)
		return unpad(cipher.decrypt(data[BLOCK_SIZE:]), BLOCK_SIZE)

	def has_credentials(self):
		debug_MS("(config.has_credentials) ### START has_credentials ###")
		USER = addon.getSetting('username')
		PASSWORD = addon.getSetting('password')
		return True if USER != '' and PASSWORD != '' else False

	def get_credentials(self):
		debug_MS("(config.get_credentials) ### START get_credentials ###")
		stored_user = addon.getSetting('username')
		stored_pw = addon.getSetting('password')
		want_encrypt = addon.getSetting('encrypt_credentials')
		if want_encrypt == 'true':
			dec_USER = self.vers_decrypt(stored_user)
			dec_PW = self.vers_decrypt(stored_pw)
			return (bytes.decode(dec_USER), bytes.decode(dec_PW))
		return (stored_user, stored_pw)

	def save_credentials(self):
		debug_MS("(config.save_credentials) ### START save_credentials ###")
		USER = dialog.input(translation(30641), type=xbmcgui.INPUT_ALPHANUM)
		PASSWORD = dialog.input(translation(30642), type=xbmcgui.INPUT_ALPHANUM)
		want_encrypt = addon.getSetting('encrypt_credentials')
		if want_encrypt == 'true':
			safely_user = self.vers_encrypt(USER)
			safely_pw = self.vers_encrypt(PASSWORD)
			addon.setSetting('username', safely_user)
			addon.setSetting('password', safely_pw)
			debug_MS("(config.save_credentials) XXX encrypt-USER : {0} || encrypt-PASSWORD : {1} XXX".format(safely_user, safely_pw))
		else:
			standard_user = USER
			standard_pw = PASSWORD
			addon.setSetting('username', standard_user)
			addon.setSetting('password', standard_pw)
			debug_MS("(config.save_credentials) XXX standard-USER : {0} || standard-PASSWORD : {1} XXX".format(standard_user, standard_pw))
		return (USER, PASSWORD)

	def clear_credentials(self):
		debug_MS("(config.clear_credentials) ### START clear_credentials ###")
		USER, PASSWORD = '', ''
		addon.setSetting('username', USER)
		addon.setSetting('password', PASSWORD)
		return (USER, PASSWORD)
