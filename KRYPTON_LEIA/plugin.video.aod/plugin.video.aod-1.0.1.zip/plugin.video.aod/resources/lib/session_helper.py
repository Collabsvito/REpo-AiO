﻿# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import sys
from os import path
import re
import xbmc
import xbmcaddon
import xbmcvfs
import shutil
from datetime import datetime
from requests import session, exceptions
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
else: 
	from urllib.parse import urlencode  # Python 3.X
try: import cPickle as pickle
except: import pickle
import warnings
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

from .common import *
from .config import Config


class Session_Helper(object):

	def __init__(self):
		self.config = Config
		self.maxSessionTime = 360 * 60 # max. Session-Time (Seconds) before clear the Session and delete Session-File [60*60 = 1 hour | 360*60 = 6 hours | 720*60 = 12 hours]
		self.temp_session_folder = tempPath
		self.session_file = cookieFile
		self.verify_ssl = verify_ssl_connect
		self.crsf_TOKEN = CSRF_Token
		forceLogin = False
		self.session = session()
		self.load_session()

	def clear_session(self):
		debug_MS("(session_helper.clear_session) ### START clear_session ###")
		if self.session_file is not None and path.isfile(self.session_file):
			if xbmcvfs.exists(self.temp_session_folder) and path.isdir(self.temp_session_folder):
				shutil.rmtree(self.temp_session_folder, ignore_errors=True)
				xbmc.sleep(500)
			xbmcvfs.mkdirs(self.temp_session_folder)

	def save_session(self):
		debug_MS("(session_helper.save_session) ### START save_session ###")
		with open(self.session_file, 'wb') as input:
			pickle.dump(self.session.cookies, input, pickle.HIGHEST_PROTOCOL)

	def modification_date(self, filename):
		last = path.getmtime(filename)
		return datetime.fromtimestamp(last)

	def has_session(self):
		debug_MS("(session_helper.has_session) ### START has_session ###")
		return True if self.load_session() is True else False

	def load_session(self):
		debug_MS("(session_helper.load_session) ### START load_session ###")
		wasReadFromCache = False
		if addon.getSetting('without_Account') == 'false' and self.session_file is not None and path.isfile(self.session_file):
			mod_time = self.modification_date(self.session_file)
			lastModification = (datetime.now() - mod_time).seconds
			if lastModification < self.maxSessionTime:
				with open(self.session_file, 'rb') as output:
					self.session.cookies = pickle.load(output)
					addon.setSetting('login_successfully', 'true')
					wasReadFromCache = True
					return True
		if not wasReadFromCache:
			debug_MS("(session_helper.load_session) ##### ERROR = load_session (pickle-ERROR) #####")
			self.clear_session()
			addon.setSetting('login_successfully', 'false')
			if addon.getSetting('without_Account') == 'true':
				debug_MS("(session_helper.load_session) ##### addon.getSetting - without_Account = TRUE || Fortsetzung jetzt ohne Account #####")
			else:
				if self.config().has_credentials() is True:
					USER, PASSWORD = self.config().get_credentials()
				else:
					USER, PASSWORD = self.config().save_credentials()
				self.login(USER, PASSWORD, forceLogin=True)

	def login(self, username, password, forceLogin=False):
		debug_MS("(session_helper.login) ##### START ...login-PROCESS - forceLogin = {0} #####".format(str(forceLogin)))
		payload = {}
		standard_res = self.retrieveContent(LOGIN_LINK)
		auth_token = re.compile('name="authenticity_token" value="([^"]+)"', re.DOTALL).findall(standard_res.text)[0]
		payload['utf8'] = '&#x2713;'
		payload['user[login]'] = username
		payload['user[password]'] = password
		payload['user[remember_me]'] = 1
		payload['commit'] = 'Einloggen'
		payload['authenticity_token'] = auth_token
		payload = urlencode(payload)
		login_res = self.retrieveContent(LOGIN_LINK, method='POST', data=payload)
		index_Account = re.search(r'<p class="alert alert-info alert-hideable">Hallo, du bist jetzt angemeldet.</p>', login_res.text)
		debug_MS("(session_helper.login) ### EINLOGGEN(login_res.text) : {0} ###".format(login_res.text))
		if index_Account:
			debug_MS("(session_helper.login) ##### !!! DU BIST ERFOLGREICH EINGELOGGT !!! #####")
			addon.setSetting('login_successfully', 'true')
			self.save_session()
			return True
		else:
			debug_MS("(session_helper.login) ##### ERROR = DU BIST NICHT EINGELOGGT = ERROR #####")
			addon.setSetting('login_successfully', 'false')
			self.clear_session()
			return False

	def load_header(self, REF, CALL_PRO):
		if REF is 'Unknown':
			HEADERS = self.session.headers.update({'User-Agent': get_userAgent()})
		else:
			HEADERS = self.session.headers.update({'User-Agent': get_userAgent(), 'Referer': REF})
		if CALL_PRO == 'playCODE' :
			HEADERS = self.session.headers.update({'X-CSRF-Token': self.crsf_TOKEN, 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json, text/javascript, */*; q=0.01'})
		return HEADERS

	def retrieveContent(self, url, method='GET', direct=False, CALL_PRO='Standard', REF='Unknown', allow_redirects=True, headers="", data=""):
		if headers == "":
			headers = self.load_header(REF, CALL_PRO)
		try:
			if method == 'GET':
				response = self.session.get(url, allow_redirects=allow_redirects, verify=self.verify_ssl, headers=headers, timeout=30)
			else:
				response = self.session.post(url, allow_redirects=allow_redirects, verify=self.verify_ssl, headers=headers, data=data, timeout=30)
			response.raise_for_status()
			#if direct is True:
				#self.save_session()
		except exceptions.RequestException as e:
			failure = str(e)
			failing("(retrieveContent) ERROR - ERROR - ERROR : ##### {0} === {1} #####".format(url, failure))
			dialog.notification(translation(30521).format('URL'), "ERROR = [COLOR red]{0}[/COLOR]".format(failure), icon, 12000)
			response = ""
			return sys.exit(0)
		return response

	def logout(self):
		debug_MS("(session_helper.logout) ### START logout the Session... ###")
		self.clear_session()
		logout_res = self.retrieveContent(BASE_URL, method='GET', REF=BASE_URL)
		index_LoggedOUT = re.search(r'<a href="/users/edit">Benutzerkonto</a>', logout_res.text)
		if index_LoggedOUT:
			debug_MS("(session_helper.logout) ##### !!! DIE SESSION WURDE ERFOLGREICH BEENDET !!! #####")
			addon.setSetting('login_successfully', 'false')
			return True
		return False
