﻿# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import re
import xbmc
import xbmcgui
import pyxbmct

from .common import *


class Infowindow(pyxbmct.AddonDialogWindow):    
	text=""
	pos=0
	image=""
	trailer=""
	starttext=""
	def __init__(self, text=''):
		self.ueberschrift = re.compile('<h1 style="margin: 0;">(.+?)</h1>', re.DOTALL).findall(text)[0]
		try:
			self.image= re.compile('class="newspic" src="(.+?)"', re.DOTALL).findall(text)[0]
			if self.image[:4] != "http":
				self.image = BASE_URL+self.image
		except: pass
		kurz_inhalt = text[text.find('<div class="article-text">')+1:]
		kurz_inhalt = kurz_inhalt[:kurz_inhalt.find('</div>')]  
		if "<table " in kurz_inhalt: 
			self.starttext = text
			kurz_inhalt = kurz_inhalt[:kurz_inhalt.find('<table ')]  
		kurz_inhalt=cleaning(kurz_inhalt)
		kurz_inhalt = kurz_inhalt.replace("</p>", "\n")
		spl = kurz_inhalt.split('\n')
		self.text = ""
		self.textlen = 0
		for i in range(1,len(spl),1):
			entry=spl[i]
			#debug("Entry :"+entry)
			if not "img alt=" in entry and not "iframe " in entry and not "<p>Vom " in entry:
				entry = entry.replace("<br />", "\n").replace("</li>", "\n")
				entry = re.sub(r'\<.*?\>', '', entry)
				self.text = self.text+entry+"\n"
				self.textlen = self.textlen+1
		self.ueberschrift = cleaning(self.ueberschrift)
		try:
			self.trailer = re.compile('src="https://www.youtube.com/embed/([^"]+?)"', re.DOTALL).findall(text)[0]        
			if "?" in self.trailer:
				self.trailer = self.trailer.split('?')[0]
		except: pass
		super(Infowindow, self).__init__("NEWS")
		self.setGeometry(925, 650, 23, 10)
		self.set_info_controls()
		# Connect a key action (Backspace) to close the window.
		self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

	def set_info_controls(self):   
		self.ueberschrift = pyxbmct.Label(self.ueberschrift, alignment=pyxbmct.ALIGN_CENTER) 
		self.placeControl(self.ueberschrift, 0, 0, columnspan=10, rowspan=1) 
		if not "<tbody>" in self.starttext:  
			if self.image == "" and self.trailer != "":
				self.image = "https://img.youtube.com/vi/"+self.trailer+"/hqdefault.jpg"        
			self.image = pyxbmct.Image(self.image,aspectRatio=4)
			self.placeControl(self.image, 1, 3, columnspan=4, rowspan=6)
			self.beschreibung = pyxbmct.TextBox()
			self.placeControl(self.beschreibung, 7, 0, columnspan=10, rowspan=15) 
			self.beschreibung.setText(self.text)
			self.beschreibung.autoScroll(3000, 2000, 3000)
			if self.trailer !="":
				self.info_button = pyxbmct.Button('[B]Trailer[/B]', font='font14')
				self.placeControl(self.info_button, 22, 0, columnspan=3, rowspan=2) 
				self.connect(self.info_button, self.playTrailer)
			self.close_button = pyxbmct.Button('[B]Close[/B]', font='font14')
			self.placeControl(self.close_button, 22, 7, columnspan=3, rowspan=2) 
			self.connect(self.close_button, self.close)
			self.setFocus(self.close_button)
		else:
			self.beschreibung = pyxbmct.FadeLabel()
			self.placeControl(self.beschreibung, 1, 0, columnspan=10, rowspan=1) 
			self.beschreibung.addLabel(self.text)
			kurz_inhalt = self.starttext[self.starttext.find('<tbody>')+1:]
			kurz_inhalt = kurz_inhalt[:kurz_inhalt.find('</tbody>')]    
			kurz_inhalt = kurz_inhalt.replace("\n","")
			starty = 2
			startx = 0
			counter = 0
			counter2 = 0
			spl = kurz_inhalt.split('</tr>')
			for i in range(0,len(spl),1):
				entry = spl[i]
				entry = entry.replace("<br />","###")
				match = re.compile('>(.+?)</td>', re.DOTALL).findall(entry)
				for feld in match:
					feld = cleaning(feld)
					feld = re.sub(r'\<.*?\>', '', feld)
					if len(feld) > 19:
						gr = 5
					else:
						gr = 0
					if "###" in feld:
						sp2 = feld.split('###')
						for i2 in range(0,len(sp2),1):
							entry2 = sp2[i2]
							self.sp1 = pyxbmct.Label(entry2)
							self.placeControl(self.sp1, starty, startx, columnspan=2+gr, rowspan=2)
							starty = starty+1
							counter = counter+1
						starty = starty-counter
						if counter2 < counter:
							counter2 = counter-1
						counter = 0
						startx = startx+2+gr
					else:
						self.sp1 = pyxbmct.Label(feld)
						self.placeControl(self.sp1, starty, startx, columnspan=2+gr, rowspan=2)
						startx = startx+2+gr 
				starty = starty+1+counter2
				counter2 = 0
				startx = 0
				self.close_button = pyxbmct.Button('[B]Close[/B]', font='font14')
				self.placeControl(self.close_button, 22, 7, columnspan=3, rowspan=2) 
				self.connect(self.close_button, self.close)
				self.setFocus(self.close_button)  
		self.connectEventList([pyxbmct.ACTION_MOVE_LEFT,
			pyxbmct.ACTION_MOVE_RIGHT,
			pyxbmct.ACTION_MOUSE_DRAG,
			pyxbmct.ACTION_MOUSE_LEFT_CLICK],
			self.leftright)

	def playTrailer(self):
		self.close()
		videoURL = 'plugin://plugin.video.youtube/play/?video_id='+self.trailer
		listitem = xbmcgui.ListItem(path=videoURL)
		listitem.setMimeType('application/vnd.apple.mpegurl')
		xbmc.Player().play(item=videoURL, listitem=listitem)

	def leftright(self):
		if self.trailer != "":
			if self.getFocus() == self.close_button:
				self.setFocus(self.info_button)
			elif self.getFocus() == self.info_button:
				self.setFocus(self.close_button)
		else:
			self.setFocus(self.close_button)
