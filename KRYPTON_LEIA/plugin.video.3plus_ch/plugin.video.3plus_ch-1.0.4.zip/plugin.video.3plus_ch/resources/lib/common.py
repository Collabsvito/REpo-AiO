﻿## -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import socket
import time
from datetime import datetime, timedelta
import io
import gzip
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import quote, quote_plus, unquote_plus, urlencode  # Python 2.X
	from urllib2 import build_opener  # Python 2.X
else:
	from urllib.parse import quote, quote_plus, unquote_plus, urlencode  # Python 3+
	from urllib.request import build_opener  # Python 3+
try: import StorageServer
except: from . import storageserverdummy as StorageServer


global debuging
socket.setdefaulttimeout(40)
HOST_AND_PATH        = sys.argv[0]
ADDON_HANDLE          = int(sys.argv[1])
dialog                              = xbmcgui.Dialog()
addon                              = xbmcaddon.Addon()
addon_id                         = addon.getAddonInfo('id')
addon_name                  = addon.getAddonInfo('name')
addon_version               = addon.getAddonInfo('version')
addonPath                      = xbmc.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                         = xbmc.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
WORKFILE                      = os.path.join(dataPath, 'episode_data.txt')
defaultFanart                 = os.path.join(addonPath, 'fanart.jpg')
icon                                  = os.path.join(addonPath, 'icon.png')
artpic                               = os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
cachePERIOD                = int(addon.getSetting('cacheRhythm'))
cache                               = StorageServer.StorageServer(addon_id, cachePERIOD) # (Your plugin name, Cache time in hours)
enableINPUTSTREAM   = addon.getSetting('useInputstream') == 'true'
INPUT_APP                     = ('inputstream' if int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 19 else 'inputstreamaddon')
prefSTREAM                    = addon.getSetting('streamSelection')
prefQUALITY                   = {0: 720, 1: 540, 2: 480, 3: 360}[int(addon.getSetting('prefVideoQuality'))]
useThumbAsFanart        = addon.getSetting('useThumbAsFanart') == 'true'
enableADJUSTMENT      = addon.getSetting('show_settings') == 'true'
DEB_LEVEL                      = (xbmc.LOGNOTICE if addon.getSetting('enableDebug') == 'true' else xbmc.LOGDEBUG)
BASE_URL                        = 'https://www.3plus.tv/'
API_URL                           = 'https://www.3plus.tv/api/pub/gql/tv3plus/'
PartnerId                         = '1719221' # für Kaltura-Player

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py2_enc(s, encoding='utf-8'):
	if PY2:
		if not isinstance(s, basestring):
			s = str(s)
		s = s.encode(encoding) if isinstance(s, unicode) else s
	return s

def py2_uni(s, encoding='utf-8'):
	if PY2 and isinstance(s, str):
		s = unicode(s, encoding)
	return s

def py3_dec(d, encoding='utf-8'):
	if not PY2 and isinstance(d, bytes):
		d = d.decode(encoding)
	return d

def translation(id):
	return py2_enc(addon.getLocalizedString(id))

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGNOTICE):
	msg = py2_enc(msg)
	return xbmc.log('[{0} v.{1}]{2}'.format(addon_id, addon_version, msg), level)

def clearCache():
	debug_MS("(clearCache) -------------------------------------------------- START = clearCache --------------------------------------------------")
	debug_MS("(clearCache) ========== Lösche jetzt den Addon-Cache ==========")
	cache.delete('%')
	xbmc.sleep(1000)
	dialog.ok(addon_id, translation(30502))

def ADDON_operate(IDD):
	js_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.GetAddonDetails", "params": {"addonid":"'+IDD+'", "properties": ["enabled"]}, "id":1}')
	if '"enabled":false' in js_query:
		try:
			xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid":"'+IDD+'", "enabled":true}, "id":1}')
			failing("(ADDON_operate) ERROR - ERROR - ERROR :\n##### Das benötigte Addon : *{0}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####".format(IDD))
		except: pass
	if '"error":' in js_query:
		dialog.ok(addon_id, translation(30501).format(IDD))
		failing("(ADDON_operate) ERROR - ERROR - ERROR :\n##### Das benötigte Addon : *{0}* ist NICHT installiert !!! #####".format(IDD))
		return False
	if '"enabled":true' in js_query:
		return True

def build_url(query):
	return '{0}?{1}'.format(HOST_AND_PATH, urlencode(query))

def makeREQUEST(url):
	return cache.cacheFunction(getUrl, url)

def getUrl(url, header=None, data=None, referer=None, agent='Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0'):
	opener = build_opener()
	opener.addheaders = [('User-Agent', agent), ('Accept-Encoding', 'gzip, identity')]
	try:
		if header: opener.addheaders = header
		if referer: opener.addheaders = [('Referer', referer)]
		response = opener.open(url, data=data, timeout=30)
		if response.info().get('Content-Encoding') == 'gzip':
			content = py3_dec(gzip.GzipFile(fileobj=io.BytesIO(response.read())).read())
		else:
			content = py3_dec(response.read())
	except Exception as e:
		failure = str(e)
		failing("(getUrl) ERROR - ERROR - ERROR : ########## {0} === {1} ##########".format(url, failure))
		if 'cdnapisec.kaltura.com' in url and '404' in failure:
			KPid = url.split('entryId/')[1].split('/format')[0]
			dialog.notification(translation(30527), translation(30528).format(KPid), icon, 15000)
		else:
			dialog.notification(translation(30521).format('URL'), "ERROR = [COLOR red]{0}[/COLOR]".format(failure), icon, 15000)
		return sys.exit(0)
	return py2_enc(content)

def utc_to_local(dt):
	if time.localtime().tm_isdst: return dt - timedelta(seconds=time.altzone)
	else: return dt - timedelta(seconds=time.timezone)

def cleaning(text):
	text = py2_enc(text)
	for n in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&apos;', "'"), ("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('►', '>'), ('3+ ', ''),
				('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''), ('\xc2\xb7', '-'),
				('&quot;', '"'), ('&szlig;', 'ß'), ('&ndash;', '-'), ('&Auml;', 'Ä'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&ouml;', 'ö'), ('&uuml;', 'ü'),
				('&agrave;', 'à'), ('&aacute;', 'á'), ('&acirc;', 'â'), ('&egrave;', 'è'), ('&eacute;', 'é'), ('&ecirc;', 'ê'), ('&igrave;', 'ì'), ('&iacute;', 'í'), ('&icirc;', 'î'),
				('&ograve;', 'ò'), ('&oacute;', 'ó'), ('&ocirc;', 'ô'), ('&ugrave;', 'ù'), ('&uacute;', 'ú'), ('&ucirc;', 'û'), ('_', ' ')):
				text = text.replace(*n)
	return text.strip()

def extractSHOW(text):
	text = py2_enc(text)
	namesList = []
	readyList = ['Adieu Heimat - Schweizer wandern aus', 'Der Bachelor@', 'Die Bachelorette', 'Bauer, ledig, sucht...', 'Bumannn, der Restauranttester',
						'Notruf - Bergretter im Einsatz', 'Notruf - Retter@ im Einsatz', 'Schatz oder Plunder - Fundstücke vom Land', 'The Voice of Switzerland', 'Jung, wild und sexy',
						'Mama ich bin schwanger', 'Camping Paradiso', 'Undercover Boss', 'Liebesglück im Osten', 'Die Bellers', 'Mike Shiva', 'Supervujo',
						'Big Pictures', 'Bernegger & Juric, die Kommissare', 'Adam & Eva', 'Die Zehn', 'Wer wird Millionär', 'Sing and Win!', 'Supermodel']
	spTitle = re.sub('[{@$%#^\\/;,:*?!\"+<>|}]', '', text)
	spTitle = spTitle.lower().replace('notruf staffel', 'retter').replace('notruf', '').replace('einsatz', '').replace('vom land', '').replace('bls', 'bauer ').replace('sumo', 'supermodel ').replace('staffel ', '').replace('folge ', '').split(' ')
	for item in spTitle:
		if item == 'bachelor': item = 'bachelor@' 
		if item == 'retter': item = 'retter@'
		if len(item) >= 4:
			minWord = str(item)
			namesList.append(minWord)
	debug_MS("(extractSHOW) ### namesList : {0} ###".format(str(namesList)))
	for elem in readyList:
		for minWord in namesList:
			if minWord in elem.lower():
				text = elem.replace('@', '')
	return text.strip()

def parameters_string_to_dict(parameters):
	paramDict = {}
	if parameters:
		paramPairs = parameters[1:].split('&')
		for paramsPair in paramPairs:
			paramSplits = paramsPair.split('=')
			if (len(paramSplits)) == 2:
				paramDict[paramSplits[0]] = paramSplits[1]
	return paramDict

params = parameters_string_to_dict(sys.argv[2])
url = unquote_plus(params.get('url', ''))
mode = unquote_plus(params.get('mode', 'root'))
extras = unquote_plus(params.get('extras', 'standard'))
limit = unquote_plus(params.get('limit', '1'))
IDENTiTY = unquote_plus(params.get('IDENTiTY', ''))
referer = unquote_plus(params.get('referer', ''))
