﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
import _strptime
from datetime import datetime, timedelta
import threading
import traceback
from collections import OrderedDict, defaultdict
import ast
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote  # Python 2.X
else: 
	from urllib.parse import urlencode, quote  # Python 3.X

from .common import *


COMBI_INDEX, COMBI_SIMPLE, COMBI_TEASER, COMBI_DEEPER = ([] for _ in range(4))
pill2kill = threading.Event()


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listStartpage', 'url': 'sendungen'})
	addDir(translation(30602), icon, {'mode': 'listMiscellaneous', 'url': 'neue-folgen', 'extras': 'NewEpisodes'})
	addDir(translation(30603), artpic+'heimat.jpg', {'mode': 'listArticles', 'url': 'adieu-heimat', 'extras': artpic+'heimat.jpg'}, background=True)
	addDir(translation(30604), artpic+'bauer.jpg', {'mode': 'listArticles', 'url': 'bauer-ledig-sucht', 'extras': artpic+'bauer.jpg'}, background=True)
	addDir(translation(30605), artpic+'bumann.jpg', {'mode': 'listArticles', 'url': 'bumann-der-restauranttester', 'extras': artpic+'bumann.jpg'}, background=True)
	addDir(translation(30609), artpic+'basesearch.png', {'mode': 'Search3PLUS'})
	if enableADJUSTMENT:
		addDir(translation(30610), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30611), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listStartpage(idd): # https://www.3plus.tv/api/pub/gql/tvnational/Page/088ad56e73222a92e44e476061740c2f63881928?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2Fsendungen%22%2C%22ressort%22%3A%22sendungen%22%7D
	debug_MS("(navigator.listStartpage) ------------------------------------------------ START = listStartpage -----------------------------------------------")
	debug_MS("(navigator.listStartpage) ### IDD : {0} ###".format(str(idd)))
	START_FIRST, START_SECOND, START_RESULT = ([] for _ in range(3))
	cd = defaultdict(list)
	START_FIRST = getMultiData([idd], 'START')
	if START_FIRST:
		for sub in START_FIRST:
			cd[sub[0]] += [sub]
		for separated in cd.values():
			START_SECOND = [i[2] for i in separated]
			debug_MS("(navigator.listStartpage[01]) ### START_SECOND : {0} ###".format(START_SECOND))
		if START_SECOND:
			START_RESULT = getMultiData(START_SECOND, 'SHOWS')
			debug_MS("(navigator.listStartpage[02]) ### START_RESULT : {0} ###".format(str(START_RESULT)))
			if START_RESULT:
				for name, desc, image, SE_link in sorted(START_RESULT, key=lambda d:d[0], reverse=False):
					addDir(name, image, {'mode': 'listArticles', 'url': SE_link, 'extras': image}, desc)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listArticles(idd, photo): # https://www.3plus.tv/api/pub/gql/tvnational/Page/088ad56e73222a92e44e476061740c2f63881928?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2Fbauer-ledig-sucht%22%2C%22ressort%22%3A%22bauer-ledig-sucht%22%7D
	debug_MS("(navigator.listArticles) ------------------------------------------------ START = listArticles -----------------------------------------------")
	debug_MS("(navigator.listArticles) ### IDD : {0} ###".format(str(idd)))
	ARTI_FIRST, ARTI_RESULT = ([] for _ in range(2))
	cd = defaultdict(list)
	ARTI_FIRST = getMultiData([idd], 'FOLDER')
	if ARTI_FIRST:
		for sub in ARTI_FIRST:
			cd[sub[0]] += [sub]
		for separated in sorted(cd.values(), key=lambda d:d[0], reverse=False):
			ARTI_RESULT = [i[2] for i in separated]
			debug_MS("(navigator.listArticles[01]) ### ARTI_RESULT : {0} ###".format(ARTI_RESULT))
			if ARTI_RESULT:
				solo = separated[0][0].replace('Standard-Newsmanager', 'Ganze Folgen')
				if 'alles zur ' in solo.lower(): catching = 'ArticlesShort' # Alles zur Sendung
				elif 'ganze folgen' in solo.lower(): catching = 'ArticlesFolgen' # Ganze Folgen
				elif ' staffel' in solo.lower(): catching = 'ArticlesSeasons' # Weitere Staffeln / Alle Staffeln
				else: catching = 'ArticlesComplete' # NICHT FESTGELEGT
				if catching == 'ArticlesSeasons':
					addDir(solo, photo, {'mode': 'listSeasons', 'url': ARTI_RESULT})
				else:
					addDir(solo, photo, {'mode': 'listMiscellaneous', 'url': ARTI_RESULT, 'extras': catching})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(idd): # https://www.3plus.tv/api/pub/gql/tvnational/NewsArticleTeaser/a4016f65fe62b81dc6664dd9f4910e4ab40383be?variables=%7B%22contextId%22%3A%22NewsArticle%3A140314540%22%7D
	debug_MS("(navigator.listSeasons) ------------------------------------------------ START = listSeasons -----------------------------------------------")
	debug_MS("(navigator.listSeasons) ### IDD : {0} ###".format(str(idd)))
	SEAS_FIRST, SEAS_RESULT = ([] for _ in range(2))
	SEAS_FIRST = ast.literal_eval(idd)
	SEAS_RESULT = getMultiData(SEAS_FIRST)
	debug_MS("(navigator.listSeasons[01]) ### SEAS_RESULT : {0} ###".format(str(SEAS_RESULT)))
	if SEAS_RESULT:
		SEAS_RESULT = sorted(SEAS_RESULT, key=lambda x:x[11], reverse=True)
		for title, origSERIE, season, episode, duration, startTIMES, desc, kalturaId, image, SE_link, SE_type, pos_SE, pos_EP, pos_OT in SEAS_RESULT:
			addDir('Staffel '+str(season), image, {'mode': 'listMiscellaneous', 'url': SE_link, 'extras': 'SeasonsSingle'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def Search3PLUS():
	debug_MS("(navigator.Search3PLUS) ------------------------------------------------ START = Search3PLUS -----------------------------------------------")
	keyword = None
	if xbmcvfs.exists(searchHackFile):
		with open(searchHackFile, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading="Search 3PLUS ...", type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
		if keyword:
			keyword = quote(keyword)
			with open(searchHackFile, 'w') as record:
				record.write(keyword)
	if keyword: return listMiscellaneous(keyword, 'SearchFeature')
	return None

def listMiscellaneous(idd, extras): # https://www.3plus.tv/api/pub/gql/tv3plus/NewsArticleTeaser/2d5925defbf8ae31f3604f3dd6a5e44783a46a11?variables=%7B%22contextId%22%3A%22NewsArticle%3A136264072%22%7D
	debug_MS("(navigator.listMiscellaneous) ------------------------------------------------ START = listMiscellaneous -----------------------------------------------")
	newIDD = [obj.replace('/', '%2F') for obj in idd] if isinstance(idd, list) else idd.replace('/', '%2F')
	message = translation(30524) if isinstance(idd, list) else translation(30525).format(newIDD.split('%2F')[-1].replace('-', ' ').title())
	debug_MS("(navigator.listMiscellaneous) ### IDD : {0} ### EXTRAS : {1} ###".format(newIDD, str(extras)))
	UN_Supported = ['dokumentation', 'film', 'serie', 'sport', 'eigenproduktion'] # these lists are empty or not compatible
	UN_Wanted = ['anmeldung', 'aufruf', 'bewirb dich', 'jetzt anmelden', 'sponsor'] # these names are not wanted
	SEND = {}
	SEND['videos'], MISC_SEARCH, MISC_FIRST, MISC_SECOND, MISC_THIRD, MISC_FOURTH, MISC_RESULT = ([] for _ in range(7))
	FOUND = False
	Isolated = set()
	if extras == 'SearchFeature':
		debug_MS("(navigator.Searching[01]) ### investigationTERM : {0} ###".format(idd))
		pageNUMBER = 1
		count, number = (0 for _ in range(2))
		while pageNUMBER <= 3:
			"""https://www.3plus.tv/api/pub/gql/tv3plus/Search/8edd5397e0fd160310524073f04d8200325310ed?variables=%7B%22fulltext%22%3A%22bauer%20sucht%22%2C%22assetType%22%3Anull%2C%22functionScore%22%3A%22%22%2C%22offset%22%3A0%7D"""
			newURL = API_URL+'Search/8edd5397e0fd160310524073f04d8200325310ed?variables=%7B%22fulltext%22%3A%22{0}%22%2C%22assetType%22%3Anull%2C%22functionScore%22%3A%22%22%2C%22offset%22%3A{1}%7D'.format(idd, str(count))
			content = getUrl(newURL)
			response = json.loads(content)['data']['search']['fulltext']['newsarticles']
			if 'total' in response and response['total'] == 0 or 'data' in response and response['data'] is None:
				mainMenu()
				return dialog.notification(translation(30522).format('Ergebnisse'), translation(30524), icon, 8000)
			else:
				for item in response['data']:
					contextType = (item.get('baseType', '00') or '00')
					contextId = (item.get('id', '00') or '00')
					typeName = (item.get('__typename', '00') or '00')
					if typeName == 'Reference': number += 1
					if contextId in Isolated or contextId == '00' or typeName != 'Reference':
						continue
					Isolated.add(contextId)
					debug_MS("(navigator.Searching[01]) ### [::{0}] || baseType = {1} || contextId = {2} ###".format(str(number), contextType, str(contextId)))
					MISC_SEARCH.append(contextId)
			pageNUMBER += 1
			count += 50
	if extras in ['ArticlesComplete', 'ArticlesFolgen', 'ArticlesShort']:
		MISC_FIRST = ast.literal_eval(idd)
	elif extras == 'SearchFeature' and MISC_SEARCH: # Verwendung für = Suchfunktion
		MISC_FIRST = MISC_SEARCH
	else:
		articleNUM = [obj.split('-')[-1] for obj in idd] if isinstance(idd, list) else idd.split('-')[-1]
		if extras != 'NewEpisodes' and articleNUM.isdigit() and len(articleNUM) > 5: # Verwendung für = Jeden einzelnen Staffelordner
			MISC_FIRST = getMultiData([newIDD], 'TEASER')
		else: # Verwendung für = Neue Videos 
			MISC_FIRST = getMultiData([newIDD], 'SIMPLE')
	if MISC_FIRST:
		title, origSERIE, Note_1, Note_2, Note_3, desc, image, SE_link = ("" for _ in range(8))
		season, episode, duration = ('0' for _ in range(3))
		kalturaId, SE_type, pos_SE, pos_EP, pos_OT = ('00' for _ in range(5))
		startTIMES =None
		MISC_RESULT = getMultiData(MISC_FIRST)
		if MISC_RESULT and extras not in ['ArticlesComplete', 'ArticlesShort', 'SearchFeature']: # Für ganze folgen = 'ArticlesFolgen' und 'NewEpisodes'
			for title, origSERIE, season, episode, duration, startTIMES, desc, kalturaId, image, SE_link, SE_type, pos_SE, pos_EP, pos_OT in MISC_RESULT:
				if ('folge' in SE_link or 'folge ' in title.lower() or 'episode ' in title.lower()):
					FOUND = True
					MISC_SECOND.append(SE_link)
			if MISC_SECOND and FOUND is True:
				debug_MS("(navigator.listMiscellaneous[02]) ### MISC_SECOND : {0} ###".format(str(MISC_SECOND)))
				MISC_THIRD = getMultiData(MISC_SECOND, 'DEEPER')
				if MISC_THIRD:
					debug_MS("(navigator.listMiscellaneous[02]) ### MISC_THIRD : {0} ###".format(str(MISC_THIRD)))
					MISC_FOURTH = getMultiData(MISC_THIRD)
					if MISC_FOURTH:
						debug_MS("(navigator.listMiscellaneous[02]) ### MISC_FOURTH : {0} ###".format(str(MISC_FOURTH)))
						debug_MS("(navigator.listMiscellaneous) ++++++++++++++++++++")
						MISC_RESULT = MISC_FOURTH
			else: pass
	else:
		return dialog.notification(translation(30522).format('Einträge'), message, icon, 8000)
	if MISC_RESULT:
		position = 3 if extras == 'ArticlesShort' else len(MISC_RESULT)
		COURSE = False if SORTING == '1' else True
		if extras in ['ArticlesComplete', 'ArticlesShort']:
			MISC_RESULT = sorted(MISC_RESULT, key=lambda x:x[0], reverse=False)
		else:
			MISC_RESULT = sorted(MISC_RESULT, key=lambda x: (x[11], x[12], x[13]), reverse=COURSE)
		for title, origSERIE, season, episode, duration, startTIMES, desc, kalturaId, image, SE_link, SE_type, pos_SE, pos_EP, pos_OT in MISC_RESULT:
			if origSERIE and episode != '0' and not 'ArticlesShort' in extras:
				suffix = 'S.'+season.zfill(2)+' - E.'+episode.zfill(2) if season != '0' else 'E.'+episode.zfill(2)
				Note_1 = origSERIE+translation(30620).format(suffix)+'[CR]'
				Note_3 = translation(30620).format(suffix)
			elif origSERIE and (episode == '0' or 'ArticlesShort' in extras):
				Note_1 = origSERIE+'[CR]'
			if startTIMES: Note_2 = translation(30621).format(str(startTIMES))
			elif startTIMES is None and Note_1 != "": Note_2 = '[CR]'
			plot = Note_1+Note_2+desc
			name = title+Note_3
			debug_MS("(navigator.listMiscellaneous[03]) ### pos_SE : {0} || pos_EP : {1} || pos_OT : {2} ###".format(str(pos_SE), str(pos_EP), str(pos_OT)))
			debug_MS("(navigator.listMiscellaneous[03]) ### TITLE = {0} || SEASON = {1} || EPISODE = {2} || startTIMES = {3} ###".format(name, str(season), str(episode), str(startTIMES)))
			debug_MS("(navigator.listMiscellaneous[03]) ### SERIE = {0} || kalturaId = {1} || FOTO = {2} || DURATION = {3} ###".format(origSERIE, kalturaId, str(image), str(duration)))
			debug_MS("(navigator.listMiscellaneous[03]) ### SE_LINK : {0} || SE_TYPE : {1} || START : {2} ###".format(str(SE_link), str(SE_type), str(startTIMES)))
			if kalturaId != '00' and kalturaId in Isolated:
				continue
			Isolated.add(kalturaId)
			if any(n in name.lower() for n in UN_Wanted) or any(o in origSERIE.lower() for o in UN_Wanted): continue # Episoden mit bestimmten Wörtern im Namen ausblenden
			if kalturaId == '00': continue # name = translation(30622).format(name) # Episoden ohne Video-ID ausblenden
			if duration != '0' and int(duration) < 70 and position > 3: continue # Werbetrailer ausblenden
			listitem = xbmcgui.ListItem(name, path=HOST_AND_PATH+'?IDENTiTY='+kalturaId+'&mode=playCODE')
			info = {}
			if season != '0':
				info['Season'] = season
			info['Episode'] = episode
			info['Tvshowtitle'] = origSERIE
			info['Title'] = name
			info['Tagline'] = None
			info['Plot'] = plot
			info['Duration'] = duration
			info['Year'] = None
			info['Genre'] = 'Eigenproduktion'
			info['Studio'] = '3plus.tv'
			info['Mpaa'] = None
			info['Mediatype'] = 'episode'
			listitem.setInfo(type='Video', infoLabels=info)
			listitem.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
			if image and useThumbAsFanart and image != icon and not artpic in image:
				listitem.setArt({'fanart': image})
			listitem.addStreamInfo('Video', {'Duration':duration})
			listitem.setProperty('IsPlayable', 'true')
			listitem.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+kalturaId+'&mode=playCODE', listitem=listitem)
			SEND['videos'].append({'filter': kalturaId, 'tvshow': origSERIE, 'name': name, 'pict': image, 'season': season, 'episode': episode, 'cycle': duration})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listContentIndex(part, pill2kill, course):
	if not pill2kill.is_set():
		try:
			desc, desc2, image, SE_link = ("" for _ in range(4))
			season, episode, duration = ('0' for _ in range(3))
			SE_type, pos_SE, pos_EP, pos_OT, kalturaId = ('00' for _ in range(5))
			title, origSERIE, startTIMES = (None for _ in range(3))
			"""https://www.3plus.tv/api/pub/gql/tvnational/NewsArticleTeaser/a4016f65fe62b81dc6664dd9f4910e4ab40383be?variables=%7B%22contextId%22%3A%22NewsArticle%3A140349351%22%7D"""
			link = API_URL+'NewsArticleTeaser/a4016f65fe62b81dc6664dd9f4910e4ab40383be?variables=%7B%22contextId%22%3A%22{0}%22%7D'.format(quote(part))
			debug_MS("(navigator.listContentIndex[01]) ### LINK : {0} ###".format(str(link)))
			result = getUrl(link)
			short = json.loads(result)['data']['context']
			if short.get('title', ''):
				title = cleaning(short['title'])
			if short.get('mainAsset', '') and short.get('mainAsset', {}).get('description', ''):
				desc2 = short.get('mainAsset', {}).get('description', '')
			desc = (short.get('text', '') or short.get('lead', '') or desc2)
			if desc and len(desc) > 10: desc = cleaning(desc)
			# grösste Auflösung = https://static.az-cdn.ch/__ip/9w9PsDp2QzKB3vvT_4ZFEPzztfQ/8a0585a3041972617a5abe010d3c6407a2901bbd/n-ch12_2x-16x9-far
			if short.get('teaserImage', '') and short.get('teaserImage', {}).get('image', '') and short.get('teaserImage', []).get('image', {}).get('url', ''):
				image = short['teaserImage']['image']['url']+'n-ch12_2x-16x9-far'
			if short.get('headRessort', '') and short.get('headRessort', {}).get('urls', '') and short.get('headRessort', []).get('urls', {}).get('relative', ''):
				SE_link = short['headRessort']['urls']['relative'][1:].replace('/', '%2F')
			elif short.get('urls', '') and short.get('urls', {}).get('relative', ''):
				SE_link = short['urls']['relative'][1:].replace('/', '%2F')
			if course == 'SHOWS' and SE_link != '00':
				COMBI_INDEX.append([title, desc, image, SE_link])
			elif course == 'ENTRIES':
				SE_type = (short.get('contextLabel', '00') or short.get('labelType', '00') or '00')
				if short.get('mainRessort', '') and short.get('mainRessort', {}).get('title', ''):
					origSERIE = cleaning(short['mainRessort']['title'])
				if origSERIE is None and short.get('mainAsset', '') and short.get('mainAsset', {}).get('title', ''):
					origSERIE = cleaning(short['mainAsset']['title'])
					if title is None: title = cleaning(short['mainAsset']['title'])
				matchSE_1 = re.search('(Staffel |ST |ST|BLS |BLS)(\d+)', origSERIE) # Staffel 9
				if matchSE_1: season = matchSE_1.group(2)
				else:
					matchSE_2 = re.search('(season|staffel)\-(\d+)', SE_link.replace('%2F', '/')) # bumann-der-restauranttester/staffel-9-137978040
					if matchSE_2: season = matchSE_2.group(2)
				pos_SE = season.zfill(2)
				matchEP_1 = re.search('(Episode|Folge)\ (\d+)', title) # Folge 11 - Paninoteca
				if matchEP_1: episode = matchEP_1.group(2) # Episode 2
				else:
					matchEP_2 = re.search('(-episode|/episode|-folge|/folge)\-(\d+)', SE_link.replace('%2F', '/')) # bumann-der-restauranttester/folge-11-paninoteca-136261756
					if matchEP_2:
						if len(matchEP_2.group(2)) < 5: episode = matchEP_2.group(2) # Nur Folgen mit max. 4 Stellen - KEINE NewsArticleNumbers
				pos_EP = episode.zfill(2)
				matchOT_1 = re.search('(Teil)\ (\d+)', title) # Folge 5 / Teil 3
				if matchOT_1: pos_OT = matchOT_1.group(2).zfill(2) # Teil 3
				else:
					matchOT_2 = re.search('(-teil|/teil)\-(\d+)', SE_link.replace('%2F', '/')) # adieu-heimat-schweizer-wandern-aus-staffel-6/folge-5-teil-3-138966529
					if matchOT_2: pos_OT = matchOT_2.group(2).zfill(2)
				if pos_OT == '00': pos_OT = '01'
				origSERIE = origSERIE.split('Staffel')[0].strip()
				if str(short.get('displayDate', ''))[:10].replace('.', '').replace('-', '').replace('/', '').isdigit():
					LOCALstart = get_Local_DT(short['displayDate'][:19])
					startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				if short.get('mainAsset', '') and short.get('mainAsset', {}).get('video', '') and short.get('mainAsset', []).get('video', {}).get('kaltura', ''):
					if short.get('mainAsset').get('video').get('kaltura').get('kalturaId', None):
						kalturaId = str(short['mainAsset']['video']['kaltura']['kalturaId'])
					if short.get('mainAsset').get('video').get('kaltura').get('meta', None) and short.get('mainAsset').get('video').get('kaltura').get('meta').get('duration', None):
						duration = short['mainAsset']['video']['kaltura']['meta']['duration']
				COMBI_INDEX.append([title, origSERIE, season, episode, duration, startTIMES, desc, kalturaId, image, SE_link, SE_type, pos_SE, pos_EP, pos_OT])
		except:
			stopping()
			if enableWARNINGS:
				dialog.notification(translation(30521).format(course), translation(30523), icon, 10000)
			failing("(navigator.listContentIndex) ERROR - ERROR - ERROR : {0} || {1}".format(course, traceback.format_exc()))

def listSimpleConverter(part, pill2kill, course):
	if not pill2kill.is_set():
		try:
			UN_Supported = ['dokumentation', 'film', 'serie', 'sport', 'eigenproduktion'] # these lists are empty or not compatible
			sim_Isolated = set()
			name, group, contextId = ('00' for _ in range(3))
			FOUND = False
			TITLELIST =[]
			newIDD = str(part).replace('/', '%2F')
			simTXT_1 = str(newIDD)
			simTXT_2 = str(newIDD.split('%2F')[0])
			simTXT_3 = str(newIDD.split('%2F')[-1])
			"""https://www.3plus.tv/api/pub/gql/tvnational/Page/088ad56e73222a92e44e476061740c2f63881928?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2Fneue-folgen%22%2C%22ressort%22%3A%22neue-folgen%22%2C%22subressort%22%3A%22neue-folgen%22%7D"""
			link = API_URL+'Page/088ad56e73222a92e44e476061740c2f63881928?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2F{0}%22%2C%22ressort%22%3A%22{1}%22%2C%22subressort%22%3A%22{2}%22%7D'.format(simTXT_1, simTXT_2, simTXT_3)
			content = getUrl(link)
			debug_MS("(navigator.listSimpleConverter[01]) ### LINK : {0} ###".format(str(link)))
			testing = len(json.loads(content)['data']['page']['layout']['content']['content'])
			if testing == 1:
				segment = json.loads(content)['data']['page']['layout']['content']['content'][0]['content'][0]['content']
			elif testing == 2:
				segment = json.loads(content)['data']['page']['layout']['content']['content'][1]['content'][0]['content']
			for item in segment:
				type, title, category, newsarticle, newstype = jsExtract(item, 'type'), jsExtract(item, 'title'), jsExtract(item, 'group'), jsExtract(item, 'contextId'), jsExtract(item, 'contextType')
				debug_MS("(navigator.listSimpleConverter[TEST]) ### TITLE = {0} || TYPE = {1} ###".format(title, type))
				if len(type) == 2 and len(title) == 1:
					name = cleaning(title[0])
					FOUND = True
				if category:
					for i in range(len(category)):
						group = category[i]
				if newsarticle and newstype:
					for i in range(len(newsarticle)):
						contextId = newsarticle[i]
						if course == 'START':
							if contextId in sim_Isolated or FOUND and not part in name.lower():
								continue
							sim_Isolated.add(contextId)
							if not FOUND: name = 'NOT FOUND'
						elif course == 'FOLDER':
							if contextId in sim_Isolated or FOUND and any(n in name.lower() for n in UN_Supported):
								continue
							sim_Isolated.add(contextId)
							if not FOUND: name = 'NEUE FOLGEN'
						else:
							if contextId in sim_Isolated:
								continue
							sim_Isolated.add(contextId)
						debug_MS("(navigator.listSimpleConverter[02]) ### TITLE = {0} || Group = {1} || contextId = {2} ###".format(name, group, str(contextId)))
						if course in ['START', 'FOLDER']:
							COMBI_SIMPLE.append([name, group, contextId])
						elif course == 'SIMPLE':
							COMBI_SIMPLE.append(contextId)
		except:
			stopping()
			if enableWARNINGS:
				dialog.notification(translation(30521).format(course), translation(30523), icon, 10000)
			failing("(navigator.listSimpleConverter) ERROR - ERROR - ERROR : {0} || {1}".format(course, traceback.format_exc()))

def listTeaserMinis(part, pill2kill, course):
	if not pill2kill.is_set():
		try:
			vid_Isolated = set()
			baseType, baseId, baseName = ('00' for _ in range(3))
			vidTXT_1 = str(part)
			vidNUM = str(part.split('-')[-1])
			vidTXT_2 = str(part.split('%2F')[0])
			"""https://www.3plus.tv/api/pub/gql/tvnational/Page/911ba7f22ae53b0b316e750c1b27ebab7a739369?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2Fbauer-ledig-sucht-staffel-15%2Ffolge-13-136262576%22%2C%22articleId%22%3A%22136262576%22%2C%22ressort%22%3A%22bauer-ledig-sucht-staffel-15%22%7D"""
			link = API_URL+'Page/911ba7f22ae53b0b316e750c1b27ebab7a739369?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2F{0}%22%2C%22articleId%22%3A%22{1}%22%2C%22ressort%22%3A%22{2}%22%7D'.format(vidTXT_1, vidNUM, vidTXT_2)
			content = getUrl(link)
			debug_MS("(navigator.listTeaserMinis[01]) ### LINK : {0} ###".format(str(link)))
			DATA = json.loads(content)
			if 'data' in DATA and 'page' in DATA['data'] and 'context' in DATA['data']['page'] and 'blockRecommendations' in DATA['data']['page']['context'] and DATA['data']['page']['context']['blockRecommendations'] and len(DATA['data']['page']['context']['blockRecommendations']) > 1:
				response = DATA['data']['page']['context']['blockRecommendations'][0]['recommendationData']
				for item in response:
					baseType = (item.get('baseType', '00') or '00')
					baseId = (item.get('id', '00') or '00')
					baseName = (item.get('__typename', '00') or '00')
					if baseId in vid_Isolated or baseId == '00' or baseName != 'Reference':
						continue
					vid_Isolated.add(baseId)
					if course == 'TEASER':
						COMBI_TEASER.append(baseId)
					if course == 'DEEPER':
						COMBI_DEEPER.append(baseId)
		except:
			stopping()
			if enableWARNINGS:
				dialog.notification(translation(30521).format(course), translation(30523), icon, 10000)
			failing("(navigator.listTeaserMinis) ERROR - ERROR - ERROR : {0} || {1}".format(course, traceback.format_exc()))

def stopping():
	pill2kill.set()

def getMultiData(simultan, event='ENTRIES'):
	debug_MS("(navigator.getMultiData) ------------------------------------------------ START = getMultiData -----------------------------------------------")
	threads = []
	if event in ['ENTRIES', 'SHOWS']:
		object, note = listContentIndex, "(navigator.listContentIndex) ------------------------------------------------ START = listContentIndex -----------------------------------------------"
	elif event in ['START', 'FOLDER', 'SIMPLE']:
		object, note = listSimpleConverter, "(navigator.listSimpleConverter) ------------------------------------------------ START = listSimpleConverter -----------------------------------------------"
	elif event in ['TEASER', 'DEEPER']:
		object, note = listTeaserMinis, "(navigator.listTeaserMinis) ------------------------------------------------ START = listTeaserMinis -----------------------------------------------"
	debug_MS("(navigator.getMultiData) ganze LISTE XXXXX {0} XXXXX".format(' || '.join(simultan)))
	debug_MS(note)
	for article in simultan:
		th = threading.Thread(target=object, args=[article, pill2kill, event])
		if hasattr(th, 'daemon'): th.daemon = True
		else: th.setDaemon()
		threads.append(th)
	[th.start() for th in threads]
	threading.Timer(25, after_timeout, [threads, pill2kill]).start()
	[th.join(3) for th in threads]
	debug_MS("(navigator.getMultiData) ++++++++++++++++++++")
	if event in ['ENTRIES', 'SHOWS'] and COMBI_INDEX:
		debug_MS("(navigator.listContentIndex) Ergebnis XXXXX COMBI_INDEX = {0} XXXXX".format(str(COMBI_INDEX)))
		debug_MS("(navigator.getMultiData) ++++++++++++++++++++")
		return COMBI_INDEX
	elif event in ['START', 'FOLDER', 'SIMPLE'] and COMBI_SIMPLE:
		debug_MS("(navigator.listSimpleConverter) Ergebnis XXXXX COMBI_SIMPLE = {0} XXXXX".format(str(COMBI_SIMPLE)))
		debug_MS("(navigator.getMultiData) ++++++++++++++++++++")
		return COMBI_SIMPLE
	elif event == 'TEASER' and COMBI_TEASER:
		debug_MS("(navigator.listTeaserMinis) Ergebnis XXXXX COMBI_TEASER = {0} XXXXX".format(str(COMBI_TEASER)))
		debug_MS("(navigator.getMultiData) ++++++++++++++++++++")
		return COMBI_TEASER
	elif event == 'DEEPER' and COMBI_DEEPER:
		debug_MS("(navigator.listTeaserMinis) Ergebnis XXXXX COMBI_DEEPER = {0} XXXXX".format(str(COMBI_DEEPER)))
		debug_MS("(navigator.getMultiData) ++++++++++++++++++++")
		return COMBI_DEEPER

def after_timeout(threads, pill2kill):
	counter = 0
	for th in threads:
		if th.is_alive() and counter == 0:
			counter += 1
			failing("(navigator.after_timeout) TIMEOUT ##### !!! DIE MAX. ZEIT FÜR THREADS IST ABGELAUFEN - KILLING THEM ALL !!! #####")
			stopping()
	return

def playCODE(IDD):
	debug_MS("(navigator.playCODE) ------------------------------------------------ START = playCODE -----------------------------------------------")
	debug_MS("(navigator.playCODE) ### IDD : {0} ###".format(str(IDD)))
	# try .mpd = https://cdnapisec.kaltura.com/p/1719221/sp/1719221/playManifest/entryId/1_umsmi7ru/flavorIds/1_m6asgeiw,1_w1plk7og,1_5che52vt,1_l6xsf1q1/deliveryProfileId/10182/protocol/https/format/mpegdash/manifest.mpd
	# all of .m3u8 = https://cdnapisec.kaltura.com/p/1719221/sp/171922100/playManifest/entryId/1_ayo0p0vy/format/applehttp/protocol/https/a.m3u8?responseFormat=json
	# .m3u8 = https://cfvod.kaltura.com/hls/p/1719221/sp/171922100/serveFlavor/entryId/1_6hrjp75i/v/1/ev/7/flavorId/1_fbhvz56l/name/a.mp4/index.m3u8
	# .mp4 = https://cfvod.kaltura.com/p/1719221/sp/171922100/serveFlavor/entryId/1_6hrjp75i/v/1/ev/7/flavorId/1_fbhvz56l/name/a.mp4
	MEDIAS = []
	STREAM, finalURL = (False for _ in range(2))
	entryId = '00'
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] == IDD:
				entryId = elem['filter']
				seriesname = py2_enc(elem['tvshow'])
				name = py2_enc(elem['name'])
				image = elem['pict']
				season = elem['season']
				episode = elem['episode']
				duration = elem['cycle']
	if IDD != '00' and entryId != '00':
		kalturaURL = 'https://cdnapisec.kaltura.com/p/{0}/sp/{0}00/playManifest/entryId/{1}/format/applehttp/protocol/https/a.m3u8?responseFormat=json'.format(PartnerId, entryId)
		"""OLD : firstUrl = 'https://cdnapisec.kaltura.com/p/{0}/sp/{0}00/playManifest/entryId/{1}/format/applehttp/protocol/https/a.m3u8?responseFormat=json'.format(PartnerId, entryId)"""
		ref = 'https://license.theoplayer.com/'
		content = getUrl(kalturaURL, referer=ref)
		debug_MS("(navigator.playCODE[1]) ### kalturaURL : {0} ###".format(str(kalturaURL)))
		result = json.loads(content)
		for elem in result['flavors']:
			VID = elem['url']
			EXT = elem['ext']
			HEIGHT = elem['height']
			if EXT in ['vnd.apple.mpegURL', 'x-mpegurl', 'mp4']:
				MEDIAS.append({'url': VID, 'mimeType': EXT, 'height': HEIGHT})
				MEDIAS = sorted(MEDIAS, key=lambda b:b['height'], reverse=True)
				debug_MS("(navigator.playCODE[2]) listing_Streams ### HEIGHT = "+str(HEIGHT)+" || URL = "+VID+" || mimeTYPE = "+EXT+" ###")
		if MEDIAS:
			if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
				for item in MEDIAS:
					if 'hls/' in MEDIAS[0]['url'] and '.m3u8' in MEDIAS[0]['url']:
						STREAM = 'HLS'
						MIME = str(MEDIAS[0]['mimeType'])
						finalURL = MEDIAS[0]['url']
						QUALITY = str(MEDIAS[0]['height'])
						debug_MS("(navigator.playCODE[3]) selected_Video ### HEIGHT = "+QUALITY+" || finalURL = "+finalURL+" || mimeTYPE = "+MIME+" || streamTYPE = "+STREAM+" ###")
						break
			if not finalURL and prefSTREAM in ['0', '1']:
				for item in MEDIAS:
					if prefSTREAM == '0' and '.m3u8' in item['url'] and item['height'] == prefQUALITY:
						STREAM = 'M3U8'
						MIME = str(item['mimeType'])
						finalURL = item['url']
						QUALITY = str(item['height'])
						debug_MS("(navigator.playCODE[3]) selected_Video ### HEIGHT = "+QUALITY+" || finalURL = "+finalURL+" || mimeTYPE = "+MIME+" || streamTYPE = "+STREAM+" ###")
					elif prefSTREAM == '1' and '.mp4' in item['url'] and item['height'] == prefQUALITY:
						STREAM = 'MP4'
						MIME = str(item['mimeType'])
						finalURL = item['url'].replace('/hls', '').replace('/index.m3u8', '')
						QUALITY = str(item['height'])
						debug_MS("(navigator.playCODE[3]) selected_Video ### HEIGHT = "+QUALITY+" || finalURL = "+finalURL+" || mimeTYPE = "+MIME+" || streamTYPE = "+STREAM+" ###")
			if not finalURL:
				for item in MEDIAS:
					if item['mimeType'].lower() == 'mp4' and '.mp4' in item['url']:
						STREAM = 'MP4'
						MIME = str(item['mimeType'])
						finalURL = item['url'].replace('/hls', '').replace('/index.m3u8', '')
						QUALITY = str(item['height'])
						log("(navigator.playCODE) !!!!! KEINEN passenden Stream gefunden --- nehme jetzt den Reserve-Stream-MP4 !!!!!")
						debug_MS("(navigator.playCODE[3]) selected_Video ### HEIGHT = "+QUALITY+" || finalURL = "+finalURL+" || mimeTYPE = "+MIME+" || streamTYPE = "+STREAM+" ###")
						break
	if finalURL and STREAM:
		log("(navigator.playCODE) [{0}p] {1}_stream : {2} ".format(QUALITY, STREAM, finalURL))
		listitem = xbmcgui.ListItem(path=finalURL)
		if ADDON_operate('inputstream.adaptive') and STREAM == 'HLS':
			listitem.setMimeType('application/x-mpegURL')
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else: 
		failing("(playCODE) ##### Die angeforderte Video-Url wurde leider NICHT gefunden !!! #####")
		return dialog.notification(translation(30521).format('PLAY'), translation(30526), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, folder=True, background=False):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and (not artpic in image or background is True):
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
