﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
import io
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import quote, quote_plus, urlencode  # Python 2.X
else: 
	from urllib.parse import quote, quote_plus, urlencode  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)


def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listProductions', 'url': 'sendungen'})
	addDir(translation(30602), icon, {'mode': 'listVideos', 'url': 'videos'})
	addDir(translation(30603), icon, {'mode': 'listVideos', 'url': 'adieu-heimat'})
	addDir(translation(30604), icon, {'mode': 'listVideos', 'url': 'bauer-ledig-sucht'})
	addDir(translation(30605), icon, {'mode': 'listVideos', 'url': 'bumann-der-restauranttester'})
	addDir(translation(30608), artpic+'basesearch.png', {'mode': 'listVideos', 'url': 'searching'})
	addDir(translation(30609).format(str(cachePERIOD)), artpic+'remove.png', {'mode': 'clearCache'})
	if enableADJUSTMENT:
		addDir(translation(30610), artpic+'settings.png', {'mode': 'aSettings'})
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30611), artpic+'settings.png', {'mode': 'iSettings'})
		else:
			addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listProductions(idd):  # https://www.3plus.tv/api/pub/gql/tv3plus/NewsArticleTeaser/2d5925defbf8ae31f3604f3dd6a5e44783a46a11?variables=%7B%22contextId%22%3A%22NewsArticle%3A136264072%22%7D
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listProductions) ------------------------------------------------ START = listProductions -----------------------------------------------")
	debug_MS("(navigator.listProductions) ### IDD : {0} ###".format(str(idd)))
	url = API_URL+'Page/296171194de3453b2934d396f36a7309f255bbf5?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2F{0}%22%2C%22ressort%22%3A%22{0}%22%7D'.format(idd)
	debug_MS("(navigator.listProductions) ### URL : {0} ###".format(str(url)))
	UN_Supported = ['dokumentationen', 'filme', 'serien'] # these lists are empty or not compatible
	content = makeREQUEST(url)
	COMBI_FIRST = []
	Isolated = set()
	response = json.loads(content)['data']['page']['layout']['content']['content'][0]['content'][0]['content']
	for item in response:
		title = '00'
		if 'type' in item and item['type'] == 'FramedContent':
			title = cleaning(item['header']['title'])
		contextType = '00'
		if 'content' in item and 'contextType' in item['content'] and item['content']['contextType'] != "" and item['content']['contextType'] != None:
			contextType =  item['content']['contextType']
		contextId = '00'
		if 'content' in item and 'contextId' in item['content'] and item['content']['contextId'] != "" and item['content']['contextId'] != None:
			contextId = item['content']['contextId']
		group = '00'
		if 'content' in item and 'group' in item['content'] and item['content']['group'] != "" and item['content']['group'] != None:
			group =  item['content']['group']
		if contextId in Isolated or contextId == '00' or any(x in group for x in UN_Supported):
			continue
		Isolated.add(contextId)
		debug_MS("(navigator.listProductions) no.01 ### TITLE = {0} || contextId = {1} || Group = {2} ###".format(title, str(contextId), group))
		COMBI_FIRST.append([title, contextId, group, contextType])
	if COMBI_FIRST:
		for title, contextId, group, contextType in COMBI_FIRST:
			link = API_URL+'NewsArticleTeaser/2d5925defbf8ae31f3604f3dd6a5e44783a46a11?variables=%7B%22contextId%22%3A%22{0}%22%2C%22displayDateSources%22%3A%5B%22transmission.upcoming%22%2C%22transmission.initial%22%2C%22dc.effective%22%5D%7D'.format(quote(contextId))
			result = makeREQUEST(link)
			debug_MS("(navigator.listProductions) no.02 ### LINK : {0} ###".format(str(link)))
			short = json.loads(result)['data']['context']
			title = cleaning(short['title'])
			plot = ""
			if 'lead' in short and short['lead'] != "" and short['lead'] != None:
				plot = cleaning(short['lead'])
			# grösste Auflösung = https://static.az-cdn.ch/__ip/9w9PsDp2QzKB3vvT_4ZFEPzztfQ/8a0585a3041972617a5abe010d3c6407a2901bbd/n-ch12_2x-16x9-far
			try: image = short['teaserImage']['image']['url']+'n-ch12_2x-16x9-far'
			except: image = ""
			PRO_link = '00'
			if 'headRessort' in short and 'urls' in short['headRessort'] and 'relative' in short['headRessort']['urls'] and short['headRessort']['urls']['relative'] != "" and short['headRessort']['urls']['relative'] != None:
				PRO_link = cleaning(short['headRessort']['urls']['relative'])[1:].replace('/', '-')
			debug_MS("(navigator.listProductions) no.02 ### TITLE = {0} || FOTO = {1} || PRO_link = {2} ###".format(title, str(image), str(PRO_link)))
			if PRO_link != '00':
				addDir(title, image, {'mode': 'listVideos', 'url': PRO_link})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def Search3plus():
	debug_MS("(navigator.Search3plus) ------------------------------------------------ START = Search3plus -----------------------------------------------")
	word = None
	word = dialog.input("Search 3plus ...", type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
	word = quote_plus(word, safe='')
	return word

def listVideos(idd, extras, limit):  # https://www.3plus.tv/api/pub/gql/tv3plus/NewsArticleTeaser/2d5925defbf8ae31f3604f3dd6a5e44783a46a11?variables=%7B%22contextId%22%3A%22NewsArticle%3A136264072%22%7D
	debug_MS("(navigator.listVideos) ------------------------------------------------ START = listVideos -----------------------------------------------")
	debug_MS("(navigator.listVideos) ### IDD : {0} ### EXTRAS : {1} ### LIMIT : {2}".format(idd, str(extras), str(limit)))
	UN_Supported = ['dokumentationen', 'filme', 'serien', 'Eigenproduktionen'] # these lists are empty or not compatible
	COMBI_FIRST = []
	COMBI_SEASON = []
	COMBI_EPISODE = []
	COMBI_A1 = []
	COMBI_B2 = []
	sea_LIST = []
	uno_LIST = []
	Isolated = set()
	pos_SE = 0
	pos_EP = 0
	pos_OT = 0
	FOUND = 1
	newIDD = idd
	limit = int(limit)
	if newIDD == 'searching':
		search_term = Search3plus()
		debug_MS("(navigator.Searching) no.01 ### search_term : {0} ###".format(search_term))
		# SEARCH = https://www.3plus.tv/api/pub/gql/tv3plus/Search/8edd5397e0fd160310524073f04d8200325310ed?variables=%7B%22fulltext%22%3A%22bauer%20sucht%22%2C%22assetType%22%3Anull%2C%22functionScore%22%3A%22%22%2C%22offset%22%3A0%7D
		url = API_URL+'Search/8edd5397e0fd160310524073f04d8200325310ed?variables=%7B%22fulltext%22%3A%22{0}%22%2C%22assetType%22%3Anull%2C%22functionScore%22%3A%22%22%2C%22offset%22%3A0%7D'.format(search_term)
		content = makeREQUEST(url)
		response = json.loads(content)['data']['search']['fulltext']['newsarticles']
		if 'total' in response and response['total'] is 0 or 'data' in response and response['data'] is None:
			mainMenu()
			return dialog.notification(translation(30522).format('Ergebnisse'), translation(30524), icon, 8000)
		else:
			for item in response['data']:
				title = '00'
				contextType = '00'
				if 'baseType' in item and item['baseType'] == 'NewsArticle':
					contextType = item['baseType']
				contextId = '00'
				if 'id' in item and item['id'] != "" and item['id'] != None:
					contextId = item['id']
				if contextId in Isolated or contextId == '00':
					continue
				Isolated.add(contextId)
				debug_MS("(navigator.Searching) no.01 ### baseType = {0} || contextId = {1} ###".format(contextType, str(contextId)))
				COMBI_FIRST.append([title, contextId, contextType])
	else:
		articleID = str(newIDD.split('-')[-1])
		debug_MS("(navigator.listVideos) no.02 ### len-articleID : {0} ###".format(str(len(articleID))))
		if extras != 'standard' and articleID.isdigit() and len(articleID) > 5:
			url = API_URL+'Page/e874cd1bbac71cc2aa50895404ee2e9c91985f4a?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2F{0}%22%2C%22articleId%22%3A%22{1}%22%2C%22ressort%22%3A%22{2}%22%7D'.format(newIDD, articleID, extras)
			content = makeREQUEST(url)
			debug_MS("(navigator.listVideos) no.02 ### URL : {0} ###".format(str(url)))
			response = json.loads(content)['data']['page']['context']['blockRecommendations'][0]['recommendationData']
			for item in response:
				title = '00'
				contextType = '00'
				if 'baseType' in item and item['baseType'] != "" and item['baseType'] != None:
					contextType = item['baseType']
				contextId = '00'
				if 'id' in item and item['id'] != "" and item['id'] != None:
					contextId = item['id']
				typeName = '00'
				if '__typename' in item and item['__typename'] != "" and item['__typename'] != None:
					typeName =  item['__typename']
				if contextId in Isolated or contextId == '00' or typeName != 'Reference':
					continue
				Isolated.add(contextId)
				debug_MS("(navigator.listVideos) no.02 ### baseType = {0} || contextId = {1} ###".format(contextType, str(contextId)))
				COMBI_FIRST.append([title, contextId, contextType])
		else:
			if extras != 'standard' and ('notruf-retter' in newIDD or 'sucht-staffel-16' in newIDD):
				url = API_URL+'Page/296171194de3453b2934d396f36a7309f255bbf5?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2F{0}%22%2C%22ressort%22%3A%22{1}%22%7D'.format(newIDD, extras)
			else:
				url = API_URL+'Page/296171194de3453b2934d396f36a7309f255bbf5?variables=%7B%22prefix%22%3A%22pwa%22%2C%22ogUrlForCurrentSkin%22%3Atrue%2C%22path%22%3A%22%2F{0}%22%2C%22ressort%22%3A%22{0}%22%7D'.format(newIDD)
			content = makeREQUEST(url)
			debug_MS("(navigator.listVideos) no.03 ### URL : {0} ###".format(str(url)))
			response = json.loads(content)['data']['page']['layout']['content']['content'][0]['content'][0]['content']
			for item in response:
				title = '00'
				if 'type' in item and item['type'] == 'FramedContent':
					title = cleaning(item['header']['title'])
				contextType = '00'
				if 'content' in item and 'contextType' in item['content'] and item['content']['contextType'] != "" and item['content']['contextType'] != None:
					contextType =  item['content']['contextType']
				contextId = '00'
				if 'content' in item and 'contextId' in item['content'] and item['content']['contextId'] != "" and item['content']['contextId'] != None:
					contextId = item['content']['contextId']
				group = '00'
				if 'content' in item and 'group' in item['content'] and item['content']['group'] != "" and item['content']['group'] != None:
					group =  item['content']['group']
				if contextId in Isolated or contextId == '00' or group == '00' or any(x in group for x in UN_Supported) or any(x in title for x in UN_Supported):
					continue
				Isolated.add(contextId)
				debug_MS("(navigator.listVideos) no.03 ### TITLE = {0} || contextId = {1} || Group = {2} ###".format(title, str(contextId), group))
				COMBI_FIRST.append([title, contextId, contextType])
	if COMBI_FIRST:
		for title, contextId, contextType in COMBI_FIRST:
			link = API_URL+'NewsArticleTeaser/2d5925defbf8ae31f3604f3dd6a5e44783a46a11?variables=%7B%22contextId%22%3A%22{0}%22%2C%22displayDateSources%22%3A%5B%22transmission.initial%22%2C%22dc.effective%22%5D%7D'.format(quote(contextId))
			result = makeREQUEST(link)
			debug_MS("(navigator.listVideos) no.04 ### LINK : {0} ###".format(str(link)))
			short = json.loads(result)['data']['context']
			name = ""
			if 'title' in short and short['title'] != "0" and short['title'] != None:
				name = cleaning(short['title'])
			if name == "" and 'mainAsset' in short and 'title' in short['mainAsset'] and short['mainAsset']['title'] != "" and short['mainAsset']['title'] != None:
				name = cleaning(short['mainAsset']['title'])
			origSERIE = ""
			origSERIE = extractSHOW(name)
			Note_1 =""
			Note_2 =""
			Note_3 =""
			season = '0'
			episode = '0'
			if 'Staffel ' in name or ' ST' in name or 'BLS' in name:
				try: 
					season = re.findall('(?:Staffel |ST |ST|BLS |BLS)([0-9]+)', name, re.S)[0].strip()#.zfill(2)
					pos_SE += 1
				except: pass
			if 'Folge ' in name or 'Episode ' in name and not 'portrait' in name.lower():
				try:
					episode = re.findall('(?:Folge |Episode )([0-9]+)', name, re.S)[0].strip().zfill(2)
					pos_EP += 1
				except: pass
			else: pos_OT += 1
			if origSERIE != "": Note_1 = translation(30620).format(str(origSERIE))
			startTIMES = None
			try:
				startDates = datetime(*(time.strptime(short['displayDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2020-01-22T10:33:11+01:00
				LOCALstart = utc_to_local(startDates)
				startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			except: pass
			if startTIMES: Note_2 = translation(30621).format(str(startTIMES))
			if 'lead' in short and short['lead'] != "" and short['lead'] != None:
				Note_3 = cleaning(short['lead'])
			plot = Note_1+Note_2+Note_3
			try: duration = short['mainAsset']['video']['kaltura']['meta']['duration']
			except: duration = '0'
			try: kalturaId = str(short['mainAsset']['video']['kaltura']['kalturaId'])
			except: kalturaId = None
			# grösste Auflösung = https://static.az-cdn.ch/__ip/9w9PsDp2QzKB3vvT_4ZFEPzztfQ/8a0585a3041972617a5abe010d3c6407a2901bbd/n-ch12_2x-16x9-far
			try: image = short['teaserImage']['image']['url']+'n-ch12_2x-16x9-far'
			except: image = ""
			SE_sign = '00'
			if 'contextLabel' in short and short['contextLabel'] != "" and short['contextLabel'] != None:
				SE_sign = cleaning(short['contextLabel'])
				debug_MS("(navigator.listVideos) ### SE_num : {0} ###".format(str(SE_sign)))
			if SE_sign == '00' and 'labelType' in short and short['labelType'] != "" and short['labelType'] != None:
				SE_sign = cleaning(short['labelType'])
			SE_link = ""
			if 'headRessort' in short and 'urls' in short['headRessort'] and 'relative' in short['headRessort']['urls'] and short['headRessort']['urls']['relative'] != "" and short['headRessort']['urls']['relative'] != None:
				SE_link = cleaning(short['headRessort']['urls']['relative'])[1:].replace('/', '%2F')
			if SE_link == "" and 'urls' in short and 'relative' in short['urls'] and short['urls']['relative'] != "" and short['urls']['relative'] != None:
				SE_link = cleaning(short['urls']['relative'])[1:].replace('/', '%2F')
			debug_MS("(navigator.listVideos) no.04 ### TITLE = {0} || SEASON = {1} || EPISODE = {2} || startTIMES = {3} ###".format(name, str(season), str(episode), str(startTIMES)))
			debug_MS("(navigator.listVideos) no.04 ### SERIE = {0} || kalturaId = {1} || FOTO = {2} || DURATION = {3} ###".format(origSERIE, kalturaId, str(image), str(duration)))
			if limit == 1 and season != '0' and newIDD in SE_link and 'staffel-'+str(season) in SE_link and ('playlist' in SE_sign.lower() or 'staffel' in SE_sign.lower() or any(x in SE_link for x in ['bauer-', 'bumann', 'notruf-retter'])) and not any(x in SE_link for x in ['episode-', 'aufruf', 'folge-']):
				COMBI_SEASON.append([season, SE_link, image, plot, newIDD, pos_SE])
			else:
				if kalturaId and kalturaId in Isolated:
					pos_EP -= 1
					continue
				Isolated.add(kalturaId)
				if not 'portrait' in name.lower() and kalturaId:
					COMBI_A1.append([episode, kalturaId, image, name, plot, duration, origSERIE, season, pos_EP, pos_OT])
				elif 'portrait' in name.lower() and kalturaId:
					COMBI_B2.append([episode, kalturaId, image, name, plot, duration, origSERIE, season, pos_EP, pos_OT])
	else:
		return dialog.notification(translation(30522).format('Einträge'), translation(30525).format(unquote_plus(newIDD)), icon, 10000)
	if COMBI_SEASON:
		for season, SE_link, image, plot, newIDD, pos_SE in COMBI_SEASON:
			try:
				NUMBER = season
				sea_LIST.append(NUMBER)
				newSE = int(max(sea_LIST))+1
				if 'bauer-' in newIDD or 'notruf-retter' in newIDD:
					NEW_link = SE_link.split('-staffel-')[0].split('%2Fstaffel-')[0].split('%2Fbauer')[0]+'-staffel-'+str(newSE)
				elif 'bumann' in newIDD and 'staffel-'+str(newSE) in SE_link:
					NEW_link = SE_link
				if FOUND == 1:
					FOUND += 1
					addDir('Staffel '+str(newSE), image, {'mode': 'listVideos', 'url': NEW_link, 'extras': newIDD, 'limit': '2'})
			except: pass
			if season not in uno_LIST:
				addDir('Staffel '+str(season), image, {'mode': 'listVideos', 'url': SE_link, 'extras': newIDD, 'limit': '2'})
				debug_MS("(navigator.listVideos) no.05 ### {0} ### serLINK : {1} ###".format('Staffel '+str(season), str(SE_link)))
				uno_LIST.append(season)
	elif (COMBI_A1 or COMBI_B2) and not COMBI_SEASON:
		if pos_EP >= len(COMBI_A1)-3:
			COMBI_A1 = sorted(COMBI_A1, key=lambda no:no[0], reverse=True)
		COMBI_EPISODE = COMBI_A1 + COMBI_B2
		for episode, kalturaId, image, name, plot, duration, origSERIE, season, pos_EP, pos_OT in COMBI_EPISODE:
			EP_entry = kalturaId+'@@'+str(origSERIE)+'@@'+str(name)+'@@'+str(image)+'@@'+str(duration)+'@@'+str(season)+'@@'+str(episode)+'@@'
			if EP_entry not in uno_LIST:
				uno_LIST.append(EP_entry)
			listitem = xbmcgui.ListItem(name, path=HOST_AND_PATH+'?IDENTiTY='+kalturaId+'&mode=playCODE')
			info = {}
			if season != '0':
				info['Season'] = season
			info['Episode'] = episode
			info['Tvshowtitle'] = origSERIE
			info['Title'] = name
			info['Tagline'] = None
			info['Plot'] = plot
			info['Duration'] = duration
			info['Year'] = None
			info['Genre'] = 'Eigenproduktion'
			info['Director'] = None
			info['Writer'] = None
			info['Studio'] = '3plus.tv'
			info['Mpaa'] = None
			info['Mediatype'] = 'episode'
			listitem.setInfo(type='Video', infoLabels=info)
			listitem.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
			if useThumbAsFanart and image != icon and not artpic in image:
				listitem.setArt({'fanart': image})
			listitem.addStreamInfo('Video', {'Duration':duration})
			listitem.setProperty('IsPlayable', 'true')
			listitem.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+kalturaId+'&mode=playCODE', listitem=listitem)
		with io.open(WORKFILE, 'w', encoding='utf-8') as input:
			input.write(py2_uni('\n'.join(uno_LIST)))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) ------------------------------------------------ START = playCODE -----------------------------------------------")
	debug_MS("(navigator.playCODE) ### IDD : {0} ###".format(str(IDD)))
	# try .mpd = https://cdnapisec.kaltura.com/p/1719221/sp/1719221/playManifest/entryId/1_p6l6ymw0/flavorIds/0_wi9evyfh,0_om5ckrkd,0_vnrmio95,0_68g0date/deliveryProfileId/10182/protocol/https/format/mpegdash/manifest.mpd
	# all of .m3u8 = https://cdnapisec.kaltura.com/p/1719221/sp/171922100/playManifest/entryId/1_p1giw45o/format/applehttp/protocol/https/a.m3u8?responseFormat=json
	# .m3u8 = https://cfvod.kaltura.com/hls/p/1719221/sp/171922100/serveFlavor/entryId/1_6hrjp75i/v/1/ev/7/flavorId/1_fbhvz56l/name/a.mp4/index.m3u8
	# .mp4 = https://cfvod.kaltura.com/p/1719221/sp/171922100/serveFlavor/entryId/1_6hrjp75i/v/1/ev/7/flavorId/1_fbhvz56l/name/a.mp4
	MEDIAS = []
	finalURL = False
	streamTYPE = False
	with io.open(WORKFILE, 'r', encoding='utf-8') as output:
		lines = output.readlines()
		for line in lines:
			field = line.split('@@')
			if field[0]==IDD:
				entryId = field[0]
				origSERIE = field[1]
				name = field[2]
				image = field[3]
				duration = field[4] 
				season = field[5]
				episode = field[6]
	if IDD != '00' and entryId != '00':
		firstUrl = 'https://cdnapisec.kaltura.com/p/{0}/sp/{0}00/playManifest/entryId/{1}/format/applehttp/protocol/https/a.m3u8?responseFormat=json'.format(PartnerId, entryId)
		ref = 'https://license.theoplayer.com/'
		content = getUrl(firstUrl, referer=ref)
		debug_MS("(navigator.playCODE) ### firstUrl : {0} ###".format(str(firstUrl)))
		result = json.loads(content)
		for elem in result['flavors']:
			vid = elem['url']
			ext = elem['ext']
			height = elem['height']
			if (ext == 'vnd.apple.mpegURL' or ext == 'x-mpegurl' or ext== 'mp4'):
				MEDIAS.append({'url': vid, 'mimeType': ext, 'height': height})
				MEDIAS = sorted(MEDIAS, key=lambda b:b['height'], reverse=True)
				debug_MS("(navigator.playCODE) listing_1_MEDIAS ### HEIGHT = "+str(height)+" || URL = "+vid+" || mimeTYPE = "+ext+" ###")
		if MEDIAS:
			for item in MEDIAS:
				if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and '/hls' and '.m3u8' in item['url']:
					finalURL = item['url']
					streamTYPE = 'HLS'
				elif not enableINPUTSTREAM and prefSTREAM == "0" and '.m3u8' in item['url'] and item['height'] == prefQUALITY:
					finalURL = item['url']
					streamTYPE = 'M3U8'
					debug_MS("(navigator.playCODE) listing_2_Standard ### HEIGHT = "+str(item['height'])+" || finalURL = "+finalURL+" || mimeTYPE = "+str(item['mimeType'])+" || streamTYPE = "+streamTYPE+" ###")
				elif not enableINPUTSTREAM and prefSTREAM == "1" and '.mp4' in item['url'] and item['height'] == prefQUALITY:
					finalURL = item['url'].replace('/hls', '').replace('/index.m3u8', '')
					streamTYPE = 'MP4'
					debug_MS("(navigator.playCODE) listing_2_Standard ### HEIGHT = "+str(item['height'])+" || finalURL = "+finalURL+" || mimeTYPE = "+str(item['mimeType'])+" || streamTYPE = "+streamTYPE+" ###")
		if not finalURL and MEDIAS:
			for item in MEDIAS:
				if item['mimeType'].lower() == 'mp4':
					finalURL = MEDIAS[0]['url'].replace('/hls', '').replace('/index.m3u8', '')
					streamTYPE = 'MP4'
			log("(navigator.playCODE) !!!!! KEINEN passenden Stream gefunden --- nehme jetzt den Reserve-Stream-MP4 !!!!!")
			debug_MS("(navigator.playCODE) listing_2_Standard ### HEIGHT = "+str(MEDIAS[0]['height'])+" || finalURL = "+finalURL+" || mimeTYPE = "+str(MEDIAS[0]['mimeType'])+" || streamTYPE = "+streamTYPE+" ###")
	if finalURL and streamTYPE:
		if streamTYPE == 'M3U8':
			log("(navigator.playCODE) M3U8_stream : {0}".format(finalURL))
		if streamTYPE == 'MP4':
			log("(navigator.playCODE) MP4_stream : {0}".format(finalURL))
		listitem = xbmcgui.ListItem(path=finalURL)
		if streamTYPE == 'HLS':
			debug_MS("(navigator.playCODE) listing_2_Standard ### HEIGHT = "+str(MEDIAS[0]['height'])+" || finalURL = "+finalURL+" || mimeTYPE = "+str(MEDIAS[0]['mimeType'])+" || streamTYPE = "+streamTYPE+" ###")
			log("(navigator.playCODE) HLS_stream : {0}".format(finalURL))
			listitem.setMimeType('application/x-mpegURL')
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else: 
		failing("(playCODE) ##### Die angeforderte Video-Url wurde leider NICHT gefunden !!! #####")
		return dialog.notification(translation(30521).format('PLAY'), translation(30526), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)
