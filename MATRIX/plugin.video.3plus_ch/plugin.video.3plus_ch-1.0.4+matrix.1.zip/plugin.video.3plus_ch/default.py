﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2020 realvito

    3plus TV

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmcaddon
from resources.lib.common import *
from resources.lib import navigator


def run():
	if mode == 'root':
		navigator.mainMenu()
	elif mode == 'listProductions':
		navigator.listProductions(url)
	elif mode == 'listVideos':
		navigator.listVideos(url, extras, limit)
	elif mode == 'playCODE':
		navigator.playCODE(IDENTiTY)
	elif mode == 'AddToQueue':
		navigator.AddToQueue()
	elif mode == 'clearCache':
		navigator.clearCache()
	elif mode == 'aSettings':
		navigator.addon.openSettings()
	elif mode == 'iSettings':
		navigator.xbmcaddon.Addon('inputstream.adaptive').openSettings()

run()
