﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2020 realvito

    Massengeschmack (light)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from __future__ import unicode_literals
from resources.lib.common import *
from resources.lib import navigator


def run():
	if mode == 'root':
		navigator.mainMenu()
	elif mode == 'listShows':
		navigator.listShows(url)
	elif mode == 'listEpisodes':
		navigator.listEpisodes(url, origSERIE)
	elif mode == 'YOUT_channel':
		navigator.YOUT_channel(url)
	elif mode == 'MULTI_download':
		navigator.MULTI_download(name, url)
	elif mode == 'listStored':
		navigator.listStored()
	elif mode == 'playVideo':
		navigator.playVideo(url, extras)
	elif mode == 'GotoTrash':
		navigator.GotoTrash(url)
	elif mode == 'aSettings':
		navigator.addon.openSettings()

run()
