﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
from datetime import datetime, timedelta
from urllib.parse import urlencode

from .common import *
from .external.scrapetube import *


def mainMenu():
	html = getUrl(BASE_URL+'/mag/1', method='LOAD', REF=BASE_URL)
	content = html[html.find('<li id="mag-button" class="nav-item">')+1:]
	content = content[:content.find('<li class="nav-item"><a href="https://forum.massengeschmack.tv/" class="nav-link">Forum</a>')]
	selection = re.findall(r'<a href="([^"]+?)">([^<]+?)</a></div>', content, re.S)
	for END_URL, name in selection:
		name = cleaning(name)
		debug_MS("(navigator.mainMenu) ### newURL : {} || NAME : {} ###".format(BASE_URL+END_URL, name))
		if not any(x in name.lower() for x in ['massengeschnack', 'premium', 'live']):
			addDir(name, icon, {'mode': 'listEpisodes', 'url': BASE_URL+END_URL, 'origSERIE': name})
	if enableYOUTUBE:
		addDir(translation(30611), icon, {'mode': 'listPlaylists'})
	if enableADJUSTMENT:
		addDir(translation(30612), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, origSERIE):
	debug_MS("(navigator.listEpisodes) -------------------------------------------------- START = listEpisodes --------------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### URL : {} ### origSERIE : {} ###".format(url, origSERIE))
	COMBI = []
	xbmc.sleep(1000) # 1 sek. um Sperrung für nächsten Zugriff vorzubeugen
	content = getUrl(url, method='LOAD', REF=url)
	PID = re.compile(r'MAG_PID = ([0-9]+?);', re.S).findall(content)[0]
	try: SID = re.compile(r'MAG_SPID = ([0-9,]+?);', re.S).findall(content)[0]
	except: SID = ""
	offset = 0
	count = 500
	# https://massengeschmack.tv/api/v2/feed/filter?offset=6&count=18&filter=%7B%22mag%22%3A%7B%2223%22%3A%5B%5D%7D%7D&include=null
	newURL = '{0}/api/v2/feed/filter?offset={1}&count={2}&filter=%7B%22mag%22%3A%7B%22{3}%22%3A%5B{4}%5D%7D%7D&include=null'.format(BASE_URL, str(offset), str(count), str(PID), str(SID))
	xbmc.sleep(2000) # 2 sek. um Sperrung für nächsten Zugriff vorzubeugen
	DATA = getUrl(newURL, REF=url)
	if DATA is not None and DATA.get('clips', '') and len(DATA['clips']) > 1:
		for item in DATA['clips']:
			debug_MS("(navigator.listEpisodes[1]) no.01 ### ITEM-01 : {} ###".format(str(item)))
			episode, duration = ('0' for _ in range(2))
			STARTED = '[CR]'
			video = (item.get('teaserFile', None) or None)
			if video is None and item.get('hasDownload', '') is True:
				video = BASE_URL+'/play/'+item.get('id', '')
			if video is None: continue
			title = cleaning(item['title'])
			if item.get('seqNr', ''):
				episode = str(item['seqNr']).zfill(4)
			photo = (item.get('image', '') or icon)
			if str(item.get('time', '')).isdigit():
				try: STARTED = '[COLOR chartreuse]'+datetime.fromtimestamp(item['time']).strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')+'[/COLOR][CR][CR]'
				except: pass
			plot = origSERIE+'[CR]'+STARTED+get_Description(item)
			duration = (get_Seconds(item.get('duration', '0')) or '0')
			COMBI.append([episode, video, photo, title, plot, duration, origSERIE])
			if episode != '0': COMBI = sorted(COMBI, key=lambda num:num[0], reverse=True)
	if COMBI:
		for episode, video, photo, title, plot, duration, origSERIE in COMBI:
			addLink(title, photo, {'mode': 'playVideo', 'url': video, 'origSERIE': origSERIE, 'extras': 'DIRECTstream', 'cineType': 'episode'}, plot, episode=episode)
	else:
		return dialog.notification(translation(30524), translation(30525).format(origSERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPlaylists():
	debug_MS("(navigator.listPlaylists) ------------------------------------------------ START = listPlaylists -----------------------------------------------")
	addDir(translation(30621), icon, {'url': BASE_YT.format(CHANNEL_CODE, 'UUj089h5WsDdh1q8t54K3ZCw'), 'extras': 'YT_FOLDER'}, tag='Neu: Massengeschmack TV')
	playlists = get_videos('https://www.youtube.com/{}/playlists'.format(CHANNEL_NAME), 'https://www.youtube.com/youtubei/v1/browse', 'gridPlaylistRenderer', None, 1) # mit "get_videos" die Playlisten eines Channels abrufen
	for item in playlists:
		debug_MS("(navigator.listPlaylists) XXXXX ENTRY : {} XXXXX".format(str(item)))
		title = cleaning(item['title']['runs'][0]['text'])
		PID = item['playlistId']
		photo = item['thumbnail']['thumbnails'][0]['url'].split('?sqp=')[0].replace('hqdefault', 'maxresdefault')
		if title.lower().startswith(('asynchron', 'hoaxilla', 'livetalk', 'live talk', 'live-talk', 'advent', 'post', 'favorit')):
			photo = item['thumbnail']['thumbnails'][0]['url'].split('?sqp=')[0]
		numbers = str(item['videoCountText']['runs'][0]['text']) if item.get('videoCountText', '') and item['videoCountText'].get('runs', '') and item['videoCountText']['runs'][0].get('text', '') else None
		name = translation(30622).format(title, numbers) if numbers is not None else translation(30623).format(title)
		addDir(name, photo, {'url': BASE_YT.format(CHANNEL_CODE, PID), 'extras': 'YT_FOLDER'}, tag='Playlist: Offizieller YouTube Kanal von Massengeschmack TV')
	xbmcplugin.endOfDirectory(ADDON_HANDLE, updateListing=True, cacheToDisc=False)

def playVideo(url, TYPE):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL : {} ### TYPE : {} ###".format(url, TYPE))
	if TYPE == 'DIRECTstream' and '/play/' in url:
		content = getUrl(url, method='LOAD')
		debug_MS("++++++++++++++++++++++++")
		debug_MS("(navigator.playVideo) XXXXX CONTENT : {} XXXXX".format(str(content)))
		debug_MS("++++++++++++++++++++++++")
		FIRST = re.findall('src: "(//massengeschmack.+?)" }', content, re.S)
		SECOND = re.findall('type: "video/mp4", src: "([^"]+)"', content, re.S)
		FINAL_URL = 'https:'+FIRST[0] if FIRST else SECOND[0] if SECOND else False
	else:
		FINAL_URL = url
	if FINAL_URL:
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log("(navigator.playVideo) StreamUrl : {0}".format(FINAL_URL))
	else:
		return dialog.notification(translation(30521).format('PLAY'), translation(30526), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, tag='...', folder=True):
	if params.get('extras') == 'YT_FOLDER': u = params.get('url')
	else: u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTvShowTitle(params.get('origSERIE')), videoInfoTag.setTitle(name), videoInfoTag.setTagLine(tag), videoInfoTag.setStudios(['massengeschmack.tv'])
	else:
		liz.setInfo(type='Video', infoLabels={'Tvshowtitle': params.get('origSERIE'), 'Title': name, 'Tagline': tag, 'Studio': 'massengeschmack.tv'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None, episode=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		if episode not in ['0', 'None', None]: videoInfoTag.setEpisode(int(episode))
		videoInfoTag.setTvShowTitle(params.get('origSERIE'))
		videoInfoTag.setTitle(name)
		videoInfoTag.setPlot(plot)
		if duration not in ['0', 'None', None]: videoInfoTag.setDuration(int(duration))
		videoInfoTag.setGenres(['Unterhaltung'])
		videoInfoTag.setStudios(['massengeschmack.tv'])
		videoInfoTag.setMediaType(params.get('cineType'))
	else:
		info = {}
		if episode not in ['0', 'None', None]: info['Episode'] = episode
		info['Tvshowtitle'] = params.get('origSERIE')
		info['Title'] = name
		info['Plot'] = plot
		if duration not in ['0', 'None', None]: info['Duration'] = duration
		info['Genre'] = 'Unterhaltung'
		info['Studio'] = 'massengeschmack.tv'
		info['Mediatype'] = params.get('cineType')
		liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, 'mode=AddToQueue'))])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
