﻿# -*- coding: utf-8 -*-

from .common import *


def mainMenu():
	debug_MS("(navigator.mainMenu) ------------------------------------------------ START = mainMenu -----------------------------------------------")
	COMBINATION, content = [], getContent(f"{BASE_URL}/mag/1", REF=f"{BASE_URL}/")
	result = content[content.find('<li id="mag-button" class="nav-item">')+1:]
	result = result[:result.find('<li class="nav-item"><a href="https://forum.massengeschmack.tv/" class="nav-link">Forum</a>')]
	selection = re.findall(r'''<a href=["']([^"']+)["']>([^<]+)</a></div>''', result, re.S)
	for link, title in selection:
		NEW_URL = f"{BASE_URL}{link}"
		title = cleaning(title)
		debug_MS(f"(navigator.mainMenu[1]) ### TITLE : {title} || LINK : {NEW_URL} ###")
		if not any(xs in title.lower() for xs in ['massengeschnack', 'premium', 'live']):
			COMBINATION.append([title, NEW_URL])
	if COMBINATION:
		for title, NEW_URL in sorted(COMBINATION, key=lambda vsx: cleanUmlaut(vsx[0]).lower()):
			addDir({'mode': 'listEpisodes', 'link': NEW_URL, 'extras': title}, create_entries({'Title': f"[B]{title}[/B]"}))
	if enableYOUTUBE:
		addDir({'mode': 'listPlaylists'}, create_entries({'Title': translation(30601)}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30602), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(TARGET, SHOW):
	debug_MS("(navigator.listEpisodes) -------------------------------------------------- START = listEpisodes --------------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### TARGET = {TARGET} ### TVSHOW = {SHOW} ###")
	xbmc.sleep(1000) # 1 sek. um Sperrung für nächsten Zugriff vorzubeugen
	COMBINATION, offset, limit, content = [], 0, 500, getContent(TARGET, REF=TARGET)
	PID = re.compile(r'MAG_PID = ([0-9]+);', re.S).findall(content)[0]
	try: SID = re.compile(r'MAG_SPID = ([0-9,]+);', re.S).findall(content)[0]
	except: SID = ""
	# https://massengeschmack.tv/api/v2/feed/filter?offset=6&count=18&filter=%7B%22mag%22%3A%7B%2223%22%3A%5B%5D%7D%7D&include=null
	NEW_URL = f"{BASE_URL}/api/v2/feed/filter?offset={str(offset)}&count={str(limit)}&filter=%7B%22mag%22%3A%7B%22{str(PID)}%22%3A%5B{str(SID)}%5D%7D%7D&include=null"
	xbmc.sleep(2000) # 2 sek. um Sperrung für nächsten Zugriff vorzubeugen
	DATA_ONE = getContent(NEW_URL, queries='JSON', REF=TARGET)
	if DATA_ONE is not None and DATA_ONE.get('clips', '') and len(DATA_ONE['clips']) > 1:
		for item in DATA_ONE.get('clips', []):
			(startTIMES, aired), (Note_1, Note_2) = (None for _ in range(2)), ("" for _ in range(2))
			debug_MS(f"(navigator.listEpisodes[1]) xxxxx ITEM-01 : {item} xxxxx")
			debug_MS("---------------------------------------------")
			video = (item.get('teaserFile', None) or None)
			if video is None and item.get('hasDownload', False) is True:
				video = f"{BASE_URL}/play/{item.get('id', '')}"
			if video is None: continue
			title, episode, photo = cleaning(item['title']), str(item['seqNr']).zfill(4) if str(item.get('seqNr')).isdecimal() else None, item.get('image', icon)
			if str(item.get('time')).isdecimal():
				startTIMES = datetime.fromtimestamp(item['time']).strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
				aired = datetime.fromtimestamp(item['time']).strftime('%d.%m.%Y') # FirstAired
			if startTIMES: Note_1 = translation(30621).format(startTIMES)
			else: Note_1 = '[CR][CR]'
			Note_2 = get_Description(item)
			COMBINATION.append([title, episode, photo, SHOW, Note_1, Note_2, aired, video])
			if episode: COMBINATION = sorted(COMBINATION, key=lambda vsx: vsx[1], reverse=True)
	if COMBINATION:
		for title, episode, photo, SHOW, Note_1, Note_2, aired, video in COMBINATION:
			FETCH_UNO = {'Title': title, 'TvShowTitle': SHOW, 'Plot': SHOW+Note_1+Note_2, 'Aired': aired, 'Year': aired, \
				'Genre': 'Unterhaltung', 'Studio': 'massengeschmack.tv', 'Mediatype': 'episode', 'Image': photo, 'Reference': 'Single'}
			addDir({'mode': 'playVideo', 'link': video}, create_entries(FETCH_UNO), False)
	else: return dialog.notification(translation(30524), translation(30525).format(SHOW), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPlaylists():
	debug_MS("(navigator.listPlaylists) ------------------------------------------------ START = listPlaylists -----------------------------------------------")
	if PERS_TOKEN == 'AIzaSy.................................':
		return dialog.ok(addon_id, translation(30350))
	elif PERS_TOKEN[:6] != 'AIzaSy':
		return dialog.ok(addon_id, translation(30501))
	addDir({'link': BASE_YOUT.format(CHANNEL_CODE, f'UU{CHANNEL_CODE[2:]}'), 'extras': 'YT_FOLDER'}, create_entries({'Title': translation(30631), 'Plot': 'Neue Uploads: Massengeschmack.TV'}))
	TARGET = f"https://youtube.googleapis.com/youtube/v3/playlists?part=snippet,contentDetails&channelId={CHANNEL_CODE}&maxResults=50&key={PERS_TOKEN}"
	PAGE_NUMBER, NEXT_PAGE = 1, None
	while PAGE_NUMBER > 0:
		content = getContent(TARGET, 'GET', 'JSON', 'https://www.youtube.com/') if PAGE_NUMBER == 1 else getContent(NEXT_PAGE, 'GET', 'JSON', 'https://www.youtube.com/')
		for item in content.get('items', []):
			if item.get('kind', '') == 'youtube#playlist':
				debug_MS(f"(navigator.listPlaylists[1]) xxxxx ENTRY-01 : {item} xxxxx")
				debug_MS("---------------------------------------------")
				title, PYID = cleaning(item['snippet']['title']), item.get('id', None)
				plot = (cleaning(item['snippet'].get('description', '')) or 'Offizieller YouTube Kanal von Massengeschmack.TV')
				photo = (item['snippet']['thumbnails'].get('maxres', {}).get('url', '') or item['snippet']['thumbnails'].get('standard', {}).get('url', '') or item['snippet']['thumbnails'].get('high', {}).get('url', ''))
				numbers = item['contentDetails']['itemCount'] if item.get('contentDetails', '') and str(item['contentDetails'].get('itemCount')).isdecimal() else None
				if isinstance(numbers, int) and int(numbers) == 0: continue
				name = translation(30632).format(title) if numbers is None else translation(30633).format(title, numbers)
				FETCH_UNO = create_entries({'Title': name, 'Plot': f'Playlist: {plot}', 'Image': photo})
				addDir({'link': BASE_YOUT.format(CHANNEL_CODE, PYID), 'extras': 'YT_FOLDER'}, FETCH_UNO)
		if content.get('nextPageToken', None):
			NEXT_PAGE, PAGE_NUMBER = f"{TARGET}&pageToken={content['nextPageToken']}", PAGE_NUMBER.__add__(1)
			debug_MS(f"(navigator.listPlaylists[2]) PAGES ### NOW GET NEXTPAGE : {NEXT_PAGE} ###")
		else: break
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def playVideo(TARGET):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### TARGET = {TARGET} ###")
	if '/play/' in TARGET:
		content = getContent(TARGET, REF=f"{BASE_URL}/")
		debug_MS("++++++++++++++++++++++++")
		debug_MS(f"(navigator.playVideo[1]) XXXXX CONTENT-01 : {content} XXXXX")
		debug_MS("++++++++++++++++++++++++")
		UNO = re.compile(r'''src: ["'](//massengeschmack.+?)["'] }''', re.S).findall(content)
		DUE = re.compile(r'''type: ["']video/mp4["'], src: ["']([^"']+)["']''', re.S).findall(content)
		FINAL_URL = f"https:{UNO[0]}" if UNO else DUE[0] if DUE else False
	else: FINAL_URL = TARGET
	if FINAL_URL:
		log(f"(navigator.playVideo) StreamURL : {FINAL_URL}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL, offscreen=True))
	else: return dialog.notification(translation(30521).format('PLAY'), translation(30526), icon, 10000)

def addDir(params, listitem, folder=True):
	uws = params.get('link') if params.get('extras') == 'YT_FOLDER' else build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
