﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
import threading
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
else: 
	from urllib.parse import urlencode  # Python 3.X

from .common import *


def mainMenu():
	if xbmcvfs.exists(target_DIR): addDir(translation(30601), icon, {'mode': 'listStored'})
	html = getUrl(BASE_URL+'/mag/1', 'GET', BASE_URL)
	content = html[html.find('<li id="mag-button" class="nav-item">')+1:]
	content = content[:content.find('<li class="nav-item"><a href="https://forum.massengeschmack.tv/" class="nav-link">Forum</a>')]
	selection = re.findall(r'<a href="([^"]+?)">([^<]+?)</a></div>', content, re.S)
	for endURL, name in selection:
		endURL = py2_enc(BASE_URL+endURL)
		name = cleaning(name)
		debug_MS("(navigator.mainMenu) ### endURL = {0} ### NAME = {1} ###".format(endURL, str(name)))
		if not any(x in name.lower() for x in ['massengeschnack', 'premium', 'live']):
			addDir(name, icon, {'mode': 'listEpisodes', 'url': endURL, 'origSERIE': name})
	if enableYOUTUBE:
		addDir(translation(30611), icon, {'mode': 'listYTcategories'})
	if enableADJUSTMENT:
		addDir(translation(30612), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, origSERIE):
	debug_MS("(navigator.listEpisodes) -------------------------------------------------- START = listEpisodes --------------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### URL = {0} ### origSERIE = {1} ###".format(url, str(origSERIE)))
	COMBI = []
	content = getUrl(url, 'GET', url)
	PID = re.compile('MAG_PID = ([0-9]+?);', re.DOTALL).findall(content)[0]
	try: SID = re.compile('MAG_SPID = ([0-9,]+?);', re.DOTALL).findall(content)[0]
	except: SID = ""
	FOUND = 0
	offset = 0
	count = 100
	total = 1
	while (total > 0):
		# https://massengeschmack.tv/api/v2/feed/filter?offset=6&count=18&filter=%7B%22mag%22%3A%7B%2223%22%3A%5B%5D%7D%7D
		JS_url = '{0}/api/v2/feed/filter?offset={1}&count={2}&filter=%7B%22mag%22%3A%7B%22{3}%22%3A%5B{4}%5D%7D%7D'.format(BASE_URL, str(offset), str(count), str(PID), str(SID))
		try:
			result = getUrl(JS_url, 'GET', url)
			DATA = json.loads(result)
			if 'clips' in DATA and len(DATA['clips']) < 10:
				total = 0
			for item in DATA['clips']:
				debug_MS("(navigator.listEpisodes) ##### EPISODE : {0} #####".format(str(item)))
				episode, duration = ('0' for _ in range(2))
				STARTED = '[CR]'
				video = (item.get('teaserFile', None) or None)
				if video is None and item.get('hasDownload', '') is True:
					video = BASE_URL+'/play/'+item.get('id', '')
				if video is None: continue
				title = cleaning(item['title'])
				if item.get('seqNr', ''):
					episode = str(item['seqNr']).zfill(4)
				photo = (item.get('image', '') or icon)
				if str(item.get('time', '')).isdigit():
					try: STARTED = '[COLOR chartreuse]'+datetime.fromtimestamp(item['time']).strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')+'[/COLOR][CR][CR]'
					except: pass
				plot = origSERIE+'[CR]'+STARTED+get_Description(item)
				duration = (get_Seconds(item.get('duration', '0')) or '0')
				COMBI.append([episode, video, photo, title, plot, duration, origSERIE])
				if episode != '0': COMBI = sorted(COMBI, key=lambda num:num[0], reverse=True)
		except: total = 0
		offset += 100
		xbmc.sleep(1000)
	if COMBI and total == 0:
		for episode, video, photo, title, plot, duration, origSERIE in COMBI:
			FOUND += 1
			addLink(title, photo, {'mode': 'playVideo', 'url': video, 'origSERIE': origSERIE, 'extras': 'DIRECTstream', 'cineType': 'episode'}, plot, episode=episode)
	if FOUND == 0:
		return dialog.notification(translation(30522), translation(30528).format(origSERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listYTcategories():
	debug_MS("(navigator.listYTcategories) -------------------------------------------------- START = listYTcategories --------------------------------------------------")
	addDir(translation(30621), icon, {'url': BASE_YT+'UUj089h5WsDdh1q8t54K3ZCw/', 'extras': 'YT_FOLDER'})
	addDir(translation(30622), icon, {'url': BASE_YT+'PLqh6lroBRtJ2s-Qchjp4Th4UdjeUnvZEZ/', 'extras': 'YT_FOLDER'})
	addDir(translation(30623), icon, {'url': BASE_YT+'PLqh6lroBRtJ3hsqfybfFBwA9Q34er0cqq/', 'extras': 'YT_FOLDER'})
	addDir(translation(30624), icon, {'url': BASE_YT+'PLqh6lroBRtJ1IMXNJphxxrng9cDc9I52S/', 'extras': 'YT_FOLDER'})
	addDir(translation(30625), icon, {'url': BASE_YT+'PLqh6lroBRtJ1MCHW4qv6jI0tvcJ9KWRaa/', 'extras': 'YT_FOLDER'})
	addDir(translation(30626), icon, {'url': BASE_YT+'PLqh6lroBRtJ0QXyvHlCc2Q-7rB5E0tNjS/', 'extras': 'YT_FOLDER'})
	addDir(translation(30627), icon, {'url': BASE_YT+'PLqh6lroBRtJ1b6at_tZBLWX5mgQZfwH9x/', 'extras': 'YT_FOLDER'})
	addDir(translation(30628), icon, {'url': BASE_YT+'PLqh6lroBRtJ2s7TYjZvf_Pzo0BkRRaRyO/', 'extras': 'YT_FOLDER'})
	addDir(translation(30629), icon, {'url': BASE_YT+'PLqh6lroBRtJ3TGilJSiLloC_sb75Taeq7/', 'extras': 'YT_FOLDER'})
	addDir(translation(30630), icon, {'url': BASE_YT+'PLqh6lroBRtJ0VtaJKNb8RBW0EIC0AAaVz/', 'extras': 'YT_FOLDER'})
	addDir(translation(30631), icon, {'url': BASE_YT+'PLqh6lroBRtJ2zjUQe3He-qkIk6oHL-AVT/', 'extras': 'YT_FOLDER'})
	addDir(translation(30632), icon, {'url': BASE_YT+'PLqh6lroBRtJ37ha_85phsaNuqleodCUK7/', 'extras': 'YT_FOLDER'})
	addDir(translation(30633), icon, {'url': BASE_YT+'PLqh6lroBRtJ3yp06m-JJ2Hgc_mL4n86Hm/', 'extras': 'YT_FOLDER'})
	addDir(translation(30634), icon, {'url': BASE_YT+'PLqh6lroBRtJ0Ew2inhQE7OEPdUirdYsNH/', 'extras': 'YT_FOLDER'})
	addDir(translation(30635), icon, {'url': BASE_YT+'PLqh6lroBRtJ1XWSjrAmVX1hAmWqYY4VCn/', 'extras': 'YT_FOLDER'})
	addDir(translation(30636), icon, {'url': BASE_YT+'PLqh6lroBRtJ2LoCcoJ3lGzLorDVQFo5_t/', 'extras': 'YT_FOLDER'})
	addDir(translation(30637), icon, {'url': BASE_YT+'PLqh6lroBRtJ2kUtgvYWQoJwKcgWqIT49-/', 'extras': 'YT_FOLDER'})
	addDir(translation(30638), icon, {'url': BASE_YT+'PLqh6lroBRtJ1zvG4KPm0edK78s8aLsDRh/', 'extras': 'YT_FOLDER'})
	addDir(translation(30639), icon, {'url': BASE_YT+'PLqh6lroBRtJ22STc80jUwywSwhLiqY7po/', 'extras': 'YT_FOLDER'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def MULTI_download(url, name):
	threads = []
	th = threading.Thread(target=getDownload, args=(url, name))
	th.daemon = True
	threads.append(th)
	[th.start() for th in threads]

def getDownload(BroadCast_Url, BroadCast_Name):
	debug_MS("(navigator.getDownload) -------------------------------------------------- START = getDownload --------------------------------------------------")
	debug_MS("(navigator.getDownload) ### URL = {0} ### NAME = {1} ###".format(BroadCast_Url, BroadCast_Name))
	now = str(time.strftime ('%d-%m-%Y'))
	if target_DIR is None or target_DIR == "":
		dialog.notification(translation(30521).format('DOWNLOAD'), translation(30523), icon, 8000)
		return addon.openSettings(HOST_AND_PATH)
	if not xbmcvfs.exists(target_DIR):
		xbmcvfs.mkdirs(target_DIR)
	dialog.notification(translation(30524), translation(30526).format(BroadCast_Name), icon, 8000)
	from youtube_dl import YoutubeDL
	fields = {'forceurl': True, 'forcetitle': True, 'quiet': True, 'no_warnings': True, 'noplaylist': True, 'format': 'best', 'outtmpl': os.path.join(py2_uni(target_DIR), py2_uni(fixPathSymbols(BroadCast_Name))+'_['+now+'].%(ext)s')}
	with YoutubeDL(fields) as ydl:
		meta = ydl.extract_info(BroadCast_Url, download=True)
		try:
			if 'entries' in meta: Vinfo = meta['entries'][0]
			else:
				Vinfo = meta
			if 'url' in Vinfo: media = Vinfo['url']
			else:
				if 'formats' in Vinfo and len(Vinfo['formats']) > 0:
					media = Vinfo['formats'][-1]['url']
			log("(navigator.getDownload) DOWNLOAD-VIDEO : {0}".format(media))
		except: pass
	xbmc.sleep(2000)
	dialog.notification(translation(30525), translation(30526).format(BroadCast_Name), icon, 12000)

def listStored():
	debug_MS("(navigator.listStored) -------------------------------------------------- START = listStored --------------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	for item in os.listdir(target_DIR):
		full_Path = os.path.join(target_DIR, item)
		name = editing(item).replace('.mp4', '').replace('_', ' ')
		addLink(name, icon, {'mode': 'playVideo', 'url': full_Path, 'extras': 'DOWNstream', 'cineType': 'movie'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def getVideo(url):
	debug_MS("(navigator.getVideo) -------------------------------------------------- START = getVideo --------------------------------------------------")
	content = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.getVideo) XXXXX CONTENT : {0} XXXXX".format(str(content)))
	debug_MS("++++++++++++++++++++++++")
	FIRST = re.findall('src: "(//massengeschmack.+?)" }', content, re.S)
	SECOND = re.findall('type: "video/mp4", src: "([^"]+)"', content, re.S)
	if FIRST:
		return 'https:'+FIRST[0]
	elif SECOND:
		return SECOND[0]
	else:
		return dialog.notification(translation(30521).format('PLAY'), translation(30529), icon, 8000)

def playVideo(url, TYPE):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL = {0} ### TYPE = {1} ###".format(url, TYPE))
	if TYPE == 'DIRECTstream' and '/play/' in url:
		finalURL = getVideo(url)
	elif TYPE == 'DOWNstream':
		finalURL = url.replace('\\', '\\\\').decode('unicode_escape', 'ignore').encode('utf-8')
	else:
		finalURL = url
	log("(navigator.playVideo) StreamURL : "+finalURL)
	xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=finalURL))

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, folder=True):
	if params.get('extras') == 'YT_FOLDER': u = params.get('url')
	else: u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Tvshowtitle': params.get('origSERIE'), 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None, episode=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Episode'] = episode
	info['Tvshowtitle'] = params.get('origSERIE')
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Year'] = None
	info['Genre'] = 'Unterhaltung'
	info['Studio'] = 'Massengeschmack.TV'
	info['Mediatype'] = params.get('cineType')
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	entries = []
	if params.get('extras') == 'DIRECTstream':
		entries.append([translation(30655), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'MULTI_download', 'url': params.get('url'), 'name': params.get('origSERIE')+' - '+name}))])
	elif params.get('extras') == 'DOWNstream':
		entries.append([translation(30656), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'GotoTrash', 'url': params.get('url')}))])
	liz.addContextMenuItems(entries, replaceItems=False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
