﻿# -*- coding: utf-8 -*-

from .common import *


def _header(REFERRER=None, PRODISCO=None, USERTOKEN=None):
	header = {}
	header['Accept'] = '*/*'
	header['documentLifecycle'] = 'active'
	header['Content-Type'] = 'application/json'
	header['User-Agent'] = defaultAgent
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	header['Accept-Language'] = 'de-DE,de;q=0.9,en;q=0.8'
	header['sec-ch-ua-platform'] = 'Windows'
	header['Origin'] = BASE_URL[:-1]
	if PRODISCO: # TOKEN // SHOWS // VIDEOS // PLAYBACK
		header['X-Device-Info'] = 'STONEJS/1 (Unknown/Unknown; Unknown/Unknown; Unknown)'
		header['X-disco-client'] = 'Alps:HyogaPlayer:0.0.0'
		header['X-disco-params'] = f"realm={REALM_DISCO}"
		if USERTOKEN: # SHOWS // VIDEOS // PLAYBACK
			header['Authorization'] = f"Bearer {USERTOKEN}"
	if REFERRER:
		header['Referer'] = REFERRER # LOMA // TOKEN // SHOWS // VIDEOS // PLAYBACK
	return header

class Transmission(object):

	def __init__(self):
		self.maxTokenTime = 595 # max. Token-Time (Seconds) before clear the Token and delete Token-File [595 = 10 Minutes]
		self.tempSTORE_folder = tempSTORE
		self.disco_file = storeSECRET

	def clear_content(self, title, filename=None, foldername=None):
		debug_MS(f"(utilities.clear_content) ### DELETE OLD-FILE : * {title} * ###")
		if filename is not None and xbmcvfs.exists(filename):
			if foldername is not None and xbmcvfs.exists(foldername) and os.path.exists(foldername):
				shutil.rmtree(foldername, ignore_errors=True)

	def save_content(self, title, filename=None, foldername=None, text=""):
		debug_MS(f"(utilities.save_content) ### SAVE NEW-FILE : * {title} * ###")
		if foldername is not None:
			os.makedirs(foldername, exist_ok=True)
		if filename is not None and text != "":
			with open(filename, 'w') as save:
				json.dump(text, save, indent=4, sort_keys=True)

	def convert_epoch(self, epoch):
		CIPHER = datetime(1970,1,1) + timedelta(seconds=int(epoch))
		return CIPHER.strftime('%d.%m.%Y - %H:%M:%S')

	def check_FreeToken(self):
		debug_MS("(utilities.check_FreeToken) ##### START check_FreeToken #####")
		CODING, forceRenew, AUTH_TOKEN = False, False, None
		if xbmcvfs.exists(self.disco_file) and os.path.isfile(self.disco_file):
			self.NOW_UTC, self.FILE_UTC = time.time(), (os.path.getmtime(self.disco_file) + self.maxTokenTime)
			debug_MS(f"(utilities.check_FreeToken) ##### SESSION-Time (utc NOW) = {str(self.convert_epoch(self.NOW_UTC))} || VALID until (utc SESSION) = {str(self.convert_epoch(self.FILE_UTC))} #####")
			if self.NOW_UTC < self.FILE_UTC:
				try:
					with open(self.disco_file, 'r') as publish:
						ACC_DATA = json.load(publish)
					AUTH_TOKEN = ACC_DATA['data']['attributes']['token']
					debug_MS("(utilities.check_FreeToken) ##### NOTHING CHANGED - TOKENFILE IS OKAY #####")
				except:
					failing("(utilities.check_FreeToken) XXXXX !!! ERROR = TOKENFILE [TOKENFORMAT IS INVALID] = ERROR !!! XXXXX")
					forceRenew = True
			else:
				debug_MS("(utilities.check_FreeToken) ##### TIMEOUT FOR TOKEN - DELETE TOKENFILE #####")
				forceRenew = True
		else:
			debug_MS("(utilities.check_FreeToken) ##### NOTHING FOUND - CREATE TOKENFILE FOR DISCOVERY #####")
			forceRenew = True
		if forceRenew:
			self.clear_content('FREE_SECRET', self.disco_file, self.tempSTORE_folder)
			CODING = self.retrieveContent(ACCESS_URL, forcing=False)
			if CODING:
				debug_MS(f"(utilities.check_FreeToken) ***** NEW TOKENFILE CREATED : {CODING} *****")
				self.save_content('FREE_SECRET', self.disco_file, self.tempSTORE_folder, CODING)
				AUTH_TOKEN = CODING['data']['attributes']['token']
		return AUTH_TOKEN

	def retrieveMultiData(self, MURLS, method='GET', REF=BASE_URL, PRO=True, fields=None):
		COMBI_NEW = []
		number = len(MURLS)
		def download(pos, url, token, manager):
			CAPTION = _header(REF, None, None) if url.startswith('https://de-api.loma-cms') else _header(REF, PRO, token)
			response = manager.request(method, url, fields, headers=CAPTION, timeout=5, retries=2)
			if response and response.status in [200, 201, 202]:
				debug_MS(f"(utilities.retrieveMultiData[1]) === POS : {str(pos)} === REQUESTED URL : {url} === REQUESTED HEADER : {CAPTION} ===")
				return f'{{"Position":{str(pos)},"Demand":"{url}",{py3_dec(response.data[1:-1])}}}'
			else:
				failing(f"(utilities.retrieveMultiData[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === STATUS : {response.status} === URL : {url} === DATA : {response.data} #####")
				return '{"ERROR_occurred":true}'
		with ThreadPoolExecutor() as executor:
			connector = urllib3.PoolManager(maxsize=10, block=True)
			debug_MS("---------------------------------------------")
			REALCODE = self.check_FreeToken()
			picker = [executor.submit(download, pos, url, REALCODE, connector) for pos, url in MURLS]
			wait(picker, timeout=30, return_when=ALL_COMPLETED)
			for ii, future in enumerate(as_completed(picker), 1):
				try:
					COMBI_NEW.append(json.loads(future.result()))
				except Exception as e:
					failing(f"(utilities.retrieveMultiData[2]) ERROR - EXEPTION - ERROR ##### FUTURE_CONNECT : {future.result()} === FAILURE : {str(e)} #####")
					dialog.notification(translation(30521).format('DETAILS', ''), translation(30523).format(str(e)), icon, 10000)
					executor.shutdown()
			if COMBI_NEW:
				matching = [flop for flop in COMBI_NEW[:] if flop.get('ERROR_occurred', '') is True]
				if len(matching) == number or len(matching) > 3:
					dialog.notification(translation(30521).format('DETAILS', ''), translation(30524), icon, 10000)
			return json.dumps(COMBI_NEW, indent=2)

	def retrieveContent(self, url, method='GET', REF=BASE_URL, PRO=True, forcing=True, headers=None, cookies=None, allow_redirects=False, verify=True, stream=None, data=None, json=None):
		attempts, ANSWER = 0, None
		ACTUCODE = self.check_FreeToken() if forcing is True else None
		SPECIFICS = _header(REF, None, None) if url.startswith('https://de-api.loma-cms') else _header(REF, PRO, ACTUCODE)
		while not ANSWER and attempts < 3: # 2 x Pingversuche für den STREAM-Request ::: zur Überprüfung der Verfügbarkeit des Streams
			attempts += 1
			try:
				if method in ['GET', 'LOAD', 'TRACK']:
					response = requests.get(url, headers=SPECIFICS, allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=30)
				elif method in ['POST', 'PUSH']:
					response = requests.post(url, headers=SPECIFICS, allow_redirects=allow_redirects, verify=verify, data=data, json=json, timeout=15)
				response.raise_for_status()
				ANSWER = response.json() if method in ['GET', 'POST'] else response.text if method == 'LOAD' else response
				debug_MS(f"(utilities.retrieveContent) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {SPECIFICS} ===")
				if method == 'GET' and response.json().get('errors', ''):
					detail = (response.json().get('errors', {})[0].get('detail', '') or 'NO DETAILS FOUND')
					failing(f"(utilities.retrieveContent) ERROR - RESPONSE - ERROR ##### URL : {url} === DETAIL : {detail} #####")
					dialog.notification(translation(30521).format('URL', ''), translation(30523).format(detail), icon, 10000)
					return sys.exit(0)
			except Exception as e: # No JSON object could be decoded
				failing(f"(utilities.retrieveContent) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {str(e)} #####")
				dialog.notification(translation(30521).format('URL', ''), translation(30523).format(str(e)), icon, 10000)
				time.sleep(2)
				if attempts >= 3: return sys.exit(0)
		return ANSWER
