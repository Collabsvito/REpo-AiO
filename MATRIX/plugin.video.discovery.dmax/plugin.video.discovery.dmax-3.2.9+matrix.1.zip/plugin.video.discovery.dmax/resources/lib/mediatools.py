﻿# -*- coding: utf-8 -*-

from .common import *
from .utilities import Transmission


def preparefiles(TARGET, NAME, ROTATE):
	debug_MS("(mediatools.preparefiles) -------------------------------------------------- START = tolibrary --------------------------------------------------")
	if mediaPATH == "":
		return dialog.ok(addon_id, translation(30503))
	elif mediaPATH !="" and plugin_operate('service.cron.autobiblio'):
		NEW_SOURCE = quote_plus(f"{mediaPATH}{fixPathSymbols(NAME)}")
		if newMETHOD:
			TARGET = f"{TARGET}@@Series"
			NEW_SOURCE = quote_plus(f"{mediaPATH}Series{os.sep}{fixPathSymbols(NAME)}")
		NEW_URL = f"{sys.argv[0]}?mode=generatefiles&url={TARGET}&name={NAME}"
		NEW_NAME, NEW_URL = quote_plus(NAME), quote_plus(NEW_URL)
		debug_MS(f"(mediatools.preparefiles) ### NEW_NAME : {NEW_NAME} ###")
		debug_MS(f"(mediatools.preparefiles) ### NEW_URL : {NEW_URL} ###")
		debug_MS(f"(mediatools.preparefiles) ### NEW_SOURCE : {NEW_SOURCE} ###")
		xbmc.executebuiltin(f"RunPlugin(plugin://service.cron.autobiblio/?mode=adddata&name={NEW_NAME}&stunden={ROTATE}&url={NEW_URL}&source={NEW_SOURCE})")
		return dialog.notification(translation(30533), translation(30534).format(f"{NAME}  (Serie)", ROTATE), icon, 15000)

def generatefiles(BroadCast_IDD, BroadCast_NAME):
	debug_MS("(mediatools.generatefiles) -------------------------------------------------- START = generatefiles --------------------------------------------------")
	debug_MS(f"(mediatools.generatefiles) ### BroadCast_IDD = {BroadCast_IDD} || BroadCast_NAME = {BroadCast_NAME} ###")
	if not enableLIBRARY or mediaPATH == "":
		return
	PHRASE_TVS, RIDERS_TVS, SHOW_season, TVS_species, BIBO_PAGES, BIBO_EPISODE, COMBINATION = ([] for _ in range(7))
	thumb_uno, poster_uno, desc_uno, thumb_due, desc_due, counter = icon, None, "", icon, "", 0
	TVS_season, TVS_episode, TVS_airdate, TVS_yeardate = ("" for _ in range(4))
	pos_ESP = 0
	newIDD = BroadCast_IDD.split('@@')[0] if '@@' in BroadCast_IDD else BroadCast_IDD
	if newMETHOD:
		EP_Path = xbmcvfs.translatePath(os.path.join(mediaPATH, 'Series', fixPathSymbols(BroadCast_NAME), ''))
	else:
		EP_Path = xbmcvfs.translatePath(os.path.join(mediaPATH, fixPathSymbols(BroadCast_NAME), ''))
	TVS_URL = f"{API_DISCO}/content/shows?include=images,genres,seasons&sort=name&filter[id]={newIDD}&filter[primaryChannel.id]={PRIMARY_CHANNEL}"
	debug_MS(f"(mediatools.generatefiles) ##### TVS_URL : {TVS_URL} #####")
	debug_MS(f"(mediatools.generatefiles) ##### EP_PATH : {EP_Path} #####")
	if xbmcvfs.exists(EP_Path) and os.path.exists(EP_Path):
		shutil.rmtree(EP_Path, ignore_errors=True)
		xbmc.sleep(200)
	try:
		SHOW_UNO = Transmission().retrieveContent(API_LOMA.format('/page/sendungen/'), forcing=False)
		SHOW_DUE = Transmission().retrieveContent(TVS_URL)
		TVS_title = cleaning(SHOW_DUE['data'][0]['attributes']['name'])
	except: return
	if SHOW_UNO.get('blocks', []) and len(SHOW_UNO['blocks']) > 0:
		for elem_uno in SHOW_UNO['blocks'][0].get('items', []):
			showIDD = elem_uno['attributes']['showId'] if elem_uno.get('attributes', '') and elem_uno['attributes'].get('showId', '') else None
			if showIDD and showIDD == newIDD and elem_uno.get('title', ''):
				TVS_species = [axo.get('title', '') for axo in elem_uno.get('taxonomies', [])]
				if TVS_species: TVS_species = sorted(TVS_species)
				if elem_uno.get('metaMedia', '') and len(elem_uno['metaMedia']) > 0:
					thumb_uno = [vot.get('media', {}).get('url', []) for vot in elem_uno.get('metaMedia') if vot.get('role') == 'default'][0]
					poster_uno = [vsr.get('media', {}).get('url', []) for vsr in elem_uno.get('metaMedia') if vsr.get('role') == 'preview'][0]
				if elem_uno.get('articleContent', ''):
					desc_uno = cleaning(elem_uno['articleContent']).replace('\n', '[CR]')
					desc_uno += '' if desc_uno.endswith(('.', '!', '?')) else '...'
	if SHOW_DUE.get('data', []) and len(SHOW_DUE['data']) > 0:
		TVS_PICS = list(filter(lambda x: x['type'] == 'image', SHOW_DUE.get('included', [])))
		for elem_due in SHOW_DUE.get('data', []):
			if elem_due.get('relationships', '') and elem_due['relationships'].get('images', '') and elem_due['relationships']['images'].get('data', ''):
				thumb_due = [img.get('attributes', {}).get('src', []) for img in TVS_PICS if img.get('id') == elem_due['relationships']['images']['data'][0]['id']][0]
			elem_due = elem_due['attributes'] if elem_due.get('attributes', '') else elem_due
			NEW_SEASON = str(elem_due['seasonNumbers']) if elem_due.get('seasonNumbers', '') else ""
			SHOW_season, TVS_season = NEW_SEASON, NEW_SEASON
			epis_num = str(elem_due['episodeCount']) if str(elem_due.get('episodeCount')).isdecimal() and int(elem_due['episodeCount']) > 1 else "" # All Episodes without STANDALONE = Specials
			TVS_episode = str(elem_due['videoCount']) if epis_num == "" and str(elem_due.get('videoCount')).isdecimal() and 1 <= int(elem_due['videoCount']) <= 5 else epis_num # All Videos include CLIP
			desc_due = cleaning(elem_due['description']).replace('\n', '[CR]') if elem_due.get('description', '') else ' '
			TVS_airdate = (str(elem_due.get('latestVideo', {}).get('airDate', ''))[:10] or str(elem_due.get('newestEpisodePublishStart', ''))[:10] or "")
			TVS_yeardate = (str(elem_due.get('latestVideo', {}).get('airDate', ''))[:4] or str(elem_due.get('newestEpisodePublishStart', ''))[:4] or "")
	TVS_image = thumb_uno if thumb_uno != icon else thumb_due if thumb_due != icon else f"{artpic}standard.png"
	TVS_aspect = 'poster' if poster_uno is not None else 'thumb'
	TVS_poster = poster_uno if poster_uno is not None else TVS_image
	TVS_plot = desc_uno if len(desc_uno) > len(desc_due) else desc_due
	if len(SHOW_season) > 0:
		for extracting in re.findall(r'\d+', SHOW_season):
			counter += 1
			PHRASE_TVS.append(f'    <thumb spoof="" cache="" season="{extracting}" type="season" aspect="{TVS_aspect}" preview="{TVS_poster}">{TVS_poster}</thumb>')
	if counter == 0:
		PHRASE_TVS.append(f'    <thumb spoof="" cache="" season="" type="season" aspect="{TVS_aspect}" preview="{TVS_poster}">{TVS_poster}</thumb>')
	for son in range(1, 6, 1):
		BLINK = f"{API_DISCO}/content/videos?include=images,genres&sort=name&filter[show.id]={newIDD}&filter[videoType]=EPISODE,STANDALONE&page[number]={str(son)}&page[size]=100"
		debug_MS(f"(mediatools.generatefiles[1]) EPISODE-PAGES XXX POS = {str(son)} || URL = {BLINK} XXX")
		BIBO_PAGES.append([int(son), BLINK])
	if BIBO_PAGES:
		BIBO_EPISODE = Transmission().retrieveMultiData(BIBO_PAGES)
		if BIBO_EPISODE:
			DATA_UNO = json.loads(BIBO_EPISODE)
			#log("++++++++++++++++++++++++")
			#log(f"(mediatools.generatefiles[2]) XXXXX DATA_UNO-02 : {DATA_UNO} XXXXX")
			#log("++++++++++++++++++++++++")
			for saxo in DATA_UNO:
				if saxo is not None and 'data' in saxo and len(saxo['data']) > 0:
					GENRES = list(filter(lambda x: x['type'] == 'genre', saxo.get('included', [])))
					IMAGES = list(filter(lambda x: x['type'] == 'image', saxo.get('included', [])))
					for catch in saxo.get('data', []):
						EP_genre1, EP_genre2, EP_genre3, EP_SUFFIX, Note_1, Note_2, Note_3, EP_fsk, EP_image, EP_airdate, EP_yeardate = ("" for _ in range(11))
						EP_season, EP_episode, EP_duration = ('0' for _ in range(3))
						EP_species, (startTIMES, endTIMES) = [], (None for _ in range(2))
						EP_idd = catch.get('id', None)
						if catch.get('relationships').get('genres', '') and catch['relationships']['genres'].get('data', ''):
							oneGEN = [og.get('id', []) for og in catch['relationships']['genres']['data']]
							EP_species = [tg.get('attributes', {}).get('name', []) for tg in GENRES if tg.get('id') in oneGEN]
							if EP_species: EP_species = sorted(EP_species)
						if catch.get('relationships').get('images', '') and catch['relationships']['images'].get('data', ''):
							EP_image = [img.get('attributes', {}).get('src', []) for img in IMAGES if img.get('id') == catch['relationships']['images']['data'][0]['id']][0]
						EP_genius = TVS_species if len(TVS_species) > len(EP_species) else EP_species
						if len(EP_genius) > 0: EP_genre1 = EP_genius[0]
						if len(EP_genius) > 1: EP_genre2 = EP_genius[1]
						if len(EP_genius) > 2: EP_genre3 = EP_genius[2]
						catch = catch['attributes'] if catch.get('attributes', '') else catch
						debug_MS(f"(mediatools.generatefiles[2]) ##### ELEMENT-02 : {catch} #####")
						EP_title = cleaning(catch.get('name', None))
						if EP_idd is None or EP_title is None:
							continue
						if catch.get('isExpiring', '') is True or catch.get('isNew', '') is True:
							EP_SUFFIX = translation(30624) if catch.get('isNew', '') is True else translation(30625)
						EP_season = f"{int(catch['seasonNumber']):02}" if str(catch.get('seasonNumber')).isdecimal() else 00
						EP_episode = f"{int(catch['episodeNumber']):02}" if str(catch.get('episodeNumber')).isdecimal() else 00
						EP_type = catch.get('videoType', 'UNKNOWN')
						if EP_type.upper() == 'STANDALONE' and EP_episode == 00:
							pos_ESP += 1
						if EP_season != 00 and EP_episode != 00:
							EP_SHORT_title = f"S{EP_season}E{EP_episode}_{EP_title}"
						else:
							if EP_type.upper() == 'STANDALONE':
								EP_season, EP_episode = f"{int(0):02}", f"{int(pos_ESP):02}"
								EP_SHORT_title = f"S{EP_season}E{EP_episode}_{EP_title}"
							else: EP_SHORT_title = EP_title
						if str(catch.get('publishStart'))[:4].isdecimal() and str(catch.get('publishStart'))[:4] not in ['0', '1970']:
							LOCALstart = get_CentralTime(catch['publishStart'])
							startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						if str(catch.get('publishEnd'))[:4].isdecimal() and str(catch.get('publishEnd'))[:4] not in ['0', '1970']:
							LOCALend = get_CentralTime(catch['publishEnd'])
							endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						if startTIMES and endTIMES: Note_1 = translation(30628).format(startTIMES, endTIMES)
						elif startTIMES and endTIMES is None: Note_1 = translation(30629).format(startTIMES)
						elif startTIMES is None and endTIMES is None: Note_1 = '[CR]'
						if str(catch.get('rating')).isdecimal():
							EP_fsk = translation(30630).format(catch['rating']) if str(catch.get('rating')) != '0' else translation(30631)
						if EP_fsk == "" and catch.get('contentRatings', '') and str(catch.get('contentRatings', {})[0].get('code', '')).isdecimal():
							EP_fsk = translation(30630).format(catch['contentRatings'][0]['code']) if str(catch['contentRatings'][0]['code']) != '0' else translation(30631)
						Note_2 = cleaning(catch['description']).replace('\n', '[CR]') if catch.get('description', '') else ""
						EP_plot = f"{BroadCast_NAME}[CR]{Note_1}{Note_2}"
						EP_protect = catch.get('drmEnabled', False)
						EP_duration = get_RunTime(catch['videoDuration'], 'MINUTES') if str(catch.get('videoDuration')).isdecimal() else '0'
						EP_airdate = (str(catch.get('airDate', ''))[:10] or str(catch.get('publishStart', ''))[:10] or "")
						EP_yeardate = (str(catch.get('airDate', ''))[:4] or str(catch.get('publishStart', ''))[:4] or "")
						EP_STREAM_ENTRIES = build_mass({'mode': 'playVideo', 'url': EP_idd})
						episodeFILE = fixPathSymbols(EP_SHORT_title) # NAME=STANDARD OHNE HINWEIS (neu|endet bald) !!!
						EP_LONG_title = EP_title+EP_SUFFIX # NAME=LONVERSION MIT SUFFIX=HINWEIS (neu|endet bald) !!!
						COMBINATION.append([episodeFILE, EP_LONG_title, TVS_title, EP_idd, EP_season, EP_episode, EP_plot, EP_duration, EP_image, EP_fsk, EP_genre1, EP_genre2, EP_genre3, EP_yeardate, EP_airdate, EP_protect, EP_STREAM_ENTRIES])
	if not COMBINATION: return
	else:
		os.makedirs(EP_Path, exist_ok=True)
		for episodeFILE, EP_LONG_title, TVS_title, EP_idd, EP_season, EP_episode, EP_plot, EP_duration, EP_image, EP_fsk, EP_genre1, EP_genre2, EP_genre3, EP_yeardate, EP_airdate, EP_protect, EP_STREAM_ENTRIES in COMBINATION:
			nfo_EPISODE_string = os.path.join(EP_Path, f'{episodeFILE}.nfo')
			with open(nfo_EPISODE_string, 'w', encoding='utf-8') as textout_EPIS:
				textout_EPIS.write(
f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<episodedetails>
    <title>{EP_LONG_title}</title>
    <showtitle>{TVS_title}</showtitle>
    <season>{EP_season}</season>
    <episode>{EP_episode}</episode>
    <plot>{EP_plot}</plot>
    <runtime>{EP_duration}</runtime>
    <thumb spoof="" cache="" aspect="" preview="{EP_image}">{EP_image}</thumb>
    <fanart>
        <thumb dim="1280x720" colors="" preview="{EP_image}">{EP_image}</thumb>
    </fanart>
    <mpaa>{EP_fsk}</mpaa>
    <genre clear="true">{EP_genre1}</genre>
    <genre>{EP_genre2}</genre>
    <genre>{EP_genre3}</genre>
    <year>{EP_yeardate}</year>
    <aired>{EP_airdate}</aired>
    <studio clear="true">DMAX</studio>
</episodedetails>''')
			strm_EPISODE_string = os.path.join(EP_Path, f'{episodeFILE}.strm')
			debug_MS(f"(mediatools.generatefiles[3]) ##### streamFILE-03 : {cleaning(strm_EPISODE_string)} #####")
			with xbmcvfs.File(strm_EPISODE_string, 'w') as textout_STRM:
				textout_STRM.write(EP_STREAM_ENTRIES)
		RIDERS_TVS.append(
f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<tvshow>
    <title>{TVS_title}</title>
    <showtitle>{TVS_title}</showtitle>
    <season>{TVS_season}</season>
    <episode>{TVS_episode}</episode>
    <plot>{TVS_plot}</plot>
    <thumb spoof="" cache="" aspect="" preview="{TVS_image}">{TVS_image}</thumb>\n''')
		RIDERS_TVS.extend('\n'.join([pse for pse in PHRASE_TVS]))
		RIDERS_TVS.extend(f'''
    <fanart>
        <thumb dim="1280x720" colors="" preview="{TVS_image}">{TVS_image}</thumb>
    </fanart>
    <genre clear="true">{EP_genre1}</genre>
    <genre>{EP_genre2}</genre>
    <genre>{EP_genre3}</genre>
    <year>{TVS_yeardate}</year>
    <aired>{TVS_airdate}</aired>
    <studio clear="true">DMAX</studio>
</tvshow>''')
		nfo_SERIE_string = os.path.join(EP_Path, 'tvshow.nfo')
		with open(nfo_SERIE_string, 'w', encoding='utf-8') as textout_TVS:
			textout_TVS.write(''.join([ris for ris in RIDERS_TVS]))
	debug_MS("(mediatools.generatefiles[4]) XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  ENDE = generatefiles  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
