﻿# -*- coding: utf-8 -*-

from .common import *


def preparefiles(url, name, rotation):
	debug_MS("(mediatools.preparefiles) -------------------------------------------------- START = tolibrary --------------------------------------------------")
	if mediaPath =="":
		return dialog.ok(addon_id, translation(30503))
	elif mediaPath !="" and ADDON_operate('service.cron.autobiblio'):
		newSOURCE = quote_plus(mediaPath+fixPathSymbols(name))
		if newMETHOD:
			url = url+'@@Series'
			newSOURCE = quote_plus(mediaPath+'Series'+os.sep+fixPathSymbols(name))
		newURL = f"{sys.argv[0]}?mode=generatefiles&url={url}&name={name}"
		newNAME, newURL = quote_plus(name), quote_plus(newURL)
		debug_MS(f"(mediatools.preparefiles) ### newNAME : {newNAME} ###")
		debug_MS(f"(mediatools.preparefiles) ### newURL : {newURL} ###")
		debug_MS(f"(mediatools.preparefiles) ### newSOURCE : {newSOURCE} ###")
		xbmc.executebuiltin(f"RunPlugin(plugin://service.cron.autobiblio/?mode=adddata&name={newNAME}&stunden={rotation}&url={newURL}&source={newSOURCE})")
		return dialog.notification(translation(30531), translation(30532).format(name+'  (Serie)', str(rotation)), icon, 15000)

def generatefiles(BroadCast_IDD, BroadCast_NAME):
	debug_MS("(mediatools.generatefiles) -------------------------------------------------- START = generatefiles --------------------------------------------------")
	debug_MS(f"(mediatools.generatefiles) ### BroadCast_IDD = {BroadCast_IDD} || BroadCast_NAME = {BroadCast_NAME} ###")
	if not enableLIBRARY or mediaPath =="":
		return
	BIBO_PAGES, BIBO_EPISODE, COMBINATION = ([] for _ in range(3))
	pos_ESP = 0
	newIDD = BroadCast_IDD.split('@@')[0] if '@@' in BroadCast_IDD else BroadCast_IDD
	if newMETHOD:
		EP_Path = os.path.join(mediaPath, 'Series', fixPathSymbols(BroadCast_NAME), '')
	else:
		EP_Path = os.path.join(mediaPath, fixPathSymbols(BroadCast_NAME), '')
	TVS_URL = f"{API_URL}/content/shows?include=images,genres,seasons&sort=name&filter[id]={newIDD}"
	debug_MS(f"(mediatools.generatefiles) ##### TVS_URL : {str(TVS_URL)} #####")
	debug_MS(f"(mediatools.generatefiles) ##### EP_PATH : {str(EP_Path)} #####")
	if os.path.isdir(EP_Path):
		shutil.rmtree(EP_Path, ignore_errors=True)
		xbmc.sleep(300)
	xbmcvfs.mkdirs(EP_Path)
	try:
		SHOW_DATA = getUrl(TVS_URL)
		TVS_title = cleaning(SHOW_DATA['data'][0]['attributes']['name'])
	except: return
	TVS_pictures = list(filter(lambda x: x['type'] == 'image', SHOW_DATA.get('included', [])))
	for elem in SHOW_DATA['data']:
		TVS_image, TVS_season, TVS_episode, TVS_plot, TVS_airdate, TVS_yeardate = ("" for _ in range(6))
		if elem.get('relationships', None) and elem.get('relationships').get('images', None) and elem.get('relationships').get('images').get('data', None):
			TVS_image = [img.get('attributes', {}).get('src', []) for img in TVS_pictures if img.get('id') == elem['relationships']['images']['data'][0]['id']][0]
		elem = elem['attributes'] if elem.get('attributes', '') else elem
		TVS_season = (str(elem.get('seasonNumbers', '')) or "")
		TVS_episode = (str(elem.get('episodeCount', '')) or "")
		TVS_plot = (cleaning(elem.get('description', '')).replace('\n', '[CR]') or "")
		TVS_airdate = (str(elem.get('latestVideo', {}).get('airDate', ''))[:10] or str(elem.get('newestEpisodePublishStart', ''))[:10] or "")
		TVS_yeardate = (str(elem.get('latestVideo', {}).get('airDate', ''))[:4] or str(elem.get('newestEpisodePublishStart', ''))[:4] or "")
	for ps in range(1, 6, 1):
		BLINK = f"{API_URL}/content/videos?include=images,genres&sort=name&filter[show.id]={newIDD}&filter[videoType]=EPISODE,STANDALONE&page[number]={str(ps)}&page[size]=100"
		debug_MS(f"(mediatools.generatefiles[1]) EPISODE-PAGES XXX POS = {str(ps)} || URL = {BLINK} XXX")
		BIBO_PAGES.append([int(ps), BLINK])
	if BIBO_PAGES:
		BIBO_EPISODE = getMultiData(BIBO_PAGES)
		if BIBO_EPISODE:
			DATA_UNO = json.loads(BIBO_EPISODE)
			#log("++++++++++++++++++++++++")
			#log(f"(mediatools.generatefiles[2]) XXXXX DATA_UNO-02 : {str(DATA_UNO)} XXXXX")
			#log("++++++++++++++++++++++++")
			for sumo in DATA_UNO:
				if sumo is not None and 'data' in sumo and len(sumo['data']) > 0:
					GENRES = list(filter(lambda x: x['type'] == 'genre', sumo.get('included', [])))
					IMAGES = list(filter(lambda x: x['type'] == 'image', sumo.get('included', [])))
					for catch in sumo.get('data', []):
						EP_genre1, EP_genre2, EP_genre3, EP_SUFFIX, Note_1, Note_2, Note_3, EP_fsk, EP_image, EP_airdate, EP_yeardate = ("" for _ in range(11))
						EP_season, EP_episode, EP_duration = ('0' for _ in range(3))
						startTIMES, endTIMES = (None for _ in range(2))
						oneGEN, EP_genreLIST = ([] for _ in range(2))
						if catch.get('relationships').get('genres', None) and catch.get('relationships').get('genres').get('data', None):
							oneGEN = [og.get('id', []) for og in catch['relationships']['genres']['data']]
							EP_genreLIST = [tg.get('attributes', {}).get('name', []) for tg in GENRES if tg.get('id') in oneGEN]
							if EP_genreLIST: EP_genreLIST = sorted(EP_genreLIST)
						if catch.get('relationships').get('images', None) and catch.get('relationships').get('images').get('data', None):
							EP_image = [img.get('attributes', {}).get('src', []) for img in IMAGES if img.get('id') == catch['relationships']['images']['data'][0]['id']][0]
						if len(EP_genreLIST) > 0: EP_genre1 = EP_genreLIST[0]
						if len(EP_genreLIST) > 1: EP_genre2 = EP_genreLIST[1]
						if len(EP_genreLIST) > 2: EP_genre3 = EP_genreLIST[2]
						EP_idd = (catch.get('id', '00') or '00')
						catch = catch['attributes'] if catch.get('attributes', '') else catch
						debug_MS(f"(mediatools.generatefiles[2]) ##### ELEMENT-02 : {str(catch)} #####")
						if catch.get('name', ''):
							EP_title = cleaning(catch['name'])
						else: continue
						if catch.get('isExpiring', '') is True or catch.get('isNew', '') is True:
							EP_SUFFIX = translation(30625) if catch.get('isNew', '') is True else translation(30626)
						EP_season = str(catch['seasonNumber']).zfill(2) if catch.get('seasonNumber', '') else '0'
						EP_episode = str(catch['episodeNumber']).zfill(2) if catch.get('episodeNumber', '') else '0'
						EP_type = (catch.get('videoType', 'SINGLE') or 'SINGLE')
						if EP_type.upper() == 'STANDALONE' and EP_episode == '0':
							pos_ESP += 1
						if EP_season != '0' and EP_episode != '0':
							EP_SHORT_title = f"S{EP_season}E{EP_episode}_{EP_title}"
						else:
							if EP_type.upper() == 'STANDALONE':
								EP_episode = str(pos_ESP).zfill(2)
								EP_SHORT_title = f"S00E{EP_episode}_{EP_title}"
							else: EP_SHORT_title = EP_title
						if str(catch.get('publishStart'))[:4].isdigit() and str(catch.get('publishStart'))[:4] not in ['0', '1970']:
							LOCALstart = get_Local_DT(catch['publishStart'][:19])
							startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						if str(catch.get('publishEnd'))[:4].isdigit() and str(catch.get('publishEnd'))[:4] not in ['0', '1970']:
							LOCALend = get_Local_DT(catch['publishEnd'][:19])
							endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						if startTIMES and endTIMES: Note_1 = translation(30630).format(str(startTIMES), str(endTIMES))
						elif startTIMES and endTIMES is None: Note_1 = translation(30631).format(str(startTIMES))
						elif startTIMES is None and endTIMES is None: Note_1 = '[CR]'
						if str(catch.get('rating')).isdigit():
							EP_fsk = translation(30632).format(str(catch['rating'])) if str(catch.get('rating')) != '0' else translation(30633)
						if EP_fsk == "" and catch.get('contentRatings', '') and str(catch.get('contentRatings', {})[0].get('code', '')).isdigit():
							EP_fsk = translation(30632).format(str(catch['contentRatings'][0]['code'])) if str(catch['contentRatings'][0]['code']) != '0' else translation(30633)
						Note_2 = cleaning(catch['description']).replace('\n', '[CR]') if catch.get('description', '') else ""
						EP_plot = translation(30624).format(BroadCast_NAME)+Note_1+Note_2
						EP_protect = (catch.get('drmEnabled', False) or False)
						EP_duration = get_Time(catch['videoDuration'], 'MINUTES') if str(catch.get('videoDuration')).isdigit() else '0'
						EP_airdate = (str(catch.get('airDate', ''))[:10] or str(catch.get('publishStart', ''))[:10] or "")
						EP_yeardate = (str(catch.get('airDate', ''))[:4] or str(catch.get('publishStart', ''))[:4] or "")
						EP_STREAM_ENTRIES = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playVideo', 'url': EP_idd}))
						episodeFILE = fixPathSymbols(EP_SHORT_title) # NAME=STANDARD OHNE HINWEIS (neu|endet bald) !!!
						EP_LONG_title = EP_title+EP_SUFFIX # NAME=LONVERSION MIT SUFFIX=HINWEIS (neu|endet bald) !!!
						COMBINATION.append([episodeFILE, EP_LONG_title, TVS_title, EP_idd, EP_season, EP_episode, EP_plot, EP_duration, EP_image, EP_fsk, EP_genre1, EP_genre2, EP_genre3, EP_yeardate, EP_airdate, EP_protect, EP_STREAM_ENTRIES])
	if not COMBINATION: return
	if not os.path.exists(EP_Path):
		os.makedirs(EP_Path)
	for episodeFILE, EP_LONG_title, TVS_title, EP_idd, EP_season, EP_episode, EP_plot, EP_duration, EP_image, EP_fsk, EP_genre1, EP_genre2, EP_genre3, EP_yeardate, EP_airdate, EP_protect, EP_STREAM_ENTRIES in COMBINATION:
		nfo_EPISODE_string = os.path.join(EP_Path, episodeFILE+'.nfo')
		with io.open(nfo_EPISODE_string, 'w', encoding='utf-8') as textobj_EP:
			textobj_EP.write(
'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<episodedetails>
    <title>{0}</title>
    <showtitle>{1}</showtitle>
    <season>{2}</season>
    <episode>{3}</episode>
    <plot>{4}</plot>
    <runtime>{5}</runtime>
    <thumb spoof="" cache="" aspect="" preview="{6}">{6}</thumb>
    <fanart>
        <thumb dim="1280x720" colors="" preview="{6}">{6}</thumb>
    </fanart>
    <mpaa>{7}</mpaa>
    <genre clear="true">{8}</genre>
    <genre>{9}</genre>
    <genre>{10}</genre>
    <year>{11}</year>
    <aired>{12}</aired>
    <studio clear="true">DMAX</studio>
</episodedetails>'''.format(EP_LONG_title, TVS_title, EP_season, EP_episode, EP_plot, EP_duration, EP_image, EP_fsk, EP_genre1, EP_genre2, EP_genre3, EP_yeardate, EP_airdate))
		streamfile = os.path.join(EP_Path, episodeFILE+'.strm')
		debug_MS(f"(mediatools.generatefiles[3]) ##### streamFILE-03 : {cleaning(streamfile)} #####")
		file = xbmcvfs.File(streamfile, 'w')
		file.write(EP_STREAM_ENTRIES)
		file.close()
	nfo_SERIE_string = os.path.join(EP_Path, 'tvshow.nfo')
	with io.open(nfo_SERIE_string, 'w', encoding='utf-8') as textobj_TVS:
		textobj_TVS.write(
'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<tvshow>
    <title>{0}</title>
    <showtitle>{0}</showtitle>
    <season>{1}</season>
    <episode>{2}</episode>
    <plot>{3}</plot>
    <thumb spoof="" cache="" aspect="" preview="{4}">{4}</thumb>
    <thumb spoof="" cache="" season="" type="season" aspect="" preview="{4}">{4}</thumb>
    <fanart>
        <thumb dim="1280x720" colors="" preview="{4}">{4}</thumb>
    </fanart>
    <genre clear="true">{5}</genre>
    <genre>{6}</genre>
    <genre>{7}</genre>
    <year>{8}</year>
    <aired>{9}</aired>
    <studio clear="true">DMAX</studio>
</tvshow>'''.format(TVS_title, TVS_season, TVS_episode, TVS_plot, TVS_image, EP_genre1, EP_genre2, EP_genre3, TVS_yeardate, TVS_airdate))
	debug_MS("(mediatools.generatefiles[4]) XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  ENDE = generatefiles  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
