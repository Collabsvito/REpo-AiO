﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	config = traversing.get_config()
	addDir(translation(30601), icon, {'mode': 'listEpisodes', 'url': config['COLLECT_DATE'].format('episode'), 'extras': 'newEP', 'transmit': translation(30601).split('[/COLOR] ')[1]})
	addDir(translation(30602), icon, {'mode': 'listEpisodes', 'url': config['COLLECT_IDD'].format(config['RELATED'], 'musicvideo'), 'extras': 'newMU', 'transmit': translation(30602).split('[/COLOR] ')[1]})
	addDir(translation(30603), icon, {'mode': 'listBroadcasts', 'url': config['COLLECT_TITLE'].format('series')})
	addDir(translation(30604), icon, {'mode': 'listMusics'})
	addDir(translation(30605), icon, {'mode': 'listCharts'})
	addDir(translation(30606), icon, {'mode': 'listPlaylists', 'url': config['COLLECT_IDD'].format(config['EXCLUDED'], 'videoplaylist')})
	addDir(translation(30607), artpic+'livestream.png', {'mode': 'playLIVE', 'url': config['LIVESTREAM']}, folder=False)
	addDir(translation(30608).format(str(cachePERIOD)), f"{artpic}remove.png", {'mode': 'clearCache'})
	if enableADJUSTMENT:
		addDir(translation(30609), f"{artpic}settings.png", {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30610), f"{artpic}settings.png", {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(url):
	debug_MS("(navigator.listBroadcasts) ------------------------------------------------ START = listBroadcasts -----------------------------------------------")
	debug_MS(f"(navigator.listBroadcasts) ### URL : {url} ###")
	FOUND = 0
	for ii in range(1, 4, 1):
		DATA = makeREQUEST(f"{url}&pageNumber={str(ii)}&pageSize=30")
		debug_MS("++++++++++++++++++++++++")
		debug_MS(f"(navigator.listBroadcasts[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
		debug_MS("++++++++++++++++++++++++")
		if DATA.get('data', '') and DATA['data'].get('items', '') and len(DATA['data']['items']) > 0:
			for item in DATA['data']['items']:
				POSTERSIZE = list(filter(lambda x: x['aspectRatio'] == '2:3', item.get('images', [])))
				plus_SUFFIX, genre = ("" for _ in range(2))
				cover, SEAS, EDIT = (None for _ in range(3))
				genreLIST = []
				showID = item.get('mgid', '00')
				shortId = item.get('shortId', '00')
				title = (cleaning(item.get('title')) or cleaning(item.get('shortTitle')))
				if item.get('ribbon', '') and (item['ribbon'].get('newSeries', '') is True or item['ribbon'].get('newSeason', '') is True or item['ribbon'].get('newEpisode', '') is True):
					plus_SUFFIX = translation(30620)
				name = title+plus_SUFFIX
				plot, photo = get_Description(item), icon
				entityType = item.get('entityType', 'Unknown')
				if item.get('images', '') and len(item['images']) > 0:
					# https://images.paramount.tech/uri/mgid:arc:imageassetref:mtv.de:6bda844a-3c16-4d1c-8f21-cd06e73e88d0?quality=0.7&gen=ntrn&legacyStatusCode=true
					resolution = max(item['images'], key=lambda y: int(y.get('width')))
					photo = f"{resolution.get('url').replace('https://mtv.mtvnimages.com/', 'https://images.paramount.tech/').split('?quality=')[0]}?quality=0.7&gen=ntrn&legacyStatusCode=true" if \
						resolution.get('url').endswith('gen=ntrn') else resolution.get('url').replace('https://mtv.mtvnimages.com/', 'https://images.paramount.tech/')
				if POSTERSIZE and len(POSTERSIZE) > 0:
					cover = [f"{img.get('url', '').split('?quality=')[0]}?quality=0.7&gen=ntrn&legacyStatusCode=true&width=600&height=900&crop=true" for img in POSTERSIZE][0]
				if item.get('genres', '') and len(item['genres']) > 0:
					genreLIST = [cleaning(gen) for gen in item.get('genres', {})]
					if genreLIST: genre = ' / '.join(sorted(genreLIST))
				if item.get('links', '') and item['links'].get('season', ''):
					SEAS = f"{item['links']['season']}&orderBy=seasonNumber&order=ascending"
				if SEAS is None and item.get('links', '') and item['links'].get('editorialplaylist', ''):
					EDIT = f"{item['links']['editorialplaylist']}&orderBy=originalPublishDate&order=descending"
				debug_MS(f"(navigator.listBroadcasts[2]) ##### NAME = {name} || URL = {str(SEAS) if SEAS else str(EDIT)} #####")
				debug_MS(f"(navigator.listBroadcasts[2]) ##### TYPE = {'SERIES' if SEAS else 'EDITORIALPLAYLIST' if EDIT else 'UNKNOWN'} || THUMB = {photo} #####")
				debug_MS("---------------------------------------------")
				if SEAS is None and EDIT is None:
					continue
				FOUND += 1
				if SEAS: addDir(name, photo, {'mode': 'listSeasons', 'url': SEAS, 'extras': photo, 'transmit': title}, plot, genre, cover)
				elif EDIT: addDir(name, photo, {'mode': 'listPlaylists', 'url': EDIT}, plot, genre, cover)
	if FOUND == 0:
		debug_MS("(navigator.listBroadcasts) ##### Keine BROADCASTS-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524).format('Einträge'), translation(30525).format('SHOWS'), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(url, THUMB, SERIE):
	debug_MS("(navigator.listSeasons) ------------------------------------------------ START = listSeasons -----------------------------------------------")
	debug_MS(f"(navigator.listSeasons) ### URL : {url} ### THUMB : {THUMB} ### SERIE : {SERIE} ###")
	COMBI_SEASON = []
	FOUND = 0
	DATA = makeREQUEST(f"{url}&pageNumber=1&pageSize=40")
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listSeasons[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	for elem in DATA['data']['items']:
		EPIS = None
		seasID = elem.get('mgid', '00')
		shortId = elem.get('shortId', '00')
		plot = get_Description(elem)
		entityType = elem.get('entityType', 'Unknown')
		name = translation(30621).format(str(elem['seasonNumber'])) if elem.get('seasonNumber', '') else translation(30622)
		if elem.get('links', '') and elem['links'].get('episode', ''):
			EPIS = f"{elem['links']['episode']}&orderBy=episodeAiringOrder&order=ascending"
		debug_MS(f"(navigator.listSeasons[2]) ##### NAME = {name} || URL = {str(EPIS)} #####")
		debug_MS(f"(navigator.listSeasons[2]) ##### TYPE = {entityType.upper()} || THUMB = {THUMB} #####")
		debug_MS("---------------------------------------------")
		if EPIS is None:
			continue
		FOUND += 1
		COMBI_SEASON.append([name, THUMB, SERIE, EPIS, plot])
	if COMBI_SEASON and FOUND == 1:
		debug_MS("(navigator.listSeasons) ----- Only one Season FOUND - goto = listEpisodes -----")
		for name, THUMB, SERIE, EPIS, plot in COMBI_SEASON:
			return listEpisodes(EPIS, extras, f"{SERIE} - {name}", page, target)
	elif COMBI_SEASON and FOUND > 1:
		for name, THUMB, SERIE, EPIS, plot in COMBI_SEASON:
			addDir(name, THUMB, {'mode': 'listEpisodes', 'url': EPIS, 'transmit': f"{SERIE} - {name}"}, plot)
	else:
		debug_MS("(navigator.listSeasons) ##### Keine COMBI_SEASON-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30526), translation(30527).format(SERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listMusics():
	debug_MS("(navigator.listMusics) ------------------------------------------------ START = listMusics -----------------------------------------------")
	config = traversing.get_config()
	addDir(translation(30701), icon, {'mode': 'listEpisodes', 'url': config['COLLECT_IDD'].format(config['RELATED'], 'musicvideo'), 'extras': 'MUSIC', 'transmit': translation(30701)})
	for n in config['music']:
		addDir(n['title'], icon, {'mode': 'listEpisodes', 'url': config['COLLECT_IDD'].format(n['id'], 'musicvideo'), 'extras': 'MUSIC', 'transmit': n['title']})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPlaylists(url, PAGE):
	debug_MS("(navigator.listPlaylists) ------------------------------------------------ START = listPlaylists -----------------------------------------------")
	debug_MS(f"(navigator.listPlaylists) ### URL : {url} ### PAGE : {PAGE} ###")
	COMBI_PLAYLIST = []
	FOUND = 0
	DATA = makeREQUEST(f"{url}&pageNumber={PAGE}&pageSize=30")
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listPlaylists[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	for elem in DATA['data']['items']:
		Note_1, Note_2 = ("" for _ in range(2))
		startTIMES, LINK = (None for _ in range(2))
		playID = elem.get('mgid', '00')
		shortId = elem.get('shortId', '00')
		name, photo = cleaning(elem['title']), icon
		entityType = elem.get('entityType', 'Unknown')
		origSERIE = cleaning(elem['parentEntity']['title'])+'[CR]' if elem.get('parentEntity', '') and elem['parentEntity'].get('title', '') else ""
		if elem.get('publishDate', '') and str(elem['publishDate'].get('dateString'))[:4].isdigit() and str(elem['publishDate'].get('dateString'))[:4] not in ['0', '1970']:
			LOCALstart = get_Local_DT(elem['publishDate']['dateString'][:19])
			startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
		if startTIMES: Note_1 = translation(30623).format(str(startTIMES))
		if elem.get('count', ''): Note_2 = translation(30624).format(str(elem['count']))
		if elem.get('images', '') and len(elem['images']) > 0:
			# https://images.paramount.tech/uri/mgid:arc:imageassetref:mtv.de:6bda844a-3c16-4d1c-8f21-cd06e73e88d0?quality=0.7&gen=ntrn&legacyStatusCode=true
			resolution = max(elem['images'], key=lambda y: int(y.get('width')))
			photo = f"{resolution.get('url').replace('https://mtv.mtvnimages.com/', 'https://images.paramount.tech/').split('?quality=')[0]}?quality=0.7&gen=ntrn&legacyStatusCode=true" if \
				resolution.get('url').endswith('gen=ntrn') else resolution.get('url').replace('https://mtv.mtvnimages.com/', 'https://images.paramount.tech/')
		if elem.get('links', '') and elem['links'].get('showvideo', ''):
			LINK = f"{elem['links']['showvideo']}&orderBy=originalPublishDate&order=descending"
		plot = origSERIE+Note_1+Note_2
		debug_MS(f"(navigator.listPlaylists[2]) ##### NAME = {name} || URL = {str(LINK)} #####")
		debug_MS(f"(navigator.listPlaylists[2]) ##### TYPE = {entityType.upper()} || THUMB = {photo} #####")
		debug_MS("---------------------------------------------")
		if LINK is None:
			continue
		FOUND += 1
		COMBI_PLAYLIST.append([name, photo, LINK, plot])
	if COMBI_PLAYLIST and FOUND > 0:
		for name, photo, LINK, plot in COMBI_PLAYLIST:
			addDir(name, photo, {'mode': 'listEpisodes', 'url': LINK, 'extras': 'SNAKE', 'transmit': name}, plot)
		if DATA.get('metadata', '') and DATA['metadata'].get('pagination', '') and DATA['metadata']['pagination'].get('hasMore', '') is True:
			debug_MS(f"(navigator.listPlaylists[3]) NEXTPAGES ### Now show NextPage ... No.{str(int(PAGE)+1)} ... ###")
			addDir(translation(30625).format(int(PAGE)+1), f"{artpic}nextpage.png", {'mode': 'listPlaylists', 'url': url, 'page': int(PAGE)+1})
	else:
		debug_MS("(navigator.listPlaylists) ##### Keine COMBI_PLAYLIST-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524).format('Einträge'), translation(30525).format('PLAYLISTS'), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, EXTRA, TRANS, PAGE, TYPE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL : {url} ### EXTRA : {EXTRA} ### TRANS : {TRANS} ### PAGE : {PAGE} ### TYPE : {TYPE} ###")
	SEND = {}
	COMBI_EPISODE, SEND['videos'] = ([] for _ in range(2))
	PLT = cleanPlaylist() if TYPE == 'play' else None
	DATA = makeREQUEST(f"{url}&pageNumber={PAGE}&pageSize=30")
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listEpisodes[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	for item in DATA['data']['items']:
		plus_SUFFIX, Note_1, Note_2 = ("" for _ in range(3))
		artist, season, episode, TABLE, startTIMES, begins, duration, mpaa, genre, year = (None for _ in range(10))
		genreLIST = []
		episID = item.get('mgid', '00')
		shortId = item.get('shortId', '00')
		title, photo = cleaning(item['title']), icon
		seriesname = cleaning(item['parentEntity']['title']) if item.get('parentEntity', '') and item['parentEntity'].get('title', '') and EXTRA not in ['newMU', 'MUSIC', 'SNAKE'] else ""
		serieOK = seriesname+'[CR]' if seriesname !="" else ""
		matchSE = re.search('(season|Season|Se)\ (\d+)', item.get('subTitle', '')) # "subTitle": "Season 3, Ep 4"
		if matchSE: season = matchSE.group(2).zfill(2)
		matchEP = re.search('(episode|Episode|Ep|folge|Folge)\ (\d+)', item.get('subTitle', '')) # "subTitle": "Season 3, Ep 4"
		if matchEP: episode = matchEP.group(2).zfill(2)
		if item.get('ribbon', '') and (item['ribbon'].get('newEpisode', '') is True or item['ribbon'].get('newContent', '') is True):
			plus_SUFFIX = translation(30620)
		if EXTRA == 'newEP':
			title = f"{title} - {seriesname}" if seriesname !="" else title
		if EXTRA in ['newMU', 'MUSIC', 'SNAKE']:
			if item.get('personContexts', '') and len(item['personContexts']) > 0:
				ENTRY, TABLE = 'title', 'personContexts'
			if TABLE is None and item.get('contributors', '') and len(item['contributors']) > 0:
				ENTRY, TABLE = 'mame', 'contributors'
			if TABLE:
				composers = [cleaning(at.get(ENTRY, '')) for at in item.get(TABLE, [])]
				artist = composers[0]
				for ii, value in enumerate(composers):
					if 1 <= ii <= 2: artist = f"{artist}, {value}" ### Listenauswahl der Composers liegt zwischen Nummer:1-2 ###
			name = f"{title} - {artist}{plus_SUFFIX}" if artist and len(artist) > 0 else title+plus_SUFFIX
			serieOK = f"Artist:  [B]{artist}[/B][CR]Song:  [B]{title}[/B]" if artist and len(artist) > 0 else f"Title:  [B]{title}[/B]"
		else:
			name = translation(30626).format(season, episode, title)+plus_SUFFIX if str(season).isdigit() and str(episode).isdigit() else title+plus_SUFFIX
		entityType = item.get('entityType', 'Unknown')
		if item.get('publishDate', '') and str(item['publishDate'].get('dateString'))[:4].isdigit() and str(item['publishDate'].get('dateString'))[:4] not in ['0', '1970']:
			LOCALstart = get_Local_DT(item['publishDate']['dateString'][:19])
			startTIMES = LOCALstart.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('.', '•', ':')
			begins = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
			if KODI_ov20:
				begins = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
		if startTIMES:
			Note_1 = f"[CR]Date:  [B][COLOR deepskyblue]{str(startTIMES)[:10]}[/COLOR][/B]" if EXTRA in ['newMU', 'MUSIC', 'SNAKE'] else translation(30623).format(str(startTIMES))
		Note_2 = get_Description(item) if EXTRA not in ['newMU', 'MUSIC', 'SNAKE'] else ""
		if item.get('images', '') and len(item['images']) > 0:
			# https://images.paramount.tech/uri/mgid:arc:imageassetref:mtv.de:6bda844a-3c16-4d1c-8f21-cd06e73e88d0?quality=0.7&gen=ntrn&legacyStatusCode=true&format=webp&width=1600
			resolution = max(item['images'], key=lambda y: int(y.get('width')))
			photo = f"{resolution.get('url').replace('https://mtv.mtvnimages.com/', 'https://images.paramount.tech/').split('?quality=')[0]}?quality=0.7&gen=ntrn&legacyStatusCode=true&format=webp&width=1600" if \
				resolution.get('url').endswith('gen=ntrn') else resolution.get('url').replace('https://mtv.mtvnimages.com/', 'https://images.paramount.tech/')
		if item.get('duration', '') and str(item['duration'].get('milliseconds')).isdigit():
			duration = int(item['duration']['milliseconds']) // 1000
			uvz = build_mass({'mode': 'playCODE', 'IDENTiTY': shortId})
		else: continue
		if item.get('contentRating', '') and str(item.get('contentRating', {})[0].get('code', '')).isdigit():
			mpaa = translation(30627).format(str(item['contentRating'][0]['code'])) if str(item['contentRating'][0]['code']) != '0' else translation(30628)
		if item.get('genres', '') and len(item['genres']) > 0:
			genreLIST = [cleaning(gen) for gen in item.get('genres', {})]
			if genreLIST: genre = ' / '.join(sorted(genreLIST))
		if str(item.get('productionYear'))[:4].isdigit() and str(item.get('productionYear'))[:4] not in ['0', '1970']:
			year = str(item['productionYear'])[:4]
		plot = serieOK+Note_1+Note_2
		debug_MS(f"(navigator.listEpisodes[2]) ##### NAME : {name} || IDD : {episID} || GENRE : {str(genre)} #####")
		debug_MS(f"(navigator.listEpisodes[2]) ##### THUMB : {photo} || SEASON : {str(season)} || EPISODE : {str(episode)} #####")
		debug_MS("---------------------------------------------")
		COMBI_EPISODE.append([uvz, name, seriesname, season, episode, duration, shortId, episID, photo, plot, genre, mpaa, year, begins])
	if TYPE == 'browse':
		if COMBI_EPISODE:
			for uvz, name, seriesname, season, episode, duration, shortId, episID, photo, plot, genre, mpaa, year, begins in COMBI_EPISODE:
				for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
				if plot in ['', 'None', None]: plot = "..."
				cineType = 'episode' if str(episode).isdigit() else 'movie'
				LSM = xbmcgui.ListItem(name)
				if KODI_ov20:
					vinfo = LSM.getVideoInfoTag()
					if str(season).isdigit(): vinfo.setSeason(int(season))
					if str(episode).isdigit(): vinfo.setEpisode(int(episode))
					vinfo.setTvShowTitle(seriesname)
					vinfo.setTitle(name)
					vinfo.setPlot(plot)
					if str(duration).isdigit(): vinfo.setDuration(int(duration))
					if begins: LSM.setDateTime(begins)
					if year: vinfo.setYear(int(year))
					if genre and len(genre) > 4: vinfo.setGenres([genre])
					vinfo.setStudios(['MTV'])
					vinfo.setMpaa(mpaa)
					vinfo.setMediaType(cineType)
				else:
					vinfo = {}
					if str(season).isdigit(): vinfo['Season'] = season
					if str(episode).isdigit(): vinfo['Episode'] = episode
					vinfo['Tvshowtitle'] = seriesname
					vinfo['Title'] = name
					vinfo['Plot'] = plot
					if str(duration).isdigit(): vinfo['Duration'] = duration
					if begins: vinfo['Date'] = begins
					if year: vinfo['Year'] = year
					if genre and len(genre) > 4: vinfo['Genre'] = genre
					vinfo['Studio'] = 'MTV'
					vinfo['Mpaa'] = mpaa
					vinfo['Mediatype'] = cineType
					LSM.setInfo(type='Video', infoLabels=vinfo)
				LSM.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
				if photo and useThumbAsFanart and photo != icon and not artpic in photo:
					LSM.setArt({'fanart': photo})
				LSM.setProperty('IsPlayable', 'true')
				LSM.setContentLookup(False)
				LSM.addContextMenuItems([(translation(30654), 'Action(Queue)')])
				xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LSM)
				SEND['videos'].append({'filter': shortId, 'name': name, 'extras': 'browse', 'transmit': episID, 'shortTITLE': name})
			with open(WORKFILE, 'w') as ground:
				json.dump(SEND, ground, indent=4, sort_keys=True)
			if EXTRA not in ['newEP', 'newMU'] and DATA.get('metadata', '') and DATA['metadata'].get('pagination', '') and DATA['metadata']['pagination'].get('hasMore', '') is True:
				debug_MS(f"(navigator.listEpisodes[3]) NEXTPAGES ### Now show NextPage ... No.{str(int(PAGE)+1)} ... ###")
				addDir(translation(30625).format(int(PAGE)+1), f"{artpic}nextpage.png", {'mode': 'listEpisodes', 'url': url, 'extras': EXTRA, 'transmit': TRANS, 'page': int(PAGE)+1})
		else:
			debug_MS("(navigator.listEpisodes) ##### Keine COMBI_EPISODE-List - Kein Eintrag gefunden #####")
			return dialog.notification(translation(30524).format('Einträge'), translation(30525).format(TRANS), icon, 8000)
		xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)
	elif TYPE == 'play' and COMBI_EPISODE:
		random.shuffle(COMBI_EPISODE)
		for uvz, name, seriesname, season, episode, duration, shortId, episID, photo, plot, genre, mpaa, year, begins in COMBI_EPISODE:
			listitem = xbmcgui.ListItem(name)
			listitem.setArt({'icon': icon, 'thumb': photo, 'poster': photo})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(uvz, listitem)
			SEND['videos'].append({'filter': shortId, 'name': name, 'extras': 'NOTICE', 'transmit': episID, 'shortTITLE': name})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
		xbmc.Player().play(PLT)

def listCharts():
	debug_MS("(navigator.listCharts) ------------------------------------------------ START = listCharts -----------------------------------------------")
	config = traversing.get_config()
	for n in config['picks']:
		addDir(n['title'], n['img'].format(chapic), {'mode': 'chartVideos', 'url': config['API_CHARTS'].format(n['id']), 'extras': 'CHART', 'transmit': n['title']}, background=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def chartVideos(url, TRANS, TYPE):
	debug_MS("(navigator.chartVideos) ------------------------------------------------ START = chartVideos -----------------------------------------------")
	debug_MS(f"(navigator.chartVideos) ### URL : {url} ### TRANS : {TRANS} ### TYPE : {TYPE} ###")
	SEND = {}
	COMBI_VID, COMBI_ALL, SEND['videos'] = ([] for _ in range(3))
	PLT = cleanPlaylist() if TYPE == 'play' else None
	content = getUrl(url, method='LOAD', REF=BASE_URL)
	#<div class="cmn-act">11</div><div class="cmn-change"><div id="cmn-arrow_down"></div></div><div class="cmn-old">9</div><div class="cmn-title"> Sweater Weather</div><div class="cmn-artist"> The Neighbourhood</div><div class="cmn-image"><img class="cmn-image" src="https://mtv.mtvnimages.com/uri/mgid:arc:content:mtv.de:afe26f40-b5d0-46ef-9058-1a6519de2484" /></div>
	#<div class="cmn-act">15</div><div class="cmn-change"><div id="cmn-arrow_up"></div></div><div class="cmn-old">17</div><div class="cmn-title"> My Heart Goes (La Di Da)</div><div class="cmn-artist"> Becky Hill feat. Topic</div><div class="cmn-image"> <a href="https://www.mtv.de/musikvideos/1c8w3b/my-heart-goes-la-di-da" target="_blank"><img class="cmn-image" src="https://mtv.mtvnimages.com/uri/mgid:arc:content:mtv.de:22d27161-3022-11ec-9b1b-0e40cf2fc285" /></a> </div>
	#<div class="cmn-act">12</div><div class="cmn-change-new"></div><div class="cmn-title"> Undeniable</div><div class="cmn-artist"> Kygo feat. X Ambassadors</div><div class="cmn-image"> <a href="https://www.mtv.de/musikvideos/9z01wv/undeniable" target="_blank"><img class="cmn-image" src="https://mtv.mtvnimages.com/uri/mgid:arc:content:mtv.de:05f35ccf-2ce3-11ec-9b1b-0e40cf2fc285" /></a> </div>
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.chartVideos[1]) XXXXX CONTENT-01 : {str(content)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	spl = content.split('class="charts-marslnet"')
	for i in range(1, len(spl), 1):
		entry = spl[i]
		debug_MS(f"(navigator.chartVideos[2]) ##### ENTRY-02 = {str(entry)} #####")
		song = re.compile(r'="cmn-title">(.*?)</div>', re.S).findall(entry)[0]
		song = cleaning(song)
		artist = re.compile(r'="cmn-artist">(.*?)</div>', re.S).findall(entry)[0]
		artist = cleaning(artist)
		Chartnow = re.compile(r'class="cmn-act">(.*?)</div>', re.S).findall(entry)[0]
		Chartold = re.compile(r'class="cmn-old">(.*?)</div>', re.S).findall(entry)
		NewRee = re.compile(r'class="cmn-change-(.*?)">', re.S).findall(entry)
		EvUpDo = re.compile(r'<div id="(.*?)">', re.S).findall(entry)
		oldpos, plus_SUFFIX = ("" for _ in range(2))
		if NewRee:
			oldpos = '[COLOR deepskyblue]  ( NEU )[/COLOR]' if NewRee[0] == 'new' else '[COLOR deepskyblue]  ( REE )[/COLOR]'
		elif Chartold and EvUpDo:
			if '_even' in EvUpDo[0]: oldpos = "  ( - )"
			elif '_up' in EvUpDo[0]: oldpos = translation(30629).format(str(int(Chartold[0]) -  int(Chartnow)))
			elif '_down' in EvUpDo[0]: oldpos = translation(30630).format(str(int(Chartnow) - int(Chartold[0])))
		img = re.compile(r'class="cmn-image" src="(https?://[^"]+)"', re.S).findall(entry)
		photo = f"{img[0].replace('https://mtv.mtvnimages.com/', 'https://images.paramount.tech/')}?quality=0.7&gen=ntrn&legacyStatusCode=true&format=webp&width=1600" if \
			img and not '?' in img[0] else img[0].replace('https://mtv.mtvnimages.com/', 'https://images.paramount.tech/') if img else icon
		video = re.compile(r'<a href="(https?://www.mtv.de/musikvideos/[^"]+)" target=', re.S).findall(entry)
		shortId = video[0].split('musikvideos/')[1].split('/')[0] if video else '00'
		if shortId != '00':
			name = translation(30631).format(str(Chartnow), song, artist+oldpos)
			uvz = build_mass({'mode': 'playCODE', 'IDENTiTY': shortId})
		elif shortId == '00' and showALL:
			name = translation(30632).format(str(Chartnow), song, artist+oldpos)
			plus_SUFFIX = '[CR][COLOR orangered]֎ No Video ֎[/COLOR]'
			uvz = build_mass({'mode': 'blankFUNC', 'IDENTiTY': shortId})
		else: continue
		plot = f"Artist:  [B]{artist}[/B][CR]Song:  [B]{song}[/B][CR]Rank:  [B]{Chartnow}{oldpos}{plus_SUFFIX}[/B]"
		debug_MS(f"(navigator.chartVideos[3]) ##### TITLE = {str(Chartnow)}. {song} - {artist} || shortId = {str(shortId)} || FOTO = {photo} #####")
		debug_MS("---------------------------------------------")
		if shortId != '00':
			COMBI_VID.append([uvz, song, artist, name, photo, plot, shortId, Chartnow, oldpos])
		COMBI_ALL.append([uvz, song, artist, name, photo, plot, shortId, Chartnow, oldpos])
	if TYPE == 'browse':
		if COMBI_ALL:
			for uvz, song, artist, name, photo, plot, shortId, Chartnow, oldpos in COMBI_ALL:
				LTM = xbmcgui.ListItem(name)
				if KODI_ov20:
					vinfo = LTM.getVideoInfoTag()
					vinfo.setTitle(name)
					vinfo.setPlot(plot)
					vinfo.setGenres(['Musicvideo'])
					vinfo.setStudios(['MTV'])
					vinfo.setMediaType('movie')
				else:
					vinfo = {}
					vinfo['Title'] = name
					vinfo['Plot'] = plot
					vinfo['Genre'] = 'Musicvideo'
					vinfo['Studio'] = 'MTV'
					vinfo['Mediatype'] = 'movie'
					LTM.setInfo(type='Video', infoLabels=vinfo)
				LTM.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
				if photo and useThumbAsFanart and photo != icon and not artpic in photo:
					LTM.setArt({'fanart': photo})
				if shortId != '00':
					LTM.setProperty('IsPlayable', 'true')
					LTM.setContentLookup(False)
					LTM.addContextMenuItems([(translation(30654), 'Action(Queue)')])
				xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LTM)
				SEND['videos'].append({'filter': shortId, 'name': name, 'extras': 'browse', 'transmit': 'tracking', 'shortTITLE': f"{song} - {artist}"})
			with open(WORKFILE, 'w') as ground:
				json.dump(SEND, ground, indent=4, sort_keys=True)
		else:
			debug_MS("(navigator.chartVideos) ##### Keine COMBI_CHARTVIDEOS-List - Kein Eintrag gefunden #####")
			return dialog.notification(translation(30524).format('Einträge'), translation(30525).format(TRANS), icon, 8000)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
	elif TYPE == 'play' and COMBI_VID:
		random.shuffle(COMBI_VID)
		for uvz, song, artist, name, photo, plot, shortId, Chartnow, oldpos in COMBI_VID:
			listitem = xbmcgui.ListItem(name)
			listitem.setArt({'icon': icon, 'thumb': photo, 'poster': photo})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(uvz, listitem)
			SEND['videos'].append({'filter': shortId, 'name': name, 'extras': 'NOTICE', 'transmit': 'tracking', 'shortTITLE': f"{song} - {artist}"})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
		xbmc.Player().play(PLT)

def MtvGetVideo(url, TRANS):
	config = traversing.get_config()
	if xbmcvfs.exists(tempSF) and os.path.isdir(tempSF):
		shutil.rmtree(tempSF, ignore_errors=True)
		xbmc.sleep(500)
	xbmcvfs.mkdirs(tempSF)
	file_Names, file_Streams = ([] for _ in range(2))
	subSOURCE, subFOUND = (False for _ in range(2))
	SECOND_URL = ""
	if TRANS == 'tracking':
		CODING = getUrl(config['SHORT_IDD'].format(url))
		if CODING.get('data', '') and CODING['data'].get('item', ''):
			TRANS = CODING['data']['item']['mgid']
			entityType = CODING['data']['item'].get('entityType', 'Unknown')
	# OFFIZIELL           = https://media.mtvnservices.com/pmt/e1/access/index.html?uri=mgid:arc:episode:mtv.intl:aaed37d0-98f6-11eb-8774-70df2f866ace&configtype=edge&ref=https://www.mtv.de/folgen/5k5mx0/catfish-verliebte-im-netz-nyhjee-cianna-staffel-8-ep-41
	# FUNKTIONIERT = https://media.mtvnservices.com/pmt/e1/access/index.html?uri=mgid:arc:episode:mtv.intl:aaed37d0-98f6-11eb-8774-70df2f866ace&configtype=edge&ref=https://www.mtv.de/
	DATA_ONE = getUrl(config['OLD_STREAM'].format(TRANS, BASE_URL), REF=BASE_URL)
	debug_MS("+++++++++++++++++++++++++")
	debug_MS(f"(navigator.MtvGetVideo[1]) XXXXX DATA_ONE : {str(DATA_ONE)} XXXXX")
	debug_MS("+++++++++++++++++++++++++")
	try: guid = DATA_ONE['feed']['items'][0]['guid']
	except: guid = DATA_ONE['uri']
	subNAME = fixPathSymbols(DATA_ONE['feed']['title']) if DATA_ONE.get('feed', '') and DATA_ONE['feed'].get('title', '') else 'TemporaryVideoSub'
	SECOND_URL = DATA_ONE['mediaGen'].replace('&device={device}', '').replace('{uri}', guid)
	# ORIGINAL = https://media-utils.mtvnservices.com/services/MediaGenerator/{uri}?arcStage=live&format=json&acceptMethods=hls&https=true&device={device}&isEpisode=true&ratingIds=b22fa3cb-b8a4-4f1c-9ccd-fdf435246ac1,f32ecc8f-7018-457a-893e-876ba039bb1c,4fca9d87-2212-4b48-8b4b-52a2adb6ca86&ratingAcc=default&accountOverride=intl.mtvi.com&ep=82ac4273
	# FERTIG     = https://media-utils.mtvnservices.com/services/MediaGenerator/mgid:arc:video:mtv.de:837234d4-7002-11e9-a442-0e40cf2fc285?arcStage=live&format=json&acceptMethods=hls&clang=de&https=true
	if 'player/html5' in SECOND_URL or not 'acceptMethods=hls' in SECOND_URL:
		SECOND_URL = DATA_ONE['feed']['items'][0]['group']['content'].replace('&device={device}', '')+'&format=json&acceptMethods=hls&tveprovider=null'
		# ERGEBNIS            = https://media-utils.mtvnservices.com/services/MediaGenerator/mgid:arc:musicvideo:mtv.intl:c188caed-fc02-11eb-9b1b-0e40cf2fc285?arcStage=live&accountOverride=intl.mtvi.com&billingSection=intl&device={device}&ep=82ac4273
		# FUNKTIONIERT = https://media-utils.mtvnservices.com/services/MediaGenerator/mgid:arc:musicvideo:mtv.intl:c188caed-fc02-11eb-9b1b-0e40cf2fc285?arcStage=live&accountOverride=intl.mtvi.com&billingSection=intl&ep=82ac4273&format=json&acceptMethods=hls&tveprovider=null
	DATA_TWO = getUrl(SECOND_URL, REF=BASE_URL)
	debug_MS("+++++++++++++++++++++++++")
	debug_MS(f"(navigator.MtvGetVideo[2]) XXXXX DATA_TWO : {str(DATA_TWO)} XXXXX")
	debug_MS("+++++++++++++++++++++++++")
	try:
		subENTRIES = DATA_TWO['package']['video']['item'][0]['transcript']
		for ii, elem in enumerate(subENTRIES, 1): # Nederlands, Deutsch (nl, de)
			if (elem.get('srclang') == langSHORT or langSHORT == 'aio') and elem.get('typographic', ''):
				subSOURCE = [vid.get('src', []) for vid in elem.get('typographic', {}) if vid.get('format') == 'vtt'][0]
				if elem.get('label', ''):
					file_Names.append(translation(30633).format(str(ii), str(elem['label'])))
					file_Streams.append(subSOURCE)
	except: pass
	if subSOURCE and enableSUBTITLE:
		siteResult = subSOURCE
		if langSHORT == 'aio' and file_Names:
			index = dialog.select(translation(30634), file_Names, preselect=0)
			siteResult = file_Streams[index] if index > -1 else None
		if siteResult:
			log(f"(navigator.MtvGetVideo[3]) SubtitleURL : {siteResult}")
			req = getUrl(siteResult, method='STREAM', stream=True)
			with open(os.path.join(tempSF, subNAME+'.srt'), 'wb') as saving:
				req.raw.decode_content = True
				shutil.copyfileobj(req.raw, saving)
			subFOUND = True
	try:
		videoURL = DATA_TWO['package']['video']['item'][0]['rendition'][0]['src']
	except:
		code = f"[B][COLOR red]{DATA_TWO['package']['video']['item'][0]['code'].replace('_', ' ').upper()}[/COLOR][/B]"
		text = f"[B]{DATA_TWO['package']['video']['item'][0]['text']}[B]"
		dialog.notification(code, text, icon, 8000)
		videoURL = False
		xbmc.sleep(5000)
	return (videoURL, subFOUND, subNAME)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### IDD : {IDD} ###")
	config = traversing.get_config()
	TRANS, DISPLAY, FINAL_URL, TEST_URL, subFOUND = (False for _ in range(5))
	SUB_NAME= 'Unknown'
	if xbmc.Player().isPlaying():
		xbmc.Player().stop()
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == IDD:
				name = elem['name']
				EXTRA = elem['extras']
				TRANS = elem['transmit']#.replace('mtv.intl:', 'mtv.de:')
				DISPLAY = elem['shortTITLE']
				debug_MS(f"(navigator.playCODE[1]) ### WORKFILE-Line : {str(elem)} ###")
				FINAL_URL, subFOUND, SUB_NAME = MtvGetVideo(IDD, TRANS)
	try:
		CODE_OLD = urlopen(FINAL_URL, timeout=8).getcode()
		if CODE_OLD in [200, 201, 202]: TEST_URL = True
		else: FINAL_URL = False
	except: FINAL_URL = False
	if FINAL_URL is False and TEST_URL is False and TRANS and DISPLAY:
		TRANS = TRANS.replace('mtv.intl:', 'mtv.de:') # Austauschen mit 'mtv.de:' sonst wird das Video nicht abgespielt !!!
		# OFFIZIELL           = https://topaz.viacomcbs.digital/topaz/api/mgid:arc:episode:mtv.de:725f607c-0df0-11ed-ad8e-0e40cf2fc285/mica.json?clientPlatform=desktop&ssus=a364455f-1ce6-4fb5-9db8-496f6f2001f1&browser=Chrome&device=Desktop&os=Windows+10
		# FUNKTIONIERT = https://topaz.viacomcbs.digital/topaz/api/mgid:arc:episode:mtv.de:725f607c-0df0-11ed-ad8e-0e40cf2fc285/mica.json?clientPlatform=desktop&browser=Chrome&device=Desktop
		DATA_TRES = getUrl(config['NEW_STREAM'].format(TRANS), REF=BASE_URL)
		debug_MS("+++++++++++++++++++++++++")
		debug_MS(f"(navigator.MtvGetVideo[3]) XXXXX DATA_TRES : {str(DATA_TRES)} XXXXX")
		debug_MS("+++++++++++++++++++++++++")
		if DATA_TRES.get('stitchedstream', '') and DATA_TRES['stitchedstream'].get('source', ''):
			FINAL_URL = DATA_TRES['stitchedstream']['source']
		#if DATA_TRE.get('thumbnails', '') and DATA_TRE['thumbnails'].get('webvtt', '') and DATA_TRE['thumbnails']['webvtt'].get('urltemplate', ''):
			#SUB_SOURCE = DATA_TRE['thumbnails']['webvtt']['urltemplate'].replace('thumbs-{size}.vtt', 'thumbs-320x180.vtt')
			'''>>> Leider nur *Webvtt - Untertitel* als Bild, nicht kompatibel mit KODI !!! <<<'''
			try:
				CODE_NEW = urlopen(FINAL_URL, timeout=8).getcode()
				if CODE_NEW in [200, 201, 202]: TEST_URL = True
				else: FINAL_URL = False
			except: FINAL_URL = False
	if FINAL_URL and TEST_URL:
		log(f"(navigator.playCODE) StreamURL : {FINAL_URL}")
		subFILE = os.path.join(tempSF, SUB_NAME+'.srt')
		LVM = xbmcgui.ListItem(path=FINAL_URL)
		if subFOUND is True and subFILE:
			debug_MS(f"(navigator.playCODE) ##### subFOUND = {str(subFOUND)} || subFILE = {subFILE} #####")
			subFILE = subFILE.split('|')
			LVM.setSubtitles(subFILE)
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "id":1, "method":"Player.SetSubtitle", "params":{"playerid":1, "subtitle":"on"}}')
			#xbmc.executeJSONRPC('{"jsonrpc":"2.0", "id":1, "method":"Player.SetSubtitle", "params":{"playerid":1, "subtitle":"off"}}')
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'm3u8' in FINAL_URL:
			LVM.setMimeType('application/vnd.apple.mpegurl')
			LVM.setProperty('inputstream', 'inputstream.adaptive')
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LVM.setProperty('inputstream.adaptive.manifest_type', 'hls')
			if KODI_ov20:
				LVM.setProperty('inputstream.adaptive.manifest_headers', f"User-Agent={get_userAgent()}")
			else: # DEPRECATED ON Kodi v20, please use 'inputstream.adaptive.manifest_headers' instead.
				LVM.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={get_userAgent()}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LVM)
		xbmc.sleep(1000)
		if enableINFOS and EXTRA == 'NOTICE': infoMessage(DISPLAY)
	else:
		failing(f"(navigator.playCODE) ##### Abspielen des Streams NICHT möglich #####\n ##### NAME : {DISPLAY} || IDD : {IDD} || TRANS : {TRANS} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *mtv.de* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('VIDEO'), translation(30529).format(DISPLAY), icon, 10000)

def playLIVE(url):
	debug_MS("(navigator.playLIVE) ------------------------------------------------ START = playLIVE -----------------------------------------------")
	log(f"(navigator.playLIVE) LiveURL : {url}")
	LZM = xbmcgui.ListItem(path=url, label=translation(30635))
	LZM.setMimeType('application/vnd.apple.mpegurl')
	if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
		LZM.setProperty('inputstream', 'inputstream.adaptive')
		if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			LZM.setProperty('inputstream.adaptive.manifest_type', 'hls')
			# THE "full" BEHAVIOUR PARAM HAS BEEN REMOVED ON Kodi v21 because now enabled by default.
			LZM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
	xbmc.Player().play(item=url, listitem=LZM)

def infoMessage(DISPLAY):
	counter = 0
	while not xbmc.Player().isPlaying():
		xbmc.sleep(200)
		if counter == 50:
			break
		counter += 1
	xbmc.sleep(int(infoDelay)*1000 - 2000)
	if xbmc.Player().isPlaying():
		xbmc.getInfoLabel('Player.Duration')
		xbmc.getInfoLabel('Player.Art(thumb)')
		xbmc.sleep(500)
		RUNTIME = xbmc.getInfoLabel('Player.Duration')
		PHOTO = xbmc.getInfoLabel('Player.Art(thumb)')
		xbmc.sleep(1000)
		dialog.notification(translation(30636), translation(30637).format(DISPLAY, RUNTIME), PHOTO, infoDuration*1000)

def addDir(name, image, params={}, plot=None, genre=None, cover=None, folder=True, background=False):
	u = build_mass(params)
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setGenres([genre]), vinfo.setStudios(['MTV'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': genre, 'Studio': 'MTV'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if cover:
		liz.setArt({'poster': cover})
	if image and useThumbAsFanart and image != icon and (not artpic in image or background is True):
		liz.setArt({'fanart': image})
	if params.get('extras') in ['newMU', 'MUSIC', 'SNAKE', 'CHART']:
		liz.addContextMenuItems([(translation(30655), 'RunPlugin({})'.format(build_mass({'mode': params.get('mode'), 'url': params.get('url'), 'extras': params.get('extras'),
			'transmit': params.get('transmit') if params.get('transmit') else 'special', 'page': params.get('page') if params.get('page') else '1', 'target': 'play'})))])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
