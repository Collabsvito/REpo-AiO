﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	config = traversing.get_config()
	addDir(translation(30601), icon, {'mode': 'listEpisodes', 'url': config['collect_Date'].format('episode'), 'extras': 'newEP', 'transmit': translation(30601).split('[/COLOR] ')[1]})
	addDir(translation(30602), icon, {'mode': 'listEpisodes', 'url': config['collect_Idd'].format(config['RELATED'], 'musicvideo'), 'extras': 'newMU', 'transmit': translation(30602).split('[/COLOR] ')[1]})
	addDir(translation(30603), icon, {'mode': 'listBroadcasts', 'url': config['collect_Title'].format('series')})
	addDir(translation(30604), icon, {'mode': 'listMusics'})
	addDir(translation(30605), icon, {'mode': 'listCharts'})
	addDir(translation(30606), icon, {'mode': 'listPlaylists', 'url': config['collect_Idd'].format(config['EXCLUDED'], 'videoplaylist')})
	addDir(translation(30607), artpic+'livestream.png', {'mode': 'playLIVE', 'url': config['live_M3U8']}, folder=False)
	addDir(translation(30608).format(str(cachePERIOD)), artpic+'remove.png', {'mode': 'clearCache'})
	if enableADJUSTMENT:
		addDir(translation(30609), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30610), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(url):
	debug_MS("(navigator.listBroadcasts) ------------------------------------------------ START = listBroadcasts -----------------------------------------------")
	pageNUMBER, FOUND = 1, 0
	while pageNUMBER < 4:
		DATA = makeREQUEST('{}&pageNumber={}&pageSize=30'.format(url, str(pageNUMBER)))
		debug_MS("++++++++++++++++++++++++")
		debug_MS("(navigator.listBroadcasts[1]) no.01 XXXXX CONTENT : {} XXXXX".format(str(DATA)))
		debug_MS("++++++++++++++++++++++++")
		pageNUMBER += 1 if len(DATA['data']['items']) > 0 else 3
		for item in DATA['data']['items']:
			plus_SUFFIX, genre = ("" for _ in range(2))
			SEAS = None
			genreLIST = []
			showID = item.get('mgid', '00')
			shortId = item.get('shortId', '00')
			title = (cleaning(item.get('title')) or cleaning(item.get('shortTitle')))
			if item.get('ribbon', '') and (item['ribbon'].get('newSeries', '') is True or item['ribbon'].get('newSeason', '') is True or item['ribbon'].get('newEpisode', '') is True):
				plus_SUFFIX = translation(30620)
			name = title+plus_SUFFIX
			plot = get_Description(item)
			entityType = item.get('entityType', 'Unknown')
			photo = icon
			if item.get('images', ''):
				resolution = max(item['images'], key=lambda x: int(x.get('width')))
				photo = resolution.get('url').replace('https://images.paramount.tech/', 'https://mtv.mtvnimages.com/') # https://mtv.mtvnimages.com/ oder https://playplex.mtvnimages.com/
			if item.get('genres', ''):
				genreLIST = [cleaning(gen) for gen in item.get('genres', '')]
				if genreLIST: genre = ' / '.join(sorted(genreLIST))
			if item.get('links', '') and item['links'].get('season', ''):
				SEAS = item['links']['season']+'&orderBy=seasonNumber&order=ascending'
			debug_MS("(navigator.listBroadcasts[2]) no.02 ##### NAME = {} || URL = {} #####".format(str(name), str(SEAS)))
			debug_MS("(navigator.listBroadcasts[2]) no.02 ##### TYPE = {} || THUMB = {} #####".format(entityType, photo))
			if SEAS is None:
				continue
			FOUND += 1
			addDir(name, photo, {'mode': 'listSeasons', 'url': SEAS, 'extras': photo, 'transmit': title}, plot, genre)
	if FOUND == 0:
		debug_MS("(navigator.listBroadcasts) ##### Keine BROADCASTS-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524).format('Einträge'), translation(30525).format('SHOWS'), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(url, THUMB, SERIE):
	debug_MS("(navigator.listSeasons) ------------------------------------------------ START = listSeasons -----------------------------------------------")
	debug_MS("(navigator.listSeasons) ### URL : {} ### THUMB : {} ### SERIE : {} ###".format(url, THUMB, SERIE))
	COMBI_SEASON = []
	FOUND = 0
	DATA = makeREQUEST(url+'&pageNumber=1&pageSize=40')
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listSeasons[1]) no.01 XXXXX CONTENT : {} XXXXX".format(str(DATA)))
	debug_MS("++++++++++++++++++++++++")
	for elem in DATA['data']['items']:
		EPIS = None
		seasID = elem.get('mgid', '00')
		shortId = elem.get('shortId', '00')
		plot = get_Description(elem)
		entityType = elem.get('entityType', 'Unknown')
		name = translation(30621).format(str(elem['seasonNumber'])) if elem.get('seasonNumber', '') else translation(30622)
		if elem.get('links', '') and elem['links'].get('episode', ''): # &orderBy=episodeAiringOrder&order=ascending&
			EPIS = elem['links']['episode']+'&orderBy=episodeAiringOrder&order=ascending'
		debug_MS("(navigator.listSeasons[2]) no.02 ##### NAME = {} || URL = {} #####".format(str(name), str(EPIS)))
		debug_MS("(navigator.listSeasons[2]) no.02 ##### TYPE = {} || THUMB = {} #####".format(entityType, THUMB))
		if EPIS is None:
			continue
		FOUND += 1
		COMBI_SEASON.append([name, THUMB, SERIE, EPIS, plot])
	if COMBI_SEASON and FOUND == 1:
		debug_MS("(navigator.listSeasons) ----- Only one Season FOUND - goto = listEpisodes -----")
		for name, THUMB, SERIE, EPIS, plot in COMBI_SEASON:
			return listEpisodes(EPIS, extras, SERIE+' - '+name, page, target)
	elif COMBI_SEASON and FOUND > 1:
		for name, THUMB, SERIE, EPIS, plot in COMBI_SEASON:
			addDir(name, THUMB, {'mode': 'listEpisodes', 'url': EPIS, 'transmit': SERIE+' - '+name}, plot)
	else:
		debug_MS("(navigator.listSeasons) ##### Keine COMBI_SEASON-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30526), translation(30527).format(SERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listMusics():
	debug_MS("(navigator.listMusics) ------------------------------------------------ START = listMusics -----------------------------------------------")
	config = traversing.get_config()
	addDir(translation(30701), icon, {'mode': 'listEpisodes', 'url': config['collect_Idd'].format(config['RELATED'], 'musicvideo'), 'extras': 'MUSIC', 'transmit': translation(30701)})
	for n in config['music']:
		addDir(n['title'], icon, {'mode': 'listEpisodes', 'url': config['collect_Idd'].format(n['id'], 'musicvideo'), 'extras': 'MUSIC', 'transmit': n['title']})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPlaylists(url, PAGE):
	debug_MS("(navigator.listPlaylists) ------------------------------------------------ START = listPlaylists -----------------------------------------------")
	debug_MS("(navigator.listPlaylists) ### URL : {} ### PAGE : {} ###".format(url, PAGE))
	COMBI_PLAYLIST = []
	FOUND = 0
	DATA = makeREQUEST('{}&pageNumber={}&pageSize=30'.format(url, str(PAGE)))
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listPlaylists[1]) no.01 XXXXX CONTENT : {} XXXXX".format(str(DATA)))
	debug_MS("++++++++++++++++++++++++")
	for elem in DATA['data']['items']:
		Note_1, Note_2 = ("" for _ in range(2))
		startTIMES, LINK = (None for _ in range(2))
		playID = elem.get('mgid', '00')
		shortId = elem.get('shortId', '00')
		name = cleaning(elem.get('title', ''))
		entityType = elem.get('entityType', 'Unknown')
		origSERIE = cleaning(elem['parentEntity']['title'])+'[CR]' if elem.get('parentEntity', '') and elem['parentEntity'].get('title', '') else ""
		if elem.get('publishDate', '') and str(elem['publishDate'].get('dateString'))[:4].isdigit() and str(elem['publishDate'].get('dateString'))[:4] not in ['0', '1970']:
			LOCALstart = get_Local_DT(elem['publishDate']['dateString'][:19])
			startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
		if startTIMES: Note_1 = translation(30623).format(str(startTIMES))
		if elem.get('count', ''): Note_2 = translation(30624).format(str(elem['count']))
		photo = icon
		if elem.get('images', ''):
			resolution = max(elem['images'], key=lambda x: int(x.get('width')))
			photo = resolution.get('url').replace('https://images.paramount.tech/', 'https://mtv.mtvnimages.com/') # https://mtv.mtvnimages.com/ oder https://playplex.mtvnimages.com/
		if elem.get('links', '') and elem['links'].get('video', ''):
			LINK = elem['links']['video']
		plot = origSERIE+Note_1+Note_2
		debug_MS("(navigator.listPlaylists[2]) no.02 ##### NAME = {} || URL = {} #####".format(str(name), str(LINK)))
		debug_MS("(navigator.listPlaylists[2]) no.02 ##### TYPE = {} || THUMB = {} #####".format(entityType, photo))
		if LINK is None:
			continue
		FOUND += 1
		COMBI_PLAYLIST.append([name, photo, LINK, plot])
	if COMBI_PLAYLIST and FOUND > 0:
		for name, photo, LINK, plot in COMBI_PLAYLIST:
			addDir(name, photo, {'mode': 'listEpisodes', 'url': LINK, 'extras': 'SNAKE', 'transmit': name}, plot)
		if DATA.get('metadata', '') and DATA['metadata'].get('pagination', '') and DATA['metadata']['pagination'].get('hasMore', '') is True:
			debug_MS("(navigator.listPlaylists) PAGES ### Now show NextPage ... No.{} ... ###".format(str(int(PAGE)+1)))
			addDir(translation(30625).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listPlaylists', 'url': url, 'page': int(PAGE)+1})
	else:
		debug_MS("(navigator.listPlaylists) ##### Keine COMBI_PLAYLIST-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524).format('Einträge'), translation(30525).format('PLAYLISTS'), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, EXTRA, TRANS, PAGE, TYPE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### URL : {} ### EXTRA : {} ### TRANS : {} ### PAGE : {} ### TYPE : {} ###".format(url, EXTRA, TRANS, PAGE, TYPE))
	SEND = {}
	COMBI_EPISODE, SEND['videos'] = ([] for _ in range(2))
	PLT = cleanPlaylist() if TYPE == 'play' else None
	DATA = makeREQUEST('{}&pageNumber={}&pageSize=30'.format(url, str(PAGE)))
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listEpisodes[1]) no.01 XXXXX CONTENT : {} XXXXX".format(str(DATA)))
	debug_MS("++++++++++++++++++++++++")
	for item in DATA['data']['items']:
		plus_SUFFIX, Note_1, Note_2 = ("" for _ in range(3))
		artist, season, episode, TABLE, startTIMES, begins, duration, mpaa, genre, year = (None for _ in range(10))
		genreLIST = []
		episID = item.get('mgid', '00')
		shortId = item.get('shortId', '00')
		title = cleaning(item.get('title', ''))
		seriesname = cleaning(item['parentEntity']['title']) if item.get('parentEntity', '') and item['parentEntity'].get('title', '') and EXTRA not in ['newMU', 'MUSIC', 'SNAKE'] else ""
		serieOK = seriesname+'[CR]' if seriesname !="" else ""
		matchSE = re.search('(season|Season|Se)\ (\d+)', item.get('subTitle', '')) # "subTitle": "Season 3, Ep 4"
		if matchSE: season = matchSE.group(2).zfill(2)
		matchEP = re.search('(episode|Episode|Ep|folge|Folge)\ (\d+)', item.get('subTitle', '')) # "subTitle": "Season 3, Ep 4"
		if matchEP: episode = matchEP.group(2).zfill(2)
		if item.get('ribbon', '') and (item['ribbon'].get('newEpisode', '') is True or item['ribbon'].get('newContent', '') is True):
			plus_SUFFIX = translation(30620)
		if EXTRA == 'newEP':
			title = title+' - '+seriesname if seriesname !="" else title
		if EXTRA in ['newMU', 'MUSIC', 'SNAKE']:
			if item.get('personContexts', '') and len(item['personContexts']) > 0:
				ENTRY, TABLE = 'title', 'personContexts'
			if TABLE is None and item.get('contributors', '') and len(item['contributors']) > 0:
				ENTRY, TABLE = 'mame', 'contributors'
			if TABLE:
				composers = [cleaning(at.get(ENTRY, '')) for at in item.get(TABLE, [])]
				artist = composers[0]
				for ii, value in enumerate(composers):
					if 1 <= ii <= 2: artist = artist + ', ' + value ### Listenauswahl der Composers liegt zwischen Nummer:1-2 ###
			name = title+' - '+artist+plus_SUFFIX if artist and len(artist) > 0 else title+plus_SUFFIX
			serieOK = 'Artist:  '+artist+'[CR]'+'Song:  '+title if artist and len(artist) > 0 else 'Title:  '+title
		else:
			name = translation(30626).format(season, episode, title)+plus_SUFFIX if str(season).isdigit() and str(episode).isdigit() else title+plus_SUFFIX
		entityType = item.get('entityType', 'Unknown')
		if item.get('publishDate', '') and str(item['publishDate'].get('dateString'))[:4].isdigit() and str(item['publishDate'].get('dateString'))[:4] not in ['0', '1970']:
			LOCALstart = get_Local_DT(item['publishDate']['dateString'][:19])
			startTIMES = LOCALstart.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('.', '•', ':')
			begins = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
			if KODI_ov20:
				begins = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
		if startTIMES: 
			Note_1 = '[CR]Date:  [COLOR deepskyblue]'+str(startTIMES)[:10]+'[/COLOR]' if EXTRA in ['newMU', 'MUSIC', 'SNAKE'] else translation(30623).format(str(startTIMES))
		Note_2 = get_Description(item) if EXTRA not in ['newMU', 'MUSIC', 'SNAKE'] else ""
		photo = icon
		if item.get('images', ''):
			resolution = max(item['images'], key=lambda x: int(x.get('width')))
			photo = resolution.get('url').replace('https://images.paramount.tech/', 'https://mtv.mtvnimages.com/') # https://mtv.mtvnimages.com/ oder https://playplex.mtvnimages.com/
		if item.get('duration', '') and str(item['duration'].get('milliseconds')).isdigit():
			duration = int(item['duration']['milliseconds']) // 1000
			uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playCODE', 'IDENTiTY': shortId}))
		else: continue
		if item.get('contentRating', '') and str(item.get('contentRating', {})[0].get('code', '')).isdigit():
			mpaa = translation(30627).format(str(item['contentRating'][0]['code'])) if str(item['contentRating'][0]['code']) != '0' else translation(30628)
		if item.get('genres', ''):
			genreLIST = [cleaning(gen) for gen in item.get('genres', '')]
			if genreLIST: genre = ' / '.join(sorted(genreLIST))
		if str(item.get('productionYear'))[:4].isdigit() and str(item.get('productionYear'))[:4] not in ['0', '1970']:
			year = str(item['productionYear'])[:4]
		plot = serieOK+Note_1+Note_2
		debug_MS("(navigator.listEpisodes[2]) no.02 ##### NAME : {} || IDD : {} || GENRE : {} #####".format(str(name), episID, str(genre)))
		debug_MS("(navigator.listEpisodes[2]) no.02 ##### THUMB : {} || SEASON : {} || EPISODE : {} #####".format(photo, str(season), str(episode)))
		COMBI_EPISODE.append([uvz, name, seriesname, season, episode, duration, shortId, episID, photo, plot, genre, mpaa, year, begins])
	if TYPE == 'browse':
		if COMBI_EPISODE:
			for uvz, name, seriesname, season, episode, duration, shortId, episID, photo, plot, genre, mpaa, year, begins in COMBI_EPISODE:
				for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
				if plot in ['', 'None', None]: plot = "..."
				cineType = 'episode' if str(episode).isdigit() else 'movie'
				LSM = xbmcgui.ListItem(name)
				if KODI_ov20:
					vinfo = LSM.getVideoInfoTag()
					if str(season).isdigit(): vinfo.setSeason(int(season))
					if str(episode).isdigit(): vinfo.setEpisode(int(episode))
					vinfo.setTvShowTitle(seriesname)
					vinfo.setTitle(name)
					vinfo.setPlot(plot)
					if str(duration).isdigit(): vinfo.setDuration(int(duration))
					if begins: LSM.setDateTime(begins)
					if year: vinfo.setYear(int(year))
					if genre and len(genre) > 4: vinfo.setGenres([genre])
					vinfo.setStudios(['MTV'])
					vinfo.setMpaa(mpaa)
					vinfo.setMediaType(cineType)
				else:
					vinfo = {}
					if str(season).isdigit(): vinfo['Season'] = season
					if str(episode).isdigit(): vinfo['Episode'] = episode
					vinfo['Tvshowtitle'] = seriesname
					vinfo['Title'] = name
					vinfo['Plot'] = plot
					if str(duration).isdigit(): vinfo['Duration'] = duration
					if begins: vinfo['Date'] = begins
					if year: vinfo['Year'] = year
					if genre and len(genre) > 4: vinfo['Genre'] = genre
					vinfo['Studio'] = 'MTV'
					vinfo['Mpaa'] = mpaa
					vinfo['Mediatype'] = cineType
					LSM.setInfo(type='Video', infoLabels=vinfo)
				LSM.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
				if photo and useThumbAsFanart and photo != icon and not artpic in photo:
					LSM.setArt({'fanart': photo})
				LSM.setProperty('IsPlayable', 'true')
				LSM.setContentLookup(False)
				LSM.addContextMenuItems([(translation(30654), 'Action(Queue)')])
				xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LSM)
				SEND['videos'].append({'filter': shortId, 'name': name, 'extras': 'browse', 'transmit': episID, 'shortTITLE': name})
			with open(WORKFILE, 'w') as ground:
				json.dump(SEND, ground, indent=4, sort_keys=True)
			if EXTRA not in ['newEP', 'newMU'] and DATA.get('metadata', '') and DATA['metadata'].get('pagination', '') and DATA['metadata']['pagination'].get('hasMore', '') is True:
				debug_MS("(navigator.listEpisodes) PAGES ### Now show NextPage ... No.{} ... ###".format(str(int(PAGE)+1)))
				addDir(translation(30625).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listEpisodes', 'url': url, 'extras': EXTRA, 'transmit': TRANS, 'page': int(PAGE)+1})
		else:
			debug_MS("(navigator.listEpisodes) ##### Keine COMBI_EPISODE-List - Kein Eintrag gefunden #####")
			return dialog.notification(translation(30524).format('Einträge'), translation(30525).format(TRANS), icon, 8000)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
	elif TYPE == 'play' and COMBI_EPISODE:
		random.shuffle(COMBI_EPISODE)
		for uvz, name, seriesname, season, episode, duration, shortId, episID, photo, plot, genre, mpaa, year, begins in COMBI_EPISODE:
			listitem = xbmcgui.ListItem(name)
			listitem.setArt({'icon': icon, 'thumb': photo, 'poster': photo})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(uvz, listitem)
			SEND['videos'].append({'filter': shortId, 'name': name, 'extras': 'NOTICE', 'transmit': episID, 'shortTITLE': name})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
		xbmc.Player().play(PLT)

def listCharts():
	debug_MS("(navigator.listCharts) ------------------------------------------------ START = listCharts -----------------------------------------------")
	config = traversing.get_config()
	for n in config['picks']:
		addDir(n['title'], n['img'].format(chapic), {'mode': 'chartVideos', 'url': config['chart_API'].format(n['id']), 'extras': 'CHART', 'transmit': n['title']}, background=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def chartVideos(url, TRANS, TYPE):
	debug_MS("(navigator.chartVideos) ------------------------------------------------ START = chartVideos -----------------------------------------------")
	debug_MS("(navigator.chartVideos) ### URL : {} ### TRANS : {} ### TYPE : {} ###".format(url, TRANS, TYPE))
	SEND = {}
	COMBI_VID, COMBI_ALL, SEND['videos'] = ([] for _ in range(3))
	PLT = cleanPlaylist() if TYPE == 'play' else None
	content = getUrl(url, method='LOAD', REF=BASE_URL)
	#<div class="cmn-act">11</div><div class="cmn-change"><div id="cmn-arrow_down"></div></div><div class="cmn-old">9</div><div class="cmn-title"> Sweater Weather</div><div class="cmn-artist"> The Neighbourhood</div><div class="cmn-image"><img class="cmn-image" src="https://mtv.mtvnimages.com/uri/mgid:arc:content:mtv.de:afe26f40-b5d0-46ef-9058-1a6519de2484" /></div>
	#<div class="cmn-act">15</div><div class="cmn-change"><div id="cmn-arrow_up"></div></div><div class="cmn-old">17</div><div class="cmn-title"> My Heart Goes (La Di Da)</div><div class="cmn-artist"> Becky Hill feat. Topic</div><div class="cmn-image"> <a href="https://www.mtv.de/musikvideos/1c8w3b/my-heart-goes-la-di-da" target="_blank"><img class="cmn-image" src="https://mtv.mtvnimages.com/uri/mgid:arc:content:mtv.de:22d27161-3022-11ec-9b1b-0e40cf2fc285" /></a> </div>
	#<div class="cmn-act">12</div><div class="cmn-change-new"></div><div class="cmn-title"> Undeniable</div><div class="cmn-artist"> Kygo feat. X Ambassadors</div><div class="cmn-image"> <a href="https://www.mtv.de/musikvideos/9z01wv/undeniable" target="_blank"><img class="cmn-image" src="https://mtv.mtvnimages.com/uri/mgid:arc:content:mtv.de:05f35ccf-2ce3-11ec-9b1b-0e40cf2fc285" /></a> </div>
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.chartVideos[1]) no.01 XXXXX CONTENT : {} XXXXX".format(str(content)))
	debug_MS("++++++++++++++++++++++++")
	spl = content.split('class="charts-marslnet"')
	for i in range(1, len(spl), 1):
		entry = spl[i]
		debug_MS("(navigator.chartVideos[2]) no.02 ##### ENTRY = {} #####".format(str(entry)))
		song = re.compile(r'="cmn-title">(.*?)</div>', re.S).findall(entry)[0]
		song = cleaning(song)
		artist = re.compile(r'="cmn-artist">(.*?)</div>', re.S).findall(entry)[0]
		artist = cleaning(artist)
		Chartnow = re.compile(r'class="cmn-act">(.*?)</div>', re.S).findall(entry)[0]
		Chartold = re.compile(r'class="cmn-old">(.*?)</div>', re.S).findall(entry)
		NewRee = re.compile(r'class="cmn-change-(.*?)">', re.S).findall(entry)
		EvUpDo = re.compile(r'<div id="(.*?)">', re.S).findall(entry)
		oldpos, plus_SUFFIX = ("" for _ in range(2))
		if NewRee:
			oldpos = '[COLOR deepskyblue]  ( NEU )[/COLOR]' if NewRee[0] == 'new' else '[COLOR deepskyblue]  ( REE )[/COLOR]'
		elif Chartold and EvUpDo:
			if '_even' in EvUpDo[0]: oldpos = "  ( - )"
			elif '_up' in EvUpDo[0]: oldpos = translation(30629).format(str(int(Chartold[0]) -  int(Chartnow)))
			elif '_down' in EvUpDo[0]: oldpos = translation(30630).format(str(int(Chartnow) - int(Chartold[0])))
		img = re.compile(r'class="cmn-image" src="(https://mtv[^"]+)"', re.S).findall(entry)
		photo = img[0] if img else icon
		video = re.compile(r'<a href="(https://www.mtv.de.*?)" target=', re.S).findall(entry)
		shortId = video[0].split('musikvideos/')[1].split('/')[0] if video else '00'
		if shortId != '00':
			name = translation(30631).format(str(Chartnow), song, artist+oldpos)
			uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playCODE', 'IDENTiTY': shortId}))
		elif shortId == '00' and showALL:
			name = translation(30632).format(str(Chartnow), song, artist+oldpos)
			plus_SUFFIX = '[CR][COLOR orangered]֎ No Video ֎[/COLOR]'
			uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'blankFUNC', 'IDENTiTY': shortId}))
		else: continue
		plot = 'Artist:  '+artist+'[CR]'+'Song:  '+song+'[CR]'+'Rank:  '+Chartnow+oldpos+plus_SUFFIX
		debug_MS("(navigator.chartVideos[3]) no.03 ##### TITLE = {} || shortId = {} || FOTO = {} #####".format(str(Chartnow)+'. '+song+' - '+artist, str(shortId), photo))
		if shortId != '00':
			COMBI_VID.append([uvz, song, artist, name, photo, plot, shortId, Chartnow, oldpos])
		COMBI_ALL.append([uvz, song, artist, name, photo, plot, shortId, Chartnow, oldpos])
	if TYPE == 'browse':
		if COMBI_ALL:
			for uvz, song, artist, name, photo, plot, shortId, Chartnow, oldpos in COMBI_ALL:
				LTM = xbmcgui.ListItem(name)
				if KODI_ov20:
					vinfo = LTM.getVideoInfoTag()
					vinfo.setTitle(name)
					vinfo.setPlot(plot)
					vinfo.setGenres(['Musicvideo'])
					vinfo.setStudios(['MTV'])
					vinfo.setMediaType('movie')
				else:
					vinfo = {}
					vinfo['Title'] = name
					vinfo['Plot'] = plot
					vinfo['Genre'] = 'Musicvideo'
					vinfo['Studio'] = 'MTV'
					vinfo['Mediatype'] = 'movie'
					LTM.setInfo(type='Video', infoLabels=vinfo)
				LTM.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
				if photo and useThumbAsFanart and photo != icon and not artpic in photo:
					LTM.setArt({'fanart': photo})
				if shortId != '00':
					LTM.setProperty('IsPlayable', 'true')
					LTM.setContentLookup(False)
					LTM.addContextMenuItems([(translation(30654), 'Action(Queue)')])
				xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LTM)
				SEND['videos'].append({'filter': shortId, 'name': name, 'extras': 'browse', 'transmit': 'tracking', 'shortTITLE': song+' - '+artist})
			with open(WORKFILE, 'w') as ground:
				json.dump(SEND, ground, indent=4, sort_keys=True)
		else:
			debug_MS("(navigator.chartVideos) ##### Keine COMBI_ALL-List - Kein Eintrag gefunden #####")
			return dialog.notification(translation(30524).format('Einträge'), translation(30525).format(TRANS), icon, 8000)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
	elif TYPE == 'play' and COMBI_VID:
		random.shuffle(COMBI_VID)
		for uvz, song, artist, name, photo, plot, shortId, Chartnow, oldpos in COMBI_VID:
			listitem = xbmcgui.ListItem(name)
			listitem.setArt({'icon': icon, 'thumb': photo, 'poster': photo})
			listitem.setProperty('IsPlayable', 'true')
			PLT.add(uvz, listitem)
			SEND['videos'].append({'filter': shortId, 'name': name, 'extras': 'NOTICE', 'transmit': 'tracking', 'shortTITLE': song+' - '+artist})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
		xbmc.Player().play(PLT)

def MtvGetVideo(url, TRANS):
	config = traversing.get_config()
	if xbmcvfs.exists(tempSF) and os.path.isdir(tempSF):
		shutil.rmtree(tempSF, ignore_errors=True)
		xbmc.sleep(500)
	xbmcvfs.mkdirs(tempSF)
	file_Names, file_Streams = ([] for _ in range(2))
	subSOURCE, subFOUND = (False for _ in range(2))
	SECOND_URL = ""
	if TRANS == 'tracking':
		CODING = getUrl(config['shortID'].format(url))
		if CODING.get('data', '') and CODING['data'].get('item', ''):
			TRANS = CODING['data']['item']['mgid']
			entityType = CODING['data']['item'].get('entityType', 'Unknown')
	# OFFIZIELL           = https://media.mtvnservices.com/pmt/e1/access/index.html?uri=mgid:arc:episode:mtv.intl:aaed37d0-98f6-11eb-8774-70df2f866ace&configtype=edge&ref=https://www.mtv.de/folgen/5k5mx0/catfish-verliebte-im-netz-nyhjee-cianna-staffel-8-ep-41
	# FUNKTIONIERT = https://media.mtvnservices.com/pmt/e1/access/index.html?uri=mgid:arc:episode:mtv.intl:aaed37d0-98f6-11eb-8774-70df2f866ace&configtype=edge&ref=https://www.mtv.de/
	DATA_ONE = getUrl(config['streamREQ'].format(TRANS, BASE_URL), REF=BASE_URL)
	debug_MS("+++++++++++++++++++++++++")
	debug_MS("(navigator.MtvGetVideo[1]) no.01 XXXXX DATA_ONE : {} XXXXX".format(str(DATA_ONE)))
	debug_MS("+++++++++++++++++++++++++")
	try: guid = DATA_ONE['feed']['items'][0]['guid']
	except: guid = DATA_ONE['uri']
	subNAME = fixPathSymbols(DATA_ONE['feed']['title']) if DATA_ONE.get('feed', '') and DATA_ONE['feed'].get('title', '') else 'TemporaryVideoSub'
	SECOND_URL = DATA_ONE['mediaGen'].replace('&device={device}', '').replace('{uri}', guid)
	# ORIGINAL = https://media-utils.mtvnservices.com/services/MediaGenerator/{uri}?arcStage=live&format=json&acceptMethods=hls&https=true&device={device}&isEpisode=true&ratingIds=b22fa3cb-b8a4-4f1c-9ccd-fdf435246ac1,f32ecc8f-7018-457a-893e-876ba039bb1c,4fca9d87-2212-4b48-8b4b-52a2adb6ca86&ratingAcc=default&accountOverride=intl.mtvi.com&ep=82ac4273
	# FERTIG     = https://media-utils.mtvnservices.com/services/MediaGenerator/mgid:arc:video:mtv.de:837234d4-7002-11e9-a442-0e40cf2fc285?arcStage=live&format=json&acceptMethods=hls&clang=de&https=true
	if 'player/html5' in SECOND_URL or not 'acceptMethods=hls' in SECOND_URL:
		SECOND_URL = DATA_ONE['feed']['items'][0]['group']['content'].replace('&device={device}', '')+'&format=json&acceptMethods=hls&tveprovider=null'
		# ERGEBNIS            = https://media-utils.mtvnservices.com/services/MediaGenerator/mgid:arc:musicvideo:mtv.intl:c188caed-fc02-11eb-9b1b-0e40cf2fc285?arcStage=live&accountOverride=intl.mtvi.com&billingSection=intl&device={device}&ep=82ac4273
		# FUNKTIONIERT = https://media-utils.mtvnservices.com/services/MediaGenerator/mgid:arc:musicvideo:mtv.intl:c188caed-fc02-11eb-9b1b-0e40cf2fc285?arcStage=live&accountOverride=intl.mtvi.com&billingSection=intl&ep=82ac4273&format=json&acceptMethods=hls&tveprovider=null
	DATA_TWO = getUrl(SECOND_URL, REF=BASE_URL)
	debug_MS("+++++++++++++++++++++++++")
	debug_MS("(navigator.MtvGetVideo[2]) no.02 XXXXX DATA_TWO : {} XXXXX".format(str(DATA_TWO)))
	debug_MS("+++++++++++++++++++++++++")
	try:
		subENTRIES = DATA_TWO['package']['video']['item'][0]['transcript']
		for ii, elem in enumerate(subENTRIES, 1): # Nederlands, Deutsch (nl, de)
			if (elem.get('srclang') == langSHORT or langSHORT == 'aio') and elem.get('typographic', ''):
				subSOURCE = [vid.get('src', []) for vid in elem.get('typographic', {}) if vid.get('format') == 'vtt'][0]
				if elem.get('label', ''):
					file_Names.append(translation(30633).format(str(ii), str(elem['label'])))
					file_Streams.append(subSOURCE)
	except: pass
	if subSOURCE and enableSUBTITLE:
		siteResult = subSOURCE
		if langSHORT == 'aio' and file_Names:
			index = dialog.select(translation(30634), file_Names, preselect=0)
			siteResult = file_Streams[index] if index > -1 else None
		if siteResult:
			log("(navigator.MtvGetVideo) SubtitleURL : {}".format(siteResult))
			req = getUrl(siteResult, method='STREAM', stream=True)
			with open(os.path.join(tempSF, subNAME+'.srt'), 'wb') as saving:
				req.raw.decode_content = True
				shutil.copyfileobj(req.raw, saving)
			subFOUND = True
	try:
		videoURL = DATA_TWO['package']['video']['item'][0]['rendition'][0]['src']
	except:
		code = '[COLOR red]'+DATA_TWO['package']['video']['item'][0]['code'].replace('_', ' ').upper()+'[/COLOR]'
		text = DATA_TWO['package']['video']['item'][0]['text']
		dialog.notification(code, text, icon, 8000)
		videoURL = False
		xbmc.sleep(5000)
	return (videoURL, subFOUND, subNAME)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS("(navigator.playCODE) ### IDD = {} ###".format(IDD))
	FINAL_URL, subFOUND = (False for _ in range(2))
	SUB_NAME= 'Unknown'
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == IDD:
				name = elem['name']
				EXTRA = elem['extras']
				TRANS = elem['transmit']
				DISPLAY = elem['shortTITLE']
				debug_MS("(navigator.playCODE) ### WORKFILE-Line : {} ###".format(str(elem)))
				FINAL_URL, subFOUND, SUB_NAME = MtvGetVideo(IDD, TRANS)
	if FINAL_URL:
		log("(navigator.playCODE) StreamURL : {}".format(FINAL_URL))
		subFILE = os.path.join(tempSF, SUB_NAME+'.srt')
		LVM = xbmcgui.ListItem(path=FINAL_URL)
		if subFOUND is True and subFILE:
			debug_MS("(navigator.playCODE) ##### subFOUND : {} || subFILE : {} #####".format(str(subFOUND), subFILE))
			subFILE = subFILE.split('|')
			LVM.setSubtitles(subFILE)
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "id":1, "method":"Player.SetSubtitle", "params":{"playerid":1, "subtitle":"on"}}')
			#xbmc.executeJSONRPC('{"jsonrpc":"2.0", "id":1, "method":"Player.SetSubtitle", "params":{"playerid":1, "subtitle":"off"}}')
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'm3u8' in FINAL_URL:
			LVM.setMimeType('application/vnd.apple.mpegurl')
			LVM.setProperty('inputstream', 'inputstream.adaptive')
			LVM.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LVM)
		xbmc.sleep(1000)
		if enableINFOS and EXTRA == 'NOTICE': infoMessage(DISPLAY)
	else:
		failing("(navigator.playCODE) ##### Abspielen des Streams NICHT möglich ##### IDD : {} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *mtv.de* gefunden !!! ##########".format(IDD))
		return dialog.notification(translation(30521).format('VIDEO'), translation(30529).format(DISPLAY), icon, 10000)

def playLIVE(url):
	debug_MS("(navigator.playLIVE) ------------------------------------------------ START = playLIVE -----------------------------------------------")
	log("(navigator.playLIVE) LiveURL : {}".format(url))
	LZM = xbmcgui.ListItem(path=url, label=translation(30635))
	LZM.setMimeType('application/vnd.apple.mpegurl')
	if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
		LZM.setProperty('inputstream', 'inputstream.adaptive')
		LZM.setProperty('inputstream.adaptive.manifest_type', 'hls')
		LZM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
	xbmc.Player().play(item=url, listitem=LZM)

def infoMessage(DISPLAY):
	count = 0
	while not xbmc.Player().isPlaying():
		xbmc.sleep(200)
		if count == 50:
			break
		count += 1
	xbmc.sleep(infoDelay*1000)
	if xbmc.Player().isPlaying():
		xbmc.getInfoLabel('Player.Duration')
		xbmc.getInfoLabel('Player.Art(thumb)')
		xbmc.sleep(500)
		RUNTIME = xbmc.getInfoLabel('Player.Duration')
		PHOTO = xbmc.getInfoLabel('Player.Art(thumb)')
		xbmc.sleep(1000)
		dialog.notification(translation(30636), DISPLAY+'[COLOR blue]  * '+RUNTIME+' *[/COLOR]', PHOTO, infoDuration*1000)
	else: pass

def addDir(name, image, params={}, plot=None, genre=None, folder=True, background=False):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setGenres([genre]), vinfo.setStudios(['MTV'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': genre, 'Studio': 'MTV'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and (not artpic in image or background is True):
		liz.setArt({'fanart': image})
	if params.get('extras') in ['newMU', 'MUSIC', 'SNAKE', 'CHART']:
		liz.addContextMenuItems([(translation(30655), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': params.get('mode'), 'url': params.get('url'), 'extras': params.get('extras'),
			'transmit': params.get('transmit') if params.get('transmit') else 'special', 'page': params.get('page') if params.get('page') else '1', 'target': 'play'})))])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
