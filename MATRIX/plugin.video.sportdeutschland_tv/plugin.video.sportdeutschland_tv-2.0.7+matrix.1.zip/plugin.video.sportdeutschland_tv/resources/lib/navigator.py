﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
from collections import OrderedDict
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else:
	from urllib.parse import urlencode, quote  # Python 3.X
	from urllib.request import urlopen  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	counter = 0
	newURL = BASE_API+'upcoming-live-assets'
	content = getUrl(newURL)
	DATA = json.loads(content, object_pairs_hook=OrderedDict)
	if DATA and len(DATA) > 0:
		for item in DATA:
			if item.get('currently_live', '') is True:
				if not str(item.get('price_in_cents', '')).isdigit() and not "PAY_PER_VIEW" in str(item.get('monetizations', '')):
					counter += 1
	if counter > 0:
		addDir(translation(30601).format(str(counter)), artpic+'livestream.png', {'mode': 'listVideos', 'url': BASE_API+'upcoming-live-assets?', 'limit': '20', 'wanted': '2', 'extras': 'allowed'})
	addDir(translation(30602), icon, {'mode': 'listVideos', 'url': BASE_API+'upcoming-live-assets?', 'limit': '20', 'wanted': '2', 'extras': 'undesired'})
	addDir(translation(30603), artpic+'favourites.png', {'mode': 'listShowsFavs'})
	addDir(translation(30604), icon, {'mode': 'listVideos', 'url': BASE_API+'home/top-assets?', 'limit': '6', 'wanted': '11', 'extras': 'undesired'})
	addDir(translation(30605), icon, {'mode': 'listVideos', 'url': BASE_API+'tags/badminton/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30606), icon, {'mode': 'listVideos', 'url': BASE_API+'tags/basketball/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30607), icon, {'mode': 'listVideos', 'url': BASE_API+'tags/eishockey/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30608), icon, {'mode': 'listVideos', 'url': BASE_API+'tags/fitness/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30609), icon, {'mode': 'listVideos', 'url': BASE_API+'tags/handball/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30610), icon, {'mode': 'listVideos', 'url': BASE_API+'tags/leichtathletik/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30611), icon, {'mode': 'listVideos', 'url': BASE_API+'tags/tischtennis/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30612), icon, {'mode': 'listVideos', 'url': BASE_API+'tags/turnen/assets?', 'limit': '20', 'wanted': '4', 'extras': 'undesired'})
	addDir(translation(30613), icon, {'mode': 'listSports', 'url': BASE_API+'home/tags?', 'limit': '6', 'wanted': '55', 'extras': 'allowed'})
	addDir(translation(30614), icon, {'mode': 'listSports', 'url': BASE_API+'sidebar/top-profiles?', 'limit': '10', 'wanted': '50', 'extras': 'allowed'})
	addDir(translation(30615), artpic+'basesearch.png', {'mode': 'SearchSDTV'})
	if enableADJUSTMENT:
		addDir(translation(30616), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30617), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def listSports(url, PAGE, LIMIT, POS, WANTED):
	debug_MS("(navigator.listSports) -------------------------------------------------- START = listSports --------------------------------------------------")
	counter, PAGE, MAXIMUM = int(POS), int(PAGE), int(PAGE) + int(WANTED)-1
	debug_MS("(navigator.listSports) ### URL : {0} ### PAGE : {1} ### LIMIT : {2} ### POSITION : {3} ### maxPAGES : {4} ###".format(url, str(PAGE), LIMIT, str(counter), str(MAXIMUM)))
	COMBI_CATS = []
	UNIKAT = set()
	while PAGE < MAXIMUM:
		newURL = '{0}page={1}&per_page={2}'.format(url, str(PAGE), LIMIT)
		debug_MS("(navigator.listSports) newURL : {0}".format(str(newURL)))
		content = getUrl(newURL)
		debug_MS("++++++++++++++++++++++++")
		debug_MS("(navigator.listSports) XXXXX CONTENT : {0} XXXXX".format(str(content)))
		debug_MS("++++++++++++++++++++++++")
		DATA = json.loads(content, object_pairs_hook=OrderedDict)
		if 'data' in DATA and len(DATA['data']) > 0:
			PAGE += 1
		else:
			PAGE += MAXIMUM
		for item in DATA['data']:
			Note_1, Note_2, plot = ("" for _ in range(3))
			counter += 1
			UUID = (item.get('uuid', '') or item.get('id', ''))
			if UUID in UNIKAT:
				continue
			UNIKAT.add(UUID)
			title = (item.get('title', '') or item.get('label', '') or item.get('name', ''))
			title = cleaning(title)
			SLUG = item.get('slug', '')
			if 'tags?' in url:
				newURL = BASE_API+'tags/'+SLUG+'/assets?'
				newLIMIT, newWANTED, Note_1 = '20', '4', translation(30630)+'[CR][CR]'
			else: 
				newURL = BASE_API+'profiles/'+SLUG+'/assets?'
				newLIMIT, newWANTED, Note_1 = '18', '4', translation(30631)+'[CR][CR]'
			if item.get('description', ''):
				Note_2 = cleaning(item['description'])
			plot = Note_1+Note_2
			photo = (item.get('image_url', '') or icon)
			if photo == icon and item.get('assets_top_20', '') and len(item.get('assets_top_20', '')) > 0:
				photo = (item.get('assets_top_20', {})[0].get('image_url', '') or icon)
			if photo: photo = photo.replace('_1024x576.', '_1280x720.', 1)
			COMBI_CATS.append([title, UUID, newURL, newLIMIT, newWANTED, photo, plot])
	if COMBI_CATS:
		COMBI_CATS = sorted(COMBI_CATS, key=lambda d:d[0], reverse=False)
		for title, UUID, newURL, newLIMIT, newWANTED, photo, plot in COMBI_CATS:
			if ('profiles?' in url and (title[0].isupper() or title[0].isdigit())) or ('tags?' in url and len(title) > 5):
				debug_MS("(navigator.listSports) ##### TITLE = {0} || LINK = {1} || IMAGE = {2} #####".format(str(title), newURL, photo))
				addType = 1
				if xbmcvfs.exists(channelFavsFile):
					with open(channelFavsFile, 'r') as fp:
						watch = json.load(fp)
						for item in watch.get('items', []):
							if item.get('url') == newURL: addType = 2
				addDir(title, photo, {'mode': 'listVideos', 'url': newURL, 'limit': newLIMIT, 'wanted': newWANTED, 'extras': 'undesired'}, plot, addType, background=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchSDTV():
	debug_MS("(navigator.SearchSDTV) ------------------------------------------------ START = SearchSDTV -----------------------------------------------")
	keyword = None
	if xbmcvfs.exists(searchHackFile):
		with open(searchHackFile, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30632), type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
		if keyword:
			keyword = quote(keyword)
			with open(searchHackFile, 'w') as record:
				record.write(keyword)
	if keyword: return listVideos('https://search.sportdeutschland.tv/api/v1/search/assets?q='+keyword+'&', page, '10', position, excluded, '10', 'undesired')
	return None

def listVideos(url, PAGE, LIMIT, POS, FILTER, WANTED, SCENE):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	counterTWO, disqualifiedTWO, PAGE, MAXIMUM = int(POS), int(FILTER), int(PAGE), int(PAGE) + int(WANTED)-1
	counterONE, disqualifiedONE = (0 for _ in range(2))
	debug_MS("(navigator.listVideos) ### URL : {0} ### PAGE : {1} ### LIMIT : {2} ### POSITION : {3} ### EXCLUDED : {4} ### maxPAGES : {5} ### showLIVE : {6} ###".format(url, str(PAGE), LIMIT, str(counterTWO), str(disqualifiedTWO), str(MAXIMUM), SCENE))
	COMBI_EPISODE = []
	UNIKAT = set()
	while PAGE < MAXIMUM:
		newURL = '{0}page={1}&per_page={2}'.format(url, str(PAGE), LIMIT)
		debug_MS("(navigator.listVideos) newURL : {0}".format(str(newURL)))
		content = getUrl(newURL)
		debug_MS("++++++++++++++++++++++++")
		debug_MS("(navigator.listVideos) XXXXX CONTENT : {0} XXXXX".format(str(content)))
		debug_MS("++++++++++++++++++++++++")
		DATA = json.loads(content, object_pairs_hook=OrderedDict)
		if ('data' in DATA and len(DATA['data']) > 0) or ('assets' in DATA and len(DATA['assets']) > 0) or (DATA and 'upcoming-live-assets' in url):
			elements = DATA['data'] if ('data' in DATA and len(DATA['data']) > 0) else DATA['assets'] if ('assets' in DATA and len(DATA['assets']) > 0) else DATA
			PAGE += 1
		else:
			elements = ""
			PAGE += MAXIMUM
		for each in elements:
			debug_MS("(navigator.listVideos) no.01 ##### ELEMENT = {0} #####".format(str(each)))
			genre, Note_1, Note_2, Note_3, plot = ("" for _ in range(5))
			PUBLISHED, startCOMPLETE, startSORTING, startDATE, startTIME, VIDEO, TEASER = (None for _ in range(7))
			duration = 0
			counterONE += 1
			counterTWO += 1
			UUID = (each.get('uuid', '') or each.get('id', ''))
			if UUID in UNIKAT:
				disqualifiedONE += 1
				disqualifiedTWO += 1
				continue
			UNIKAT.add(UUID)
			title = (each.get('title', '') or each.get('label', '') or each.get('name', ''))
			title = cleaning(title)
			PUBLISHED = (each.get('content_start_date', '') or each.get('published_at', ''))
			if PUBLISHED and PUBLISHED[:10].replace('.', '').replace('-', '').replace('/', '').isdigit():
				LOCALstart = get_Local_DT(PUBLISHED[:19])
				startCOMPLETE = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				startSORTING = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('.', ':')
				startDATE = LOCALstart.strftime('%d{0}%m{0}%Y').format('.')
				startTIME = LOCALstart.strftime('%H{0}%M').format(':')
			photo = (each.get('image_url', '') or icon)
			if photo: photo = photo.replace('_1024x576.', '_1280x720.', 1)
			if str(each.get('price_in_cents', '')).isdigit() or 'PAY_PER_VIEW' in str(each.get('monetizations', '')):
				disqualifiedONE += 1
				disqualifiedTWO += 1
				continue
			if (each.get('currently_live', '') is True and SCENE == 'undesired') or (each.get('currently_live', '') is False and SCENE == 'allowed'):
				disqualifiedONE += 1
				disqualifiedTWO += 1
				continue
			VIDEO = (each.get('video_url', None) or None)
			name = startDATE+" - "+title if startDATE and not '1970' in startDATE else title
			if startTIME and each.get('currently_live', '') is True:
				name = translation(30633).format(startTIME, title)
			if ((VIDEO and SCENE == 'undesired') or (not VIDEO)) and startCOMPLETE:
				if LOCALstart > datetime.now():
					name = startCOMPLETE+" - "+title
			duration = int(duration)+int(each.get('video_duration', '0') or '0')
			duration = "{0:.0f}".format(duration)
			if each.get('profile', ''):
				if each.get('profile', {}).get('sport_type', '') and each.get('profile', []).get('sport_type', {}).get('name', ''):
					genre = cleaning(each['profile']['sport_type']['name'])
				if each.get('profile', {}).get('name', ''):
					Note_1 = cleaning(each['profile']['name'])+'[CR]'
			Note_2 = translation(30634).format(str(startCOMPLETE)) if startCOMPLETE else '[CR]'
			TEASER = (each.get('description', '') or each.get('teaser', ''))
			if TEASER: Note_3 = cleaning(TEASER, True).replace('\n', '[CR]')
			plot = Note_1+Note_2+Note_3
			COMBI_EPISODE.append([title, name, startSORTING, VIDEO, UUID, photo, plot, duration, genre])
	if COMBI_EPISODE:
		if 'search/assets?' in url:
			COMBI_EPISODE = sorted(COMBI_EPISODE, key=lambda d:d[2], reverse=True)
		for title, name, startSORTING, VIDEO, UUID, photo, plot, duration, genre in COMBI_EPISODE:
			debug_MS("(navigator.listVideos) no.02 ##### NAME : {0} || UUID : {1} || GENRE : {2} #####".format(str(name), UUID, str(genre)))
			debug_MS("(navigator.listVideos) no.02 ##### THUMB : {0} || VIDEO : {1} #####".format(photo, VIDEO))
			if VIDEO:
				addLink(name, photo, {'mode': 'playVideo', 'url': VIDEO, 'extras': UUID}, plot, duration, genre)
		debug_MS("(navigator.listVideos) NUMBERING ### current_RESULT : {0} // all_RESULT : {1} ### current_EXCLUDED : {2} // all_EXCLUDED : {3} ###".format(str(counterONE), str(counterTWO), str(disqualifiedONE), str(disqualifiedTWO)))
		if 'meta' in DATA and DATA['meta'] and not (SCENE == 'allowed' and 'upcoming-live-assets' in url):
			if DATA.get('meta', {}).get('total', '') and isinstance(DATA['meta']['total'], int) and int(DATA['meta']['total']) > int(LIMIT)*int(PAGE):
				debug_MS("(navigator.listVideos) NUMBERING ### totalRESULTS : {0} ###".format(str(DATA['meta']['total'])))
				debug_MS("(navigator.listVideos) Now show NextPage ... No.{0} ... ###".format(PAGE))
				addDir(translation(30635), artpic+'nextpage.png', {'mode': 'listVideos', 'url': url, 'page': PAGE, 'limit': LIMIT, 'position': counterTWO, 'excluded': disqualifiedTWO, 'wanted': WANTED, 'extras': SCENE})
				### addDir(translation(30636).format(PAGE), artpic+'nextpage.png', {'mode': 'listVideos', 'url': url, 'page': PAGE, 'limit': LIMIT, 'position': counterTWO, 'excluded': disqualifiedTWO, 'wanted': WANTED, 'extras': SCENE})
	else:
		debug_MS("(navigator.listEpisodes) ##### Keine COMBI_EPISODE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30522).format('Einträge'), translation(30524), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url, UUID):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL : {0} ### UUID : {1} ###".format(url, str(UUID)))
	STREAM_URL, LICENSE_URL, TEST_URL = (False for _ in range(3))
	codeLICENSE = ""
	if 'vidibus.net/live' in url:
		STREAM_URL = url.replace('.smil', '.m3u8', 1)
	else:
		### "id":"936fa719-926d-4873-9cc0-dc8e68d7e1e4" ###
		### "video_url":"https:\/\/manager.dosbnewmedia.de\/\/mediafiles\/fd4bbf70ae540139bf7c2c4d54466afd.smil" ###
		### https://api.sportdeutschland.tv/api/frontend/assets/936fa719-926d-4873-9cc0-dc8e68d7e1e4/token ###
		### https://manager.dosbnewmedia.de/mediafiles/fd4bbf70ae540139bf7c2c4d54466afd.smil?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJodHRwczpcL1wvYXBpLnNwb3J0ZGV1dHNjaGxhbmQudHZcLyIsInN1YiI6eyJpcCI6IjIxNy44OS4xMC4xNzMiLCJ1c2VyX2lkIjpudWxsLCJhc3NldF9pZCI6IjkzNmZhNzE5LTkyNmQtNDg3My05Y2MwLWRjOGU2OGQ3ZTFlNCIsInZpZGVvX2Nkbl9pZCI6ImZkNGJiZjcwLWFlNTQtMDEzOS1iZjdjLTJjNGQ1NDQ2NmFmZCIsInZpZGVvX2lkIjoiOTNhZDQ2NzktNTBjMi00Y2NiLTg1MzUtYzViZDU0MTJmZTNhIiwidmlkZW9fdXJsIjoiaHR0cHM6XC9cL21hbmFnZXIuZG9zYm5ld21lZGlhLmRlXC9tZWRpYWZpbGVzXC9mZDRiYmY3MGFlNTQwMTM5YmY3YzJjNGQ1NDQ2NmFmZC5zbWlsIiwibGl2ZXN0cmVhbV9jZG5faWQiOm51bGwsImxpdmVzdHJlYW1faWQiOm51bGwsImxpdmVzdHJlYW1fdXJsIjpudWxsfSwiYXVkIjoicHJvZHVjdGlvbiIsImlhdCI6MTYyNTMzMjQxNywibmJmIjoxNjI1MzMyNDE3LCJleHAiOjE2MjUzMzI3MTcsImp0aSI6IjkzZDJiODIzLTNhNDAtNDg3ZS04NzNiLTgzN2ZkZTJlM2NiMCJ9.Ain6cTyLTwpPXR0w8mIqhauzBC57Ts5YaQXVPMoN7lXuvYEsiHkwFx1AqvVluiImY1qppgaOVpUMutNOEDdOYSr79R_OF20Q-e4NwweRbAEVz4bvnDDkKZzY2GZABj-lHO2khze5P-PN9pU4PLlLezLYYqioa811BgeO8yMT8JEkHM1TbSXYNC2C3EX5hlqwTlHCHFL1lMV1lJZKpDlPsD5jdvlew0s-OBJB3fOBpdOK3Xfgp2stn4oatcPPDZw60kfOvUAuV5-0B1kOBdE7k4ra2SLyud4V0MkSRMRMnV2Jzk3nkSVt34m1uNPb1IHbqgNeJuXcUwle7osJC6zqqwO2iJJHb1dilxTjpgeQfDyklLIgS2jdRm9j5aU_wWb_7_cg4b4T5Ipq_4DbnotCPWVUT5iDpNZ9_5JrFcmapdB-wjcuB_wjDpZLUuGfVQlmX9AWUZ4IG8jRh2dJN0Wi2RgrroWWdSAMavACSeAOS6LdtXil1TtsKUd_zcBK-BEclYgHAk690YNzlm5O-g8urrur8vYucyCNQjBsE_T1d3dW0k3M8d5cZ_dgD6jESYpCuI3NUf7ffP--WcIwDQtT6FvkAqjX9g23e_hcGu3-u9t8r_9UtshMOFYTutZM5XFR6v67ucuaxgUn0-6v_tThpXpaOwDK0VdksItxRMerUCU ###
		### https://cloudvodstreamer1.dosbnewmedia.de/dynamic-vod/60c5d6afe534586c8f0000c9.json/master.m3u8 ###
		newURL = 'https://api.sportdeutschland.tv/api/frontend/assets/'+str(UUID)+'/token'# This takes for now the old-API
		content = getUrl(newURL)
		token = '?jwt='+re.compile('\\{"token":"(eyJ.*?)"\\}', re.S).findall(content)[0]
		url = url.replace('.mp4', '.smil', 1) if url.endswith('.mp4') else url
		debug_MS("(navigator.playVideo) XXXXX staticURL+token : {0} XXXXX".format(str(url+token)))
		result = getUrl(url+token)
		debug_MS("(navigator.playVideo) XXXXX RESULT : {0} XXXXX".format(str(result)))
		lastURL = re.compile('<video src="(.*?)" type=', re.S).findall(result)
		playTYPE = re.compile('" type="([^"]+?)"', re.S).findall(result)
		if lastURL and playTYPE and playTYPE[0] == 'video/mp4':
			STREAM_URL = lastURL[0]
		elif lastURL and playTYPE and playTYPE[0] != 'video/mp4':
			if lastURL[0].count('/') > 4:
				### a.split('/', 3) will split the string upto the third occurrence of '/' || a.split('/', 3)[:3] will give the first 3 elements in the list. Then simply join the first 3 elements. ###
				LICENSE_URL = '/'.join(lastURL[0].split('/', 3)[:3])+'/encrypt/'+lastURL[0].split('/')[-2].replace('.json', '.json/encryption.key', 1)
			debug_MS("(navigator.playVideo) XXXXX LICENSE_URL : {0} XXXXX".format(str(LICENSE_URL)))
			STREAM_URL = lastURL[0]
	if not STREAM_URL:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *sportdeutschland.tv* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('URL-1'), translation(30526), icon, 8000)
	try:
		codeSTREAM = urlopen(STREAM_URL, timeout=6).getcode()
		if LICENSE_URL:
			codeLICENSE = urlopen(LICENSE_URL, timeout=6).getcode()
		if (LICENSE_URL and str(codeSTREAM) == '200' and str(codeLICENSE) == '200') or (not LICENSE_URL and str(codeSTREAM) == '200'):
			TEST_URL = True
	except: pass
	if STREAM_URL and TEST_URL:
		log("(navigator.playVideo) StreamURL : {0}".format(STREAM_URL))
		listitem = xbmcgui.ListItem(path=STREAM_URL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'm3u8' in STREAM_URL:
			listitem.setMimeType('application/vnd.apple.mpegurl')
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## Die Stream-Url auf der Webseite von *sportdeutschland.tv* ist OFFLINE !!! ##########".format(url))
		return dialog.notification(translation(30521).format('URL-2'), translation(30527), icon, 8000)

def listShowsFavs():
	debug_MS("(navigator.listShowsFavs) ------------------------------------------------ START = listShowsFavs -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as fp:
			watch = json.load(fp)
			for item in watch.get('items', []):
				name = cleaning(item.get('name'))
				logo = icon if item.get('pict', 'None') == 'None' else item.get('pict')
				urlFW = item.get('url').replace('api/frontend/', 'api/stateless/frontend/') if 'api/frontend/' in item.get('url') else item.get('url')
				desc = None if item.get('plot', 'None') == 'None' else cleaning(item.get('plot'))
				debug_MS("(navigator.listShowsFavs) ### NAME : {0} || URL : {1} || IMAGE : {2} ###".format(name, urlFW, logo))
				addDir(name, logo, {'mode': 'listVideos', 'url': urlFW, 'limit': item.get('limit'), 'wanted': item.get('wanted'), 'extras': item.get('extras')}, desc, FAVclear=True, background=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(*args):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'name': name, 'pict': pict, 'url': url, 'limit': limit, 'wanted': wanted, 'extras': extras, 'plot': plot})
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30528), translation(30529).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('url') != url]
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30528), translation(30530).format(name), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, addType=0, FAVclear=False, folder=True, background=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'Sportdeutschland.tv'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	entries = []
	if addType == 1 and FAVclear is False:
		entries.append([translation(30651), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'action': 'ADD', 'name': name, 'pict': 'None' if image == icon else image, 'url': params.get('url'),
			'limit': params.get('limit'), 'wanted': params.get('wanted'), 'extras': params.get('extras'), 'plot': 'None' if plot == None else plot.replace('\n', '[CR]')}))])
	if FAVclear is True:
		entries.append([translation(30652), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'action': 'DEL', 'name': name, 'pict': image, 'url': params.get('url'),
			'limit': params.get('limit'), 'wanted': params.get('wanted'), 'extras': params.get('extras'), 'plot': plot}))])
	liz.addContextMenuItems(entries, replaceItems=False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None, genre=None, seriesname=None, mpaa=None, year=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Tvshowtitle'] = seriesname
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Year'] = year
	info['Genre'] = genre
	info['Studio'] = 'Sportdeutschland.tv'
	info['Mpaa'] = mpaa
	info['Mediatype'] = 'tvshow'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
