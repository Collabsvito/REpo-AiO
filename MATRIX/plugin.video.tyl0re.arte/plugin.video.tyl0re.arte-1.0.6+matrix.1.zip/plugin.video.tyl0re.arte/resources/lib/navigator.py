﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus  # Python 2.X
else:
	from urllib.parse import urlencode, quote_plus  # Python 3.X

from .common import *


starting = {
    'highlights': API_URL+'pages/HOME/',
    'magazines': API_URL+'data/VIDEO_LISTING/?videoType=MAGAZINES&limit=50',
    'byDate': API_URL+'pages/TV_GUIDE/?day=',
    'viewed': API_URL+'data/VIDEO_LISTING/?videoType=MOST_VIEWED',
    'recent': API_URL+'data/VIDEO_LISTING/?videoType=MOST_RECENT',
    'chance': API_URL+'data/VIDEO_LISTING/?videoType=LAST_CHANCE',
    'search': API_URL+'data/SEARCH_LISTING/?query='
}

if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	if COUNTRY == 'de':
		addDir(translation(30601), icon, {'mode': 'listMagazines', 'url': starting['highlights']})
		addDir(translation(30602), icon, {'mode': 'listThemes', 'url': 'https://api.arte.tv/api/opa/v3/'})
		addDir(translation(30603), icon, {'mode': 'listMagazines', 'url': starting['magazines']})
		addDir(translation(30604), icon, {'mode': 'listSelection'})
		addDir(translation(30605), icon, {'mode': 'listRunTime'})
		addDir(translation(30606), icon, {'mode': 'listEpisodes', 'url': starting['viewed']})
		addDir(translation(30607), icon, {'mode': 'listEpisodes', 'url': starting['recent']})
		addDir(translation(30608), icon, {'mode': 'listEpisodes', 'url': starting['chance']})
		addDir(translation(30609), artpic+'basesearch.png', {'mode': 'SearchArte'})
		addDir(translation(30610), artpic+'livestream.png', {'mode': 'liveTV'})
		if enableADJUSTMENT: addDir(translation(30611), artpic+'settings.png', {'mode': 'aSettings'})
	elif COUNTRY == 'fr':
		addDir('Faits saillants spéciaux', icon, {'mode': 'listMagazines', 'url': starting['highlights']})
		addDir('Sujets', icon, {'mode': 'listThemes', 'url': 'https://api.arte.tv/api/opa/v3/'})
		addDir('Émissions A-Z', icon, {'mode': 'listMagazines', 'url': starting['magazines']})
		addDir('Programme trié par date', icon, {'mode': 'listSelection'})
		addDir('Vidéos triées par durée', icon, {'mode': 'listRunTime'})
		addDir('Les plus vues', icon, {'mode': 'listEpisodes', 'url': starting['viewed']})
		addDir('Les plus récentes', icon, {'mode': 'listEpisodes', 'url': starting['recent']})
		addDir('Dernière chance', icon, {'mode': 'listEpisodes', 'url': starting['chance']})
		addDir('Recherche ...', artpic+'basesearch.png', {'mode': 'SearchArte'})
		if enableADJUSTMENT: addDir('ARTE Paramètres', artpic+'settings.png', {'mode': 'aSettings'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listThemes(url):
	debug_MS("(navigator.listThemes) ------------------------------------------------ START = listThemes -----------------------------------------------")
	result = getUrl(url+'categories?language='+COUNTRY+'&limit=50', CALL_PRO=OPA_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listThemes) RESULT : {0}".format(str(result)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(result)
	for themeITEM in DATA['categories']:
		Cat = str(themeITEM['code'])
		title = cleaning(themeITEM['label'])
		tagline = (cleaning(themeITEM.get('description', '') or ""))
		if title.lower() != 'andere':
			sublist = json.dumps(themeITEM['subcategories'])
			debug_MS("(navigator.listThemes) ### NAME = {0} || CATEGORY = {1} ###".format(title, Cat))
			addDir(title, thepic+Cat+'.png', {'mode': 'listSubThemes', 'url': sublist, 'extras': Cat}, tagline)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

# https://www.arte.tv/guide/api/emac/v3/de/web/pages/ARTE_CONCERT_CLASSIC/
# https://www.arte.tv/guide/api/emac/v3/de/web/pages/ARTE_CONCERT/?category=ARS&subcategories
def listSubThemes(Xurl, nomCat):
	debug_MS("(navigator.listSubThemes) ------------------------------------------------ START = listSubThemes -----------------------------------------------")
	subcategories = json.loads(Xurl)
	if COUNTRY == 'de' and nomCat == "ARS":
		newURL = API_URL+'data/VIDEO_LISTING/?category={0}@imageFormats=landscape@videoType=MOST_RECENT'.format(nomCat)
		addDir(translation(30613), icon, {'mode': 'listEpisodes', 'url': newURL})
	for subITEM in subcategories:
		subCat = str(subITEM['code'])
		title = cleaning(subITEM['label'])
		tagline = (cleaning(subITEM.get('description', '') or ""))
		debug_MS("(navigator.listSubThemes) ### CAT = {0} || subCAT = {1} || NAME = {2} ###".format(nomCat, subCat, title))
		# https://api-cdn.arte.tv/api/emac/v3/de/web/data/VIDEO_LISTING/?category=ARS&imageFormats=landscape&subcategories=MUA&videoType=MOST_RECENT&page=2&limit=20
		if subCat in ['CHU', 'SES']:
			newURL = API_URL+'pages/{0}/'.format(subCat)
			addDir(title, thepic+nomCat+'.png', {'mode': 'listMagazines', 'url': newURL}, tagline)
		else:
			newURL = API_URL+'data/VIDEO_LISTING/?category={0}&subcategories={1}&imageFormats=landscape&videoType=MOST_RECENT'.format(nomCat, subCat)
			addDir(title, thepic+nomCat+'.png', {'mode': 'listEpisodes', 'url': newURL}, tagline)
	xbmcplugin.endOfDirectory(ADDON_HANDLE) 

def listMagazines(url):
	debug_MS("(navigator.listMagazines) ------------------------------------------------ START = listMagazines -----------------------------------------------")
	Isolated = set()
	if 'CHU/' in url:
		prefer = ['kurz-und-witzig']
		serURL = API_URL+'data/MOST_RECENT_SUBCATEGORY/?subCategoryCode=CHU'
		addDir(translation(30614), icon, {'mode': 'listEpisodes', 'url': serURL})
	elif 'SES/' in url:
		prefer = ['serien']
		serURL = API_URL+'data/MOST_RECENT_SUBCATEGORY/?subCategoryCode=SES'
		addDir(translation(30615), icon, {'mode': 'listEpisodes', 'url': serURL})
	else:
		prefer = ['derzeit-im-trend', 'gesellschaft', 'highlights', 'playlists']
	result = 	getUrl(url.replace('SES/', 'HOME/').replace('CHU/', 'SER/'), CALL_PRO=EMAC_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listMagazines) RESULT : {0}".format(str(result)))
	debug_MS("++++++++++++++++++++++++")
	CON = json.loads(result)
	DATA = CON['zones'] if 'CHU/' in url or 'HOME/' in url or 'SES/' in url else CON['data']
	for magITEM in DATA:
		if any(x in magITEM['id'].lower() for x in prefer):
			for teaser in magITEM['data']:
				if not 'CHU/' in url and not 'SES/' in url and 'kind' in teaser and 'isCollection' in teaser['kind'] and teaser['kind']['isCollection'] == False and str(teaser.get('duration')) not in ['', 'None', '0']:
					if teaser['url'] in Isolated:
						continue
					Isolated.add(teaser['url'])
					LINKING(teaser, '(listMagazines)')
				elif 'kind' in teaser and 'isCollection' in teaser['kind'] and teaser['kind']['isCollection'] == True:
					if ('CHU/' in url or 'SES' in url) and ('kind' in teaser and 'code' in teaser['kind'] and teaser['kind']['code'] == 'TV_SERIES'):
						PID = str(teaser['programId'])
						title = cleaning(teaser['title'])
						plot = get_Description(teaser)
						image, fotoBIG = get_Picture(teaser)
						debug_MS("(navigator.listMagazines) ready ### NAME = {0} || PID = {1} ###".format(title, PID))
						addDir(title, image, {'mode': 'listCollections', 'url': PID, 'extras': image, 'background': fotoBIG}, plot=plot)
		elif not 'CHU/' in url and not 'HOME/' in url and not 'SES/' in url:
			PID = str(magITEM['programId'])
			title = cleaning(magITEM['title'])
			plot = get_Description(magITEM)
			image, fotoBIG = get_Picture(magITEM)
			debug_MS("(navigator.listMagazines) ready ### NAME = {0} || PID = {1} ###".format(title, PID))
			addDir(title, image, {'mode': 'listCollections', 'url': PID, 'extras': image, 'background': fotoBIG}, plot=plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

# COLLECTION_PROGRAM, COLLECTION_UPCOMING, COLLECTION_ARTICLE
# https://www.arte.tv/guide/api/emac/v3/de/web/data/MANUAL_TEASERS/?code=collections_SER&zone=07b776c7-8cc5-41e7-a16f-e4a5b51730cb&page=1&limit=6 || RUBRIK - kurz und witzig unter Serien
# https://api-internal.arte.tv/api/emac/v3/de/web/data/MANUAL_TEASERS/?imageFormats=landscape&authorizedAreas=DE_FR%2CEUR_DE_FR%2CSAT%2CALL&code=collections_DEC&zone=94d2d049-5860-42ba-9175-c07e856ef10f&page=2&limit=6
def listCollections(url, photo, fotoBIG):
	COMBI = []
	prefer = ['collection_videos', 'collection_subcollection']
	result = getUrl(API_URL+url, CALL_PRO=EMAC_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listCollections) CONTENT : {0}".format(str(result)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(result)
	FOUND = 0
	FILTER = filter(lambda item: item['data'] and item['title'] != None and any(x in item['code']['name'].lower() for x in prefer), DATA['zones'])
	for zone in FILTER:
		title = cleaning(zone['title'])
		collection = zone['code']['name'].upper()
		CID = str(zone['code']['id'])
		newURL = API_URL+'data/'+collection+'/?collectionId='+CID # https://api-cdn.arte.tv/api/emac/v3/de/web/data/COLLECTION_SUBCOLLECTION/?collectionId=RC-014035&subCollectionId=RC-017486&page=2
		if collection == 'COLLECTION_SUBCOLLECTION':
			newURL = API_URL+'data/'+collection+'/?collectionId='+CID.split('_')[0]+'@subCollectionId='+CID.split('_')[1]
		debug_MS("(navigator.listCollections) ### NAME = {0} || COLLECTION = {1} || CID = {2} ###".format(title, collection, CID))
		FOUND += 1
		COMBI.append([title, collection, newURL])
	if FOUND < 2:
		listEpisodes(newURL, '1')
		debug_MS("(navigator.listCollections) ----- Nothing FOUND - goto = listEpisodes -----")
	else:
		for title, collection, newURL in COMBI:
			addDir(title, photo, {'mode': 'listEpisodes', 'url': newURL, 'background': fotoBIG})
	xbmcplugin.endOfDirectory(ADDON_HANDLE) 

def listSelection():
	i = -20
	while i <= 20:
		WU = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
		WT = (datetime.now() - timedelta(days=i)).strftime('%a~%d.%m.%Y')
		if COUNTRY == 'de':
			MD = WT.split('~')[0].replace('Mon', translation(30621)).replace('Tue', translation(30622)).replace('Wed', translation(30623)).replace('Thu', translation(30624)).replace('Fri', translation(30625)).replace('Sat', translation(30626)).replace('Sun', translation(30627))
		elif COUNTRY == 'fr':
			MD = WT.split('~')[0].replace('Mon', 'Lundi').replace('Tue', 'Mardi').replace('Wed', 'Mercredi').replace('Thu', 'Jeudi').replace('Fri', 'Vendredi').replace('Sat', 'Samedi').replace('Sun', 'Dimanche')
		if i == 0: addDir("[COLOR lime]"+WT.split('~')[1]+" | "+MD+"[/COLOR]", icon, {'mode': 'videosByDate', 'url': starting['byDate']+WU})
		else: addDir(WT.split('~')[1]+" | "+MD, icon, {'mode': 'videosByDate', 'url': starting['byDate']+WU})
		i += 1
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def videosByDate(url):
	debug_MS("(navigator.videosByDate) ------------------------------------------------ START = videosByDate -----------------------------------------------")
	debug_MS("(navigator.videosByDate) URL : {0}".format(url)) # URL-Tag = https://api-cdn.arte.tv/api/emac/v3/de/web/pages/TV_GUIDE/?day=2019-12-08
	result = getUrl(url, CALL_PRO=EMAC_token)
	DATA = json.loads(result)
	for movie in DATA['zones'][-1]['data']:
		if "FULL_VIDEO" in str(movie.get('stickers')):
			LINKING(movie, '(videosByDate)')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listRunTime():
	debug_MS("(navigator.listRunTime) ------------------------------------------------ START = listRunTime -----------------------------------------------")
	newURL = API_URL+'data/VIDEO_LISTING/?videoType='
	if COUNTRY == 'de':
		addDir(translation(30628), icon, {'mode': 'listEpisodes', 'url': newURL+'SHORT_DURATION'})
		addDir(translation(30629), icon, {'mode': 'listEpisodes', 'url': newURL+'MEDIUM_DURATION'})
		addDir(translation(30630), icon, {'mode': 'listEpisodes', 'url': newURL+'LONG_DURATION'})
		addDir(translation(30631), icon, {'mode': 'listEpisodes', 'url': newURL+'LONGER_DURATION'})
	elif COUNTRY == 'fr':
		addDir('Vidéos 0 à 5 min.', icon, {'mode': 'listEpisodes', 'url': newURL+'SHORT_DURATION'})
		addDir('Vidéos 5 à 15 min.', icon, {'mode': 'listEpisodes', 'url': newURL+'MEDIUM_DURATION'})
		addDir('Vidéos 15 à 60 min.', icon, {'mode': 'listEpisodes', 'url': newURL+'LONG_DURATION'})
		addDir('Vidéos > 60 min.', icon, {'mode': 'listEpisodes', 'url': newURL+'LONGER_DURATION'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchArte():
	debug_MS("(navigator.SearchArte) ------------------------------------------------ START = SearchArte -----------------------------------------------")
	word = None # SEARCH = https://api-cdn.arte.tv/api/emac/v3/de/web/data/SEARCH_LISTING/?query=b%C3%A4ren&page=1&limit=50
	word = dialog.input("Search ARTE ...", type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
	if not word: return
	return listEpisodes(starting['search']+quote_plus(word), '1')

def listEpisodes(url, PAGE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### URL : {0} || PAGE : {1} ###".format(url, PAGE))
	FOUND = 0
	url = url.replace('@', '&').replace(' ', '+')+'&page='+PAGE+'&limit=50' if int(PAGE) == 1 else url
	# DURATION = https://api-cdn.arte.tv/api/emac/v3/de/web/data/VIDEO_LISTING/?videoType=LONGER_DURATION&page=2&limit=20 || SEARCH = https://api-cdn.arte.tv/api/emac/v3/de/web/data/SEARCH_LISTING/?query=europe&page=2&limit=20
	# STANDARD =  https://api-cdn.arte.tv/api/emac/v3/de/web/data/VIDEO_LISTING/?videoType=MOST_VIEWED&page=1&limit=20
	debug_MS("(navigator.listEpisodes) complete JSON-URL : {0}".format(url))
	result = getUrl(url, CALL_PRO=EMAC_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listEpisodes) RESULT : {0}".format(str(result)))
	debug_MS("++++++++++++++++++++++++")
	DATA = json.loads(result)
	for movie in DATA['data']:
		if str(movie.get('duration')) not in ['', 'None', '0']:
			FOUND += 1
			LINKING(movie, '(listEpisodes)')
	try: # NEXTPAGE = https://api-cdn.arte.tv/api/emac/v3/de/web/data/COLLECTION_SUBCOLLECTION/?collectionId=RC-014035&subCollectionId=RC-015171&page=2&limit=20
		nextPG = DATA["nextPage"]
		debug_MS("(navigator.listEpisodes) This is NextPage : {0}".format(nextPG))
		if nextPG[:4] == "http":
			debug_MS("(navigator.listEpisodes) Now show NextPage ...")
			addDir(translation(30640), artpic+'nextpage.png', {'mode': 'listEpisodes', 'url': nextPG, 'page': int(PAGE)+1})
	except: pass
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	# Übergabe des Abspiellinks von anderem Video-ADDON: plugin://plugin.video.tyl0re.arte/?mode=playVideo&url=048256-000-A oder: plugin://plugin.video.tyl0re.arte/?mode=playVideo&url=https://www.arte.tv/de/videos/048256-000-A/wir-waren-koenige/
	MEDIAS = []
	finalURL = False
	try:
		PLID = re.compile('/videos/(.+?)/', re.DOTALL).findall(url)[0] if url[:4] == "http" else url
		debug_MS("----->")
		debug_MS("(navigator.playVideo) ### PLID : {0} ###".format(str(PLID)))
		if COUNTRY == 'de':
			SHORTCUTS = ['DE', 'OmU', 'OV', 'VO'] # "DE" = Original deutsch | "OmU" = Original mit deutschen Untertiteln | "OV" = Stumm oder Originalversion
		elif COUNTRY == 'fr':
			SHORTCUTS = ['VOF', 'VF', 'VOSTF', 'VO'] # "VOF" = Original französisch | "VF" = französisch vertont | "VOSTF" = Stumm oder Original mit französischen Untertiteln
		#content = getUrl('https://api.arte.tv/api/player/v2/config/'+COUNTRY+'/'+str(PLID), CALL_PRO=PLAY_token)
		content = getUrl('https://api.arte.tv/api/player/v1/config/'+COUNTRY+'/'+str(PLID)+'?autostart=0&lifeCycle=1')
		stream = json.loads(content)['videoJsonPlayer']
		stream_offer = stream['VSR']
		for element in stream_offer:
			if int(stream['VSR'][element]['versionProg']) == 1 and stream['VSR'][element]['mediaType'].lower() == "mp4":
				debug_MS("(playVideo) ### Stream-Element : {0} ###".format(str(stream['VSR'][element])))
				for found in SHORTCUTS:
					if stream['VSR'][element]['versionShortLibelle'] == found and stream['VSR'][element]['height'] == prefQUALITY:
						MEDIAS.append({'streamURL': stream['VSR'][element]['url']})
						finalURL = MEDIAS[0]['streamURL']
				if not finalURL:
					if stream['VSR'][element]['height'] == prefQUALITY:
						finalURL = stream['VSR'][element]['url']
		debug_MS("(navigator.playVideo) ### Quality-Setting : {0} ###".format(str(prefQUALITY)))
		log("(navigator.playVideo) StreamURL : {0}".format(str(finalURL)))
		debug_MS("<-----")
		if finalURL: 
			listitem = xbmcgui.ListItem(path=finalURL)
			listitem.setContentLookup(False)
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
		else: return dialog.notification(translation(30521).format('VIDEO - URL'), translation(30526), icon, 8000)
	except: return dialog.notification(translation(30521).format('VIDEO - URL'), translation(30527), icon, 8000)

def playLive(url, name):
	listitem = xbmcgui.ListItem(path=url, label=name)
	listitem.setMimeType('application/vnd.apple.mpegurl')
	xbmc.Player().play(item=url, listitem=listitem)

def liveTV():
	debug_MS("(navigator.liveTV) ------------------------------------------------ START = liveTV -----------------------------------------------")
	items = []
	items.append([translation(30641), "https://artelive-lh.akamaihd.net/i/artelive_de@393591/index_1_av-p.m3u8", artpic+'livestream.png'])
	items.append([translation(30642), "https://artehlsevent01-i.akamaihd.net/hls/live/252715/channel01/master.m3u8", artpic+'livestream.png'])
	items.append([translation(30643), "https://artehlsevent02-i.akamaihd.net/hls/live/252716/channel02/master.m3u8", artpic+'livestream.png'])
	items.append([translation(30644), "https://artehlsevent03-i.akamaihd.net/hls/live/252717/channel03/master.m3u8", artpic+'livestream.png'])
	items.append([translation(30645), "https://artehlsevent04-i.akamaihd.net/hls/live/252718/channel04/master.m3u8", artpic+'livestream.png'])
	items.append([translation(30646), "https://artehlsevent05-i.akamaihd.net/hls/live/252719/channel05/master.m3u8", artpic+'livestream.png'])
	for item in items:
		listitem = xbmcgui.ListItem(path=item[1], label=item[0])
		listitem.setArt({'icon': icon, 'thumb': item[2], 'poster': item[2], 'fanart': defaultFanart})
		xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+"?mode=playLive&url="+quote_plus(item[1])+"&name="+item[0], listitem=listitem)  
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def LINKING(info, extras=None):
	u = '{0}?mode=playVideo&url={1}'.format(HOST_AND_PATH, quote_plus(info['url']))
	liz = get_ListItem(info, extras)
	if liz is None: return
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)

def addDir(name, image, params={}, tagline=None, plot=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Tagline': tagline})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image != icon and not artpic in image and params.get('background') != 'KEIN HINTERGRUND':
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)
