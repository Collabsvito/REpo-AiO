﻿# -*- coding: utf-8 -*-

import xbmcaddon

if __name__ == '__main__':
	xbmcaddon.Addon().setSetting('maximum_tries', '1')
