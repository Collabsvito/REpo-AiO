﻿# -*- coding: utf-8 -*-

from .common import *


class clientMaster():
	def __init__(self, *args, **kwargs):
		super(clientMaster, self).__init__()
		self.expire_public = 3595 # max. Token-Time (Seconds) before clear the Token and delete Token-File [3595 = 60 Minutes]
		self.tempSTORE = tempSTORE
		self.savePUBLIC = publicSECRET

	def main_menu(self):
		item_uno = create_entries({'Title': translation(30601), 'Plot': translation(30602), \
			'Image': f"{artpic}livestream.png", 'Mediatype': 'video', 'Reference': 'Single'})
		self.add_views({'mode': 'play_live'}, item_uno)
		for title, action in [(30603, {'mode': 'list_species', 'marker': 'newest'}), (30604, {'mode': 'list_species', 'marker': 'oldest'}),
			(30605, {'mode': 'list_movies'}), (30606, {'mode': 'list_series'})]:
			self.add_views(action, create_entries({'Title': translation(title), 'Image': f"{artpic}icon.png"}), True)
		if enable_tune:
			self.add_views({'mode': 'antuning'}, create_entries({'Title': translation(30608), 'Image': f"{artpic}settings.png"}))
		xbmcplugin.endOfDirectory(ADDON_HANDLE)

	def list_species(self, mark):
		debug_MS("(navigator.list_species) ------------------------------------------------ START = list_species -----------------------------------------------")
		COMBI_UNO, COMBI_DUE, COMBI_TRE = ([] for _ in range(3))
		COMBI_UNO, COMBI_TRE = self.list_aurora('/page/mediathek/')
		for method in get_sorting('others'): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
		content, serve, adjust = 'publishStart' if mark == 'newest' else 'publishEnd', '2026-01-01T00:01', True if mark == 'newest' else False
		for each_due in sorted(self.fetch_pages(COMBI_UNO, 'collect'), key=lambda asx: asx.get(content, serve)[:16], reverse=adjust):
			com_slug = each_due.get('auraTicket', {}).get('secCipher', '')
			com_title = each_due.get('title', '') # get('title') für Episoden // get('item').get('title') für Filme
			com_ceas = (each_due.get('id', None) or each_due.get('ctaVideoId', None)) # get('id') für Episoden // get('item').get('id') oder get('ctaVideoId') für Filme
			com_brand = each_due.get('auraTicket', {}).get('secBrand', '')
			if mark == 'newest' and str(each_due.get('publishStart'))[:4].isdecimal():
				if parse_dates(each_due['publishStart']) < (datetime.utcnow() - timedelta(days=3)): continue # 3 Tage // 2026-05-15T02:00:00+00.00
			if mark == 'oldest' and str(each_due.get('publishEnd'))[:4].isdecimal():
				if parse_dates(each_due['publishEnd']) > (datetime.utcnow() + timedelta(days=3)): continue # 3 Tage // 2026-05-15T02:00:00+00.00
			COMBI_DUE.append([com_slug, com_title, com_ceas, com_brand, each_due])
		if COMBI_DUE:
			RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_TRE if av[0] == bv[2]]
			for xev in RESULT:
				if len(xev) >= 11: # Liste1+Liste2 = 13
					riders = {**xev[4], **{'auraPluss': {'secTitle': xev[6], 'secThumb': xev[11], 'secCover': xev[12], 'secTeaser': xev[13]}}}
					self.add_views({'mode': 'play_video', 'url': xev[2]}, create_entries(riders, 'COLLATE', 'novelties', xev[3]))
		xbmcplugin.endOfDirectory(ADDON_HANDLE)

	def list_movies(self):
		debug_MS("(navigator.list_movies) ------------------------------------------------ START = list_movies -----------------------------------------------")
		COMBI_UNO, COMBI_DUE, COMBI_TRE = ([] for _ in range(3))
		COMBI_UNO, COMBI_TRE = self.list_aurora('/page/mediathek/')
		for method in get_sorting('others'): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
		for each_due in self.fetch_pages(COMBI_UNO, 'movies'):
			mov_slug = each_due.get('auraTicket', {}).get('secCipher', '')
			mov_title = (each_due.get('title', '') or each_due.get('show', {}).get('title', '')) # get('item').get('title') oder get('show').get('title')
			mov_ceas = (each_due.get('id', None) or each_due.get('ctaVideoId', None)) # get('item').get('id') oder get('ctaVideoId')
			COMBI_DUE.append([mov_slug, mov_title, mov_ceas, each_due])
		if COMBI_DUE:
			RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_TRE if av[0] == bv[2]]
			for xev in RESULT:
				if len(xev) >= 11: # Liste1+Liste2 = 13
					riders = {**xev[3], **{'auraPluss': {'secTitle': xev[5], 'secThumb': xev[10], 'secCover': xev[11], 'secTeaser': xev[12]}}}
					self.add_views({'mode': 'play_video', 'url': xev[2]}, create_entries(riders, 'COLLATE', 'movie'))
		xbmcplugin.endOfDirectory(ADDON_HANDLE)

	def list_series(self):
		debug_MS("(navigator.list_series) ------------------------------------------------ START = list_series -----------------------------------------------")
		ISOLATE, (COMBI_UNO, COMBI_DUE, COMBI_TRE) = set(), ([] for _ in range(3))
		COMBI_UNO, COMBI_TRE = self.list_aurora('/page/mediathek/')
		for method in get_sorting('names'): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
		for each_due in sorted(self.fetch_pages(COMBI_UNO, 'series'), key=lambda asx: asx.get('publishStart', '2026-01-01T00:01')[:16], reverse=True):
			ser_slug = each_due.get('auraTicket', {}).get('secCipher', '')
			ser_title = (each_due.get('show', {}).get('title', '') or each_due.get('item', {}).get('show', {}).get('title', '')) # get('show').get('title') oder get('item').get('show').get('title')
			if ser_slug not in ISOLATE: # Nur jeweils einen Teil einer Serie behalten
				ISOLATE.add(ser_slug)
				COMBI_DUE.append([ser_slug, ser_title, each_due])
		if COMBI_DUE:
			RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_TRE if av[0] == bv[2]]
			for xev in sorted(RESULT, key=lambda nox: int(nox[2].get('auraTicket', {}).get('secCount', 1))): # Originalsortierung für Übersicht wiederherstellen
				if len(xev) >= 11: # Liste1+Liste2 = 12
					riders = {**xev[2], **{'auraPluss': {'secTitle': xev[4], 'secThumb': xev[9], 'secCover': xev[10], 'secTeaser': xev[11]}}}
					self.add_views({'mode': 'list_episodes', 'slug': f"/shows/{xev[0]}/"}, create_entries(riders, 'COLLATE', 'tvshow'), True)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)

	def list_episodes(self, series_slug):
		debug_MS("(navigator.list_episodes) ------------------------------------------------ START = list_episodes -----------------------------------------------")
		packs = self.track_content(AURA_HOST.format(series_slug), headers=DEFAULT_HEADERS)
		if packs is not None and packs.get('blocks', []) and len(packs['blocks']) > 1 and packs.get('blocks', {})[-1].get('items', {}):
			for riders in sorted(packs.get('blocks', {})[-1].get('items', {}), key=lambda sx: (int(sx.get('seasonNumber', 1)), int(sx.get('episodeNumber', 1)))):
				if 'NICHT IM PROGRAMM' in riders.get('subtitle', '').upper() or not str(riders.get('videoDuration')).isdecimal(): continue
				debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
				debug_MS(f"(navigator.list_episodes[1]) xxxxx EACH-01 : {riders} xxxxx")
				self.add_views({'mode': 'play_video', 'url': riders.get('id')}, create_entries(riders, 'COLLATE', 'episode'))
		xbmcplugin.endOfDirectory(ADDON_HANDLE)

	def list_aurora(self, purpose):
		UNIKAT, (COMBI_AURO, COMBI_LINKS) = set(), ([] for _ in range(2))
		mediathek = self.track_content(AURA_HOST.format(purpose), headers=DEFAULT_HEADERS)
		if mediathek is not None and mediathek.get('blocks', {}) and len(mediathek['blocks']) > 0:
			for num, each_uno in enumerate(mediathek['blocks'][0].get('items', {}), 1):
				teaser, (photo, portrait) = "", (None for _ in range(2))
				title = each_uno['title']
				showSlug = (each_uno.get('slug', None) or each_uno.get('url', None))
				if showSlug is None and each_uno.get('show', {}).get('title', ''):
					title, showSlug = cleaning(each_uno['show']['title']), clear_invalid(each_uno['show']['title']).lower()
				parentSlug = (each_uno.get('parentSlug', '') or each_uno.get('parentUrl', '') or each_uno.get('parentPage', {}).get('slug', ''))
				showID = (each_uno.get('attributes', {}).get('showId', '') or each_uno.get('show', {}).get('id', '') or each_uno.get('showId', '') or None)
				infos = (each_uno.get('attributes', {}).get('tuneinInfo', '') or each_uno.get('tuneinInfo', ''))
				if showSlug is None and showID is None: continue
				if 'NICHT IM PROGRAMM' not in infos.upper() and showSlug not in UNIKAT:
					UNIKAT.add(showSlug)
					debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
					debug_MS(f"(navigator.list_aurora[1]) xxxxx POSITION-01 : {num} || EACH-01 : {each_uno} xxxxx")
					if each_uno.get('metaMedia', '') and len(each_uno['metaMedia']) > 0:
						photo = [pox.get('media', {}).get('url', '') for pox in each_uno.get('metaMedia') if pox.get('role') == 'default'][0]
						portrait = [ptx.get('media', {}).get('url', '') for ptx in each_uno.get('metaMedia') if ptx.get('role') == 'preview'][0]
					if portrait is None and each_uno.get('image', '') and each_uno['image'].get('url', ''):
						portrait = each_uno['image']['url']
					if portrait is None and each_uno.get('poster', '') and each_uno['poster'].get('src', ''):
						photo = each_uno['poster']['src']
					if each_uno.get('articleContent', '') and len(each_uno['articleContent']) > 20:
						teaser = cleaning(each_uno['articleContent'])
					COMBI_LINKS.append([int(num), showSlug, AURA_HOST.format(f"/shows/{showSlug.lower()}/")])
					COMBI_AURO.append([int(num), title, showSlug, parentSlug, showID, infos, photo, portrait, teaser])
		return COMBI_LINKS, COMBI_AURO

	def play_video(self, video_id):
		debug_MS("(navigator.play_video) ------------------------------------------------ START = play_video -----------------------------------------------")
		debug_MS(f"(navigator.play_video) ### LINK = {AURA_PLAYER} ### PLID = {video_id} ###")
		STREAM, FINAL_URL, DRM_GUARD, DRM_SPECIES = (False for _ in range(4))
		coident = self.check_authtoken()
		payload = {'deviceInfo': {'adBlocker': False, 'drmSupported': True, 'hdrCapabilities': [], 'hwDecodingCapabilities': [], 'soundCapabilities': []}, 'wisteriaProperties': {}, 'videoId': str(video_id)}
		package = self.track_content(AURA_PLAYER, 'POST', 'JSON', {**STONE_HEADERS, **{'Authorization': f"Bearer {coident}"}}, data=json.dumps(payload, indent=2))
		for riders in package['data']['attributes']['streaming']:
			if riders.get('protection', {}).get('drmEnabled', False) is True and riders.get('type') =='dash':
				STREAM, MIME, FINAL_URL = 'MPD', 'application/dash+xml', riders['url']
				DRM_GUARD, DRM_TOKEN = riders['protection']['schemes']['widevine']['licenseUrl'], riders['protection']['drmToken']
				debug_MS("(navigator.play_video[1]) ***** TAKE - Inputstream (mpd) - FILE *****")
			if FINAL_URL is False and riders.get('type') == 'hls':
				STREAM, MIME, FINAL_URL = 'HLS', 'application/vnd.apple.mpegurl', riders['url']
				debug_MS("(navigator.play_video[1]) ***** TAKE - Inputstream (hls) - FILE *****")
		if FINAL_URL and STREAM and plugin_operate('inputstream.adaptive'):
			LPM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
			IA_NAME, IA_SYSTEM = 'inputstream.adaptive', 'com.widevine.alpha'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			DRM_HEADERS = {'PreAuthorization': DRM_TOKEN, 'Content-Type': 'application/octet-stream', 'User-Agent': HEAD_WEB} if DRM_GUARD else {}
			LPM.setMimeType(MIME); LPM.setProperty('inputstream', IA_NAME)
			if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", STREAM.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
			LPM.setProperty(f"{IA_NAME}.{PHRASE}_headers", f"User-Agent={HEAD_WEB}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
			if int(IA_VERSION) >= 2150 and STREAM in ['HLS', 'MPD']:
				DRM_SPECIES = {'DRM_System': 'org.w3.clearkey'} if STREAM == 'HLS' else {'DRM_System': IA_SYSTEM}
				if STREAM == 'MPD' and DRM_GUARD:
					DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS)}
				LPM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
			elif int(IA_VERSION) < 2150 and STREAM == 'MPD':
				LPM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
				if DRM_GUARD:
					DRM_SPECIES = {'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS), 'Post_Data': 'R{SSM}|'}
					LPM.setProperty(f"{IA_NAME}.license_key", '|'.join(DRM_SPECIES.values())) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
			if DRM_SPECIES: log(f"(navigator.play_video[2]) INPUTSTREAM_VERSION: {IA_VERSION} >>>>> LICENSE : {'|'.join(DRM_SPECIES.values())} <<<<<")
			log(f"(navigator.play_video) {STREAM}_stream : {FINAL_URL}|User-Agent={HEAD_WEB}")
			self.set_resolved(LPM, automatic=True)
			return
		else:
			failing(f"(navigator.play_video) ##### Abspielen des Streams NICHT möglich ##### PLID : {video_id} #####\n ########## KEINEN Stream-Eintrag gefunden !!! ##########")
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
			xbmc.PlayList(1).clear()
			return dialog.notification(translation(30521).format('PLAYER'), translation(30525), icon, 10000)

	def play_live(self):
		debug_MS("(navigator.play_live) ------------------------------------------------ START = play_live -----------------------------------------------")
		auth_page = self.track_content('https://embed.zattoo.com/token.json',
			headers = {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'DNT': '1', \
				'Content-Type': 'application/json; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/?partner_id=channel-embed'})['session_token']
		live_page = self.track_content('https://embed.zattoo.com/zapi/watch/live/tele-5', 'POST', \
			headers = {'Accept': 'application/json', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'Origin': 'https://embed.zattoo.com', \
				'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/client'}, \
			data = urlencode({'https_watch_urls': True, 'partner_site': 'tele5_de_channel', 'session_token': auth_page, 'stream_type': 'dash', 'uuid': make_uuid()}))
		debug_MS(f"(navigator.play_live[1]) ### FINAL_URL : {live_page['stream']['url']} ###")
		LTM = xbmcgui.ListItem(path=live_page['stream']['url'], offscreen=True)
		LTM.setProperty('inputstream', 'inputstream.adaptive')
		if KODI_BUILD in [19, 20]: LTM.setProperty('inputstream.adaptive.manifest_type', 'mpd')
		self.set_resolved(LTM)

	def fetch_pages(self, templates, trace):
		package = self.track_several(templates, 'GET', timeout=20)
		if package:
			combies = json.loads(package)
			for article in combies:
				if trace in ['collect', 'movies'] and article is not None and article.get('blocks', []) and len(article['blocks']) == 1 and article.get('blocks', {})[0].get('item', {}):
					num_one, code_one, mark_one = article.get('Position', 0), article.get('NaviCode', 'unknown'), 'MOVIES'
					for settle in article['blocks']:
						if settle['item'].get('show', {}) and settle.get('show', {}): settle['item']['show'] = settle['show'] # Kopiere Show-Ordner in 2. Ebene zu 'item.show'
						settle.update({k:v for k, v in settle['item'].items()}) # Kopiere Inhalt von 'item' ins Hauptverzeichnis
						settle.pop('item', None) # Lösche 'item' Ordner komplett
						if ('NICHT IM PROGRAMM' in settle.get('subtitle', '').upper()) or (not str(settle.get('videoDuration')).isdecimal()) or \
							(str(settle.get('seasonNumber')).isdecimal() and int(settle['seasonNumber']) > 1) or (code_one == 'unknown') or \
							(str(settle.get('episodeNumber')).isdecimal() and int(settle['episodeNumber']) > 1): continue
						embrace_one = {**settle, **{'auraTicket': {'secCount': num_one, 'secCipher': code_one, 'secBrand': mark_one}}}
						debug_MS("---------------------------------------------")
						debug_MS(f"(navigator.fetch_pages[2]) {mark_one} ### POSITION-02 : {num_one} || SLUG-02 : {code_one} || ENTRY-02 : {embrace_one} ###")
						yield embrace_one
				if trace in ['collect', 'series'] and article is not None and article.get('blocks', []) and len(article['blocks']) > 1 and article.get('blocks', {})[-1].get('items', {}):
					num_two, code_two, mark_two = article.get('Position', 0), article.get('NaviCode', 'unknown'), 'SERIES'
					for scraps in article.get('blocks', {})[-1].get('items', {}):
						secs_two = (scraps.get('videoDuration', '') or scraps.get('item', {}).get('videoDuration', ''))
						if not str(secs_two).isdecimal() or code_two == 'unknown': continue # get('videoDuration) für Collect // get('item).get('videoDuration) für Series
						embrace_two = {**scraps, **{'auraTicket': {'secCount': num_two, 'secCipher': code_two, 'secBrand': mark_two}}}
						debug_MS("---------------------------------------------")
						debug_MS(f"(navigator.fetch_pages[3]) {mark_two} ### POSITION-03 : {num_two} || SLUG-03 : {code_two} || ENTRY-03 : {embrace_two} ###")
						yield embrace_two

	def track_content(self, url, method='GET', queries='JSON', headers={}, redirects=True, data=None, json=None, timeout=30):
		attempts, ANSWER, headers = 0, None, {**headers, **{'User-Agent': HEAD_WEB}}
		while not ANSWER and attempts < 2: # 2 x Pingversuche für den Request ::: zur Überprüfung der Verfügbarkeit der URL
			attempts += 1
			try:
				response = requests.request(method, url, headers=headers, allow_redirects=redirects, data=data, json=json, timeout=timeout)
				ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
				debug_MS(f"(navigator.track_content) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} || DATA : {data} ===")
				if queries == 'JSON' and not isinstance(ANSWER, list) and ANSWER.get('errors', {}):
					message = (ANSWER.get('errors', {})[0].get('detail', '') or 'NO DETAILS FOUND')
					failing(f"(navigator.track_content) ERROR - RESPONSE - ERROR ##### URL : {url} === DETAILS : {message} #####")
					dialog.notification(translation(30521).format('URL'), translation(30523).format(message), icon, 12000)
					return sys.exit(0)
				response.raise_for_status()
			except Exception as exc: # No JSON object could be decoded
				failing(f"(navigator.track_content) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {exc} #####")
				dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 12000)
				sleep(2)
				if attempts >= 2: return sys.exit(0)
		return ANSWER

	def track_several(self, stacks, method='GET', queries='JSON', redirects=True, timeout=5, workers=20):
		COMBI_NEW, number, counter, fixation, = [], len(stacks), 0, requests.Session()
		fixation.mount('https://', HTTPAdapter(pool_connections=int(number), pool_maxsize=int(number), pool_block=True)) # Pool-Verbindungen und -Grösse auf tatsächlichen Inhalt festlegen, um Fehlermeldungen zu vermeiden
		def download(pos, code, link, coident):
			heading = {**STONE_HEADERS, **{'User-Agent': HEAD_WEB, 'Authorization': f"Bearer {coident}"}}
			try:
				response = fixation.request(method, link, headers=heading, allow_redirects=redirects, timeout=timeout)
				response.raise_for_status()
				debug_MS(f"(navigator.track_several[1]) === POS : {pos} || STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
				return f'{{"Position":{pos},"NaviCode":"{code}","Demand":"{link}",{response.text[1:-1]}}}'
			except Exception as exc_uno:
				failing(f"(navigator.track_several[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === URL : {link} === FAILURE : {exc_uno} #####")
				return f'{{"Position":{pos},"Status":"ERROR"}}'
		with ThreadPoolExecutor(max_workers=workers) as executor:
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
			coident = self.check_authtoken()
			picker = [executor.submit(download, pos, code, link, coident) for pos, code, link in stacks]
			wait(picker, timeout=30, return_when=ALL_COMPLETED)
			for future, section in zip(as_completed(picker), stacks):
				counter += 1
				try:
					COMBI_NEW.append(json.loads(future.result()))
				except Exception as exc_due:
					if counter == 1: dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(exc_due), f"{artpic}icon.png", 12000)
					failing(f"(navigator.track_several[2]) ERROR - EXEPTION - ERROR ##### POS : {section[0]} === URL : {section[2]} === FAILURE : {exc_due} #####")
					executor.shutdown()
			if COMBI_NEW:
				matching = [flop for flop in COMBI_NEW[:] if flop.get('Status', 'OOKAY') == 'ERROR']
				if len(matching) == number or len(matching) > 6:
					dialog.notification(translation(30521).format('DETAILS'), translation(30524), f"{artpic}icon.png", 12000)
		return json.dumps(COMBI_NEW, indent=2)

	def convert_epoch(self, epoch):
		CIPHER = datetime(1970,1,1) + timedelta(seconds=int(epoch))
		return CIPHER.strftime('%d.%m.%Y - %H:%M:%S')

	def check_authtoken(self):
		CODING, forceRenew, SWITCH = False, False, None
		GUARDIA, SECURITY, self.TIME_UTC = self.tempSTORE, self.savePUBLIC, time()
		if SECURITY is not None and os.path.isfile(SECURITY):
			try:
				self.TOKEN_UTC = (os.path.getmtime(SECURITY) + self.expire_public)
				debug_MS(f"(navigator.check_authtoken) ### SESSION-Time (utc NOW) = {self.convert_epoch(self.TIME_UTC)} || VALID until (utc SESSION) = {self.convert_epoch(self.TOKEN_UTC)} ###")
				if self.TIME_UTC < self.TOKEN_UTC and preserve(SECURITY) is not None:
					SWITCH = preserve(SECURITY)['data']['attributes']['token']
					debug_MS("(navigator.check_authtoken) ### NOTHING CHANGED - TOKENFILE IS OKAY ###")
				else:
					debug_MS("(navigator.check_authtoken) ### TIMEOUT FOR TOKEN - DELETE TOKENFILE ###")
					forceRenew = True
			except:
				failing("(navigator.check_authtoken) XXXXX !!! ERROR = TOKENFILE [TOKENFORMAT IS INVALID] = ERROR !!! XXXXX")
				forceRenew = True
		else:
			debug_MS("(navigator.check_authtoken) ### NOTHING FOUND - CREATE TOKENFILE FOR DISCOVERY ###")
			forceRenew = True
		if forceRenew:
			if SECURITY is not None and os.path.isfile(SECURITY):
				shutil.rmtree(GUARDIA, ignore_errors=True)
			CODING = self.track_content(AURA_ACCESS, headers=STONE_HEADERS)
			if CODING:
				debug_MS(f"(navigator.check_authtoken) ***** NEW TOKENFILE CREATED : {CODING} *****")
				if not xbmcvfs.exists(GUARDIA) and not os.path.isdir(GUARDIA):
					xbmcvfs.mkdirs(GUARDIA)
				preserve(SECURITY, CODING)
				SWITCH = CODING['data']['attributes']['token']
		return SWITCH

	def set_resolved(self, listitem, automatic=False):
		listitem.setProperty('isPlayable', 'true')
		listitem.setContentLookup(False)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
		if automatic is True and clamps_player:
			from .player import discoMaster
			discoMaster().start_signal()

	def add_views(self, params, listitem, folder=False):
		uws = build_mass(params)
		listitem.setPath(uws)
		return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
