﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
from time import time, strftime, strptime, localtime, sleep
from datetime import datetime, timedelta
from calendar import timegm
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import parse_qsl, urlencode, quote_plus, unquote_plus
from uuid import uuid4 as make_uuid
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_desc						= addon.getAddonInfo('description')
addon_folder						= xbmcvfs.translatePath(addon.getAddonInfo('path'))
addon_profile					= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
tempSTORE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'tempSTORE', ''))
publicSECRET						= xbmcvfs.translatePath(os.path.join(tempSTORE, 'PUBLIC_SECRET'))
defaultFanart						= os.path.join(addon_folder, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addon_folder, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addon_folder, 'resources', 'media', '')
clamps_player					= (True if addon.getSetting('force_stopping') == 'true' else False)
complete_titles					= addon.getSetting('complete_titles') == 'true'
show_timer						= int(addon.getSetting('visual_remaining'))
using_fanart						= addon.getSetting('use_fanart') == 'true'
enable_tune						= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_BUILD						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2])
BASE_URL							= 'https://tele5.de/'
WEB_AGENT						= 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:152.0) Gecko/20100101 Firefox/152.0'
DEFAULT_HEADERS			= {'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json; charset=utf-8', 'DNT': '1', 'Accept-Encoding': 'gzip, deflate', \
	'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'sec-ch-ua-platform': 'Windows', 'Origin': BASE_URL[:-1], 'Referer': BASE_URL}
STONE_HEADERS				= {**DEFAULT_HEADERS, **{'X-Device-Info': 'STONEJS/1 (Unknown/Unknown; Windows/NT 10.0; Unknown)', \
	'X-disco-client': 'WEB:UNKNOWN:wbdatv:2.1.9', 'X-disco-params': 'realm=de'}}
PUBIS_START						= 'https://public.aurora.enhanced.live'
PUBIS_ENDES						= f"include=default,advancedSearch&filter[environment]=tele5&v=2" # 'dmaxde' = DMAX // 'hgtvde' = HGTV // 'tlcde' = TLC // 'tele5' = TELE5
AURA_NORM						= f"{PUBIS_START}/site/page/mediathek/?{PUBIS_ENDES}" # https://public.aurora.enhanced.live/site/page/mediathek/?include=default&filter[environment]=tele5&v=2
AURA_ITEMS						= f"{PUBIS_START}/site/page/{{}}/?{PUBIS_ENDES}&parent_slug=mediathek" # https://public.aurora.enhanced.live/site/page/mediathek/?include=default&filter[environment]=tele5&v=2
AURA_VIDEOS					= f"{PUBIS_START}/site/shows/{{}}/?{PUBIS_ENDES}"
AURA_PLAYER					= f"{PUBIS_START}/playback/v3/videoPlaybackInfo"
AURA_ACCESS					= f"{PUBIS_START}/token?realm=de" # https://public.aurora.enhanced.live/token?realm=de

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def plugin_operate(MARKING):
	check_uno = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
	answer_uno, answer_due = json.loads(check_uno), json.loads(f'{{"error": "{MARKING} NOT FOUND"}}')
	if not "error" in answer_uno.keys() and answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is False:
		try:
			xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{MARKING}","enabled":true}}}}')
			failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####")
		except: pass
		del answer_due
		check_due = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
		answer_due = json.loads(check_due)
	if (answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is True) or (answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is True):
		return True
	if answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is False:
		dialog.ok(addon_id, translation(30501).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Eine automatische Aktivierung ist leider NICHT möglich !!! #####")
	if "error" in answer_uno.keys() or "error" in answer_due.keys():
		dialog.ok(addon_id, translation(30502).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - INSTALLED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT installiert !!! #####")
	return False

def get_sorting(persist):
	if persist == 'names': return [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL]
	return [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL, xbmcplugin.SORT_METHOD_DURATION, xbmcplugin.SORT_METHOD_DATE]

def convert_times(TIMING=None, ROUNDED=True, PLACES=3):
	DEMAND = float(int(round(TIMING*1000))) if ROUNDED is True else float(int(TIMING*1000))
	if ROUNDED is True and PLACES == 3:
		return str(timedelta(milliseconds=DEMAND))[: - PLACES]
	return str(timedelta(milliseconds=DEMAND))

def parse_dates(periods):
	return datetime(*(strptime(periods[:19], '%Y-%m-%dT%H:%M:%S')[0:6]))

def parse_stamp(periods):
	return timegm(strptime(periods[:19], '%Y-%m-%dT%H:%M:%S'))

def calibre_stamp(terms, visual=False):
	timepoint = '%Y-%m-%dT%H:%M' if KODI_BUILD >= 20 and visual is True else '%d.%m.%Y'
	return strftime(timepoint, localtime(terms))# 2026-05-15T12:30:00 = NEWFORMAT // 15.05.2026 = OLDFORMAT

def render_duration(duration):
	if duration < 1: return ""
	elif duration < 60:
		return translation(30621).format(int(duration))
	elif duration < 3600:
		return translation(30622).format(int(duration // 60))
	elif duration < 86400:
		return translation(30623).format(int(duration // 3600))
	return translation(30624).format(int(duration // 86400))

def render_stamp(periods):
	actual = xbmc.getRegion('time') if abs(periods - time()) <= 43200 else xbmc.getRegion('dateshort')
	return strftime(actual, localtime(periods))

def preserve(store, facts=None, arrive=None):
	if facts is not None:
		with open(store, 'w') as topics:
			json.dump(facts, topics, indent=2, sort_keys=True)
	else:
		if xbmcvfs.exists(store) and os.path.exists(store) and os.stat(store).st_size > 0:
			with open(store, 'r') as topics:
				arrive = json.load(topics)
		return arrive

def clear_umlaut(changes):
	if changes is not None:
		for cm in (('Ä', 'Ae'), ('ä', 'ae'), ('Ö', 'Oe'), ('ö', 'oe'), ('Ü', 'Ue'), ('ü', 'ue'), ('ß', 'ss')):
			changes = changes.replace(*cm)
		changes = changes.strip()
	return changes

def clear_invalid(changes):
	if changes is not None: # Ersetze den Umlaut und bestimmte Zeichen, um einen Slug für die entsprechende TV-Show für den Weiterleitungs-Link zu generieren
		for cn in (('Ä', 'Ae'), ('ä', 'ae'), ('Ö', 'Oe'), ('ö', 'oe'), ('Ü', 'Ue'), ('ü', 'ue'), ('ß', 'ss'), ('&', 'und'), (',', ''), ('.', ''), (':', ''), ('!', ''), ('?', ''), ('(', ''), (')', ''),  (' - ', '-'), (' ', '-'), ('--', '-')):
			changes = changes.replace(*cn)
		changes = changes.strip()
	return changes

def cleaning(text):
	if text is not None:
		for tx in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\xc2\xb7', '-'),
			("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''),
			('&#xC4;', 'Ä'), ('&#xE4;', 'ä'), ('&#xD6;', 'Ö'), ('&#xF6;', 'ö'), ('&#xDC;', 'Ü'), ('&#xFC;', 'ü'), ('&#xDF;', 'ß'), ('&#x201E;', '„'), ('&#xB4;', '´'), ('&#x2013;', '-'), ('&#xA0;', ' '),
			('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
			("&rsquo;", "’"), ("&lsquo;", "‘"), ("&sbquo;", "’"), ('&rdquo;', '”'), ('&ldquo;', '“'), ('&bdquo;', '”'), ('&rsaquo;', '›'), ('lsaquo;', '‹'), ('&raquo;', '»'), ('&laquo;', '«'), ('\n', ' '), ('<br>', '[CR]'), ('</p><p>', '[CR]'),
			('\\xC4', 'Ä'), ('\\xE4', 'ä'), ('\\xD6', 'Ö'), ('\\xF6', 'ö'), ('\\xDC', 'Ü'), ('\\xFC', 'ü'), ('\\xDF', 'ß'), ('\\x201E', '„'), ('\\x28', '('), ('\\x29', ')'), ('\\x2F', '/'), ('\\x2D', '-'), ('\\x20', ' '), ('\\x3A', ':'), ("\\'", "'")):
			text = text.replace(*tx)
		text = re.sub(r'\<.*?\>', '', text).strip()
	return text

def create_entries(metas, version='DEFAULT', tables='video'):
	if version in ['COLLECT', 'NEWEST', 'OLDEST']:
		metas = {key: value for key, value in metas.items() if value is not None}
		#log(f"(common.create_entries[1]) xxxxx METAS-01 : {metas} xxxxx")
		duration, mpaa, utc_start, starting, airing, thumb, poster, show_name, season, episode, species = (None for _ in range(11))
		(new_vids, pigment), (note_1, story, note_2) = (False for _ in range(2)), ("" for _ in range(3))
		model = metas.get('videoType', 'UNKNOWN')
		if tables == 'novelties':
			tables, pigment = 'episode' if metas.get('BrandType') == 'SERIES' else 'movie', False if metas.get('BrandType') == 'SERIES' else True
		if str(metas.get('publishStart'))[:4].isdecimal():
			if parse_dates(metas['publishStart']) > (datetime.utcnow() - timedelta(days=3)): new_vids = True # 3 Tage // 2026-05-15T02:00:00+00.00
		if tables in ['episode', 'movie']: # Diese Einträge nur für Filme und Episoden nutzen
			duration = int(metas['videoDuration']) // 1000 if str(metas.get('videoDuration')).isdecimal() else None
			if str(metas.get('contentRating', {}).get('code')).isdecimal():
				mpaa = str(metas['contentRating']['code']) if str(metas['contentRating']['code']) != '0' else translation(30625)
			if str(metas.get('publishStart'))[:4].isdecimal():
				starting = calibre_stamp(parse_stamp(metas['publishStart']), visual=True)
				airing = calibre_stamp(parse_stamp(metas['publishStart']))
			if show_timer in [0, 1] and str(metas.get('publishEnd'))[:4].isdecimal():
				ending = parse_stamp(metas['publishEnd'])
				note_1 = render_duration(ending - time()) if show_timer == 0 else translation(30626).format(render_stamp(ending))
		thumb = (metas.get('poster', {}).get('src', None) or metas.get('meta', {}).get('thumbnailUrl', None))
		if tables in ['movie', 'tvshow']:
			thumb = (metas.get('show', {}).get('image', {}).get('url', None) or metas.get('ShowImage', None))
			poster = (metas.get('show', {}).get('poster', {}).get('url', None) or metas.get('ShowPoster', None))
		show_title = (metas.get('show', {}).get('title', '') or metas.get('ShowTitle', ''))
		if tables == 'episode': # Diese Einträge nur für Episoden nutzen
			show_name = cleaning(show_title)
			season = f"{int(metas['seasonNumber']):02}" if str(metas.get('seasonNumber')).isdecimal() and int(metas['seasonNumber']) != 0 else None
			episode = f"{int(metas['episodeNumber']):02}" if str(metas.get('episodeNumber')).isdecimal() and int(metas['episodeNumber']) != 0 else None
			story = metas['description'] if metas.get('description', None) else ""
		elif tables == 'movie': # Diesen Eintrag nur für Filme nutzen
			story = metas['show']['description'] if metas.get('show', {}).get('description', None) else ""
			if metas.get('show', {}).get('taxonomies', ''):
				species = ' / '.join(sorted([tax.get('title', '') for tax in metas['show']['taxonomies'] if tax.get('category') == 'genre' and not tax.get('title', 'UNK').upper().endswith(('FILME', 'PROGRAMM'))][:2]))
		note_2 = cleaning(story) if len(story) > 20 else metas.get('ShowTeaser', '')
		titling = cleaning(metas['title']) if tables in ['episode', 'movie'] else cleaning(show_title)
		pioneer = translation(30627).format(season, episode, titling) if tables == 'episode' and season and episode else \
			translation(30628).format(addon.getSetting('title_marking'), titling) if pigment is True else titling
		suffix = translation(30629) if new_vids is True else ""
		full_name = f"{pioneer}{suffix}" if version not in ['NEWEST', 'OLDEST'] else pioneer
		if version in ['NEWEST', 'OLDEST'] and complete_titles and show_name:
			full_name = f"{pioneer} - {show_name}"
		teaser = f"{show_name}[CR]{note_1}{note_2}" if show_name and note_1 != "" else f"{show_name}[CR][CR]{note_2}" if show_name and note_1 == "" else note_1+note_2
		metas = {'Title': full_name, 'TvShowTitle': show_name, 'Plot': teaser, 'Season': season,'Episode': episode, 'Duration': duration, \
			'Date': starting, 'Aired': airing, 'Genre': species, 'Mpaa': mpaa, 'Mediatype': tables, 'Image': thumb, 'Cover': poster, 'Reference': 'Single'}
	listitem = xbmcgui.ListItem(metas['Title'])
	vinfo = listitem.getVideoInfoTag() if KODI_BUILD >= 20 else {}
	if KODI_BUILD >= 20: vinfo.setTitle(metas['Title'])
	else: vinfo['Title'] = metas['Title']
	if metas.get('TvShowTitle', ''):
		if KODI_BUILD >= 20: vinfo.setTvShowTitle(metas['TvShowTitle'])
		else: vinfo['Tvshowtitle'] = metas['TvShowTitle']
	description = metas['Plot'] if metas.get('Plot') not in ['', 'None', None] else ' '
	if KODI_BUILD >= 20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if str(metas.get('Duration')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setDuration(int(metas['Duration']))
		else: vinfo['Duration'] = metas['Duration']
	if str(metas.get('Season')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setSeason(int(metas['Season']))
		else: vinfo['Season'] = metas['Season']
	if str(metas.get('Episode')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setEpisode(int(metas['Episode']))
		else: vinfo['Episode'] = metas['Episode']
	if metas.get('Date', ''):
		if KODI_BUILD >= 20: listitem.setDateTime(metas['Date'])
		else: vinfo['Date'] = metas['Date']
	if metas.get('Aired', ''):
		if KODI_BUILD >= 20: vinfo.setFirstAired(metas['Aired'])
		else: vinfo['Aired'] = metas['Aired']
	if str(metas.get('Aired'))[6:10].isdecimal():
		if KODI_BUILD >= 20: vinfo.setYear(int(metas['Aired'][6:10]))
		else: vinfo['Year'] = metas['Aired'][6:10]
	if metas.get('Genre', ''):
		if KODI_BUILD >= 20: vinfo.setGenres([metas['Genre']])
		else: vinfo['Genre'] = metas['Genre']
	if metas.get('Mpaa', ''):
		if KODI_BUILD >= 20: vinfo.setMpaa(metas['Mpaa'])
		else: vinfo['Mpaa'] = metas['Mpaa']
	if metas.get('Mediatype', ''):
		if KODI_BUILD >= 20: vinfo.setMediaType(metas['Mediatype'])
		else: vinfo['Mediatype'] = metas['Mediatype']
	picture = metas['Image'] if metas.get('Image') else f"{artpic}standard.png"
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'fanart': defaultFanart})
	if metas.get('Cover'): listitem.setArt({'poster': metas['Cover']})
	if using_fanart and picture and not artpic in picture:
		listitem.setArt({'fanart': picture})
	if metas.get('Reference') == 'Single':
		listitem.setProperty('IsPlayable', 'true')
	if KODI_BUILD < 20: listitem.setInfo('Video', vinfo)
	return listitem
