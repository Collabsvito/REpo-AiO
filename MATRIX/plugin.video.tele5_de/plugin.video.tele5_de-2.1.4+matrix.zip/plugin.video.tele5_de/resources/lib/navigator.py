﻿# -*- coding: utf-8 -*-

from .common import *
from .utilities import clientHelper


def main_menu():
	item_uno = create_entries({'Title': translation(30601), 'Plot': translation(30602), \
		'Image': f"{artpic}livestream.png", 'Mediatype': 'video', 'Reference': 'Single'})
	add_views({'mode': 'play_live'}, item_uno)
	for title, action in [(30603, {'mode': 'list_species', 'marker': 'newest'}), (30604, {'mode': 'list_species', 'marker': 'oldest'}),
		(30605, {'mode': 'list_movies'}), (30606, {'mode': 'list_series'})]:
		add_views(action, create_entries({'Title': translation(title), 'Image': f"{artpic}icon.png"}), True)
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30608), 'Image': f"{artpic}settings.png"}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_species(mark):
	debug_MS("(navigator.list_species) ------------------------------------------------ START = list_species -----------------------------------------------")
	COMBI_UNO, COMBI_DUE, COMBI_TRE = ([] for _ in range(3))
	COMBI_UNO, COMBI_TRE = list_aurora()
	for method in get_sorting('others'): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	content, serve, adjust = 'publishStart' if mark == 'newest' else 'publishEnd', '2026-01-01T00:01', True if mark == 'newest' else False
	for each_due in sorted(fetch_pages(COMBI_UNO, 'collect'), key=lambda asx: asx.get(content, serve)[:16], reverse=adjust):
		com_slug = each_due.get('auraTicket', {}).get('secCipher', '')
		com_title = each_due.get('title', '')
		com_ceas = (each_due.get('id', None) or each_due.get('videoId', None) or each_due.get('ctaVideoId', None)) # get('id') für Episoden // get('id') oder get('videoId') oder get('ctaVideoId') für Filme
		com_brand = each_due.get('auraTicket', {}).get('secBrand', '')
		if mark == 'newest' and str(each_due.get('publishStart'))[:4].isdecimal():
			if parse_dates(each_due['publishStart']) < (datetime.utcnow() - timedelta(days=3)): continue # 3 Tage // 2026-05-15T02:00:00+00.00
		if mark == 'oldest' and str(each_due.get('publishEnd'))[:4].isdecimal():
			if parse_dates(each_due['publishEnd']) > (datetime.utcnow() + timedelta(days=3)): continue # 3 Tage // 2026-05-15T02:00:00+00.00
		COMBI_DUE.append([com_slug, com_title, com_ceas, com_brand, each_due])
	if COMBI_DUE:
		RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_TRE if av[0] == bv[2]]
		for xev in RESULT:
			if len(xev) >= 11: # Liste1+Liste2 = 13
				riders = {**xev[4], **{'auraPluss': {'secTitle': xev[6], 'secThumb': xev[11], 'secCover': xev[12], 'secTeaser': xev[13]}}}
				add_views({'mode': 'play_video', 'url': xev[2]}, create_entries(riders, 'COLLATE', 'novelties', xev[3]))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_movies():
	debug_MS("(navigator.list_movies) ------------------------------------------------ START = list_movies -----------------------------------------------")
	COMBI_UNO, COMBI_DUE, COMBI_TRE = ([] for _ in range(3))
	COMBI_UNO, COMBI_TRE = list_aurora()
	for method in get_sorting('others'): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	for each_due in fetch_pages(COMBI_UNO, 'movies'):
		mov_slug = each_due.get('auraTicket', {}).get('secCipher', '')
		mov_title = (each_due.get('title', '') or each_due.get('show', {}).get('title', '')) # get('title') oder get('show').get('title')
		mov_ceas = (each_due.get('id', None) or each_due.get('videoId', None) or each_due.get('ctaVideoId', None)) # get('id') oder get('videoId') oder get('ctaVideoId')
		COMBI_DUE.append([mov_slug, mov_title, mov_ceas, each_due])
	if COMBI_DUE:
		RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_TRE if av[0] == bv[2]]
		for xev in RESULT:
			if len(xev) >= 11: # Liste1+Liste2 = 13
				riders = {**xev[3], **{'auraPluss': {'secTitle': xev[5], 'secThumb': xev[10], 'secCover': xev[11], 'secTeaser': xev[12]}}}
				add_views({'mode': 'play_video', 'url': xev[2]}, create_entries(riders, 'COLLATE', 'movie'))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_series():
	debug_MS("(navigator.list_series) ------------------------------------------------ START = list_series -----------------------------------------------")
	ISOLATE, (COMBI_UNO, COMBI_DUE, COMBI_TRE) = set(), ([] for _ in range(3))
	COMBI_UNO, COMBI_TRE = list_aurora()
	for method in get_sorting('names'): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	for each_due in sorted(fetch_pages(COMBI_UNO, 'series'), key=lambda asx: asx.get('publishStart', '2026-01-01T00:01')[:16], reverse=True):
		ser_slug = each_due.get('auraTicket', {}).get('secCipher', '')
		ser_title = each_due.get('show', {}).get('title', '')
		if ser_slug not in ISOLATE: # Nur jeweils einen Teil einer Serie behalten
			ISOLATE.add(ser_slug)
			COMBI_DUE.append([ser_slug, ser_title, each_due])
	if COMBI_DUE:
		RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_TRE if av[0] == bv[2]]
		for xev in sorted(RESULT, key=lambda nox: int(nox[2].get('auraTicket', {}).get('secCount', 1))): # Originalsortierung für Übersicht wiederherstellen
			if len(xev) >= 11: # Liste1+Liste2 = 12
				riders = {**xev[2], **{'auraPluss': {'secTitle': xev[4], 'secThumb': xev[9], 'secCover': xev[10], 'secTeaser': xev[11]}}}
				add_views({'mode': 'list_episodes', 'slug': xev[0]}, create_entries(riders, 'COLLATE', 'tvshow'), True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes(series_slug):
	debug_MS("(navigator.list_episodes) ------------------------------------------------ START = list_episodes -----------------------------------------------")
	combies = clientHelper().track_content(AURA_ITEMS.format(series_slug), headers=DEFAULT_HEADERS)
	for article in combies.get('blocks', []):
		if article.get('type') == 'sonicShowBlock' and article.get('items', {}):
			for riders in sorted(article.get('items', {}), key=lambda sx: (int(sx.get('seasonNumber', 1)), int(sx.get('episodeNumber', 1)))):
				if 'NICHT IM PROGRAMM' in riders.get('subtitle', '').upper() or not str(riders.get('videoDuration')).isdecimal(): continue
				debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
				debug_MS(f"(navigator.list_episodes[1]) xxxxx EACH-01 : {riders} xxxxx")
				add_views({'mode': 'play_video', 'url': riders.get('id')}, create_entries(riders, 'COLLATE', 'episode'))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_aurora():
	UNIKAT, (COMBI_AURO, COMBI_LINKS) = set(), ([] for _ in range(2))
	mediathek = clientHelper().track_content(AURA_NORM, headers=DEFAULT_HEADERS)
	if mediathek is not None and mediathek.get('blocks', {}) and len(mediathek['blocks']) > 0:
		for block in mediathek['blocks']:
			if block.get('type') == 'categoryCollectionBlock' and block.get('items', {}):
				for num, each_uno in enumerate(block.get('items', {}), 1):
					teaser, (photo, portrait) = "", (None for _ in range(2))
					title = each_uno['title']
					showSlug = (each_uno.get('slug', None) or each_uno.get('url', None))
					if showSlug is None and each_uno.get('show', {}).get('title', ''):
						title, showSlug = cleaning(each_uno['show']['title']), clear_invalid(each_uno['show']['title']).lower()
					parentSlug = (each_uno.get('parentSlug', '') or each_uno.get('parentUrl', '') or each_uno.get('parentPage', {}).get('slug', ''))
					showID = (each_uno.get('attributes', {}).get('showId', '') or each_uno.get('show', {}).get('id', '') or each_uno.get('showId', '') or None)
					infos = (each_uno.get('attributes', {}).get('tuneinInfo', '') or each_uno.get('tuneinInfo', ''))
					if showSlug is None and showID is None: continue
					if 'NICHT IM PROGRAMM' not in infos.upper() and showSlug not in UNIKAT:
						UNIKAT.add(showSlug)
						debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
						debug_MS(f"(navigator.list_aurora[1]) xxxxx POSITION-01 : {num} || EACH-01 : {each_uno} xxxxx")
						if each_uno.get('metaMedia', '') and len(each_uno['metaMedia']) > 0:
							photo = [pox.get('media', {}).get('url', '') for pox in each_uno.get('metaMedia') if pox.get('role') == 'default'][0]
							portrait = [ptx.get('media', {}).get('url', '') for ptx in each_uno.get('metaMedia') if ptx.get('role') == 'preview'][0]
						if portrait is None and each_uno.get('image', '') and each_uno['image'].get('url', ''):
							portrait = each_uno['image']['url']
						if portrait is None and each_uno.get('poster', '') and each_uno['poster'].get('src', ''):
							photo = each_uno['poster']['src']
						if each_uno.get('articleContent', '') and len(each_uno['articleContent']) > 20:
							teaser = cleaning(each_uno['articleContent'])
						COMBI_LINKS.append([int(num), showSlug, AURA_ITEMS.format(showSlug.lower())])
						COMBI_AURO.append([int(num), title, showSlug, parentSlug, showID, infos, photo, portrait, teaser])
	return COMBI_LINKS, COMBI_AURO

def play_video(video_id):
	debug_MS("(navigator.play_video) ------------------------------------------------ START = play_video -----------------------------------------------")
	debug_MS(f"(navigator.play_video) ### LINK = {AURA_PLAYER} ### PLID = {video_id} ###")
	STREAM, FINAL_URL, DRM_GUARD, DRM_SPECIES = (False for _ in range(4))
	payload = {'deviceInfo': {'adBlocker': False, 'drmSupported': True, 'hdrCapabilities': [], 'hwDecodingCapabilities': [], 'soundCapabilities': []}, 'wisteriaProperties': {}, 'videoId': str(video_id)}
	package = clientHelper().track_content(AURA_PLAYER, 'POST', headers=STONE_HEADERS, data=json.dumps(payload, indent=2))
	for riders in package['data']['attributes']['streaming']:
		if riders.get('protection', {}).get('drmEnabled', False) is True and riders.get('type') =='dash':
			STREAM, MIME, FINAL_URL = 'MPD', 'application/dash+xml', riders['url']
			DRM_GUARD, DRM_TOKEN = riders['protection']['schemes']['widevine']['licenseUrl'], riders['protection']['drmToken']
			debug_MS("(navigator.play_video[1]) ***** TAKE - Inputstream (mpd) - FILE *****")
		if FINAL_URL is False and riders.get('type') == 'hls':
			STREAM, MIME, FINAL_URL = 'HLS', 'application/vnd.apple.mpegurl', riders['url']
			debug_MS("(navigator.play_video[1]) ***** TAKE - Inputstream (hls) - FILE *****")
	if FINAL_URL and STREAM and plugin_operate('inputstream.adaptive'):
		LPM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		IA_NAME, IA_SYSTEM = 'inputstream.adaptive', 'com.widevine.alpha'
		IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
		DRM_HEADERS = {'PreAuthorization': DRM_TOKEN, 'Content-Type': 'application/octet-stream', 'User-Agent': HEAD_WEB} if DRM_GUARD else {}
		LPM.setMimeType(MIME); LPM.setProperty('inputstream', IA_NAME)
		if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", STREAM.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
		PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
		LPM.setProperty(f"{IA_NAME}.{PHRASE}_headers", f"User-Agent={HEAD_WEB}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
		if int(IA_VERSION) >= 2150 and STREAM in ['HLS', 'MPD']:
			DRM_SPECIES = {'DRM_System': 'org.w3.clearkey'} if STREAM == 'HLS' else {'DRM_System': IA_SYSTEM}
			if STREAM == 'MPD' and DRM_GUARD:
				DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS)}
			LPM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
		elif int(IA_VERSION) < 2150 and STREAM == 'MPD':
			LPM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
			if DRM_GUARD:
				DRM_SPECIES = {'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS), 'Post_Data': 'R{SSM}|'}
				LPM.setProperty(f"{IA_NAME}.license_key", '|'.join(DRM_SPECIES.values())) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
		if DRM_SPECIES: log(f"(navigator.play_video[2]) INPUTSTREAM_VERSION: {IA_VERSION} >>>>> LICENSE : {'|'.join(DRM_SPECIES.values())} <<<<<")
		log(f"(navigator.play_video) {STREAM}_stream : {FINAL_URL}|User-Agent={HEAD_WEB}")
		return set_resolved(LPM, automatic=True)
	else:
		failing(f"(navigator.play_video) ##### Abspielen des Streams NICHT möglich ##### PLID : {video_id} #####\n ########## KEINEN Stream-Eintrag gefunden !!! ##########")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		xbmc.PlayList(1).clear()
		return dialog.notification(translation(30521).format('PLAYER'), translation(30525), icon, 10000)

def play_live():
	debug_MS("(navigator.play_live) ------------------------------------------------ START = play_live -----------------------------------------------")
	auth_page = clientHelper().track_content('https://embed.zattoo.com/token.json',
		headers = {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'DNT': '1', \
			'Content-Type': 'application/json; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/?partner_id=channel-embed'})['session_token']
	live_page = clientHelper().track_content('https://embed.zattoo.com/zapi/watch/live/tele-5', 'POST', \
		headers = {'Accept': 'application/json', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'Origin': 'https://embed.zattoo.com', \
			'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/client'}, \
		data = urlencode({'https_watch_urls': True, 'partner_site': 'tele5_de_channel', 'session_token': auth_page, 'stream_type': 'dash', 'uuid': make_uuid()}))
	debug_MS(f"(navigator.play_live[1]) ### FINAL_URL : {live_page['stream']['url']} ###")
	LTM = xbmcgui.ListItem(path=live_page['stream']['url'], offscreen=True)
	LTM.setProperty('inputstream', 'inputstream.adaptive')
	if KODI_BUILD in [19, 20]: LTM.setProperty('inputstream.adaptive.manifest_type', 'mpd')
	return set_resolved(LTM)

def fetch_pages(templates, trace):
	package = clientHelper().track_several(templates, 'GET', timeout=20)
	if package:
		combies = json.loads(package)
		for article in combies:
			movie_table, movie_section = (None for _ in range(2))
			if trace in ['collect', 'series', 'movies'] and article is not None and article.get('blocks', {}) and len(article['blocks']) > 0 and any(sonic.get('type') == 'sonicShowBlock' for sonic in article.get('blocks', {})):
				num_two, code_two, mark_two = article.get('Position', 0), article.get('NaviCode', 'unknown'), 'SERIES'
				movie_table = next(filter(lambda mov: mov.get('type') == 'showHeaderBlock' and mov.get('item', {}), article['blocks']), None) # Suche nach den Inhalten im 'show' Ordner
				for scraps in article['blocks']:
					if scraps.get('type') == 'sonicShowBlock' and scraps.get('items', {}):
						for single in scraps.get('items', {}):
							if str(single.get('videoDuration')).isdecimal() and int(single['videoDuration']) // 1000 > 4500: # Sende diesen 'item' zur Kategorie: MOVIES, da dieser länger als 75 Minuten (4500 Sekunden) ist
								movie_section = {'Position': num_two, 'NaviCode': code_two}
							if not str(single.get('videoDuration')).isdecimal() or code_two == 'unknown' or trace == 'movies' or movie_section: continue
							single.pop('features', None); single.pop('contentDescriptors', None); single.pop('package', None)
							embrace_two = {**single, **{'auraTicket': {'secCount': num_two, 'secCipher': code_two, 'secBrand': mark_two}}}
							debug_MS("---------------------------------------------")
							debug_MS(f"(navigator.fetch_pages[3]) {mark_two} ### POSITION-03 : {num_two} || SLUG-03 : {code_two} || ENTRY-03 : {embrace_two} ###")
							yield embrace_two
			if trace in ['collect', 'movies'] and article is not None and article.get('blocks', {}) and len(article['blocks']) > 0 and (not any(sonic.get('type') == 'sonicShowBlock' for sonic in article.get('blocks', {})) or (movie_section and movie_table)):
				num_one, code_one, mark_one = article.get('Position', 0), article.get('NaviCode', 'unknown'), 'MOVIES'
				show_table = next(filter(lambda sox: sox.get('type') == 'showHeaderBlock' and sox.get('show', {}), article['blocks']), None) # Suche nach den Inhalten im 'show' Ordner
				for settle in article['blocks']:
					if (settle.get('type') == 'sonicVideoBlock' and settle.get('item', {})) or (movie_section and movie_table and movie_table.get('item', {})):
						if movie_section: settle, num_one, code_one = movie_table, movie_section.get('Position', 0), movie_section.get('NaviCode', 'unknown')
						if settle['item'].get('show', {}) and show_table: settle['item']['show'] = show_table['show'] # Kopiere Show-Ordner in 2. Ebene zu 'item.show'
						settle.update({k:v for k, v in settle['item'].items()}) # Kopiere Inhalt von 'item' ins Hauptverzeichnis
						settle.pop('item', None); settle.pop('features', None); settle.pop('contentDescriptors', None); settle.pop('package', None) # Lösche 'item' Ordner komplett
						if ('NICHT IM PROGRAMM' in settle.get('subtitle', '').upper()) or (not str(settle.get('videoDuration')).isdecimal()) or \
							(str(settle.get('seasonNumber')).isdecimal() and int(settle['seasonNumber']) > 1) or (code_one == 'unknown') or \
							(str(settle.get('episodeNumber')).isdecimal() and int(settle['episodeNumber']) > 1): continue
						embrace_one = {**settle, **{'auraTicket': {'secCount': num_one, 'secCipher': code_one, 'secBrand': mark_one}}}
						debug_MS("---------------------------------------------")
						debug_MS(f"(navigator.fetch_pages[2]) {mark_one} ### POSITION-02 : {num_one} || SLUG-02 : {code_one} || ENTRY-02 : {embrace_one} ###")
						yield embrace_one

def set_resolved(listitem, automatic=False):
	listitem.setProperty('isPlayable', 'true')
	listitem.setContentLookup(False)
	xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	if automatic is True and clamps_player:
		from .player import discoMaster
		discoMaster().start_signal()

def add_views(params, listitem, folder=False):
	uws = build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
