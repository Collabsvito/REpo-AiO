﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import inputstreamhelper
from uuid import uuid4 as make_uuid
from urllib.parse import urlsplit, urlunsplit, urlencode
from urllib.request import urlopen, Request
from urllib.error import HTTPError
from time import time, strftime, strptime, localtime
from datetime import datetime, timedelta
from calendar import timegm


KODI_VERSION = int(xbmc.getInfoLabel('System.BuildVersion')[0:2])

PATHS = ('main_menu', {
	'live': ('play_live', {}),
	'newest': ('list_newest', {}),
	'movies': ('list_movies', {}),
	'series': 'show_series',
	'special': 'show_special',
	'play': 'play_video',
	'settings': ('open_settings', {}),
})

HEAD_WEB = 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:130.0) Gecko/20100101 Firefox/130.0'

DEFAULT_HEADERS = {'Accept': '*/*', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'DNT': '1', \
	'Origin': 'https://tele5.de', 'Referer': 'https://tele5.de/'}

DISCO_ID = '626'
DISCO_HOST = 'https://eu1-prod.disco-api.com'
DISCO_REALM = 'dmaxde'

DISCO_HEADERS = {**DEFAULT_HEADERS, **{'X-disco-client': 'Alps:HyogaPlayer:0.0.0', 'X-disco-params': f"realm={DISCO_REALM}", \
	'X-Device-Info': 'STONEJS/1 (Unknown/Unknown; Unknown/Unknown; Unknown)'}}

LOMA_ID = 'tele5'
LOMA_HOST = f"https://de-api.loma-cms.com/feloma{{}}?environment={LOMA_ID}&v=2"
LOMA_REALM = '.de'

LOMA_HEADERS = {**DEFAULT_HEADERS, **{'Content-Type': 'application/json; charset=utf-8'}}

MANIFEST_TYPES = {'dash': 'mpd', 'hls': 'hls'}

class clientMaster():
	def __init__(self, *args, **kwargs):
		super(clientMaster, self).__init__()
		url = urlsplit(sys.argv[0])
		path = url.path.strip('/')
		self.handle = int(sys.argv[1])
		self.plugin = url.netloc
		self.addon = xbmcaddon.Addon()
		self.name = self.addon.getAddonInfo('id')
		self.version = self.addon.getAddonInfo('version')
		self.show_online = int(self.addon.getSetting('visual_remaining'))

		xbmcplugin.setContent(self.handle, 'tvshows')
		paths = PATHS
		while isinstance(paths, tuple):
			if path == "":
				getattr(self, paths[0])()
				break
			else:
				head, _, path = path.partition('/')
				paths = paths[1][head]
		else:
			getattr(self, paths)(path)

	def main_menu(self):
		item_uno = self.create_entries('DEFAULT', {'Title': self.translate(30601), 'Plot': self.translate(30602), \
			'Image': self.get_thumb('livestream.png'), 'Mediatype': 'video', 'Reference': 'Single'})
		self.add_dir_item('/live', item_uno)
		for precis, title in [('/newest', 30603), ('/movies', 30604), ('/series', 30605), ('/special', 30606)]:
			item_due = self.create_entries('DEFAULT', {'Title': self.translate(title), 'Image': self.get_thumb('icon.png')})
			self.add_dir_item(precis, item_due, True)
		if self.addon.getSetting('show_settings') == 'true':
			item_tre = self.create_entries('DEFAULT', {'Title': self.translate(30607), 'Image': self.get_thumb('settings.png')})
			self.add_dir_item('/settings', item_tre)
		xbmcplugin.endOfDirectory(self.handle)

	def open_settings(self):
		self.addon.openSettings()
		xbmc.executebuiltin('Container.Refresh')

	def list_newest(self):
		back_times = f"{(datetime.utcnow() - timedelta(days=3)).isoformat(timespec='seconds')}Z" # 3 Tage // 2025-01-17T02:00:00Z
		videos = list(self.fetch_disco_paginated("/content/videos?include=images,genres,show&sort=-earliestPlayableStart"\
			f"&filter[earliestPlayableStart.gt]={back_times}&filter[videoType]=EPISODE,STANDALONE&filter[primaryChannel.id]={DISCO_ID}"))
		if not videos:
			return
		for video in sorted(videos, key=lambda vx: vx['attributes'].get('earliestPlayableStart', str('2025-01-01T22:00:00Z')), reverse=True):
			shorts = video['attributes']
			if not str(shorts.get('videoDuration')).isdecimal():
				continue
			style = False if shorts.get('videoType') == 'STANDALONE' else True
			item = self.create_entries('STREAM', video, 'novelties', style)
			self.add_dir_item(f"/play/{video['id']}", item)
		xbmcplugin.endOfDirectory(self.handle)

	def list_movies(self):
		COMBI_UNO, COMBI_DUE = ([] for _ in range(2))
		COMBI_UNO = self.list_feloma('/page/mediathek/')
		for each_due in self.fetch_disco_paginated("/content/videos?include=images,genres,show"\
			f"&filter[videoType]=STANDALONE&filter[primaryChannel.id]={DISCO_ID}"):
			for method in self.set_sort_methods(): xbmcplugin.addSortMethod(self.handle, method)
			movie, shorts = each_due['relationships']['show']['data']['attributes'], each_due['attributes']
			if movie['videoCount'] > 1 or not str(shorts.get('videoDuration')).isdecimal():
				continue
			COMBI_DUE.append([shorts.get('alternateId', ''), shorts['name'].strip(), each_due['id'], each_due])
		if COMBI_UNO and COMBI_DUE:
			RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_UNO if av[0] == bv[0]]
			RESULT += [cv for cv in COMBI_DUE if all(dv[0] != cv[0] for dv in COMBI_UNO)]
			for xev in RESULT:
				if len(xev) >= 8:
					RIDERS = {**xev[3], **{'felomaContent': {'imgsrc': xev[5], 'covsrc': xev[6], 'teaser': xev[7]}}}
				else:
					RIDERS = xev[3]
				item = self.create_entries('STREAM', RIDERS, 'movie')
				self.add_dir_item(f"/play/{xev[2]}", item)
		xbmcplugin.endOfDirectory(self.handle)

	def show_series(self, series_id):
		if not series_id:
			return self.list_series()
		videos = list(self.fetch_disco_paginated("/content/videos?include=images,genres,show"\
			f"&filter[show.id]={series_id}&filter[videoType]=EPISODE,STANDALONE"))
		if not videos:
			return
		for video in sorted(videos, key=lambda vx: (int(vx['attributes'].get('seasonNumber', 1)), int(vx['attributes'].get('episodeNumber', 1)))):
			if not str(video['attributes'].get('videoDuration')).isdecimal():
				continue
			item = self.create_entries('STREAM', video, 'episode', True)
			self.add_dir_item(f"/play/{video['id']}", item)
		xbmcplugin.endOfDirectory(self.handle)

	def list_series(self):
		COMBI_UNO, COMBI_DUE = ([] for _ in range(2))
		COMBI_UNO = self.list_feloma('/page/mediathek/')
		for each_due in self.fetch_disco_paginated("/content/shows?include=images,genres"\
			f"&sort=name&filter[primaryChannel.id]={DISCO_ID}"):
			shorts, new_ser = each_due['attributes'], False
			if shorts['episodeCount'] == 0:
				continue
			if str(shorts.get('newestEpisodeDate'))[:4].isdecimal() and str(shorts.get('newestEpisodeDate'))[:4] not in ['0', '1970']:
				utc_start = datetime(*(strptime(shorts['newestEpisodeDate'][:19], '%Y-%m-%dT%H:%M:%S')[0:6]))
				if utc_start > (datetime.utcnow() - timedelta(days=3)): new_ser = True # 3 Tage // 2025-01-17T02:00:00Z
			COMBI_DUE.append([shorts.get('alternateId', ''), shorts['name'], each_due['id'], shorts.get('description', ''), new_ser])
		if COMBI_UNO and COMBI_DUE:
			RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_UNO if av[0] == bv[0]]
			for xev in RESULT:
				name, plot = self.translate(30620).format(xev[1].strip()) if xev[4] is True else xev[1].strip(), xev[8] if len(xev[8]) > len(xev[3]) else xev[3]
				image = xev[6] if xev[6] is not None else self.get_thumb('standard.png')
				item = self.create_entries('DEFAULT', {'Title': name, 'Plot': plot, 'Image': image, 'Cover': xev[7]})
				self.add_dir_item(f"/series/{xev[2]}", item, True)
		xbmcplugin.endOfDirectory(self.handle)

	def show_special(self, series_id):
		if not series_id:
			return self.list_special()
		videos = list(self.fetch_disco_paginated(f"/content/videos?include=images,genres,show&filter[show.id]={series_id}"))
		if not videos:
			return
		for video in videos:
			for method in self.set_sort_methods(): xbmcplugin.addSortMethod(self.handle, method)
			if not str(video['attributes'].get('videoDuration')).isdecimal():
				continue
			norms = 'movie' if video['attributes'].get('videoType') == 'STANDALONE' else 'video'
			item = self.create_entries('STREAM', video, norms, True)
			self.add_dir_item(f"/play/{video['id']}", item)
		xbmcplugin.endOfDirectory(self.handle)

	def list_special(self):
		for series in self.fetch_disco_paginated(f"/content/shows?include=images,genres"\
			f"&sort=name&filter[primaryChannel.id]={DISCO_ID}"):
			shorts = series['attributes']
			if (shorts['episodeCount'] != 0 or shorts['videoCount'] <= 1):
				continue
			item_uno = self.create_entries('DEFAULT', {'Title': shorts['name'].strip(), 'Plot': shorts.get('description'), 'Image': self.get_thumb('standard.png')})
			self.add_dir_item(f"/special/{series['id']}", item_uno, True)
		for clip in self.fetch_disco_paginated("/content/videos"\
			f"?include=images,genres,show&filter[videoType]=CLIP&filter[primaryChannel.id]={DISCO_ID}"):
			show, briefs = clip['relationships']['show']['data']['attributes'], clip['attributes']
			if show['videoCount'] > 1 or not str(briefs.get('videoDuration')).isdecimal():
				continue
			item_due = self.create_entries('STREAM', clip, 'video', True)
			self.add_dir_item(f"/play/{clip['id']}", item_due)
		xbmcplugin.endOfDirectory(self.handle)

	def list_feloma(self, purpose):
		COMBI_LOMA = []
		api_loma = self.fetch_json_post_raw(LOMA_HOST.format(purpose), headers=LOMA_HEADERS)
		for each_uno in api_loma['blocks'][0].get('items', []):
			teaser, (photo, poster) = "", (None for _ in range(2))
			showID = each_uno.get('slug', None)
			if each_uno.get('metaMedia', '') and len(each_uno['metaMedia']) > 0:
				photo = [pot.get('media', {}).get('url', []) for pot in each_uno.get('metaMedia') if pot.get('role') == 'default'][0]
				poster = [psr.get('media', {}).get('url', []) for psr in each_uno.get('metaMedia') if psr.get('role') == 'preview'][0]
			if each_uno.get('articleContent', ''):
				teaser = each_uno['articleContent'].replace('\n', '[CR]')
				teaser += '' if teaser.endswith(('.', '!', '?')) else '...'
			COMBI_LOMA.append([showID, photo, poster, teaser])
		return COMBI_LOMA

	def create_entries(self, target, metadata, medias='video', series=False):
		if target == 'STREAM':
			shorts, new_vid, (online, mpaa, show_title, portrait), (starting, airing) = metadata['attributes'], False, (None for _ in range(4)), ("" for _ in range(2))
			medias, pigment = 'tvshow' if medias == 'novelties' else medias, True if medias == 'novelties' else False
			story = shorts.get('description')
			duration = int(shorts['videoDuration']) // 1000 if str(shorts.get('videoDuration')).isdecimal() else None
			season = f"{int(shorts['seasonNumber']):02}" if str(shorts.get('seasonNumber')).isdecimal() and int(shorts.get('seasonNumber')) != 0 else None
			episode = f"{int(shorts['episodeNumber']):02}" if str(shorts.get('episodeNumber')).isdecimal() and int(shorts.get('episodeNumber')) != 0 else None
			if str(shorts.get('publishStart'))[:4].isdecimal():
				utc_start = datetime(*(strptime(shorts['publishStart'][:19], '%Y-%m-%dT%H:%M:%S')[0:6]))
				if utc_start > (datetime.utcnow() - timedelta(days=3)): new_vid = True # 3 Tage // 2025-01-17T02:00:00Z
				starting = self.format_timestamp(self.parse_timestamp(shorts['publishStart']))
				airing = self.format_timestamp(self.parse_timestamp(shorts['publishStart']), display=True)
			if self.show_online in [0, 1] and str(shorts.get('publishEnd'))[:4].isdecimal():
				ending = self.parse_timestamp(shorts['publishEnd'])
				if self.show_online == 0:
					online = self.format_duration_user(ending - time())
				elif self.show_online == 1:
					online = self.translate(30621).format(self.format_timestamp_user(ending))
			if story is None: plot = online
			elif online is None: plot = story
			else: plot = f"{online}[CR][CR]{story}"
			if str(shorts.get('rating')).isdecimal():
				mpaa = shorts['rating'] if str(shorts.get('rating')) != '0' else None
			if mpaa is None and shorts.get('contentRatings', '') and str(shorts.get('contentRatings', {})[0].get('code', '')).isdecimal():
				mpaa = shorts['contentRatings'][0]['code'] if str(shorts['contentRatings'][0]['code']) != '0' else None
			try: thumb = metadata['relationships']['images']['data'][0]['attributes']['src']
			except: thumb = self.get_thumb('standard.png')
			if series is True:
				show_title = metadata['relationships']['show']['data']['attributes']['name'].strip()
				plot = f"{show_title}[CR]{plot}" if plot and '[CR][CR]' in plot else f"{show_title}[CR][CR]{plot}"if plot else show_title
			elif series is False and metadata.get('felomaContent', '') and len(metadata['felomaContent']) > 0:
				thumb = metadata['felomaContent']['imgsrc'] if metadata['felomaContent'].get('imgsrc', '') else thumb
				portrait = metadata['felomaContent'].get('covsrc', '')
			titling = shorts['name'].strip()
			naming = self.translate(30622).format(season, episode, titling) if season and episode else \
				self.translate(30623).format(self.addon.getSetting('title_marking'), titling) if pigment is True else titling
			full_name = self.translate(30624).format(naming) if new_vid is True else naming
			metadata = {'Title': full_name, 'TvShowTitle': show_title, 'Plot': plot, 'Season': season,'Episode': episode, 'Duration': duration,
				'Date': starting, 'Aired': airing, 'Mpaa': mpaa, 'Mediatype': medias, 'Image': thumb, 'Cover': portrait, 'Reference': 'Single'}
		listitem = xbmcgui.ListItem(metadata['Title'])
		description = metadata['Plot'] if metadata.get('Plot') not in ['', 'None', None] else ' '
		metadata.update({'Plot': description})
		picture = metadata['Image'] if metadata.get('Image') else self.get_thumb('standard.png')
		listitem.setArt({'icon': self.get_icon(), 'thumb': picture, 'poster': picture, 'fanart': self.get_fanart()})
		if metadata.get('Cover'): listitem.setArt({'poster': metadata['Cover']})
		if self.addon.getSetting('use_fanart') == 'true' and \
			not picture.endswith(('icon.png', 'standard.png', 'livestream.png', 'settings.png')):
			listitem.setArt({'fanart': picture})
		if metadata.get('Reference') == 'Single':
			listitem.setProperty('IsPlayable', 'true')
		if KODI_VERSION >= 20:
			vinfo = listitem.getVideoInfoTag()
			vinfo.setTitle(metadata['Title'])
			if metadata.get('TvShowTitle', ''):
				vinfo.setTvShowTitle(metadata['TvShowTitle'])
			vinfo.setPlot(metadata['Plot'])
			if str(metadata.get('Duration')).isdecimal():
				vinfo.setDuration(int(metadata['Duration']))
			if str(metadata.get('Season')).isdecimal():
				vinfo.setSeason(int(metadata['Season']))
			if str(metadata.get('Episode')).isdecimal():
				vinfo.setEpisode(int(metadata['Episode']))
			if metadata.get('Date', ''):
				listitem.setDateTime(metadata['Date'])
			if metadata.get('Aired', ''):
				vinfo.setFirstAired(metadata['Aired'])
			if metadata.get('Mpaa', ''):
				vinfo.setMpaa(metadata['Mpaa'])
			if metadata.get('Mediatype', ''):
				vinfo.setMediaType(metadata['Mediatype'])
		else:
			listitem.setInfo('Video', metadata)
		return listitem

	def parse_timestamp(self, timestamp):
		return timegm(strptime(timestamp, '%Y-%m-%dT%H:%M:%SZ'))

	def format_timestamp(self, terms, display=False):
		if KODI_VERSION >= 20 and display is False:
			return strftime('%Y-%m-%dT%H:%M', localtime(terms)) # 2023-07-23T12:30:00 / NEWFORMAT
		return strftime('%d.%m.%Y', localtime(terms)) # 23.07.2023 / OLDFORMAT

	def format_duration_user(self, duration):
		if duration < 60:
			return self.translate(30625).format(int(duration))
		elif duration < 3600:
			return self.translate(30626).format(int(duration // 60))
		elif duration < 86400:
			return self.translate(30627).format(int(duration // 3600))
		return self.translate(30628).format(int(duration // 86400))

	def format_timestamp_user(self, timestamp):
		if abs(timestamp - time()) <= 43200:
			actual = xbmc.getRegion('time')
		else:
			actual = xbmc.getRegion('dateshort')
		return strftime(actual, localtime(timestamp))

	def play_video(self, video_id):
		DRM_GUARD, DRM_SPECIES = (False for _ in range(2))
		payload = {'deviceInfo': {'adBlocker': False, 'drmSupported': True, 'hdrCapabilities': [], 'hwDecodingCapabilities': [], 'soundCapabilities': []}, 'wisteriaProperties': {}, 'videoId': str(video_id)}
		video_info = self.fetch_disco('/playback/v3/videoPlaybackInfo', payload)
		for stream in video_info['data']['attributes']['streaming']:
			manifest_api = stream['type']
			try:
				manifest_kodi = MANIFEST_TYPES[manifest_api]
			except KeyError:
				self.log("Unknown manifest type {!r}".format(manifest_api), xbmc.LOGWARNING)
				continue
			safety = stream['protection']
			if safety['drmEnabled']:
				streamhelper = inputstreamhelper.Helper(manifest_kodi, drm='com.widevine.alpha')
				DRM_GUARD, DRM_TOKEN = safety['schemes']['widevine']['licenseUrl'], safety['drmToken']
			else:
				streamhelper = inputstreamhelper.Helper(manifest_kodi)
			if not streamhelper.check_inputstream():
				return
			LPM = xbmcgui.ListItem(path=stream['url'], offscreen=True)
			IA_NAME, IA_SYSTEM = streamhelper.inputstream_addon, 'com.widevine.alpha'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			DRM_HEADERS = {'PreAuthorization': DRM_TOKEN, 'Content-Type': 'application/octet-stream', 'User-Agent': HEAD_WEB} if DRM_GUARD else {}
			LPM.setProperty('inputstream', IA_NAME)
			if KODI_VERSION <= 20:
				LPM.setProperty(f"{IA_NAME}.manifest_type", manifest_kodi)
			if KODI_VERSION >= 20:
				LPM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={HEAD_WEB}") # On KODI v20 and above
			else: LPM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={HEAD_WEB}") # On KODI v19 and below
			if int(IA_VERSION) >= 2150 and manifest_kodi in ['hls', 'mpd']:
				DRM_SPECIES = {'DRM_System': 'org.w3.clearkey'} if manifest_kodi == 'hls' else {'DRM_System': IA_SYSTEM}
				if manifest_kodi == 'mpd' and DRM_GUARD:
					DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS)}
				LPM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
			elif int(IA_VERSION) < 2150 and manifest_kodi == 'mpd':
				LPM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
				if DRM_GUARD:
					DRM_SPECIES = {'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS), 'Post_Data': 'R{SSM}|'}
					LPM.setProperty(f"{IA_NAME}.license_key", '|'.join(DRM_SPECIES.values())) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
			if DRM_SPECIES: self.log(f"(navigator.play_video) INPUTSTREAM_VERSION: {IA_VERSION} >>>>> LICENSE : {'|'.join(DRM_SPECIES.values())} <<<<<")
			self.log(f"(navigator.play_video) {manifest_kodi.upper()}_stream : {stream['url']}|User-Agent={HEAD_WEB}")
			self.set_resolved(LPM, automatic=True)
			return
		self.log("No known manifest type found", xbmc.LOGERROR)
		xbmcgui.Dialog().notification(self.translate(32220), self.translate(32221), xbmcgui.NOTIFICATION_ERROR)

	def play_live(self):
		html_page = self.fetch_json_post_raw('https://embed.zattoo.com/token.json',
			headers = {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'DNT': '1', \
				'Content-Type': 'application/json; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/?partner_id=channel-embed'})['session_token']
		result = self.fetch_json_post_raw('https://embed.zattoo.com/zapi/watch/live/tele-5', \
			urlencode({'https_watch_urls': True, 'partner_site': 'tele5_de_channel', 'session_token': html_page, 'stream_type': 'dash', \
				'uuid': make_uuid()}).encode('utf-8'), \
			headers = {'Accept': 'application/json', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'Origin': 'https://embed.zattoo.com', \
				'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/client'})
		streamhelper = inputstreamhelper.Helper('mpd')
		if not streamhelper.check_inputstream():
			return
		item = xbmcgui.ListItem(path=result['stream']['url'], offscreen=True)
		item.setProperty('inputstream', streamhelper.inputstream_addon)
		if KODI_VERSION <= 20:
			item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
		self.set_resolved(item)

	def fetch_disco_paginated(self, path):
		path += '&' if '?' in path else '?'
		path += 'page[size]=100'
		first_page = self.fetch_disco(path)
		for item in first_page['data']: yield item
		for page in range(2, first_page['meta']['totalPages']+1):
			result = self.fetch_disco(f"{path}&page[number]={page}")
			for item in result['data']: yield item

	def fetch_disco(self, path, data=None, headers={}):
		token = self.get_disco_token()
		all_headers = DISCO_HEADERS.copy()
		all_headers['Authorization'] = f"Bearer {token}"
		all_headers.update(headers)
		response = self.fetch_json(DISCO_HOST+path, data, all_headers)
		if 'included' in response:
			included = {(res['type'], res['id']): res for res in response['included']}
			if included:
				for inc in included.values():
					self.update_included(inc, included)
				self.update_included(response['data'], included)
		return response

	def update_included(self, data, included):
		def find_value(v):
			try: return included[v['type'], v['id']]
			except KeyError: return v

		def update_item(item):
			try: relations = item['relationships']
			except KeyError: return
			for value in relations.values():
				data = value['data']
				if isinstance(data, list):
					for i, item in enumerate(data): data[i] = find_value(item)
				else:
					value['data'] = find_value(data)

		if isinstance(data, list):
			for item in data: update_item(item)
		else:
			update_item(data)

	def py3_dec(self, d, nom='utf-8', ign='ignore'):
		if isinstance(d, bytes):
			d = d.decode(nom, ign)
		return d

	def fetch_json(self, url, data=None, headers={}):
		if data is not None: data = json.dumps(data).encode()
		headers.update({'Content-Type': 'application/json'})
		return self.fetch_json_post_raw(url, data, headers)

	def fetch_json_post_raw(self, url, data=None, headers={}):
		return self.urlopen(url, data, headers, lambda ej: json.loads(self.py3_dec(ej.read())))

	def fetch(self, url, data=None, headers={}):
		return self.urlopen(url, data, headers, lambda er: self.py3_dec(er.read()))

	def urlopen(self, url, data, heading, func):
		request = Request(url, data, headers={**heading, **{'User-Agent': HEAD_WEB}})
		with urlopen(request, timeout=20) as conn:
			return func(conn)

	def get_disco_token(self):
		try: return self.disco_token
		except AttributeError: pass
		response = self.fetch_json(f"{DISCO_HOST}/token?realm={DISCO_REALM}", headers=DISCO_HEADERS)
		token = response['data']['attributes']['token']
		self.disco_token = token
		return token

	def log(self, msg, level=xbmc.LOGINFO):
		xbmc.log(f"[{self.name} v.{self.version}] {str(msg)}", level)

	def set_sort_methods(self):
		return [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL,\
			xbmcplugin.SORT_METHOD_DURATION, xbmcplugin.SORT_METHOD_DATE]

	def add_dir_item(self, path, listitem, folder=False):
		path = urlunsplit(('plugin', self.plugin, path, '', ''))
		listitem.setPath(path)
		xbmcplugin.addDirectoryItem(self.handle, path, listitem, folder)

	def set_resolved(self, listitem, automatic=False):
		listitem.setProperty('isPlayable', 'true')
		listitem.setContentLookup(False)
		xbmcplugin.setResolvedUrl(self.handle, True, listitem)
		if automatic is True and self.addon.getSetting('force_stopping') == 'true':
			from .player import discoMaster
			discoMaster().start_signal()

	def translate(self, num):
		return self.addon.getLocalizedString(num)

	def get_icon(self):
		return xbmcvfs.translatePath(self.addon.getAddonInfo('icon'))
	def get_thumb(self, image):
		addon_folder = xbmcvfs.translatePath(self.addon.getAddonInfo('path'))
		return os.path.join(addon_folder, 'resources', 'media', image)
	def get_fanart(self):
		return xbmcvfs.translatePath(self.addon.getAddonInfo('fanart'))
