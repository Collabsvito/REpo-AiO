﻿# -*- coding: utf-8 -*-

from .common import *
from .utilities import clientHelper


def main_menu():
	item_uno = create_entries({'Title': translation(30601), 'Plot': translation(30602), \
		'Image': f"{artpic}livestream.png", 'Mediatype': 'video', 'Reference': 'Single'})
	add_views({'mode': 'play_live'}, item_uno)
	for title, action in [(30603, {'mode': 'list_species', 'marker': 'NEWEST'}), (30604, {'mode': 'list_species', 'marker': 'OLDEST'}),
		(30605, {'mode': 'list_movies'}), (30606, {'mode': 'list_series'})]:
		add_views(action, create_entries({'Title': translation(title), 'Image': f"{artpic}icon.png"}), True)
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30608), 'Image': f"{artpic}settings.png"}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_species(marker):
	debug_MS("(navigator.list_species) ------------------------------------------------ START = list_species -----------------------------------------------")
	isolate, (combo_links, combo_uno, combo_due) = set(), ([] for _ in range(3))
	combo_links, combo_uno = _fetch_aurora()
	for method in get_sorting('others'): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	content, serve, adjust = 'publishStart' if marker == 'NEWEST' else 'publishEnd', '2026-01-01T00:01', True if marker == 'NEWEST' else False
	for riders in sorted(_fetch_pages(combo_links, 'collect'), key=lambda asx: asx.get(content, serve)[:16], reverse=adjust):
		com_ceas = (riders.get('id', None) or riders.get('videoId', None) or riders.get('ctaVideoId', None)) # get('id') für Episoden // get('id') oder get('videoId') oder get('ctaVideoId') für Filme
		if marker == 'NEWEST' and str(riders.get('publishStart'))[:4].isdecimal():
			if parse_dates(riders['publishStart']) < (datetime.utcnow() - timedelta(days=3)): continue # 3 Tage // 2026-05-15T02:00:00+00.00
		if marker == 'OLDEST' and str(riders.get('publishEnd'))[:4].isdecimal():
			if parse_dates(riders['publishEnd']) > (datetime.utcnow() + timedelta(days=3)): continue # 3 Tage // 2026-05-15T02:00:00+00.00
		if com_ceas not in isolate:
			isolate.add(com_ceas)
			fetch_items = create_entries(riders, marker, 'novelties')
			add_views({'mode': 'play_video', 'url': com_ceas}, fetch_items)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_movies():
	debug_MS("(navigator.list_movies) ------------------------------------------------ START = list_movies -----------------------------------------------")
	isolate, merging, (combo_links, combo_uno, combo_due) = set(), {}, ([] for _ in range(3))
	combo_links, combo_uno = _fetch_aurora()
	for method in get_sorting('others'): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	combo_due = [xrs for xrs in _fetch_pages(combo_links, 'movies')]
	if combo_due: # https://stackoverflow.com/questions/71649085/most-pythonic-way-to-merge-two-dictionnaries-having-common-key-value-pair
		merging = [{**uno, **due} for uno in combo_uno for due in combo_due if uno.get('Slug_1') == due.get('Slug_2')] # Merge List1 and List2 (dictionaries) by specific value if value exists else nothing !!!
		for riders in merging:
			mov_ceas = (riders.get('id', None) or riders.get('videoId', None) or riders.get('ctaVideoId', None)) # get('id') oder get('videoId') oder get('ctaVideoId')
			if mov_ceas not in isolate:
				isolate.add(mov_ceas)
				fetch_items = create_entries(riders, 'COLLECT', 'movie')
				add_views({'mode': 'play_video', 'url': mov_ceas}, fetch_items)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_series():
	debug_MS("(navigator.list_series) ------------------------------------------------ START = list_series -----------------------------------------------")
	isolate, merging, (combo_links, combo_uno, combo_due) = set(), {}, ([] for _ in range(3))
	combo_links, combo_uno = _fetch_aurora()
	for method in get_sorting('names'): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	for each_due in sorted(_fetch_pages(combo_links, 'series'), key=lambda asx: asx.get('publishStart', '2026-01-01T00:01')[:16], reverse=True):
		if each_due.get('Slug_2', None) not in isolate: # Nur jeweils einen Teil einer Serie behalten
			isolate.add(each_due['Slug_2'])
			combo_due.append(each_due)
	if combo_due: # https://stackoverflow.com/questions/71649085/most-pythonic-way-to-merge-two-dictionnaries-having-common-key-value-pair
		merging = [{**uno, **due} for uno in combo_uno for due in combo_due if uno.get('Slug_1') == due.get('Slug_2')] # Merge List1 and List2 (dictionaries) by specific value if value exists else nothing !!!
		for riders in sorted(merging, key=lambda nox: int(nox.get('Count_1', 1))): # Originalsortierung für Übersicht wiederherstellen
			fetch_items = create_entries(riders, 'COLLECT', 'tvshow')
			add_views({'mode': 'list_episodes', 'slug': riders.get('Slug_1')}, fetch_items, True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes(series_slug):
	debug_MS("(navigator.list_episodes) ------------------------------------------------ START = list_episodes -----------------------------------------------")
	combies = clientHelper().track_content(AURA_ITEMS.format(series_slug), headers=DEFAULT_HEADERS)
	for article in combies.get('blocks', []):
		if article.get('type') == 'sonicShowBlock' and article.get('items', {}):
			for riders in sorted(article.get('items', {}), key=lambda sx: (int(sx.get('seasonNumber', 1)), int(sx.get('episodeNumber', 1)))):
				if 'NICHT IM PROGRAMM' in riders.get('subtitle', '').upper() or not str(riders.get('videoDuration')).isdecimal(): continue
				debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
				debug_MS(f"(navigator.list_episodes[1]) xxxxx EACH-01 : {riders} xxxxx")
				fetch_items = create_entries(riders, 'COLLECT', 'episode')
				add_views({'mode': 'play_video', 'url': riders.get('id')}, fetch_items)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def _fetch_aurora():
	unikat, (primodo, secondo) = set(), ([] for _ in range(2))
	mediathek = clientHelper().track_content(AURA_NORM, headers=DEFAULT_HEADERS)
	if mediathek is not None and mediathek.get('blocks', {}) and len(mediathek['blocks']) > 0:
		for block in mediathek['blocks']:
			if block.get('type') == 'categoryCollectionBlock' and block.get('items', {}):
				for num, each_uno in enumerate(block.get('items', []), 1):
					teaser, (thumb, cover) = "", (None for _ in range(2))
					title = each_uno['title']
					slug = (each_uno.get('slug', None) or each_uno.get('url', None))
					if slug is None and each_uno.get('show', {}).get('title', ''):
						title, slug = cleaning(each_uno['show']['title']), clear_invalid(each_uno['show']['title']).lower()
					parent = (each_uno.get('parentSlug', '') or each_uno.get('parentUrl', '') or each_uno.get('parentPage', {}).get('slug', ''))
					showCID = (each_uno.get('attributes', {}).get('showId', '') or each_uno.get('show', {}).get('id', '') or each_uno.get('showId', '') or None)
					infos = (each_uno.get('attributes', {}).get('tuneinInfo', '') or each_uno.get('tuneinInfo', ''))
					if slug is None and showCID is None: continue
					if 'NICHT IM PROGRAMM' not in infos.upper() and slug not in unikat:
						unikat.add(slug)
						debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
						debug_MS(f"(navigator.fetch_aurora[1]) xxxxx COUNT-01 : {num} || EACH-01 : {each_uno} xxxxx")
						if each_uno.get('metaMedia', '') and len(each_uno['metaMedia']) > 0:
							thumb = [pmb.get('media', {}).get('url', None) for pmb in each_uno.get('metaMedia') if pmb.get('role') == 'default'][0]
							cover = [per.get('media', {}).get('url', None) for per in each_uno.get('metaMedia') if per.get('role') == 'preview'][0]
						if cover is None and each_uno.get('image', '') and each_uno['image'].get('url', ''):
							cover = each_uno['image']['url']
						if cover is None and each_uno.get('poster', '') and each_uno['poster'].get('src', ''):
							thumb = each_uno['poster']['src']
						if each_uno.get('articleContent', '') and len(each_uno['articleContent']) > 20:
							teaser = cleaning(each_uno['articleContent'])
						transition = AURA_ITEMS.format(slug.lower())
						primodo.append({'Count_1': int(num), 'Slug_1': slug, 'Link_1': transition})
						secondo.append({'Count_1': int(num), 'Slug_1': slug, 'Link_1': transition, 'ShowTitle': title, 'parentSlug': parent, \
							'ShowCID': showCID, 'Infos': infos, 'ShowImage': thumb, 'ShowPoster': cover, 'ShowTeaser': teaser})
	return primodo, secondo

def _fetch_pages(templates, trace):
	package = clientHelper().track_several(templates, 'GET', timeout=20)
	if package:
		for article in json.loads(package):
			movie_table, movie_section = (None for _ in range(2))
			if trace in ['collect', 'series', 'movies'] and article is not None and article.get('blocks', {}) and len(article['blocks']) > 0 and any(sonic.get('type') == 'sonicShowBlock' for sonic in article.get('blocks', {})):
				num_ser, code_ser, link_ser = article.get('Count_2', 0), article.get('Slug_2'), article.get('Link_2')
				series_table = next(filter(lambda ser: ser.get('type') == 'showHeaderBlock' and ser.get('show', {}), article['blocks']), None) # Suche nach den Inhalten im 'show' Ordner
				movie_table = next(filter(lambda mov: mov.get('type') == 'showHeaderBlock' and mov.get('item', {}), article['blocks']), None) # Suche nach den Inhalten im 'show' Ordner
				for bodies in article['blocks']:
					if bodies.get('type') == 'sonicShowBlock' and bodies.get('items', {}):
						for scraps in bodies.get('items', {}):
							if str(scraps.get('videoDuration')).isdecimal() and int(scraps['videoDuration']) // 1000 > 4200: # Sende diesen 'item' zur Kategorie: MOVIES, da dieser länger als 70 Minuten (4200 Sekunden) ist
								movie_section = {'Count_2': num_ser, 'Slug_2': code_ser, 'Link_2': link_ser}
							if not str(scraps.get('videoDuration')).isdecimal() or trace == 'movies' or movie_section: continue
							if scraps.get('show', {}) and series_table:
								scraps['show'].update({key: value for key, value in series_table['show'].items() if value not in ['', 'None', None]}) # Kopiere Show-Ordner in 2. Ebene zu 'show'
							scraps.pop('schedule', None); scraps.pop('features', None); scraps.pop('contentDescriptors', None); scraps.pop('package', None)
							embrace_ser = {**scraps, **{'Count_2': num_ser, 'Slug_2': code_ser, 'Link_2': link_ser, 'BrandType': 'SERIES'}}
							debug_MS("---------------------------------------------")
							debug_MS(f"(navigator.fetch_pages[2.1]) SERIES ### COUNT-03 : {num_ser} || SLUG-03 : {code_ser} || ENTRY-03 : {embrace_ser} ###")
							yield embrace_ser
			if trace in ['collect', 'movies'] and article is not None and article.get('blocks', {}) and len(article['blocks']) > 0 and (not any(sonic.get('type') == 'sonicShowBlock' for sonic in article.get('blocks', {})) or (movie_section and movie_table)):
				num_mov, code_mov, link_mov = article.get('Count_2', 0), article.get('Slug_2'), article.get('Link_2')
				show_table = next(filter(lambda sox: sox.get('type') == 'showHeaderBlock' and sox.get('show', {}), article['blocks']), None) # Suche nach den Inhalten im 'show' Ordner
				for settle in article['blocks']:
					if (settle.get('type') == 'sonicVideoBlock' and settle.get('item', {})) or (movie_section and movie_table and movie_table.get('item', {})):
						if movie_section: settle, num_mov, code_mov, link_mov = movie_table, movie_section.get('Count_2', 0), movie_section.get('Slug_2'), movie_section.get('Link_2')
						if settle['item'].get('show', {}) and show_table: settle['item']['show'] = show_table['show'] # Kopiere Show-Ordner in 2. Ebene zu 'item.show'
						settle.update({key: value for key, value in settle['item'].items()}) # Kopiere Inhalt von 'item' ins Hauptverzeichnis
						settle.pop('item', None); settle.pop('schedule', None); settle.pop('features', None); settle.pop('contentDescriptors', None); settle.pop('package', None) # Lösche 'item' Ordner komplett
						if ('NICHT IM PROGRAMM' in settle.get('subtitle', '').upper()) or (not str(settle.get('videoDuration')).isdecimal()) or \
							(str(settle.get('seasonNumber')).isdecimal() and int(settle['seasonNumber']) > 1) or \
							(str(settle.get('episodeNumber')).isdecimal() and int(settle['episodeNumber']) > 1): continue
						embrace_mov = {**settle, **{'Count_2': num_mov, 'Slug_2': code_mov, 'Link_2': link_mov, 'BrandType': 'MOVIES'}}
						debug_MS("---------------------------------------------")
						debug_MS(f"(navigator.fetch_pages[2.2]) MOVIES ### COUNT-02 : {num_mov} || SLUG-02 : {code_mov} || ENTRY-02 : {embrace_mov} ###")
						yield embrace_mov

def play_video(video_id):
	debug_MS("(navigator.play_video) ------------------------------------------------ START = play_video -----------------------------------------------")
	debug_MS(f"(navigator.play_video) ### LINK = {AURA_PLAYER} ### PLID = {video_id} ###")
	STREAM, FINAL_URL, DRM_GUARD, DRM_SPECIES = (False for _ in range(4))
	payload = {'deviceInfo': {'adBlocker': False, 'drmSupported': True, 'hdrCapabilities': [], 'hwDecodingCapabilities': [], 'soundCapabilities': []}, 'wisteriaProperties': {}, 'videoId': str(video_id)}
	package = clientHelper().track_content(AURA_PLAYER, 'POST', headers=STONE_HEADERS, data=json.dumps(payload, indent=2))
	for riders in package['data']['attributes']['streaming']:
		if riders.get('protection', {}).get('drmEnabled', False) is True and riders.get('type') =='dash':
			STREAM, MIME, FINAL_URL = 'MPD', 'application/dash+xml', riders['url']
			DRM_GUARD, DRM_TOKEN = riders['protection']['schemes']['widevine']['licenseUrl'], riders['protection']['drmToken']
			debug_MS("(navigator.play_video[1]) ***** TAKE - Inputstream (mpd) - FILE *****")
		if FINAL_URL is False and riders.get('type') == 'hls':
			STREAM, MIME, FINAL_URL = 'HLS', 'application/vnd.apple.mpegurl', riders['url']
			debug_MS("(navigator.play_video[1]) ***** TAKE - Inputstream (hls) - FILE *****")
	if FINAL_URL and STREAM and plugin_operate('inputstream.adaptive'):
		LPM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		IA_NAME, IA_SYSTEM = 'inputstream.adaptive', 'com.widevine.alpha'
		IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
		DRM_HEADERS = {'PreAuthorization': DRM_TOKEN, 'Content-Type': 'application/octet-stream', 'User-Agent': WEB_AGENT} if DRM_GUARD else {}
		LPM.setMimeType(MIME); LPM.setProperty('inputstream', IA_NAME)
		if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", STREAM.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
		PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
		LPM.setProperty(f"{IA_NAME}.{PHRASE}_headers", f"User-Agent={WEB_AGENT}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
		if int(IA_VERSION) >= 2150 and STREAM in ['HLS', 'MPD']:
			DRM_SPECIES = {'DRM_System': 'org.w3.clearkey'} if STREAM == 'HLS' else {'DRM_System': IA_SYSTEM}
			if STREAM == 'MPD' and DRM_GUARD:
				DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS)}
			LPM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
		elif int(IA_VERSION) < 2150 and STREAM == 'MPD':
			LPM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
			if DRM_GUARD:
				DRM_SPECIES = {'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS), 'Post_Data': 'R{SSM}|'}
				LPM.setProperty(f"{IA_NAME}.license_key", '|'.join(DRM_SPECIES.values())) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
		if DRM_SPECIES: log(f"(navigator.play_video[2]) INPUTSTREAM_VERSION: {IA_VERSION} >>>>> LICENSE : {'|'.join(DRM_SPECIES.values())} <<<<<")
		log(f"(navigator.play_video) {STREAM}_stream : {FINAL_URL}|User-Agent={WEB_AGENT}")
		return set_resolved(LPM, automatic=True)
	else:
		failing(f"(navigator.play_video) ##### Abspielen des Streams NICHT möglich ##### PLID : {video_id} #####\n ########## KEINEN Stream-Eintrag gefunden !!! ##########")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		xbmc.PlayList(1).clear()
		return dialog.notification(translation(30521).format('PLAYER'), translation(30525), icon, 10000)

def play_live():
	debug_MS("(navigator.play_live) ------------------------------------------------ START = play_live -----------------------------------------------")
	auth_page = clientHelper().track_content('https://embed.zattoo.com/token.json',
		headers = {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'DNT': '1', \
			'Content-Type': 'application/json; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/?partner_id=channel-embed'})['session_token']
	live_page = clientHelper().track_content('https://embed.zattoo.com/zapi/watch/live/tele-5', 'POST', \
		headers = {'Accept': 'application/json', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'Origin': 'https://embed.zattoo.com', \
			'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/client'}, \
		data = urlencode({'https_watch_urls': True, 'partner_site': 'tele5_de_channel', 'session_token': auth_page, 'stream_type': 'dash', 'uuid': make_uuid()}))
	debug_MS(f"(navigator.play_live[1]) ### FINAL_URL : {live_page['stream']['url']} ###")
	LTM = xbmcgui.ListItem(path=live_page['stream']['url'], offscreen=True)
	LTM.setProperty('inputstream', 'inputstream.adaptive')
	if KODI_BUILD in [19, 20]: LTM.setProperty('inputstream.adaptive.manifest_type', 'mpd')
	return set_resolved(LTM)

def set_resolved(listitem, automatic=False):
	listitem.setProperty('isPlayable', 'true')
	listitem.setContentLookup(False)
	xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	if automatic is True and clamps_player:
		from .player import discoMaster
		discoMaster().start_signal()

def add_views(params, listitem, folder=False):
	uws = build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
