﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
from time import time, strftime, strptime, localtime
from datetime import datetime, timedelta
from calendar import timegm
from urllib.parse import urlsplit, urlunsplit, urlencode
from uuid import uuid4 as make_uuid
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import inputstreamhelper

KODI_VERSION = int(xbmc.getInfoLabel('System.BuildVersion')[0:2])

PATHS = ('main_menu', {'live': ('play_live', {}), 'newest': ('list_newest', {}), 'movies': ('list_movies', {}), \
	'series': 'show_series', 'special': 'show_special', 'play': 'play_video', 'settings': ('open_settings', {})})

HEAD_WEB = 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:147.0) Gecko/20100101 Firefox/147.0'

DEFAULT_HEADERS = {'Accept': '*/*', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'DNT': '1', \
	'Origin': 'https://tele5.de', 'Referer': 'https://tele5.de/'}

DISCO_CHANNEL = '626'
DISCO_HOST = 'https://eu1-prod.disco-api.com'
DISCO_REALM = 'dmaxde'

DISCO_HEADERS = {**DEFAULT_HEADERS, **{'Content-Type': 'application/json; charset=utf-8', 'X-disco-client': 'WEB:UNKNOWN:wbdatv:2.1.9', \
	'X-disco-params': f"realm={DISCO_REALM}", 'X-Device-Info': 'STONEJS/1 (Unknown/Unknown; Windows/NT 10.0; Unknown)'}}

PUBLIC_CHANNEL = 'tele5' # https://public.aurora.enhanced.live/site/page/mediathek/?include=default&filter[environment]=tele5&v=2
PUBLIC_HOST = f"https://public.aurora.enhanced.live/site{{}}?include=default,advancedSearch&filter[environment]={PUBLIC_CHANNEL}&v=2"
PUBLIC_REALM = 'de' # https://public.aurora.enhanced.live/token?realm=de

PUBLIC_HEADERS = {**DEFAULT_HEADERS, **{'Content-Type': 'application/json; charset=utf-8'}}

MANIFEST_TYPES = {'dash': 'mpd', 'hls': 'hls'}

class clientMaster():
	def __init__(self, *args, **kwargs):
		super(clientMaster, self).__init__()
		url = urlsplit(sys.argv[0])
		path = url.path.strip('/')
		self.handle = int(sys.argv[1])
		self.plugin = url.netloc
		self.addon = xbmcaddon.Addon()
		self.addon_name = self.addon.getAddonInfo('id')
		self.addon_version = self.addon.getAddonInfo('version')
		self.addon_folder = xbmcvfs.translatePath(self.addon.getAddonInfo('path'))
		self.addon_profile = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
		self.frames = os.path.join(self.addon_folder, 'resources', 'media', '')
		self.show_online = int(self.addon.getSetting('visual_remaining'))
		self.maxi_tokentime = 595 # max. Token-Time (Seconds) before clear the Token and delete Token-File [595 = 10 Minutes]
		self.tempSTORE_folder = xbmcvfs.translatePath(os.path.join(self.addon_profile, 'tempSTORE', ''))
		self.tempDISCO_file = xbmcvfs.translatePath(os.path.join(self.tempSTORE_folder, 'FREE_SECRET'))

		xbmcplugin.setContent(self.handle, 'tvshows')
		paths = PATHS
		while isinstance(paths, tuple):
			if path == "":
				getattr(self, paths[0])()
				break
			else:
				head, _, path = path.partition('/')
				paths = paths[1][head]
		else:
			getattr(self, paths)(path)

	def main_menu(self):
		item_uno = self.create_entries('DEFAULT', {'Title': self.translate(30601), 'Plot': self.translate(30602), \
			'Image': f"{self.frames}livestream.png", 'Mediatype': 'video', 'Reference': 'Single'})
		self.add_dir_item('/live', item_uno)
		for precis, title in [('/newest', 30603), ('/movies', 30604), ('/series', 30605), ('/special', 30606)]:
			item_due = self.create_entries('DEFAULT', {'Title': self.translate(title), 'Image': f"{self.frames}icon.png"})
			self.add_dir_item(precis, item_due, True)
		if self.addon.getSetting('show_settings') == 'true':
			item_tre = self.create_entries('DEFAULT', {'Title': self.translate(30607), 'Image': f"{self.frames}settings.png"})
			self.add_dir_item('/settings', item_tre)
		xbmcplugin.endOfDirectory(self.handle)

	def open_settings(self):
		self.addon.openSettings()
		xbmc.executebuiltin('Container.Refresh')

	def list_newest(self):
		back_times = f"{(datetime.utcnow() - timedelta(days=3)).isoformat(timespec='seconds')}Z" # 3 Tage // 2026-02-20T02:00:00Z
		videos = list(self.fetch_pages("/content/videos?include=images,genres,show&sort=-earliestPlayableStart"\
			f"&filter[earliestPlayableStart.gt]={back_times}&filter[videoType]=EPISODE,STANDALONE&filter[primaryChannel.id]={DISCO_CHANNEL}"))
		if not videos:
			return
		for video in sorted(videos, key=lambda vx: vx['attributes'].get('earliestPlayableStart', str('2026-01-01T22:00:00Z')), reverse=True):
			shorts = video['attributes']
			if not str(shorts.get('videoDuration')).isdecimal():
				continue
			style = False if shorts.get('videoType') == 'STANDALONE' else True
			item = self.create_entries('STREAM', video, 'novelties', style)
			self.add_dir_item(f"/play/{video['id']}", item)
		xbmcplugin.endOfDirectory(self.handle)

	def list_movies(self):
		COMBI_UNO, COMBI_DUE = ([] for _ in range(2))
		COMBI_UNO = self.list_aurora('/page/mediathek/')
		for each_due in self.fetch_pages(f"/content/videos?include=images,genres,show&filter[videoType]=STANDALONE&filter[primaryChannel.id]={DISCO_CHANNEL}"):
			for method in self.get_sorting(): xbmcplugin.addSortMethod(self.handle, method)
			movie, shorts = each_due['relationships']['show']['data']['attributes'], each_due['attributes']
			if movie['videoCount'] > 1 or not str(shorts.get('videoDuration')).isdecimal():
				continue
			COMBI_DUE.append([shorts.get('alternateId', ''), shorts['name'].strip(), each_due['id'], each_due])
		if COMBI_DUE:
			RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_UNO if av[0] == bv[0]]
			RESULT += [cv for cv in COMBI_DUE if all(dv[0] != cv[0] for dv in COMBI_UNO)]
			for xev in RESULT:
				if len(xev) >= 8:
					RIDERS = {**xev[3], **{'auroraContent': {'imgsrc': xev[5], 'covsrc': xev[6], 'teaser': xev[7]}}}
				else:
					RIDERS = xev[3]
				item = self.create_entries('STREAM', RIDERS, 'movie')
				self.add_dir_item(f"/play/{xev[2]}", item)
		xbmcplugin.endOfDirectory(self.handle)

	def show_series(self, series_id):
		if not series_id:
			return self.list_series()
		videos = list(self.fetch_pages(f"/content/videos?include=images,genres,show&filter[show.id]={series_id}&filter[videoType]=EPISODE,STANDALONE"))
		if not videos:
			return
		for video in sorted(videos, key=lambda vx: (int(vx['attributes'].get('seasonNumber', 1)), int(vx['attributes'].get('episodeNumber', 1)))):
			if not str(video['attributes'].get('videoDuration')).isdecimal():
				continue
			item = self.create_entries('STREAM', video, 'episode', True)
			self.add_dir_item(f"/play/{video['id']}", item)
		xbmcplugin.endOfDirectory(self.handle)

	def list_series(self):
		COMBI_UNO, COMBI_DUE = ([] for _ in range(2))
		COMBI_UNO = self.list_aurora('/page/mediathek/')
		for each_due in self.fetch_pages(f"/content/shows?include=images,genres&sort=name&filter[primaryChannel.id]={DISCO_CHANNEL}"):
			shorts, new_ser = each_due['attributes'], False
			if shorts['episodeCount'] == 0:
				continue
			if str(shorts.get('newestEpisodeDate'))[:4].isdecimal() and str(shorts.get('newestEpisodeDate'))[:4] not in ['0', '1970']:
				utc_start = datetime(*(strptime(shorts['newestEpisodeDate'][:19], '%Y-%m-%dT%H:%M:%S')[0:6]))
				if utc_start > (datetime.utcnow() - timedelta(days=3)): new_ser = True # 3 Tage // 2026-02-20T02:00:00Z
			COMBI_DUE.append([shorts.get('alternateId', ''), shorts['name'], each_due['id'], shorts.get('description', ''), new_ser])
		if COMBI_DUE:
			RESULT = [av + bv for av in COMBI_DUE for bv in COMBI_UNO if av[0] == bv[0]] if COMBI_UNO else \
				[cv for cv in COMBI_DUE if all(dv[0] != cv[0] for dv in COMBI_UNO)]
			for xev in RESULT:
				if len(xev) >= 8:
					name, plot = self.translate(30620).format(xev[1].strip()) if xev[4] is True else xev[1].strip(), xev[8] if len(xev[8]) > len(xev[3]) else xev[3]
					image, portrait = xev[6] if xev[6] is not None else f"{self.frames}standard.png", xev[7] if xev[7] is not None else f"{self.frames}standard.png"
				else:
					name, plot = self.translate(30620).format(xev[1].strip()) if xev[4] is True else xev[1].strip(), xev[3]
					image, portrait = f"{self.frames}standard.png", None
				item = self.create_entries('DEFAULT', {'Title': name, 'Plot': plot, 'Image': image, 'Cover': portrait})
				self.add_dir_item(f"/series/{xev[2]}", item, True)
		xbmcplugin.endOfDirectory(self.handle)

	def show_special(self, series_id):
		if not series_id:
			return self.list_special()
		videos = list(self.fetch_pages(f"/content/videos?include=images,genres,show&filter[show.id]={series_id}"))
		if not videos:
			return
		for video in videos:
			for method in self.get_sorting(): xbmcplugin.addSortMethod(self.handle, method)
			if not str(video['attributes'].get('videoDuration')).isdecimal():
				continue
			norms = 'movie' if video['attributes'].get('videoType') == 'STANDALONE' else 'video'
			item = self.create_entries('STREAM', video, norms, True)
			self.add_dir_item(f"/play/{video['id']}", item)
		xbmcplugin.endOfDirectory(self.handle)

	def list_special(self):
		for series in self.fetch_pages(f"/content/shows?include=images,genres&sort=name&filter[primaryChannel.id]={DISCO_CHANNEL}"):
			shorts = series['attributes']
			if (shorts['episodeCount'] != 0 or shorts['videoCount'] <= 1):
				continue
			item_uno = self.create_entries('DEFAULT', {'Title': shorts['name'].strip(), 'Plot': shorts.get('description'), 'Image': f"{self.frames}standard.png"})
			self.add_dir_item(f"/special/{series['id']}", item_uno, True)
		for clip in self.fetch_pages(f"/content/videos?include=images,genres,show&filter[videoType]=CLIP&filter[primaryChannel.id]={DISCO_CHANNEL}"):
			show, briefs = clip['relationships']['show']['data']['attributes'], clip['attributes']
			if show['videoCount'] > 1 or not str(briefs.get('videoDuration')).isdecimal():
				continue
			item_due = self.create_entries('STREAM', clip, 'video', True)
			self.add_dir_item(f"/play/{clip['id']}", item_due)
		xbmcplugin.endOfDirectory(self.handle)

	def list_aurora(self, purpose):
		COMBI_AURO = []
		mediathek = self.fetch_content(PUBLIC_HOST.format(purpose), headers=PUBLIC_HEADERS)
		if mediathek is not None and mediathek.get('blocks', {}) and len(mediathek['blocks']) > 0:
			for each_uno in mediathek['blocks'][0].get('items', []):
				teaser, (photo, poster) = "", (None for _ in range(2))
				showID = each_uno.get('slug', None)
				if each_uno.get('metaMedia', '') and len(each_uno['metaMedia']) > 0:
					photo = [pot.get('media', {}).get('url', '') for pot in each_uno.get('metaMedia') if pot.get('role') == 'default'][0]
					poster = [psr.get('media', {}).get('url', '') for psr in each_uno.get('metaMedia') if psr.get('role') == 'preview'][0]
				if each_uno.get('articleContent', '') and len(each_uno['articleContent']) > 20:
					teaser = re.sub(r'\<.*?\>', '', each_uno['articleContent'].replace('<p></p><p>', '[CR][CR]'))
				COMBI_AURO.append([showID, photo, poster, teaser])
		return COMBI_AURO

	def create_entries(self, target, metadata, medias='video', series=False):
		if target == 'STREAM':
			shorts, new_vid, double, (online, mpaa, show_title, portrait), (starting, airing) = metadata['attributes'], False, False, (None for _ in range(4)), ("" for _ in range(2))
			medias, pigment = 'tvshow' if medias == 'novelties' else medias, True if medias == 'novelties' else False
			story = shorts.get('description')
			if series is False and metadata.get('auroraContent', '') and len(metadata['auroraContent']) > 0:
				teaser = (metadata['auroraContent'].get('teaser', None) or None)
				story = teaser if (teaser and story and len(teaser) > len(story)) or (story is None) else story
			duration = int(shorts['videoDuration']) // 1000 if str(shorts.get('videoDuration')).isdecimal() else None
			season = f"{int(shorts['seasonNumber']):02}" if str(shorts.get('seasonNumber')).isdecimal() and int(shorts['seasonNumber']) != 0 else None
			episode = f"{int(shorts['episodeNumber']):02}" if str(shorts.get('episodeNumber')).isdecimal() and int(shorts['episodeNumber']) != 0 else None
			if str(shorts.get('publishStart'))[:4].isdecimal():
				utc_start = datetime(*(strptime(shorts['publishStart'][:19], '%Y-%m-%dT%H:%M:%S')[0:6]))
				if utc_start > (datetime.utcnow() - timedelta(days=3)): new_vid = True # 3 Tage // 2026-02-20T02:00:00Z
				starting = self.format_timestamp(self.parse_timestamp(shorts['publishStart']), visual=True)
				airing = self.format_timestamp(self.parse_timestamp(shorts['publishStart']))
			if self.show_online in [0, 1] and str(shorts.get('publishEnd'))[:4].isdecimal():
				ending = self.parse_timestamp(shorts['publishEnd'])
				if self.show_online == 0:
					online = self.rendering_duration(ending - time())
				elif self.show_online == 1:
					online = self.translate(30621).format(self.rendering_timstamp(ending))
			if story is None: plot = online
			elif online is None: plot = story
			else: plot, double = f"{online}[CR][CR]{story}", True
			if str(shorts.get('rating')).isdecimal():
				mpaa = shorts['rating'] if str(shorts.get('rating')) != '0' else None
			if mpaa is None and shorts.get('contentRatings', '') and str(shorts.get('contentRatings', {})[0].get('code', '')).isdecimal():
				mpaa = shorts['contentRatings'][0]['code'] if str(shorts['contentRatings'][0]['code']) != '0' else None
			try: thumb = metadata['relationships']['images']['data'][0]['attributes']['src']
			except: thumb = f"{self.frames}standard.png"
			if series is True:
				show_title = metadata['relationships']['show']['data']['attributes']['name'].strip()
				plot = f"{show_title}[CR]{plot}" if plot and double is True else f"{show_title}[CR][CR]{plot}" if plot else show_title
			elif series is False and metadata.get('auroraContent', '') and len(metadata['auroraContent']) > 0:
				thumb = (metadata['auroraContent'].get('imgsrc', '') or thumb)
				portrait = metadata['auroraContent'].get('covsrc', '')
			titling = shorts['name'].strip()
			naming = self.translate(30622).format(season, episode, titling) if season and episode else \
				self.translate(30623).format(self.addon.getSetting('title_marking'), titling) if pigment is True else titling
			full_name = self.translate(30624).format(naming) if new_vid is True else naming
			metadata = {'Title': full_name, 'TvShowTitle': show_title, 'Plot': plot, 'Season': season,'Episode': episode, 'Duration': duration, \
				'Date': starting, 'Aired': airing, 'Mpaa': mpaa, 'Mediatype': medias, 'Image': thumb, 'Cover': portrait, 'Reference': 'Single'}
		listitem = xbmcgui.ListItem(metadata['Title'])
		vinfo = listitem.getVideoInfoTag() if KODI_VERSION >= 20 else {}
		if KODI_VERSION >= 20: vinfo.setTitle(metadata['Title'])
		else: vinfo['Title'] = metadata['Title']
		if metadata.get('TvShowTitle', ''):
			if KODI_VERSION >= 20: vinfo.setTvShowTitle(metadata['TvShowTitle'])
			else: vinfo['Tvshowtitle'] = metadata['TvShowTitle']
		description = metadata['Plot'].replace('&nbsp;', '[CR]') if metadata.get('Plot') not in ['', 'None', None] else ' '
		if KODI_VERSION >= 20: vinfo.setPlot(description)
		else: vinfo['Plot'] = description
		if str(metadata.get('Duration')).isdecimal():
			if KODI_VERSION >= 20: vinfo.setDuration(int(metadata['Duration']))
			else: vinfo['Duration'] = metadata['Duration']
		if str(metadata.get('Season')).isdecimal():
			if KODI_VERSION >= 20: vinfo.setSeason(int(metadata['Season']))
			else: vinfo['Season'] = metadata['Season']
		if str(metadata.get('Episode')).isdecimal():
			if KODI_VERSION >= 20: vinfo.setEpisode(int(metadata['Episode']))
			else: vinfo['Episode'] = metadata['Episode']
		if metadata.get('Date', ''):
			if KODI_VERSION >= 20: listitem.setDateTime(metadata['Date'])
			else: vinfo['Date'] = metadata['Date']
		if metadata.get('Aired', ''):
			if KODI_VERSION >= 20: vinfo.setFirstAired(metadata['Aired'])
			else: vinfo['Aired'] = metadata['Aired']
		if metadata.get('Mpaa', ''):
			if KODI_VERSION >= 20: vinfo.setMpaa(metadata['Mpaa'])
			else: vinfo['Mpaa'] = metadata['Mpaa']
		if metadata.get('Mediatype', ''):
			if KODI_VERSION >= 20: vinfo.setMediaType(metadata['Mediatype'])
			else: vinfo['Mediatype'] = metadata['Mediatype']
		picture = metadata.get('Image', f"{self.frames}standard.png")
		listitem.setArt({'icon': f"{self.frames}icon.png", 'thumb': picture, 'poster': picture, 'fanart': f"{self.frames}fanart.png"})
		if metadata.get('Cover'): listitem.setArt({'poster': metadata['Cover']})
		if self.addon.getSetting('use_fanart') == 'true' and not self.frames in picture:
			listitem.setArt({'fanart': picture})
		if metadata.get('Reference') == 'Single':
			listitem.setProperty('IsPlayable', 'true')
		if KODI_VERSION < 20: listitem.setInfo('Video', vinfo)
		return listitem

	def parse_timestamp(self, timestamp):
		return timegm(strptime(timestamp, '%Y-%m-%dT%H:%M:%SZ'))

	def format_timestamp(self, terms, visual=False):
		timepoint = '%Y-%m-%dT%H:%M' if KODI_VERSION >= 20 and visual is True else '%d.%m.%Y'
		return strftime(timepoint, localtime(terms))# 2023-07-23T12:30:00 = NEWFORMAT // 23.07.2023 = OLDFORMAT

	def rendering_duration(self, duration):
		if duration < 60:
			return self.translate(30625).format(int(duration))
		elif duration < 3600:
			return self.translate(30626).format(int(duration // 60))
		elif duration < 86400:
			return self.translate(30627).format(int(duration // 3600))
		return self.translate(30628).format(int(duration // 86400))

	def rendering_timstamp(self, timestamp):
		actual = xbmc.getRegion('time') if abs(timestamp - time()) <= 43200 else xbmc.getRegion('dateshort')
		return strftime(actual, localtime(timestamp))

	def play_video(self, video_id):
		DRM_GUARD, DRM_SPECIES = (False for _ in range(2))
		payload = {'deviceInfo': {'adBlocker': False, 'drmSupported': True, 'hdrCapabilities': [], 'hwDecodingCapabilities': [], 'soundCapabilities': []}, 'wisteriaProperties': {}, 'videoId': str(video_id)}
		video_info = self.fetch_disco('/playback/v3/videoPlaybackInfo', 'POST', data=json.dumps(payload, indent=2))
		for stream in video_info['data']['attributes']['streaming']:
			manifest_api = stream['type']
			try:
				manifest_kodi = MANIFEST_TYPES[manifest_api]
			except KeyError:
				self.log("Unknown manifest type {!r}".format(manifest_api), xbmc.LOGWARNING)
				continue
			safety = stream['protection']
			if safety['drmEnabled']:
				streamhelper = inputstreamhelper.Helper(manifest_kodi, drm='com.widevine.alpha')
				DRM_GUARD, DRM_TOKEN = safety['schemes']['widevine']['licenseUrl'], safety['drmToken']
			else:
				streamhelper = inputstreamhelper.Helper(manifest_kodi)
			if not streamhelper.check_inputstream():
				return
			LPM = xbmcgui.ListItem(path=stream['url'], offscreen=True)
			IA_NAME, IA_SYSTEM = streamhelper.inputstream_addon, 'com.widevine.alpha'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			DRM_HEADERS = {'PreAuthorization': DRM_TOKEN, 'Content-Type': 'application/octet-stream', 'User-Agent': HEAD_WEB} if DRM_GUARD else {}
			LPM.setProperty('inputstream', IA_NAME)
			if KODI_VERSION <= 20:
				LPM.setProperty(f"{IA_NAME}.manifest_type", manifest_kodi)
			if KODI_VERSION >= 20:
				LPM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={HEAD_WEB}") # On KODI v20 and above
			else: LPM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={HEAD_WEB}") # On KODI v19 and below
			if int(IA_VERSION) >= 2150 and manifest_kodi in ['hls', 'mpd']:
				DRM_SPECIES = {'DRM_System': 'org.w3.clearkey'} if manifest_kodi == 'hls' else {'DRM_System': IA_SYSTEM}
				if manifest_kodi == 'mpd' and DRM_GUARD:
					DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS)}
				LPM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
			elif int(IA_VERSION) < 2150 and manifest_kodi == 'mpd':
				LPM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
				if DRM_GUARD:
					DRM_SPECIES = {'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS), 'Post_Data': 'R{SSM}|'}
					LPM.setProperty(f"{IA_NAME}.license_key", '|'.join(DRM_SPECIES.values())) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
			if DRM_SPECIES: self.log(f"(navigator.play_video) INPUTSTREAM_VERSION: {IA_VERSION} >>>>> LICENSE : {'|'.join(DRM_SPECIES.values())} <<<<<")
			self.log(f"(navigator.play_video) {manifest_kodi.upper()}_stream : {stream['url']}|User-Agent={HEAD_WEB}")
			self.set_resolved(LPM, automatic=True)
			return
		self.log("No known manifest type found", xbmc.LOGERROR)
		xbmcgui.Dialog().notification(self.translate(30521).format('PLAY'), self.translate(30524), f"{self.frames}icon.png", 12000)

	def play_live(self):
		auth_page = self.fetch_content('https://embed.zattoo.com/token.json',
			headers = {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'DNT': '1', \
				'Content-Type': 'application/json; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/?partner_id=channel-embed'})['session_token']
		live_page = self.fetch_content('https://embed.zattoo.com/zapi/watch/live/tele-5', 'POST', \
			headers = {'Accept': 'application/json', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'Origin': 'https://embed.zattoo.com', \
				'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8', 'Referer': 'https://embed.zattoo.com/tele-5/client'}, \
			data = urlencode({'https_watch_urls': True, 'partner_site': 'tele5_de_channel', 'session_token': auth_page, 'stream_type': 'dash', 'uuid': make_uuid()}))
		streamhelper = inputstreamhelper.Helper('mpd')
		if not streamhelper.check_inputstream():
			return
		LTM = xbmcgui.ListItem(path=live_page['stream']['url'], offscreen=True)
		LTM.setProperty('inputstream', streamhelper.inputstream_addon)
		if KODI_VERSION <= 20:
			LTM.setProperty('inputstream.adaptive.manifest_type', 'mpd')
		self.set_resolved(LTM)

	def fetch_pages(self, path):
		path += '&' if '?' in path else '?'
		path += 'page[size]=100'
		first_page = self.fetch_disco(path)
		for item in first_page['data']: yield item
		for pages in range(2, first_page['meta']['totalPages']+1):
			result = self.fetch_disco(f"{path}&page[number]={pages}")
			for item in result['data']: yield item

	def fetch_disco(self, path, modus='GET', data=None):
		token = self.check_authtoken()
		reaction = self.fetch_content(f"{DISCO_HOST}{path}", modus, headers={**DISCO_HEADERS, **{'Authorization': f"Bearer {token}"}}, data=data)
		if 'included' in reaction:
			included = {(zone['type'], zone['id']): zone for zone in reaction['included']}
			if included:
				for inc in included.values():
					self.update_included(inc, included)
				self.update_included(reaction['data'], included)
		return reaction

	def update_included(self, data, included):
		def find_value(v):
			try: return included[v['type'], v['id']]
			except KeyError: return v

		def update_item(item):
			try: relations = item['relationships']
			except KeyError: return
			for value in relations.values():
				data = value['data']
				if isinstance(data, list):
					for i, item in enumerate(data): data[i] = find_value(item)
				else:
					value['data'] = find_value(data)

		if isinstance(data, list):
			for item in data: update_item(item)
		else:
			update_item(data)

	def fetch_content(self, url, method='GET', queries='JSON', headers={}, redirects=True, verify=False, data=None, json=None, timeout=30):
		ANSWER, headers = None, {**headers, **{'User-Agent': HEAD_WEB}}
		try:
			response = requests.request(method, url, headers=headers, allow_redirects=redirects, verify=verify, data=data, json=json, timeout=timeout)
			ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
			self.debuggin(f"(navigator.fetch_content) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {headers} || DATA : {data} ===")
		except Exception as exc: # No JSON object could be decoded
			self.log(f"(navigator.fetch_content) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {exc} #####", xbmc.LOGERROR)
			if url.startswith(DISCO_HOST):
				xbmcgui.Dialog().notification(self.translate(30521).format('URL'), self.translate(30523).format(exc), f"{self.frames}icon.png", 12000)
				return sys.exit(0)
		return ANSWER

	def convert_epoch(self, epoch):
		CIPHER = datetime(1970,1,1) + timedelta(seconds=int(epoch))
		return CIPHER.strftime('%d.%m.%Y - %H:%M:%S')

	def check_authtoken(self):
		CODING, forceRenew, AUTH_TOKEN = False, False, None
		SELECT_PATH, SECURITY, self.TIME_UTC = self.tempSTORE_folder, self.tempDISCO_file, time()
		if SECURITY is not None and os.path.isfile(SECURITY):
			try:
				self.TOKEN_UTC = (os.path.getmtime(SECURITY) + self.maxi_tokentime)
				self.debuggin(f"(navigator.check_authtoken) ### SESSION-Time (utc NOW) = {self.convert_epoch(self.TIME_UTC)} || VALID until (utc SESSION) = {self.convert_epoch(self.TOKEN_UTC)} ###")
				if self.TIME_UTC < self.TOKEN_UTC:
					AUTH_TOKEN = self.preserve(SECURITY)['data']['attributes']['token']
					self.debuggin("(navigator.check_authtoken) ### NOTHING CHANGED - TOKENFILE IS OKAY ###")
				else:
					self.debuggin("(navigator.check_authtoken) ### TIMEOUT FOR TOKEN - DELETE TOKENFILE ###")
					forceRenew = True
			except:
				self.log("(navigator.check_authtoken) XXXXX !!! ERROR = TOKENFILE [TOKENFORMAT IS INVALID] = ERROR !!! XXXXX", xbmc.LOGERROR)
				forceRenew = True
		else:
			self.debuggin("(navigator.check_authtoken) ### NOTHING FOUND - CREATE TOKENFILE FOR DISCOVERY ###")
			forceRenew = True
		if forceRenew:
			if SECURITY is not None and os.path.isfile(SECURITY):
				shutil.rmtree(SELECT_PATH, ignore_errors=True)
			CODING = self.fetch_content(f"{DISCO_HOST}/token?realm={DISCO_REALM}", headers=DISCO_HEADERS)
			if CODING:
				self.debuggin(f"(navigator.check_authtoken) ***** NEW TOKENFILE CREATED : {CODING} *****")
				if not xbmcvfs.exists(SELECT_PATH) and not os.path.isdir(SELECT_PATH):
					xbmcvfs.mkdirs(SELECT_PATH)
				self.preserve(SECURITY, CODING)
				AUTH_TOKEN = CODING['data']['attributes']['token']
		return AUTH_TOKEN

	def translate(self, chiffre):
		return self.addon.getLocalizedString(chiffre)

	def debuggin(self, content):
		DEB_LEVEL = (xbmc.LOGINFO if self.addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
		self.log(content, DEB_LEVEL)

	def log(self, msg, level=xbmc.LOGINFO):
		return xbmc.log(f"[{self.addon_name} v.{self.addon_version}]{str(msg)}", level)

	def get_sorting(self):
		return [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL,\
			xbmcplugin.SORT_METHOD_DURATION, xbmcplugin.SORT_METHOD_DATE]

	def preserve(self, storage, content=None):
		if content is not None:
			with open(storage, 'w') as topics:
				json.dump(content, topics, indent=2, sort_keys=True)
		else:
			with open(storage, 'r') as topics:
				arrive = json.load(topics)
			return arrive

	def set_resolved(self, listitem, automatic=False):
		listitem.setProperty('isPlayable', 'true')
		listitem.setContentLookup(False)
		xbmcplugin.setResolvedUrl(self.handle, True, listitem)
		if automatic is True and self.addon.getSetting('force_stopping') == 'true':
			from .player import discoMaster
			discoMaster().start_signal()

	def add_dir_item(self, path, listitem, folder=False):
		path = urlunsplit(('plugin', self.plugin, path, '', ''))
		listitem.setPath(path)
		xbmcplugin.addDirectoryItem(self.handle, path, listitem, folder)
