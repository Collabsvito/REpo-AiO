# -*- coding: utf-8 -*-

import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import shutil
PY2 = sys.version_info[0] == 2


dialog                                = xbmcgui.Dialog()
addon                                = xbmcaddon.Addon('service.cron.autobiblio')
addon_id                           = addon.getAddonInfo('id')
addon_name                    = addon.getAddonInfo('name')
addon_version                 = addon.getAddonInfo('version')
TRANS_PATH                   = (xbmcvfs.translatePath if int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 19 else xbmc.translatePath)
addonPath                        = TRANS_PATH(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                           = TRANS_PATH(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
temp                                   = TRANS_PATH(os.path.join(dataPath, 'temp', '')).encode('utf-8').decode('utf-8')
Database                           = os.path.join(temp, 'MyTimeOrders.db')
icon                                     = (os.path.join(addonPath, 'icon.png') or os.path.join(addonPath, 'resources', 'icon.png') or os.path.join(addonPath, 'resources', 'media', 'icon.png'))
LOG_MESSAGE                  = (xbmc.LOGINFO if int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 19 else xbmc.LOGNOTICE)


class Unload:
	def __init__(self, *args, **kwargs):
		if sys.argv[1] == 'loeschen':
			if os.path.isdir(temp) and xbmcvfs.exists(Database):
				if dialog.yesno(addon_id, translation(30502), nolabel=translation(30503), yeslabel=translation(30504)):
					shutil.rmtree(temp, ignore_errors=True)
					xbmc.sleep(1000)
					dialog.notification(translation(30521), translation(30522), icon, 8000)
					log("########## DELETING complete DATABASE ... {0} ... success ##########".format(Database))
				else:
					return # they clicked no, we just have to exit the gui here
			else:
				dialog.ok(addon_id, translation(30505))

def py2_enc(s, encoding='utf-8'):
	if PY2:
		if not isinstance(s, basestring):
			s = str(s)
		s = s.encode(encoding) if isinstance(s, unicode) else s
	return s

def translation(id):
	return py2_enc(addon.getLocalizedString(id))

def log(msg, level=LOG_MESSAGE):
	msg = py2_enc(msg)
	return xbmc.log('[{0} v.{1}](reset_base) {2}'.format(addon_id, addon_version, msg), level)

if __name__ == '__main__':
	Unload()
