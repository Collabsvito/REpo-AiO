﻿# -*- coding: utf-8 -*-

import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import time
import _strptime
from datetime import datetime, timedelta
import sqlite3
import traceback
from urllib.parse import parse_qsl, urlencode, quote_plus, unquote_plus


dialog                                   = xbmcgui.Dialog()
addon                                   = xbmcaddon.Addon()
addon_id                             = addon.getAddonInfo('id')
addon_name                       = addon.getAddonInfo('name')
addon_version                    = addon.getAddonInfo('version')
addonPath                           = xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                              = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
temp                                     = xbmcvfs.translatePath(os.path.join(dataPath, 'temp', '')).encode('utf-8').decode('utf-8')
Database                              = os.path.join(temp, 'MyTimeOrders.db')
icon                                       = os.path.join(addonPath, 'resources', 'icon.png')
enableWARNINGS               = addon.getSetting('show_warnings') == 'true'
forceTrash                            = addon.getSetting('force_removing') == 'true'
KODI_ov20                          = int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20


def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def special(msg, level=xbmc.LOGINFO):
	return xbmc.log(msg, level)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug(content):
	log(content, xbmc.LOGDEBUG)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log('[{} v.{}]{}'.format(addon_id, addon_version, str(msg)), level)
