﻿# -*- coding: utf-8 -*-

import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus, unquote_plus  # Python 2.X
else:
	from urllib.parse import urlencode, quote_plus, unquote_plus  # Python 3+
import xbmcvfs
import shutil
import time
from datetime import datetime
import sqlite3
import traceback


global debuging
HOST_AND_PATH          = sys.argv[0]
ADDON_HANDLE            = int(sys.argv[1])
dialog                                = xbmcgui.Dialog()
addon                                = xbmcaddon.Addon()
addon_id                           = addon.getAddonInfo('id')
addon_name                    = addon.getAddonInfo('name')
addon_version                 = addon.getAddonInfo('version')
addonPath                        = xbmc.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                            = xbmc.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
temp                                   = xbmc.translatePath(os.path.join(dataPath, 'temp', '')).encode('utf-8').decode('utf-8')
Database                           = os.path.join(temp, 'MyTimeOrders.db')
icon                                     = os.path.join(addonPath, 'resources', 'icon.png')
forceTrash                         = addon.getSetting('forceErasing') == 'true'

if not xbmcvfs.exists(temp):
	xbmcvfs.mkdirs(temp)

def py2_enc(s, encoding='utf-8'):
	if PY2:
		if not isinstance(s, basestring):
			s = str(s)
		s = s.encode(encoding) if isinstance(s, unicode) else s
	return s

def py2_uni(s, encoding='utf-8'):
	if PY2 and isinstance(s, str):
		s = unicode(s, encoding)
	return s

def translation(id):
	return py2_enc(addon.getLocalizedString(id))

def failing(content):
	log(content, xbmc.LOGERROR)

def debug(content):
	log(content, xbmc.LOGDEBUG)

def log(msg, level=xbmc.LOGNOTICE):
	msg = py2_enc(msg)
	return xbmc.log('[{0} v.{1}](navigator) {2}'.format(addon_id, addon_version, msg), level)

def mainMenu():
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
	try:
		conn = sqlite3.connect(Database)
		cur = conn.cursor()
		cur.execute('SELECT * FROM stocks')
		r = list(cur)
		conn.commit()
		for member in r:
			stunden = member[0]
			url = member[1]
			name= py2_enc(member[2])
			name += translation(30601).format(url.split('@@')[1].split('&')[0]) if '@@' in url else translation(30602)
			shortENTRY= py2_enc(member[2])
			shortENTRY += '  ('+url.split('@@')[1].split('&')[0]+')' if '@@' in url else '  (Serie)'
			updated = member[3]
			source = member[4]
			debug("##### Stunden= {0} || URL= {1} || shortENTRY= {2} || lastUPDATE= {3} || Source= {4} #####".format(str(stunden), url, shortENTRY, updated, source))
			if source != 'standard' and os.path.isdir(source) and forceTrash:
				addDir(translation(30603).format(name), icon, {'mode': 'deleteData', 'url': url, 'shortENTRY': shortENTRY, 'source': source})
			elif source == 'standard' or not forceTrash:
				addDir(translation(30604).format(name), icon, {'mode': 'deleteData', 'url': url, 'shortENTRY': shortENTRY, 'source': source})
	except:
		var = traceback.format_exc()
		debug(var)
	finally:
		cur.close()
		conn.close()
	xbmcplugin.endOfDirectory(ADDON_HANDLE) 

def createtable():
	conn = sqlite3.connect(Database)
	cur = conn.cursor()
	try:
		cur.execute('CREATE TABLE IF NOT EXISTS stocks (stunden INTEGER, url TEXT PRIMARY KEY, name TEXT, last DATETIME)')
		try:
			cur.execute('ALTER TABLE stocks ADD COLUMN source TEXT')
		except sqlite3.OperationalError: pass
	except :
		var = traceback.format_exc()
		debug(var)
	finally:
		conn.commit() #Do not forget this !
		cur.close()
		conn.close()

def insert(name, stunden, url, source):
	last = "datetime('now', 'localtime')"
	try:
		conn = sqlite3.connect(Database)
		cur = conn.cursor()
		cur.execute('INSERT OR REPLACE INTO stocks VALUES ({0}, \"{1}\", \"{2}\", {3}, \"{4}\")'.format(int(stunden), url, name, last, source))
		conn.commit()
	except:
		conn.rollback()
		var = traceback.format_exc()
		debug(var)
	finally:
		cur.close()
		conn.close()

def deleteData(shortENTRY, url, source):
	source = xbmc.translatePath(os.path.join('source', '')) if source.startswith('special://') else source
	source = py2_uni(source)
	first_BASE = os.sep.join(source.split(os.sep)[:-1]) if '@@' in url and source != 'standard' else False
	try:
		conn = sqlite3.connect(Database, isolation_level=None)
		cur = conn.cursor()
		cur.execute('DELETE FROM stocks WHERE url = \"{0}\"'.format(url))
		cur.execute('VACUUM')
		conn.commit()
		if source != 'standard' and os.path.isdir(source) and forceTrash:
			shutil.rmtree(source, ignore_errors=True)
			log("########## DELETING from Crontab and System || FOLDER = {0} || TITLE = {1} || ##########".format(str(source), shortENTRY))
			if first_BASE:
				if len([f for f in os.listdir(first_BASE)]) == 1:
					shutil.rmtree(first_BASE, ignore_errors=True)
					log("########## LAST TURN - DELETING from System || BASE-FOLDER = {0} || ##########".format(str(first_BASE)))
		elif source == 'standard' or not forceTrash:
			dialog.ok(addon_id, translation(30501))
			log("########## DELETING only from Crontab - TITLE = {0} ##########".format(shortENTRY))
	except:
		conn.rollback()# Roll back any change if something goes wrong
		var = traceback.format_exc()
		failing("ERROR - ERROR - ERROR : ########## ({0}) received... ({1}) ...Delete Name in List failed ##########".format(shortENTRY, var))
	finally:
		cur.close()
		conn.close()

def parameters_string_to_dict(parameters):
	paramDict = {}
	if parameters:
		paramPairs = parameters[1:].split('&')
		for paramsPair in paramPairs:
			paramSplits = paramsPair.split('=')
			if (len(paramSplits)) == 2:
				paramDict[paramSplits[0]] = paramSplits[1]
	return paramDict

def addDir(name, image, params={}):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type="Video", infoLabels={"Title": name})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image})
	xbmcplugin.setContent(ADDON_HANDLE, 'movies')
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)

params = parameters_string_to_dict(sys.argv[2])
name = unquote_plus(params.get('name', ''))
url = unquote_plus(params.get('url', ''))
mode = unquote_plus(params.get('mode', 'root'))
shortENTRY = unquote_plus(params.get('shortENTRY', ''))
stunden = unquote_plus(params.get('stunden', ''))
source = unquote_plus(params.get('source', 'standard'))

if mode == 'root':
	mainMenu()
elif mode == 'adddata':
	createtable()
	debug("########## START INSTERT ##########")
	debug("### Name = {0} || Stunden = {1} || URL-1 = {2} || Source = {3} ###".format(name, str(stunden), url, source))
	insert(name, stunden, url, source)
	debug("########## AFTER INSTERT ##########")
	xbmc.executebuiltin('RunPlugin('+url+')')
elif mode == 'deleteData':
	deleteData(shortENTRY, url, source)
	xbmc.executebuiltin('Container.Refresh')
