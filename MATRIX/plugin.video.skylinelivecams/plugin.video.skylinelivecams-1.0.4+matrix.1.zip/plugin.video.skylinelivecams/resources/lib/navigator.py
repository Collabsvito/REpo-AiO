﻿# -*- coding: utf-8 -*-

from .common import *


def main_menu():
	for TITLE, PATH in [(30601, {'mode': 'list_favorites'}), (30602, {'mode': 'list_cameras', 'link': SKY_LANG, 'extra': 'CASUALCAM'}),
		(30603, {'mode': 'list_cameras', 'link': SKY_NEWS, 'extra': 'NEWEST'}), (30604, {'mode': 'list_cameras', 'link': SKY_TOPS, 'extra': 'POPULAR'}),
		(30605, {'mode': 'list_overview', 'link': SKY_LANG, 'extra': 'COUNTRIES'}), (30606, {'mode': 'list_overview', 'link': SKY_LANG, 'extra': 'CATEGORIES'})]:
		fetch_items = {'Title': translation(TITLE), 'Image': f"{artpic}favourites.png" if TITLE == 30601 else icon}
		add_views(PATH, create_entries(fetch_items), folder=False if TITLE == 30602 else True)
	add_views({'mode': 'clear_storage'}, create_entries({'Title': translation(30607).format(cache_periods), 'Image': f"{artpic}remove.png"}), False)
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_overview(target, extra, primodo= []): 
	debug_MS("(navigator.list_overview) ------------------------------------------------ START = list_overview -----------------------------------------------")
	debug_MS(f"(navigator.list_overview) ### URL = {target} ### EXTRA = {extra} ###")
	content = track_content(target, headers=WEB_HEADER)
	htmlPage = BeautifulSoup(clear_unknown(content), 'html.parser') # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.list_overview[1]) $$$$$ PRETTIFIED-SOUP : {htmlPage.prettify()} $$$$$")
	debug_MS("++++++++++++++++++++++++")
	if extra == 'COUNTRIES':
		menus = htmlPage.find('div', class_='dropdown mega-dropdown live')
	else:
		menus = htmlPage.find('div', class_='dropdown-menu mega-dropdown-menu cat')
	for item in menus.find_all('a', href=True):
		adress, plot, photo = item['href'], "", None
		if not adress.endswith('.html'): continue
		title = item.get_text().replace('The ', '').replace('Die ', '') # In countries the Title is hidden in Link-Text, extract it with: 'get_text()'
		name = translation(30621).format(title)
		if extra == 'COUNTRIES' and not 'live' in title.lower():
			genre = translation(30622).format(title)
			photo = f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png" if xbmcvfs.exists(f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png") else photo
		else: genre = translation(30623).format(title)
		descrn = item.find('p', class_='subt')
		if descrn: plot = f"{descrn.text}..." if not descrn.text.endswith(('.', '!', '?')) else f"{desc.text[:-1]}..." if descrn.text.endswith((',', ';')) else descrn.text
		link = f"{BASE_URL}{adress}" if adress.startswith('/') else f"{BASE_URL}/{adress}" if not adress.startswith(('http', '/')) else adress
		if item.find('img') and item.find('img').get('src'):
			photo = f"https:{item.img['src']}" if item.img['src'].startswith('//') else item.img['src']
			photo = photo.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', photo) else photo
		primodo.append({'Sorting': title, 'Link': link, 'Name': name, 'Genre': genre, 'Image': photo, 'Plot': plot})
	for article in sorted(primodo, key=lambda vsx: clear_umlaut(vsx.get('Sorting', 'zorro')).lower()):
		fetch_items = create_entries({'Title': article.get('Name'), 'Plot': article.get('Plot'), 'Image': article.get('Image')})
		add_views({'mode': 'list_cameras', 'link': article.get('Link'), 'extra': extra, 'phase': article.get('Genre')}, fetch_items)
		debug_MS(f"(navigator.list_overview[2]) ##### NAME : {article.get('Name')} || THUMB : {article.get('Image')} || LINK : {article.get('Link')} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_cameras(target, page, persist, extra, phase):
	debug_MS("(navigator.list_cameras) ------------------------------------------------ START = list_cameras -----------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL : {target} ### PAGE = {page} ### LIMIT = {limitation} ### POSITION = {persist} ### EXTRA = {extra} ### CATEGORY = {phase} ###")
	(merge_uno, merge_due), (combo_partial, combo_widget, combo_uno, combo_due, combo_tre, sending) = ({} for _ in range(2)), ([] for _ in range(6))
	default, counter, further = 0 if int(page) == 1 else int(page) - 1, 0, False
	minimum = int(default)*int(limitation) + 1
	maximum = int(page)*int(limitation) if extra != 'CASUALCAM' else 50
	higher = True if extra not in ['CASUALCAM', 'FAVORITES'] and int(page) > 1 else False
	if enable_decrease and button_place == 0 and higher is True:
		add_views({'mode': 'calling_main'}, create_entries({'Title': translation(30624), 'Image': f"{artpic}backmain.png"}))
	if isinstance(target, (dict, list)):
		for item in target:
			link, titling, photo, teasing = item['Stream'], item['Title'], item['Photo'], item['Teaser']
			vista, counter = link.replace('webcam/', 'weather/'), counter.__add__(1)
			combo_uno.append({'Count_1': int(counter), 'Link_1': link, 'Book_1': link, 'Title_1': titling, 'Thumb_1': photo, 'Teaser': teasing})
			combo_widget.append({'Count_1': int(counter), 'Link_1': link, 'Book_1': f"{vista[:vista.rfind('/')]}.html"})
	else:
		if not xbmcvfs.exists(tempDATA) and not os.path.exists(tempDATA):
			xbmcvfs.mkdirs(tempDATA)
		pages_data = f"{urlparse(target).path.replace('/', '_').replace('.html', '')}.gz"
		pages_path = xbmcvfs.translatePath(os.path.join(tempDATA, pages_data))
		if preserve(pages_path, cache_periods) is None or extra == 'CASUALCAM':
			content = track_content(target, headers=WEB_HEADER)
			htmlPage = BeautifulSoup(clear_unknown(content), 'html.parser') # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
			debug_MS("++++++++++++++++++++++++")
			debug_MS(f"(navigator.list_cameras[1]) $$$$$ PRETTIFIED-SOUP : {htmlPage.prettify()} $$$$$")
			debug_MS("++++++++++++++++++++++++")
			places = htmlPage.find('main', class_='content')
			for video in places.find_all('a', href=True):
				adress, teaser, thumb_uno = video['href'], "", None
				title_uno = video.img['alt'] if video.find('img') and video.find('img').get('alt') else None
				if not adress.endswith('.html') or title_uno is None: continue
				descrn, counter = video.find('p', class_='subt'), counter.__add__(1)
				if descrn: teaser = f"{descrn.text}..." if not descrn.text.endswith(('.', '!', '?')) else f"{descrn.text[:-1]}..." if descrn.text.endswith((',', ';')) else descrn.text
				info_link = f"{BASE_URL}{adress}" if adress.startswith('/') else f"{BASE_URL}/{adress}" if not adress.startswith(('http', '/')) else adress
				if video.find('img') and video.find('img').get('src'):
					thumb_uno = f"https:{video.img['src']}" if video.img['src'].startswith('//') else video.img['src']
					thumb_uno = thumb_uno.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', thumb_uno) else thumb_uno
				combo_partial.append({'Counter': int(counter), 'Link': info_link, 'Title': title_uno, 'Thumb': thumb_uno, 'Descript': teaser})
			preserve(pages_path, cache_periods, combo_partial)
		if preserve(pages_path, cache_periods) is not None:
			for item in preserve(pages_path, cache_periods):
				further = True if extra != 'CASUALCAM' and item['Counter'] != 0 and item['Counter'] > maximum else False
				if item['Counter'] != 0 and minimum <= item['Counter'] <= maximum:
					number, link, titling, photo, teasing = item['Counter'], item['Link'], item['Title'], item['Thumb'], item['Descript']
					vista = link.replace('webcam/', 'weather/')
					combo_uno.append({'Count_1': number, 'Link_1': link, 'Book_1': link, 'Title_1': titling, 'Thumb_1': photo, 'Teaser': teasing})
					combo_widget.append({'Count_1': number, 'Link_1': link, 'Book_1': f"{vista[:vista.rfind('/')]}.html"})
	if combo_uno:
		combo_due = _fetch_weather(combo_widget) if show_weather is True else combo_due
		merge_uno = [{**uno, **next(iter([due for due in combo_due if due.get('Link_2') == uno.get('Link_1')]), {})} for uno in combo_uno] # Merge List1 and List2 (dictionaries) by specific value if value exists else only List1 !!!
		combo_tre = _fetch_pages(combo_uno)
		merge_due = [{**uno, **tre} for uno in merge_uno for tre in combo_tre if uno.get('Link_1') == tre.get('Link_3')] # Merge List1 and List2 (dictionaries) by specific value if value exists else nothing !!!
		for riders in sorted(merge_due, key=lambda nox: int(nox.get('Count_1', 1))): # List1 = 0-11 or 0-7 || List2 = 12-15 or empty || List3 = 16-29 or 12-25
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
			debug_MS(f"(navigator.list_cameras[3]) ### Anzahl : {len(riders)} || Eintrag : {riders} ###")
			title, operation = (riders.get('Title_2', None) or riders.get('Title_1', None)), 'adding'
			if riders.get('Available') is True and (riders.get('SkyStream') or riders.get('YouStream')):
				ACTION, name = {'mode': 'playCODE', 'IDENTiTY': riders.get('Link_1')}, translation(30625).format(title)
				prefix = translation(30626).format(riders['Location'], riders['Clock'], riders['Views']) if riders.get('Views') else translation(30627).format(riders['Location'], riders['Clock'])
			elif riders.get('Available') is False or (riders.get('SkyStream') is None and riders.get('YouStream') is None):
				ACTION, name = {'mode': 'blankFUNC', 'IDENTiTY': riders.get('Link_1')}, translation(30628).format(title)
				prefix = translation(30629).format(riders['Location'], riders['Clock'], riders['Views']) if riders.get('Views') else translation(30630).format(riders['Location'], riders['Clock'])
			full_desc = riders['Story'] if len(riders.get('Story', '')) > len(riders.get('Teaser', '')) else riders['Teaser']
			full_tags = riders['Tagline'] if riders.get('Tagline') and not riders['Tagline'] in full_desc else None
			weather = translation(30631).format(riders['Degree'], riders['Outlook']) if riders.get('Degree', None) and riders.get('Outlook', None) else '[CR]'
			plot_long = prefix+weather+full_desc
			country = riders.get('Country').replace('-', ' ')
			if WEB_LANG in ['de', 'en']:
				for tt in (('Austria', translation(32101)), ('Belarus', translation(32102)), ('Cabo Verde', translation(32103)), ('Caribbean Netherlands', translation(32104)), 
					('Czech Republic', translation(32105)), ('Egypt', translation(32106)), ('Ellada', translation(32107)), ('Espana', translation(32108)),
					('Faroe Islands', translation(32109)), ('Greenland', translation(32110)), ('Hrvatska', translation(32111)), ('Norge', translation(32112)),
					('Nouvelle Caledonie', translation(32113)), ('Repubblica Di San Marino', translation(32114)), ('Srbija', translation(32115)), ('Svezia', translation(32116)),
					('United Arab Emirates', translation(32117)), ('United Kingdom', translation(32118)), ('United States', translation(32119)), ('Us Virgin Islands', translation(32120))):
					country = country.replace(*tt)
			image =(riders.get('Thumb_1', None) or riders.get('Thumb_2', None))
			debug_MS(f"(navigator.list_cameras[3]) ##### COUNT : {riders.get('Count_1')} || NAME : {name} || LINK : {riders.get('Link_1')} || COUNTRY : {country} #####")
			debug_MS(f"(navigator.list_cameras[3]) ##### THUMB : {image} || SKY_VIDEO : {riders.get('SkyStream')} || YOUTUBE : {riders.get('YouStream')} #####")
			fetch_items = context = {'Streaming': riders.get('Link_1'), 'Clearname': title, 'Title': name, 'Tagline': full_tags, 'plot_long': plot_long, 'plot_short': riders.get('Teaser', ''), \
				'Country': country, 'Rating': riders.get('Rating'), 'Voting': riders.get('Voting'), 'Studio': 'Skylinewebcams', 'Mediatype': 'movie', 'Image': image, 'Logo': riders.get('Clogo')}
			if extra != 'FAVORITES':
				if preserve(FAVORIT_FILE, 0) is not None:
					for present in preserve(FAVORIT_FILE, 0):
						if present.get('Streaming') == riders.get('Link_1'): operation = 'skipping'
			elif extra == 'FAVORITES': operation = 'removing'
			if extra != 'CASUALCAM': add_views(ACTION, create_entries(fetch_items), False, context, operation, higher)
			sending.append({'select': riders.get('Link_1'), 'name': name, 'photo': image, 'plot': plot_long, 'SkyStream': riders.get('SkyStream'), 'YouStream': riders.get('YouStream')})
		preserve(WORKS_FILE, 0, sending)
		if extra != 'CASUALCAM' and further is True:
			debug_MS(f"(navigator.list_cameras[4]) PAGES ### NOW GET NEXTPAGE ... No.{int(page)+1} ... ###")
			fetch_blades = create_entries({'Title': translation(30640).format(int(page)+1), 'Image': f"{artpic}nextpage.png"})
			add_views({'mode': 'list_cameras', 'link': target, 'page': int(page)+1, 'persist': int(maximum)+1, 'extra': extra, 'phase': phase}, fetch_blades)
	else:
		debug_MS(f'(navigator.list_cameras) ##### NO CAMERA_LIST - NO ENTRY FOR: "{extra}" FOUND #####')
		return dialog.notification(translation(30525), translation(30526).format(extra), icon, 10000)
	if extra == 'CASUALCAM' and sending:
		video_code = next(filter(lambda cxs: (cxs.get('SkyStream', None) or cxs.get('YouStream', None)), sending), None)
		if video_code: return playCODE(video_code['select'])
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def _fetch_weather(weather_table, primodo=[]):
	complete = track_several(weather_table, 'GET', 'TEXT', WEB_HEADER)
	if complete:
		for points, links, books, casts in complete:
			if casts not in ['', None]:
				degree, outlook = (None for _ in range(2))
				tempPage = BeautifulSoup(clear_unknown(casts), 'html.parser')
				predict = tempPage.find('div', class_='cast today')
				degree = predict.find('span', class_='degrees').text if predict.find('span', class_='degrees') else None
				forecast = predict.find('p', class_='foretext')
				if forecast: outlook = ' '.join(forecast.text.split(' ')[:2]) if WEB_LANG in ['de', 'en'] else forecast.text
				debug_MS("* * * * * * * * * * * * * * * * * * * * * * * * *")
				debug_MS(f"(navigator.fetch_weather[2]) XXX COUNT-02 : {points} || LINK-02 : {books} || DEGREE-02 : {degree} || FORECAST-02 : {outlook} XXX")
				primodo.append({'Count_2': int(points), 'Link_2': links, 'Book_1': books, 'Degree': degree, 'Outlook': outlook})
	return primodo

def _fetch_pages(pages_table, secondo=[]):
	package = track_several(pages_table, 'GET', 'TEXT', WEB_HEADER)
	if package:
		for points, links, books, article in package:
			if article not in ['', None]:
				story, (thumb_due, youtube, skyline) = "", (None for _ in range(3))
				correct = clear_unknown(article) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
				infoPage = BeautifulSoup(correct, 'html.parser')
				record = infoPage.find('main', class_='content')
				title_due = record.find('h1').text if record.find('h1') else 'UNKNOWN'
				tagline = record.find('h2').text if record.find('h2') else None
				tagline = f"{tagline[:125]}..." if tagline and len(tagline) > 125 else tagline
				flagpart = links.split('webcam/')[1].split('/')[0]
				regiopart = [span.string for span in record.find_all('span', itemprop='name')]
				if len(regiopart) > 1:
					location = f"{clear_nation(regiopart[1])}, {clear_nation(regiopart[0])}" if regiopart[1] != regiopart[0] else clear_nation(regiopart[0])
					country = clear_nation(regiopart[0])
				else: location, country = clear_nation(flagpart).title(), clear_nation(flagpart).title() if clear_nation(flagpart) != 'USA' else clear_nation(flagpart)
				timing = record.find('span', id='servertime').string if record.find('span', id='servertime') else '--:--'
				depict = record.find('div', class_='descr')
				if depict: story = f"{depict.text[:700]}..." if not depict.text[:700].endswith(('.', '!', '?')) else f"{depict.text[:699]}..." if depict.text[:700].endswith((',', ';')) else depict.text[:700]
				views = record.find('span', id='v_now').text if record.find('span', id='v_now') else None
				rating = record.find('span', itemprop='ratingValue').text if record.find('span', itemprop='ratingValue') else None
				voting = record.find('span', itemprop='ratingCount').text if record.find('span', itemprop='ratingCount') else None
				if infoPage.find('meta', property='og:image') and infoPage.find('meta', property='og:image').get('content'):
					thumb_due = infoPage.find('meta', property='og:image').get('content')
					thumb_due = thumb_due.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', thumb_due) else thumb_due
				clogo = f"{flagpic}{flagpart}.png" if xbmcvfs.exists(f"{flagpic}{flagpart}.png") else None
				if re.search(r'https://www.youtube.com/iframe', correct):
					source = re.compile(r''',videoId:["']([^"']+)["'],''', re.S).findall(correct) # ,videoId:'SJ7dRgcEvBs',
					youtube = source[0] if source and len(source[0]) > 0 else None
				else:
					source = re.compile(r''',source:["']([^"']+)["'],''', re.S).findall(correct) # ,source:'livee.m3u8?a=1kthl1f6neoehp6fq44bq2o4e0',
					skyline = f"https://hd-auth.skylinewebcams.com/{source[0].replace('livee', 'live')}" if source and len(source[0]) > 0 else None
				works = False if youtube is None and skyline is None else True
				embrace = {'Count_3': int(points), 'Link_3': links, 'Title_2': title_due, 'Tagline': tagline, 'Story': story, 'Location': location, 'Country': country, 'Clock': timing,
					'Views': views, 'Rating': rating, 'Voting': voting, 'Thumb_2': thumb_due, 'Clogo': clogo, 'SkyStream': skyline, 'YouStream': youtube, 'Available': works}
				debug_MS("]-------------------------------------------------")
				debug_MS(f"(navigator.fetch_pages[3]) ### COUNT-03 : {points} || LINK-03 : {books} || ENTRY-03 : {embrace} ###")
				secondo.append(embrace)
	return secondo

def playCODE(ORIGIN): # https://hd-auth.skylinewebcams.com/live.m3u8?a=aaki37oq67e624gn8qee12n5f2
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### SKYLINE_LINK : {ORIGIN} ###")
	STREAM, UNSOLVED, (youtube, skyline, FINAL_URL) = 'UNKNOWN', 'COOKIE=PHPSESSID NOT FOUND', (False for _ in range(3))
	for elem in preserve(WORKS_FILE, 0):
		if elem['select'] != '00' and elem['select'] == ORIGIN:
			full_title, clear_title = re.sub(r'(\[/?B\])', '', elem['name']), re.sub(r'(\[.*?\]|■  )', '', elem['name'])
			small_title, photo, teaser = f"{clear_title[:20].strip()} ...", elem['photo'], elem['plot']
			skyline, youtube = elem['SkyStream'], elem['YouStream']
			debug_MS(f"(navigator.playCODE[1]) ### WORK_FILE-Line : {elem} ###")
	if youtube:
		debug_MS(f"(navigator.playCODE[2]) ***** TAKE - REDIRECTED : https://youtu.be/{youtube} || (Youtube-Redirect) *****")
		you_verify = track_content(f"https://youtu.be/{youtube}", 'GET', 'TRACK', WEB_HEADER, 'https://www.youtube.com', 'https://www.youtube.com/', timeout=10)
		STREAM, FINAL_URL = 'YOUTUBE', f"plugin://plugin.video.youtube/play/?video_id={youtube}" if you_verify.status_code in [200, 201, 202] else False
	if not FINAL_URL and skyline:
		DATAS = track_content(ORIGIN, queries='TRACK', timeout=10)
		PHP_SESSID = DATAS.cookies.get('PHPSESSID') if DATAS.status_code in [200, 201, 202, 300, 301, 302] and 'PHPSESSID' in DATAS.cookies else None
		if PHP_SESSID:
			UNSOLVED = f"https://hd-auth.skylinewebcams.com/live.m3u8?a={PHP_SESSID}|{urlencode({'User-Agent': WEB_AGENT, 'Referer': 'https://www.skylinewebcams.com/'}, safe='/:?=&')}"
			sky_verify = track_content(UNSOLVED, queries='TRACK', timeout=10)
			STREAM, FINAL_URL = 'SKYLINE', UNSOLVED if sky_verify.status_code in [200, 201, 202, 300, 301, 302] else False
		debug_MS(f"(navigator.playCODE[2]) ***** TAKE - DIRECT : {UNSOLVED} || (Skyline-Direct) *****")
	if FINAL_URL:
		log(f"(navigator.playCODE) {STREAM}_stream : {FINAL_URL}")
		LPM = xbmcgui.ListItem(full_title, path=FINAL_URL, offscreen=True)
		teaser = ' ' if teaser in ['', 'None', None] else teaser
		if KODI_BUILD >= 20:
			LPM.getVideoInfoTag().setTitle(full_title), LPM.getVideoInfoTag().setPlot(teaser), LPM.getVideoInfoTag().setStudios(['Skylinewebcams'])
		else: LPM.setInfo('Video', {'Title': full_title, 'Plot': teaser, 'Studio': 'Skylinewebcams'})
		LPM.setArt({'icon': icon, 'thumb': photo, 'poster': photo})
		if prefer_player == 1 and xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)') and skyline and STREAM == 'SKYLINE':
			IA_NAME = 'inputstream.ffmpegdirect'
			LPM.setMimeType('application/vnd.apple.mpegurl'); LPM.setProperty('inputstream', IA_NAME)
			LPM.setProperty(f'{IA_NAME}.stream_mode', 'default')
			LPM.setProperty(f'{IA_NAME}.manifest_type', 'hls')
			LPM.setProperty(f'{IA_NAME}.is_realtime_stream', 'true')
			if open_modus != 0:
				LPM.setProperty(f'{IA_NAME}.open_mode', 'ffmpeg' if open_modus == 1 else 'curl')
		xbmc.Player().play(item=FINAL_URL, listitem=LPM)
		xbmc.sleep(10000)
		if not xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)') and not xbmc.Player().isPlaying():
			return dialog.notification(translation(30527).format(small_title), translation(30528), icon, 15000)
	else:
		if youtube:
			failing(f"(navigator.playCODE) $$$$$ Playback of the stream is NOT possible; the Stream-URL on the *skylinewebcams.com* website is BROKEN or OFFLINE !!! $$$$$\n $$$$$ TITLE : {clear_title} || YOUTUBE-ID : {youtube} $$$$$")
		elif skyline:
			failing(f"(navigator.playCODE) $$$$$ Playback of the stream is NOT possible; the Stream-URL on the *skylinewebcams.com* website is BROKEN or OFFLINE !!! $$$$$\n $$$$$ TITLE : {clear_title} || VIDEO : {skyline} $$$$$")
		return dialog.notification(translation(30527).format(small_title), translation(30529), icon, 15000)

def list_favorites(watching=[]):
	debug_MS("(navigator.list_favorites) ------------------------------------------------ START = list_favorites -----------------------------------------------")
	if preserve(FAVORIT_FILE, 0) is not None: # List all LIVE cameras in favourites - go directly to the 'list_cameras' folder
		for snippet in sorted(preserve(FAVORIT_FILE, 0), key=lambda vsx: clear_umlaut(vsx.get('Clearname', 'zorro')).lower()):
			debug_MS(f"(navigator.list_favorites[1]) ##### NAME : {snippet.get('Clearname')} || LINK : {snippet.get('Streaming')} || THUMB : {snippet.get('Image')} #####")
			watching.append({'Stream': snippet.get('Streaming'), 'Title': snippet.get('Clearname'), 'Photo': snippet.get('Image'), 'Region': snippet.get('country'), 'Teaser': snippet.get('plot_short')})
		if watching:
			return list_cameras(watching, 1, 0, 'FAVORITES', 'Favourites')
	return dialog.notification(translation(30530), translation(30531), icon, 10000)

def favorit_construct(**kwargs):
	TOPS = []
	if preserve(FAVORIT_FILE, 0) is not None:
		TOPS = preserve(FAVORIT_FILE, 0)
	if kwargs['action'] == 'ADD':
		kwargs.pop('mode', None); kwargs.pop('action', None); kwargs.pop('plot_long', None); kwargs.pop('Studio', None)
		TOPS.append({key: value for key, value in kwargs.items() if value not in ['', 'None', None]})
		preserve(FAVORIT_FILE, 0, TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30532), translation(30533).format(kwargs['Clearname']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Streaming') != kwargs.get('Streaming')]
		preserve(FAVORIT_FILE, 0, TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30532), translation(30534).format(kwargs['Clearname']), icon, 10000)

def add_views(params, listitem, folder=True, context={}, handling='default', higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enable_decrease and button_place == 1 and higher is True:
		entries.append([translation(30650), f"RunPlugin({build_mass({'mode': 'calling_main'})})"])
	if handling == 'adding' and context:
		entries.append([translation(30651), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
