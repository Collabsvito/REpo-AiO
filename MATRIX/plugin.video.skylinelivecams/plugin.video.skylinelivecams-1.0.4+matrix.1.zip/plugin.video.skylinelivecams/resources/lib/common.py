﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import random
import gzip
import time
from urllib.parse import parse_qsl, urlparse, urlencode, quote, quote_plus, unquote_plus
from bs4 import BeautifulSoup, UnicodeDammit
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from .external import * # psf_requests, psf_requests.Retry, psf_requests.HTTPAdapter


socket.setdefaulttimeout(30)
HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_desc						= addon.getAddonInfo('description')
addon_folder						= xbmcvfs.translatePath(addon.getAddonInfo('path'))
addon_profile					= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
tempDATA							= xbmcvfs.translatePath(os.path.join(addon_profile, 'tempDATA', ''))
WORKS_FILE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'episode_data.gz'))
FAVORIT_FILE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'favorites_SKYLINE.gz'))
defaultFanart						= os.path.join(addon_folder, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addon_folder, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addon_folder, 'resources', 'media', '')
flagpic								= os.path.join(addon_folder, 'resources', 'media', 'country', '')
WEB_LANG							= {0: 'de', 1: 'en', 2: 'fr', 3: 'es', 4: 'it', 5: 'el', 6: 'pl', 7: 'ru', 8: 'hr', 9: 'sl'}[int(addon.getSetting('language'))]
# Available Languages(settings) ~ German=0|English=1|French=2|Spanish=3|Italian=4|Greek=5|Polish=6|Russian=7|Croatian=8|Slovenian=9
# Language Codes(SkylineWebCams) ~ 0: de|1: en|2: fr|3: es|4: it|5: el|6: pl|7: ru|8: hr|9: sl
cache_periods					= int(addon.getSetting('cache_rhythm'))
limitation							= int(addon.getSetting('max_entries'))
show_weather					= (True if addon.getSetting('show_weather') == 'true' else False)
using_fanart						= addon.getSetting('use_fanart') == 'true'
prefer_player						= int(addon.getSetting('prefer_player'))
open_modus						= int(addon.getSetting('open_modus'))
enable_decrease				= addon.getSetting('show_homebutton') == 'true'
button_place						= int(addon.getSetting('button_place'))
enable_tune						= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_BUILD						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2])
# IMG_flags						= 'https://img.freeflagicons.com/thumb/round_icon/{}/{}_640.png'
BASE_URL							= "https://www.skylinewebcams.com"
SKY_FULL							= f"{BASE_URL}/{WEB_LANG}/webcam.html"
SKY_TOPS							= f"{BASE_URL}/{WEB_LANG}/top-live-cams.html"
SKY_NEWS							= f"{BASE_URL}/{WEB_LANG}/new-livecams.html"
SKY_LANG							= f"{BASE_URL}/{WEB_LANG}.html"
WEB_AGENT						= 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0'
WEB_HEADER					= {'Cache-Control': 'public, max-age=300', 'Accept': 'text/html,application/xhtml+xml,*/*', 'DNT': '1', 'Upgrade-Insecure-Requests': '1', 'Accept-Encoding': 'gzip, deflate', 'sec-ch-ua-platform': 'Windows', 'X-Forwarded-For': '127.0.0.1', 'Cookie': 'Default'}

xbmcplugin.setContent(ADDON_HANDLE, 'movies')

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def get_driftless():
	gateway = random.choice(['CHROME', 'FIREFOX', 'EDGE'])
	windows = random.choice(['Windows NT 10.0', 'Windows NT 7.0', 'Windows NT 6.3', 'Windows NT 6.2', 'Windows NT 6.1'])
	bits_one, bits_two = random.choice(['; WOW64', '; Win64; x64', '']), random.choice(['; WOW64', '; Win64; x64'])
	features = bits_one if windows[:12] == 'Windows NT 6' else bits_two
	webkitts = 'AppleWebKit/537.36 (KHTML, like Gecko)'
	if gateway == 'CHROME':
		selection = f"{random.randint(129, 149)}.{random.randint(0, 9)}.{random.randint(1000, 9999)}.{random.randint(0, 99)}" # Chrome (129-149) // last edited: 25.07.26
		new_agent = f"Mozilla/5.0 ({windows}{features}) {webkitts} Chrome/{selection} Safari/537.36"
	elif gateway == 'FIREFOX':
		selection = random.randint(132, 152) # Firefox (132-152) // last edited: 25.07.26
		new_agent = f"Mozilla/5.0 ({windows}{features}; rv:{selection}.0) Gecko/20100101 Firefox/{selection}.0"
	else:
		ciphers = random.randint(129, 149) # Edge (129-149) // last edited: 25.07.26
		selection = f"{random.randint(0, 9)}.{random.randint(1000, 9999)}.{random.randint(0, 99)}"
		new_agent = f"Mozilla/5.0 ({windows}{features}) {webkitts} Chrome/{int(ciphers)-3}.{selection} Safari/537.36 Edg/{ciphers}.{selection}"
	return new_agent

def track_several(stacks, method='GET', queries='TEXT', headers={}, timeout=4, ORG=BASE_URL, REF=f"{BASE_URL}/", workers=20):
	COMBI_NEW, number, counter, fixation = [], len(stacks), 0, psf_requests.Session()
	pretence = psf_requests.Retry(total=5, backoff_factor=0.2, status_forcelist=[500, 502, 503, 504])
	fixation.mount('https://', psf_requests.HTTPAdapter(pool_connections=int(number), pool_maxsize=int(number), max_retries=pretence, pool_block=True)) # Pool-Verbindungen und -Grösse auf tatsächlichen Inhalt festlegen, um Fehlermeldungen zu vermeiden
	def download(pos, demand, link):
		response, heading = None, {**headers, **{'User-Agent': get_driftless(), 'Origin': ORG, 'Referer': REF}}
		try:
			response = fixation.request(method, link, headers=heading, allow_redirects=True, timeout=timeout)
			response.raise_for_status()
			debug_MS(f"(common.track_several[1]) === POS : {pos} || STATUS : {response.status_code} || URL : {link} || HEADER : {response.request.headers} ===")
		except Exception as exc_uno:
			failing(f"(common.track_several[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === LINK : {link} === FAILURE : {exc_uno} #####")
		return [pos, demand, link, response.text] if response else [pos, demand, link, None]
	with ThreadPoolExecutor(max_workers=workers) as executor:
		debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
		picker = [executor.submit(download, single['Count_1'], single['Link_1'], single['Book_1']) for single in stacks]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for future, section in zip(as_completed(picker), stacks):
			counter += 1
			try:
				COMBI_NEW.append(future.result())
			except Exception as exc_due:
				if counter == 1:
					dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(exc_due), icon, 12000)
				failing(f"(common.track_several[2]) ERROR - EXEPTION - ERROR ##### POS : {section['Count_1']} === URL : {section['Book_1']} === FAILURE : {exc_due} #####")
				executor.shutdown()
		if COMBI_NEW:
			matching = [flop for flop in COMBI_NEW[:] if flop[3] is None]
			if len(matching) == number or len(matching) > 9:
				dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 12000)
	return COMBI_NEW

def track_content(url, method='GET', queries='TEXT', headers={}, ORG=BASE_URL, REF=f"{BASE_URL}/", redirects=True, data=None, json=None, timeout=30):
	ANSWER, heading = None, {**headers, **{'User-Agent': get_driftless(), 'Origin': ORG, 'Referer': REF}}
	try:
		response = psf_requests.request(method, url, headers=heading, allow_redirects=redirects, timeout=timeout)
		ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
		debug_MS(f"(common.track_content) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
	except Exception as exc: # No JSON object could be decoded
		failing(f"(common.track_content) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {exc} #####")
		dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 12000)
		return sys.exit(0)
	return ANSWER

def preserve(store, timing, facts=None, arrive=None): # timing = cache_periods in Hours storing of FOLDER_FILES / 0 or 1 for all other FILES
	if facts is not None:
		with gzip.open(store, 'wt', encoding='utf-8') as topics:
			json.dump(facts, topics, indent=2, sort_keys=True)
	else:
		if xbmcvfs.exists(store) and os.path.exists(store) and os.stat(store).st_size > 0:
			NOW_UTC, FILE_UTC = time.time(), (os.path.getmtime(store) + 60*60*int(timing)) if int(timing) != 0 else int(timing)
			if int(timing) == 0 or (int(timing) != 0 and NOW_UTC < FILE_UTC):
				with gzip.open(store, 'rt', encoding='utf-8') as topics:
					arrive = json.load(topics)
			else: xbmcvfs.delete(store)
		return arrive

def clear_storage():
	debug_MS("(common.clear_storage) -------------------------------------------------- START = clear_storage --------------------------------------------------")
	debug_MS("(common.clear_storage) ========== Delete the Addon-Cache now ==========")
	if xbmcvfs.exists(tempDATA):
		shutil.rmtree(tempDATA, ignore_errors=True) # Delete tempDATA-Folder
	xbmc.sleep(1000)
	return dialog.ok(addon_id, translation(30501))

def clear_umlaut(changes):
	if changes is not None:
		for cu in (('Ä', 'Ae'), ('ä', 'ae'), ('Ö', 'Oe'), ('ö', 'oe'), ('Ü', 'Ue'), ('ü', 'ue'), ('ß', 'ss')):
			changes = changes.replace(*cu)
		changes = changes.strip()
	return changes

def clear_unknown(text):
	if text is not None:
		text = re.sub(r'<h3>.*?</h3>', '', text)
		for ea in (('<strong>', ''), ('</strong>', ''), ('<b>', ''), ('</b>', ''), ('<em>', ''), ('</em>', ''), ('<br>', ' '), ('class="descr"><p>', 'class="descr">'), ('<p>', '[CR]')):
			text = text.replace(*ea)
		convert = UnicodeDammit(text.strip()) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
		return convert.unicode_markup
	return None

def clear_nation(changes):
	if changes is not None and changes not in (('Dominican Republic', 'Dominikanische Republik', 'Central African Republic', 'Zentralafrikanische Republik')):
		for cn in ((' ', ' '), ('The ', ''), ('Die ', ''), (' Republic', ''), (' Republik', ''), ('Republic ', ''), ('Republik ', ''), ('Sint Maarten', 'Sint Marteen'), ('United Kingdom', 'Great Britain'),
			('Vereinigtes Königreich', 'Großbritannien'), ('United States', 'USA'), ('Vereinigte Staaten', 'USA'), ('(US Virgin Islands)', ''), ('(Amerikanische Jungferninseln)', '')):
			changes = changes.replace(*cn)
		changes = changes.strip()
	return changes

def create_entries(metadata, SIGNS=None):
	listitem = xbmcgui.ListItem(metadata['Title'])
	vinfo = listitem.getVideoInfoTag() if KODI_BUILD >= 20 else {}
	if KODI_BUILD >= 20: vinfo.setTitle(metadata['Title'])
	else: vinfo['Title'] = metadata['Title']
	if metadata.get('Tagline', ''):
		if KODI_BUILD >= 20: vinfo.setTagLine(metadata['Tagline'])
		else: vinfo['Tagline'] = metadata['Tagline']
	description = metadata['plot_long'] if metadata.get('plot_long') not in ['', 'None', None] else ' '
	if KODI_BUILD >= 20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if metadata.get('Country', ''):
		if KODI_BUILD >= 20: vinfo.setCountries([metadata['Country']])
		else: vinfo['Country'] = metadata['Country']
	if str(metadata.get('Rating')).replace('.', '').isdecimal() and str(metadata.get('Voting')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setRating(float(metadata['Rating']), int(metadata['Voting']), 'user', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		else: listitem.setRating('user', float(metadata['Rating']), int(metadata['Voting']), True) # listitem.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
	if metadata.get('Studio', ''):
		if KODI_BUILD >= 20: vinfo.setStudios([metadata['Studio']])
		else: vinfo['Studio'] = metadata['Studio']
	if metadata.get('Mediatype', ''):
		if KODI_BUILD >= 20: vinfo.setMediaType(metadata['Mediatype'])
		else: vinfo['Mediatype'] = metadata['Mediatype']
	picture, piclogo = metadata.get('Image', icon), metadata.get('Logo', None)
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'clearlogo': piclogo})
	if using_fanart: listitem.setArt({'fanart': defaultFanart})
	if KODI_BUILD < 20: listitem.setInfo('Video', vinfo)
	return listitem
