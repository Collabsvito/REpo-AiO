﻿# -*- coding: utf-8 -*-

from .common import *


def main_menu():
	for TITLE, PATH in [(30601, {'mode': 'list_favorites'}), (30602, {'mode': 'list_cameras', 'link': SKY_TOPS, 'extra': 'CASUALCAM'}),
		(30603, {'mode': 'list_cameras', 'link': SKY_NEWS, 'extra': 'NEWEST'}), (30604, {'mode': 'list_cameras', 'link': SKY_TOPS, 'extra': 'POPULAR'}),
		(30605, {'mode': 'list_overview', 'link': SKY_FULL, 'extra': 'COUNTRIES'}), (30606, {'mode': 'list_overview', 'link': SKY_CATS, 'extra': 'CATEGORIES'})]:
		fetch_items = {'Title': translation(TITLE), 'Image': f"{artpic}favourites.png" if TITLE == 30601 else icon}
		add_views(PATH, create_entries(fetch_items), folder=False if TITLE == 30602 else True)
	add_views({'mode': 'clear_storage'}, create_entries({'Title': translation(30607).format(cache_periods), 'Image': f"{artpic}remove.png"}), False)
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_overview(target, extra, phase):
	debug_MS("(navigator.list_overview) -------------------------------------------------- START = list_overview --------------------------------------------------")
	debug_MS(f"(navigator.list_overview) ### URL = {target} ### EXTRA = {extra} ### COUNTRY = {phase} ###")
	found, primodo, data_one = 0, [], track_content(target, headers=WEB_HEADER)
	htmlPage = BeautifulSoup(clear_unknown(data_one), 'html.parser') # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.list_overview[1]) $$$$$ PRETTIFIED-SOUP : {htmlPage.prettify()} $$$$$")
	debug_MS("++++++++++++++++++++++++")
	if extra == 'COUNTRIES':
		chapters = htmlPage.find('div', class_='continents')
	elif extra == 'METROPOLS':
		section = htmlPage.find('section', class_='section')
		chapters = section.find('nav', class_='chips')
	else: chapters = htmlPage.find('section', class_='section')
	for item in chapters.find_all('a', href=True):
		adress, plot, photo = item['href'], "", None
		if not adress.endswith('.html'): continue
		if extra in ['COUNTRIES', 'METROPOLS']:
			title = item.get_text().replace('The ', '').replace('Die ', '') if WEB_LANG =='de'else item.get_text() # Der Titel ist versteckt im Link, extrahiert wird dieser mit: 'get_text()' - z.B. tag.get_text(separator=" ", strip=True)
			if extra == 'COUNTRIES': photo = f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png" if xbmcvfs.exists(f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png") else photo
			elif extra == 'METROPOLS': photo = f"{flagpic}{adress.split('/')[-2].replace('.html', '')}.png" if xbmcvfs.exists(f"{flagpic}{adress.split('/')[-2].replace('.html', '')}.png") else photo
		else:
			title = item.img['alt'] if item.find('img') and item.find('img').get('alt') else None
			if title is None: continue
		name, new_phase, found = f"[B]{title}[/B]", title, found.__add__(1)
		descrn = item.find('div', class_='meta meta-txt')
		if descrn: plot = f"{descrn.text}..." if not descrn.text.endswith(('.', '!', '?')) else f"{desc.text[:-1]}..." if descrn.text.endswith((',', ';')) else descrn.text
		piper = f"{BASE_URL[:-1]}{adress}" if adress.startswith('/') else f"{BASE_URL}{adress}" if not adress.startswith(('http', '/')) else adress
		if item.find('img') and item.find('img').get('src'):
			photo = f"https:{item.img['src']}" if item.img['src'].startswith('//') else item.img['src']
			photo = photo.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', photo) else photo
		primodo.append({'Sorting': title, 'Link': piper, 'Name': name, 'Phase': new_phase, 'Image': photo, 'Plot': plot})
	if primodo and extra == 'METROPOLS' and found == 1:
		debug_MS("(navigator.list_overview[2]) ----- Only one Entry FOUND - goto = list_cameras -----")
		return list_cameras(target, 1, 0, extra, phase)
	elif primodo and ((extra == 'METROPOLS' and found > 1) or (extra != 'METROPOLS' and found >= 1)):
		if extra == 'METROPOLS': 
			fetch_firsts = create_entries({'Title': translation(30623).format(phase), 'Image': primodo[0]['Image']})
			add_views({'mode': 'list_cameras', 'link': target, 'extra': extra, 'phase': phase}, fetch_firsts)
		for blocks in sorted(primodo, key=lambda vsx: clear_umlaut(vsx.get('Sorting', 'zorro')).lower()):
			action = 'list_overview' if extra == 'COUNTRIES' else 'list_cameras'
			new_extra = 'METROPOLS' if extra == 'COUNTRIES' else extra
			fetch_items = create_entries({'Title': blocks.get('Name'), 'Plot': blocks.get('Plot'), 'Image': blocks.get('Image')})
			add_views({'mode': action, 'link': blocks.get('Link'), 'extra': new_extra, 'phase': blocks.get('Phase')}, fetch_items)
			debug_MS(f"(navigator.list_overview[2]) ##### NAME : {blocks.get('Name')} || THUMB : {blocks.get('Image')} || LINK : {blocks.get('Link')} #####")
	else:
		failing(f'(navigator.list_overview) ##### NO OVERVIEW-LIST - NO ENTRY FOR: "{extra}" FOUND #####')
		return dialog.notification(translation(30527), translation(30528).format(extra), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_cameras(target, page, persist, extra, phase):
	debug_MS("(navigator.list_cameras) -------------------------------------------------- START = list_cameras --------------------------------------------------")
	debug_MS(f"(navigator.list_cameras) ### URL : {target} ### PAGE = {page} ### LIMIT = {limitation} ### POSITION = {persist} ### EXTRA = {extra} ### CATEGORY = {phase} ###")
	(merge_uno, merge_due), (combo_sector, combo_partial, combo_widget, combo_uno, combo_due, combo_tre, sending) = ({} for _ in range(2)), ([] for _ in range(7))
	default, counter, further = 0 if int(page) == 1 else int(page) - 1, 0, False
	minimum = int(default)*int(limitation) + 1
	maximum = int(page)*int(limitation) if extra != 'CASUALCAM' else 25
	higher = True if extra not in ['CASUALCAM', 'FAVORITES'] and int(page) > 1 else False
	if enable_decrease and button_place == 0 and higher is True:
		add_views({'mode': 'calling_main'}, create_entries({'Title': translation(30624), 'Image': f"{artpic}backmain.png"}))
	if isinstance(target, (dict, list)):
		for item in target:
			piper, titling, photo, teasing = item['Link'], item['Title'], item.get('Thumb'), (item.get('Statement') or '')
			vista, counter = piper.replace('webcam/', 'weather/'), counter.__add__(1)
			combo_uno.append({'Count_1': int(counter), 'Book_1': piper, 'Link_1': piper, 'Title_1': titling, 'Thumb_1': photo, 'Teaser': teasing})
			combo_widget.append({'Count_1': int(counter), 'Book_1': piper, 'Link_1': fr"{vista[:vista.rfind('/')]}.html"})
	else:
		if not xbmcvfs.exists(tempDATA) and not os.path.exists(tempDATA):
			xbmcvfs.mkdirs(tempDATA)
		pages_data = f"{urlparse(target).path.replace('/', '_').replace('.html', '')}.gz"
		pages_path = xbmcvfs.translatePath(os.path.join(tempDATA, pages_data))
		if preserve(pages_path, timing=cache_periods) is None or extra == 'CASUALCAM':
			data_one = track_content(target, headers=WEB_HEADER)
			htmlPage = BeautifulSoup(clear_unknown(data_one), 'html.parser') # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
			debug_MS("++++++++++++++++++++++++")
			debug_MS(f"(navigator.list_cameras[1]) $$$$$ PRETTIFIED-SOUP : {htmlPage.prettify()} $$$$$")
			debug_MS("++++++++++++++++++++++++")
			chapters = htmlPage.find_all('section', class_='section')
			for places in chapters: combo_sector.extend(places.find_all('div', class_='cam'))
			for video in combo_sector:
				clipping, teaser, thumb_uno = video.find('a', class_='cam-title'), "", None
				adress = clipping.get('href') if clipping else None
				title_uno = clipping.text if clipping and adress else None
				if adress is None or not adress.endswith('.html') or title_uno is None: continue
				descrn, counter = video.find('div', class_='meta meta-txt'), counter.__add__(1)
				if descrn: teaser = f"{descrn.text}..." if not descrn.text.endswith(('.', '!', '?')) else f"{descrn.text[:-1]}..." if descrn.text.endswith((',', ';')) else descrn.text
				link_uno = f"{BASE_URL[:-1]}{adress}" if adress.startswith('/') else f"{BASE_URL}{adress}" if not adress.startswith(('http', '/')) else adress
				if video.find('img') and video.find('img').get('src'):
					thumb_uno = f"https:{video.img['src']}" if video.img['src'].startswith('//') else video.img['src']
					thumb_uno = thumb_uno.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', thumb_uno) else thumb_uno
				combo_partial.append({'Counter': int(counter), 'Link': link_uno, 'Title': title_uno, 'Thumb': thumb_uno, 'Statement': teaser})
			if combo_partial: preserve(pages_path, combo_partial, cache_periods)
		if preserve(pages_path, timing=cache_periods) is not None:
			for item in preserve(pages_path, timing=cache_periods):
				further = True if extra != 'CASUALCAM' and item['Counter'] != 0 and item['Counter'] > maximum else False
				if item['Counter'] != 0 and minimum <= item['Counter'] <= maximum:
					number, piper, titling, photo, teasing = item['Counter'], item['Link'], item['Title'], item['Thumb'], item['Statement']
					vista = piper.replace('webcam/', 'weather/')
					combo_uno.append({'Count_1': number, 'Book_1': piper, 'Link_1': piper, 'Title_1': titling, 'Thumb_1': photo, 'Teaser': teasing})
					combo_widget.append({'Count_1': number, 'Book_1': piper, 'Link_1': fr"{vista[:vista.rfind('/')]}.html"})
	if combo_uno:
		if extra == 'CASUALCAM': dialog.notification(translation(30525), translation(30526), icon, 6000)
		combo_due = _fetch_weather(combo_widget) if show_weather is True and extra != 'CASUALCAM' else combo_due # Bei Aufruf von >CASUALCAM< den Ablauf beschleunigen und das Wetter nicht anfordern
		merge_uno = [{**uno, **next(iter([due for due in combo_due if due.get('Book_2') == uno.get('Book_1')]), {})} for uno in combo_uno] # Merge List1 and List2 (dictionaries) by specific value if value exists else only List1 !!!
		combo_tre = _fetch_pages(combo_uno)
		merge_due = [{**uno, **tre} for uno in merge_uno for tre in combo_tre if uno.get('Book_1') == tre.get('Book_3')] # Merge List1 and List3 (dictionaries) by specific value if value exists else nothing !!!
		for riders in sorted(merge_due, key=lambda nox: int(nox.get('Count_1', 1))): # List1 = 0-6 || List2 = 7-11 or empty || List3 = 12-26 or 7-21
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
			debug_MS(f"(navigator.list_cameras[4]) ### Anzahl : {len(riders)} || Eintrag : {riders} ###")
			title, operation = (riders.get('Title_2', None) or riders.get('Title_1', None)), 'adding'
			if riders.get('Available') is True and (riders.get('SkyStream') or riders.get('YouStream')):
				action, name = {'mode': 'play_video', 'link': riders.get('Book_1')}, translation(30625).format(title)
				prefix = translation(30626).format(riders['Location'], riders['Clock'], riders['Views']) if riders.get('Views') else translation(30627).format(riders['Location'], riders['Clock'])
			elif riders.get('Available') is False or (riders.get('SkyStream') is None and riders.get('YouStream') is None):
				action, name = {'mode': 'blankFUNC', 'link': riders.get('Book_1')}, translation(30628).format(title)
				prefix = translation(30629).format(riders['Location'], riders['Clock'], riders['Views']) if riders.get('Views') else translation(30630).format(riders['Location'], riders['Clock'])
			full_desc = riders['Story'] if len(riders.get('Story', '')) > len(riders.get('Teaser', '')) else riders['Teaser']
			full_desc = full_desc.replace(' [CR]', '[CR]').strip()
			full_desc = full_desc[4:].strip() if full_desc[:4] == '[CR]' else full_desc # Unnötige Abstände am Anfang des Plot entfernen
			full_tags = riders['Tagline'] if riders.get('Tagline') and not riders['Tagline'] in full_desc else None
			weather = translation(30631).format(riders['Degree'], riders['Outlook']) if riders.get('Degree', None) and riders.get('Outlook', None) else '[CR]'
			plot_long = prefix+weather+full_desc
			country = riders.get('Country').replace('-', ' ')
			if WEB_LANG in ['de', 'en']:
				for tt in (('Austria', translation(32101)), ('Belarus', translation(32102)), ('Cabo Verde', translation(32103)), ('Caribbean Netherlands', translation(32104)), 
					('Czech Republic', translation(32105)), ('Egypt', translation(32106)), ('Ellada', translation(32107)), ('Espana', translation(32108)),
					('Faroe Islands', translation(32109)), ('Greenland', translation(32110)), ('Hrvatska', translation(32111)), ('Norge', translation(32112)),
					('Nouvelle Caledonie', translation(32113)), ('Repubblica Di San Marino', translation(32114)), ('Srbija', translation(32115)), ('Svezia', translation(32116)),
					('United Arab Emirates', translation(32117)), ('United Kingdom', translation(32118)), ('United States', translation(32119)), ('Us Virgin Islands', translation(32120))):
					country = country.replace(*tt)
			image =(riders.get('Thumb_1', None) or riders.get('Thumb_2', None))
			debug_MS(f"(navigator.list_cameras[4]) ##### COUNT : {riders.get('Count_1')} || NAME : {name} || LINK : {riders.get('Book_1')} || COUNTRY : {country} #####")
			debug_MS(f"(navigator.list_cameras[4]) ##### THUMB : {image} || SKY_VIDEO : {riders.get('SkyStream')} || YOUTUBE : {riders.get('YouStream')} #####")
			fetch_items = context = {'Streaming': riders.get('Book_1'), 'Clearname': title, 'Title': name, 'Tagline': full_tags, 'plot_long': plot_long, 'plot_short': riders.get('Teaser', ''), \
				'Country': country, 'Rating': riders.get('Rating'), 'Voting': riders.get('Voting'), 'Studio': 'Skylinewebcams', 'Mediatype': 'movie', 'Image': image, 'Logo': riders.get('Clogo')}
			if extra != 'FAVORITES':
				if preserve(FAVORIT_FILE):
					for present in preserve(FAVORIT_FILE):
						if present.get('Streaming') == riders.get('Book_1'): operation = 'skipping'
			elif extra == 'FAVORITES': operation = 'removing'
			if extra != 'CASUALCAM': add_views(action, create_entries(fetch_items), False, context, operation, higher)
			sending.append({'select': riders.get('Book_1'), 'name': name, 'photo': image, 'plot': plot_long, 'SkyStream': riders.get('SkyStream'), 'YouStream': riders.get('YouStream')})
		if sending: preserve(WORKS_FILE, sending)
		if extra != 'CASUALCAM' and further is True:
			debug_MS(f"(navigator.list_cameras[5]) PAGES ### NOW GET NEXTPAGE ... No.{int(page)+1} ... ###")
			fetch_blades = create_entries({'Title': translation(30640).format(int(page)+1), 'Image': f"{artpic}nextpage.png"})
			add_views({'mode': 'list_cameras', 'link': target, 'page': int(page)+1, 'persist': int(maximum)+1, 'extra': extra, 'phase': phase}, fetch_blades)
	else:
		debug_MS(f'(navigator.list_cameras) ##### NO CAMERA_LIST - NO ENTRY FOR: "{phase}" FOUND #####')
		return dialog.notification(translation(30527), translation(30528).format(phase), icon, 10000)
	if extra == 'CASUALCAM' and sending:
		random.shuffle(sending)
		camera_conduit = next(filter(lambda cxs: (cxs.get('SkyStream', None) or cxs.get('YouStream', None)), sending), None)
		if camera_conduit: return play_video(camera_conduit['select'])
	xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def _fetch_weather(weather_table, primodo=[]):
	complete = track_several(weather_table, 'GET', 'TEXT', WEB_HEADER)
	if complete:
		for points, books, links, casts in complete:
			if casts not in ['', None]:
				degree, outlook = (None for _ in range(2))
				tempPage = BeautifulSoup(clear_unknown(casts), 'html.parser')
				predict = tempPage.find('div', class_='cam-main')
				grades = predict.find('span', class_='t').text if predict.find('span', class_='t') else None
				troops = predict.find('span', class_='u').text if predict.find('span', class_='u') else None
				if grades and troops: degree = f"{grades} {troops}"
				forecast = predict.find('p', class_='wx-cond')
				if forecast: outlook = ' '.join(forecast.text.split(' ')[:2]) if WEB_LANG in ['de', 'en'] else forecast.text
				debug_MS("* * * * * * * * * * * * * * * * * * * * * * * * *")
				debug_MS(f"(navigator.fetch_weather[2]) XXX COUNT-02 : {points} || LINK-02 : {links} || DEGREE-02 : {degree} || FORECAST-02 : {outlook} XXX")
				primodo.append({'Count_2': int(points), 'Book_2': books, 'Link_1': links, 'Degree': degree, 'Outlook': outlook})
	return primodo

def _fetch_pages(media_table, secondo=[]):
	package = track_several(media_table, 'GET', 'TEXT', WEB_HEADER)
	if package:
		for points, books, links, scraps in package:
			if scraps not in ['', None]:
				story, (rating, voting, thumb_due, youtube, skyline) = "", (None for _ in range(5))
				correct = clear_unknown(scraps) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
				infoPage = BeautifulSoup(correct, 'html.parser')
				record = infoPage.find('div', class_=lambda cv: cv.startswith('cam-layout has')) # Dieser Abschnitt startet mit >cam-layout has< [cam-layout has-ads] oder [cam-layout has-user]
				title_due = record.find('h1').text if record.find('h1') else 'UNKNOWN'
				tagline = record.find('h2').text if record.find('h2') else None
				tagline = f"{tagline[:125]}..." if tagline and len(tagline) > 125 else tagline
				flagpart = books.split('webcam/')[1].split('/')[0]
				territory = record.find('nav', class_='crumbs')
				regiopart = [state.string for state in territory.find_all('a', href=True)]
				if len(regiopart) > 1:
					location = f"{clear_nation(regiopart[1])}, {clear_nation(regiopart[0])}" if regiopart[1] != regiopart[0] else clear_nation(regiopart[0])
					country = clear_nation(regiopart[0])
				else: location, country = clear_nation(flagpart).title(), clear_nation(flagpart).title() if clear_nation(flagpart) != 'USA' else clear_nation(flagpart)
				timing = record.find('time', id='servertime').text if record.find('time', id='servertime') else '--:--'
				descos = record.find('div', class_='desc')
				if descos:
					if descos.find('a', class_='show more'): descos.find('a', class_='show more').decompose() # Löschen eines bestimmten Elements
					story = f"{descos.text[:700]}..." if not descos.text[:700].endswith(('.', '!', '?')) else f"{descos.text[:699]}..." if descos.text[:700].endswith((',', ';')) else descos.text[:700]
				views = record.find('b', id='v_now').text if record.find('b', id='v_now') else None
				analysis = record.find('p', class_='ratemsg').text if record.find('p', class_='ratemsg') else None
				if analysis: rating, voting = analysis.split('/5 · ')[0], analysis.split('/5 · ')[1].split(' ')[0]
				if infoPage.find('meta', property='og:image') and infoPage.find('meta', property='og:image').get('content'):
					thumb_due = infoPage.find('meta', property='og:image').get('content')
					thumb_due = thumb_due.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', thumb_due) else thumb_due
				clogo = f"{flagpic}{flagpart}.png" if xbmcvfs.exists(f"{flagpic}{flagpart}.png") else None
				if re.search(r'https://www.youtube.com/iframe', correct):
					source = re.compile(r''',(?: )?videoId:(?: )?["']([^"']+)["'],''', re.S).findall(correct) # , videoId: "98jOtUeM3m8",
					youtube = source[0] if source and len(source[0]) > 0 else None
				else:
					source = re.compile(r''',(?: )?source:(?: )?["']([^"']+)["'],''', re.S).findall(correct) # ,source: "livee.m3u8?a=6n4tgktbnshf0sns98q1p0bo04",
					skyline = f"https://hd-auth.skylinewebcams.com/{source[0].replace('livee', 'live')}" if source and len(source[0]) > 0 else None
				works = False if youtube is None and skyline is None else True
				embrace = {'Count_3': int(points), 'Book_3': books, 'Title_2': title_due, 'Tagline': tagline, 'Story': story, 'Location': location, 'Country': country, 'Clock': timing,
					'Views': views, 'Rating': rating, 'Voting': voting, 'Thumb_2': thumb_due, 'Clogo': clogo, 'SkyStream': skyline, 'YouStream': youtube, 'Available': works}
				debug_MS("-------------------------------------------------")
				debug_MS(f"(navigator.fetch_pages[3]) ### COUNT-03 : {points} || LINK-03 : {links} || ENTRY-03 : {embrace} ###")
				secondo.append(embrace)
	return secondo

def play_video(ORIGIN): # https://hd-auth.skylinewebcams.com/live.m3u8?a=aaki37oq67e624gn8qee12n5f2
	debug_MS("(navigator.play_video) -------------------------------------------------- START = play_video --------------------------------------------------")
	debug_MS(f"(navigator.play_video) ### SKYLINE_LINK : {ORIGIN} ###")
	stream, unsolved, (youtube, skyline, final_link) = 'UNKNOWN', 'COOKIE >> sw << NOT FOUND', (False for _ in range(3))
	for worx in preserve(WORKS_FILE):
		if worx['select'] != '00' and worx['select'] == ORIGIN:
			full_title, clear_title = re.sub(r'(\[/?B\])', '', worx['name']), re.sub(r'(\[.*?\]|■  )', '', worx['name'])
			small_title, photo, teaser = f"{clear_title[:20].strip()} ...", worx['photo'], worx['plot']
			skyline, youtube = worx['SkyStream'], worx['YouStream']
			debug_MS(f"(navigator.play_video[1]) ### WORKS_FILE-Line : {worx} ###")
	if youtube:
		debug_MS(f"(navigator.play_video[2]) ***** TAKE - REDIRECTED : https://youtu.be/{youtube} || (Youtube-Redirect) *****")
		you_verify = track_content(f"https://youtu.be/{youtube}", 'GET', 'TRACK', WEB_HEADER, 'https://www.youtube.com', 'https://www.youtube.com/', timeout=10)
		stream, final_link = 'YOUTUBE', f"plugin://plugin.video.youtube/play/?video_id={youtube}" if you_verify.status_code in [200, 201, 202] else False
	if not final_link and skyline:
		DATAS = track_content(ORIGIN, queries='TRACK', timeout=10)
		lives_auth = DATAS.cookies.get('sw') if DATAS.status_code in [200, 201, 202, 300, 301, 302] and 'sw' in DATAS.cookies else None
		if lives_auth:
			unsolved = f"https://hd-auth.skylinewebcams.com/live.m3u8?a={lives_auth}|{urlencode({'User-Agent': WEB_AGENT, 'Referer': BASE_URL}, safe='/:?=&')}"
			sky_verify = track_content(unsolved, queries='TRACK', timeout=10)
			stream, final_link = 'SKYLINE', unsolved if sky_verify.status_code in [200, 201, 202, 300, 301, 302] else False
		debug_MS(f"(navigator.play_video[2]) ***** TAKE - DIRECT : {unsolved} || (Skyline-Direct) *****")
	if final_link:
		log(f"(navigator.play_video) {stream}_stream : {final_link}")
		LPM = xbmcgui.ListItem(full_title, path=final_link, offscreen=True)
		teaser = ' ' if teaser in ['', 'None', None] else teaser
		if KODI_BUILD >= 20:
			LPM.getVideoInfoTag().setTitle(full_title), LPM.getVideoInfoTag().setPlot(teaser), LPM.getVideoInfoTag().setStudios(['Skylinewebcams'])
		else: LPM.setInfo('Video', {'Title': full_title, 'Plot': teaser, 'Studio': 'Skylinewebcams'})
		LPM.setArt({'icon': icon, 'thumb': photo, 'poster': photo})
		if prefer_player == 1 and xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)') and skyline and stream == 'SKYLINE':
			IA_NAME = 'inputstream.ffmpegdirect'
			LPM.setMimeType('application/vnd.apple.mpegurl'); LPM.setProperty('inputstream', IA_NAME)
			LPM.setProperty(f'{IA_NAME}.stream_mode', 'default')
			LPM.setProperty(f'{IA_NAME}.manifest_type', 'hls')
			LPM.setProperty(f'{IA_NAME}.is_realtime_stream', 'true')
			if open_modus != 0:
				LPM.setProperty(f'{IA_NAME}.open_mode', 'ffmpeg' if open_modus == 1 else 'curl')
		xbmc.Player().play(item=final_link, listitem=LPM)
		xbmc.sleep(10000)
		if not xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)') and not xbmc.Player().isPlaying():
			return dialog.notification(translation(30529).format(small_title), translation(30530), icon, 15000)
	else:
		if youtube:
			failing(f"(navigator.play_video) $$$$$ Playback of the stream is NOT possible; the Stream-URL on the *skylinewebcams.com* website is BROKEN or OFFLINE !!! $$$$$\n $$$$$ TITLE : {clear_title} || YOUTUBE-ID : {youtube} $$$$$")
		elif skyline:
			failing(f"(navigator.play_video) $$$$$ Playback of the stream is NOT possible; the Stream-URL on the *skylinewebcams.com* website is BROKEN or OFFLINE !!! $$$$$\n $$$$$ TITLE : {clear_title} || VIDEO : {skyline} $$$$$")
		return dialog.notification(translation(30529).format(small_title), translation(30531), icon, 15000)

def list_favorites(watches=[]):
	debug_MS("(navigator.list_favorites) -------------------------------------------------- START = list_favorites --------------------------------------------------")
	if preserve(FAVORIT_FILE): # List all LIVE cameras in favourites - go directly to the 'list_cameras' folder
		for snipps in sorted(preserve(FAVORIT_FILE), key=lambda vsx: clear_umlaut(vsx.get('Clearname', 'zorro')).lower()):
			debug_MS(f"(navigator.list_favorites[1]) ##### NAME : {snipps.get('Clearname')} || LINK : {snipps.get('Streaming')} || THUMB : {snipps.get('Image')} #####")
			watches.append({'Link': snipps.get('Streaming'), 'Title': snipps.get('Clearname'), 'Thumb': snipps.get('Image'), 'Region': snipps.get('Country'), 'Statement': snipps.get('plot_short')})
		if watches: return list_cameras(watches, 1, 0, 'FAVORITES', 'Favourites')
	return dialog.notification(translation(30532), translation(30533), icon, 10000)

def favorit_construct(**kwargs):
	topper = preserve(FAVORIT_FILE) if preserve(FAVORIT_FILE) else []
	if kwargs['action'] == 'ADD':
		kwargs.pop('mode', None); kwargs.pop('action', None); kwargs.pop('plot_long', None); kwargs.pop('Studio', None)
		topper.append({key: value for key, value in kwargs.items() if value not in ['', 'None', None]})
		preserve(FAVORIT_FILE, topper)
		xbmc.sleep(500)
		dialog.notification(translation(30534), translation(30535).format(kwargs['Clearname']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		topper = [xs for xs in topper if xs.get('Streaming') != kwargs.get('Streaming')]
		preserve(FAVORIT_FILE, topper)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30534), translation(30536).format(kwargs['Clearname']), icon, 10000)

def add_views(params, listitem, folder=True, context={}, handling='default', higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enable_decrease and button_place == 1 and higher is True:
		entries.append([translation(30650), f"RunPlugin({build_mass({'mode': 'calling_main'})})"])
	if handling == 'adding' and context:
		entries.append([translation(30651), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
