﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2024 realvito

    Skyline LiveCams

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib.common import *
from resources.lib import navigator


def run():
	if mode == 'root':
		navigator.mainMenu()
	elif mode == 'listPages':
		navigator.listPages(url, extras)
	elif mode == 'listCameras':
		navigator.listCameras(url, page, position, extras, selection)
	elif mode == 'playCODE':
		navigator.playCODE(IDENTiTY)
	elif mode == 'listFavorites':
		navigator.listFavorites()
	elif mode == 'favs':
		navigator.favs(action, name, picture, IDENTiTY, region, plot)
	elif mode == 'callingMain':
		navigator.mainMenu()
		xbmc.executebuiltin(f"Container.Update({HOST_AND_PATH}, replace)")
		return sys.exit(0)
	elif mode == 'blankFUNC':
		pass # do nothing
	elif mode == 'clear_storage':
		navigator.clear_storage()
	elif mode == 'aConfigs':
		addon.openSettings()
		xbmc.executebuiltin('Container.Refresh')

run()
