﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	addDir(translation(30601), f"{artpic}favourites.png", {'mode': 'listFavorites'})
	addDir(translation(30602), icon, {'mode': 'listCameras', 'url': LANG_URL, 'extras': 'CASUALCAM'})
	addDir(translation(30603), icon, {'mode': 'listCameras', 'url': NEW_URL, 'extras': 'NEWEST'})
	addDir(translation(30604), icon, {'mode': 'listCameras', 'url': TOP_URL, 'extras': 'POPULAR'})
	addDir(translation(30605), icon, {'mode': 'listPages', 'url': LANG_URL, 'extras': 'COUNTRIES'})
	addDir(translation(30606), icon, {'mode': 'listPages', 'url': LANG_URL, 'extras': 'CATEGORIES'})
	addDir(translation(30607).format(str(cachePERIOD)), f"{artpic}remove.png", {'mode': 'clear_storage'}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30610), f"{artpic}settings.png", {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPages(url, EXTRA): 
	debug_MS("(navigator.listPages) ------------------------------------------------ START = listPages -----------------------------------------------")
	debug_MS(f"(navigator.listPages) ### URL = {url} ### EXTRA = {EXTRA} ###")
	COMBI_PAGES = []
	req = getUrl(url, 'LOAD', LANG_URL)
	converted = clear_unknown(req) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
	htmlPage = BeautifulSoup(converted, 'html.parser')
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listPages[1]) $$$$$ PRETTIFIED-SOUP : {htmlPage.prettify()} $$$$$")
	debug_MS("++++++++++++++++++++++++")
	if EXTRA == 'COUNTRIES':
		cats = htmlPage.find('div', class_='dropdown mega-dropdown live')
	else:
		cats = htmlPage.find('div', class_='dropdown-menu mega-dropdown-menu cat')
	ARTICLES = cats.find_all('a', href=True)
	for item in ARTICLES:
		adress = item['href']
		if not adress.endswith('.html'):
			continue
		title = item.get_text() # In countries the Title is hidden in Link-Text, extract it with: 'get_text()'
		SORTING_TITLE = title.replace('Ä', 'Ae').replace('Ü', 'Ue').replace('Ö', 'Oe')
		name = translation(30621).format(title)
		if EXTRA == 'COUNTRIES' and not 'live' in title.lower():
			category = translation(30622).format(title)
			photo = f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png" if xbmcvfs.exists(f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png") else icon
		else:
			category = translation(30623).format(title)
			photo = icon
		desc = item.find('p', class_='subt')
		plot = desc.text+' ...' if desc and not desc.text.endswith(('.', '!', '?')) else desc.text[:-1]+' ...' if desc and desc.endswith((',', ';')) else desc.text if desc else None
		plot = re.sub(r'\<.*?\>', '', plot.replace('.[/B]', '.')) if desc else None
		link = f"{BASE_URL}{adress}" if adress.startswith('/') else f"{BASE_URL}/{adress}" if not adress.startswith(('http', '/')) else adress
		if item.find('img') and item.find('img').get('src'):
			photo = f"https:{item.img['src']}" if item.img['src'].startswith('//') else item.img['src']
		if re.search(r'/live[0-9]+', photo):
			photo = photo.replace('/live', '/social').replace('.webp', '.jpg')
		COMBI_PAGES.append([name, SORTING_TITLE, category, photo, link, plot])
	for name, SORTING_TITLE, category, photo, link, plot in sorted(COMBI_PAGES, key=lambda d: d[1], reverse=False):
		addDir(name, photo, {'mode': 'listCameras', 'url': link, 'extras': EXTRA, 'selection': category}, plot)
		debug_MS(f"(navigator.listPages[2]) ##### NAME : {name} || THUMB : {photo} || LINK : {link} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listCameras(url, PAGE, POS, EXTRA, CAT):
	debug_MS("(navigator.listCameras) ------------------------------------------------ START = listCameras -----------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL : {url} ### PAGE = {PAGE} ### LIMIT = {str(LIMITATION)} ### POSITION = {POS} ### EXTRA = {EXTRA} ### CATEGORY = {CAT} ###")
	counter, HASMORE, (COMPLETE, SEND) = 0, False, ({} for _ in range(2))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_THIRD, COMBI_WIDGET, COMBI_FOURTH, RESULT_ONE, RESULT_TWO, COMPLETE['entries'], SEND['videos'] = ([] for _ in range(10))
	DEFAULT = 0 if int(PAGE) == 1 else int(PAGE) - 1
	MINIMUM = int(DEFAULT)*int(LIMITATION) + 1
	MAXIMUM = int(PAGE)*int(LIMITATION) if EXTRA != 'CASUALCAM' else 50
	if enableBACK and PLACEMENT == '0' and EXTRA not in ['CASUALCAM', 'FAVORITES'] and int(PAGE) > 1:
		addDir(translation(30624), f"{artpic}backmain.png", {'mode': 'callingMain'})
	if isinstance(url, (dict, list)):
		for item in url:
			LINK_1, TITLE_1, PHOTO_1, DESC_1 = item['IDENTiTY'], item['name'], item['picture'], item['plot']
			WEATHER_1 = LINK_1.replace('webcam/', 'weather/')
			counter += 1
			COMBI_FIRST.append([int(counter), LINK_1, TITLE_1, PHOTO_1, DESC_1])
			COMBI_WIDGET.append([int(counter), LINK_1, f"{WEATHER_1[:WEATHER_1.rfind('/')]}.html"])
			COMBI_LINKS.append([int(counter), LINK_1, LINK_1])
	else:
		if not xbmcvfs.exists(tempDATA) and not os.path.exists(tempDATA):
			xbmcvfs.mkdirs(tempDATA)
		SWEEP = urlparse(url)
		PAGES_DATA = f"{SWEEP.path.replace('/', '-').replace('.html', '')}.json"
		PAGES_PATH = os.path.join(tempDATA, PAGES_DATA)
		if xbmcvfs.exists(PAGES_PATH):
			for root, dirs, files in os.walk(tempDATA):
				for names in files:
					filename = os.path.join(root, names).encode('utf-8').decode('utf-8')
					try:
						if os.path.exists(filename):
							if os.path.getmtime(filename) < time.time() - (60*60*cachePERIOD): # Check if CACHED-File exists and remove CACHED-File after 'cachePERIOD' Hours
								os.unlink(filename)
					except: pass
			xbmc.sleep(500)
		if not xbmcvfs.exists(PAGES_PATH) or EXTRA == 'CASUALCAM':
			DATA_ONE = getUrl(url, 'LOAD', LANG_URL)
			converted = clear_unknown(DATA_ONE) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
			htmlPage = BeautifulSoup(converted, 'html.parser')
			debug_MS("++++++++++++++++++++++++")
			debug_MS(f"(navigator.listCameras[1]) $$$$$ PRETTIFIED-SOUP : {htmlPage.prettify()} $$$$$")
			debug_MS("++++++++++++++++++++++++")
			cams = htmlPage.find('div', class_='content')
			MOVIES = cams.find_all('a', href=True)
			for video in MOVIES:
				adress = video['href']
				if not adress.endswith('.html'):
					continue
				HEADLINE = video.img['alt'] if video.find('img') and video.find('img').get('alt') else None
				if HEADLINE is None: continue
				STORY = video.find('p', class_='subt')
				DESCRIPT = STORY.text+' ...' if STORY and not STORY.text.endswith(('.', '!', '?')) else STORY.text[:-1]+' ...' if STORY and STORY.text.endswith((',', ';')) else STORY.text if STORY else ""
				DESCRIPT = re.sub(r'\<.*?\>', '', DESCRIPT.replace('.[/B]', '.')) if STORY else ""
				WEBLINK = f"{BASE_URL}{adress}" if adress.startswith('/') else f"{BASE_URL}/{adress}" if not adress.startswith(('http', '/')) else adress
				if video.find('img') and video.find('img').get('src'):
					PICTURE = f"https:{video.img['src']}" if video.img['src'].startswith('//') else video.img['src']
				else: PICTURE = icon
				if re.search(r'/live[0-9]+', PICTURE):
					PICTURE = PICTURE.replace('/live', '/social').replace('.webp', '.jpg')
				counter += 1
				COMPLETE['entries'].append({'number': counter, 'IDENTiTY': WEBLINK, 'name': HEADLINE, 'photo': PICTURE, 'plot': DESCRIPT})
			with open(PAGES_PATH, 'w') as backup:
				json.dump(COMPLETE, backup, indent=4, sort_keys=True)
			xbmc.sleep(500)
		if xbmcvfs.exists(PAGES_PATH):
			with open(PAGES_PATH, 'r') as pdd:
				REACHED = json.load(pdd)
				for item in REACHED['entries']:
					if item['number'] != 0 and MINIMUM <= item['number'] <= MAXIMUM:
						NUMBER_1, LINK_1, TITLE_1, PHOTO_1, DESC_1 = item['number'], item['IDENTiTY'], item['name'], item['photo'], item['plot']
						WEATHER_1 = LINK_1.replace('webcam/', 'weather/')
						COMBI_FIRST.append([int(NUMBER_1), LINK_1, TITLE_1, PHOTO_1, DESC_1])
						COMBI_WIDGET.append([int(NUMBER_1), LINK_1, f"{WEATHER_1[:WEATHER_1.rfind('/')]}.html"])
						COMBI_LINKS.append([int(NUMBER_1), LINK_1, LINK_1])
					if EXTRA != 'CASUALCAM' and item['number'] != 0 and item['number'] > MAXIMUM:
						HASMORE = True
	if COMBI_FIRST:
		if showWEATHER is True:
			COMBI_SECOND = listWeather(COMBI_WIDGET)
			RESULT_ONE = [a + b for a in COMBI_FIRST for b in COMBI_SECOND if a[1] == b[1]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
			RESULT_ONE += [c for c in COMBI_FIRST if all(d[1] != c[1] for d in COMBI_SECOND)] # Der übriggebliebene Rest von Liste1 - wenn die ID nicht in der Liste2 vorkommt !!!
		else:
			RESULT_ONE = COMBI_FIRST
	if COMBI_LINKS:
		COMBI_THIRD = getMultiData(COMBI_LINKS)
		if COMBI_THIRD:
			#log("++++++++++++++++++++++++")
			#log(f"(navigator.listCameras[2]) XXXXX COMBI_THIRD-02 : {str(COMBI_THIRD)} XXXXX")
			#log("++++++++++++++++++++++++")
			for meter, WLINK_3, CONT_3, elem in COMBI_THIRD:
				if elem is not None:
					PHOTO_3, (TAGLINE_3, VIEWS_3, RATED_3, NUMBERS_3, LOGO_3, YOUTUBE_3, STREAM_3) = icon, (None for _ in range(7))
					corrected = clear_unknown(elem) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
					contentPage = BeautifulSoup(corrected, 'html.parser')
					record = contentPage.find('div', class_='content')
					NAME = record.find('h1')
					TITLE_3 = NAME.text if NAME is not None else 'UNKNOWN'
					TEASER = record.find('h2')
					TAGLINE_3 = TEASER.text if TEASER is not None else None
					if TAGLINE_3 and len(TAGLINE_3) > 125:
						TAGLINE_3 = f"{TAGLINE_3[:125]}..."
					FLAGPART = WLINK_3.split('webcam/')[1].split('/')[0]
					REGIONS = [span.string for span in record.find_all('span', itemprop='name')]
					if len(REGIONS) > 1:
						LOCATION_3 = f"{REGIONS[1]}, {REGIONS[0]}" if REGIONS[1] != REGIONS[0] else REGIONS[0]
						COUNTRY_3 = REGIONS[0]
					else:
						LOCATION_3, COUNTRY_3 = FLAGPART, FLAGPART
					SERVALUE = record.find('span', id='servertime')
					TIME_3 = SERVALUE.string if SERVALUE is not None else 'UNKNOWN'
					STORY = record.find('div', class_='descr')
					DESC_3 = STORY.text+' ...' if STORY and not STORY.text.endswith(('.', '!', '?')) else STORY.text[:-1]+' ...' if STORY and STORY.text.endswith((',', ';')) else STORY.text if STORY else ""
					DESC_3 = re.sub(r'\<.*?\>', '', DESC_3.replace('.[/B]', '.')[:DESC_3.rfind('[CR][CR]')]) if STORY else ""
					VIECOUNT = record.find('span', id='v_now')
					VIEWS_3 = VIECOUNT.text if VIECOUNT is not None else None
					RATVALUE = record.find('span', itemprop='ratingValue')
					RATED_3 = RATVALUE.text if RATVALUE is not None else None
					RATCOUNT = record.find('span', itemprop='ratingCount')
					NUMBERS_3 = RATCOUNT.text if RATCOUNT is not None else None
					if contentPage.find('meta', property='og:image') and contentPage.find('meta', property='og:image').get('content'):
						PHOTO_3 = contentPage.find('meta', property='og:image').get('content')
					if re.search(r'/live[0-9]+', PHOTO_3):
						PHOTO_3 = PHOTO_3.replace('/live', '/social').replace('.webp', '.jpg')
					LOGO_3 = f"{flagpic}{FLAGPART}.png" if xbmcvfs.exists(f"{flagpic}{FLAGPART}.png") else None
					if re.search(r'https://www.youtube.com/iframe', corrected):
						SOURCE = re.compile(r''',videoId:["']([^"']+)["'],''', re.S).findall(corrected) # ,videoId:'SJ7dRgcEvBs',
						YOUTUBE_3 = SOURCE[0] if SOURCE and len(SOURCE[0]) > 0 else None
					else:
						SOURCE = re.compile(r''',source:["']([^"']+)["'],''', re.S).findall(corrected) #  ,source:'livee.m3u8?a=1kthl1f6neoehp6fq44bq2o4e0',
						STREAM_3 = f"https://hd-auth.skylinewebcams.com/{SOURCE[0].replace('livee', 'live')}" if SOURCE and len(SOURCE[0]) > 0 else None
					WORKS_3 = False if YOUTUBE_3 is None and STREAM_3 is None else True
					COMBI_FOURTH.append([int(meter), WLINK_3, WORKS_3, TITLE_3, TAGLINE_3, LOCATION_3, COUNTRY_3, TIME_3, VIEWS_3, RATED_3, NUMBERS_3, PHOTO_3, LOGO_3, DESC_3, STREAM_3, YOUTUBE_3])
	if COMBI_FOURTH and RESULT_ONE:
		RESULT_TWO = [e + f for e in RESULT_ONE for f in COMBI_FOURTH if e[1] == f[1]] # Zusammenführung von Liste1 und Liste2 - wenn der LINK überein stimmt !!!
		for da in sorted(RESULT_TWO, key=lambda k: int(k[0]), reverse=False): # Liste1 = 0-11 oder 0-7 || Liste2 = 12-15 oder leer || Liste3 = 16-29 oder 12-25
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listCameras[3]) ### Anzahl = {str(len(da))} || Eintrag : {str(da)} ###")
			'''
			STANDARD und FAVORITEN:
				Liste-1 = Number1, Link1, Title1, Photo1, Desc1 = da[0], da[1], da[2], da[3], da[4]
				Liste-2 = Number2, Link2, temperature, condition = da[5], da[6], da[7], da[8]
				Liste-3 = Number3, Link3, works, Title3, tagline, LocationComplete, CountryTitle, CountryTime, viewers, rated, ratingcount, Photo3, Logo3, Desc3, directstream, youtubestream = da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19], da[20], da[21], da[22], da[23], da[24]
			'''
			if len(da) >= 25: ### Liste1+Liste2+Liste3 ist grösser als oder ist gleich Nummer:25 ###
				Number1, Link1, Title1, Photo1, Desc1 = da[0], da[1], da[2], da[3], da[4]
				Number2, Link2, temperature, condition = da[5], da[6], da[7], da[8]
				Number3, Link3, works, Title3, tagline, LocationComplete, CountryTitle, CountryTime, viewers, rated, ratingcount, Photo3, Logo3, Desc3, directstream, youtubestream = da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19], da[20], da[21], da[22], da[23], da[24]
			elif len(da) <= 21: ### Liste1+Liste3 ist kleiner als oder ist gleich Nummer:21 und Liste2 ist AUS ###
				Number1, Link1, Title1, Photo1, Desc1 = da[0], da[1], da[2], da[3], da[4]
				Number2, Link2, temperature, condition = (None for _ in range(4))
				Number3, Link3, works, Title3, tagline, LocationComplete, CountryTitle, CountryTime, viewers, rated, ratingcount, Photo3, Logo3, Desc3, directstream, youtubestream = da[5], da[6], da[7], da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19], da[20]
			else: continue
			country = CountryTitle.replace('-', ' ').title()
			if CountryTitle and WEB_LANG in ['de', 'en']:
				for tt in (('Albania', translation(32101)), ('Argentina', translation(32102)), ('Australia', translation(32103)), ('Austria', translation(32104)), ('Belarus', translation(32105)),
					('Belgique', translation(32106)), ('Bosnia And Herzegovina', translation(32107)), ('Brasil', translation(32108)), ('Cabo Verde', translation(32109)), ('Canada', translation(32110)),
					('Caribbean Netherlands', translation(32111)), ('Cyprus', translation(32112)), ('Czech Republic', translation(32113)), ('Dominican Republic', translation(32114)), ('Egypt', translation(32115)),
					('Ellada', translation(32116)), ('Espana', translation(32117)), ('Faroe Islands', translation(32118)), ('France', translation(32119)), ('Hrvatska', translation(32120)),
					('Hungary', translation(32121)), ('Iceland', translation(32122)), ('Ireland', translation(32123)), ('Italia', translation(32124)), ('Kenya', translation(32125)),
					('Maledives', translation(32126)), ('Mexico', translation(32127)), ('Morocco', translation(32128)), ('Netherlands', translation(32129)), ('Norge', translation(32130)),
					('Philippines', translation(32131)), ('Poland', translation(32132)), ('Repubblica Di San Marino', translation(32133)), ('Romania', translation(32134)), ('Seychelles', translation(32135)),
					('Slovenija', translation(32136)), ('South Africa', translation(32137)), ('Turkey', translation(32138)), ('United Arab Emirates', translation(32139)), ('United Kingdom', translation(32140)),
					('United States', translation(32141)), ('Us Virgin Islands', translation(32142)), ('Zambia', translation(32143)), ('Zanzibar', translation(32144))):
					country = country.replace(*tt)
			if works is True and (directstream or youtubestream):
				name = translation(30625).format(Title3)
				prefix = translation(30626).format(LocationComplete, CountryTime, str(viewers)) if viewers else translation(30627).format(LocationComplete, CountryTime)
				uvz = build_mass({'mode': 'playCODE', 'IDENTiTY': Link1})
			elif works is False or (directstream is None and youtubestream is None):
				name = translation(30628).format(Title3)
				prefix = translation(30629).format(LocationComplete, CountryTime, str(viewers)) if viewers else translation(30630).format(LocationComplete, CountryTime)
				uvz = build_mass({'mode': 'blankFUNC', 'IDENTiTY': Link1})
			else: continue
			image = Photo1 if Photo1 != icon else Photo3
			logo = Logo3 if Logo3 else None
			FULL_DESC = Desc3 if len(Desc3) > len(Desc1) else Desc1
			FULL_TAGLINE = tagline if tagline and not tagline in FULL_DESC else None
			weather = translation(30631).format(str(temperature), condition) if temperature and condition else '[CR]'
			plot = prefix+weather+FULL_DESC
			debug_MS(f"(navigator.listCameras[3]) ##### POS : {str(da[0])} || NAME : {name} || LINK : {Link1} || COUNTRY : {country} #####")
			debug_MS(f"(navigator.listCameras[3]) ##### THUMB : {image} || VIDEO : {str(directstream)} || YOUTUBE : {str(youtubestream)} #####")
			if EXTRA != 'FAVORITES':
				addType, FAVclear = 1, False
				if xbmcvfs.exists(cameraFavsFile) and os.stat(cameraFavsFile).st_size > 0:
					with open(cameraFavsFile, 'r') as fp:
						present = json.load(fp)
						for entry in present .get('items', []):
							if entry.get('IDENTiTY') == Link1: addType = 2
			elif EXTRA == 'FAVORITES': 
				addType, FAVclear = 0, True
			LEM = xbmcgui.ListItem(name)
			if plot in ['', 'None', None]: plot = "..."
			if KODI_ov20:
				vinfo = LEM.getVideoInfoTag()
				vinfo.setTitle(name)
				vinfo.setTagLine(FULL_TAGLINE)
				vinfo.setPlot(plot)
				if country: vinfo.setCountries([country])
				if rated and str(rated.replace('.', '')).isdigit() and ratingcount and str(ratingcount).isdigit():
					vinfo.setRating(float(rated), int(ratingcount), 'userrating', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
				vinfo.setStudios(['Skylinewebcams'])
				vinfo.setMediaType('movie')
			else:
				vinfo = {}
				vinfo['Title'] = name
				vinfo['Tagline'] = FULL_TAGLINE
				vinfo['Plot'] = plot
				if country: vinfo['Country'] = country
				if rated and str(rated.replace('.', '')).isdigit() and ratingcount and str(ratingcount).isdigit():
					LEM.setRating('userrating', float(rated), int(ratingcount), True) # LEM.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
				vinfo['Studio'] = 'Skylinewebcams'
				vinfo['Mediatype'] = 'movie'
				LEM.setInfo(type='Video', infoLabels=vinfo)
			LEM.setArt({'icon': icon, 'thumb': image, 'poster': image, 'clearlogo': logo})
			if useThumbAsFanart:
				LEM.setArt({'fanart': defaultFanart})
			entries = []
			CLEAR_NAME = re.sub(r'(\[.*?\]|■  )', '', name)
			if enableBACK and PLACEMENT == '1' and EXTRA not in ['CASUALCAM', 'FAVORITES'] and int(PAGE) > 1:
				entries.append([translation(30650), 'RunPlugin({})'.format(build_mass({'mode': 'callingMain'}))])
			if works is True and (directstream or youtubestream):
				if addType == 1 and FAVclear is False:
					entries.append([translation(30651), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'ADD', 'name': CLEAR_NAME, 'picture': image, 'IDENTiTY': Link1, 'region': country, 'plot': Desc1}))])
				entries.append([translation(30654), 'Action(Queue)'])
			if addType == 0 and FAVclear is True:
				entries.append([translation(30652), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'DEL', 'name': CLEAR_NAME, 'picture': image, 'IDENTiTY': Link1, 'region': country, 'plot': Desc1}))])
			LEM.addContextMenuItems(entries)
			SEND['videos'].append({'filter': Link1, 'name': name, 'photo': image, 'plot': plot, 'directLINK': directstream, 'youtubeID': youtubestream})
			if EXTRA != 'CASUALCAM':
				xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LEM)
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
		if EXTRA != 'CASUALCAM' and HASMORE is True:
			debug_MS(f"(navigator.listCameras[4]) NEXTPAGES ### Now show NextPage ... No.{str(int(PAGE)+1)} ... ###")
			addDir(translation(30640).format(int(PAGE)+1), f"{artpic}nextpage.png", {'mode': 'listCameras', 'url': url, 'page': int(PAGE)+1, 'position': int(MAXIMUM)+1, 'extras': EXTRA, 'selection': CAT})
		if EXTRA == 'CASUALCAM' and SEND['videos']:
			for vs in SEND['videos']:
				if vs['directLINK'] is not None or vs['youtubeID'] is not None:
					playCODE(vs['filter'])
					break
	else:
		debug_MS(f"(navigator.listCameras) ##### Keine COMBI_CAMERAS-List - Kein Eintrag *** {str(EXTRA)} *** gefunden #####")
		return dialog.notification(translation(30525).format('Einträge'), translation(30526).format(EXTRA), icon, 10000)
	if EXTRA != 'CASUALCAM' and (COMBI_FOURTH and RESULT_ONE):
		debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
		xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listWeather(MURLS):
	COMBI_DETAILS, COMBI_WEATHER = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listWeather[2]) XXXXX COMBI_DETAILS-02 : {str(COMBI_DETAILS)} XXXXX")
		#log("++++++++++++++++++++++++")
		for number, WLINK_2, WEATHER_2, each in COMBI_DETAILS:
			if each is not None:
				TEMP_2, COND_2 = (None for _ in range(2))
				cleared = clear_unknown(each) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
				weatherPage = BeautifulSoup(cleared, 'html.parser')
				predict = weatherPage.find('div', class_='cast today')
				DEGREES = predict.find('span', class_='degrees')
				TEMP_2 = DEGREES.text if DEGREES else None
				FORETEXT = predict.find('p', class_='foretext')
				COND_2 = ' '.join(FORETEXT.text.split(' ')[:2]) if FORETEXT and WEB_LANG in ['de', 'en'] else FORETEXT.text if FORETEXT and WEB_LANG not in ['de', 'en'] else None
				debug_MS(f"(navigator.listWeather[2]) ##### POS : {str(number)} || TEMPERATURE : {str(TEMP_2)} || CONDITION : {str(COND_2)} #####")
				COMBI_WEATHER.append([int(number), WLINK_2, TEMP_2, COND_2])
	return COMBI_WEATHER

def playCODE(IDD):# https://hd-auth.skylinewebcams.com/live.m3u8?a=aaki37oq67e624gn8qee12n5f2
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### SKYLINE_LINK : {IDD} ###")
	ADRESS, YOUTUBE, SKYLINE, FINAL_URL = (False for _ in range(4))
	if xbmc.Player().isPlaying():
		xbmc.Player().stop()
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == IDD:
				FULL_TITLE = re.sub(r'(\[B\]|\[/B\])', '', elem['name'])
				CLEAR_TITLE = re.sub(r'(\[.*?\]|■  )', '', elem['name'])
				SMALL_TITLE = ' '.join(CLEAR_TITLE.split(' ')[:4])+' ...'
				PHOTO = elem['photo']
				PLOT = elem['plot']
				SKYLINE = elem['directLINK'].replace('&amp;', '&') if elem.get('directLINK', '') else None
				YOUTUBE = elem['youtubeID']
				debug_MS(f"(navigator.playCODE[1]) ### WORKFILE-Line : {str(elem)} ###")
	if YOUTUBE:
		debug_MS(f"(navigator.playCODE[2]) ***** TAKE - REDIRECTED : plugin://plugin.video.youtube/play/?video_id={YOUTUBE} || (Youtube-Redirect) *****")
		TEST_URL = getUrl(f"https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={YOUTUBE}", method='TRACK', timeout=20)
		if TEST_URL.status_code in [200, 201, 202] and re.search(r'''["']provider_url["']:["']https://www.youtube.com/["']''', TEST_URL.text):
			FINAL_URL = f"plugin://plugin.video.youtube/play/?video_id={YOUTUBE}"
			STREAM = 'YOUTUBE'
	if not FINAL_URL and SKYLINE:
		SKYLINE += f"|User-Agent={quote(getRandom())}&Referer={quote(BASE_URL+'/')}"
		debug_MS(f"(navigator.playCODE[2]) ***** TAKE - DIRECT : {SKYLINE} || (Skyline-Direct) *****")
		STREAM = 'MP4' if '.mp4' in SKYLINE else 'TS' if '.ts' in SKYLINE else 'HLS' if 'hls' in SKYLINE else 'M3U8'
		TEST_URL = getUrl(SKYLINE, method='TRACK', timeout=20)
		if TEST_URL.status_code in [200, 201, 202]:
			FINAL_URL = SKYLINE
	if FINAL_URL:
		log(f"(navigator.playCODE) {STREAM}_stream : {FINAL_URL}")
		LSM = xbmcgui.ListItem(FULL_TITLE, path=FINAL_URL)
		if PLOT in ['', 'None', None]: PLOT = "..."
		if KODI_ov20:
			vinfo = LSM.getVideoInfoTag()
			vinfo.setTitle(FULL_TITLE), vinfo.setPlot(PLOT), vinfo.setStudios(['Skylinewebcams'])
		else:
			LSM.setInfo(type='Video', infoLabels={'Title': FULL_TITLE, 'Plot': PLOT, 'Studio': 'Skylinewebcams'})
		LSM.setArt({'icon': icon, 'thumb': PHOTO, 'poster': PHOTO})
		xbmc.Player().play(item=FINAL_URL, listitem=LSM)
		xbmc.sleep(5000)
		if not xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)') and not xbmc.Player().isPlaying():
			return dialog.notification(translation(30527).format(str(SMALL_TITLE)), translation(30528), icon, 15000)
	else:
		if YOUTUBE:
			failing(f"(navigator.playCODE) $$$$$ Abspielen des Streams NICHT möglich, die Stream-Url auf der Webseite von *webcamera24.com* ist DEFEKT oder OFFLINE !!! $$$$$\n $$$$$ TITLE : {str(CLEAR_TITLE)} || YOUTUBE-ID : {str(YOUTUBE)} $$$$$")
		elif SKYLINE:
			failing(f"(navigator.playCODE) $$$$$ Abspielen des Streams NICHT möglich, die Stream-Url auf der Webseite von *webcamera24.com* ist DEFEKT oder OFFLINE !!! $$$$$\n $$$$$ TITLE : {str(CLEAR_TITLE)} || VIDEO : {str(SKYLINE)} $$$$$")
		return dialog.notification(translation(30527).format(str(SMALL_TITLE)), translation(30529), icon, 15000)

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	WATCH = {}
	WATCH['items'] = []
	if xbmcvfs.exists(cameraFavsFile) and os.stat(cameraFavsFile).st_size > 0:
		with open(cameraFavsFile, 'r') as misc: # Liste alle LIVE-Kameras in Favoriten - gehe direkt zum 'listCameras' Ordner
			snippets = json.load(misc)
			for article in snippets.get('items', []):
				debug_MS(f"(navigator.listFavorites[1]) ##### NAME : {article.get('name')} || LINK : {article.get('IDENTiTY')} || IMAGE : {article.get('picture')} #####")
				WATCH['items'].append({'name': article.get('name'), 'picture': article.get('picture'), 'IDENTiTY': article.get('IDENTiTY'), 'region': article.get('region'), 'plot': article.get('plot')})
				WATCH['items'] = sorted(WATCH['items'], key=lambda k: k['name'], reverse=False)
		if WATCH['items']:
			return listCameras(WATCH['items'], page, position, 'FAVORITES', 'Favourites')
	return dialog.notification(translation(30530), translation(30531), icon, 8000)

def favs(*args):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(cameraFavsFile) and os.stat(cameraFavsFile).st_size > 0:
		with open(cameraFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'name': name, 'picture': picture, 'IDENTiTY': IDENTiTY, 'region': region, 'plot': plot})
		with open(cameraFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30532), translation(30533).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('IDENTiTY') != IDENTiTY]
		with open(cameraFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30532), translation(30534).format(name), icon, 8000)

def addDir(name, image, params={}, plot=None, folder=True):
	u = build_mass(params)
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setStudios(['Skylinewebcams'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'Skylinewebcams'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image})
	if useThumbAsFanart:
		liz.setArt({'fanart': defaultFanart})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
