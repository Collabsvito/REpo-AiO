﻿# -*- coding: utf-8 -*-

import re
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import random
import time
from datetime import datetime, timedelta
import requests
from urllib.parse import parse_qsl, urlparse, urlencode, quote, quote_plus, unquote_plus
from urllib.request import urlopen
from bs4 import BeautifulSoup, UnicodeDammit
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


socket.setdefaulttimeout(30)
HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_desc						= addon.getAddonInfo('description')
addonPath							= xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath								= xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
tempDATA							= xbmcvfs.translatePath(os.path.join(dataPath, 'tempDATA', '')).encode('utf-8').decode('utf-8')
WORKFILE							= xbmcvfs.translatePath(os.path.join(dataPath, 'episode_data.json'))
cameraFavsFile					= xbmcvfs.translatePath(os.path.join(dataPath, 'favorites_SKYLINE.json'))
defaultFanart						= os.path.join(addonPath, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addonPath, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
flagpic								= os.path.join(addonPath, 'resources', 'media', 'country', '').encode('utf-8').decode('utf-8')
WEB_LANG						= {0: 'de', 1: 'en', 2: 'fr', 3: 'es', 4: 'it', 5: 'el', 6: 'pl', 7: 'ru', 8: 'hr', 9: 'sl'}[int(addon.getSetting('language'))]
# Available Languages(settings) ~ German=0|English=1|French=2|Spanish=3|Italian=4|Greek=5|Polish=6|Russian=7|Croatian=8|Slovenian=9
# Language Codes(SkylineWebCams) ~ 0: de|1: en|2: fr|3: es|4: it|5: el|6: pl|7: ru|8: hr|9: sl
cachePERIOD						= int(addon.getSetting('cache_rhythm'))
LIMITATION						= int(addon.getSetting('max_entries'))
showWEATHER					= (True if addon.getSetting('show_weather') == 'true' else False)
useThumbAsFanart			= addon.getSetting('use_fanart') == 'true'
LAST_STORED					= (int(addon.getSetting('last_agent_stored')) or 0)
ACTUAL_AGENT					= addon.getSetting('actual_user_agent')
enableBACK						= addon.getSetting('show_homebutton') == 'true'
PLACEMENT						= addon.getSetting('button_place')
enableADJUSTMENT			= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_ov20						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
KODI_un21						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) <= 20
# IMG_flags						= 'https://img.freeflagicons.com/thumb/round_icon/{}/{}_640.png'
FULL_URL							= f'https://www.skylinewebcams.com/{WEB_LANG}/webcam.html'
TOP_URL							= f'https://www.skylinewebcams.com/{WEB_LANG}/top-live-cams.html'
NEW_URL							= f'https://www.skylinewebcams.com/{WEB_LANG}/new-livecams.html'
LANG_URL							= f"https://www.skylinewebcams.com/{WEB_LANG}.html"
BASE_URL							= "https://www.skylinewebcams.com"

xbmcplugin.setContent(ADDON_HANDLE, 'movies')

def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def getRandom():
	WEBBROWSER = [['%s.0' % i for i in range(18, 50)], ['37.0.2062.103', '37.0.2062.120', '37.0.2062.124', '38.0.2125.101','38.0.2125.104',
		'38.0.2125.111', '39.0.2171.71', '39.0.2171.95', '39.0.2171.99', '40.0.2214.93', '40.0.2214.111', '40.0.2214.115', '39.0.2171.99',
		'40.0.2214.93', '40.0.2214.111', '40.0.2214.115', '42.0.2311.90', '42.0.2311.135', '42.0.2311.152', '43.0.2357.81', '43.0.2357.124',
		'44.0.2403.155', '44.0.2403.157', '45.0.2454.101', '45.0.2454.85', '46.0.2490.71', '46.0.2490.80', '46.0.2490.86', '47.0.2526.73',
		'47.0.2526.80', '49.0.2623.112', '50.0.2661.86'], ['11.0'], ['8.0', '9.0', '10.0', '10.6']]
	WINDOWS = ['Windows NT 10.0', 'Windows NT 7.0', 'Windows NT 6.3', 'Windows NT 6.2', 'Windows NT 6.1', 'Windows NT 6.0',
		'Windows NT 5.1', 'Windows NT 5.0']
	FEATURES = ['; WOW64', '; Win64; IA64', '; Win64; x64', '']
	RANDOM_AGENT = ['Mozilla/5.0 ({windows}{features}; rv:{browser}) Gecko/20100101 Firefox/{browser}',
		'Mozilla/5.0 ({windows}{features}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{browser} Safari/537.36',
		'Mozilla/5.0 ({windows}{features}; Trident/7.0; rv:{browser}) like Gecko']
	index = random.randrange(len(RANDOM_AGENT))
	releases = {'windows': random.choice(WINDOWS), 'features': random.choice(FEATURES), 'browser': random.choice(WEBBROWSER[index])}
	new_agent = RANDOM_AGENT[index].format(**releases)
	if ((ACTUAL_AGENT == "") or (LAST_STORED < time.time() - (15 * 60))): # Time in Seconds : 15*60 = 15 min.
		addon.setSetting('actual_user_agent', new_agent), addon.setSetting('last_agent_stored', str(int(time.time())))
		debug_MS(f"(common.getRandom) === CREATED NEW AGENT === AGENT : {str(new_agent)} || TIME : {str(int(time.time()))} ===")
	else: new_agent = ACTUAL_AGENT
	return new_agent

def _header(REFERRER=None):
	header = {} # !!! Accept-Language only set if browser should offer these languages !!!
	header['Pragma'] = 'no-cache'
	header['Accept'] = 'application/json, application/x-www-form-urlencoded, text/plain, */*'
	header['documentLifecycle'] = 'active'
	header['User-Agent'] = getRandom()
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	header['Origin'] = BASE_URL
	if REFERRER:
		header['Referer'] = REFERRER
	return header

def getMultiData(MURLS, method='GET', REF=None, fields=None):
	COMBI_NEW = []
	number = len(MURLS)
	def download(pos, sign, url, manager):
		response = manager.request(method, url, fields, headers=_header(REF), timeout=5, retries=2)
		if response and response.status in [200, 201, 202]:
			debug_MS(f"(common.getMultiData[1]) === POS : {str(pos)} === REQUESTED URL : {url} === REQUESTED HEADER : {_header(REF)} ===")
			return [pos, sign, url, py3_dec(response.data)]
		else:
			failing(f"(common.getMultiData[1]) ERROR - RESPONSE - ERROR ##### POS : {str(pos)} === STATUS : {str(response.status)} === URL : {url} === DATA : {str(response.data)} #####")
			return [pos, sign, url, None]
	with ThreadPoolExecutor() as executor:
		connector = urllib3.PoolManager(maxsize=20, block=True)
		debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
		picker = [executor.submit(download, pos, sign, url, connector) for pos, sign, url in MURLS]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for ii, future in enumerate(as_completed(picker), 1):
			try:
				COMBI_NEW.append(future.result())
			except Exception as e:
				failing(f"(common.getMultiData[2]) ERROR - EXEPTION - ERROR ##### FUTURE_CONNECT : {future.result()} === FAILURE : {str(e)} #####")
				dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(str(e)), icon, 10000)
				executor.shutdown()
		if COMBI_NEW:
			matching = [flop for flop in COMBI_NEW[:] if flop[3] is None]
			if len(matching) == number or len(matching) > 10:
				dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 10000)
		return COMBI_NEW

def getUrl(url, method='GET', REF=None, headers=None, cookies=None, allow_redirects=True, verify=True, stream=None, data=None, json=None, timeout=30):
	simple = requests.Session()
	ANSWER = None
	try:
		response = simple.get(url, headers=_header(REF), cookies=cookies, allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=timeout)
		ANSWER = response.json() if method in ['GET', 'POST'] else response.text if method == 'LOAD' else response
		debug_MS(f"(common.getUrl) === CALLBACK === STATUS : {str(response.status_code)} || URL : {response.url} || HEADER : {_header(REF)} ===")
	except requests.exceptions.RequestException as e:
		failing(f"(common.getUrl) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {str(e)} #####")
		dialog.notification(translation(30521).format('URL'), translation(30523).format(str(e)), icon, 12000)
		return sys.exit(0)
	return ANSWER

def clear_storage():
	debug_MS("(common.clear_storage) -------------------------------------------------- START = clear_storage --------------------------------------------------")
	debug_MS("(common.clear_storage) ========== Lösche jetzt den Addon-Cache ==========")
	if xbmcvfs.exists(tempDATA):
		shutil.rmtree(tempDATA, ignore_errors=True) # Delete tempDATA-Folder
	xbmc.sleep(1000)
	return dialog.ok(addon_id, translation(30501))

def clear_unknown(text):
	if text is not None:
		for ea in (('<strong>', '[B]'), ('</strong>', '[/B]'), ('<em>', '[I]'), ('</em>', '[/I]'), ('<br>', '[CR]'), ('</p><p>', '[CR][CR]')):
					text = text.replace(*ea)
		convert = UnicodeDammit(text.strip()) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
		return convert.unicode_markup
	return None

params = dict(parse_qsl(sys.argv[2][1:]))
mode = unquote_plus(params.get('mode', 'root'))
action = unquote_plus(params.get('action', 'DEFAULT'))
name = unquote_plus(params.get('name', ''))
url = unquote_plus(params.get('url', '00'))
page = unquote_plus(params.get('page', '1'))
position = unquote_plus(params.get('position', '0'))
extras = unquote_plus(params.get('extras', 'UNKNOWN'))
selection = unquote_plus(params.get('selection', 'standard'))
picture = unquote_plus(params.get('picture', ''))
IDENTiTY = unquote_plus(params.get('IDENTiTY', ''))
region = unquote_plus(params.get('region', ''))
plot = unquote_plus(params.get('plot', ''))
