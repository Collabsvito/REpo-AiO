﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	addDir(translation(30601), artpic+'favourites.png', {'mode': 'listShowsFavs'})
	addDir(translation(30602), icon, {'mode': 'listSeries', 'url': f"{API_URL}/content/shows?include=images,genres&sort=-newestEpisodePublishStart&filter[hasNewEpisodes]=true", 'extras': 'newest_Series'})
	addDir(translation(30603), icon, {'mode': 'listEpisodes', 'url': f"{API_URL}/content/videos?include=show,images,genres&sort=-earliestPlayableStart&filter[primaryChannel.id]={PRIMARY_CHANNEL}", 'extras': 'newest_Episodes'})
	addDir(translation(30604), icon, {'mode': 'listSeries', 'url': f"{API_URL}/content/shows?include=images,genres&sort=publishEnd&filter[hasExpiringEpisodes]=true", 'extras': 'last_Chance'})
	addDir(translation(30605), icon, {'mode': 'listThemes', 'url': f"{API_URL}/content/genres?include=images&filter[primaryChannel.id]={PRIMARY_CHANNEL}&page[size]=50"})
	addDir(translation(30606), icon, {'mode': 'listSeries', 'url': f"{API_URL}/content/shows?include=images,genres&sort=views.lastWeek", 'extras': 'most_Popular'})
	addDir(translation(30607), icon, {'mode': 'listAlphabet'})
	addDir(translation(30608), icon, {'mode': 'listSeries', 'url': f"{API_URL}/content/shows?include=images,genres&sort=name", 'extras': 'listing_Series'})
	if enableADJUSTMENT:
		addDir(translation(30609), f"{artpic}settings.png", {'mode': 'aConfigs'}, folder=False)
		if ADDON_operate('inputstream.adaptive'):
			addDir(translation(30610), f"{artpic}settings.png", {'mode': 'iConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listThemes(url):
	debug_MS("(navigator.listThemes) ------------------------------------------------ START = listThemes -----------------------------------------------")
	DATA = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listThemes[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	IMAGES = list(filter(lambda x: x['type'] == 'image', DATA.get('included', [])))
	for elem in DATA.get('data', []):
		image = icon
		genreID = elem.get('id', '00')
		name = cleaning(elem['attributes']['name'])
		if elem.get('relationships').get('images', None) and elem.get('relationships').get('images').get('data', None):
			image = [img.get('attributes', {}).get('src', []) for img in IMAGES if img.get('id') == elem['relationships']['images']['data'][0]['id']][0]
		NEW_URL = f"{API_URL}/content/shows?include=images,genres&sort=name&filter[genre.id]={genreID}"
		addDir(name, image, {'mode': 'listSeries', 'url': NEW_URL, 'extras': 'overview_Genres'})
		debug_MS(f"(navigator.listThemes[2]) ### NAME : {str(name)} || GENRE-ID : {genreID} || IMAGE : { image} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listAlphabet():
	debug_MS("(navigator.listAlphabet) ------------------------------------------------ START = listAlphabet -----------------------------------------------")
	for letter in ['0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']:
		NEW_URL = f"{API_URL}/content/shows?include=images,genres&sort=name&filter[name.startsWith]={letter.replace('0-9', '7')}"
		addDir(letter, f"{alppic}{letter}.jpg", {'mode': 'listSeries', 'url': NEW_URL, 'extras': 'overview_Alphabet'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeries(url, PAGE, POS, ADDITION):
	debug_MS("(navigator.listSeries) ------------------------------------------------ START = listSeries -----------------------------------------------")
	debug_MS(f"(navigator.listSeries) ### URL : {url} ### PAGE : {PAGE} ### POS : {POS} ### ADDITION : {ADDITION} ###")
	COMBI_PAGES, COMBI_SERIES, COMBI_FIRST = ([] for _ in range(3))
	UNIKAT, counter = set(), int(POS)
	NEW_URL = f"{url}&filter[primaryChannel.id]={PRIMARY_CHANNEL}&page[number]={PAGE}&page[size]=50"
	DATA_ONE = [] if 'filter[hasNewEpisodes]' in url and FORCE_SCRIPT else getUrl(NEW_URL)
	DEB_TEXT = "{'data': [], 'FORCE_SCRIPT': True, 'Skip FirstUrl': True}" if 'filter[hasNewEpisodes]' in url and FORCE_SCRIPT else str(DATA_ONE)
	debug_MS("+++++++++++++++++++++++")
	debug_MS(f"(navigator.listSeries[1]) XXXXX DATA_ONE-01 : {DEB_TEXT} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if 'filter[hasNewEpisodes]' in url and (('data' in DATA_ONE and len(DATA_ONE['data']) < 1) or not 'data' in DATA_ONE or FORCE_SCRIPT):
		for ii in range(1, 11, 1):
			SLINK = f"{url.replace('&filter[hasNewEpisodes]=true', '')}&filter[primaryChannel.id]={PRIMARY_CHANNEL}&page[number]={str(ii)}&page[size]=50"
			debug_MS(f"(navigator.listSeries[2]) SERIES-PAGES XXX POS = {str(ii)} || URL = {SLINK} XXX")
			COMBI_PAGES.append([int(ii), SLINK])
		if COMBI_PAGES:
			COMBI_SERIES = getMultiData(COMBI_PAGES)
			if COMBI_SERIES:
				DATA_TWO = json.loads(COMBI_SERIES)
				#log("++++++++++++++++++++++++")
				#log(f"(navigator.listSeries[3]) XXXXX DATA_TWO-03 : {str(DATA_TWO)} XXXXX")
				#log("++++++++++++++++++++++++")
				for item in DATA_TWO:
					if item is not None and 'data' in item and len(item['data']) > 0:
						GENRES = list(filter(lambda x: x['type'] == 'genre', item.get('included', [])))
						IMAGES = list(filter(lambda x: x['type'] == 'image', item.get('included', [])))
						for each in item.get('data', []):
							debug_MS("-----------------------------------------")
							debug_MS(f"(navigator.listSeries[3]) ### EACH-03 : {str(each)} ###")
							startTIMES, image = None, icon
							genre, plot = ("" for _ in range(2))
							oneGEN, twoGEN = ([] for _ in range(2))
							if each.get('relationships').get('genres', None) and each.get('relationships').get('genres').get('data', None):
								oneGEN = [og.get('id', []) for og in each['relationships']['genres']['data']]
								twoGEN = [tg.get('attributes', {}).get('name', []) for tg in GENRES if tg.get('id') in oneGEN]
								if twoGEN: genre = ' / '.join(sorted(twoGEN))
							if each.get('relationships').get('images', None) and each.get('relationships').get('images').get('data', None):
								image = [img.get('attributes', {}).get('src', []) for img in IMAGES if img.get('id') == each['relationships']['images']['data'][0]['id']][0]
							seriesID = each.get('id', None)
							if seriesID is None or seriesID in UNIKAT:
								continue
							UNIKAT.add(seriesID)
							each = each['attributes'] if each.get('attributes', '') else each
							if each.get('name', ''):
								name, seriesNAME = cleaning(each['name']), cleaning(each['name'])
							else: continue
							if str(each.get('newestEpisodePublishStart'))[:4].isdigit() and str(each.get('newestEpisodePublishStart'))[:4] not in ['0', '1970']:
								LOCALstart = get_Local_DT(each['newestEpisodePublishStart'][:19]) # 2022-06-07T21:05:00
								if LOCALstart > (datetime.now() - timedelta(days=7, hours=3)): # 7 Tage und 3 Stunden
									startTIMES = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':')
							NEWEST = True if (each.get('hasNewEpisodes', '') is True or startTIMES) else False
							if NEWEST is False: continue
							plot = cleaning(each['description']).replace('\n', '[CR]') if each.get('description', '') else ""
							debug_MS(f"(navigator.listSeries[4]) noFilter @@@@@ NAME : {str(name)} || SERIE-IDD : {seriesID} || IMAGE : {image} @@@@@")
							COMBI_FIRST.append([name, seriesID, image, seriesNAME, plot, genre, startTIMES, NEWEST])
	else:
		GENRES = list(filter(lambda x: x['type'] == 'genre', DATA_ONE.get('included', [])))
		IMAGES = list(filter(lambda x: x['type'] == 'image', DATA_ONE.get('included', [])))
		for elem in DATA_ONE.get('data', []):
			debug_MS("-----------------------------------------")
			debug_MS(f"(navigator.listSeries[33]) ### ELEM-33 : {str(elem)} ###")
			startTIMES, image = None, icon
			genre, plot = ("" for _ in range(2))
			oneGEN, twoGEN = ([] for _ in range(2))
			if elem.get('relationships').get('genres', None) and elem.get('relationships').get('genres').get('data', None):
				oneGEN = [og.get('id', []) for og in elem['relationships']['genres']['data']]
				twoGEN = [tg.get('attributes', {}).get('name', []) for tg in GENRES if tg.get('id') in oneGEN]
				if twoGEN: genre = ' / '.join(sorted(twoGEN))
			if elem.get('relationships').get('images', None) and elem.get('relationships').get('images').get('data', None):
				image = [img.get('attributes', {}).get('src', []) for img in IMAGES if img.get('id') == elem['relationships']['images']['data'][0]['id']][0]
			seriesID = elem.get('id', None)
			if seriesID is None or seriesID in UNIKAT:
				continue
			UNIKAT.add(seriesID)
			elem = elem['attributes'] if elem.get('attributes', '') else elem
			if elem.get('name', ''):
				name, seriesNAME = cleaning(elem['name']), cleaning(elem['name'])
			else: continue
			if str(elem.get('newestEpisodePublishStart'))[:4].isdigit() and str(elem.get('newestEpisodePublishStart'))[:4] not in ['0', '1970']:
				LOCALstart = get_Local_DT(elem['newestEpisodePublishStart'][:19]) # 2022-06-07T21:05:00
				if LOCALstart > (datetime.now() - timedelta(days=7, hours=3)): # 7 Tage und 3 Stunden
					startTIMES = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':')
			NEWEST = True if (elem.get('hasNewEpisodes', '') is True or startTIMES) else False
			plot = cleaning(elem['description']).replace('\n', '[CR]') if elem.get('description', '') else ""
			debug_MS(f"(navigator.listSeries[44]) noFilter @@@@@ NAME : {str(name)} || SERIE-IDD : {seriesID} || IMAGE : {image} @@@@@")
			COMBI_FIRST.append([name, seriesID, image, seriesNAME, plot, genre, startTIMES, NEWEST])
	debug_MS("*****************************************")
	for name, seriesID, image, seriesNAME, plot, genre, startTIMES, NEWEST in COMBI_FIRST:
		if seriesID and len(seriesID) < 9:
			counter += 1
			if 'views.lastWeek' in url:
				name = translation(30620).format(str(counter), seriesNAME)
			elif 'filter[hasExpiringEpisodes]' in url:
				name = translation(30621).format(name)
			if not 'filter[hasExpiringEpisodes]' in url and NEWEST is True:
				name = translation(30622).format(name)
			debug_MS(f"(navigator.listSeries[5]) Filtered **** NAME : {str(name)} || SERIE-IDD : {seriesID} || IMAGE : {image} ****")
			addType = 1
			if xbmcvfs.exists(channelFavsFile) and os.stat(channelFavsFile).st_size > 0:
				with open(channelFavsFile, 'r') as fp:
					watch = json.load(fp)
					for item in watch.get('items', []):
						if item.get('url') == seriesID: addType = 2
			addDir(name, image, {'mode': 'listEpisodes', 'url': seriesID, 'origSERIE': seriesNAME}, plot, genre, addType)
	if 'meta' in DATA_ONE and 'totalPages' in DATA_ONE['meta'] and isinstance(DATA_ONE['meta']['totalPages'], int) and int(PAGE) < int(DATA_ONE['meta']['totalPages']):
		debug_MS(f"(navigator.listSeries[6]) PAGES ### currentPG : {PAGE} from totalPG : {str(DATA_ONE['meta']['totalPages'])} ###")
		addDir(translation(30623), artpic+'nextpage.png', {'mode': 'listSeries', 'url': url, 'page': int(PAGE)+1, 'position': int(counter), 'extras': ADDITION})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(TVID, origSERIE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL : {TVID} ### origSERIE : {origSERIE} ###")
	COMBI_PAGES, COMBI_EPISODE, COMBI_SECOND = ([] for _ in range(3))
	POSS, FAULTS = 0, False
	backTIMES = (datetime.now() - timedelta(days=7, hours=2)).strftime('%Y{0}%m{0}%dT%H{1}%M{1}%SZ'.format('-', ':')) # 7 Tage und 2 Stunden // 2022-06-17T02:00:00Z
	for ii in range(1, 6, 1):
		ELINK = f"{API_URL}/content/videos?include=images,genres&sort=-seasonNumber,-episodeNumber&filter[show.id]={TVID}&filter[videoType]=EPISODE,STANDALONE&page[number]={str(ii)}&page[size]=100"
		if TVID.startswith(API_URL): # filter[earliestPlayableStart.gt] = ab zurückliegendem Zeitpunkt // filter[earliestPlayableStart.lt] = bis vorausliegendem Zeitpunkt
			ELINK = f"{TVID}&filter[earliestPlayableStart.gt]={backTIMES}&filter[videoType]=EPISODE,STANDALONE&page[number]={str(ii)}&page[size]=30"
		debug_MS(f"(navigator.listEpisodes[1]) EPISODE-PAGES XXX POS = {str(ii)} || URL = {ELINK} XXX")
		COMBI_PAGES.append([int(ii), ELINK])
	if COMBI_PAGES:
		COMBI_EPISODE = getMultiData(COMBI_PAGES)
		if COMBI_EPISODE:
			DATA_ONE = json.loads(COMBI_EPISODE)
			#log("++++++++++++++++++++++++")
			#log(f"(navigator.listEpisodes[2]) XXXXX DATA_ONE-02 : {str(DATA_ONE)} XXXXX")
			#log("++++++++++++++++++++++++")
			for item in sorted(DATA_ONE, key=lambda k: int(k.get('Position', 0) or 0), reverse=False):
				if item is not None and 'ERROR_occurred' in item: FAULTS = True
				elif item is not None and 'data' in item and len(item['data']) > 0:
					GENRES = list(filter(lambda x: x['type'] == 'genre', item.get('included', [])))
					IMAGES = list(filter(lambda x: x['type'] == 'image', item.get('included', [])))
					SHOWS = list(filter(lambda x: x['type'] == 'show', item.get('included', [])))
					for each in item.get('data', []):
						debug_MS("-----------------------------------------")
						debug_MS(f"(navigator.llistEpisodes[2]) ### EACH-02 : {str(each)} ###")
						image = icon
						plus_SUFFIX, number, Note_1, Note_2 = ("" for _ in range(4))
						genre, newSERIE, Title2, startTIMES, endTIMES, aired, begins, year, mpaa = (None for _ in range(9))
						oneGEN, twoGEN = ([] for _ in range(2))
						if each.get('relationships').get('genres', None) and each.get('relationships').get('genres').get('data', None):
							oneGEN = [og.get('id', []) for og in each['relationships']['genres']['data']]
							twoGEN = [tg.get('attributes', {}).get('name', []) for tg in GENRES if tg.get('id') in oneGEN]
							if twoGEN: genre = ' / '.join(sorted(twoGEN))
						if each.get('relationships').get('images', None) and each.get('relationships').get('images').get('data', None):
							image = [img.get('attributes', {}).get('src', []) for img in IMAGES if img.get('id') == each['relationships']['images']['data'][0]['id']][0]
						if TVID.startswith(API_URL) and each.get('relationships').get('show', None) and each.get('relationships').get('show').get('data', None):
							newSERIE = [tvs.get('attributes', {}).get('name', []) for tvs in SHOWS if tvs.get('id') == each['relationships']['show']['data']['id']][0]
						seriesname = origSERIE if newSERIE is None else newSERIE
						episID = each.get('id', '00')
						each = each['attributes'] if each.get('attributes', '') else each
						if each.get('name', ''):
							title = cleaning(each['name'])
						else: continue
						if each.get('isExpiring', '') is True or each.get('isNew', '') is True:
							plus_SUFFIX = translation(30624) if each.get('isNew', '') is True else translation(30625)
						season = str(each['seasonNumber']).zfill(2) if each.get('seasonNumber', '') else None
						episode = str(each['episodeNumber']).zfill(2) if each.get('episodeNumber', '') else None
						videoTYPE = each.get('videoType', 'SINGLE')
						if videoTYPE.upper() == 'STANDALONE' and episode is None:
							POSS += 1
						if season and episode:
							Title1 = translation(30626).format(season, episode) if videoTYPE.upper() == 'STANDALONE' else translation(30627).format(season, episode)
							Title2 = f"{title} - {newSERIE+plus_SUFFIX}" if newSERIE else title+plus_SUFFIX
							number = f"S{season}E{episode}"
						else:
							if videoTYPE.upper() == 'STANDALONE':
								episode = str(POSS).zfill(2)
								Title1 = translation(30628).format(episode)
								Title2 = f"{title}  (Special) - {plus_SUFFIX}" if not 'Special' in title else title+plus_SUFFIX
								if newSERIE:
									Title2 = f"{title}  (Special) - {newSERIE+plus_SUFFIX}" if not 'Special' in title else f"{title} - {newSERIE+plus_SUFFIX}"
								number = f"S00E{episode}"
							else: Title1 = f"{title} - {newSERIE+plus_SUFFIX}" if newSERIE else title+plus_SUFFIX
						if str(each.get('publishStart'))[:4].isdigit() and str(each.get('publishStart'))[:4] not in ['0', '1970']:
							LOCALstart = get_Local_DT(each['publishStart'][:19])
							startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
							aired = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # FirstAired
							begins = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # 23.07.2023 / OLDFORMAT
							if KODI_ov20:
								begins = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-07-23T12:30:00 / NEWFORMAT
						if str(each.get('publishEnd'))[:4].isdigit() and str(each.get('publishEnd'))[:4] not in ['0', '1970']:
							LOCALend = get_Local_DT(each['publishEnd'][:19])
							endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						if str(each.get('airDate'))[:4].isdigit() and str(each.get('airDate'))[:4] not in ['0', '1970']:
							year = str(each['airDate'])[:4]
						if startTIMES and endTIMES: Note_1 = translation(30629).format(startTIMES, endTIMES)
						elif startTIMES and endTIMES is None: Note_1 = translation(30630).format(startTIMES)
						elif startTIMES is None and endTIMES is None: Note_1 = '[CR]'
						if str(each.get('rating')).isdigit():
							mpaa = translation(30631).format(str(each['rating'])) if str(each.get('rating')) != '0' else translation(30632)
						if mpaa is None and each.get('contentRatings', '') and str(each.get('contentRatings', {})[0].get('code', '')).isdigit():
							mpaa = translation(30631).format(str(each['contentRatings'][0]['code'])) if str(each['contentRatings'][0]['code']) != '0' else translation(30632)
						Note_2 = cleaning(each['description']).replace('\n', '[CR]') if each.get('description', '') else ""
						plot = seriesname+'[CR]'+Note_1+Note_2
						protect = each.get('drmEnabled', False)
						duration = get_Time(each['videoDuration']) if str(each.get('videoDuration')).isdigit() else None
						COMBI_SECOND.append([number, Title1, Title2, episID, image, season, episode, seriesname, plot, duration, begins, aired, year, genre, mpaa, protect])
	if COMBI_SECOND:
		COMBI_SECOND = sorted(COMBI_SECOND, key=lambda d: d[0], reverse=True) if SORTING == '0' and not TVID.startswith(API_URL) else COMBI_SECOND
		for number, Title1, Title2, episID, image, season, episode, seriesname, plot, duration, begins, aired, year, genre, mpaa, protect in COMBI_SECOND:
			if SORTING == '1' and not TVID.startswith(API_URL):
				for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			name = Title1.strip() if Title2 is None else f"{Title1.strip()}  {Title2.strip()}"
			cineType = 'episode' if episode else 'movie'
			debug_MS("*****************************************")
			debug_MS(f"(navigator.listEpisodes[3]) ##### NAME : {str(name)} || IDD : {str(episID)} || DURATION : {str(duration)} #####")
			debug_MS(f"(navigator.listEpisodes[3]) ##### START : {str(startTIMES)} || SEASON : {str(season)} || EPISODE : {str(episode)} || MPAA : {str(mpaa)} #####")
			debug_MS(f"(navigator.listEpisodes[3]) ##### SERIE : {str(seriesname)} || IMAGE : {image} #####")
			addLink(name, image, {'mode': 'playVideo', 'url': episID, 'cineType': cineType}, season, episode, seriesname, plot, duration, begins, aired, year, genre, mpaa)
	elif not COMBI_SECOND and not FAULTS:
		debug_MS("(navigator.listEpisodes) ##### Keine COMBI_EPISODEN-Liste - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525), translation(30526).format(origSERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(PLID):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	STREAM, FINAL_URL, LICE = (False for _ in range(3))
	# NEW Playback = https://eu1-prod.disco-api.com/playback/videoPlaybackInfo/142036?usePreAuth=true
	DATA = getUrl(f"{API_URL}/playback/videoPlaybackInfo/{PLID}?usePreAuth=true")
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.playVideo[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if DATA.get('data', '') and DATA['data'].get('attributes', '') and len(DATA['data']['attributes']) > 0:
		SHORT = DATA['data']['attributes']
		if SHORT.get('protection', '') and SHORT['protection'].get('drmEnabled', '') is True:
			STREAM, MIME, FINAL_URL = 'MPD', 'application/dash+xml', SHORT['streaming']['dash']['url']
			LICE = SHORT['protection']['schemes']['widevine']['licenseUrl']
			drm_TOKEN = SHORT['protection']['drmToken']
			debug_MS("(navigator.playVideo[2]) ***** TAKE - Inputstream (mpd) - FILE *****")
		if not FINAL_URL and SHORT.get('protection', '') and SHORT['protection'].get('clearkeyEnabled', '') is True:
			STREAM, MIME, FINAL_URL = 'HLS', 'application/vnd.apple.mpegurl', SHORT['streaming']['hls']['url']
			debug_MS("(navigator.playVideo[2]) ***** TAKE - Inputstream (hls) - FILE *****")
	if FINAL_URL and STREAM and ADDON_operate('inputstream.adaptive'):
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		LSM.setMimeType(MIME)
		LSM.setProperty('inputstream', 'inputstream.adaptive')
		if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			LSM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
		LSM.setProperty('inputstream.adaptive.manifest_headers', f"User-Agent={get_userAgent()}") # On KODI v20 and above
		LSM.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={get_userAgent()}") # On KODI v19 and below
		if LICE:
			LSM.setProperty('inputstream.adaptive.license_key', LICENSE_URL.format(LICE, drm_TOKEN, 'R{SSM}'))
			debug_MS("(navigator.playVideo) LICENSE : "+LICENSE_URL.format(LICE, drm_TOKEN, 'R{SSM}'))
			LSM.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}|User-Agent={get_userAgent()}")
	else:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### PLID : {PLID} #####\n ########## KEINEN Stream-Eintrag gefunden !!! ##########")
		return dialog.notification(translation(30521).format('ID - ', PLID), translation(30527), icon, 8000)

def listShowsFavs():
	debug_MS("(navigator.listShowsFavs) ------------------------------------------------ START = listShowsFavs -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as fp:
			watch = json.load(fp)
			for item in watch.get('items', []):
				name = cleaning(item.get('name'))
				logo = icon if item.get('pict', 'None') == 'None' else item.get('pict')
				debug_MS(f"(navigator.listShowsFavs) ### NAME : {name} || URL : {item.get('url')} || IMAGE : {logo} ###")
				addDir(name, logo, {'mode': 'listEpisodes', 'url': item.get('url'), 'origSERIE': name}, cleaning(item.get('plot')), FAVclear=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(*args):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(channelFavsFile) and os.stat(channelFavsFile).st_size > 0:
		with open(channelFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'name': name, 'pict': pict, 'url': url, 'plot': plot})
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30528), translation(30529).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('url') != url]
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30528), translation(30530).format(name), icon, 8000)

def addDir(name, image, params={}, plot=None, genre=None, addType=0, FAVclear=False, folder=True):
	u = build_mass(params)
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setGenres([genre]), vinfo.setStudios(['TLC'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': genre, 'Studio': 'TLC'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	entries = []
	if addType == 1 and FAVclear is False:
		entries.append([translation(30651), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'ADD', 'name': params.get('origSERIE'), 'pict': 'None' if image == icon else image,
			'url': params.get('url'), 'plot': plot}))])
	if FAVclear is True:
		entries.append([translation(30652), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'DEL', 'name': name, 'pict': image, 'url': params.get('url'), 'plot': plot}))])
	liz.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, season=None, episode=None, seriesname=None, plot=None, duration=None, begins=None, aired=None, year=None, genre=None, mpaa=None):
	u = build_mass(params)
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		if str(season).isdigit(): vinfo.setSeason(int(season))
		if str(episode).isdigit(): vinfo.setEpisode(int(episode))
		vinfo.setTvShowTitle(seriesname)
		vinfo.setTitle(name)
		vinfo.setPlot(plot)
		if str(duration).isdigit(): vinfo.setDuration(int(duration))
		if begins: liz.setDateTime(begins)
		if aired: vinfo.setFirstAired(aired)
		if year: vinfo.setYear(int(year))
		if genre and len(genre) > 3: vinfo.setGenres([genre])
		vinfo.setStudios(['TLC'])
		if mpaa: vinfo.setMpaa(mpaa)
		vinfo.setMediaType(params.get('cineType'))
	else:
		vinfo = {}
		if str(season).isdigit(): vinfo['Season'] = season
		if str(episode).isdigit(): vinfo['Episode'] = episode
		vinfo['TvShowTitle'] = seriesname
		vinfo['Title'] = name
		vinfo['Plot'] = plot
		if str(duration).isdigit(): vinfo['Duration'] = duration
		if begins: vinfo['Date'] = begins
		if aired: vinfo['Aired'] = aired
		if year: vinfo['Year'] = year
		if genre and len(genre) > 3: vinfo['Genre'] = genre
		vinfo['Studio'] = 'TLC'
		if mpaa: vinfo['Mpaa'] = mpaa
		vinfo['Mediatype'] = params.get('cineType')
		liz.setInfo(type='Video', infoLabels=vinfo)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'Action(Queue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
