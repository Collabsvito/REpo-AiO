﻿# -*- coding: utf-8 -*-

from .common import *


class realvitoPlayer(xbmc.Player):
	def __init__(self, *args, **kwargs):
		xbmc.Player.__init__(self, *args, **kwargs)
		self.discoFinished = False
		self.discoCourse = 0
		self.actualTime = 0
		self.totalTime = 999999
		debug_MS("(navigator.discoPlayer[1]) -> [PLAYER]: >>> Player Instanz erstellt >>>")

	def onAVStarted(self):
		debug_MS("(navigator.discoPlayer[3]) -> [PLAYER]: >>> Wiedergabe gestartet >>>")

	def onPlayBackStopped(self):
		debug_MS("(navigator.discoPlayer[6]) -> [PLAYER]: <<< Wiedergabe gestoppt <<<")
		self.discoFinished = True
		self.discoCourse = 0
		self.actualTime = 0
		self.totalTime = 999999
		return

	def onPlayBackEnded(self):
		debug_MS("(navigator.discoPlayer[6]) -> [PLAYER]: @@@ Wiedergabe abgeschlossen @@@")
		self.onPlayBackStopped()

class discoPlayer:
	def start_timer(self):
		loop_time, xbmcPlayer, monitor = 2, realvitoPlayer(), xbmc.Monitor()
		while not monitor.abortRequested() and not xbmcPlayer.discoFinished:
			if FORCE_PLAYER is True and xbmc.getCondVisibility('Player.Playing') and xbmc.getCondVisibility('Player.HasVideo') and xbmcPlayer.isPlayingVideo():
				xbmcPlayer.discoCourse += 1
				if xbmcPlayer.totalTime == 999999:
					xbmcPlayer.totalTime = xbmcPlayer.getTotalTime()
					debug_MS(f"(navigator.discoPlayer[2]) -> [PLAYER]: STARTING === COURSE_no : {xbmcPlayer.discoCourse} === TOTAL_TIME : {convert_times(xbmcPlayer.totalTime, False, 0)}.000 / Modus gesamte Videolaufzeit abrufen ===")
				xbmcPlayer.actualTime = xbmcPlayer.getTime()
				if xbmcPlayer.actualTime != 0 and xbmcPlayer.totalTime != 999999:
					if xbmc.getCondVisibility('Player.Seeking'):
						continue
					if int(round(xbmcPlayer.actualTime*1000)) + 150000 < int(xbmcPlayer.totalTime)*1000:
						debug_MS(f"(navigator.discoPlayer[3]) -> [PLAYER]: WAITING === COURSE_no : {xbmcPlayer.discoCourse} === ACTUAL_TIME : {convert_times(xbmcPlayer.actualTime)} / Modus lange Wartezeit *90 Sekunden* ===")
						loop_time = 90
					else:
						debug_MS(f"(navigator.discoPlayer[4]) -> [PLAYER]: SLEEPING === COURSE_no : {xbmcPlayer.discoCourse} === ACTUAL_TIME : {convert_times(xbmcPlayer.actualTime)} / Modus kurze Wartezeit *2 Sekunden* ===")
						self.track_quick(xbmcPlayer, xbmcPlayer.discoFinished, xbmcPlayer.actualTime, xbmcPlayer.totalTime)
						loop_time = 2
				else:
					failing("(navigator.discoPlayer[3]) -> [PLAYER]: ERROR - TIME - ERROR XXXXX FAILURE : Die Laufzeitangaben des Videos sind fehlerhaft !!! XXXXX")
					xbmcPlayer.discoFinished = True
			else:
				failing("(navigator.discoPlayer[2]) -> [PLAYER]: ERROR - INTERRUPT - ERROR XXXXX FAILURE : Erzwungener Playerstopp wurde vom Benutzer deaktiviert oder es läuft zur Zeit kein Video !!! XXXXX")
				xbmcPlayer.discoFinished = True
			if monitor.waitForAbort(loop_time):
				break

	def track_quick(self, INSTANCE, FINISH, ACTUAL, TOTAL):
		if not FINISH and int(round(ACTUAL*1000)) >= int(TOTAL)*1000:
			debug_MS(f"(navigator.discoPlayer[5]) -> [PLAYER]: FORCE-STOPPING === ACTUAL_TIME : {convert_times(ACTUAL)} || TOTAL_TIME : {convert_times(TOTAL, False, 0)}.000 ===")
			INSTANCE.stop()
			FINISH = True
		else: pass
