﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import time
from datetime import datetime, timedelta
import requests
import base64
import hashlib
import hmac
from urllib.parse import urlparse, urlencode, quote_plus, unquote_plus  # Python 3.X
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


HOST_AND_PATH                 = sys.argv[0]
ADDON_HANDLE                  = int(sys.argv[1])
dialog                                      = xbmcgui.Dialog()
addon                                     = xbmcaddon.Addon()
addon_id                                = addon.getAddonInfo('id')
addon_name                         = addon.getAddonInfo('name')
addon_version                      = addon.getAddonInfo('version')
addonPath                             = xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                                = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
defaultFanart                        = os.path.join(addonPath, 'resources', 'media', 'fanart.jpg')
icon                                         = os.path.join(addonPath, 'resources', 'media', 'icon.png')
artpic                                      = os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
enableINPUTSTREAM          = addon.getSetting('useInputstream') == 'true'
useThumbAsFanart              = addon.getSetting('useThumbAsFanart') == 'true'
enableADJUSTMENT            = addon.getSetting('show_settings') == 'true'
DEB_LEVEL                            = (xbmc.LOGINFO if addon.getSetting('enableDebug') == 'true' else xbmc.LOGDEBUG) # kompatibel mit Python-2 und Python-3
GALEO_staticCODE               = addon.getSetting('new_staticCODE')
KODI_ov20                            = int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
IMG_cover                             = 'https://cms-api.galileo.tv{}'
API_BASE                               = 'https://www.galileo.tv/_next/data/' # B90QZil20zo6JXDXuBDQs # CODE of the Webpage
API_COMP                             = 'https://www.galileo.tv/_next/data/'+GALEO_staticCODE
API_PLAYER                          = 'https://vas-v4.p7s1video.net/4.0/getsources?token={}' # https://vas-v4.p7s1video.net/4.0/getsources?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InhfZ2FsaWxlb3R2LWRlIn0.eyJjb250ZW50X2lkcyI6eyI3MjMwMDMyIjp7fX0sInNlY3VyZV9kZWxpdmVyeSI6dHJ1ZSwiaWF0IjoxNjY3ODQ3NTcxLCJuYmYiOjE2Njc4NDcyNzEsImV4cCI6MTY2Nzg0Nzg3MX0.g5GVckykvoR6Mf7xih9I1fDgIvHkl5JMo6dcUa0yLZM   mit Authorization
BASE_URL                              = 'https://www.galileo.tv/'

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO): # Python-3
	return xbmc.log('[{0} v.{1}]{2}'.format(addon_id, addon_version, msg), level)

def get_userAgent():
	base = 'Mozilla/5.0 {0} AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36'
	if xbmc.getCondVisibility('System.Platform.Android'):
		if 'arm' in os.uname()[4]: return base.format('(X11; CrOS armv7l 7647.78.0)') # ARM based Linux
		return base.format('(X11; Linux x86_64)') # x86 Linux
	elif xbmc.getCondVisibility('System.Platform.Windows'):
		return base.format('(Windows NT 10.0; WOW64)') # Windows
	elif xbmc.getCondVisibility('System.Platform.IOS'):
		return base.format('(iPhone; CPU iPhone OS 10_3 like Mac OS X)') # iOS iPhone/iPad
	elif xbmc.getCondVisibility('System.Platform.Darwin'):
		return base.format('(Macintosh; Intel Mac OS X 10_10_1)') # Mac OSX
	return base.format('(X11; Linux x86_64)') # x86 Linux

def _header(REFERRER=None, USERTOKEN=None):
	header = {}
	header['Pragma'] = 'no-cache'
	header['Content-Type'] = 'application/json; charset=utf-8'
	header['User-Agent'] = get_userAgent()
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	header['Accept-Language'] = 'en-US,en;q=0.8,de;q=0.7'
	if REFERRER:
		header['Referer'] = REFERRER
	if USERTOKEN:
		header['Authorization'] = 'Bearer {}'.format(USERTOKEN)
	return header

def getUrl(url, method='GET', REF=None, AUTH=None, headers=None, cookies=None, allow_redirects=True, verify=True, stream=None, data=None, json=None):
	simple = requests.Session()
	ANSWER, freshCODE = (None for _ in range(2))
	success = False
	retries = 1
	if url[:4] == 'http':
		try:
			response = simple.get(url, headers=_header(REF, AUTH), allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=30)
			ANSWER = response.json() if method in ['GET', 'POST'] else response
			debug_MS("(utilities.retrieveContent) === CALLBACK === status : {} || url : {} || header : {} ===".format(str(response.status_code), response.url, _header(REF, AUTH)))
		except requests.exceptions.RequestException as e:
			failing("(common.getUrl) ERROR - ERROR - ERROR ##### url: {} === error: {} #####".format(url, str(e)))
			dialog.notification(translation(30521).format('URL', ''), translation(30523).format(str(e)), icon, 10000)
			return sys.exit(0)
	else:
		def getCollected(suffixURL, tokenTransfer=None):
			debug_MS("(common.getCollected) === suffixURL: {} || tokenTransfer: {} ===".format(suffixURL, str(tokenTransfer)))
			recentURL = API_BASE+tokenTransfer+suffixURL if tokenTransfer else API_BASE+GALEO_staticCODE+suffixURL
			return recentURL
		while not success and retries < 3: # 2 x Wiederholungen (gesamt=3) für den URL-Request ::: da der Code für die API_BASE evtl. wieder geändert wurde
			try:
				endURL = getCollected(url, freshCODE)
				response = simple.get(endURL, headers=_header(REF, AUTH), allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=30)
				ANSWER = response.json() if method in ['GET', 'POST'] else response.text
				success = True
				debug_MS("(common.getUrl) === CALLBACK === status : {} || url : {} || header : {} ===".format(str(response.status_code), response.url, _header(REF, AUTH)))
			except Exception as e: # No JSON object could be decoded
				failing("(common.getUrl) ERROR - CURRENT_TOKEN - ERROR ##### status: {} === url: {} === error: {} #####".format(str(response.status_code), url, str(e)))
				CONTENT = simple.get(BASE_URL, headers=_header(REF, AUTH), allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=10)
				freshCODE = re.compile('</script><script src="/_next/static/([^/]+?)/_ssgManifest.js" defer=', re.S).findall(CONTENT.text)[0]
				#freshCODE = re.compile('"query":{},"buildId":"([^"]+?)","runtimeConfig"', re.S).findall(CONTENT.text)[0]
				addon.setSetting('new_staticCODE', freshCODE)
				if retries > 1 and CONTENT.status_code not in [200, 201, 202]:
					dialog.notification(translation(30521).format('URL', ''), translation(30524), icon, 10000)
				time.sleep(2)
				retries += 1
			else:
				retries += 2
				break
	return ANSWER

def ADDON_operate(IDD):
	js_query = xbmc.executeJSONRPC('{{"jsonrpc":"2.0", "id":1, "method":"Addons.GetAddonDetails", "params":{{"addonid":"{}", "properties":["enabled"]}}}}'.format(IDD))
	if '"enabled":false' in js_query:
		try:
			xbmc.executeJSONRPC('{{"jsonrpc":"2.0", "id":1, "method":"Addons.SetAddonEnabled", "params":{{"addonid":"{}", "enabled":true}}}}'.format(IDD))
			failing("(common.ADDON_operate) ERROR - ERROR - ERROR :\n##### Das benötigte Addon : *{0}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####".format(IDD))
		except: pass
	if '"error":' in js_query:
		dialog.ok(addon_id, translation(30501).format(IDD))
		failing("(common.ADDON_operate) ERROR - ERROR - ERROR :\n##### Das benötigte Addon : *{0}* ist NICHT installiert !!! #####".format(IDD))
		return False
	if '"enabled":true' in js_query:
		return True

def getSorting():
	return [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, xbmcplugin.SORT_METHOD_DURATION, xbmcplugin.SORT_METHOD_DATE]

def cleaning(text):
	if text is not None:
		for n in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\xc2\xb7', '-'),
					("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''),
					('&#xC4;', 'Ä'), ('&#xE4;', 'ä'), ('&#xD6;', 'Ö'), ('&#xF6;', 'ö'), ('&#xDC;', 'Ü'), ('&#xFC;', 'ü'), ('&#xDF;', 'ß'), ('&#x201E;', '„'), ('&#xB4;', '´'), ('&#x2013;', '-'), ('&#xA0;', ' '),
					('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
					('&agrave;', 'à'), ('&Agrave;', 'À'), ('&aacute;', 'á'), ('&Aacute;', 'Á'), ('&acirc;', 'â'), ('&Acirc;', 'Â'), ('&egrave;', 'è'), ('&Egrave;', 'È'), ('&eacute;', 'é'), ('&Eacute;', 'É'), ('&ecirc;', 'ê'), ('&Ecirc;', 'Ê'),
					('&igrave;', 'ì'), ('&Igrave;', 'Ì'), ('&iacute;', 'í'), ('&Iacute;', 'Í'), ('&icirc;', 'î'), ('&Icirc;', 'Î'), ('&ograve;', 'ò'), ('&Ograve;', 'Ò'), ('&oacute;', 'ó'), ('&Oacute;', 'Ó'), ('&ocirc;', 'ô'), ('&Ocirc;', 'Ô'),
					('&ugrave;', 'ù'), ('&Ugrave;', 'Ù'), ('&uacute;', 'ú'), ('&Uacute;', 'Ú'), ('&ucirc;', 'û'), ('&Ucirc;', 'Û'), ('&yacute;', 'ý'), ('&Yacute;', 'Ý'),
					('&atilde;', 'ã'), ('&Atilde;', 'Ã'), ('&ntilde;', 'ñ'), ('&Ntilde;', 'Ñ'), ('&otilde;', 'õ'), ('&Otilde;', 'Õ'), ('&Scaron;', 'Š'), ('&scaron;', 'š'), ('&ccedil;', 'ç'), ('&Ccedil;', 'Ç'),
					('&alpha;', 'a'), ('&Alpha;', 'A'), ('&aring;', 'å'), ('&Aring;', 'Å'), ('&aelig;', 'æ'), ('&AElig;', 'Æ'), ('&epsilon;', 'e'), ('&Epsilon;', 'Ε'), ('&eth;', 'ð'), ('&ETH;', 'Ð'), ('&gamma;', 'g'), ('&Gamma;', 'G'),
					('&oslash;', 'ø'), ('&Oslash;', 'Ø'), ('&theta;', 'θ'), ('&thorn;', 'þ'), ('&THORN;', 'Þ'), ('&bull;', '•'), ('&iexcl;', '¡'), ('&iquest;', '¿'), ('&copy;', '(c)'), ('\t', '    '), ('<br />', ' - '),
					("&rsquo;", "’"), ("&lsquo;", "‘"), ("&sbquo;", "’"), ('&rdquo;', '”'), ('&ldquo;', '“'), ('&bdquo;', '”'), ('&rsaquo;', '›'), ('lsaquo;', '‹'), ('&raquo;', '»'), ('&laquo;', '«'),
					('\\xC4', 'Ä'), ('\\xE4', 'ä'), ('\\xD6', 'Ö'), ('\\xF6', 'ö'), ('\\xDC', 'Ü'), ('\\xFC', 'ü'), ('\\xDF', 'ß'), ('\\x201E', '„'), ('\\x28', '('), ('\\x29', ')'), ('\\x2F', '/'), ('\\x2D', '-'), ('\\x20', ' '), ('\\x3A', ':'), ("\\'", "'")):
					text = text.replace(*n)
		text = re.sub('\<.*?\>', '', text)
		text = text.strip()
	return text

def jwt_enc_hs256(payload_data, key_data):
	header_data = {'alg': 'HS256', 'typ': 'JWT', 'kid': 'x_galileotv-de'}
	header_b64 = base64.urlsafe_b64encode(json.dumps(header_data).encode()).replace(b"=", b"")
	payload_b64 = base64.urlsafe_b64encode(json.dumps(payload_data).encode()).replace(b"=", b"")
	h6 = hmac.new(key_data.encode(), header_b64 + b'.' + payload_b64, hashlib.sha256)
	signature_b64 = base64.urlsafe_b64encode(h6.digest()).replace(b"=", b"")
	com_token = header_b64 + b'.' + payload_b64 + b'.' + signature_b64
	return com_token

def parameters_string_to_dict(parameters):
	paramDict = {}
	if parameters:
		paramPairs = parameters[1:].split('&')
		for paramsPair in paramPairs:
			paramSplits = paramsPair.split('=')
			if (len(paramSplits)) == 2:
				paramDict[paramSplits[0]] = paramSplits[1]
	return paramDict

params = parameters_string_to_dict(sys.argv[2])
name = unquote_plus(params.get('name', ''))
url = unquote_plus(params.get('url', ''))
plot = unquote_plus(params.get('plot', ''))
mode = unquote_plus(params.get('mode', 'root'))
page = unquote_plus(params.get('page', '1'))
position = unquote_plus(params.get('position', '0'))
first = unquote_plus(params.get('first', 'standard'))
extras = unquote_plus(params.get('extras', 'standard'))
transmit = unquote_plus(params.get('transmit', 'Unbekannt'))
