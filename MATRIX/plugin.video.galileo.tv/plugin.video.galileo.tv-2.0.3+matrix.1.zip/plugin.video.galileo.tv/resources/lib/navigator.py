﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	debug_MS("(navigator.mainMenu) ------------------------------------------------ START = mainMenu -----------------------------------------------")
	slug = None
	DATA = getUrl('/de/serien/galileo.json')
	if DATA is not None and DATA.get('pageProps', '') and DATA['pageProps'].get('content', '') and DATA['pageProps']['content'].get('header', '') and \
		DATA['pageProps']['content']['header'].get('nav', '') and DATA['pageProps']['content']['header']['nav'].get('tabs', ''):
		for item in DATA['pageProps']['content']['header']['nav']['tabs']: # home, alle-videos, alle-rezepte, natur, gesundheit, life, weltall, technik, abenteuer --- Stand vom: 24.12.2023 ---
			slug = item['href'] if item['href'].startswith('/de/serien') else f"/de{item['href']}"
			name = cleaning(item['text'])
			IDENT = 'OVERVIEW' if slug == '/de/serien/galileo' else 'STANDARD'
			addDir({'mode': 'listTopics', 'url': f"{slug}.json", 'extras': IDENT}, create_entries({'Title': translation(30601).format(name.title())}))
			debug_MS(f"(navigator.mainMenu) ### NAME : {name} || SLUG : {slug} ###")
	addDir({'mode': 'listEpisodes', 'url': '/de/serien/galileo/news/galileo-stories-61405.json', 'extras': 'doc-1gf39e9n40', 'transmit': 'Galileo Stories'}, create_entries({'Title': translation(30602)}))
	addDir({'mode': 'listEpisodes', 'url': '/de/archiv/galileo-x-plorer.json', 'extras': 'landscape-1', 'transmit': 'Galileo X-Plorer'}, create_entries({'Title': translation(30603)}))
	#addDir({'mode': 'listEpisodes', 'url': '/de/serien/galileo/news/galileo-plus-61404.json', 'extras': 'doc-1gf38q80m0', 'transmit': 'Galileo Plus'}, create_entries({'Title': translation(30604)}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30609), 'Image': f"{artpic}settings.png"}), folder=False)
		if ADDON_operate('inputstream.adaptive'):
			addDir({'mode': 'iConfigs'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"}), folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTopics(url, EXTRA):
	debug_MS("(navigator.listTopics) -------------------------------------------------- START = listTopics --------------------------------------------------")
	debug_MS(f"(navigator.listTopics) ### URL = {url} ### EXTRA = {EXTRA} ###")
	UNWANTED = ['article-related-teaser-section', 'teaser-lane-section']
	(PLOT_1, TAG_2, PLOT_2), PHOTO_2 = (None for _ in range(3)), icon
	DATA = getUrl(url)
	if DATA is not None and DATA.get('pageProps', '') and DATA['pageProps'].get('content', '') and DATA['pageProps']['content'].get('pageHeader', '') and DATA['pageProps']['content']['pageHeader'].get('pills', ''):
		for entry in DATA['pageProps']['content']['pageHeader']['pills']: # Oberkategorien für einzelne Themen
			SLUG_1 = entry['pathname'] if entry['pathname'].startswith('/de/serien') else f"/de{entry['pathname']}"
			NAME_1 = cleaning(entry['title'])
			if entry.get('imageConfig', '') and entry['imageConfig'].get('src', ''):
				PHOTO_1 = entry['imageConfig']['src'].split('?')[0]
			else: PHOTO_1 = icon
			PLOT_1 = DATA['pageProps']['content']['pageHeader']['intro'] if DATA['pageProps']['content']['pageHeader'].get('intro', '') else None
			FETCH_UNO = create_entries({'Title': translation(30620).format(NAME_1), 'Plot': PLOT_1, 'Image': PHOTO_1})
			addDir({'mode': 'listTopics', 'url': f"{SLUG_1}.json", 'extras': SLUG_1}, FETCH_UNO)
			debug_MS(f"(navigator.listTopics[1]) ### NAME : {NAME_1} || SLUG : {SLUG_1} ###")
	if DATA is not None and DATA.get('pageProps', '') and DATA['pageProps'].get('content', '') and DATA['pageProps']['content'].get('body', ''):
		for item in DATA['pageProps']['content']['body']: # Unterkategorien für alle Themen
			if EXTRA == 'OVERVIEW' and not item.get('component', '') in ['teaser-highlight-section', 'teaser-lane-section', 'teaser-auto-lane-section']: continue # Leere Ordner und ADS ausblenden
			if item.get('component', '') == 'heading-two' and item.get('text', ''):
				TAG_2 = cleaning(item['text'], True)
			if item.get('component', '') == 'paragraph' and item.get('text', ''):
				PLOT_2 = cleaning(item['text'], True)
			PLOT_2 = PLOT_1 if PLOT_2 is None else PLOT_2
			if (item.get('teasers', '') and len(item['teasers']) > 0) or (item.get('videoContent', '') and len(item['videoContent']) > 0) or (item.get('highlights', '') and len(item['highlights']) > 0):
				if EXTRA != 'OVERVIEW' and any(x in item.get('component', '') for x in UNWANTED):
					continue # UNWANTED ausblenden
				NAME_2 = cleaning(item['title']) if item.get('title', '') else 'Galileo-Highlights' # Highlights - Bezeichnung ist leer, daher hier den Namen einblenden
				SLUG_2 = item.get('id', '')
				if item.get('highlights', '') and item.get('highlights', {})[0].get('imageConfig', '') and item.get('highlights', {})[0].get('imageConfig', {}).get('src', ''):
					PHOTO_2 = item['highlights'][0]['imageConfig']['src']
				if item.get('teasers', '') and not 'teasers' in item['teasers'] and item.get('teasers', {})[0].get('imageConfig', '') and item.get('teasers', {})[0].get('imageConfig', {}).get('src', ''):
					PHOTO_2 = item['teasers'][0]['imageConfig']['src']
				elif item.get('teasers', '') and 'teasers' in item['teasers'] and item['teasers'].get('teasers', {})[0].get('imageConfig', '') and item['teasers'].get('teasers', {})[0].get('imageConfig', {}).get('src', ''):
					PHOTO_2 = item['teasers']['teasers'][0]['imageConfig']['src']
				FETCH_DUE = create_entries({'Title': NAME_2, 'Tagline': TAG_2, 'Plot': PLOT_2, 'Image': PHOTO_2})
				addDir({'mode': 'listEpisodes', 'url': url, 'extras': SLUG_2, 'transmit': NAME_2}, FETCH_DUE)
				debug_MS(f"(navigator.listTopics[2]) ### NAME : {NAME_2} || SLUG : {SLUG_2} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, EXTRA, TRANS):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL = {url} ### EXTRA = {EXTRA} ### FOLDERNAME = {TRANS} ###")
	DATA_ONE, counter, SEND, (UNIKAT, SINGLE) = None, 0, {}, (set() for _ in range(2))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_MULTI, COMBI_THIRD, COMBI_FOURTH, SEND['videos'] = ([] for _ in range(7))
	DATA_ONE = getUrl(url)
	if DATA_ONE is not None and DATA_ONE.get('pageProps', '') and DATA_ONE['pageProps'].get('content', ''):
		if EXTRA in ['doc-1gf39e9n40', 'doc-1gf38q80m0'] and DATA_ONE['pageProps']['content'].get('footer', ''):
			elements = DATA_ONE['pageProps']['content']['footer']
		elif EXTRA == 'landscape-1' and DATA_ONE['pageProps']['content'].get('teasersSection', ''):
			elements = [DATA_ONE['pageProps']['content']['teasersSection']]
			if DATA_ONE['pageProps']['content'].get('page', '') and str(DATA_ONE['pageProps']['content']['page']).isdecimal() and \
				DATA_ONE['pageProps']['content'].get('totalPages', '') and str(DATA_ONE['pageProps']['content']['totalPages']).isdecimal():
				if int(DATA_ONE['pageProps']['content']['totalPages']) > int(DATA_ONE['pageProps']['content']['page']):
					DATA_NEXT = getUrl(f"{url}?page=2")
					elements += [DATA_NEXT['pageProps']['content']['teasersSection']]
		elif EXTRA not in ['doc-1gf39e9n40', 'landscape-1', 'doc-1gf38q80m0'] and DATA_ONE['pageProps']['content'].get('body', ''):
			elements = DATA_ONE['pageProps']['content']['body']
		else: elements = []
		for element in elements:
			if element.get('id', '') == EXTRA:
				debug_MS("++++++++++++++++++++++++")
				debug_MS(f"(navigator.listEpisodes[1]) XXXXX ELEMENT-01 : {element} XXXXX")
				debug_MS("++++++++++++++++++++++++")
				items = element['highlights'] if element.get('highlights', '') else []
				items += element['teasers'] if not 'teasers' in element.get('teasers', '') else element['teasers']['teasers'] if 'teasers' in element.get('teasers', '') else []
				for item in items:
					markID_1 = item.get('entityId', '00')
					PREFIX = 'newsTeaser' if item.get('contentType') == 'article' else 'videoTeaser'
					TITLE_1 = cleaning(item[PREFIX]['title'])
					THUMB_1 = item['imageConfig']['src'] if item.get('imageConfig', '') and item['imageConfig'].get('src', '') else icon
					EXTERN_1 = (True if item.get('external', '') is True else False)
					TARGET_1 = item['trackingData'].get('targetUrl', '')
					if EXTERN_1 is True and TARGET_1.startswith(BASE_JOYN[:-4]):
						if not 'serien/' in TARGET_1: continue
						SWEEP = urlparse(TARGET_1)
						PATH_1, URL_TWO, POINT_1 = SWEEP.path, f"JOYN_REDIRECT@@{SWEEP.path.replace('play/', '')}.json", BASE_JOYN
					else:
						TARGET_1 = TARGET_1 if TARGET_1.startswith('/de/serien') else f"/de{TARGET_1}"
						PATH_1, URL_TWO, POINT_1 = TARGET_1, f"{TARGET_1}.json", BASE_PROSIEBEN
					counter += 1
					COMBI_FIRST.append([int(counter), markID_1, PATH_1, TITLE_1, THUMB_1, TARGET_1, URL_TWO])
					COMBI_LINKS.append([int(counter), PATH_1, URL_TWO, POINT_1])
	if COMBI_FIRST:
		for METER_2, PATH_2, CONT_2, POINT_2 in COMBI_LINKS:
			URL_THREE = getUrl(CONT_2, method='TRACK', REF=POINT_2)
			if URL_THREE is None:
				TEXT_TWO, DATA_TWO = (None for _ in range(2))
			else:
				TEXT_TWO, DATA_TWO = URL_THREE.text, URL_THREE.json()
			#log("++++++++++++++++++++++++")
			#log(f"(navigator.listEpisodes[2]) XXXXX DATA_TWO-02 : {DATA_TWO} XXXXX")
			#log("++++++++++++++++++++++++")
			if DATA_TWO is not None and DATA_TWO.get('pageProps', '') and (DATA_TWO['pageProps'].get('video', '') or DATA_TWO['pageProps'].get('initialData', '') or DATA_TWO['pageProps'].get('content', '')):
				BRIEF = DATA_TWO['pageProps']
				if BRIEF.get('initialData', '') and BRIEF['initialData'].get('page', '') and BRIEF['initialData']['page'].get('episode', ''):
					COMBI_SECOND.append({'NUMBER': METER_2, 'WAYS': PATH_2, 'VIDEO': BRIEF['initialData']['page']['episode']['video'], 'INFO': BRIEF['initialData']['page']['episode'], 'HEAD': None, \
						'PHOTO': None, 'META': DATA_TWO.get('emptyField', {}), 'SEVEN': False, 'JOYN': True, 'EMBED': False, 'MANUAL': None, 'TIMER': DATA_TWO.get('emptyField', {})})
				if BRIEF.get('video', '') and BRIEF.get('info', ''):
					COMBI_SECOND.append({'NUMBER': METER_2, 'WAYS': PATH_2, 'VIDEO': BRIEF['video'], 'INFO': BRIEF['info'], 'HEAD': None, 'PHOTO': None, 'META': DATA_TWO.get('emptyField', {}), \
						'SEVEN': True, 'JOYN': False, 'EMBED': False, 'MANUAL': None, 'TIMER': DATA_TWO.get('emptyField', {})})
				if BRIEF.get('content', '') and BRIEF['content'].get('header', '') and BRIEF['content']['header'].get('video', '') and BRIEF['content']['header']['video'].get('videoContent', ''):
					PERIOD = BRIEF['articleStructuredData'] if BRIEF.get('articleStructuredData', '') else BRIEF['recipeStructuredData'] if BRIEF.get('recipeStructuredData', '') else DATA_TWO.get('emptyField', {})
					COMBI_SECOND.append({'NUMBER': METER_2, 'WAYS': PATH_2, 'VIDEO': BRIEF['content']['header']['video']['videoContent'], 'INFO': DATA_TWO.get('emptyField', {}), \
						'HEAD': BRIEF['content']['header']['video']['videoClipStructuredData']['headline'], 'PHOTO': None, 'META': BRIEF['content']['header']['video']['videoClipStructuredData'], \
						'SEVEN': True, 'JOYN': False, 'EMBED': False, 'MANUAL': None, 'TIMER': PERIOD})
				if BRIEF.get('content', '') and BRIEF['content'].get('body', '') and (BRIEF.get('articleStructuredData', '') or BRIEF.get('recipeStructuredData', '')):
					(NAMING, AREA, CODE), (POS_COM, POS_VID, POS_YOU), content = (None for _ in range(3)), (0 for _ in range(3)), BRIEF['content'].get('body', [])
					TEXTS = list(filter(lambda x: x['component'] == 'paragraph', content))
					LINES = list(filter(lambda x: x['component'] == 'quick-info-container', content))
					if TEXT_TWO is not None:
						part = TEXT_TWO.split(',"body":')[1].split('"component":"heading')
						for i in range(1, len(part), 1):
							record = part[i][:part[i].rfind('"providerName":"youtube"')]
							if 'https://www.youtube.com/embed/' in record:
								COMPONENT = re.compile(r'''["']component["']:["']paragraph["'],["']text["']:["'](.*?)["']},''', re.S).findall(record)
								if COMPONENT:
									DESC_1 = 'breakone'.join(COMPONENT[:3])
									POS_COM += 1
									COMBI_MULTI.append({'NUM_URL': METER_2, 'NUM_COM': POS_COM, 'MULTI': DESC_1})
					for more in content:
						(MULTI_TEXT, PICTURE), OEMBED = (None for _ in range(2)), False
						if more.get('component') == 'single-video-embed' and more.get('sectionHeadline', '') and more['sectionHeadline'].get('sectionTitle', ''):
							NAMING = more['sectionHeadline']['sectionTitle']
							if more.get('videoContent', '') and len(more['videoContent']) > 0:
								PICTURE, AREA, CODE = more['videoContent'].get('thumbnail', None), more['videoContent'], more['videoContent'].get('id', None)
								POS_VID += 1
						FULL_META = more['videoClipStructuredData'] if more.get('videoClipStructuredData', '') and AREA else None
						if more.get('component') == 'oembed' and more.get('providerName') == 'youtube':
							SRC_YOU = re.compile(r'''https://www.youtube.com/embed/([^"']+)["']''', re.S).findall(more.get('html', ''))
							NAM_YOU = re.compile(r'''title=["']([^"']+)["']''', re.S).findall(more.get('html', ''))
							if SRC_YOU:
								if NAM_YOU: NAMING = NAM_YOU[0].replace('|', '-')
								PICTURE = f"https://i.ytimg.com/vi/{SRC_YOU[0].split('?')[0]}/hqdefault.jpg"
								try:
									IMG_TEST = urlopen(f"https://i.ytimg.com/vi/{SRC_YOU[0].split('?')[0]}/maxresdefault.jpg", timeout=5).getcode()
									if IMG_TEST in [200, 201, 202]: PICTURE = f"https://i.ytimg.com/vi/{SRC_YOU[0].split('?')[0]}/maxresdefault.jpg"
								except: pass
								OEMBED, AREA, CODE = True, SRC_YOU[0].split('?')[0], SRC_YOU[0].split('?')[0]
								POS_YOU += 1
						if OEMBED is True and COMBI_MULTI:
							for trust in COMBI_MULTI:
								if trust['NUM_URL'] == METER_2 and trust['NUM_COM'] == POS_YOU: MULTI_TEXT = trust['MULTI']
						DESC_2 = [top.get('text', '') for top in TEXTS if top.get('id', '')[:3] == 'doc' and len(re.sub(r'\<.*?\>', '', top.get('text', ''))) > 110]
						if DESC_2 and ((FULL_META is None and OEMBED is False) or (MULTI_TEXT is None and OEMBED is True)):
							if len(DESC_2) > 0 and MULTI_TEXT is None and POS_YOU == 1: MULTI_TEXT = 'breakone'.join(DESC_2[:3])
							if len(DESC_2) > 0 and OEMBED is False and POS_VID == 1: MULTI_TEXT = 'breakone'.join(DESC_2[:3])
							if len(DESC_2) > 3 and MULTI_TEXT is None and POS_YOU == 2: MULTI_TEXT = 'breakone'.join(DESC_2[3:6])
							if len(DESC_2) > 3 and OEMBED is False and POS_VID == 2: MULTI_TEXT = 'breakone'.join(DESC_2[3:6])
							if len(DESC_2) > 6 and MULTI_TEXT is None and POS_YOU == 3: MULTI_TEXT = 'breakone'.join(DESC_2[6:9])
							if len(DESC_2) > 6 and OEMBED is False and POS_VID == 3: MULTI_TEXT = 'breakone'.join(DESC_2[6:9])
							if len(DESC_2) > 9 and MULTI_TEXT is None and POS_YOU == 4: MULTI_TEXT = 'breakone'.join(DESC_2[9:12])
							if len(DESC_2) > 9 and OEMBED is False and POS_VID == 4: MULTI_TEXT = 'breakone'.join(DESC_2[9:12])
						FULL_META = DATA_TWO.get('emptyField', {}) if FULL_META is None else FULL_META
						STRUCT = 'articleStructuredData' if BRIEF.get('articleStructuredData', '') else 'recipeStructuredData' if BRIEF.get('recipeStructuredData', '') else None
						CLOCK = BRIEF[STRUCT] if STRUCT and AREA else DATA_TWO.get('emptyField', {})
						DESC_5 = [linpart.get('lines', []) for linpart in LINES if LINES and linpart.get('id', '')[:3] == 'doc']
						if MULTI_TEXT is None and DESC_5 and len(DESC_5[0]) > 0 and (POS_YOU == 1 or POS_VID == 1): MULTI_TEXT = 'breakone'.join(DESC_5[0][:4])
						if AREA and NAMING:
							if CODE is None or CODE in UNIKAT:
								continue
							UNIKAT.add(CODE)
							COMBI_THIRD.append({'NUMBER': METER_2, 'WAYS': PATH_2, 'VIDEO': AREA, 'INFO': DATA_TWO.get('emptyField', {}), 'HEAD': NAMING, 'PHOTO': PICTURE, \
								'META': FULL_META, 'SEVEN': True, 'JOYN': False, 'EMBED': OEMBED, 'MANUAL': MULTI_TEXT, 'TIMER': CLOCK})
	if COMBI_SECOND or COMBI_THIRD:
		COMBI_MERGE = COMBI_SECOND+COMBI_THIRD
		debug_MS("++++++++++++++++++++++++")
		debug_MS(f"(navigator.listEpisodes[3]) XXXXX COMBI_MERGE-03 : {COMBI_MERGE} XXXXX")
		for each in COMBI_MERGE:
			MPAA_2, THUMB_2, SEAS_2, EPIS_2, AIRED_2, BEGINS_2 = (None for _ in range(6))
			COUNT_2, WAYS_2, VIDEO, INFO, HEAD, PHOTO = each['NUMBER'], each['WAYS'], each['VIDEO'], each['INFO'], each['HEAD'], each['PHOTO']
			META, SEVEN_2, JOYN_2, EMBED_2, MANUAL, TIMER = each['META'], each['SEVEN'], each['JOYN'], each['EMBED'], each['MANUAL'], each['TIMER']
			if VIDEO:
				markID_2 = VIDEO.get('id', None) if EMBED_2 is False else VIDEO
				if markID_2 is None or markID_2 in SINGLE:
					continue
				SINGLE.add(markID_2)
				if INFO.get('ageRating', '') and INFO['ageRating'].get('minAge', '') and str(INFO['ageRating']['minAge']).isdecimal():
					MPAA_2 = str(INFO['ageRating']['minAge'])
				elif EMBED_2 is False and VIDEO.get('ageRestriction', '') and str(VIDEO['ageRestriction']).isdecimal():
					MPAA_2 = str(VIDEO['ageRestriction'])
				DURATION_2 = VIDEO['duration'] if EMBED_2 is False and str(VIDEO.get('duration')).isdecimal() else None
				THUMB_2 = PHOTO
				if PHOTO is None and INFO.get('heroImageDesktop', '') and INFO['heroImageDesktop'].get('url', ''):
					THUMB_2 = INFO['heroImageDesktop']['url']
				elif PHOTO is None and EMBED_2 is False and VIDEO.get('thumbnail', ''):
					THUMB_2 = VIDEO['thumbnail']
				NAME = (INFO.get('title', None) or INFO.get('mediaTitle', None))
				TITLE_2 = cleaning(HEAD) if NAME is None and HEAD else cleaning(NAME)
				ROUTE_2 = INFO['path'] if INFO.get('path', '') else None
				STORY = (INFO.get('description', None) or INFO.get('metaDescription', None) or META.get('description', None))
				STORY = MANUAL if STORY is None and MANUAL else STORY
				PLOT_2 = cleaning(STORY, True) if STORY else ""
				if INFO.get('season', '') and isinstance(INFO['season'], list) and INFO['season'].get('number', '') and str(INFO['season']['number']).isdecimal():
					SEAS_2 = str(INFO['season']['number']).zfill(2)
				elif INFO.get('season', '') and not isinstance(INFO['season'], list) and str(INFO['season']).isdecimal():
					SEAS_2 = str(INFO['season']).zfill(2)
				CHAPTER = (INFO.get('episode', None) or INFO.get('number', None))
				EPIS_2 = str(CHAPTER).zfill(2) if str(CHAPTER).isdecimal() else None
				PUBLISHED = (INFO.get('date', None) or INFO.get('createdAt', None) or INFO.get('startsAt', None) or INFO.get('publishedAt', None))
				if str(PUBLISHED).isdecimal(): # 1702235640
					LOCALstart = get_CentralTime(datetime(1970, 1, 1) + timedelta(seconds=PUBLISHED))
					AIRED_2 = LOCALstart.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
					BEGINS_2 = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # 23.02.2024 / OLDFORMAT
					if KODI_ov20:
						BEGINS_2 = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2024-02-23T04:17:00.00 / NEWFORMAT
				MODIFIED = (META.get('uploadDate', None) or TIMER.get('dateModified', None) or TIMER.get('datePublished', None))
				if AIRED_2 is None and MODIFIED and len(MODIFIED) >= 19:
					LOCALstart = get_CentralTime(MODIFIED, 'FULLTIME')
					AIRED_2 = LOCALstart.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
					BEGINS_2 = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # 23.02.2024 / OLDFORMAT
					if KODI_ov20:
						BEGINS_2 = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2024-02-23T04:17:00.00 / NEWFORMAT
				COMBI_FOURTH.append([int(COUNT_2), markID_2, WAYS_2, TITLE_2, THUMB_2, SEAS_2, EPIS_2, MPAA_2, BEGINS_2, AIRED_2, PLOT_2, DURATION_2, JOYN_2, ROUTE_2, EMBED_2])
	if COMBI_FIRST and COMBI_FOURTH:
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_FOURTH if a[2] == b[2]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listEpisodes[4]) XXXXX RESULT-04 : {RESULT} XXXXX")
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda pn: int(pn[0])): # Liste1 = 0-6 || Liste2 = 7-21
			Note_1, Note_2, Note_3 = ("" for _ in range(3))
			debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
			debug_MS(f"(navigator.listEpisodes[4]) ### Anzahl = {str(len(da))} || Eintrag : {da} ###")
			'''
			STANDARD:
				Liste-1 = Number1, Mark1, Title1, Thumb1, target, link = da[0], da[1], da[2], da[3], da[4], da[5], da[6]
				Liste-2 = Number2, Mark2, Path2, Title2, Thumb2, season, episode, mpaa, begins, aired, description, duration, Joyn2, Route2 = \
					da[7], da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19], da[20], da[21]
			'''
			if len(da) >= 22: ### Liste1+Liste2 ist grösser als oder ist gleich Nummer:22 ###
				Number1, Mark1, Path1, Title1, Thumb1, target, link = da[0], da[1], da[2], da[3], da[4], da[5], da[6]
				Number2, Mark2, Path2, Title2, Thumb2, season, episode, mpaa, begins, aired, description, duration, Joyn2, Route2, youtube = \
					da[7], da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19], da[20], da[21]
			else: continue
			name = Title2
			if TRANS : Note_1 = translation(30621).format(TRANS)
			if season and episode: Note_2 = translation(30622).format(season, episode)
			elif season is None and episode: Note_2 = translation(30623).format(episode)
			if aired: Note_3 = translation(30624).format(aired)
			if TRANS and aired is None: Note_3 = '[CR]'
			plot = Note_1+Note_2+Note_3+description
			studio = 'Joyn.de' if Joyn2 is True else 'Youtube' if youtube is True else 'ProSieben'
			PIC_BASIS = Thumb2 if Thumb2 else Thumb1
			image = PIC_BASIS
			fanart = f"{PIC_BASIS.split('/profile')[0]}/profile:original?w=1200" if '/profile' in PIC_BASIS else PIC_BASIS
			cineType = 'episode' if str(episode).isdecimal() else 'movie'
			for method in get_Sorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			debug_MS(f"(navigator.listEpisodes[4]) ##### NAME : {name} || IDD : {Mark2} || TARGET : {link} #####")
			debug_MS(f"(navigator.listEpisodes[4]) ##### THUMB : {image} || SEASON : {season} || EPISODE : {episode} || AIRED : {aired} #####")
			FETCH_UNO = create_entries({'Title': name, 'Plot': plot, 'Season': season,'Episode': episode, 'Duration': duration, 'Date': begins, 'Aired': aired,\
				'Genre': 'Unterhaltung / Wissen', 'Studio': studio, 'Mpaa': mpaa, 'Mediatype': cineType, 'Image': image, 'Fanback': fanart, 'Reference': 'Single'})
			addDir({'mode': 'playCODE', 'IDENTiTY': Mark2}, FETCH_UNO, folder=False)
			SEND['videos'].append({'filter': Mark2, 'name': name, 'photo': image, 'plot': plot, 'duration': duration, 'joynEXT': Joyn2, 'joynWAY': Route2, 'youEMBED': youtube})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	else:
		failing(f"(navigator.listEpisodes) ##### Keine COMBI_CAMERAS-List - Kein Eintrag *** {TRANS} *** gefunden #####")
		return dialog.notification(translation(30525), translation(30526).format(TRANS), icon, 10000)
	debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### SENDUNGS_ID : {IDD} ###")
	JOYN_REDIRECT, YOUT_REDIRECT, DEVINE, LICE, STREAM, FINAL_URL = (False for _ in range(6))
	video_id, JOYN_ROUTE = (None for _ in range(2))
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == IDD:
				CLEAR_TITLE = re.sub(r'\[.*?\]', '', elem['name']) if elem.get('name', '') else None
				video_id, PHOTO, PLOT, RUNTIME, JOYN_REDIRECT, JOYN_ROUTE, YOUT_REDIRECT = elem['filter'], elem['photo'], elem['plot'], elem['duration'], elem['joynEXT'], elem['joynWAY'], elem['youEMBED']
				debug_MS(f"(navigator.playCODE[1]) ### WORKFILE-Line : {elem} ###")
	if JOYN_REDIRECT is True and JOYN_ROUTE and video_id:
		CLIENT = f'{{"genre": [], "startTime": 0, "videoId": "{video_id}", "npa": false, "duration": {int(RUNTIME) * 1000}, "brand": ""}}'
		debug_MS("(navigator.playCODE[2]) ***** TAKE - REDIRECTED : "+build_mass('plugin://plugin.video.joyn/', {'mode': 'play_video', 'movie_id': '', 'video_id': video_id, 'stream_type': 'VOD', 'title': CLEAR_TITLE, 'client_data': CLIENT, 'path': JOYN_ROUTE})+" || (Joyn-Redirect) *****")
		STREAM, MIME, FINAL_URL = 'JOYN-TRANSMIT', 'application/vnd.apple.mpegurl', build_mass('plugin://plugin.video.joyn/', {'mode': 'play_video', 'movie_id': '', 'video_id': video_id, 'stream_type': 'VOD', 'title': CLEAR_TITLE, 'client_data': CLIENT, 'path': JOYN_ROUTE})
		# JOYN-TRANSMIT : plugin://plugin.video.joyn/?mode=play_video&movie_id=&video_id=a_plf6fi6v9wq&stream_type=VOD&title=Young+Monaco&client_data=%7B%22genre%22%3A+%5B%5D%2C+%22startTime%22%3A+0%2C+%22videoId%22%3A+%22a_plf6fi6v9wq%22%2C+%22npa%22%3A+false%2C+%22duration%22%3A+2966000%2C+%22brand%22%3A+%22%22%7D&path=%2Fserien%2Fgalileo-stories%2F2024-32-young-monaco
	elif YOUT_REDIRECT is True and video_id:
		debug_MS(f"(navigator.playCODE[2]) ***** TAKE - REDIRECTED : plugin://plugin.video.youtube/play/?video_id={video_id} || (Youtube-Redirect) *****")
		TEST_URL = getUrl(f"https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={video_id}", method='TRACK', timeout=20)
		if TEST_URL.status_code in [200, 201, 202] and re.search(r'''["']provider_url["']:["']https://www.youtube.com/["']''', TEST_URL.text):
			STREAM, MIME, FINAL_URL = 'YOUTUBE-TRANSMIT', 'application/vnd.apple.mpegurl', f"plugin://plugin.video.youtube/play/?video_id={video_id}"
	elif JOYN_REDIRECT is False and YOUT_REDIRECT is False and video_id:
		UAG = f"User-Agent={get_userAgent()}&Referer={BASE_PROSIEBEN}"
		ACCESS_ID = 'x_supernovatvc-de' # Für ProSieben NEU - 24.12.2023
		ENCRYPTION_KEY = 'Ahsh3soxiemusijophoophiodeevujup'
		actual = datetime.now()
		rewind = actual - timedelta(minutes=5)
		expire = actual + timedelta(minutes=5)
		payload = {'content_ids': {''+video_id+'': {}}, 'secure_delivery': True, 'iat': int(actual.timestamp()), 'nbf': int(rewind.timestamp()), 'exp': int(expire.timestamp())}
		jwt_token = jwt_enc_hs256(ACCESS_ID, payload, ENCRYPTION_KEY)
		time.sleep(2)
		req = getUrl(API_PLAYER.format(py3_dec(jwt_token)), method='TRACK', REF=BASE_PROSIEBEN, AUTH=py3_dec(jwt_token))
		if req.status_code in [200, 201, 202]:
			DATA = req.json()
			debug_MS("++++++++++++++++++++++++")
			debug_MS(f"(navigator.playCODE[2]) XXXXX CONTENT-02 : {str(DATA)} XXXXX")
			debug_MS("++++++++++++++++++++++++")
			if DATA is not None and DATA.get('data', '') and DATA['data'].get(video_id, '') and DATA['data'][video_id].get('urls', '') and len(DATA['data'][video_id]['urls']) > 0:
				SHORT = DATA['data'][video_id]
				DEVINE = SHORT['urls']['dash']['widevine']['drm']['licenseAcquisitionUrl'] if SHORT.get('urls', '') and SHORT['urls'].get('dash', '') and SHORT['urls']['dash'].get('widevine', '') and \
					SHORT['urls']['dash']['widevine'].get('drm', '') and SHORT['urls']['dash']['widevine']['drm'].get('licenseAcquisitionUrl', '') else None
				if SHORT.get('is_protected', '') is True and DEVINE:
					STREAM, MIME, FINAL_URL, LICE = 'MPD', 'application/dash+xml', SHORT['urls']['dash']['widevine']['url'], DEVINE
					DRM_TOKEN = SHORT['urls']['dash']['widevine']['drm']['token']
					debug_MS("(navigator.playCODE[3]) ***** TAKE - Inputstream (mpd) - FILE (ProSieben) *****")
				if not FINAL_URL and SHORT.get('is_protected', '') is False and not LICE:
					STREAM, MIME, FINAL_URL = 'HLS', 'application/vnd.apple.mpegurl', SHORT['urls']['hls']['clear']['url']
					debug_MS("(navigator.playCODE[3]) ***** TAKE - Inputstream (hls) - FILE (ProSieben) *****")
	if FINAL_URL and STREAM and ADDON_operate('inputstream.adaptive'):
		LSM = xbmcgui.ListItem(CLEAR_TITLE, path=FINAL_URL)
		LSM.setMimeType(MIME)
		if PLOT in ['', 'None', None]: PLOT = "..."
		PROVIDER = 'Joyn.de' if JOYN_REDIRECT is True else 'Youtube' if YOUT_REDIRECT is True else 'ProSieben'
		if KODI_ov20:
			vinfo = LSM.getVideoInfoTag()
			vinfo.setTitle(CLEAR_TITLE), vinfo.setPlot(PLOT), vinfo.setStudios([PROVIDER])
		else:
			LSM.setInfo('Video', {'Title': CLEAR_TITLE, 'Plot': PLOT, 'Studio': PROVIDER})
		LSM.setArt({'icon': icon, 'thumb': PHOTO, 'poster': PHOTO})
		if STREAM in ['HLS', 'MPD']:
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LSM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
			if KODI_ov20:
				LSM.setProperty('inputstream.adaptive.manifest_headers', f"User-Agent={get_userAgent()}") # On KODI v20 and above
			else:
				LSM.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={get_userAgent()}") # On KODI v19 and below
			if LICE:
				LSM.setProperty('inputstream.adaptive.license_key', LICENSE_URL.format(LICE, DRM_TOKEN, UAG, 'R{SSM}'))
				LSM.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
				debug_MS("(navigator.playVideo[3]) ### LICENSE_URL : "+LICENSE_URL.format(LICE, DRM_TOKEN, UAG, 'R{SSM}')+" ###")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.playCODE) {STREAM}_stream : {FINAL_URL}")
	else:
		if JOYN_REDIRECT is True:
			failing(f"(navigator.playCODE[4]) ERROR - PLAY - JOYN - ERROR ##### TITLE : {CLEAR_TITLE} === URL : {JOYN_ROUTE} #####")
		elif YOUT_REDIRECT is True:
			failing(f"(navigator.playCODE[4]) ERROR - PLAY - YOUTUBE - ERROR ##### TITLE : {CLEAR_TITLE} === URL : plugin://plugin.video.youtube/play/?video_id={video_id} #####")
		else:
			failing(f"(navigator.playCODE[4]) ERROR - PLAY - PROSIEBEN - ERROR ##### URL : {API_PLAYER.format(py3_dec(jwt_token))} === ERROR : {req.text} #####")
		return dialog.notification(translation(30521).format('ID - ', str(video_id)), translation(30527), icon, 8000)

def addDir(params, listitem, folder=True):
	uws = build_mass(HOST_AND_PATH, params)
	listitem.setPath(uws)
	if params.get('mode') == 'playCODE':
		listitem.addContextMenuItems([(translation(30654), 'Action(Queue)')])
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
