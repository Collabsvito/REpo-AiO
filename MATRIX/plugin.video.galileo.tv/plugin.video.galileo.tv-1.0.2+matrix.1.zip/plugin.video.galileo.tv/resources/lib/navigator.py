﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import time
from datetime import datetime, timedelta
from urllib.parse import urlparse, urlencode

from .common import *


def mainMenu():
	debug_MS("(navigator.mainMenu) ------------------------------------------------ START = mainMenu -----------------------------------------------")
	DATA = getUrl('/a-z.json')
	if DATA is not None and DATA.get('pageProps', '') and DATA.get('pageProps', {}).get('categories', ''):
		for item in DATA['pageProps']['categories']: # home, corona, food, natur, gesundheit, abenteuer, life, technik, weltall, interaktiver-montag, specials, bundestagswahl --- Stand vom: 12.11.2022 ---
			slug = (item.get('slug', 'index') or 'index') # für die HOME Seite ist der Slug leer - daher hier 'index'
			name, origSERIE = cleaning(item['name']), cleaning(item['name'])
			plot = (item.get('description', '') or item.get('metaDescription', '') or '')
			image = icon
			if item.get('images', '') and item.get('images', {}).get('desktop', '') and item.get('images', []).get('desktop', {}).get('actual', ''):
				image = item['images']['desktop']['actual']
			addDir(name, image, {'mode': 'listEpisodes', 'url': '/'+slug+'.json', 'first': 'topics', 'extras': slug, 'transmit': origSERIE}, plot, background=False)
			debug_MS("(navigator.mainMenu) ### NAME : {0} || SLUG : {1} || FOTO : {2} ###".format(str(name), slug, image))
	addDir(translation(30601), icon, {'mode': 'listMediathek'})
	if enableADJUSTMENT:
		addDir(translation(30609), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30610), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listMediathek():
	debug_MS("(navigator.listMediathek) ------------------------------------------------ START = listMediathek -----------------------------------------------")
	addDir(translation(30621), icon, {'mode': 'listEpisodes', 'url': '/mediathek/ganze-galileo-folgen.json', 'first': 'resultsState', 'extras': 'ganze-galileo-folgen', 'transmit': 'Alle ganzen Galileo-Folgen'})
	addDir(translation(30622), icon, {'mode': 'listEpisodes', 'url': '/mediathek/alle-video-clips.json', 'first': 'resultsState', 'extras': 'alle-video-clips', 'transmit': 'Alle Video-Clips'})
	addDir(translation(30623), icon, {'mode': 'listEpisodes', 'url': '/mediathek.json', 'first': 'lanes', 'extras': 'clip', 'transmit': 'Neue Video-Clips'})
	addDir(translation(30624), icon, {'mode': 'listEpisodes', 'url': '/mediathek.json', 'first': 'lanes', 'extras': 'themenvideo', 'transmit': 'Digital Exclusives'})
	addDir(translation(30625), icon, {'mode': 'listEpisodes', 'url': '/mediathek.json', 'first': 'lanes', 'extras': 'episode', 'transmit': 'Ganze Galileo-Folgen'})
	addDir(translation(30626), icon, {'mode': 'listEpisodes', 'url': '/mediathek.json', 'first': 'lanes', 'extras': 'topvideos', 'transmit': 'Beliebte Videos'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, PAGE, POS, FIRST, TYPE, SERIE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### URL : {0} ### PAGE : {1} ### POSITION : {2} ### FIRST : {3} ### TYPE : {4} ### SERIE : {5} ###".format(url, str(PAGE), str(POS), FIRST, TYPE, SERIE))
	PAGE, POS = int(PAGE), int(POS)
	COMBI_EPISODE = []
	counter = 0
	DATA_ONE = getUrl(url)
	DATA_TWO = DATA_ONE
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listEpisodes) XXXXX CONTENT : {0} XXXXX".format(str(DATA_ONE)))
	debug_MS("++++++++++++++++++++++++")
	if DATA_ONE is not None and DATA_ONE.get('pageProps', '') and DATA_ONE.get('pageProps', {}).get(FIRST, ''):
		if FIRST == 'topics' and DATA_ONE.get('pageProps', {}).get(FIRST, ''):
			DATA_ONE = DATA_ONE['pageProps']['topics']
		elif FIRST == 'resultsState' and DATA_ONE.get('pageProps', {}).get(FIRST, '') and DATA_ONE.get('pageProps', []).get(FIRST, {}).get('rawResults', ''):
			DATA_ONE = DATA_ONE['pageProps']['resultsState']['rawResults'][0]['hits']
		elif FIRST == 'lanes' and DATA_ONE.get('pageProps', {}).get(FIRST, ''):
			da = DATA_ONE['pageProps']['lanes']
			DATA_ONE = da[0]['data'] if TYPE == 'clip' else da[1]['data'] if TYPE == 'themenvideo' else da[2]['data'] if TYPE == 'episode' else da[3]['data']
		elif FIRST == 'topicContent' and DATA_ONE.get('pageProps', {}).get(FIRST, ''):
			try: DATA_ONE = DATA_ONE['pageProps']['topicContent']['acf']['relatedVideos']['items'] # related content anzeigen
			except: pass
		elements = DATA_ONE if isinstance(DATA_ONE, list) else [DATA_ONE]
		for item in elements:
			related = False
			'''
			Rubriken/Slugs['pageProps']['topics'] == index, corona, food, natur, gesundheit, abenteuer, life, technik, weltall, interaktiver-montag, specials, bundestagswahl ###
			API_COMP/index.json(Startübersicht)['pageProps']['topics'] == id=['id'], broadcast=['date'], link=['link'], likes=['likes'], contentSlug=['slug'], title=['title'], videoSlug=['relatedVideo']['slug'], videoMAIN=['relatedVideo']['clipIds']['main'], photo=['relatedVideo']['videoPoster']['actual'], desc=['description'], duration=['relatedVideo']['duration'], mpaa=['relatedVideo']['fsk'], genre=['topicCategory']('name') ###
			API_COMP/mediathek.json(einzelne DataOrdner)['pageProps']['lanes'][0,1,2,3]['data'] == id=['id'], broadcast=['date'], link=0, likes=0, contentSlug=0, title=['stripped']['title'], videoSlug=['acf']['slug'], videoMAIN=['acf']['clip-ID'], photo=['image'], desc=['stripped']['content'], duration=['acf']['duration'], mpaa=['acf']['fsk'], genre=0 ###
			API_COMP/mediathek/ganze-galileo-folgen.json(Auswahl)['pageProps']['resultsState']['rawResults'][0]['hits'] == id=['post_id'], broadcast=['post_date'], link=0, likes=0, contentSlug=0, title=['post_title'], videoSlug=['video']['main']['slug'], videoMAIN=['video']['main']['clip_id'], photo=['images']['topic-teaser']['url'], desc=['content'], duration=['video']['main']['duration'], mpaa=['video']['main']['fsk'], genre=0 ###
			API_COMP/food/rezept-gruenkohl-quiche-schnell-und-lecker-kitchen-moves.json(RelatedVideos)['pageProps']['topicContent']['acf']['relatedVideos']['items'] == id=['ID'], broadcast=['date'], link=0, likes=0, contentSlug=0, title=['postTitle'], videoSlug=['postSlug'], videoMAIN=['clipID'], photo=['postImgUrl']['actual'], desc=['postContent'], duration=['duration'], mpaa=['fsk'], genre=0 ###
			'''
			Note_1, Note_2, genre = ("" for _ in range(3))
			startTIMES, begins, contentSlug, videoSlug, videoMAIN, duration, mpaa = (None for _ in range(7))
			genreLIST = []
			name, MORE_COLLECT = 'UNBEKANNT', 'DEFAULT'
			SHORT, photo = item, icon
			debug_MS("(navigator.listEpisodes) ##### ELEMENT : {0} #####".format(str(item)))
			episID = (item.get('post_id', '') or item.get('id', '') or item.get('ID', '') or '00') # resultsState=post_id, topics+lanes=id, topicContent=ID
			if str(item.get('date'))[:4].isdigit() and str(item.get('date'))[:4] not in ['0', '1970']: # 2022-10-25 18:45:00 oder 2022-10-25T18:45:00 // FIRST=topics+lanes+topicContent
				broadcast = datetime(*(time.strptime(item['date'][:16].replace('T', ' '), '%Y{0}%m{0}%d %H{1}%M'.format('-', ':'))[0:6])) # 20.12.2021 20:15
				startTIMES = broadcast.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				begins = broadcast.strftime('%d{0}%m{0}%Y').format('.')
			if str(item.get('post_date', '')).isdigit(): # broadcasttimestamp=1666203274 // FIRST=resultsState
				startTIMES = datetime.fromtimestamp(item['post_date']).strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				begins = datetime.fromtimestamp(item['post_date']).strftime('%d{0}%m{0}%Y').format('.')
			link = item['link'] if item.get('link', '') and not 'video/' in item['link'] and item['link'].count('/') > 4 else None # link for related videos // FIRST=topics
			likes = (item.get('likes', None) or None) # FIRST=topics
			if FIRST == 'topics': # FIRST=topics
				if item.get('title', ''): name = cleaning(item['title'])
				else: continue
				if item.get('relatedVideo', ''):
					SHORT = item['relatedVideo']
					videoSlug = (SHORT.get('slug', None) or None)
					if SHORT.get('clipIds', '') and SHORT.get('clipIds', {}).get('main', ''):
						related = True
						videoMAIN = SHORT['clipIds']['main']
					if SHORT.get('videoPoster', '') and SHORT.get('videoPoster', {}).get('actual', ''): # Videofoto
						photo = SHORT['videoPoster']['actual'].replace('-640x360', '')
					#if item.get('topicThumbnails', '') and item.get('topicThumbnails', {}).get('actual', '') and photo == icon: # Themenfoto
						#photo = item['topicThumbnails']['actual'].replace('-500x500', '')
				elif item.get('webLink', '') and 'tags/' in item['webLink']: # gefundene Tags weiterleiten
					contentSlug = item['webLink']
				if item.get('description', ''): # description
					Note_2 = cleaning(item['description'])
				if item.get('topicCategory', '') and isinstance(item['topicCategory'], list): # genres
					genreLIST = [cleaning(one.get('name', [])) for one in item['topicCategory']]
					if genreLIST: genre = ' / '.join(sorted(genreLIST))
			elif item.get('acf', ''): # FIRST=lanes
				if item.get('stripped', '') and item.get('stripped', {}).get('title', ''): name = cleaning(item['stripped']['title'])
				else: continue
				SHORT = item['acf']
				videoSlug = (SHORT.get('slug', None) or None)
				if SHORT.get('clip-ID', ''):
					related = True
					videoMAIN = SHORT['clip-ID']
				if item.get('image', ''):
					photo = item['image']+'/profile:original'
				if item.get('stripped', '') and item.get('stripped', {}).get('content', ''): # description
					Note_2 = cleaning(item['stripped']['content'])
			elif item.get('video', '') and item.get('video', {}).get('main', ''): # FIRST=resultsState
				if item.get('post_title', ''): name = cleaning(item['post_title'])
				else: continue
				SHORT = item['video']['main']
				videoSlug = (item.get('slug', None) or None)
				if SHORT.get('clip_id', ''):
					related = True
					videoMAIN = SHORT['clip_id']
				if item.get('images', '') and item.get('images', {}).get('topic-teaser', '') and item.get('images', []).get('topic-teaser', {}).get('url', ''):
					photo = IMG_cover.format(item['images']['topic-teaser']['url'].replace('-500x500', ''))
				if item.get('content', ''): # description
					Note_2 = cleaning(item['content'])
			elif FIRST == 'topicContent': # FIRST=topicContent
				if item.get('postTitle', ''): name = (item['postTitle'])
				else: continue
				videoSlug = (item.get('postSlug', None) or None)
				if item.get('clipID', ''):
					related = True
					videoMAIN = item['clipID']
				if item.get('postImgUrl', '') and item.get('postImgUrl', {}).get('actual', ''):
					photo = item['postImgUrl']['actual'].replace('-640x360', '')
				if item.get('postContent', ''): # description
					Note_2 = cleaning(item['postContent'])
			duration = int(SHORT['duration']) if str(SHORT.get('duration', '')).isdigit() else None
			if cleaning(str(SHORT.get('fsk'))) not in ['None', 'nicht definiert']:
				mpaa = cleaning(str(SHORT.get('fsk')))
			POS += 1
			if duration and related:
				MORE_COLLECT = '{}.json'.format(link[0:-1].replace('https://www.galileo.tv', API_COMP)) if link else 'DEFAULT' # related content suchen
				uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playVideo', 'url': videoMAIN}))
				folder = False
			elif duration is None and related is False and contentSlug:
				newURL = '{}.json'.format(contentSlug[0:-1].replace('https://www.galileo.tv', ''))
				uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'listEpisodes', 'url': newURL, 'first': 'topics', 'extras': TYPE, 'transmit': name}))
				folder = True
			else: continue
			if startTIMES and likes: Note_1 = translation(30631).format(str(startTIMES), str(likes))
			elif startTIMES and likes is None: Note_1 = translation(30632).format(str(startTIMES))
			plot = Note_1+Note_2
			COMBI_EPISODE.append([POS, uvz, folder, episID, begins, likes, name, photo, plot, genre, duration, mpaa, MORE_COLLECT])
	if COMBI_EPISODE:
		for POS, uvz, folder, episID, begins, likes, name, photo, plot, genre, duration, mpaa, MORE_COLLECT in COMBI_EPISODE:
			if not folder:
				for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			debug_MS("(navigator.listEpisodes) ##### NAME : {0} || IDD : {1} || GENRE : {2} #####".format(name, str(episID), genre))
			debug_MS("(navigator.listEpisodes) ##### SERIE : {0} || DURATION : {1} || IMAGE : {2} #####".format(SERIE, str(duration), photo))
			debug_MS("(navigator.listEpisodes) ##### MORE : {0} || MPAA : {1} || DATE : {2} #####".format(str(MORE_COLLECT), str(mpaa), str(begins)))
			liz = xbmcgui.ListItem(name)
			if plot in ['', 'None', None]: plot = "..."
			if KODI_ov20:
				videoInfoTag = liz.getVideoInfoTag()
				videoInfoTag.setTitle(name)
				videoInfoTag.setTagLine(None)
				videoInfoTag.setPlot(plot)
				if duration: videoInfoTag.setDuration(int(duration))
				if begins: videoInfoTag.setDateAdded(begins)
				if begins: videoInfoTag.setFirstAired(begins)
				videoInfoTag.setGenres([genre])
				videoInfoTag.setStudios(['ProSieben'])
				if likes: videoInfoTag.setVotes(int(likes))
				videoInfoTag.setMpaa(mpaa)
				if not folder: videoInfoTag.setMediaType('movie')
			else:
				info = {}
				info['Title'] = name
				info['Tagline'] = None
				info['Plot'] = plot
				if duration: info['Duration'] = duration
				if begins: info['Date'] = begins
				if begins: info['Aired'] = begins
				info['Genre'] = [genre]
				info['Studio'] = ['ProSieben']
				if likes: info['Votes'] = likes
				info['Mpaa'] = mpaa
				if not folder: info['Mediatype'] = 'movie'
				liz.setInfo(type='Video', infoLabels=info)
			liz.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
			if photo and useThumbAsFanart and photo != icon and not artpic in photo:
				liz.setArt({'fanart': photo})
			if not folder:
				liz.setProperty('IsPlayable', 'true')
				liz.setContentLookup(False)
				entries = []
				entries.append([translation(30654), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, 'mode=AddToQueue')])
				if MORE_COLLECT != 'DEFAULT': # cyan, magenta, springgreen
					entries.append([translation(30655), 'Container.Update({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'listEpisodes', 'url': MORE_COLLECT, 'first': 'topicContent', \
						'extras': 'relatedvideos', 'transmit': 'Passende Videos'}))])
				liz.addContextMenuItems(entries)
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=liz, isFolder=folder)
		try:
			if FIRST == 'resultsState':
				LAST, CODE = DATA_TWO['pageProps']['resultsState']['rawResults'][0]['nbPages'], 'page'
			else:
				LAST, CODE = DATA_TWO['pageProps']['totalPages'], 'seite'
			if LAST and isinstance(LAST, int) and int(LAST) > int(PAGE):
				debug_MS("(navigator.listEpisodes) NUMBERING ### totalRESULTS : {0} ###".format(str(LAST)))
				debug_MS("(navigator.listEpisodes) Now show NextPage ... No.{0} ... ###".format(str(int(PAGE)+1)))
				if int(PAGE) == 1:
					plus_SUFFIX = ('&', '?')[urlparse(url).query == ''] + urlencode({CODE: str(int(PAGE)+1)})
				else:
					url, plus_SUFFIX = url.split(CODE+'=')[0], CODE+'='+str(int(PAGE)+1)
				addDir(translation(30633).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listEpisodes', 'url': url+plus_SUFFIX, 'page': int(PAGE)+1,'position': int(POS), 'first': FIRST, \
					'extras': TYPE, 'transmit': SERIE})
		except: pass
	else:
		debug_MS("(navigator.listEpisodes) ##### Keine COMBI_EPISODE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525), translation(30526).format(SERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(PLID):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	STREAM, FINAL_URL, WALU = (False for _ in range(3))
	ACCESS_ID = 'x_galileotv-de'
	ENCRYPTION_KEY = 'Shae4queijievoyeihaishahkahchahp'
	actual_time = datetime.now()
	not_before = actual_time - timedelta(minutes=5)
	expire = actual_time + timedelta(minutes=5)
	payload = {'content_ids': {'{}'.format(PLID): {}}, 'secure_delivery': True, 'iat': int(actual_time.timestamp()), 'nbf': int(not_before.timestamp()), 'exp': int(expire.timestamp())}
	jwt_token = jwt_enc_hs256(payload, ENCRYPTION_KEY)
	time.sleep(2)
	req = getUrl(API_PLAYER.format(py3_dec(jwt_token)), method='TRACK', REF='https://www.galileo.tv/', AUTH=py3_dec(jwt_token))
	if req.status_code == 200:
		DATA = req.json()
		debug_MS("++++++++++++++++++++++++")
		debug_MS("(navigator.playVideo) XXXXX CONTENT : {0} XXXXX".format(str(DATA)))
		debug_MS("++++++++++++++++++++++++")
		if DATA is not None and DATA.get('data', '') and DATA.get('data', {}).get(PLID, '') and DATA.get('data', {}).get(PLID, {}).get('urls', '') and len(DATA['data'][PLID]['urls']) > 0:
			SHORT = DATA['data'][PLID]
			WILIZ = SHORT['urls']['dash']['widevine']['drm']['licenseAcquisitionUrl'] if SHORT.get('urls', '') and SHORT.get('urls', {}).get('dash', '') and SHORT.get('urls', {}).get('dash', {}).get('widevine', '') \
				and SHORT.get('urls', {}).get('dash', {}).get('widevine', {}).get('drm', '') and SHORT.get('urls', {}).get('dash', {}).get('widevine', {}).get('drm', {}).get('licenseAcquisitionUrl', '') else None
			if SHORT.get('is_protected', '') is True and WILIZ:
				STREAM, MIME, FINAL_URL, WALU = 'MPD', 'application/dash+xml', SHORT['urls']['dash']['widevine']['url'], WILIZ
				drm_TOKEN = SHORT['urls']['dash']['widevine']['drm']['token']
				debug_MS("(navigator.playVideo[2]) no.02 ***** TAKE - Inputstream (mpd) - FILE *****")
			if not FINAL_URL and SHORT.get('is_protected', '') is False and not WALU:
				STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
				MIME, FINAL_URL = 'application/vnd.apple.mpegurl', SHORT['urls']['hls']['clear']['url']
				debug_MS("(navigator.playVideo[2]) no.02 ***** TAKE - Inputstream (hls) and Standard (m3u8) - FILE *****")
	if FINAL_URL and STREAM:
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		LSM.setMimeType(MIME)
		if ADDON_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			LSM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
			if KODI_ov20:
				LSM.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent={0}'.format(get_userAgent()))
			else:
				LSM.setProperty('inputstream.adaptive.stream_headers', 'User-Agent={0}'.format(get_userAgent()))
			if WALU:
				WAKEY = u'{0}?token={1}|User-Agent={2}&Referer=https://www.galileo.tv/&Content-Type=application/x-www-form-urlencoded|{3}|'.format(WALU, drm_TOKEN, get_userAgent(), 'R{SSM}')
				LSM.setProperty('inputstream.adaptive.license_key', WAKEY)
				debug_MS("(navigator.playVideo) LICENSE : {0}".format(str(WAKEY)))
				LSM.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log("(navigator.playVideo) {0}_stream : {1}|User-Agent={2}".format(STREAM, FINAL_URL, get_userAgent()))
	else:
		failing("(navigator.playVideo) ERROR - ERROR - ERROR : ##### url: {0} === error: {1} #####".format(API_PLAYER.format(py3_dec(jwt_token)), req.text))
		return dialog.notification(translation(30521).format('ID - ', PLID), translation(30527), icon, 8000)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, folder=True, background=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot), videoInfoTag.setStudios(['ProSieben'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'ProSieben'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
