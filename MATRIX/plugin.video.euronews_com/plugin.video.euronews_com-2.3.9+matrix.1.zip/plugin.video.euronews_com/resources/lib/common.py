﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import time
from datetime import datetime, timedelta
from calendar import timegm as TGM
import ssl
from urllib.parse import parse_qsl, urlencode, quote_plus, unquote_plus
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from .external import * # cloudscraper, psf_requests, psf_requests.HTTPAdapter


socket.setdefaulttimeout(30)
HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_folder						= xbmcvfs.translatePath(addon.getAddonInfo('path'))
addon_profile					= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
WORKS_FILE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'episode_data.json'))
defaultFanart						= os.path.join(addon_folder, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addon_folder, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addon_folder, 'resources', 'media', '')
SHORTS_WEB						= {0: 'arabic', 1: 'www', 2: 'fr', 3: 'de', 4: 'gr', 5: 'hu', 6: 'it', 7: 'parsi', 8: 'pl', 9: 'pt', 10: 'ru', 11: 'es', 12: 'tr'}[int(addon.getSetting('language'))]
# Spachennummerierung(settings) ~ Arabic=0|English=1|French=2|German=3|Greek=4|Hungarian=5|Italian=6|Persian=7|Polish=8|Portuguese=9|Russian=10|Spanish=11|Turkish=12
#         Webseitenkürzel(euronews) = 0: arabic|1: www|2: fr|3: de|4: gr|5: hu|6: it|7: parsi|8: pl|9: pt|10: ru|11: es|12: tr
SHORTS_DROID					= SHORTS_WEB.replace('www', 'en').replace('arabic', 'ar').replace('parsi', 'pe')
CHANNEL_LIVE					= {0: 'pykpO5kQJ98', 1: 'pykpO5kQJ98', 2: 'NiRIbKwAejk', 3: 'CQ3KsEbsYHs', 4: 'uWIhV9gQClg', 5: 'jAn7L2Kt32U', 6: 'pUcmpyynASM', 7: 'Up6Je4uhBtk', 8: 'fG7PjdiKaBY', 9: 'XuZAl-ZPEcA', 10: 'lwYzwdBiaho', 11: 'O9mOtdZ-nSk', 12: 'CQ3KsEbsYHs'}[int(addon.getSetting('language'))]
PREFER_TUBE						= (True if addon.getSetting('YOUTUBE_LINK') == 'true' else False)
VIDEO_META						= (True if addon.getSetting('video_extradata') == 'true' else False)
useThumbAsFanart			= addon.getSetting('use_fanart') == 'true'
enable_tune						= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_BUILD						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2])
BASE_URL							= f"https://{SHORTS_WEB}.euronews.com"
BASE_DROID						= f"https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/{SHORTS_DROID}"
BASE_EIRIS							= f"https://{SHORTS_DROID}.euronews.com/iris/euronews/v7.3/{SHORTS_DROID}/articles/"
HEAD_ATV							= {'Cache-Control': 'public, max-age=300', 'Accept': 'application/json', 'Content-Type': 'application/json; charset=utf-8'}
HEAD_WEB							= {'Cache-Control': 'public, max-age=300', 'Accept': 'text/html, */*', 'Origin': BASE_URL, 'Referer': f"{BASE_URL}/"}
HEAD_TUBE						= {'Accept': 'text/html, */*', 'Origin': 'https://www.youtube.com', 'Referer': 'https://www.youtube.com/'}

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def trackSeveral(stacks, method='GET', queries='JSON', headers={}, timeout=5, workers=25):
	COMBI_NEW, number, counter, fixation = [], len(stacks), 0, psf_requests.Session()
	fixation.mount('https://', psf_requests.HTTPAdapter(pool_connections=int(number), pool_maxsize=int(number), pool_block=True)) # Pool-Verbindungen und -Grösse auf tatsächlichen Inhalt festlegen, um Fehlermeldungen zu vermeiden
	UNCHECK = ssl.create_default_context()
	UNCHECK.check_hostname = False
	UNCHECK.verify_mode = ssl.CERT_NONE
	def download(pos, link):
		connector = {'browser': 'chrome', 'platform': 'android', 'desktop': False} if queries == 'JSON' else {'browser': 'chrome', 'platform': 'windows', 'mobile': False}
		fixation = cloudscraper.create_scraper(browser=connector, ssl_context=UNCHECK)
		try:
			response = fixation.request(method, link, headers=headers, allow_redirects=True, timeout=timeout)
			response.raise_for_status()
			debug_MS(f"(common.trackSeveral[1]) === POS : {pos} || STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
			return f'{{"Position":{pos},"Demand":"{link}",{response.text[1:-1]}}}' if queries == 'JSON' else [pos, link, response.text]
		except Exception as exc_uno:
			failing(f"(common.trackSeveral[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === URL : {link} === FAILURE : {exc_uno} #####")
			return f'{{"Position":{pos},"Status":"ERROR"}}' if queries == 'JSON' else [pos, link, None]
	with ThreadPoolExecutor(max_workers=workers) as executor:
		picker = [executor.submit(download, single['Count_1'], single['Link_1']) for single in stacks]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for future, section in zip(as_completed(picker), stacks):
			counter += 1
			try:
				COMBI_NEW.append(json.loads(future.result())) if queries == 'JSON' else COMBI_NEW.append(future.result())
			except Exception as exc_due:
				if counter == 1:
					debug_MS("x x x x x x x x x x x x x x x x x x x x x x x")
					dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(exc_due), icon, 12000)
				failing(f"(common.trackSeveral[2]) ERROR - EXEPTION - ERROR ##### POS : {section['Count_1']} === URL : {section['Link_1']} === FAILURE : {exc_due} #####")
				executor.shutdown()
		if COMBI_NEW:
			matching = [flop for flop in COMBI_NEW[:] if flop.get('Status', 'OOKAY') == 'ERROR'] if queries == 'JSON' else [flop for flop in COMBI_NEW[:] if flop[2] is None]
			if len(matching) == number or (queries == 'JSON' and len(matching) > 8) or (queries == 'TEXT' and len(matching) > 3):
				dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 12000)
	return json.dumps(COMBI_NEW, indent=2) if queries == 'JSON' else COMBI_NEW

def trackContent(url, method='GET', queries='JSON', headers={}, redirects=True, data=None, json=None, timeout=30):
	attempts, ANSWER = 0, None
	UNCHECK = ssl.create_default_context()
	UNCHECK.check_hostname = False
	UNCHECK.verify_mode = ssl.CERT_NONE
	while not ANSWER and attempts < 2: # 2 x ping attempts for the LINK request ::: to check the availability of the LINK
		attempts += 1
		connector = {'browser': 'chrome', 'platform': 'android', 'desktop': False} if queries == 'JSON' else {'browser': 'chrome', 'platform': 'windows', 'mobile': False}
		fixation = cloudscraper.create_scraper(browser=connector, ssl_context=UNCHECK)
		try:
			response = fixation.request(method, url, headers=headers, allow_redirects=redirects, timeout=timeout)
			response.raise_for_status()
			ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
			debug_MS(f"(common.trackContent) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
		except Exception as exc: # No JSON object could be decoded
			if response.status_code >= 400 or 'Expecting value:' in str(exc): ANSWER = None
			failing(f"(common.trackContent) ERROR - EXCEPTION - ERROR ##### TRY.no : {attempts} === URL : {url} === FAILURE : {exc} #####")
			if attempts >= 2:
				dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 10000)
				return sys.exit(0)
			time.sleep(2)
	debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
	return ANSWER

def preserve(store, facts=None):
	if facts is not None:
		with open(store, 'w') as topics:
			json.dump(facts, topics, indent=2, sort_keys=True)
	else:
		with open(store, 'r') as topics:
			arrive = json.load(topics)
		return arrive

def cleaning(text, CUSTOMISE=False):
	if text is not None:
		if CUSTOMISE is True: # Remove Emojis and other unwanted Symbols and Text in JSON-Text on EURONEWS
			for ex in (('<script>', 'javstart'), ('</script>', 'javend'), ('<figcaption ', 'capstart'), ('</figcaption>', 'capend'), ('<strong>', 'fatstart'), ('</strong>', 'fatend'), ('<br>', 'breakone'), ('\n', 'breakone'), ('</p><p>', 'breakdouble'),
				(',', 'comcom'), (';', 'semisemi'), (':', 'doubledot'), ('.', 'nomdot'), ('!', 'markmark'), ('?', 'questquest'), ('=', 'equalequal'), ('&', 'andand'), ("'", 'quotone'), ('"', 'quotdouble'), ('-', 'dashdash'), (' | ', 'pipepipe'),
				('~', 'swunswun'), ('*', 'starstar'), ('+', 'crosscross'), ('(', 'brackstart'), (')', 'brackend'), ('//', 'verticvertic'), ('/', 'slashslash'), ('#', 'atrhomb'), ('@', 'atmonkey'), ('§', 'parapara'), ('$', 'dolldoll'), ('%', 'perper')):
				text = text.replace(*ex)
			text = re.sub(r'(javstart.*?javend|capstart.*?capend|\<.*?\>)', '', text) # FIRST: Remove text in Script/Figcaption-Types (e.g.Twitter mentions) // SECOND: Remove text between arrow-signs (Links etc.)
			text = re.sub(r'[^\w]', ' ', text) # Remove anything that's not alphanumeric or underscore
		for nw in (('    ', ' '), ('   ', ' '), ('  ', ' '), ('javstart', ''), ('javend', ''), ('capstart', ''), ('capend', ''), ('fatstart', '[B]'), ('fatend', '[/B]'), ('breakone ', '[CR]'), ('breakone', '[CR]'), ('breakdouble', '[CR][CR]'), ('[CR][CR]', '[CR]'),
			('comcom', ','), ('semisemi', ';'), ('doubledot', ':'), ('nomdot', '.'), ('markmark', '!'), ('questquest', '?'), ('equalequal', '='), ('andand', '&'), ('quotone', "'"), ('quotdouble', '"'), ('dashdash', '-'), ('pipepipe', ' | '),
			('swunswun', '~'), ('starstar', '*'), ('crosscross', '+'), ('brackstart', '('), ('brackend', ')'), ('verticvertic', '|'), ('slashslash', '/'), ('atrhomb', '#'), ('atmonkey', '@'), ('parapara', '§'), ('dolldoll', '$'), ('perper', '%'),
			('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\xc2\xb7', '-'),
			("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''),
			('&#xC4;', 'Ä'), ('&#xE4;', 'ä'), ('&#xD6;', 'Ö'), ('&#xF6;', 'ö'), ('&#xDC;', 'Ü'), ('&#xFC;', 'ü'), ('&#xDF;', 'ß'), ('&#x201E;', '„'), ('&#xB4;', '´'), ('&#x2013;', '-'), ('&#xA0;', ' '),
			('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
			('&agrave;', 'à'), ('&Agrave;', 'À'), ('&aacute;', 'á'), ('&Aacute;', 'Á'), ('&acirc;', 'â'), ('&Acirc;', 'Â'), ('&egrave;', 'è'), ('&Egrave;', 'È'), ('&eacute;', 'é'), ('&Eacute;', 'É'), ('&ecirc;', 'ê'), ('&Ecirc;', 'Ê'),
			('&igrave;', 'ì'), ('&Igrave;', 'Ì'), ('&iacute;', 'í'), ('&Iacute;', 'Í'), ('&icirc;', 'î'), ('&Icirc;', 'Î'), ('&ograve;', 'ò'), ('&Ograve;', 'Ò'), ('&oacute;', 'ó'), ('&Oacute;', 'Ó'), ('&ocirc;', 'ô'), ('&Ocirc;', 'Ô'),
			('&ugrave;', 'ù'), ('&Ugrave;', 'Ù'), ('&uacute;', 'ú'), ('&Uacute;', 'Ú'), ('&ucirc;', 'û'), ('&Ucirc;', 'Û'), ('&yacute;', 'ý'), ('&Yacute;', 'Ý'),
			('&atilde;', 'ã'), ('&Atilde;', 'Ã'), ('&ntilde;', 'ñ'), ('&Ntilde;', 'Ñ'), ('&otilde;', 'õ'), ('&Otilde;', 'Õ'), ('&Scaron;', 'Š'), ('&scaron;', 'š'), ('&ccedil;', 'ç'), ('&Ccedil;', 'Ç'),
			('&alpha;', 'a'), ('&Alpha;', 'A'), ('&aring;', 'å'), ('&Aring;', 'Å'), ('&aelig;', 'æ'), ('&AElig;', 'Æ'), ('&epsilon;', 'e'), ('&Epsilon;', 'Ε'), ('&eth;', 'ð'), ('&ETH;', 'Ð'), ('&gamma;', 'g'), ('&Gamma;', 'G'),
			('&oslash;', 'ø'), ('&Oslash;', 'Ø'), ('&theta;', 'θ'), ('&thorn;', 'þ'), ('&THORN;', 'Þ'), ('&bull;', '•'), ('&iexcl;', '¡'), ('&iquest;', '¿'), ('&copy;', '(c)'), ('\t', ''), ('ㅤ', ''),
			("&rsquo;", "’"), ("&lsquo;", "‘"), ("&sbquo;", "’"), ('&rdquo;', '”'), ('&ldquo;', '“'), ('&bdquo;', '”'), ('&rsaquo;', '›'), ('lsaquo;', '‹'), ('&raquo;', '»'), ('&laquo;', '«'),
			('\\xC4', 'Ä'), ('\\xE4', 'ä'), ('\\xD6', 'Ö'), ('\\xF6', 'ö'), ('\\xDC', 'Ü'), ('\\xFC', 'ü'), ('\\xDF', 'ß'), ('\\x201E', '„'), ('\\x28', '('), ('\\x29', ')'), ('\\x2F', '/'), ('\\x2D', '-'), ('\\x20', ' '), ('\\x3A', ':'), ('\\"', '"')):
			text = text.replace(*nw)
		text = text.strip()
	return text

def create_entries(metadata, SIGNS=True):
	listitem = xbmcgui.ListItem(metadata['Title'])
	vinfo = listitem.getVideoInfoTag() if KODI_BUILD >= 20 else {}
	if KODI_BUILD >= 20: vinfo.setTitle(metadata['Title'])
	else: vinfo['Title'] = metadata['Title']
	if metadata.get('Tagline', ''):
		if KODI_BUILD >= 20: vinfo.setTagLine(metadata['Tagline'])
		else: vinfo['Tagline'] = metadata['Tagline']
	description = metadata['Plot'] if metadata.get('Plot') not in ['', 'None', None] else ' '
	if KODI_BUILD >= 20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if str(metadata.get('Duration')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setDuration(int(metadata['Duration']))
		else: vinfo['Duration'] = metadata['Duration']
	if metadata.get('Date', ''):
		if KODI_BUILD >= 20: listitem.setDateTime(metadata['Date'])
		else: vinfo['Date'] = metadata['Date']
	if metadata.get('Aired', ''):
		if KODI_BUILD >= 20: vinfo.setFirstAired(metadata['Aired'])
		else: vinfo['Aired'] = metadata['Aired']
	if str(metadata.get('Aired'))[6:10].isdecimal():
		if KODI_BUILD >= 20: vinfo.setYear(int(metadata['Aired'][6:10]))
		else: vinfo['Year'] = metadata['Aired'][6:10]
	if metadata.get('Genre', ''):
		if KODI_BUILD >= 20: vinfo.setGenres([metadata['Genre']])
		else: vinfo['Genre'] = metadata['Genre']
	if KODI_BUILD >= 20: vinfo.setStudios(['euronews'])
	else: vinfo['Studio'] = 'euronews'
	if metadata.get('Mediatype', ''):
		if KODI_BUILD >= 20: vinfo.setMediaType(metadata['Mediatype'])
		else: vinfo['Mediatype'] = metadata['Mediatype']
	picture = metadata.get('Image', icon)
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'fanart': defaultFanart})
	if useThumbAsFanart and not artpic in picture and SIGNS is True:
		listitem.setArt({'fanart': picture})
	if metadata.get('Reference') == 'Single':
		listitem.setProperty('IsPlayable', 'true')
	if KODI_BUILD < 20: listitem.setInfo('Video', vinfo)
	return listitem
