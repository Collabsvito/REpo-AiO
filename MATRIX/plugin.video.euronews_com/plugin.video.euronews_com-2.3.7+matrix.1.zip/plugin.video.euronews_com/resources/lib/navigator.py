﻿# -*- coding: utf-8 -*-

from .common import *


def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	addDir({'mode': 'listVideos', 'slug': 'timeline', 'name': 'Timeline'}, create_entries({'Title': translation(30605)}))
	FOUND, UNWANTED = 0, ['livingit', 'joboffers', '/paidpost', 'partner', 'service', '/tag', '/video']
	DATA_ONE = getContent(f"{BASE_URL}/video", queries='TEXT', TYPE='text/html; charset=utf-8', ORG=BASE_URL, REF=f"{BASE_URL}/")
	RESULTS = re.findall(r'''<ul class=["']c-navigation-bar__wrappable-list(.*?)<div class=["']o-site-hr__second-level__dropdown__container''', DATA_ONE, re.S)
	for chtml in RESULTS:
		part = chtml.split('id="adb-header-mainnav')
		for i in range(1, len(part), 1):
			entry = part[i] # <a class="c-navigation-bar__link" href="/my-europe" aria-label="Read more about Europa">Europa</a>
			articles = re.compile(r'''class=["']c-navigation-bar__link["'] href=["']([^"']*)["'] aria-label=[^>]*>(.*?)</a>''', re.S).findall(entry)
			for link, name in articles:
				name, FOUND = cleaning(name.replace('\n', '')), FOUND.__add__(1)
				if link and (any(rs in link.lower() for rs in UNWANTED) or FOUND == 1): continue
				debug_MS(f"(navigator.mainMenu[1]) ##### COUNTER : {FOUND} || NAME : {name} || LINK : {link} #####")
				addDir({'mode': 'SubTopics', 'slug': link, 'synopsis': f"{entry}</level></stop>", 'name': name}, create_entries({'Title': translation(30606).format(name)}))
	addDir({'mode': 'listPrograms'}, create_entries({'Title': translation(30607)}))
	addDir({'mode': 'playLIVE'}, create_entries({'Title': translation(30608), 'Image': f"{artpic}livestream.png"}), False)
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30609), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SubTopics(SLUG, COMPACT, NAME):
	debug_MS("(navigator.SubTopics) -------------------------------------------------- START = SubTopics --------------------------------------------------")
	debug_MS(f"(navigator.SubTopics) ### NAME = {NAME} ###\n### >>> COMPACT_LIST = {COMPACT}\n<<< COMPACT_LIST ###\n### SLUG = {SLUG} ###")
	debug_MS("---------------------------------------------")
	FOUND, UNWANTED, UNIKAT = 0, ['livingit', 'joboffers', '/paidpost', 'partner', 'service', '/tag', '/video'], set()
	DATA_ONE = re.findall(r'''<div class=["']c-navigation-bar__subitem (?:c-links-list|c-featured-nav)[^>]*>(.*?)</ul>\s*</div>''', COMPACT, re.S)
	for chtml in DATA_ONE:
		heading = re.compile(r'''<div class=["']c-navigation-bar__subitem__title(?: c-featured-nav__title)?["']>([^<]*)<''', re.S).findall(chtml)
		if SLUG and heading: # HEADLINE === <div class="c-navigation-bar__subitem__title">Programme</div>
			addDir({'mode': 'blankFUNC'}, create_entries({'Title': f"[B][COLOR lime]≡ ≡ ≡ {heading[0]} ≡ ≡ ≡[/COLOR][/B]"}), False)
			debug_MS(f"(navigator.SubTopics[1]) >>>>> MAIN_CATEGORY : {heading[0]} >>>>>")
		PARTS_UNO = re.compile(r'''<a href=["']([^"']*)["'] class=["']c-links-list__link["'] aria-label=[^>]*>(.*?)</a>''', re.S).findall(chtml)
		PARTS_DUE = re.compile(r'''<a class=["']c-featured-nav__item__link["'] href=["']([^"']*)["'] aria-label=.+?class=["']c-featured-nav__item__title[^>]*>(.*?)</p>''', re.S).findall(chtml)
		categories = PARTS_UNO if PARTS_UNO else PARTS_DUE # <a href="/my-europe/europa-news" class="c-links-list__link" aria-label="Read more about Europa News">Europa News</a>
		for link, name in categories: # <a class="c-featured-nav__item__link" href="https://de.euronews.com/programme/water-matters" aria-label=...<p class="c-featured-nav__item__title">Water Matters</p>
			if link not in UNIKAT and not any(ts in link.lower() for ts in UNWANTED):
				UNIKAT.add(link)
				name, piece, FOUND = cleaning(name.replace('\n', '')), 'THEMES' if link.count('/') == 2 else 'PROGRAMS', FOUND.__add__(1)
				target = link if link.startswith('http') else f"https:{link}" if link.startswith('//') else f"{BASE_URL}{link}"
				addDir({'mode': 'listVideos', 'slug': target, 'name': name, 'piece': piece}, create_entries({'Title': name, 'Genre': name}))
				debug_MS(f"(navigator.SubTopics[2]) ##### COUNTER : {FOUND} || NAME : {name} || CATEGORY : {piece} || LINK : {target} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPrograms():
	debug_MS("(navigator.listPrograms) ------------------------------------------------ START = listPrograms -----------------------------------------------")
	FOUND, DATA_ONE = 0, getContent(f"{BASE_URL}/{PROGRAMMES}", queries='TEXT', TYPE='text/html; charset=utf-8', ORG=BASE_URL, REF=f"{BASE_URL}/")
	RESULT_ONE = re.compile(r'''<main class=["']o-site-main["'] id=["']enw-main-content["']>\s*<div data-content=["'](.*?)\]\}["'] data-verticals=["']''', re.S).findall(DATA_ONE)[0].replace('&quot;', '"').replace('\/', '/')+']}'
	addDir({'mode': 'listVideos', 'slug': 'FASTRUN@@homevideo', 'name': 'Homevideo', 'piece': 'VIDEOS'}, create_entries({'Title': translation(30610), 'Genre': 'Homevideo'}))
	character = json.loads(RESULT_ONE) # ▲ AR+EN+GR+PE+PL+RU=programs, FR=programmes, DE=programme, HU=musorok, IT=programmi, PT+ES=programas, TR=programlar ▲
	for key, value in character.items():
		for article in value:
			name, piece = cleaning(article['data']['title']), 'PROGRAMS'
			target, teaser = article.get('data', {}).get('id', None), (cleaning(article.get('data', {}).get('description', '')) or '')
			thumb = re.sub(r'programs/{{w}}x{{h}}_', 'programs/programs-posters/500x660_poster-', article['data']['images'][0]['url']) if article.get('data', '') and article['data'].get('images', '') and article['data'].get('images', {})[0].get('url', '') else None
			if thumb and 'from-the-usa' in thumb: thumb = f"{artpic}from-the-usa.png"
			if target is None or any(vs in target for vs in ['eurasia-', '-detectives']): continue # https://static.euronews.com/articles/programs/{{w}}x{{h}}_climate-now.jpg
			FOUND += 1 # https://static.euronews.com/articles/programs/programs-posters/500x660_poster-climate-now.jpg // https://static.euronews.com/articles/programs/programs-bg/632x512_bg-climate-now.jpg
			addDir({'mode': 'listVideos', 'slug': f"FASTRUN@@{target}", 'name': name, 'piece': piece}, create_entries({'Title': name, 'Plot': teaser, 'Genre': name, 'Image': thumb}, False))
			debug_MS(f"(navigator.listPrograms[1]) ##### COUNTER : {FOUND} || NAME : {name} || CATEGORY : {piece} || SLUG : {target} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(SLUG, NAME, PIECE):
	debug_MS("(navigator.listVideos) ------------------------------------------------ START = listVideos -----------------------------------------------")
	debug_MS(f"(navigator.listVideos) ### NAME = {NAME} ### CATEGORY = {PIECE} ### LINK/SLUG = {SLUG} ###")
	(COMBI_FIRST, COMBI_LINKS, COMBI_PAGES, COMBI_PRECIS, COMBI_SECOND, SENDING), PAGE_NUMBER, FOUND, NEXT_PAGE, UNIKAT = ([] for _ in range(6)), 1, 0, None, set()
	if NAME == 'Timeline':
		while PAGE_NUMBER > 0:
			DATA_ONE = getContent(f"{BASE_DROID}/pages/{SLUG}", MOBI=True) if PAGE_NUMBER == 1 else getContent(NEXT_PAGE, MOBI=True)
			if DATA_ONE is not None and DATA_ONE.get('pageContent', '') and len(DATA_ONE['pageContent']) > 0:
				for item in DATA_ONE.get('pageContent', []):
					if item.get('type', '') == 'justin' and item.get('content', '') and len(item['content']) > 0:
						for article in item.get('content', []):
							debug_MS(f"(navigator.listVideos[1]) xxxxx ARTICLE-01 : {article} xxxxx")
							title = cleaning(article['title'])
							ident = str(article['id']).replace('article-', '').replace('header-', '').strip() if article.get('id', '') else None
							thumb = re.sub(r'/{{w}}x{{h}}', '/1280x720', article['image']['url']) if article.get('image', '') and article['image'].get('url', '') else None
							transfer, playable = f"{BASE_EIRIS}{ident}?device=androidPhone" if ident else None, article.get('showVideo', False) # https://www.euronews.com/iris/euronews/v7.3/de/articles/2812488?device=androidPhone  // NEW at 03.07.25
							if str(ident).isdecimal() and ident not in UNIKAT and transfer and playable is True:
								FOUND += 1
								UNIKAT.add(ident)
								COMBI_FIRST.append([int(FOUND), ident, transfer, playable, title, thumb])
								COMBI_LINKS.append([int(FOUND), transfer]) # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/article?id=2812488 // OLD before
			if DATA_ONE is not None and DATA_ONE.get('pagination', '') and DATA_ONE['pagination'].get('next', '') and \
				DATA_ONE['pagination']['next'].get('url', '') and DATA_ONE['pagination']['next']['url'].startswith('/pages/timeline') and int(PAGE_NUMBER) <= 3: # Maximum of total 4 Pages
				debug_MS("---------------------------------------------")
				PAGE_NUMBER, NEXT_PAGE = PAGE_NUMBER.__add__(1), f"{BASE_DROID}{DATA_ONE['pagination']['next']['url']}"
				debug_MS(f"(navigator.listVideos[2]) PAGES ### NOW GET NEXTPAGE : {NEXT_PAGE} ###")
			else: break
	else:
		if SLUG.startswith('FASTRUN'):
			MARKS, SIGN_LINK = '&' if PIECE == 'PROGRAMS' else '?', f"programvideolanding?programs={SLUG.split('@@')[1]}" if PIECE == 'PROGRAMS' else SLUG.split('@@')[1]
		else:
			MARKS, DATA_ONE = '&', getContent(SLUG, queries='TEXT', TYPE='text/html; charset=utf-8', ORG=BASE_URL, REF=f"{BASE_URL}/")
			PARTS_UNO = re.compile(r'''["']entities["']:\{["']theme["']:\{["']id["']:["']([^"']*)["'],["']urlSafeValue["']''', re.S).findall(DATA_ONE) # "entities":{"theme":{"id":"europe-news","urlSafeValue"
			PARTS_DUE = re.compile(r'''["']entities["']:\{["']program["']:\{["']id["']:["']([^"']*)["'],["']urlSafeValue["']''', re.S).findall(DATA_ONE) # "entities":{"program":{"id":"europeans-stories","urlSafeValue"
			PARTS_TRE = re.compile(r'''<link rel=["']alternate["'] hreflang=["']en["'] href=["']([^"']*)["']>''', re.S).findall(DATA_ONE) # <link rel="alternate" hreflang="en" href="https://www.euronews.com/nocomment">
			SIGN_LINK = f"theme?id={PARTS_UNO[0]}" if PARTS_UNO else f"programvideolanding?programs={PARTS_DUE[0]}" if PARTS_DUE else f"theme?id={PARTS_TRE[0].split('/')[-1]}" if \
				PARTS_TRE and PIECE == 'THEMES' else f"programvideolanding?programs={PARTS_TRE[0].split('/')[-1]}" if PARTS_TRE and PIECE == 'PROGRAMS' else None
		if SIGN_LINK: # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/programvideolanding?programs=europeans-stories&slide=1 // Request for Programs
			HIGHEST = 11 if 'theme?id=' in SIGN_LINK and not any(ws in SIGN_LINK for ws in ['markets', 'series', 'sport']) else 5 # Maximum of total 10 Pages for Themes and maximum of total 4 Pages for Program-Videos
			for ii in range(1, HIGHEST, 1): # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/theme?id=europe-news&slide=1 // Request for Themes
				PAGE_LINK = f"{BASE_DROID}/pages/{SIGN_LINK}{MARKS}slide={str(ii)}"
				debug_MS(f"(navigator.listVideos[1]) OVERVIEW-PAGES XXX POS : {str(ii)} || LINK : {PAGE_LINK} XXX")
				COMBI_PAGES.append([int(ii), PAGE_LINK])
			debug_MS("---------------------------------------------")
			if COMBI_PAGES:
				COMBI_PRECIS = getMultiData(COMBI_PAGES)
				if COMBI_PRECIS:
					DATA_TWO = json.loads(COMBI_PRECIS)
					debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
					for contents in DATA_TWO:
						if contents is not None and contents.get('pageContent', '') and len(contents['pageContent']) > 0:
							for item in contents.get('pageContent', []):
								if item.get('type', '') in ['articleslist', 'sliders'] and item.get('content', '') and len(item['content']) > 0:
									for article in item.get('content', []): # THEMES and PROGRAMS = 'articleslist' // VIDEOS = 'sliders'
										debug_MS(f"(navigator.listVideos[2]) xxxxx ARTICLE-02 : {article} xxxxx")
										title = cleaning(article['title'])
										ident = str(article['id']).replace('article-', '').replace('header-', '').strip() if article.get('id', '') else None
										thumb = re.sub(r'/{{w}}x{{h}}', '/1280x720', article['image']['url']) if article.get('image', '') and article['image'].get('url', '') else None
										transfer, playable = f"{BASE_EIRIS}{ident}?device=androidPhone" if ident else None, article.get('showVideo', False) # https://www.euronews.com/iris/euronews/v7.3/de/articles/2812488?device=androidPhone  // NEW at 03.07.25
										if str(ident).isdecimal() and ident not in UNIKAT and transfer and playable is True:
											FOUND += 1
											UNIKAT.add(ident)
											COMBI_FIRST.append([int(FOUND), ident, transfer, playable, title, thumb])
											COMBI_LINKS.append([int(FOUND), transfer]) # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/article?id=2812488 // OLD before
		else:
			failing(f"(navigator.listVideos) ERROR - EXCEPTION - ERROR ##### NAME : {NAME} === CATEGORY : {PIECE} === LINK : {SLUG} #####")
			return dialog.notification(translation(30521).format('URL'), translation(30525), icon, 15000)
	if COMBI_LINKS:
		COMBI_SECOND = listCompletion(COMBI_LINKS)
	if COMBI_FIRST and COMBI_SECOND:
		RESULTS = [ae + be for ae in COMBI_FIRST for be in COMBI_SECOND if ae[1] == be[0]] # Merge List1 and List2 - if the ID matches !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listVideos[4]) XXXXX RESULTS-04 : {RESULTS} XXXXX")
		for xev in sorted(RESULTS, key=lambda soa: soa[10], reverse=True): # 0-5 = List1 || 6-18 = List2 (sorted by date in descending order)
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listVideos[4]) ### Anzahl = {len(xev)} || Eintrag : {xev} ###")
			EpisID, Link, Show, Name, Photo1 = xev[1], xev[2], xev[3], xev[4], xev[5]
			MarkID, Tagline, Desc1, Desc2, Sorting, Note, Begins, Aired, Genre, Timing, Photo2, Enlink, Youid = xev[6], xev[7], xev[8], xev[9], xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18]
			PREFIX = translation(30611).format(Note) if Note else ""
			PLOT = PREFIX+Desc2 if len(Desc2) > len(Desc1) else PREFIX+Desc1
			THUMB = Photo2 if Photo2 else Photo1
			debug_MS(f"(navigator.listVideos[4]) ##### TITLE : {Name} || IDD : {EpisID} || THUMB : {THUMB} #####")
			debug_MS(f"(navigator.listVideos[4]) ##### YOUTUBE : {Youid} || EURO_VIDEO : {Enlink} || DATE : {Begins} #####")
			FETCH_UNO = create_entries({'Title': Name, 'Tagline': Tagline, 'Plot': PLOT, 'Duration': Timing, 'Date': Begins, \
				'Aired': Aired, 'Genre': Genre, 'Mediatype': 'movie', 'Image': THUMB, 'Reference': 'Single'})
			addDir({'mode': 'playCODE', 'IDENTiTY': EpisID}, FETCH_UNO, False)
			SENDING.append({'filtrate': EpisID, 'name': Name, 'directLINK': Enlink, 'youtubeID': Youid})
		preserve(WORKS_FILE, SENDING)
	else:
		debug_MS(f"(navigator.listVideos) ##### NO VIDEO-LIST - NO ENTRY FOR >{NAME}< FOUND #####")
		return dialog.notification(translation(30526).format('Videos'), translation(30527).format(NAME), icon, 10000)
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listCompletion(MURLS):
	debug_MS("(navigator.listCompletion) -------------------------------------------------- START = listCompletion --------------------------------------------------")
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		DATA_RIDER = json.loads(COMBI_DETAILS)
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.llistCompletion[3]) XXXXX CONTENT-03 : {DATA_RIDER} XXXXX")
		for elem in DATA_RIDER:
			if elem is not None and elem.get('pageContent', '') and elem.get('pageContent', {})[0].get('content', ''):
				(DESC_1, DESC_2), SORT_2, (TAGS_2, NOTE_2, BEGIN_2, AIRED_2, TIME_2, ENVID_2, YTIDD_2) = ("" for _ in range(2)), '2020-01-01T00:01', (None for _ in range(7))
				debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
				debug_MS(f"(navigator.listCompletion[3]) xxxxx POSITION : {elem.get('Position', 0)} || ELEMENT-03 : {elem['pageContent'][0]['content'][0]} xxxxx")
				SHORT = elem['pageContent'][0]['content'][0]
				ATIDD_2 = str(SHORT['id']).replace('article-', '').replace('header-', '').strip() if SHORT.get('id', '') else None
				DESC_1 = cleaning(SHORT.get('summary', ''), True)
				THUMB_2 = re.sub(r'/{{w}}x{{h}}', '/1280x720', SHORT['image']['url']) if SHORT.get('image', '') and SHORT['image'].get('url', '') else None
				BODIES = next(filter(lambda aco: aco.get('type', '') == 'article-body' and aco.get('content', []), elem['pageContent']), None)
				if VIDEO_META is True and BODIES and BODIES.get('content', {})[0].get('text', ''):
					STYLE = re.compile(r'</style></head>.+?<h[2/3]>(.*?)</h[2/3]>', re.S).findall(BODIES['content'][0]['text'])
					TAGS_2 = cleaning(re.sub(r'\<.*?\>', ' ', STYLE[0])) if STYLE else None
					TAGS_2 = f"{TAGS_2[:125]}..." if TAGS_2 and len(TAGS_2) > 125 else TAGS_2
					STORY = re.findall(r'<p[^>]*>(.*?)</p>', BODIES['content'][0]['text'], re.S)
					TEASER = 'breakone'.join([sto for sto in STORY if sto is not None]) if STORY and len(STORY[0]) > 10 else None
					DESC_2 = cleaning(re.sub(r'(>Related\<.*?</li></ul></div|View this post.*?www.instagram.com.*?</a>breakone)', 'breakone', TEASER), True) if TEASER else "" # Delete Related Text and Instagram-Posts
				CHIPS = next(filter(lambda cps: cps.get('type', '') == 'chipslist' and cps.get('content', []), elem['pageContent']), None)
				SPECS = [cleaning(og.get('title', '')) for og in CHIPS.get('content', [])] if CHIPS else []
				GENRE_2 = ' / '.join(sorted(SPECS[:2])) if SPECS else None
				if SHORT.get('video', ''):
					STARTING = elem['tracking']['insider']['product']['custom']['article_publication_date'] if elem.get('tracking', '') and elem['tracking'].get('insider', '') and elem['tracking']['insider'].get('product', '') and \
						elem['tracking']['insider']['product'].get('custom', '') and str(elem['tracking']['insider']['product']['custom'].get('article_publication_date')).isdecimal() else SHORT['dateUts'] if str(SHORT.get('dateUts')).isdecimal() else None
					if STARTING:
						CIPHER = datetime(1970,1,1) + timedelta(seconds=TGM(time.localtime(STARTING)))
						SORT_2 = CIPHER.strftime('%Y-%m-%dT%H:%M')
						NOTE_2 = CIPHER.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
						BEGIN_2 = CIPHER.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else CIPHER.strftime('%d.%m.%Y') # 2025-07-03T12:30:00 = NEWFORMAT // 03.07.2025 = OLDFORMAT
						AIRED_2 = CIPHER.strftime('%d.%m.%Y').format('.') # FirstAired
					if elem.get('tracking', '') and elem['tracking'].get('adobe', '') and elem['tracking']['adobe'].get('customParams', ''): # Duration is displayed in Seconds
						TIME_2 = next((tac.get('value') for tac in elem['tracking']['adobe'].get('customParams', []) if 'videoduration' in tac.get('key', '') and str(tac.get('value')).isdecimal()), None)
					ENVID_2 = SHORT['video'].get('url', None)
					YTIDD_2 = SHORT['video'].get('id', None) if SHORT['video'].get('type', '') == 'pfp' else None # 'pfp' Type is for YOUTUBE
					if SHORT['video'].get('videoFallback', ''):
						if ENVID_2 is None: ENVID_2 = SHORT['video']['videoFallback'].get('url', None)
						if YTIDD_2 is None and SHORT['video']['videoFallback'].get('type', '') == 'pfp': YTIDD_2 = SHORT['video']['videoFallback'].get('id', None) # 'pfp' Type is for YOUTUBE
					COMBI_THIRD.append([ATIDD_2, TAGS_2, DESC_1, DESC_2, SORT_2, NOTE_2, BEGIN_2, AIRED_2, GENRE_2, TIME_2, THUMB_2, ENVID_2, YTIDD_2])
	return COMBI_THIRD

def YouGetVideo(CODE):
	END_URL, MARK = (None for _ in range(2))
	TEST_URL = getContent(f"https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={CODE}", queries='TRACK', ORG='https://www.youtube.com', REF='https://www.youtube.com/', timeout=15)
	if TEST_URL.status_code in [200, 201, 202] and re.search(r'''["']provider_url["']:["']https://www.youtube.com/["']''', TEST_URL.text):
		END_URL, MARK = f"plugin://plugin.video.youtube/play/?video_id={CODE}", 'YOUTUBE'
	return (END_URL, MARK)

def playLIVE():
	debug_MS("(navigator.playLIVE) -------------------------------------------------- START = playLIVE --------------------------------------------------")
	LIVE_URL, STREAM, EURO_SIGN, YOUT_SIGN, YOUT_CIPHER = (False for _ in range(5))
	CHECK_ONE = getContent(f"{BASE_DROID.replace('/tr', '/de')}/livestream/{SHORTS_DROID.replace('tr', 'de')}", queries='TRACK', MOBI=True)
	if CHECK_ONE.status_code in [200, 201, 202]: # Available Languages: en, fr, de, gr, hu, it, pe, pl, pt, ru, es / Arabic in English - Turkish in german
		ORIG_ONE = re.compile(r'''["']primary["']:["']([^"']*)["']''', re.S).findall(CHECK_ONE.text)
		ORIG_TWO = re.compile(r'''["']backup["']:["']([^"']*)["']''', re.S).findall(CHECK_ONE.text)
		EURO_SIGN = ORIG_ONE[0] if ORIG_ONE else ORIG_TWO[0] if ORIG_TWO else False
		if EURO_SIGN:
			debug_MS(f"(navigator.playLIVE[1]) ***** EURONEWS-DIRECT-STREAM FOUND : {EURO_SIGN} *****")
			LIVE_URL, STREAM = EURO_SIGN, 'DIRECT'
		else: log("(navigator.playLIVE[1]) XXXXX !!! EURONEWS-DIRECT-STREAM NOT FOUND - ACTION NOT SUCCESSFUL - SKIP !!! XXXXX")
	if not EURO_SIGN: # Available Languages: en, fr, de, el, hu, it, fa, pl, pt, ru, es / Arabic in English - Turkish in german
		CHECK_TWO = getContent(f"https://www.euronews.com/api/live/data?locale={SHORTS_DROID.replace('gr', 'el').replace('pe', 'fa').replace('tr', 'de')}", queries='TRACK', ORG=BASE_URL, REF=f"{BASE_URL}/")
		if CHECK_TWO.status_code in [200, 201, 202]: # https://www.euronews.com/api/live/data?locale=en
			NUMERALS = re.compile(r'''["']videoId["']:["']([^"']*)["']''', re.S).findall(CHECK_TWO.text)
			YOUT_SIGN = NUMERALS[0] if NUMERALS else False
			debug_MS(f"(navigator.playLIVE[2]) ***** CHECKED YOUTUBE - ID IN CONTEXT : {YOUT_SIGN} *****")
		YOUT_CIPHER = YOUT_SIGN if YOUT_SIGN else CHANNEL_LIVE if CHANNEL_LIVE != '00' else False
		if YOUT_CIPHER:
			debug_MS(f"(navigator.playLIVE[3]) ***** TESTING - REDIRECTED : https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={YOUT_CIPHER} || (Youtube-Redirect-Test) *****")
			LIVE_URL, STREAM = YouGetVideo(YOUT_CIPHER)
		else: log("(navigator.playLIVE[3]) XXXXX !!! YOUTUBE - ID NOT FOUND - ACTION NOT SUCCESSFUL - SKIP !!! XXXXX")
	if LIVE_URL and STREAM in ['DIRECT', 'YOUTUBE']:
		debug_MS(f"(navigator.playLIVE) ### LIVE_URL : {LIVE_URL} ###")
		LTM = xbmcgui.ListItem(translation(30612).format(SHORTS_DROID.upper()), path=LIVE_URL)
		if STREAM == 'DIRECT':
			LTM.setArt({'icon': icon, 'thumb': f"{artpic}livestream.png", 'poster': f"{artpic}livestream.png"})
			MIME = 'video/mp4' if LIVE_URL.endswith('.mp4') else 'application/vnd.apple.mpegurl'
			LTM.setMimeType(MIME)
			if xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)') and MIME == 'application/vnd.apple.mpegurl':
				IA_NAME = 'inputstream.ffmpegdirect'
				LTM.setContentLookup(False), LTM.setProperty('inputstream', IA_NAME)
				LTM.setProperty('Seekable', 'false'), LTM.setProperty('SeekEnabled', 'false')
				LTM.setProperty(f'{IA_NAME}.open_mode', 'ffmpeg')
				LTM.setProperty(f'{IA_NAME}.manifest_type', 'hls')
				LTM.setProperty(f'{IA_NAME}.is_realtime_stream', 'false')
				LTM.setProperty('http-reconnect', 'true')
		xbmc.Player().play(item=LIVE_URL, listitem=LTM)
	else:
		failing("(navigator.playLIVE) ##### PLAYBACK OF THE >LIVE STREAM< NOT POSSIBLE #####\n ########## NO STREAM ENTRY FOUND ON THE *Euronews.com* WEBSITE !!! ##########")
		return dialog.notification(translation(30521).format('LIVE'), translation(30528), icon, 10000)

def playCODE(PLID):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### EURONEWS_IDD = {PLID} ###")
	FINAL_URL, DIRECT_STREAM, YOUT_CIPHER = (False for _ in range(3))
	for xrs in preserve(WORKS_FILE):
		if xrs['filtrate'] != '00' and xrs['filtrate'] == PLID:
			CLEAR_TITLE, DIRECT_STREAM, YOUT_CIPHER = xrs['name'], xrs['directLINK'], xrs['youtubeID']
			debug_MS(f"(navigator.playCODE[1]) ### WORKFILE-Line : {xrs} ###")
	if DIRECT_STREAM or YOUT_CIPHER:
		if DIRECT_STREAM: FINAL_URL = DIRECT_STREAM
		if PREFER_TUBE is True or not DIRECT_STREAM:
			if not YOUT_CIPHER:
				debug_MS(f"(navigator.playCODE[2]) ***** SEARCH FOR YOUTUBE - ID : {BASE_URL}/embed/{PLID} || (Youtube-Video-Search) *****")
				CHECK_ONE = getContent(f"{BASE_URL}/embed/{PLID}", queries='TEXT', TYPE='text/html; charset=utf-8', ORG=BASE_URL, REF=f"{BASE_URL}/").replace('\\', '').replace("&quot;", "\"")
				NUMERALS = re.compile(r'''["']videoid["']:["']([^"']*)["'],["']youtubevideoid["']:["']([^"']*)["'],''', re.S).findall(CHECK_ONE)
				YOUT_CIPHER = NUMERALS[0][1] if NUMERALS and NUMERALS[0][0] == PLID and NUMERALS[0][1] not in ['', 'none', 'None'] else False
			if YOUT_CIPHER:
				debug_MS(f"(navigator.playCODE[3]) ***** TESTING - REDIRECTED : https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={YOUT_CIPHER} || (Youtube-Redirect-Test) *****")
				VOD_URL, STREAM = YouGetVideo(YOUT_CIPHER)
				if VOD_URL and STREAM == 'YOUTUBE':
					FINAL_URL = VOD_URL
	if FINAL_URL:
		log(f"(navigator.playCODE) YTID : {YOUT_CIPHER} || StreamURL : {FINAL_URL}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL))
	else:
		failing(f"(navigator.playCODE) ##### PLAYBACK OF THE VOD-STREAM : >{PLID}< NOT POSSIBLE #####\n ########## NO STREAM ENTRY FOUND ON THE *Euronews.com* WEBSITE !!! ##########")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem(path='https://realvito-nosupport.de'))
		xbmc.PlayList(1).clear()
		return dialog.notification(translation(30521).format('STREAM'), translation(30528), icon, 10000)

def addDir(params, listitem, folder=True):
	uws = build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
