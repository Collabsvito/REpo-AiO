﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	debug_MS(f"(navigator.mainMenu) ### BASE_URL = {BASE_URL} ###")
	addDir(translation(30607), icon, {'mode': 'listTimeline', 'url': f"{BASE_DROID}/pages/timeline"})
	UNWANTED = ['livingit', 'joboffers', '/paidpost', 'partner', '/video']
	COMBI_SINGLE, COMBI_FIRST = ([] for _ in range(2))
	content = getUrl(BASE_URL, 'LOAD')
	DATA_ONE = re.findall(r'''<ul class=["']c-navigation-bar__wrappable-list[^>]*>(.*?)</nav>''', content, re.S)
	for chtml in DATA_ONE:
		part = chtml.split('<li id="adb-header-mainnav')
		for i in range(2 ,len(part), 1):# Start at number two to hiding 'breaking news'
			entry = part[i]# <a class="c-navigation-bar__link" href="//de.euronews.com/my-europe" aria-label="Read more about My Europe">My Europe</a>
			ARTICLES = re.compile(r'''class=["']c-navigation-bar__link["'] href=["']([^"']+)["'] aria-label=[^>]*>(.*?)<\/a>''', re.S).findall(entry)
			for LINK, NAME in ARTICLES:
				NAME = cleaning(NAME.replace('\n', ''))
				if LINK and any(rs in LINK.lower() for rs in UNWANTED): continue
				debug_MS(f"(navigator.mainMenu[1]) ##### TITLE : {NAME} || URL : {LINK} || ARTICLES_CONTENT : {str(entry)} #####")
				debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
				COMBI_SINGLE.append(NAME.lower())
				COMBI_FIRST.append([NAME, LINK, entry])
	if COMBI_FIRST:
		for title_one, news_one, elem in COMBI_FIRST:
			addDir(f"[B]{title_one}[/B]", icon, {'mode': 'SubTopics', 'url': elem, 'extras': news_one}, title_one)
	DATA_TWO = re.findall(r'''class=["']c-navigation-bar__item c-navigation-bar__item--more(.*?)</div></div>''', content, re.S)
	for item in DATA_TWO:
		SUBART = re.compile(r'''<h2 class=["']c-links-list__title["']>([^<]*)<''', re.S).findall(item)
		for TITLE in SUBART:
			title_two = cleaning(TITLE.replace('\n', ''))
			if title_two.lower() not in COMBI_SINGLE:
				addDir(f"[B]{title_two}[/B]", icon, {'mode': 'SubTopics', 'url': item}, title_two)
				debug_MS(f"(navigator.mainMenu[2]) ##### TITLE : {title_two} || REST_CONTENT : {str(item)} #####")
	addDir(translation(30608), f"{artpic}livestream.png", {'mode': 'playLIVE'}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30609), f"{artpic}settings.png", {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SubTopics(COMPACT, PHRASE):
	debug_MS("(navigator.SubTopics) -------------------------------------------------- START = SubTopics --------------------------------------------------")
	debug_MS(f"(navigator.SubTopics) ### COMPACT_LIST = {COMPACT} ### PHRASE = {PHRASE} ###")
	UNWANTED = ['livingit', 'joboffers', '/paidpost', 'partner', '/video']
	UNIKAT = set()
	if PHRASE not in ['', 'None', None]:
		addDir("[B][COLOR yellow]NEWS ...[/COLOR][/B]", icon, {'mode': 'listVideos', 'url': PHRASE})
	DATA_ONE = re.findall(r'''<div class=["']c-links-list[^>]*>(.*?)(?:</div>|</ul>)''', COMPACT, re.S)
	for chtml in DATA_ONE: # <div class="c-links-list"> === START / (?:</div>|</ul>) === END
		if PHRASE not in ['', 'None', None]: # <h2 class="c-links-list__title">Programme</h2> === HEADLINE
			HEADLINES = re.compile(r'''<h2 class=["']c-links-list__title["']>([^<]*)<''', re.S).findall(chtml)
			for HEAD in HEADLINES:
				addDir(f"[B][COLOR lime]≡ ≡ ≡ {HEAD} ≡ ≡ ≡[/COLOR][/B]", icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
				debug_MS(f"(navigator.SubTopics[1]) >>>>> MAIN_CATEGORY : {HEAD} >>>>>")
		ENTRIES = re.compile(r'''<a href=["']([^"']+)["'].*?links-list__link[^>]*>(.*?)<\/a>''', re.S).findall(chtml)
		for LINK, NAME in ENTRIES: # <a href="//de.euronews.com/my-europe/meine-europa-serie/unreported-europe" class="c-links-list__link" aria-label="Read more about Unreported Europe">Unreported Europe</a> === URL+CATEGORY
			if LINK in UNIKAT or any(ts in LINK.lower() for ts in UNWANTED):
				continue
			UNIKAT.add(LINK)
			NAME = cleaning(NAME.replace('\n', ''))
			addDir(NAME, icon, {'mode': 'listVideos', 'url': LINK, 'extras': NAME}, NAME)
			debug_MS(f"(navigator.SubTopics[2]) ##### SUB_CATEGORY : {NAME} || URL : {LINK} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(TARGET, CAT):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS(f"(navigator.listVideos) ### START_URL = {TARGET} ### CATEGORY = {CAT} ###")
	SEND = {}
	(COMBI_EPISODE, SEND['videos']), UNIKAT, FOUND, API_DETECT = ([] for _ in range(2)), set(), 0, False
	NEW_URL = TARGET if TARGET.startswith('http') else f"https:{TARGET}" if TARGET.startswith('//') else BASE_URL+TARGET
	content = getUrl(NEW_URL, 'LOAD', REF=f"{BASE_URL}/") # https://de.euronews.com/api/program/state-of-the-union?before=1519998565&extra=1&offset=13
	match = re.findall(r'''data-api-url=["']([^"']+)["']''', content, re.S)
	if match: API_LINK, API_DETECT = match[-1], True
	elif not match and TARGET.count('/') > 0: # WELT -> No Comment (url='/nocomment', KEINE 'data-api-url' vorhanden)
		API_LINK, API_DETECT = f"{BASE_URL}/api/program/{TARGET.split('/')[-1]}", True
		# WELT -> Euronews Witness (url='//de.euronews.com/programme/euronews-witness', KEINE 'data-api-url' vorhanden)
	if API_DETECT:
		URL_TWO = f"https:{API_LINK}?extra=1&offset=0&limit=70" if API_LINK.startswith('//') else f"{API_LINK}?extra=1"
		debug_MS(f"(navigator.listVideos[1]) ### URL_TWO : {URL_TWO} ###")
		result = getUrl(URL_TWO, REF=f"{BASE_URL}/")
		DATA = result['articles'] if isinstance(result, (dict, list)) and result.get('articles', '') else result if isinstance(result, (dict, list)) else []
		for item in DATA:
			photo, Note_1, Note_2 = ("" for _ in range(3))
			startTIMES, aired, begins, duration, EURO_LINK, YOU_LINK = (None for _ in range(6))
			if isinstance(item, str):
				item = DATA[item]
			item = item['data'] if item.get('data', '') else item
			if len(item) == 0: continue
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
			debug_MS(f"(navigator.listVideos[2]) xxxxx ARTICLE-02 : {str(item)} xxxxx")
			episID = str(item['id']).replace('article-', '').replace('header-', '').strip() if item.get('id', '') else '00'
			name = cleaning(item['title'])
			if item.get('images', '') and item.get('images', {})[0].get('url', ''):
				photo = item['images'][0]['url'].replace('{{w}}x{{h}}', '1280x720') # OLD = 861x485
			if str(item.get('publishedAt')).isdigit():
				CIPHER = datetime(1970,1,1) + timedelta(seconds=TGM(time.localtime(item['publishedAt'])))
				startTIMES = CIPHER.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
				aired = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # FirstAired
				begins = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
				if KODI_ov20:
					begins = CIPHER.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
			if startTIMES: Note_1 = translation(30610).format(startTIMES)
			Note_2 = cleaning(item.get('leadin', ''))
			if item.get('videos', '') and len(item['videos']) > 0:
				if 'duration' in str(item['videos']):
					duration = [int(vid.get('duration', [])) // 1000 for vid in item.get('videos', {})][-1]
				if 'url' in str(item['videos']):
					EURO_LINK = [vid.get('url', []) for vid in item.get('videos', {})][-1]
				if item.get('externalPartners', '') and item['externalPartners'].get('youtubeId', ''):
					YOU_LINK = item['externalPartners']['youtubeId']
			if EURO_LINK is None or EURO_LINK in UNIKAT:
				continue
			UNIKAT.add(EURO_LINK)
			FOUND += 1
			debug_MS(f"(navigator.listVideos[3]) ##### TITLE : {name} || THUMB : {photo} #####")
			debug_MS(f"(navigator.listVideos[3]) ##### YoutubeID : {str(YOU_LINK)} || VIDEO : {str(EURO_LINK)} || BEGINS : {str(begins)} #####")
			addLink(name, photo, {'mode': 'playCODE', 'IDENTiTY': episID}, Note_1+Note_2, genre=CAT, duration=duration, begins=begins, aired=aired)
			SEND['videos'].append({'filter': episID, 'url': EURO_LINK, 'name': name, 'transmit': YOU_LINK})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	if FOUND == 0:
		debug_MS("(navigator.listVideos) ##### Keine VIDEO-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format(str(CAT)), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTimeline(TARGET):
	debug_MS("(navigator.listTimeline) ------------------------------------------------ START = listTimeline -----------------------------------------------")
	debug_MS(f"(navigator.listTimeline) ### START_URL = {TARGET} ###")
	SEND, counter = {}, 0
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_THIRD, SEND['videos'] = ([] for _ in range(5))
	DATA_ONE = getUrl(TARGET)
	MERGING = [DATA_ONE]
	if DATA_ONE.get('pagination', '') and DATA_ONE['pagination'].get('next', '') and DATA_ONE['pagination']['next'].get('url', ''):
		if DATA_ONE['pagination']['next']['url'].startswith('/pages/timeline') and DATA_ONE['pagination']['next']['url'].endswith('slide=2'):
			debug_MS(f"(navigator.listTimeline) PAGES ### Now show NextPage : {BASE_DROID+DATA_ONE['pagination']['next']['url']} ### FOUND")
			DATA_TWO = getUrl(f"{BASE_DROID}{DATA_ONE['pagination']['next']['url']}")
			MERGING += [DATA_TWO]
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listTimeline[1]) XXXXX CONTENT-01 : {str(MERGING)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	for each in MERGING:
		for article in each.get('pageContent', []):
			if article.get('type', '') == 'justin' and article.get('content', '') and len(article['content']) > 0:
				for item in article.get('content', []):
					debug_MS(f"(navigator.listTimeline[2]) xxxxx ITEM-02 : {str(item)} xxxxx")
					debug_MS("---------------------------------------------")
					THUMB_1, NOTE_1 = ("" for _ in range(2))
					startTIMES_1, AIRED_1, BEGINS_1 = (None for _ in range(3))
					counter += 1
					episID_1 = str(item['id']).replace('article-', '').replace('header-', '').strip() if item.get('id', '') else '00'
					TITLE_1 = cleaning(item['title'])
					if item.get('image', '') and item['image'].get('url', ''):
						THUMB_1 = item['image']['url'].replace('{{w}}x{{h}}', '1280x720') # OLD = 861x485
					if str(item.get('uts')).isdigit():
						CIPHER = datetime(1970,1,1) + timedelta(seconds=TGM(time.localtime(item['uts'])))
						startTIMES_1 = CIPHER.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
						AIRED_1 = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # FirstAired
						BEGINS_1 = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
						if KODI_ov20:
							BEGINS_1 = CIPHER.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
					if startTIMES_1: NOTE_1 = translation(30610).format(startTIMES_1)
					SHOWVIDEO_1 = item.get('showVideo', False)
					COMBI_FIRST.append([int(counter), episID_1, TITLE_1, THUMB_1, BEGINS_1, AIRED_1, NOTE_1, SHOWVIDEO_1])
					if item.get('link', '') and item['link'].get('url', ''):
						COMBI_LINKS.append([int(counter), f"{BASE_DROID}{item['link']['url']}"])
	if COMBI_FIRST:
		COMBI_SECOND = getMultiData(COMBI_LINKS)
		if COMBI_SECOND:
			DATA_DETAILS = json.loads(COMBI_SECOND)
			#log("++++++++++++++++++++++++")
			#log(f"(navigator.listTimeline[3]) XXXXX CONTENT-03 : {str(DATA_DETAILS)} XXXXX")
			#log("++++++++++++++++++++++++")
			for elem in DATA_DETAILS:
				if elem is not None and elem.get('pageContent', '') and elem.get('pageContent', {})[0].get('content', ''):
					(THUMB_2, DESC_1, DESC_2), METER_2 = ("" for _ in range(3)), elem['Position']
					TAGLINE_2, DURATION_2, PLAYLINK_2 = (None for _ in range(3))
					debug_MS("---------------------------------------------")
					debug_MS(f"(navigator.listTimeline[3]) xxxxx ELEM-03 : {str(elem)} xxxxx")
					SHORT = elem['pageContent'][0]['content'][0]
					LONGER = elem['pageContent'][2]['content'][0] if len(elem['pageContent']) > 2 and elem.get('pageContent', {})[2].get('content', '') else None
					markID_2 = str(SHORT['id']).replace('article-', '').replace('header-', '').strip() if SHORT.get('id', '') else '00'
					DESC_1 = SHORT.get('summary', '')
					if SHORT.get('image', '') and SHORT['image'].get('url', ''):
						THUMB_2 = SHORT['image']['url'].replace('{{w}}x{{h}}', '1280x720') # OLD = 861x485
					if VIDEO_METAS is True and LONGER and LONGER.get('text', ''):
						TAG_2 = re.compile(r'</style></head>.+?<h2>(.*?)</h2>', re.S).findall(LONGER['text'])
						TAGLINE_2 = cleaning(TAG_2[0]) if TAG_2 else None
						TAGLINE_2 = TAGLINE_2[:125]+'...' if TAGLINE_2 and len(TAGLINE_2) > 125 else TAGLINE_2
						STORY_2 = re.findall(r'<p[^>]*>(.*?)</p>', LONGER['text'], re.S)
						DESC_2 = '[CR]'.join([cleaning(sto) for sto in STORY_2]) if STORY_2 and len(STORY_2[0]) > 10 else ""
					if SHORT.get('video', ''):
						if elem.get('tracking', '') and elem['tracking'].get('adobe', '') and elem['tracking']['adobe'].get('customParams', ''):
							for entry in elem['tracking']['adobe']['customParams']:
								if 'videoduration' in entry.get('key', '') and str(entry.get('value')).isdigit():
									DURATION_2 = int(entry['value']) # Wird in Sekunden angezeigt
						YTID_2 = SHORT['video'].get('id', None)
						PLAYLINK_2 = (SHORT['video'].get('videoFallback', {}).get('url', '') or SHORT['video'].get('url', ''))
						COMBI_THIRD.append([markID_2, THUMB_2, DESC_1, DESC_2, TAGLINE_2, DURATION_2, YTID_2, PLAYLINK_2])
	if COMBI_THIRD:
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_THIRD if a[1] == b[0]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listTimeline[4]) XXXXX RESULT-04 : {str(RESULT)} XXXXX")
		for da in sorted(RESULT, key=lambda cr: int(cr[0])): # 0-7 = Liste1 || 8-15 = Liste2
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
			debug_MS(f"(navigator.listTimeline[4]) ### Anzahl = {str(len(da))} || Eintrag : {str(da)} ###")
			episID, name, Photo1, begins, aired, Note_1, showVID = da[1], da[2], da[3], da[4], da[5], da[6], da[7]
			markID, Photo2, Desc1, Desc2, tagline, duration, YOU_LINK, EURO_LINK = da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15]
			thumb = Photo2 if Photo2 != "" else Photo1
			FULL_DESC = Desc2 if len(Desc2) > len(Desc1) else Desc1
			plot = Note_1+FULL_DESC
			debug_MS(f"(navigator.listTimeline[5]) ##### TITLE : {name} || THUMB : {thumb} #####")
			debug_MS(f"(navigator.listTimeline[5]) ##### showVID : {str(showVID)} || YoutubeID : {str(YOU_LINK)} || VIDEO : {str(EURO_LINK)} || BEGINS : {str(begins)} #####")
			if showVID is True and EURO_LINK:
				addLink(name, thumb, {'mode': 'playCODE', 'IDENTiTY': episID}, plot, tagline, 'Breaking News', duration, begins, aired)
				SEND['videos'].append({'filter': episID, 'url': EURO_LINK, 'name': name, 'transmit': YOU_LINK})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	else:
		debug_MS("(navigator.listTimeline[2]) ##### Keine TIMELINE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format('NEWS – TICKER'), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playLIVE():
	debug_MS("(navigator.playLIVE) -------------------------------------------------- START = playLIVE --------------------------------------------------")
	LIVE_URL, youtubeID, TEST_CODE = (False for _ in range(3))
	START_URL = f"https://www.euronews.com/api/live/data?locale={langDROID.replace('gr', 'el').replace('pe', 'fa')}" # https://www.euronews.com/api/live/data?locale=en
	CHECK_ONE = getUrl(START_URL, 'TRACK')
	if CHECK_ONE.status_code in [200, 201, 202] and re.search(r'"videoId":', CHECK_ONE.text):
		youtubeID = CHECK_ONE.json()['videoId']
		debug_MS(f"(navigator.playLIVE[1]) ***** FOUND YOUTUBE - ID IN CONTEXT : {youtubeID} *****")
	TEST_CODE = youtubeID if youtubeID else channelLIVE if channelLIVE != '00' else False
	if TEST_CODE:
		debug_MS(f"(navigator.playLIVE[2]) ***** TESTING - REDIRECTED : https://www.youtube.com/watch?v={TEST_CODE} || (Youtube-Redirect-Test) *****")
		CHECK_TWO = getUrl(f"https://www.youtube.com/watch?v={TEST_CODE}", 'TRACK')
		if CHECK_TWO.status_code in [200, 201, 202] and re.search(r'"isLive":true', CHECK_TWO.text):
			LIVE_URL = f"plugin://plugin.video.youtube/play/?video_id={TEST_CODE}"
	else: log("(navigator.playLIVE[1]) XXXXX !!! YOUTUBE - ID NOT FOUND - ACTION NOT SUCCESSFUL - SKIP !!! XXXXX")
	if LIVE_URL:
		debug_MS(f"(navigator.playLIVE) ### LIVE_URL : {LIVE_URL} ###")
		LTM = xbmcgui.ListItem(translation(30611), path=LIVE_URL)
		LTM.setMimeType('application/vnd.apple.mpegurl')
		xbmc.Player().play(item=LIVE_URL, listitem=LTM)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich #####\n ########## KEINEN Live-Stream-Eintrag auf der Webseite von *euronews.com* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('LIVE'), translation(30527), icon, 8000)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### EURONEWS_IDD = {IDD} ###")
	FINAL_URL = False
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == IDD:
				FINAL_URL, CLEAR_TITLE, youtubeID = elem['url'], elem['name'], elem['transmit']
				debug_MS(f"(navigator.playCODE[1]) ### WORKFILE-Line : {str(elem)} ###")
	if FINAL_URL:
		if preferTUBE is True:
			if youtubeID is None:
				debug_MS(f"(navigator.playCODE[2]) ***** SEARCH FOR YOUTUBE - ID : {BASE_URL}/embed/{IDD} || (Youtube-Video-Search) *****")
				CHECK_ONE = getUrl(f"{BASE_URL}/embed/{IDD}", 'LOAD').replace('\\', '').replace("&quot;", "\"")
				match = re.compile(r'''["']videoid["']:["']([^"']+)["'],["']youtubevideoid["']:["']([^"']+)["'],''', re.S).findall(CHECK_ONE)
				youtubeID = match[0][1] if match and match[0][0] == IDD and match[0][1] not in ['', 'none', 'None'] else None
			if youtubeID:
				debug_MS(f"(navigator.playCODE[3]) ***** TESTING - REDIRECTED : https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={youtubeID} || (Youtube-Redirect-Test) *****")
				CHECK_TWO = getUrl(f"https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={youtubeID}", 'TRACK')
				if CHECK_TWO.status_code in [200, 201, 202] and re.search(r'''["']provider_url["']:["']https://www.youtube.com/["']''', CHECK_TWO.text):
					FINAL_URL = f"plugin://plugin.video.youtube/play/?video_id={youtubeID}"
		log(f"(navigator.playCODE) YTID : {str(youtubeID)} || StreamURL : {FINAL_URL}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL))

def addDir(name, image, params={}, genre=None, folder=True):
	uws = build_mass(params)
	LDM = xbmcgui.ListItem(name, offscreen=True)
	if KODI_ov20:
		vinfo = LDM.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(' '), vinfo.setStudios(['euronews'])
		if genre and len(genre) > 2: vinfo.setGenres([genre])
	else:
		vinfo = {'Title': name, 'Plot': ' ', 'Studio': 'euronews'}
		if genre and len(genre) > 2: vinfo['Genre'] = genre
		LDM.setInfo('Video', vinfo)
	LDM.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		LDM.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, LDM, folder)

def addLink(name, image, params={}, plot=None, tagline=None, genre=None, duration=None, begins=None, aired=None):
	uvz = build_mass(params)
	LEM = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = ' '
	if KODI_ov20:
		vinfo = LEM.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setTagLine(tagline), vinfo.setPlot(plot), vinfo.setStudios(['euronews']), vinfo.setMediaType('movie')
		if str(duration).isdigit(): vinfo.setDuration(int(duration))
		if begins: LEM.setDateTime(begins)
		if aired: vinfo.setFirstAired(aired)
		if str(aired[6:10]).isdigit(): vinfo.setYear(int(aired[6:10]))
		if genre and len(genre) > 2: vinfo.setGenres([genre])
	else:
		vinfo = {'Title': name, 'Tagline': tagline, 'Plot': plot, 'Studio': 'euronews', 'Mediatype': 'movie'}
		if str(duration).isdigit(): vinfo['Duration'] = duration
		if begins: vinfo['Date'] = begins
		if aired: vinfo['Aired'] = aired
		if str(aired[6:10]).isdigit(): vinfo['Year'] = aired[6:10]
		if genre and len(genre) > 2: vinfo['Genre'] = genre
		LEM.setInfo('Video', vinfo)
	LEM.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		LEM.setArt({'fanart': image})
	LEM.setProperty('IsPlayable', 'true')
	LEM.setContentLookup(False)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uvz, LEM)
