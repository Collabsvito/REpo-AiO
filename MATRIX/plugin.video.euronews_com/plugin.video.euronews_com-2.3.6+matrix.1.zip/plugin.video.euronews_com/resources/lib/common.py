﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import time
from datetime import datetime, timedelta
from calendar import timegm as TGM
import requests
import ssl
from urllib.parse import parse_qsl, urlencode, quote_plus, unquote_plus
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from .external import *


socket.setdefaulttimeout(30)
HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addonPath							= xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath								= xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
WORKS_FILE						= xbmcvfs.translatePath(os.path.join(dataPath, 'episode_data.json'))
defaultFanart						= os.path.join(addonPath, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addonPath, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
SHORTS_WEB						= {0: 'www', 1: 'gr', 2: 'fr', 3: 'de', 4: 'it', 5: 'es', 6: 'pt', 7: 'hu', 8: 'ru', 9: 'tr', 10: 'arabic', 11: 'parsi'}[int(addon.getSetting('language'))]
# Spachennummerierung(settings) ~ English=0|Greek=1|French=2|German=3|Italian=4|Spanish=5|Portuguese=6|Hungarian=7|Russian=8|Turkish=9|Arabic=10|Persian=11
#         Webseitenkürzel(euronews) = 0: www|1: gr|2: fr|3: de|4: it|5: es|6: pt|7: hu|8: ru|9: tr|10: arabic|11: parsi
SHORTS_DROID					= SHORTS_WEB.replace('www', 'en').replace('arabic', 'ar').replace('parsi', 'pe')
PROGRAMMES					= {0: 'programs', 1: 'programs', 2: 'programmes', 3: 'programme', 4: 'programmi', 5: 'programas', 6: 'programas', 7: 'musorok', 8: 'programs', 9: 'programlar', 10: 'programs', 11: 'programs'}[int(addon.getSetting('language'))]
CHANNEL_LIVE					= {0: 'pykpO5kQJ98', 1: 'uWIhV9gQClg', 2: 'NiRIbKwAejk', 3: 'CQ3KsEbsYHs', 4: 'pUcmpyynASM', 5: 'O9mOtdZ-nSk', 6: 'XuZAl-ZPEcA', 7: 'jAn7L2Kt32U', 8: 'lwYzwdBiaho', 9: 'CQ3KsEbsYHs', 10: 'pykpO5kQJ98', 11: 'Up6Je4uhBtk'}[int(addon.getSetting('language'))]
PREFER_TUBE						= (True if addon.getSetting('YOUTUBE_LINK') == 'true' else False)
VIDEO_META						= (True if addon.getSetting('video_extradata') == 'true' else False)
useThumbAsFanart			= addon.getSetting('use_fanart') == 'true'
enableADJUSTMENT			= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_ov20							= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
KODI_un21							= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) <= 20
BASE_URL							= f"https://{SHORTS_WEB}.euronews.com"
BASE_DROID						= f"https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/{SHORTS_DROID}"
BASE_EIRIS							= f"https://www.euronews.com/iris/euronews/v7.3/{SHORTS_DROID}/articles/"

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def _header(CONTENT='application/json; charset=utf-8', ORIGIN=None, REFERRER=None, ANDROID=False):
	header = {} # !!! Accept-Language only set if browser should offer these languages !!!
	header['Cache-Control'] = 'public, max-age=300'
	header['Accept'] = 'application/json, application/x-www-form-urlencoded, text/html, */*'
	if ANDROID: header['Accept'] = 'application/json'
	header['Content-Type'] = CONTENT
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	if ORIGIN: header['Origin'] = ORIGIN
	if REFERRER: header['Referer'] = REFERRER
	return header

def getMultiData(MURLS, method='GET', MOBI=True, timeout=5, retries=2):
	COMBI_NEW, number = [], len(MURLS)
	def download(pos, url):
		heading = {**_header(ANDROID=MOBI), **{'User-Agent': 'okhttp/4.12.0'}}
		UNCHECK = ssl.create_default_context()
		UNCHECK.check_hostname = False
		UNCHECK.verify_mode = ssl.CERT_NONE
		connector = urllib3.PoolManager(block=True, ssl_context=UNCHECK, maxsize=25)
		with connector.request(method, f"{BASE_DROID}/pages/menu", headers=heading, preload_content=False, redirect=True, timeout=timeout, retries=retries) as mrs:
			if mrs.status in [200, 201, 202, 300, 301, 302]: # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/timeline // REMAINS at 03.07.25 - do not change
				response = connector.request(method, url, headers=heading, redirect=True, timeout=timeout, retries=retries)
				if response.status in [200, 201, 202, 300, 301, 302]: # https://www.euronews.com/iris/euronews/v7.3/de/articles/2812488?device=androidPhone // NEW at 03.07.25
					debug_MS(f"(common.getMultiData[1]) === POS : {pos} === URL : {url} === HEADER : {heading} ===")
					return f'{{"Position":{pos},{py3_dec(response.data[1:-1])}}}'
				else:
					failing(f"(common.getMultiData[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === STATUS : {response.status} === URL : {url} #####")
					return '{"ERROR_occurred":true}'
		connector.clear()
	with ThreadPoolExecutor() as executor:
		picker = [executor.submit(download, pos, url) for pos, url in MURLS]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for ii, future in enumerate(as_completed(picker), 1):
			try:
				COMBI_NEW.append(json.loads(future.result()))
			except Exception as exc:
				failing(f"(common.getMultiData[2]) ERROR - EXCEPTION - ERROR ##### FUTURE_RESULT : {future.result()} === FAILURE : {exc} #####")
				dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 10000)
				executor.shutdown()
		if COMBI_NEW:
			matching = [flop for flop in COMBI_NEW[:] if flop.get('ERROR_occurred', '') is True]
			if len(matching) == number or len(matching) > 10:
				dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 10000)
		return json.dumps(COMBI_NEW, indent=2)

def getContent(url, method='GET', queries='JSON', TYPE='application/json; charset=utf-8', ORG=None, REF=None, MOBI=False, redirects=True, verify=False, data=None, json=None, timeout=30):
	attempts, ANSWER = 0, None
	UNCHECK = ssl.create_default_context()
	UNCHECK.check_hostname = False
	UNCHECK.verify_mode = ssl.CERT_NONE
	while not ANSWER and attempts < 2: # 2 x ping attempts for the LINK request ::: to check the availability of the LINK
		attempts += 1
		connector = {'browser': 'chrome', 'platform': 'android', 'desktop': False} if MOBI is True else {'browser': 'chrome', 'platform': 'windows', 'mobile': False}
		simple = create_scraper(browser=connector, ssl_context=UNCHECK)
		try:
			response = simple.get(url, headers=_header(TYPE, ORG, REF, MOBI), allow_redirects=redirects, verify=verify, timeout=timeout)
			ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
			debug_MS(f"(common.getContent) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
		except Exception as exc:
			failing(f"(common.getContent) ERROR - EXCEPTION - ERROR ##### TRY.no : {attempts} === URL : {url} === FAILURE : {exc} #####")
			if attempts >= 2:
				if method in ['GET', 'POST'] and 'Expecting value:' in str(exc): pass
				else:
					dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 10000)
					return sys.exit(0)
			time.sleep(2)
	debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
	return ANSWER

def preserve(store, data=None):
	if data is not None:
		with open(store, 'w') as topics:
			json.dump(data, topics, indent=2, sort_keys=True)
	else:
		with open(store, 'r') as topics:
			arrive = json.load(topics)
		return arrive

def cleaning(text, CUSTOMISE=False):
	if text is not None:
		if CUSTOMISE is True: # Remove Emojis and other unwanted Symbols and Text in JSON-Text on EURONEWS
			for ex in (('<script>', 'javstart'), ('</script>', 'javend'), ('<figcaption ', 'capstart'), ('</figcaption>', 'capend'), ('<strong>', 'fatstart'), ('</strong>', 'fatend'), ('<br>', 'breakone'), ('\n', 'breakone'), ('</p><p>', 'breakdouble'),
				(',', 'comcom'), (';', 'semisemi'), (':', 'doubledot'), ('.', 'nomdot'), ('!', 'markmark'), ('?', 'questquest'), ('=', 'equalequal'), ('&', 'andand'), ("'", 'quotone'), ('"', 'quotdouble'), ('-', 'dashdash'), (' | ', 'pipepipe'),
				('~', 'swunswun'), ('*', 'starstar'), ('+', 'crosscross'), ('(', 'brackstart'), (')', 'brackend'), ('//', 'verticvertic'), ('/', 'slashslash'), ('#', 'atrhomb'), ('@', 'atmonkey'), ('§', 'parapara'), ('$', 'dolldoll'), ('%', 'perper')):
				text = text.replace(*ex)
			text = re.sub(r'(javstart.*?javend|capstart.*?capend|\<.*?\>)', '', text) # FIRST: Remove text in Script/Figcaption-Types (e.g.Twitter mentions) // SECOND: Remove text between arrow-signs (Links etc.)
			text = re.sub(r'[^\w]', ' ', text) # Remove anything that's not alphanumeric or underscore
		for nw in (('    ', ' '), ('   ', ' '), ('  ', ' '), ('javstart', ''), ('javend', ''), ('capstart', ''), ('capend', ''), ('fatstart', '[B]'), ('fatend', '[/B]'), ('breakone ', '[CR]'), ('breakone', '[CR]'), ('breakdouble', '[CR][CR]'), ('[CR][CR]', '[CR]'),
			('comcom', ','), ('semisemi', ';'), ('doubledot', ':'), ('nomdot', '.'), ('markmark', '!'), ('questquest', '?'), ('equalequal', '='), ('andand', '&'), ('quotone', "'"), ('quotdouble', '"'), ('dashdash', '-'), ('pipepipe', ' | '),
			('swunswun', '~'), ('starstar', '*'), ('crosscross', '+'), ('brackstart', '('), ('brackend', ')'), ('verticvertic', '|'), ('slashslash', '/'), ('atrhomb', '#'), ('atmonkey', '@'), ('parapara', '§'), ('dolldoll', '$'), ('perper', '%'),
			('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\xc2\xb7', '-'),
			("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''),
			('&#xC4;', 'Ä'), ('&#xE4;', 'ä'), ('&#xD6;', 'Ö'), ('&#xF6;', 'ö'), ('&#xDC;', 'Ü'), ('&#xFC;', 'ü'), ('&#xDF;', 'ß'), ('&#x201E;', '„'), ('&#xB4;', '´'), ('&#x2013;', '-'), ('&#xA0;', ' '),
			('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
			('&agrave;', 'à'), ('&Agrave;', 'À'), ('&aacute;', 'á'), ('&Aacute;', 'Á'), ('&acirc;', 'â'), ('&Acirc;', 'Â'), ('&egrave;', 'è'), ('&Egrave;', 'È'), ('&eacute;', 'é'), ('&Eacute;', 'É'), ('&ecirc;', 'ê'), ('&Ecirc;', 'Ê'),
			('&igrave;', 'ì'), ('&Igrave;', 'Ì'), ('&iacute;', 'í'), ('&Iacute;', 'Í'), ('&icirc;', 'î'), ('&Icirc;', 'Î'), ('&ograve;', 'ò'), ('&Ograve;', 'Ò'), ('&oacute;', 'ó'), ('&Oacute;', 'Ó'), ('&ocirc;', 'ô'), ('&Ocirc;', 'Ô'),
			('&ugrave;', 'ù'), ('&Ugrave;', 'Ù'), ('&uacute;', 'ú'), ('&Uacute;', 'Ú'), ('&ucirc;', 'û'), ('&Ucirc;', 'Û'), ('&yacute;', 'ý'), ('&Yacute;', 'Ý'),
			('&atilde;', 'ã'), ('&Atilde;', 'Ã'), ('&ntilde;', 'ñ'), ('&Ntilde;', 'Ñ'), ('&otilde;', 'õ'), ('&Otilde;', 'Õ'), ('&Scaron;', 'Š'), ('&scaron;', 'š'), ('&ccedil;', 'ç'), ('&Ccedil;', 'Ç'),
			('&alpha;', 'a'), ('&Alpha;', 'A'), ('&aring;', 'å'), ('&Aring;', 'Å'), ('&aelig;', 'æ'), ('&AElig;', 'Æ'), ('&epsilon;', 'e'), ('&Epsilon;', 'Ε'), ('&eth;', 'ð'), ('&ETH;', 'Ð'), ('&gamma;', 'g'), ('&Gamma;', 'G'),
			('&oslash;', 'ø'), ('&Oslash;', 'Ø'), ('&theta;', 'θ'), ('&thorn;', 'þ'), ('&THORN;', 'Þ'), ('&bull;', '•'), ('&iexcl;', '¡'), ('&iquest;', '¿'), ('&copy;', '(c)'), ('\t', ''), ('ㅤ', ''),
			("&rsquo;", "’"), ("&lsquo;", "‘"), ("&sbquo;", "’"), ('&rdquo;', '”'), ('&ldquo;', '“'), ('&bdquo;', '”'), ('&rsaquo;', '›'), ('lsaquo;', '‹'), ('&raquo;', '»'), ('&laquo;', '«'),
			('\\xC4', 'Ä'), ('\\xE4', 'ä'), ('\\xD6', 'Ö'), ('\\xF6', 'ö'), ('\\xDC', 'Ü'), ('\\xFC', 'ü'), ('\\xDF', 'ß'), ('\\x201E', '„'), ('\\x28', '('), ('\\x29', ')'), ('\\x2F', '/'), ('\\x2D', '-'), ('\\x20', ' '), ('\\x3A', ':'), ('\\"', '"')):
			text = text.replace(*nw)
		text = text.strip()
	return text

def create_entries(metadata, SIGNS=True):
	listitem = xbmcgui.ListItem(metadata['Title'])
	vinfo = listitem.getVideoInfoTag() if KODI_ov20 else {}
	if KODI_ov20: vinfo.setTitle(metadata['Title'])
	else: vinfo['Title'] = metadata['Title']
	if metadata.get('Tagline', ''):
		if KODI_ov20: vinfo.setTagLine(metadata['Tagline'])
		else: vinfo['Tagline'] = metadata['Tagline']
	description = metadata['Plot'] if metadata.get('Plot') not in ['', 'None', None] else ' '
	if KODI_ov20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if str(metadata.get('Duration')).isdecimal():
		if KODI_ov20: vinfo.setDuration(int(metadata['Duration']))
		else: vinfo['Duration'] = metadata['Duration']
	if metadata.get('Date', ''):
		if KODI_ov20: listitem.setDateTime(metadata['Date'])
		else: vinfo['Date'] = metadata['Date']
	if metadata.get('Aired', ''):
		if KODI_ov20: vinfo.setFirstAired(metadata['Aired'])
		else: vinfo['Aired'] = metadata['Aired']
	if str(metadata.get('Aired'))[6:10].isdecimal():
		if KODI_ov20: vinfo.setYear(int(metadata['Aired'][6:10]))
		else: vinfo['Year'] = metadata['Aired'][6:10]
	if metadata.get('Genre', ''):
		if KODI_ov20: vinfo.setGenres([metadata['Genre']])
		else: vinfo['Genre'] = metadata['Genre']
	if KODI_ov20: vinfo.setStudios(['euronews'])
	else: vinfo['Studio'] = 'euronews'
	if metadata.get('Mediatype', ''):
		if KODI_ov20: vinfo.setMediaType(metadata['Mediatype'])
		else: vinfo['Mediatype'] = metadata['Mediatype']
	picture = metadata.get('Image', icon)
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'fanart': defaultFanart})
	if useThumbAsFanart and not artpic in picture and SIGNS is True:
		listitem.setArt({'fanart': picture})
	if metadata.get('Reference') == 'Single':
		listitem.setProperty('IsPlayable', 'true')
	if not KODI_ov20: listitem.setInfo('Video', vinfo)
	return listitem
