﻿# -*- coding: utf-8 -*-

import sys
import xbmc
import xbmcaddon


def translation(ident):
	return xbmcaddon.Addon().getLocalizedString(ident)

class Client(object):
	CONFIG_STAIGE = {
		'DEFAULT': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/page/landing',
		'COUNTRIES': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/page/region',
		'CITIES': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/page/city',
		'CALENDAR': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/calendar',
		'SEARCHES': 'https://europe-west3-aisw-ww-prod.cloudfunctions.net/api_search/search?query={}&kind=skyhook-beta-club&fuzzy=false&match=name,aliasList,searchName,city',
		'INFO_CLUB': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/page/club',
		'INFO_COMP': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/page/competition',
		'INFO_LAND': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/page/region',
		'INFO_CITY': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/tile/city',
		'INFO_TEAM': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/page/team',
		'INFO_MATCH': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/tile/match',
		'INFO_VIDEO': 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta/page/video',
		'VIDEO_LINK': 'https://storage.googleapis.com/sw-sc-de-shared/{}/master.m3u8',
		'mount': [
		{
			'title': translation(30621),
			'shift': 'Auswahl Live',
			'turn': 'skyhook.live',
			'lane': '/tile/match',
			'vars': 'tkz_',
			'solo': 'video',
			'step': 'container',
			'code': 11
		},
		{
			'title': translation(30622),
			'shift': 'Auswahl Demnächst',
			'turn': 'skyhook.comingSoon',
			'lane': '/tile/match',
			'vars': 'tkz_',
			'solo': 'video',
			'step': 'container',
			'code': 12
		},
		{
			'title': 'Highlights',
			'shift': 'Auswahl Highlights',
			'turn': 'skyhook.toVideo',
			'lane': '/tile/match',
			'vars': 'tkz_',
			'solo': 'video',
			'step': 'teaser',
			'code': 13
		},
		{
			'title': translation(30623),
			'shift': 'Auswahl Letzte Begegnungen',
			'turn': 'skyhook.recent',
			'lane': '/tile/match',
			'vars': 'tkz_',
			'solo': 'video',
			'step': 'container',
			'code': 14
		},
		{
			'title': translation(30624),
			'shift': 'Übersicht Verein',
			'turn': 'skyhook.clubs',
			'lane': '/page/club',
			'start': 'clu_',
			'vars': 'idn_',
			'solo': 'club',
			'step': 'container',
			'code': 15
		},
		{
			'title': translation(30625),
			'shift': 'Übersicht Wettbewerb',
			'turn': 'skyhook.competitions',
			'lane': '/page/competition',
			'start': 'com_',
			'vars': 'idn_',
			'solo': 'competition',
			'step': 'container',
			'code': 16
		},
		{
			'title': translation(30626),
			'shift': 'Übersicht Land',
			'turn': 'skyhook.countries',
			'lane': '/page/region',
			'start': 'seg_',
			'vars': 'idn_',
			'solo': 'country',
			'step': 'container',
			'code': 17
		},
		{
			'title': translation(30627),
			'shift': 'Übersicht Stadt',
			'turn': 'skyhook.inRegion',
			'lane': '/page/city',
			'start': 'cit_',
			'vars': 'idn_',
			'solo': 'city',
			'step': 'container',
			'code': 18
		},
		{
			'title': 'Teams',
			'shift': 'Übersicht Team',
			'turn': 'skyhook.teamsAll',
			'lane': '/page/team',
			'start': 'tea_',
			'vars': 'idn_',
			'solo': 'team',
			'step': 'container',
			'code': 19
		},
		{
			'title': 'Suchfunktion',
			'shift': 'Übersicht Verein',
			'turn': 'skyhook.searches',
			'lane': '/page/club',
			'start': 'clu_',
			'vars': 'idn_',
			'solo': 'club',
			'step': 'hits',
			'code': 20
		}],
		'genres': [
		{
			'title': translation(30628),
			'shift': 'Übersicht Fußball',
			'turn': 'skyhook.genres',
			'vars': 'evs_soccer',
			'solo': 'soccer',
			'code': 31
		},
		{
			'title': translation(30629),
			'shift': 'Übersicht Eishockey',
			'turn': 'skyhook.genres',
			'vars': 'evs_icehockey',
			'solo': 'icehockey',
			'code': 32
		},
		{
			'title': 'Hockey',
			'shift': 'Übersicht Hockey',
			'turn': 'skyhook.genres',
			'vars': 'evs_hockey',
			'solo': 'hockey',
			'code': 33
		},
		{
			'title': 'Handball',
			'shift': 'Übersicht Handball',
			'turn': 'skyhook.genres',
			'vars': 'evs_handball',
			'solo': 'handball',
			'code': 34
		},
		{
			'title': 'Volleyball',
			'shift': 'Übersicht Volleyball',
			'turn': 'skyhook.genres',
			'vars': 'evs_volleyball',
			'solo': 'volleyball',
			'code': 35
		},
		{
			'title': 'Basketball',
			'shift': 'Übersicht Basketball',
			'turn': 'skyhook.genres',
			'vars': 'evs_basketball',
			'solo': 'basketball',
			'code': 36
		},
		{
			'title': translation(30630),
			'shift': 'Übersicht Wasserpolo',
			'turn': 'skyhook.genres',
			'vars': 'evs_waterpolo',
			'solo': 'waterpolo',
			'code': 37
		},
		{
			'title': 'Motoball',
			'shift': 'Übersicht Motoball',
			'turn': 'skyhook.genres',
			'vars': 'evs_motoball',
			'solo': 'motoball',
			'code': 38
		}],
	}

	def __init__(self, records):
		self._records = records

	def get_records(self):
		return self._records
