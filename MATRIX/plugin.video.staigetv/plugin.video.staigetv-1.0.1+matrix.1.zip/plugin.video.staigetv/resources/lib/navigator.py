﻿# -*- coding: utf-8 -*-

from .common import *
config = traversing.get_records()


def get_variables(codes=None, starts={}):
	if codes and codes[:4] == 'tkz_': return {"id": codes[4:]}
	elif codes and codes[:4] == 'idn_': starts = {"id": codes[4:]}
	elif codes and codes[:4] == 'evs_': starts = {"eventType": codes[4:]}
	elif codes and codes[:4] == 'ena_': starts = {"start": codes.split('@@')[-1], "eventType": codes[4:].split('@@')[0]}
	elif codes and codes[:4] == 'san_': starts = {"start": codes.split('@@')[-1]}
	elif codes and codes[:4] == 'clu_': starts = {"start": codes.split('@@')[-1], "clubId": codes[4:].split('@@')[0]}
	elif codes and codes[:4] == 'com_': starts = {"start": codes.split('@@')[-1], "competitionId": codes[4:].split('@@')[0]}
	elif codes and codes[:4] == 'seg_': starts = {"start": codes.split('@@')[-1], "regionId": codes[4:].split('@@')[0]}
	elif codes and codes[:4] == 'cit_': starts = {"start": codes.split('@@')[-1], "cityId": codes[4:].split('@@')[0]}
	elif codes and codes[:4] == 'tea_': starts = {"start": codes.split('@@')[-1], "teamId": codes[4:].split('@@')[0]}
	return {**starts , **{"tenantId": "staige"}}

def list_categories(target, stage, sector, phase, mark):
	debug_MS("(navigator.list_categories) -------------------------------------------------- START = list_categories --------------------------------------------------")
	debug_MS(f"(navigator.list_categories) ### URL = {target} ### STAGE = {stage} ### SECTOR = {sector} ### PHASE = {phase} ### NAME = {mark} ###")
	if stage == 'Sportarten':
		for each in config.get('genres', []):
			title, staing, secting, phaing, photo = each['title'], each['shift'], each['turn'], each['vars'], f"{artpic}{each['solo']}.png"
			add_views({'mode': 'list_categories', 'link': '/page/landing', 'stage': staing, 'sector': secting, 'phase': phaing}, create_entries({'Title': title, 'Image': photo}))
			debug_MS(f"(navigator.list_categories[1]) ### NAME : {title} || SECTOR : {secting} || PHASE : {phaing} ###")
	else:
		if stage == 'Startmenu': add_views({'mode': 'list_favorites'}, create_entries({'Title': translation(30601), 'Image': f"{artpic}favourites.png"}))
		placing, primodo, data_uno = 0, [], track_content(SKY_CLOUD+target, 'POST', 'JSON', SKY_HEADER, json=get_variables(phase))
		if data_uno is not None:
			for each in config.get('mount', []):
				if stage == 'Startmenu' and addon.getSetting(each.get('turn', 'true')) == 'false': continue
				if data_uno.get('teaser', '') and len(data_uno['teaser']) > 1 and each['turn'] == 'skyhook.toVideo':
					primodo.append({'Place': each['code'], 'Title': f"[B]{each['title']}[/B]", 'Stage': each['title'], 'Sector': each['turn']})
				for item in data_uno.get('container', []):
					if each['turn'] == item.get('header') and item.get('tiles', []):
						primodo.append({'Place': each['code'], 'Title': f"[B]{each['title']}[/B]", 'Stage': re.sub(r'(\[.*?\]|■|▲|  )', '', each['title']), 'Sector': each['turn']})
			if primodo:
				for posts in sorted(primodo, key=lambda asx: int(asx.get('Place', 0))): # Sortieren nach eigener Vorlage und nicht nach Provider
					add_views({'mode': 'list_videos', 'link': SKY_CLOUD+target, 'stage': posts.get('Stage').strip(), 'sector': posts.get('Sector'), 'phase': phase}, create_entries({'Title': posts.get('Title')}))
					placing = int(posts.get('Place'))
					debug_MS(f"(navigator.list_categories[1.1]) ### COUNT : {placing} || NAME : {posts.get('Stage').strip()} || SECTOR : {posts.get('Sector')} || PHASE : {phase} ###")
		if stage == 'Startmenu':
			add_views({'mode': 'list_categories', 'link': 'page/landing', 'stage': 'Sportarten', 'sector': 'unknown'}, create_entries({'Title': f"[B]{translation(30602)}[/B]"}))
			if basedates:
				fetch_items = create_entries({'Title': f"[B]{translation(30603)}[/B]", 'Image': f"{artpic}calendar.png"})
				add_views({'mode': 'list_calendar', 'link': f"/calendar", 'stage': 'Spielpläne', 'sector': 'skyhook.calendar', 'phase': 'san_'}, fetch_items)
				debug_MS(f"(navigator.list_categories[1.2]) ### COUNT : {placing+1} || NAME : {translation(30603)} || SECTOR : skyhook.calendar || PHASE : san_ ###")
			if basesearch:
				add_views({'mode': 'search_staige'}, create_entries({'Title': f"[B]{translation(30604)}[/B]", 'Image': f"{artpic}basesearch.png"}))
				debug_MS(f"(navigator.list_categories[1.3]) ### COUNT : {placing+2} || NAME : {translation(30604)} || SECTOR : skyhook.searches || PHASE : idn_ ###")
			if enable_tune:
				add_views({'mode': 'antuning'}, create_entries({'Title': translation(30605), 'Image': f"{artpic}settings.png"}), False)
		elif stage.startswith('Übersicht') and data_uno is not None:
			if any(len(cmx.get('tiles', {})) > 0 for cmx in data_uno.get('container', [])):
				suffix, fetch_title = next((swa.get('new') for swa in swaps_vars if swa.get('old') == sector), None), create_entries({'Title': f"[B]{translation(30606)}[/B]"})
				carlink = f"/calendar/{target.split('/')[-1]}" if sector != 'skyhook.genres' else '/calendar'
				add_views({'mode': 'list_calendar', 'link': carlink, 'stage': f"Spielplan{stage[9:]}", 'sector': sector, 'phase': f"{suffix}{phase[4:]}"}, fetch_title)
				debug_MS(f"(navigator.list_categories[1.2]) ### COUNT : {placing+1} || NAME : {translation(30606)} || SECTOR : {sector} || PHASE : {suffix}{phase[4:]} ###")
			else: return dialog.notification(translation(30525), translation(30526).format(mark if mark else stage), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_calendar(target, stage, sector, phase):
	debug_MS("(navigator.list_calendar) ------------------------------------------------ START = list_calendar -----------------------------------------------")
	for ii in range(-6, 19, 1):
		dating = '{dtn.year}-{dtn.month}-1'.format(dtn=datetime.utcnow() - relativedelta(months=ii))
		yearing, monting, monat_due = dating[:4], dating[5:].split('-')[0], dating[5:].split('-')[0].zfill(2) # Datum gesplittet: 2026-6-1 || year=2026, month=6, monat_due=06
		debug_MS(f"(navigator.list_calendar[1]) ### STAGE : {stage} / {monat_due} ~ {yearing} || DATES : {dating} ###")
		for tt in (('01', translation(32101)), ('02', translation(32102)), ('03', translation(32103)), ('04', translation(32104)), ('05', translation(32105)), ('06', translation(32106)), \
			('07', translation(32107)), ('08', translation(32108)), ('09', translation(32109)), ('10', translation(32110)), ('11', translation(32111)), ('12', translation(32112))): monat_due = monat_due.replace(*tt)
		title = translation(30701).format(yearing, monat_due) if ii == 0 else translation(30702).format(yearing, monat_due)
		fetch_items = create_entries({'Title': title, 'Image': f"{artpic}calendar.png"})
		add_views({'mode': 'list_videos', 'link': SKY_CLOUD+target, 'stage': f"{stage} / {monting.zfill(2)} ~ {yearing}", 'sector': 'skyhook.calendar', 'phase': f"{phase}@@{dating}"}, fetch_items)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_staige():
	debug_MS("(navigator.search_staige) ------------------------------------------------ START = search_staige -----------------------------------------------")
	keyword = preserve(SEARCH_FILE, 'TEXT')
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30703), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword: return list_videos(config['SEARCHES'].format(quote(keyword)), translation(30704).format(keyword), 'skyhook.searches', 'idn_')
	return None

def list_videos(target, stage, sector, phase):
	debug_MS("(navigator.list_videos) -------------------------------------------------- START = list_videos --------------------------------------------------")
	debug_MS(f"(navigator.list_videos) ### URL = {target} ### STAGE = {stage} ### SECTOR = {sector} ### PHASE = {phase} ###")
	# Stream-Status = Mission running : Livestream // created : Kommender Stream // done : Aufgezeichneter Stream
	route, unikat, playable, (combo_links, combo_uno, combo_due, sending) = 'POST', set(), False, ([] for _ in range(4))
	(number, counter, exclude), (lanes, varius, steps, begin) = (0 for _ in range(3)), (None for _ in range(4))
	for trails in config.get('mount', []):
		if sector == trails.get('turn'):
			lanes, varius, steps, route = f"{SKY_CLOUD}{trails['lane']}", trails['vars'], trails['step'], 'POST' if sector != 'skyhook.searches' else 'GET'
		elif sector == 'skyhook.calendar':
			lanes, varius, steps, begin = f"{SKY_CLOUD}/tile/match", 'tkz_', 'videos', stage.split('/')[-1] # 2026-06 = begin[6:10]-begin[1:3]
	if lanes and steps:
		data_uno = track_content(target, route, 'JSON', SKY_HEADER, json=get_variables(phase) if route=='POST' else None)
		tables = data_uno.get(steps, []) if sector != 'skyhook.searches' else [data_uno]
		for parts in tables:
			if (sector == parts.get('header') and parts.get('tiles', [])) or (sector == 'skyhook.searches' and parts.get(steps, {})):
				elements = parts.get('tiles', []) if sector != 'skyhook.searches' else parts[steps].get(steps, [])
				for meter, tiles in enumerate(elements, 1):
					source = tiles if sector != 'skyhook.searches' else tiles.get('_source', {})
					if isinstance(tiles, (dict, list)):
						matches = {**source, **{'Count_1': int(meter), 'Link_1': target, 'Code_1': source.get('RowKey', None)}}
						combo_uno.append(matches)
					else:
						combo_links.append({'Count_1': int(meter), 'Hook_1': sector, 'Link_1': lanes, 'Code_1': tiles, 'Trans_1': get_variables(varius+tiles if varius else None)})
					debug_MS(f"(navigator.list_videos[1.1]) xxxxx COUNT-01 : {meter} || CODE-01 : {source.get('RowKey', None) if isinstance(tiles, (dict, list)) else '>>>'} || ENTRY-01 : {tiles} xxxxx")
					debug_MS("* * * * * * * * * * * * * * * * * * * * * * * * *")
			elif (sector == parts.get('text') and parts.get('game', {})) or data_uno.get('videos', {}):
				playable, number = True, number.__add__(1)
				games = parts['game'] if parts.get('game', {}) else parts
				games = {**games, **{'Count_1': int(number), 'Link_1': target, 'Code_1': games.get('RowKey', None)}}
				debug_MS(f"(navigator.list_videos[1.2]) xxxxx COUNT-01 : {number} || CODE-01 : {games.get('Code_1')} || ENTRY-01 : {games} xxxxx")
				debug_MS("* * * * * * * * * * * * * * * * * * * * * * * * *")
				combo_uno.append(games)
	if combo_uno:
		combo_due = [cea for cea in _fetch_pages(combo_links, sector)] if combo_links else combo_due
		merging = combo_uno + [bv for bv in combo_due if any(bv.get('Count_2') != av.get('Count_1') for av in combo_uno)]
		sorting = False if sector.endswith('comingSoon') else True
		if sector.endswith(('clubs', 'competitions', 'countries', 'inRegion', 'searches', 'teamsAll')) and not playable:
			merging = sorted(merging, key=lambda vox: clear_umlaut(vox.get('name', 'zorro')).lower())
		else: merging = sorted(merging, key=lambda vox: vox.get('startTime', '2026-01-01T00:01:00')[:19], reverse=sorting)
		for riders in merging:
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
			shorties = {key: str(value)[:130] for key, value in riders.items() if value not in ['', None]}
			debug_MS(f"(navigator.list_videos[3]) ### Anzahl = {len(riders)} || Eintrag : {shorties} ###")
			each = create_substances(riders, sector.split('.')[-1] if not playable else 'videos')
			# [uuid=0, species=1, genre=2, name=3, duration=4, stream=5, media=6, starting=7, airing=8, money=9, status=10]
			# [note_1=11, note_2=12, note_3=13, note_4=14, photo=15, backdrop=16, excluding=17, next_on=18, runs_on=19, sector=20]
			counter += 1
			plot = each[11]+each[12]+each[13]+each[14]
			if each[17] is True or each[0] in unikat or (sector == 'skyhook.calendar' and begin and f"{begin[6:10]}-{begin[1:3]}" != str(riders.get('startTime'))[:7]):
				exclude += 1
				if sector.endswith(('clubs', 'competitions', 'countries', 'inRegion', 'searches', 'teamsAll')):
					debug_MS(f"(navigator.list_videos[~0~]) ~~~ POS : {counter} || NAME : {each[3]} || CODE : {each[0]} || GENRE : {each[2]} || THUMB : {each[15]} ~~~")
				else:
					debug_MS(f"(navigator.list_videos[~0~]) ~~~ POS : {counter} || NAME : {each[3]} || MEDIA : {each[6]} || CODE : {each[0]} || GENRE : {each[2]} ~~~")
					debug_MS(f"(navigator.list_videos[~0~]) ~~~ AIRED : {each[8]} || STATUS : {each[10]} || DURATION : {each[4]} || THUMB : {each[15]} ~~~")
				continue
			unikat.add(each[0])
			fetching, operation = {'Slug': each[0], 'Species': each[1], 'Title': each[3], 'Plot': plot, 'Genre': each[2], 'Image': each[15], 'Fanback': each[16]}, 'skipping'
			if sector.endswith(('clubs', 'competitions', 'countries', 'inRegion', 'searches', 'teamsAll')) and not playable:
				debug_MS(f"(navigator.list_videos[3.1]) ##### POS : {counter} || NAME : {each[3]} || CODE : {each[0]} || GENRE : {each[2]} || THUMB : {each[15]} #####")
				follow, operation = next(filter(lambda cmx: cmx.get('turn') == sector and cmx.get('lane', {}), config['mount']), None), 'adding'
				if follow:
					secting = sector.replace('skyhook.searches', 'skyhook.clubs')
					folder, higher, action = True, False, {'mode': 'list_categories', 'link': follow.get('lane'), 'stage': follow.get('shift'), 'sector': secting, 'phase': f"{follow.get('vars')}{each[0]}", 'mark': each[3]}
					fetch_items = context = {**fetching, **{'Link': follow.get('lane'), 'Stage': follow.get('shift'), 'Sector': secting, 'Phase': f"{follow.get('vars')}{each[0]}"}}
					if preserve(FAVORIT_FILE) is not None:
						for snippet in preserve(FAVORIT_FILE):
							if snippet.get('Slug') == each[0]: operation = 'skipping'
			else:
				debug_MS(f"(navigator.list_videos[3.2]) ##### POS : {counter} || NAME : {each[3]} || MEDIA : {each[6]} || CODE : {each[0]} || GENRE : {each[2]} #####")
				debug_MS(f"(navigator.list_videos[3.2]) ##### AIRED : {each[8]} || STATUS : {each[10]} || DURATION : {each[4]} || THUMB : {each[15]} #####")
				folder, higher, action = False, True, {'mode': 'play_video', 'link': each[0]}
				fetch_items = context = {**fetching, **{'Duration': each[4], 'Date': each[7], 'Aired': each[8], 'Year': each[8], 'Mediatype': 'episode', 'Reference': 'Single'}}
				sending.append({'filtrate': each[0], 'name': each[3], 'photo': each[15], 'teaser': plot, 'media': each[6]})
			add_views(action, create_entries(fetch_items), folder, context, operation, higher)
		preserve(WORKS_FILE, 'JSON', sending)
	if not combo_uno or counter == exclude:
		notices = stage if not 'searches' in target else re.sub(r'(SEARCH: |SUCHE: )', '', stage)
		return dialog.notification(translation(30525), translation(30526).format(notices), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def _fetch_pages(templates, style):
	package = track_several(templates, 'POST', 'JSON', SKY_HEADER)
	if package:
		for article in json.loads(package):
			if article not in ['', None] and article.get('Status', 'OOKAY') != 'ERROR' and any(sax.get('turn') == style for sax in config.get('mount', [])):
				sports = next((sva.get('solo') for sva in config.get('mount', []) if sva.get('turn') == style), None)
				if sports:
					scraps = article.get(sports, {})
					embrace = {**scraps, **{'Count_2': article['Count_2'], 'Hook_2': article['Hook_2'], 'Link_2': article['Link_2'], 'Code_2': scraps.get('RowKey', None)}}
					debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++++")
					short_infos = {key: str(value)[:130] for key, value in embrace.items() if value not in ['', None]}
					debug_MS(f"(navigator.list_videos[2]) xxxxx COUNT-02 : {article['Count_2']} || CODE-02 : {scraps.get('RowKey', None)} || ENTRY-02 : {short_infos} xxxxx")
					yield embrace

def create_substances(rsx, others=None):
	(start_full, start_date, start_time, airing, starting, ends_date, photo), branch, backdrop = (None for _ in range(7)), 'sport', True
	(next_on, runs_on, excluding), (note_1, note_2, note_3, note_4, gender) = (False for _ in range(3)), ("" for _ in range(5))
	name, duration, stream, media, money, status = (None for _ in range(6))
	uuid = rsx.get('RowKey', None)
	species = rsx['eventType'][0] if rsx.get('eventType', '') and isinstance(rsx['eventType'], list) else rsx['eventType'] if rsx.get('eventType', '') else branch
	if species == 'sport': species = rsx['Ref_Team_SportType'][0] if rsx.get('Ref_Team_SportType', '') and isinstance(rsx['Ref_Team_SportType'], list) else rsx['Ref_Team_SportType'] if rsx.get('Ref_Team_SportType', '') else branch
	if species == 'sport': species = rsx['sportType'] if rsx.get('sportType', '') and not isinstance(rsx['sportType'], list) else branch
	genre = next((lang.get('new') for lang in genre_lang if lang.get('old') == species.lower()), species.title())
	photo = (rsx.get('thumbnail', '') or rsx.get('imageUrl', ''))
	photo = photo.replace('.jpeg', '-4x.jpeg').replace('.jpg', '-4x.jpg').replace('schweiz-4x.jpg', 'schweiz.jpg') if photo and not photo.startswith('/') and not '-4x' in photo else None
	if photo is None:
		photo, backdrop = (rsx.get('Ref_CC_Image', '') or rsx.get('Ref_Club_A_Thumbnail', '') or rsx.get('Ref_Club_B_Thumbnail', '') or rsx.get('Ref_Club_Thumbnail', '') or None), False
	if photo is None or photo.endswith('.png'): backdrop = False
	if photo is None: photo = f"{artpic}cityblur.png" if others == 'inRegion' else f"{artpic}standard.png"
	sexual = (rsx.get('league', '') or rsx.get('teamAAge', '') or rsx.get('teamBAge', '') or rsx.get('age', 'All'))
	if sexual and any(xw in sexual.lower() for xw in ['frauen', 'juniorinnen']): gender = translation(30711)
	elif sexual and any(xm in sexual.lower() for xm in ['herren', 'junioren']): gender = translation(30712)
	if others in ['countries', 'competitions', 'clubs', 'inRegion', 'searches', 'teamsAll']:
		if rsx.get('name', None):
			title, name = rsx['name'][:1].upper()+rsx['name'][1:], rsx['name'][:1].upper()+rsx['name'][1:]+gender
			if others in ['clubs', 'searches']:
				note_1 = translation(30713).format(title)
				location = f"{str(rsx['zip']).replace('-1', '45340')} {rsx['city'][:1].upper()+rsx['city'][1:]}" if rsx.get('zip', None) and rsx.get('city', None) else None
				if location is None: location = rsx['location'].split(', ')[1] if rsx.get('location', None) and ', ' in rsx['location'] else None
				if location: note_2 = translation(30714).format(location)
			elif others == 'inRegion':
				genre, note_1 = None, translation(30715).format(title)
				if rsx.get('state', None): note_2 = translation(30716).format(rsx['state'])
			elif others == 'teamsAll':
				note_1 = translation(30717).format(title, sexual.title())
			else:
				genre, season = None if others == 'countries' else genre, rsx.get('season', None)
				league, event, agen = rsx.get('leagueName', None), rsx.get('eventCategory', None), rsx.get('ageName', None)
				if season: note_1 = translation(30718).format(f"20{season[:2]} - 20{season[2:]}")
				if others == 'competitions': note_2 = translation(30719).format(title)
				if league and event and agen: note_3 = translation(30720).format(league, event, agen)
		else: excluding = True
	else:
		title = f"{rsx['clubAName']} vs. {rsx['clubBName']}"
		money = rsx.get('paywall', False)
		status = rsx.get('state', 'done') # created, done, Mission running
		if str(rsx.get('startTime'))[:4].isdecimal(): # 2024-05-10T19:15:18.000Z
			local_start = convert_region(rsx['startTime'])
			start_full = local_start.strftime('%a{0} %d{0}%m{0}%y {1} %H{2}%M').format( '.', '•', ':')
			for tt in (('Mon', translation(32121)), ('Tue', translation(32122)), ('Wed', translation(32123)), ('Thu', translation(32124)), \
				('Fri', translation(32125)), ('Sat', translation(32126)), ('Sun', translation(32127))): start_full = start_full.replace(*tt)
			start_date = local_start.strftime('%d.%m.%Y')
			start_time = local_start.strftime('%H:%M')
			if datetime.now() < local_start - timedelta(minutes=15): next_on, runs_on = True, False # 19:44 < 20:00-15m = 19:45
			if datetime.now() > local_start - timedelta(minutes=15): next_on, runs_on = False, True # 19:46 > 20:00-15m = 19:45
			starting = local_start.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else local_start.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
			airing = local_start.strftime('%d.%m.%Y') # FirstAired
		if str(rsx.get('endTime'))[:4].isdecimal(): # 2024-05-10T22:00:18.000Z
			local_ends = convert_region(rsx['endTime'])
			ends_date = local_ends.strftime('%d.%m.%YT%H:%M')
			if datetime.now() > local_ends + timedelta(minutes=15): # 22:30 > 22:00+15m = 22:15
				next_on, runs_on = False, False
		else: runs_on = False if status == 'created' and runs_on is True else runs_on
		teamA = (rsx.get('clubAName', None) or rsx.get('clubATeam', None))
		teamB = (rsx.get('clubBName', None) or rsx.get('clubBTeam', None))
		league = (rsx.get('league', None) or rsx.get('teamAAge', None) or rsx.get('teamBAge', None))
		if teamA and teamB:
			note_1 = translation(30721).format(teamA, teamB)
			if league: note_2 = translation(30722).format(league.title())
			if str(rsx.get('scoreA')).isdecimal() and str(rsx.get('scoreB')).isdecimal(): note_3 = translation(30723).format(rsx['scoreA'], rsx['scoreB'])
			if start_date: note_4 = translation(30724).format(start_full) if status != 'done' else translation(30725).format(start_date)
		duration = int(rsx['durationMin'])*60 if status == 'done' and str(rsx.get('durationMin')).isdecimal() else None
		stream = rsx.get('userStream', None)
		if uuid is None or (start_date and money is True) or (status == 'done' and stream is None):
			excluding = True
		name = f"{start_date} - {title+gender}" if start_date else title+gender
		if status == 'Mission running' and runs_on is True and start_time:
			name = translation(30726).format(start_time, title+gender)
		media = 'VOD' if status == 'done' else 'LIVE'
	return [uuid, species, genre, name, duration, stream, media, starting, airing, money, status, note_1, note_2, note_3, note_4, photo, backdrop, excluding, next_on, runs_on, others]

def play_video(PLID):
	debug_MS("(navigator.play_video) -------------------------------------------------- START = play_video --------------------------------------------------")
	debug_MS(f"(navigator.play_video) ### SOURCE = {config['VIDEO_LINK'].format(PLID)} ###")
	for elem in preserve(WORKS_FILE): # https://content.aisportswatch.com/584327/master.m3u8
		if elem['filtrate'] != '00' and elem['filtrate'] == PLID:
			clear_title, photo, teaser, media = re.sub(r'\[/?B\]', '', elem['name']), elem['photo'], ' ' if elem['teaser'] in ['', 'None', None] else elem['teaser'], elem['media']
			debug_MS(f"(navigator.play_video[1]) ### WORKS_FILE-Line : {elem} ###")
	stream, final_tests, checking, final_works = 'HLS' if prefer_player == 1 else 'M3U8', config['VIDEO_LINK'].format(PLID), 0, False
	while not final_works and checking < 2: # 2 x Pingversuche für den STREAM-Request ::: zur Überprüfung der Verfügbarkeit des Streams
		checking += 1
		try:
			scanning = urlopen(Request(final_tests, None, {**WEB_HEADER, **{'Cache-Control': 'no-cache', 'Accept': '*/*'}}), timeout=10)
			debug_MS(f"(navigator.play_video[1]) === CALL_{stream}_STREAM === RETRIES_no : {checking} === STATUS : {str(scanning.getcode())} || URL : {final_tests} ===")
		except (URLError, HTTPError) as exo:
			failing(f"(navigator.play_video[1]) ERROR - {stream}_STREAM - ERROR ##### RETRIES_no : {checking} === URL : {final_tests} === FAILURE : {exo} #####")
			time.sleep(2)
		else: final_works = final_tests
	if final_works is False:
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		failing(f"(navigator.play_video[2]) ##### Abspielen des Streams NICHT möglich ##### URL : {final_tests} #####\n ########## Der vorhandene Stream-Eintrag auf der Webseite von *https://staige.tv/* ist OFFLINE/DEFEKT !!! ##########")
		return dialog.notification(translation(30521).format('URL'), translation(30527), icon, 10000)
	elif final_works:
		LPM = xbmcgui.ListItem(clear_title, path=f"{final_works}|{urlencode({'User-Agent': WEB_AGENT, 'Referer': BASE_URL}, safe='/:?=&')}", offscreen=True)
		if KODI_BUILD >= 20:
			LPM.getVideoInfoTag().setTitle(clear_title), LPM.getVideoInfoTag().setPlot(teaser), LPM.getVideoInfoTag().setStudios(['Staige.tv'])
		else: LPM.setInfo('Video', {'Title': clear_title, 'Plot': teaser, 'Studio': 'Staige.tv'})
		LPM.setArt({'icon': icon, 'thumb': photo, 'poster': photo})
		if prefer_player == 1 and xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)'):
			IA_NAME = 'inputstream.ffmpegdirect'
			LPM.setMimeType('application/vnd.apple.mpegurl'); LPM.setContentLookup(False); LPM.setProperty('inputstream', IA_NAME)
			LPM.setProperty(f'{IA_NAME}.stream_mode', 'default')
			LPM.setProperty(f'{IA_NAME}.manifest_type', 'hls')
			LPM.setProperty(f'{IA_NAME}.is_realtime_stream', 'true')
			if open_modus != 0:
				LPM.setProperty(f'{IA_NAME}.open_mode', 'ffmpeg' if open_modus == 1 else 'curl')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		log(f"(navigator.play_video) {stream}_stream : {final_works}")
		xbmc.sleep(10000)
		if not xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)') and not xbmc.Player().isPlaying():
			return dialog.notification(translation(30521).format('PLAYER'), translation(30529), icon, 10000)

def list_favorites():
	debug_MS("(navigator.list_favorites) ------------------------------------------------ START = list_favorites -----------------------------------------------")
	if preserve(FAVORIT_FILE) is not None: # Favoriten für Profile/Vereine
		for item in sorted(preserve(FAVORIT_FILE), key=lambda vox: (vox.get('Sector', 'zorro'), clear_umlaut(vox.get('Title', 'zorro')).lower())):
			action = {'mode': 'list_categories', 'link': item.get('Link'), 'stage': item.get('Stage'), 'sector': item.get('Sector'), 'phase': item.get('Phase')}
			fetch_items = context = {'Slug': item.get('Slug'), 'Species': item.get('Species'), 'Title': item.get('Title'), 'Plot': item.get('Plot'), 'Genre': item.get('Stage'),
				'Image': item.get('Image'), 'Fanback': item.get('Fanback'), 'Link': item.get('Link'), 'Stage': item.get('Stage'), 'Sector': item.get('Sector'), 'Phase': item.get('Phase')}
			add_views(action, create_entries(fetch_items), True, context, 'removing')
			debug_MS(f"(navigator.list_favorites[1]) ### NAME : {item.get('Title')} || SLUG : {item.get('Slug')} || IMAGE : {item.get('Image')} || GENRE : {item.get('Sector', 'Sport')} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favorit_construct(**kwargs):
	TOPS = []
	if preserve(FAVORIT_FILE) is not None:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		kwargs.pop('mode', None); kwargs.pop('action', None)
		TOPS.append({key: value for key, value in kwargs.items() if value not in ['', 'None', None]})
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30530), translation(30531).format(kwargs['Title']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Slug') != kwargs.get('Slug')]
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30530), translation(30532).format(kwargs['Title']), icon, 10000)

def add_views(params, listitem, folder=True, context={}, handling='default', higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enable_decrease and higher is True:
		entries.append([translation(30651), f"RunPlugin({build_mass({'mode': 'calling_main'})})"])
	if handling == 'adding' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30653), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
