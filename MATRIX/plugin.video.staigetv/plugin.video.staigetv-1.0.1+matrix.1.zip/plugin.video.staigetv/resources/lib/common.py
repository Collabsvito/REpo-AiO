﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import time
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from calendar import timegm
from urllib.parse import parse_qsl, urlencode, quote, quote_plus, unquote_plus
from urllib.request import urlopen, Request, URLError, HTTPError
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from .external import * # psf_requests, psf_requests.HTTPAdapter
from .provider import Client


socket.setdefaulttimeout(30)
HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_folder						= xbmcvfs.translatePath(addon.getAddonInfo('path'))
addon_profile					= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
SEARCH_FILE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'search_string'))
WORKS_FILE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'episode_data.json'))
FAVORIT_FILE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'favorites_STAIGE.json'))
defaultFanart						= os.path.join(addon_folder, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addon_folder, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addon_folder, 'resources', 'media', '')
basedates							= addon.getSetting('basedates') == 'true'
basesearch							= addon.getSetting('basesearch') == 'true'
prefer_player						= int(addon.getSetting('prefer_player'))
open_modus						= int(addon.getSetting('open_modus'))
enable_decrease				= addon.getSetting('show_homebutton') == 'true'
enable_tune						= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_BUILD						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2])
BASE_URL							= 'https://staige.tv/'
WEB_AGENT						= 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0'
WEB_HEADER					= {'User-Agent': WEB_AGENT, 'Origin': BASE_URL[:-1], 'Referer': BASE_URL, 'Cache-Control': 'public, max-age=300', 'Accept': 'application/json, text/plain, */*', 'DNT': '1', 'Upgrade-Insecure-Requests': '1', 'Accept-Encoding': 'gzip, deflate', 'sec-ch-ua-platform': 'Windows', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8'}
SKY_HEADER						= {**WEB_HEADER, **{'Content-Type': 'application/json; charset=utf-8'}}
genre_lang							= [{'old': 'americanfootball', 'new': 'American Football'},{'old': 'fieldhockey', 'new': 'Feldhockey'},{'old': 'icehockey', 'new': 'Eishockey'},{'old': 'soccer', 'new': 'Fußball'},{'old': 'waterpolo', 'new': 'Wasserball'}]
swaps_vars							= [{'old': 'skyhook.genres', 'new': 'ena_'},{'old': 'skyhook.clubs', 'new': 'clu_'},{'old': 'skyhook.competitions', 'new': 'com_'},{'old': 'skyhook.countries', 'new': 'seg_'},{'old': 'skyhook.inRegion', 'new': 'cit_'},{'old': 'skyhook.teamsAll', 'new': 'tea_'}]
SKY_CLOUD						= 'https://europe-west1-aisw-ww-prod.cloudfunctions.net/api_skyhook_v2_beta'
traversing							= Client(Client.CONFIG_STAIGE)

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def translation(ident):
	return addon.getLocalizedString(ident)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def track_several(stacks, method='GET', queries='JSON', headers={}, timeout=6, workers=20):
	COMBI_NEW, number, counter, fixation = [], len(stacks), 0, psf_requests.Session()
	fixation.mount('https://', psf_requests.HTTPAdapter(pool_connections=int(number), pool_maxsize=int(number), pool_block=True)) # Pool-Verbindungen und -Grösse auf tatsächlichen Inhalt festlegen, um Fehlermeldungen zu vermeiden
	def download(pos, hook, link, code, specs):
		transfer = None if method == 'GET' else specs
		try:
			response = fixation.request(method, link, headers=headers, allow_redirects=True, json=transfer, timeout=timeout)
			response.raise_for_status()
			debug_MS(f"(common.track_several[1]) === POS : {pos} || STATUS : {response.status_code} || MODE : {method} || URL : {link} || HEADER : {response.request.headers} || JSON : {transfer} ===")
			return f'{{"Count_2":{pos},"Hook_2":"{hook}","Link_2":"{link}","Code_2":"{code}",{response.text[1:-1]}}}'
		except Exception as exc_uno:
			failing(f"(common.track_several[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === IDENT : {code} === URL : {link} === FAILURE : {exc_uno} #####")
			return f'{{"Position":{pos},"Status":"ERROR"}}'
	with ThreadPoolExecutor(max_workers=workers) as executor:
		picker = [executor.submit(download, single['Count_1'], single['Hook_1'], single['Link_1'], single['Code_1'], single['Trans_1']) for single in stacks]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for future, section in zip(as_completed(picker), stacks):
			counter += 1
			try:
				COMBI_NEW.append(json.loads(future.result()))
			except Exception as exc_due:
				if counter == 1:
					dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(exc_due), icon, 12000)
				failing(f"(common.track_several[2]) ERROR - EXEPTION - ERROR ##### POS : {section['Count_1']} === IDENT : {section['Code_1']} === URL : {section['Link_1']} === FAILURE : {exc_due} #####")
				executor.shutdown()
		if COMBI_NEW:
			matching = [flop for flop in COMBI_NEW[:] if flop.get('Status', 'OOKAY') == 'ERROR']
			if len(matching) == number or len(matching) > 5:
				dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 12000)
	return json.dumps(COMBI_NEW, indent=2)

def track_content(link, method='GET', queries='JSON', headers={}, redirects=True, data=None, json=None, timeout=30):
	ANSWER = None
	try:
		response = psf_requests.request(method, link, headers=headers, allow_redirects=redirects, data=data, json=json, timeout=timeout)
		response.raise_for_status()
		ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
		debug_MS(f"(common.track_content) === CALLBACK === STATUS : {response.status_code} || MODE : {method} || URL : {response.url} || HEADER : {response.request.headers} || JSON : {json} ===")
		debug_MS("-------------------------------------------------")
	except Exception as exc: # No JSON object could be decoded
		failing(f"(common.track_content) ERROR - EXEPTION - ERROR ##### URL : {link} === FAILURE : {exc} #####")
		dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 12000)
		return sys.exit(0)
	return ANSWER

def convert_region(info): # 2024-05-05T19:10:00Z
	CONVERTED = datetime(*(time.strptime(info[:19], '%Y-%m-%dT%H:%M:%S')[0:6]))
	try:
		LOCAL_DATE = datetime.fromtimestamp(timegm(CONVERTED.timetuple()))
		assert CONVERTED.resolution >= timedelta(microseconds=1)
		LOCAL_DATE = LOCAL_DATE.replace(microsecond=CONVERTED.microsecond)
	except (ValueError, OverflowError): # ERROR on Android 32bit Systems = cannot convert unix timestamp over year 2038
		LOCAL_DATE = datetime.fromtimestamp(0) + timedelta(seconds=timegm(CONVERTED.timetuple()))
		LOCAL_DATE = LOCAL_DATE - timedelta(hours=datetime.timetuple(LOCAL_DATE).tm_isdst)
	return LOCAL_DATE

def preserve(store, action='JSON', facts=None, arrive=None):
	if facts is not None:
		with open(store, 'w') as topics:
			json.dump(facts, topics, indent=2, sort_keys=True) if action == 'JSON' else topics.write(facts)
	else:
		if xbmcvfs.exists(store) and os.path.exists(store) and os.stat(store).st_size > 0:
			with open(store, 'r') as topics:
				arrive = json.load(topics) if action == 'JSON' else topics.read()
		return arrive

def clear_umlaut(changes):
	if changes is not None:
		for cm in (('Ä', 'Ae'), ('ä', 'ae'), ('Ö', 'Oe'), ('ö', 'oe'), ('Ü', 'Ue'), ('ü', 'ue'), ('ß', 'ss')):
			changes = changes.replace(*cm)
		changes = changes.strip()
	return changes

def create_entries(metadata, SIGNS=None):
	listitem = xbmcgui.ListItem(metadata['Title'])
	vinfo = listitem.getVideoInfoTag() if KODI_BUILD >= 20 else {}
	if KODI_BUILD >= 20: vinfo.setTitle(metadata['Title'])
	else: vinfo['Title'] = metadata['Title']
	description = metadata['Plot'] if metadata.get('Plot') not in ['', 'None', None] else ' '
	if KODI_BUILD >= 20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if str(metadata.get('Duration')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setDuration(int(metadata['Duration']))
		else: vinfo['Duration'] = metadata['Duration']
	if metadata.get('Date', ''):
		if KODI_BUILD >= 20: listitem.setDateTime(metadata['Date'])
		else: vinfo['Date'] = metadata['Date']
	if metadata.get('Aired', ''):
		if KODI_BUILD >= 20: vinfo.setFirstAired(metadata['Aired'])
		else: vinfo['Aired'] = metadata['Aired']
	if str(metadata.get('Aired'))[6:10].isdecimal():
		if KODI_BUILD >= 20: vinfo.setYear(int(metadata['Aired'][6:10]))
		else: vinfo['Year'] = metadata['Aired'][6:10]
	if metadata.get('Genre', ''):
		if KODI_BUILD >= 20: vinfo.setGenres([metadata['Genre']])
		else: vinfo['Genre'] = metadata['Genre']
	if metadata.get('Mediatype', ''):
		if KODI_BUILD >= 20: vinfo.setMediaType(metadata['Mediatype'])
		else: vinfo['Mediatype'] = metadata['Mediatype']
	picture = metadata.get('Image', icon)
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'fanart': defaultFanart})
	if metadata.get('Fanback') in ['True', True] and picture and not artpic in picture:
		listitem.setArt({'fanart': picture})
	if metadata.get('Reference') == 'Single':
		listitem.setProperty('IsPlayable', 'true')
	if KODI_BUILD < 20: listitem.setInfo('Video', vinfo)
	return listitem
