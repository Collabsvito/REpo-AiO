﻿# -*- coding: utf-8 -*-

from .common import *


def main_menu():
	for title, thumb, action in [(30601, 'uebersicht', {'mode': 'list_articles', 'link': f"{BASE_URL}video/", 'limit': '2'}), (30602, 'thema', {'mode': 'list_spiegeltv'}),
		(30603, 'panorama', {'mode': 'list_articles', 'link': f"{BASE_URL}panorama/", 'limit': '20'}), (30604, 'ausland', {'mode': 'list_articles', 'link': f"{BASE_URL}ausland/", 'limit': '20'}),
		(30605, 'ukraine', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/russlands-krieg-gegen-die-ukraine-videos/", 'limit': '-3'}),
		(30606, 'deutschland', {'mode': 'list_articles', 'link': f"{BASE_URL}politik/deutschland/", 'limit': '16'}),
		(30607, 'talk', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/spitzengespraech-der-talk-mit-markus-feldenkirchen/", 'limit': '-3'}),
		(30608, 'bestseller', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/spiegel-bestseller-mehr-lesen-mit-elke-heidenreich/"}),
		(30609, 'autotests', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/auto-tests-im-video/", 'limit': '-3'})]:
		add_views(action, create_entries({'Title': translation(title), 'Image': f"{artpic}{thumb}.png"}))
	if youtube_seen:
		add_views({'mode': 'list_playlists'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}youtube.png"}))
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30611), 'Image': f"{artpic}settings.png"}), False)
		if enable_adaptive and plugin_operate('inputstream.adaptive'):
			add_views({'mode': 'ietuning'}, create_entries({'Title': translation(30612), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_spiegeltv():
	for title, thumb, action in [(30621, 'beitraege', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/spiegel-tv/", 'limit': '-3'}),
		(30622, 'magazin', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/spiegel-tv/", 'extra': 'spiegel_tv'}),
		(30623, 'reportage', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/spiegel-tv/", 'extra': 'spiegel_tv_reportage'}),
		(30624, 'arte', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/spiegel-tv/", 'extra': 'spiegel_tv_für_arte_re:'}),
		(30625, 'geld', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/spiegel-tv/", 'extra': 'reden_wir_über_geld'}),
		(30626, 'crime', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/spiegel-tv/", 'extra': 'spiegel_tv_true_crime'}),
		(30627, 'verhoer', {'mode': 'list_articles', 'link': f"{BASE_URL}thema/spiegel-tv/", 'extra': 'im_verhör'})]:
		add_views(action, create_entries({'Title': translation(title), 'Image': f"{genpic}{thumb}.png"}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_articles(target, addition, extra):
	debug_MS("(navigator.list_articles) -------------------------------------------------- START = list_articles --------------------------------------------------")
	debug_MS(f"(navigator.list_articles) ### URL = {target} ### MAX_PAGES = {pagination+int(addition)} ### EXTRA = {extra} ###")
	combo_pages, combo_links, combo_codes, combo_taken, combo_uno, combo_due, combo_tre = ([] for _ in range(7))
	counter, unikat, (merge_uno, merge_due) = 0, set(), ({} for _ in range(2))
	highest = 2 if extra != 'DEFAULT' else pagination+int(addition)
	for ii in range(1, highest, 1):
		next_page = f"{target}p{str(ii)}/" if int(ii) > 1 else target
		debug_MS(f"(navigator.list_articles[1]) THEME-PAGES XXX POS = {str(ii)} || URL = {next_page} XXX")
		combo_pages.append({'Count_1': int(ii), 'Media_1': 'THEME', 'Hook_1': next_page, 'Link_1': next_page})
	if combo_pages:
		debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
		complete = track_several(combo_pages, 'GET', 'TEXT', HEAD_DESP, 4)
		if complete:
			debug_MS("++++++++++++++++++++++++++++++++++++++++++++++")
			for points, medias, hooks, links, tables in sorted(complete, key=lambda fix: int(fix[0])):
				if tables not in ['', None]:
					if extra == 'DEFAULT':
						sections = re.findall(r'data-area="article-teaser-list"(.*?)data-area="pagination-bar"', tables, re.S)
					else:
						sections = re.findall(fr'<section class="relative flex flex-wrap w-full.*?data-size="full" (?:data-first="true" |data-last="true" )?data-area="block>topic:{extra}"(.*?)(?:<section class="relative flex flex-wrap w-full|data-area="article-teaser-list")', tables, re.S)
					for entries in sections:
						postings = re.findall(r'data-block-el="articleTeaser"(.*?)</article>', entries, re.S)
						for article in postings:
							article, code_uno = article.replace('&#34;', '"'), '00'
							(meta_uno, display_uno, plays_uno), (desc_uno, media_uno) = (None for _ in range(3)), ("" for _ in range(2))
							debug_MS(f"(navigator.list_articles[2]) xxxxx ENTRY-02 : {article} xxxxx")
							matchTIE = re.compile(r'<article aria-label="(.*?)" (?:data-|class=)', re.S).findall(article)
							title_uno = cleaning(matchTIE[0]) if matchTIE and len(matchTIE[0]) > 1 else None
							matchNAV = re.compile(r'<a href="([^"]+)" target=', re.S).findall(article)
							hook_uno = matchNAV[0] if matchNAV and matchNAV[0].startswith('http') else None
							if title_uno is None or hook_uno is None or hook_uno in unikat:
								continue
							unikat.add(hook_uno)
							# <img data-image-el="img" class="block lazyload h-full mx-auto" src= || <img data-video-el="poster" class="block lazyload h-full mx-auto" src=
							matchIMG = re.compile(r'<img data-(?:image|video)-el=".*?src="(https://cdn.prod.www.spiegel.de/images[^"]+)"', re.S).findall(article)
							thumb_uno = matchIMG[-1] if matchIMG else None
							# <span class="text-black dark:text-shade-lightest block font-sansUI font-normal leading-normal text-s mb-4" data-target-teaser-el="topmark">
							matchTAG = re.compile(r'data-target-teaser-el="topmark">([^<]+)</', re.S).findall(article)
							tags_uno = cleaning(matchTAG[0]).replace('\n',' ').replace('\t',' ') if matchTAG else None # Lauterbach und das Scholz-Team
							# <span class="font-sansUI font-normal text-s text-shade-darker dark:text-shade-light" data-target-teaser-el="meta">
							matchMET = re.compile(r'data-target-teaser-el="meta">([^<]+)</', re.S).findall(article) # Ein SPIEGEL-TV-Film von Thore Brüggemann
							matchDAT = re.compile(r'<span data-auxiliary>(.*?Uhr)</', re.S).findall(article) # 26. März 2026, 12.58 Uhr
							if matchMET and not 'spitzengespraech' in hook_uno:
								meta_uno = cleaning(re.sub(r'\<.*?\>', '', matchMET[0]))
							if matchDAT and ' Uhr' in matchDAT[0]:
								try: 
									broadcast = cleaning(matchDAT[0])
									for dt in (('Januar', 'Jan'), ('Februar', 'Feb'), ('März', 'Mar'), ('April', 'Apr'), ('Mai', 'May'), ('Juni', 'Jun'), ('Juli', 'Jul'),
										 ('August', 'Aug'), ('September', 'Sep'), ('Oktober', 'Oct'),('November', 'Nov'), ('Dezember', 'Dec')): broadcast = broadcast.replace(*dt)
									converted = datetime(*(time.strptime(broadcast, '%d. %b %Y, %H.%M Uhr')[0:6])) # 26. März 2026, 12.58 Uhr
									display_uno = converted.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
								except: pass
							# <span class="font-hybrid font-normal text-base leading-loose mr-6" data-target-teaser-el="text">
							matchDSC = re.compile(r'data-target-teaser-el="text">(.*?)</', re.S).findall(article) # Beschreibung long
							if matchDSC: desc_uno = cleaning(re.sub(r'\<.*?\>', '', matchDSC[0]))
							# </svg>\n</span>\n<span class="text-white dark:text-shade-lightest font-sansUI text-s font-bold">27:09</span>\n</span> || </svg>\n</span>\n<span>7 Min</span>\n</span>
							matchDUR = re.compile(r'</svg>\s*</span>\s*<spa.*?>([^<]+)</span>\s*</span>', re.S).findall(article)
							dura_uno = get_seconds(matchDUR[0].strip()) if matchDUR else 0
							if re.search(r'data-contains-flags="Spplus-paid"', article): continue # SpiegelPlus-Beitrag nur mit ABO abrufbar
							elif re.search(r'<span data-icon-auxiliary="Video"', article):
								mark_uno = re.compile(r'data-component="Video" data-settings=.*?,"(?:jwplayerMedia|media)Id":"([^"]+)",', re.S).findall(article)
								plays_uno = f"https://cdn.jwplayer.com/v2/media/{mark_uno[0]}?poster_width=1280&sources=hls,dash,mp4" if mark_uno else None
								media_uno, code_uno = 'VIDEO', mark_uno[0] if mark_uno else '00'
							elif re.search(r'<span data-icon-auxiliary="Audio"', article):
								if not audiostreams: continue # Audioeinträge ausblenden wenn Audio in den Settings ausgeschaltet ist 
								media_uno, code_uno = 'AUDIO', '00'
							else: continue # KEIN Playsymbol (Audio/Video) im ICON gefunden !!!
							counter += 1
							combo_uno.append({'Count_1': int(counter), 'Media_1': media_uno, 'Code_1': code_uno, 'Hook_1': hook_uno, 'Title_1': title_uno,
								'Tags_1': tags_uno, 'Story_1': desc_uno, 'Meta_1': meta_uno, 'Display_1': display_uno, 'Dura_1': dura_uno, 'Thumb_1': thumb_uno})
							if plays_uno is None and hook_uno:
								combo_links.append({'Count_1': int(counter), 'Media_1': media_uno, 'Hook_1': hook_uno, 'Link_1': hook_uno})
							elif plays_uno and hook_uno:
								combo_codes.append({'Count_1': int(counter), 'Media_1': media_uno, 'Hook_1': hook_uno, 'Link_1': plays_uno})
	if combo_uno:
		if combo_links: combo_taken, combo_due = _fetch_pages(combo_links)
		merge_uno = [{**uno, **next(iter([due for due in combo_due if due.get('Hook_2') == uno.get('Hook_1')]), {})} for uno in combo_uno] # Merge List1 and List2 (dictionaries) by specific value if value exists else only List1 !!!
		combo_tre = _fetch_details(combo_taken+combo_codes) if combo_taken or combo_codes else combo_tre
		merge_due = [{**uno, **next(iter([tre for tre in combo_tre if tre.get('Hook_3') == uno.get('Hook_1')]), {})} for uno in merge_uno] # Merge List1 and List3 (dictionaries) by specific value if value exists else only List1 !!!
		if courses == 0 or any(rider.get('Sort_3') == '2026-01-01T00:01' for rider in merge_due):
			transition = sorted(merge_due, key=lambda nox: int(nox.get('Count_1', 1)))
		else: transition = sorted(merge_due, key=lambda nox: nox.get('Sort_3', '2026-01-01T00:01')[:16], reverse=True)
		for post in transition: # Liste1 = 11 || Liste2 = 4 || Liste3 = 10
			if len(post) < 20: continue # Weniger als 20 Einträge es fehlt Liste3 - daher ausblenden
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ")
			notice = {key: value for key, value in post.items() if key[:5] != 'Story'}
			debug_MS(f"(navigator.list_articles[5]) ##### Anzahl = {len(post)} || Eintrag : {notice} #####")
			(aired, year), (start_date, note_1, note_2, note_3, note_4, note_5) = (None for _ in range(2)), ("" for _ in range(6))
			identity = post['Code_1'] if post.get('Code_1') != '00' else post.get('Code_3')
			note_1 = translation(30641).format(post['Meta_1']) if post.get('Meta_1') else ""
			if post.get('Display_1') or post.get('Display_3'):
				start_date = post['Display_3'] if post.get('Display_3') else post.get('Display_1')
				note_2 = translation(30642).format(start_date) if post.get('Media_1') == 'AUDIO' else translation(30643).format(start_date)
				aired, year = start_date[0:10].replace('-', '.'), start_date[6:10]
			note_3 = '[CR]' if note_1 != "" or note_2 != "" else ""
			note_4 = post['Story_3'] if post.get('Story_3') and len(post.get('Story_3')) > len(post.get('Story_1')) else post.get('Story_1')
			note_5 = '[COLOR magenta] ♫[/COLOR]' if post.get('Media_1') == 'AUDIO' else ""
			plot = note_1+note_2+note_3+note_4
			naming = post.get('Title_1')+note_5
			duration = post['Dura_3'] if post.get('Dura_3') not in [0, None] else post.get('Dura_1')
			image = post['Thumb_3'] if post.get('Thumb_3') else post.get('Thumb_1')
			debug_MS(f"(navigator.list_articles[5]) ##### COUNT : {post.get('Count_1')} || NAME : {naming} || mediaID : {identity} || DATE : {start_date} #####")
			debug_MS(f"(navigator.list_articles[5]) ##### TAGLINE : {post.get('Tags_1')} || DURATION : {duration} || THUMB : {image} #####")
			fetch_items = create_entries({'Title': naming, 'Tagline': post.get('Tags_1'), 'Plot': plot, 'Duration': duration, \
				'Date': post.get('Date_3'), 'Aired': aired, 'Year': year, 'Genre': 'News', 'Mediatype': 'movie', 'Image': image, 'Reference': 'Single'})
			add_views({'mode': 'play_media', 'slug': identity}, fetch_items, False)
	else:
		debug_MS(f'(navigator.list_articles[4]) ##### NO ARTICLES-LIST - NO ENTRY FOR THIS: "{target}" FOUND #####')
		return dialog.notification(translation(30521).format('ARTICLE'), translation(30523).format(target), icon, 10000)
	xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def _fetch_pages(templates, primodo=[], secondo=[]):
	debug_MS("(navigator.fetch_pages) -------------------------------------------------- START = fetch_pages --------------------------------------------------")
	package = track_several(templates, 'GET', 'TEXT', HEAD_DESP, 4)
	if package:
		debug_MS("++++++++++++++++++++++++++++++++++++++++++++++")
		for scraps in package:
			if len(scraps) == 5 and scraps[4] is not None:
				areas, omny_clear, plays_due = (None for _ in range(3))
				if scraps[1] == 'VIDEO':
					areas = re.compile(r'<div data-component="(?:JWPlayer|Video)" data-settings=(.*?)" class="', re.S).findall(scraps[4])
					code_due = re.compile(r'"(?:jwplayerMedia|media)Id":"([^"]+)",', re.S).findall(areas[0].replace('&#34;', '"')) if areas else None
					plays_due = f"https://cdn.jwplayer.com/v2/media/{code_due[0]}?poster_width=1280&sources=hls,dash,mp4" if code_due else None
				elif scraps[1] == 'AUDIO':
					areas = re.compile(r'(?:<div data-area="presentation_element>podlove">|<aside aria-label="Artikel zum Hören")(.*?)(?:<span class="|data-area="playlist_button")', re.S).findall(scraps[4])
					omny_keys = re.compile(r'x-audio-omny="([^"]+)"', re.S).findall(areas[0]) if areas else None
					omny_clear = base64.b64decode(omny_keys[0]).decode() if omny_keys else None
					code_due = re.compile(r'"omnystudioClipId":"([^"]+)",', re.S).findall(omny_clear.replace('&#34;', '"')) if omny_clear else None
					plays_due = f"https://omny.fm/api/orgs/{COMPANY_ID}/clips/{code_due[0]}" if code_due else None
				contents = areas[0].replace('&#34;', '"') if areas else 'EntryNotFound'
				debug_MS(f"(navigator.fetch_pages[3]) ### COUNT-02 : {scraps[0]} || PLAY-02 : {scraps[1]} || EACH-02 : {contents} ###")
				if plays_due and scraps[3]:
					primodo.append({'Count_1': int(scraps[0]), 'Media_1': scraps[1], 'Hook_1': scraps[2], 'Link_1': plays_due})
					secondo.append({'Count_2': int(scraps[0]), 'Media_2': scraps[1], 'Hook_2': scraps[2], 'Link_2': plays_due})
	return primodo, secondo

def _fetch_details(news, terzondo=[]):
	debug_MS("(navigator.fetch_details) -------------------------------------------------- START = fetch_details --------------------------------------------------")
	bundles = track_several(news, 'GET', 'JSON', HEAD_DESP, 3)
	if bundles:
		for elem in json.loads(bundles):
			if elem is not None and ((elem.get('playlist', {}) and len(elem['playlist']) > 0) or (elem.get('Slug', ''))):
				(thumb_tre, display_tre, starting), sorting = (None for _ in range(3)), '2026-01-01T00:01'
				pos_tre, media_tre, hook_tre, link_tre = elem['Count_2'], elem['Media_2'], elem['Hook_2'], elem['Link_2']
				short = elem['playlist'][0] if 'playlist' in elem and len(elem.get('playlist', [])[0]) > 0 else elem
				code_tre = (short.get('mediaid', '') or short.get('Id', '') or 'Unknown-ID')
				title_tre = (cleaning(short.get('title')) or cleaning(short.get('Title')))
				thumb_tre = short.get('image', None)
				if thumb_tre is None and short.get('images', '') and len(short['images']) > 0:
					thumb_tre = [vid.get('src', []) for vid in short.get('images', {}) if vid.get('type')[:5] == 'image'][-1]
				published = (short.get('pubdate', None) or short.get('PublishedUtc', None))
				if published and str(published).isdecimal():
					local_start = convert_region(datetime(1970, 1, 1) + timedelta(seconds=published))
					display_tre = local_start.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
					sorting = local_start.strftime('%Y-%m-%dT%H:%M')
					starting = local_start.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else local_start.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
				elif published and not str(published).isdecimal():
					local_start = convert_region(published, 'DATETIME')
					display_tre = local_start.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
					sorting = local_start.strftime('%Y-%m-%dT%H:%M')
					starting = local_start.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else local_start.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
				desc_tre = (cleaning(short.get('description', '')) or cleaning(short.get('Description', '')))
				dura_tre = (short.get('duration', 0) or short.get('DurationSeconds', 0))
				if dura_tre != 0: dura_tre = "{0:.0f}".format(dura_tre)
				specifics = {'Count_3': int(pos_tre), 'Code_3': code_tre, 'Hook_3': hook_tre, 'Title_3': title_tre, 'Story_3': desc_tre,
					'Sort_3': sorting, 'Date_3': starting, 'Display_3': display_tre, 'Dura_3': dura_tre, 'Thumb_3': thumb_tre}
				debug_MS("++++++++++++++++++++++++++++++++++++++++++++++")
				debug_MS(f"(navigator.fetch_details[4]) ### COUNT-03 : {pos_tre} || PLAY-03 : {media_tre} || ELEM-03 : {specifics} ###")
				terzondo.append(specifics)
	return terzondo

def list_playlists():
	debug_MS("(navigator.list_playlists) ------------------------------------------------ START = list_playlists -----------------------------------------------")
	if pers_token == 'AIzaSy.................................':
		return dialog.ok(addon_id, translation(30350))
	elif pers_token[:6] != 'AIzaSy':
		return dialog.ok(addon_id, translation(30503))
	add_views({'link': BASE_YOUT.format(CANAL_CODE, f'UU{CANAL_CODE[2:]}'), 'extra': 'YT_FOLDER'}, create_entries({'Title': translation(30631), 'Plot': 'Neue Uploads: DER SPIEGEL'}))
	target = f"https://youtube.googleapis.com/youtube/v3/playlists?part=snippet,contentDetails&channelId={CANAL_CODE}&maxResults=50&key={pers_token}"
	scrolling, next_page = 1, None
	while scrolling > 0:
		contents = track_content(target if scrolling == 1 else next_page, 'GET', 'JSON', HEAD_TUBE)
		for item in contents.get('items', []):
			if item.get('kind', '') == 'youtube#playlist':
				debug_MS(f"(navigator.list_playlists[1]) xxxxx ENTRY-01 : {item} xxxxx")
				debug_MS("----------------------------------------------")
				title, yout_video = cleaning(item['snippet']['title']), item.get('id', None)
				plot = (cleaning(item['snippet'].get('description', '')) or 'Offizieller YouTube Kanal von SPIEGEL TV und DER SPIEGEL')
				photo = (item['snippet']['thumbnails'].get('maxres', {}).get('url', '') or item['snippet']['thumbnails'].get('standard', {}).get('url', '') or item['snippet']['thumbnails'].get('high', {}).get('url', ''))
				numbers = item['contentDetails']['itemCount'] if item.get('contentDetails', '') and str(item['contentDetails'].get('itemCount')).isdecimal() else None
				if isinstance(numbers, int) and int(numbers) == 0: continue
				name = translation(30632).format(title) if numbers is None else translation(30633).format(title, numbers)
				fetch_plays = create_entries({'Title': name, 'Plot': f'Playlist: {plot}', 'Image': photo})
				add_views({'link': BASE_YOUT.format(CANAL_CODE, yout_video), 'extra': 'YT_FOLDER'}, fetch_plays)
		if contents.get('nextPageToken', None):
			next_page, scrolling = f"{target}&pageToken={contents['nextPageToken']}", scrolling.__add__(1)
			debug_MS(f"(navigator.list_playlists[2]) PAGES ### NOW GET NEXTPAGE : {next_page} ###")
		else: break
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def play_media(source_id):
	debug_MS("(navigator.play_media) -------------------------------------------------- START = play_media --------------------------------------------------")
	MEDIAS = [] # https://omny.fm/api/orgs/5ac1e950-45c7-4eb7-87c0-aa0f018441b8/clips/6a92c18a-3ce2-49a4-9c87-b01a0144dadc
	M3U8_FILE, STREAM, QUALITY, FINAL_URL = (False for _ in range(4)) # https://cdn.jwplayer.com/v2/media/ed2L0yL7?sources=hls,dash,mp4
	new_link = f"https://cdn.jwplayer.com/v2/media/{source_id}?sources=hls,dash,mp4" if len(source_id) < 18 else f"https://omny.fm/api/orgs/{COMPANY_ID}/clips/{source_id}"
	debug_MS(f"(navigator.play_media) ### SOURCE_URL = {new_link} ###")
	contents = track_content(new_link, headers=HEAD_DESP)
	if new_link.startswith('https://cdn.jwplayer') and contents.get('playlist', '') and contents.get('playlist', {})[0].get('sources', ''):
		for asset in contents['playlist'][0]['sources']:
			delivery = (asset.get('type', '') or 'unknown')
			variable = (asset.get('file', None) or None)
			if delivery.lower() in ['application/x-mpegurl', 'application/vnd.apple.mpegurl'] and variable and 'm3u8' in variable:
				M3U8_FILE = variable
			if delivery.lower() == 'video/mp4' and variable and 'mp4' in variable:
				height = (asset.get('height', 0) or 0)
				MEDIAS.append({'url': variable, 'mimeType': delivery.lower(), 'height': height})
				MEDIAS = sorted(MEDIAS, key=lambda xs: int(xs['height']), reverse=True)
		if MEDIAS: debug_MS(f"(navigator.play_media[1]) SORTED_LIST | MPP4 ### MEDIAS : {MEDIAS} ###")
		if (enable_adaptive or prefer_stream == 0) and (M3U8_FILE or MEDIAS):
			STREAM = 'HLS' if enable_adaptive else 'M3U8'
			if M3U8_FILE:
				MIME, QUALITY, FINAL_URL = 'application/vnd.apple.mpegurl', 'AUTO', M3U8_FILE
			elif MEDIAS and 'videos/' in MEDIAS[0]['url']: # https://cdn.jwplayer.com/videos/n1QbH5SV-b8Tmknhy.mp4 // https://docs.jwplayer.com/platform/reference/get_manifests-media-id-manifest-extension
				MIME, QUALITY, FINAL_URL = 'application/vnd.apple.mpegurl', 'BUILD', f"https://cdn.jwplayer.com/manifests/{MEDIAS[0]['url'].split('videos/')[1][:8]}.m3u8"
			if FINAL_URL: debug_MS(f"(navigator.play_media[2]) ***** TAKE - {'Inputstream (hls)' if STREAM == 'HLS' else 'Standard (m3u8)'} - FILE *****")
		if not FINAL_URL and MEDIAS:
			debug_MS(f"(navigator.play_media[3]) ***** TAKE - (mp4) - FILE : {MEDIAS[0]['url']} *****")
			QUALITY = f"{str(MEDIAS[0]['height'])}p" if MEDIAS[0]['height'] != 0 else 'Unknown'
			STREAM, MIME, FINAL_URL = 'MP4', 'video/mp4', MEDIAS[0]['url']
	elif new_link.startswith('https://omny.fm') and contents.get('AudioUrl', ''):
		actual_timer = int(round(time.time())) # UTC Datetime now
		debug_MS(f"(navigator.play_media[1]) ***** TAKE - (mp3) - FILE : {contents['AudioUrl']}?d={str(actual_timer)}&utm_source=CustomPlayer1 *****")
		STREAM, MIME, QUALITY, FINAL_URL = 'MP3', 'audio/mp3', 'AUTO', f"{contents['AudioUrl']}?d={str(actual_timer)}&utm_source=CustomPlayer1"
	if FINAL_URL and STREAM:
		LSM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		LSM.setMimeType(MIME)
		if plugin_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			IA_NAME = 'inputstream.adaptive'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			LSM.setContentLookup(False); LSM.setProperty('inputstream', IA_NAME)
			if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", STREAM.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
			LSM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={WEB_AGENT}") # 'Without this rejected the Stream and ERROR 403 appears on KODI 21.3
			LSM.setProperty(f"{IA_NAME}.{PHRASE}_headers", f"User-Agent={WEB_AGENT}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
			if int(IA_VERSION) >= 2150:
				LSM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.play_media) [{QUALITY}] {STREAM}_stream : {FINAL_URL} ")
	else:
		failing(f"(navigator.play_media) ##### Abspielen des Streams NICHT möglich ##### URL : {new_link} #####\n ########## KEINEN passenden Stream-Eintrag gefunden !!! ##########")
		return dialog.notification(translation(30521).format('PLAYER'), translation(30527), icon, 8000)

def add_views(params, listitem, folder=True):
	uws = params.get('link') if params.get('extra') == 'YT_FOLDER' else build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
