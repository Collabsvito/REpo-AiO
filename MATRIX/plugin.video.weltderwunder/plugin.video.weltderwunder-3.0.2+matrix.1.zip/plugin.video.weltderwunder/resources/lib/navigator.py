﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
from urllib.parse import urlencode
from urllib.request import urlopen

from .common import *
from .external.scrapetube import *


def listPlaylists():
	addDir(translation(30601), icon, {'url': BASE_YT.format(CHANNEL_CODE, 'UUBk6ZmyoyX1kLl-w17B0V1A'), 'extras': 'YT_FOLDER'}, tag='Neu: Welt der Wunder')
	playlists = get_videos('https://www.youtube.com/{}/playlists'.format(CHANNEL_NAME), 'https://www.youtube.com/youtubei/v1/browse', 'gridPlaylistRenderer', None, 1) # mit "get_videos" die Playlisten eines Channels abrufen
	for item in playlists:
		#log("(navigator.listPlaylists) XXXXX ENTRY : {0} XXXXX".format(str(item)))
		title = cleaning(item['title']['runs'][0]['text'])
		PID = item['playlistId']
		photo = item['thumbnail']['thumbnails'][0]['url'].split('?sqp=')[0].replace('hqdefault', 'maxresdefault')
		if title.lower().startswith(('jobs', 'mystery', 'krimi', 'schau ')):
			photo = item['thumbnail']['thumbnails'][0]['url'].split('?sqp=')[0]
		numbers = str(item['videoCountText']['runs'][0]['text']) if item.get('videoCountText', '') and item['videoCountText'].get('runs', '') and item['videoCountText']['runs'][0].get('text', '') else None
		name = translation(30602).format(title, numbers) if numbers is not None else translation(30603).format(title)
		addDir(name, photo, {'url': BASE_YT.format(CHANNEL_CODE, PID), 'extras': 'YT_FOLDER'}, tag='Playlist: Offizieller YouTube Kanal von Welt der Wunder TV')
	addDir(translation(30604), artpic+'livestream.png', {'mode': 'playLIVE', 'url': BASE_URL+'live-tv/'}, tag='Das Live-TV-Programm von Welt der Wunder TV als Live-Stream im Internet', folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, updateListing=True, cacheToDisc=False)

def playLIVE(url):
	live_url = False
	try:
		content = getUrl(url).replace('\/', '/').replace('&quot;', '"')
		stream = re.compile('data-item="\{"sources":\[\{"src":"(https:[^"]+?)","type":"application', re.DOTALL).findall(content)[0]
		code = urlopen(stream, timeout=6).getcode()
		if str(code) == '200': live_url = stream
	except: pass
	if live_url:
		log("(navigator.playLIVE) ### LiveURL : {0} ###".format(live_url))
		LTM = xbmcgui.ListItem(path=live_url, label=translation(30641))
		LTM.setMimeType('application/x-mpegurl')
		if ADDON_operate('inputstream.adaptive') and 'm3u8' in live_url:
			LTM.setProperty('inputstream', 'inputstream.adaptive')
			LTM.setProperty('inputstream.adaptive.manifest_type', 'hls')
			LTM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
		xbmc.Player().play(item=live_url, listitem=LTM)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Live-Stream-Eintrag auf der Webseite von *weltderwunder.de* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('LIVE'), translation(30525), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def addDir(name, image, params={}, tag='...', folder=True):
	if params.get('extras') == 'YT_FOLDER': u = params.get('url')
	else: u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setTagLine(tag), videoInfoTag.setStudios(['weltderwunder.de'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Tagline': tag, 'Studio': 'weltderwunder.de'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
