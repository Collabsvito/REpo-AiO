﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2026 realvito

    SPORTEUROPE.TV (light)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib.common import *
from resources.lib import navigator
params = dict(parse_qsl(sys.argv[2][1:]))


def run():
	if params:
		if params['mode'] == 'create_account':
			navigator.create_account()
		elif params['mode'] == 'erase_account':
			navigator.erase_account()
		elif params['mode'] == 'list_selection':
			navigator.list_selection(params['Link'], params.get('Page', 1), params.get('Limit', 20), params.get('Wanted', 4))
		elif params['mode'] == 'list_sports':
			navigator.list_sports(params['Link'], params.get('Code', ''), params.get('Sector', 'Sport'), params.get('Page', 1), params.get('Limit', 20), params.get('Wanted', 4), params.get('Extras', 'standard'), params.get('Name', 'Unknown'))
		elif params['mode'] == 'list_categories':
			navigator.list_categories(params['Slug'], params['Code'], params.get('Sector', 'Sport'), params.get('Page', 1), params.get('Limit', 20), params.get('Wanted', 4), params.get('Extras', 'standard'), params.get('Title', 'Unknown'))
		elif params['mode'] == 'search_euro':
			navigator.search_euro(params.get('Extras', 'Standard'))
		elif params['mode'] == 'list_videos':
			navigator.list_videos(params['Link'], params.get('Sector', 'Sport'), params.get('Page', 1), params.get('Limit', 20), params.get('Meter', 0), params.get('Kicked', 0), params.get('Wanted', 4), params.get('Extras', 'standard'))
		elif params['mode'] == 'play_video':
			navigator.play_video(params['Link'])
		elif params['mode'] == 'list_favorites':
			navigator.list_favorites()
		elif params['mode'] == 'favorit_construct':
			navigator.favorit_construct(**params)
		elif params['mode'] == 'calling_main':
			navigator.main_menu()
			xbmc.executebuiltin(f"Container.Update({HOST_AND_PATH}, replace)")
			return sys.exit(0)
		elif params['mode'] == 'blankFUNC':
			pass # do nothing
		elif params['mode'] == 'antuning':
			addon.openSettings()
			xbmc.executebuiltin('Container.Refresh')
		elif params['mode'] == 'ietuning':
			xbmcaddon.Addon('inputstream.adaptive').openSettings()
	else: ##### Delete old Files in Userdata-Folder 'settings' to cleanup old Entries #####
		DONE = False ##### [plugin.video.sporteurope.tv v.3.0.2] - 04.10.26 #####
		firstSCRIPT = xbmcvfs.translatePath(os.path.join(f"special://home{os.sep}addons{os.sep}{addon_id}{os.sep}lib{os.sep}")).encode('utf-8').decode('utf-8')
		UNO = xbmcvfs.translatePath(os.path.join(firstSCRIPT, 'only_at_FIRSTSTART'))
		if xbmcvfs.exists(UNO):
			SOURCE = xbmcvfs.translatePath(os.path.join(f"special://home{os.sep}userdata{os.sep}addon_data{os.sep}{addon_id}{os.sep}")).encode('utf-8').decode('utf-8')
			if xbmcvfs.exists(SOURCE):
				try:
					xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{addon_id}","enabled":false}}}}')
					shutil.rmtree(SOURCE, ignore_errors=True)
				except: pass
				xbmcvfs.delete(UNO)
				xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{addon_id}","enabled":true}}}}')
				xbmc.sleep(500)
				DONE = True
			else:
				xbmcvfs.delete(UNO)
				xbmc.sleep(500)
				DONE = True
		else:
			DONE = True
		if DONE is True:
			if not xbmcvfs.exists(os.path.join(addon_profile, 'settings.xml')):
				xbmcvfs.mkdirs(addon_profile)
				xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")
			navigator.main_menu()

run()
