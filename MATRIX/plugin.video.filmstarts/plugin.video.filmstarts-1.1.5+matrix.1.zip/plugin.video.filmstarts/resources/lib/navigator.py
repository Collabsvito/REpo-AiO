﻿# -*- coding: utf-8 -*-

from .common import *


def main_menu():
	for title, action in [(30601, {'mode': 'blankFUNC', 'link': '00'}), (30602, {'mode': 'list_trailers', 'phase': 'MOVIES'}),
		(30603, {'mode': 'list_broadcasts', 'phase': 'MOVIES'}), (30604, {'mode': 'blankFUNC', 'link': '00'}), (30605, {'mode': 'list_trailers', 'phase': 'SERIES'}),
		(30606, {'mode': 'list_broadcasts', 'phase': 'SERIES'}), (30607, {'mode': 'list_videos', 'link': f"{BASE_URL}/trailer/interviews/", 'phase': 'INTERVIEWS'})]:
		add_views(action, create_entries({'Title': translation(title)}), folder=False if title in [30601, 30604] else True)
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30608), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_trailers(phase):
	if phase == 'MOVIES':
		for item in [{'name': 30621, 'turn': 'list_videos', 'slug': '/trailer/beliebteste.html'},{'name': 30622, 'turn': 'list_videos', 'slug': '/trailer/imkino/'},
			{'name': 30623, 'turn': 'list_videos', 'slug': '/trailer/bald/'},{'name': 30624, 'turn': 'list_videos', 'slug': '/trailer/neu/'},{'name': 30625, 'turn': 'filtrating', 'slug': '/trailer/filme/archiv/'}]:
			add_views({'mode': item['turn'], 'link': f"{BASE_URL}{item['slug']}", 'phase': 'ARCHIVES' if item['name'] == 30625 else 'TRAILERS'}, create_entries({'Title': translation(item['name'])}))
	else:
		for item in [{'name': 30626, 'turn': 'list_videos', 'slug': '/trailer/serien/kurz/'},{'name': 30627, 'turn': 'list_videos', 'slug': '/trailer/serien/meisterwartete/'},
			{'name': 30628, 'turn': 'list_videos', 'slug': '/trailer/serien/neueste/'},{'name': 30629, 'turn': 'filtrating', 'slug': '/trailer/serien/archiv/'}]:
			add_views({'mode': item['turn'], 'link': f"{BASE_URL}{item['slug']}", 'phase': 'ARCHIVES' if item['name'] == 30629 else 'TRAILERS'}, create_entries({'Title': translation(item['name'])}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_broadcasts(phase):
	if phase == 'MOVIES':
		for item in [{'name': 30631, 'turn': 'list_videos', 'slug': '/filme-imkino/vorpremiere/'},
			{'name': 30632, 'turn': 'list_videos', 'slug': '/filme-imkino/kinostart/'},{'name': 30633, 'turn': 'list_videos', 'slug': '/filme-imkino/neu/'},
			{'name': 30634, 'turn': 'list_videos', 'slug': '/filme-imkino/besten-filme/user-wertung/'},{'name': 30635, 'turn': 'selection_weeks', 'slug': '/filme-vorschau/de/'},
			{'name': 30636, 'turn': 'filtrating', 'slug': '/kritiken/filme-alle/user-wertung/'},{'name': 30637, 'turn': 'filtrating', 'slug': '/kritiken/filme-alle/'}]:
			add_views({'mode': item['turn'], 'link': f"{BASE_URL}{item['slug']}", 'phase': 'MOVIES' if item['name'] in [30636, 30637] else 'standard'}, create_entries({'Title': translation(item['name'])}))
	else:
		for item in [{'name': 30641, 'turn': 'list_videos', 'slug': '/serien/top/'},{'name': 30642, 'turn': 'filtrating', 'slug': '/serien/beste/'},
			{'name': 30643, 'turn': 'list_videos', 'slug': '/serien/neue/meisterwartete/'},{'name': 30644, 'turn': 'list_videos', 'slug': '/serien/kommende-staffeln/meisterwartete/'},
			{'name': 30645, 'turn': 'list_videos', 'slug': '/serien/kommende-staffeln/'},{'name': 30646, 'turn': 'list_videos', 'slug': '/serien/kommende-staffeln/demnaechst/'},
			{'name': 30647, 'turn': 'list_videos', 'slug': '/serien/neue/'},{'name': 30648, 'turn': 'filtrating', 'slug': '/serien-archiv/'}]:
			add_views({'mode': item['turn'], 'link': f"{BASE_URL}{item['slug']}", 'phase': 'SERIES' if item['name'] in [30642, 30648] else 'standard'}, create_entries({'Title': translation(item['name'])}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def filtrating(target, phase):
	debug_MS("(navigator.filtrating) -------------------------------------------------- START = filtrating --------------------------------------------------")
	debug_MS(f"(navigator.filtrating) ### URL = {target} ### PHASE = {phase} ###")
	if not 'genre-' in target:
		add_views({'mode': 'selection_posts', 'link': target, 'phase': phase, 'extra': 'Nach Genre'}, create_entries({'Title': translation(30801)}))
	if phase == 'ARCHIVES' and not 'sprache-' in target:
			add_views({'mode': 'selection_posts', 'link': target, 'phase': phase, 'extra': 'Nach Sprache'}, create_entries({'Title': translation(30802)}))
	if phase == 'ARCHIVES' and not 'format-' in target:
			add_views({'mode': 'selection_posts', 'link': target, 'phase': phase, 'extra': 'Nach Typ'}, create_entries({'Title': translation(30803)}))
	if phase != 'ARCHIVES' and not 'jahrzehnt' in target:
			add_views({'mode': 'selection_posts', 'link': target, 'phase': phase, 'extra': 'Nach Produktionsjahr'}, create_entries({'Title': translation(30804)}))
	if phase != 'ARCHIVES' and not 'produktionsland' in target:
			add_views({'mode': 'selection_posts', 'link': target, 'phase': phase, 'extra': 'Nach Land'}, create_entries({'Title': translation(30805)}))
	add_views({'mode': 'list_videos', 'link': target, 'phase': phase}, create_entries({'Title': translation(30806)}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selection_posts(target, phase, extra):
	debug_MS("(navigator.selection_posts) -------------------------------------------------- START = selection_posts --------------------------------------------------")
	debug_MS(f"(navigator.selection_posts) ### URL = {target} ### PHASE = {phase} ### TYPE = {extra} ###")
	block_table = track_content(target, headers=WEB_HEADER)
	results = block_table[block_table.find(f'class="filter-entity-word" data-name="{extra}"')+1:]
	results = results[:results.find('</ul>')]
	part = results.split('class="filter-entity-item"')
	for i in range(1, len(part), 1):
		entry = re.sub(r'</?strong>', '', part[i])
		matchLN1 = re.compile(r'''class=["']item-content["'] href=["']([^"']+)["'] title=[^>]*>([^<]+)</a>''', re.S).findall(entry)
		matchLN2 = re.compile(r'''<span class=["']ACr([^"']+) item-content["'] title=[^>]*>([^<]+)</span>''', re.S).findall(entry)
		links = BASE_URL+matchLN1[0][0] if matchLN1 else BASE_URL+convert64(matchLN2[0][0])
		names = cleaning(matchLN1[0][1]) if matchLN1 else cleaning(matchLN2[0][1])
		matchNUM = re.compile(r'''<span class=["']light["']>\(([^<]+)\)</span>''', re.S).findall(entry)
		if matchNUM: names += translation(30831).format(str(matchNUM[0].strip()))
		add_views({'mode': 'filtrating', 'link': links, 'phase': phase}, create_entries({'Title': names}))
		debug_MS(f"(navigator.selection_posts[1]) ##### NAME : {names} || LINK : {links} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selection_weeks(target):
	debug_MS("(navigator.selection_weeks) -------------------------------------------------- START = selection_weeks --------------------------------------------------")
	debug_MS(f"(navigator.selection_weeks) ### URL = {target} ###")
	block_table = track_content(target, headers=WEB_HEADER)
	results = block_table[block_table.find('<div class="pagination pagination-select">')+1:]
	results = results[:results.find('<span class="txt">Nächste</span><i class="icon icon-right icon-arrow-right-a">')]
	matchOPT = re.compile(r'''<option value=["']ACr([^"']+)["']([^<]+)</option>''', re.S).findall(results)
	for linkway, title in matchOPT:
		links = BASE_URL+convert64(linkway)
		dates = re.sub(r'filme-vorschau/de/week-|/', '', linkway)
		names = translation(30832).format(cleaning(title.replace('>', '').replace('selected', ''))) if 'selected' in title else cleaning(title.replace('>', ''))
		add_views({'mode': 'list_videos', 'link': links, 'phase': 'PREVIEWS'}, create_entries({'Title': names}))
		debug_MS(f"(navigator.selection_weeks[1]) ##### NAME : {names} || DATE : {dates} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_videos(target, page, number, phase):
	debug_MS("(navigator.list_videos) -------------------------------------------------- START = list_videos --------------------------------------------------")
	unikat, merging, counter, (combo_links, combo_uno, combo_due, combo_send) = set(), {}, 0, ([] for _ in range(4))
	new_url = f"{target}?page={page}" if int(page) > 1 else target
	debug_MS(f"(navigator.list_videos) ### URL = {new_url} ### PAGE = {page} ### POSITION = {number} ### PHASE = {phase} ###")
	block_table = track_content(new_url, headers=WEB_HEADER)
	highlights = True if int(page) > 1 else False
	if enable_decrease and button_place == 0 and highlights is True:
		add_views({'mode': 'calling_main'}, create_entries({'Title': translation(30833), 'Image': f"{artpic}backmain.png"}))
	agreePGS = re.findall(r'''<nav class=["']pagination(.+?)<div class=["']mdl-rc["']>''', block_table, re.S)
	if int(number) == 0 and agreePGS:
		sites_uno = re.compile(r'''<a class=["']button button-md item["'] href=.+?page=[0-9]+["']>([0-9]+)</a></div></nav>''', re.S).findall(agreePGS[0])
		sites_due = re.compile(r'''<span class=["']ACr.+?button-md item["']>([0-9]+)</span></div></nav>''', re.S).findall(agreePGS[0])
		number = sites_uno[0] if sites_uno else sites_due[0] if sites_due else number
		debug_MS(f"(navigator.list_videos[1]) NEXTPAGES ~~~ Pages-Maximum : {number} ~~~")
	results = block_table[block_table.find('<main class="content-layout cf"\s*id="main-content"')+1:]
	results = results[:results.find('<div class="mdl-rc">')]
	part = results.split('<figure class="thumbnail')
	for i in range(1, len(part), 1):
		entry = re.sub(r'</?strong>', ' ', part[i])
		clear_videos = "".join([ecs for ecs in entry.strip().splitlines(True) if ecs.strip('\n\n').strip()])
		debug_MS(f"(navigator.list_videos[1]) xxxxx ENTRY-01 : {clear_videos} xxxxx")
		desc_uno, (date_uno, rate_uno) = "", (None for _ in range(2))
		genre_uno, director_uno, writer_uno, staff_uno = ([] for _ in range(4))
		agreeLN1 = re.compile(r'''(?:class=["']meta-title-link["']|class=["']layer-link-holder["']><a) href=["']([^"']+)["'](?: class=["']layer-link["']| )?>([^<]+)</a>''', re.S).findall(entry)
		agreeLN2 = re.compile(r'''class=["']layer-link-holder["']><span class=["']ACr([^ "']+) layer-link["']>([^<]+)</span>''', re.S).findall(entry)
		agreeLN3 = re.compile(r'''class=["']thumbnail-container thumbnail-link["'] href=["']([^"']+)["'] title=["']([^"']+)["']>''', re.S).findall(entry)
		agreeLN4 = re.compile(r'''class=["']ACr([^ "']+) thumbnail-container thumbnail-link["'] title=["']([^"']+)["']''', re.S).findall(entry)
		sdlink_uno = BASE_URL+agreeLN1[0][0] if agreeLN1 else BASE_URL+convert64(agreeLN2[0][0]) if agreeLN2 else BASE_URL+agreeLN3[0][0] if agreeLN3 else BASE_URL+convert64(agreeLN4[0][0])
		wulink_uno = f"{sdlink_uno.split('/videos')[0]}.html" if '/videos' in sdlink_uno else f"{sdlink_uno.split('/trailer')[0]}.html" if '/trailer' in sdlink_uno else f"{sdlink_uno.split('/staffel')[0]}.html" if '/staffel' in sdlink_uno else sdlink_uno
		if phase != 'INTERVIEWS' and wulink_uno in unikat:
			continue
		unikat.add(wulink_uno)
		title_uno = cleaning(agreeLN1[0][1]) if agreeLN1 else cleaning(agreeLN2[0][1]) if agreeLN2 else cleaning(agreeLN3[0][1]) if agreeLN3 else cleaning(agreeLN4[0][1])
		image = re.compile(r'''(?:class=["']thumbnail-img["'] |data-)src=["'](https?://.+?[a-z0-9]+(?:\.png|\.jpg|\.JPG|\.jpeg|\.jfif|\.gif|\.webp))["'?]''', re.S).findall(entry)
		thumb_uno = scaling_img(image[0], phase) if image and len(image[0]) > 0 else None
		agreeDUR = re.compile(r'''class=["']thumbnail-count["']>([^<]+)</span>''', re.S).findall(entry) # Grab - Duration
		dura_uno = get_seconds(agreeDUR[0]) if agreeDUR and len(agreeDUR[0]) > 0 else None # 1:55
		agreeVIS = re.compile(r'''class=["']meta-sub light["']>(.+?)</div>''', re.S).findall(entry)
		visitor = cleaning(agreeVIS[0], True) if agreeVIS else None
		counter += 1
		work_uno = True if '<span class="icon icon-play-arrow"></span>' in entry or dura_uno is not None else False
		if phase == 'INTERVIEWS':
			desc_uno, title_uno = title_uno, 'FILMSTARTS - Interview'
			desc_uno += translation(30834).format(visitor) if visitor else ""
		if phase not in ['ARCHIVES', 'INTERVIEWS', 'TRAILERS']:
			area_uno = re.compile(r'''<div class=["']meta-body-item meta-body-info(.+?)</div>''', re.S).findall(entry) # Grab - Genres
			if '<span class="spacer">' in entry:
				area_uno = re.compile(r'''<span class=["']spacer["']>(.+?)<div class=["']meta-body-item(?: meta-body-direction)?''', re.S).findall(entry) # Grab - Genres
			agreeGEN = re.compile(r'''<span class=["']ACr.*?["']>(.+?)</span>''', re.S).findall(area_uno[0]) if area_uno else []
			genre_uno = ' / '.join(sorted([cleaning(gens, True) for gens in agreeGEN])) if agreeGEN else [] # Drama, Familie, Komödie
			area_due = re.compile(r'''<span class=["']light["']>Regie(.+?)</div>''', re.S).findall(entry) # Grab - Directors
			agreeDIR = re.compile(r'''(?:<span class=["']ACr|href=["']/personen).*?["']>(.+?)(?:</span>|</a>)''', re.S).findall(area_due[0]) if area_due else []
			director_uno = ', '.join([cleaning(dirs, True) for dirs in agreeDIR]) if agreeDIR else [] # Steven Seagal
			area_tre = re.compile(r'''<span class=["']light["']>(?:Drehbuch|Creator)(.+?)</div>''', re.S).findall(entry) # Grab - Writers
			agreeCRE = re.compile(r'''(?:<span class=["']ACr|href=["']/personen).*?["']>(.+?)(?:</span>|</a>)''', re.S).findall(area_tre[0]) if area_tre else []
			writer_uno = ', '.join([cleaning(creas, True) for creas in agreeCRE]) if agreeCRE else [] # Ed Horowitz, Robin U. Russin
			area_qua = re.compile(r'''<span class=["']light["']>Besetzung(.+?)</div>''', re.S).findall(entry) # Grab - Casts
			agreeACT = re.compile(r'''(?:<span class=["']ACr|href=["']/personen).*?["']>(.+?)(?:</span>|</a>)''', re.S).findall(area_qua[0]) if area_qua else []
			staff_uno = ','.join([cleaning(star, True) for star in agreeACT]) if agreeACT and len(agreeACT) > 0 else [] # Fran Monegan, Gabriel L. Muktoyuk, Helen Hakkila
			agreeDES = re.compile(r'''<div class=["']content-txt(?: )?["']>(.+?)</div>''', re.S).findall(entry) # Grab - Plot
			desc_uno = cleaning(agreeDES[0], True) if agreeDES else ""
			agreeDAT = re.compile(r'''<span class=["'](?:ACr.*?)?date(?: )?["']>(.+?)</span>''', re.S).findall(entry) # Grab - Date
			if '/serien' in sdlink_uno or not agreeDAT:
				agreeDAT = re.compile(r'''<div class=["']meta-body-item meta-body-info["']>(.+?)<span class=["']spacer["']>''', re.S).findall(entry) # Grab - Date
			date_uno = cleaning(re.sub(r'\n|\<.*?\>|Im Kino|als VoD', '', agreeDAT[0])) if agreeDAT and len(agreeDAT[0]) > 0 else None # 20. Februar 2024 auf Amazon
			try:
				area_cin = (entry[entry.find('User-Wertung')+1:] or entry[entry.find('Pressekritiken')+1:]) # Grab - Rating
				rate_uno = re.compile(r'''class=["']stareval-note["']>([^<]+)</span>''', re.S).findall(area_cin)[0].strip().replace(',', '.') # 2,5
			except: pass
			combo_uno.append({'Count_1': int(counter), 'Target_1': target, 'Book_1': sdlink_uno, 'Link_1': wulink_uno, 'Title_1': title_uno,
				'Date_1': date_uno, 'Story_1': desc_uno, 'Time_1': dura_uno, 'Genre_1': genre_uno, 'Director_1': director_uno, 'Writer_1': writer_uno,
				'Staff_1': staff_uno, 'Rate_1': rate_uno, 'Thumb_1': thumb_uno, 'Spot_1': sdlink_uno, 'Available_1': work_uno})
			combo_links.append({'Count_1': int(counter), 'Extra_1': phase, 'Book_1': sdlink_uno, 'Link_1': wulink_uno})
		else:
			combo_uno.append({'Count_1': int(counter), 'Target_1': target, 'Book_1': sdlink_uno, 'Link_1': wulink_uno, 'Title_1': title_uno,
				'Date_1': date_uno, 'Story_1': desc_uno, 'Time_1': dura_uno, 'Genre_1': genre_uno, 'Director_1': director_uno, 'Writer_1': writer_uno,
				'Staff_1': staff_uno, 'Rate_1': rate_uno, 'Thumb_1': thumb_uno, 'Spot_1': sdlink_uno, 'Available_1': work_uno})
			combo_links.append({'Count_1': int(counter), 'Extra_1': phase, 'Book_1': sdlink_uno, 'Link_1': wulink_uno})
	if combo_uno:
		if phase != 'INTERVIEWS': # Für Interviews kein Aufruf der 'combo_due'
			combo_due = _fetch_pages(combo_links)
			merging = [{**uno, **due} for uno in combo_uno for due in combo_due if uno.get('Book_1') == due.get('Book_2')] # Merge List1 and List2 (dictionaries) by specific value if value exists else nothing !!!
		else: merging = combo_uno
		for rider in sorted(merging, key=lambda sox: int(sox.get('Count_1', 0))): # 0-16 = Liste1 || 17-36 = Liste2
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
			notice = {key: value for key, value in rider.items() if key[:5] != 'Story'}
			debug_MS(f"(navigator.list_videos[3]) ##### Anzahl : {len(rider)} || Eintrag : {notice} #####")
			starting, (note_1, note_2, note_3) = None, ("" for _ in range(3))
			title = rider['Title_2'] if rider.get('Title_2') and phase != 'ARCHIVES' else rider.get('Title_1')
			duration = rider['Time_2'] if rider.get('Time_2') and phase != 'ARCHIVES' else rider.get('Time_1')
			genre = rider['Genre_2'] if rider.get('Genre_2') else rider.get('Genre_1')
			country = rider['Country_2'] if rider.get('Country_2') else []
			director = rider['Director_2'] if rider.get('Director_2') else rider.get('Director_1')
			writer = rider['Writer_2'] if rider.get('Writer_2') else rider.get('Writer_1')
			actors = rider['Staff_2'] if rider.get('Staff_2') else rider.get('Staff_1')
			rating = rider['Rate_2'] if rider.get('Rate_2') else rider.get('Rate_1')
			agerate = translation(30835) if '0' in str(rider.get('Mpaa')) else rider.get('Mpaa')
			working = True if rider.get('Available_1') is True or rider.get('Available_2') is True else False
			transfer = rider['Spot_2'] if rider.get('Spot_2') else rider.get('Spot_1')
			if working is True and duration not in ['0', None]:
				action, name = {'mode': 'playCODE', 'IDENTiTY': transfer}, title
			else: action, name = {'mode': 'blankFUNC', 'link': 'NO VIDEO'}, translation(30836).format(title)
			image = rider['Thumb_2'] if rider.get('Thumb_2') else rider.get('Thumb_1')
			if rider.get('Seasons'): note_1 = translation(30837).format(rider['Seasons'])
			if rider.get('Date_1') or rider.get('Date_2'):
				starting = rider['Date_2'].replace('er Starttermin', '') if rider.get('Date_2') else rider.get('Date_1').replace('er Starttermin', '')
				note_2 = translation(30838).format(starting)
			if rider.get('Seasons') and rider.get('Date_1') is None and rider.get('Date_2') is None: note_2 = '[CR]'
			note_3 = rider['Story_2'] if rider.get('Story_2') and len(rider.get('Story_2')) > len(rider.get('Story_1')) else rider.get('Story_1')
			plot = note_1+note_2+note_3
			debug_MS(f"(navigator.list_videos[3]) ##### NAME : {name} || LINK : {transfer} || DATE : {starting} #####")
			debug_MS(f"(navigator.list_videos[3]) ##### GENRE : {genre} || COUNTRY : {country} || DIRECTOR : {director} || WRITER : {writer} #####")
			debug_MS(f"(navigator.list_videos[3]) ##### TRAILER : {working} || DURATION : {duration} || THUMB : {image} #####")
			fetch_riders = create_entries({'Title': name, 'Original': rider.get('Original'), 'Plot': plot, 'Duration': duration, 'Genre': genre, 'Country': country, 'Director': director, \
				'Writer': writer, 'Cast': actors, 'Rating': rating, 'Mpaa': agerate, 'Mediatype': 'movie', 'Image': image, 'Reference': 'Single' if working is True else 'Standard'})
			add_views(action, fetch_riders, False, highlights)
			combo_send.append({'filtrate': transfer, 'title': name, 'photo': image, 'genre': genre})
		preserve(WORKS_FILE, combo_send)
	if not combo_uno or counter == 0:
		return dialog.notification(translation(30525), translation(30526), icon, 10000)
	if forward_backward and phase == 'PREVIEWS':
		try:
			boss_left = convert64(re.compile(r'''<span class=["']ACr([^ "']+) button button-md button-primary-full button-left["']>.*?span class=["']txt["']>Vorherige</span>''', re.S).findall(results)[0])
			boss_right = convert64(re.compile(r'''<span class=["']ACr([^ "']+) button button-md button-primary-full button-right["']>.*?span class=["']txt["']>Nächste</span>''', re.S).findall(results)[0])
			pre_day, past_day = re.sub(r'filme-vorschau/de/week-|/', '', boss_left), re.sub(r'filme-vorschau/de/week-|/', '', boss_right)
			pre_date, past_date = datetime(*(time.strptime(pre_day, '%Y-%m-%d')[0:6])), datetime(*(time.strptime(past_day, '%Y-%m-%d')[0:6]))
			pre_new, past_new = pre_date.strftime('%d.%m.%Y'), past_date.strftime('%d.%m.%Y')
			add_views({'mode': 'list_videos', 'link': BASE_URL+boss_right, 'phase': phase}, create_entries({'Title': translation(30839).format(past_new)}))
			add_views({'mode': 'list_videos', 'link': BASE_URL+boss_left, 'phase': phase}, create_entries({'Title': translation(30840).format(pre_new)}))
		except: pass
	if combo_uno and int(number) > int(page) and phase != 'PREVIEWS':
		debug_MS(f"(navigator.list_videos[4]) NEXTPAGES ~~~ Now show NextPage ... No.{int(page)+1} ... ~~~")
		fetch_blades = create_entries({'Title': translation(30841).format(int(page)+1), 'Image': f"{artpic}nextpage.png"})
		add_views({'mode': 'list_videos', 'link': target, 'page': int(page)+1, 'number': int(number), 'phase': phase}, fetch_blades)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def _fetch_pages(media_table, secondo=[]):
	xbmc.sleep(1500) # 1,5 Sekunden vor der Abfrage warten, um den Error 429 - Too many requests zu vermeiden
	package = track_several(media_table, 'GET', 'TEXT', WEB_HEADER)
	if package:
		for points, extras, books, links, scraps in package:
			if scraps not in ['', None]:
				rate_due, spot_due = (None for _ in range(2))
				genre_due, land_due, director_due, writer_due, staff_due = ([] for _ in range(5))
				articles = re.findall(r'''<main class=["']content-layout (?:row )?entity (?:movie|series) cf(.*?)<section class=["']js-outbrain section(?: )?["']>''', scraps, re.S)
				for item in articles:
					item = re.sub(r'</?strong>', ' ', item)
					sector_uno = re.compile(r'''class=["']card entity-card entity-card-list cf(.+?)</figure>''', re.S).findall(item) # Grab - Title + Link + Photo
					matchLN1 = re.compile(r'''class=["']thumbnail-container thumbnail-link["'] href=["']([^"']+)["'] title=["'](.+?)["']>''', re.S).findall(sector_uno[0]) if sector_uno else None # Grab - Link
					matchLN2 = re.compile(r'''class=["']ACr([^ "']+) thumbnail-container thumbnail-link["'] title=["'](.+?)["']>''', re.S).findall(sector_uno[0]) if sector_uno else None # Grab - Link
					sdlink_tre = BASE_URL+matchLN1[0][0] if matchLN1 else BASE_URL+convert64(matchLN2[0][0]) if matchLN2 else None
					name = cleaning(matchLN1[0][1]) if matchLN1 else cleaning(matchLN2[0][1]) if matchLN2 else None
					photo = re.compile(r'''class=["']thumbnail-img["'] (?:.*?data-)?src=["'](https?://.+?[a-z0-9]+(?:\.png|\.jpg|\.JPG|\.jpeg|\.jfif|\.gif|\.webp))["'?]''', re.S).findall(sector_uno[0]) if sector_uno else None
					thumb_due = scaling_img(photo[0], extras) if photo and not 'empty/' in photo[0] else None
					sector_due = re.compile(r'''<div class=["']meta-body-item meta-body-info(.+?)</div>''', re.S).findall(item) # Grab - Genres
					if '<span class="spacer">' in item:
						sector_due = re.compile(r'''<span class=["']spacer["']>(.+?)<div class=["']meta-body-item(?: meta-body-direction)?''', re.S).findall(item) # Grab - Genres
					matchGEN = re.compile(r'''<span class=["']ACr.*?["']>(.+?)</span>''', re.S).findall(sector_due[0]) if sector_due else []
					genre_due = ' / '.join(sorted([cleaning(gens, True) for gens in matchGEN])) if matchGEN else [] # Drama, Familie, Komödie
					matchORG = re.compile(r'''<span class=["']light["']>Originaltitel:(.+?)</div>''', re.S).findall(item) # Grab - Originaltitle
					original = cleaning(matchORG[0], True) if matchORG else None # World on Fire
					sector_tre = re.compile(r'''<span class=["']light["']>Regie(.+?)</div>''', re.S).findall(item) # Grab - Directors
					matchDIR = re.compile(r'''(?:<span class=["']ACr|href=["']/personen).*?["']>(.+?)(?:</span>|</a>)''', re.S).findall(sector_tre[0]) if sector_tre else []
					director_due = ', '.join([cleaning(dirs, True) for dirs in matchDIR]) if matchDIR else [] # Steven Seagal
					sector_qua = re.compile(r'''<span class=["']light["']>(?:Drehbuch|Creator)(.+?)</div>''', re.S).findall(item) # Grab - Writers
					matchCRE = re.compile(r'''(?:<span class=["']ACr|href=["']/personen).*?["']>(.+?)(?:</span>|</a>)''', re.S).findall(sector_qua[0]) if sector_qua else []
					writer_due = ', '.join([cleaning(creas, True) for creas in matchCRE]) if matchCRE else [] # Ed Horowitz, Robin U. Russin
					sector_cin = re.compile(r'''<span class=["']light["']>Besetzung(.+?)</div>''', re.S).findall(item) # Grab - Casts
					matchACT = re.compile(r'''(?:<span class=["']ACr|href=["']/personen).*?["']>(.+?)(?:</span>|</a>)''', re.S).findall(sector_cin[0]) if sector_cin else []
					staff_due = ','.join([cleaning(stars, True) for stars in matchACT]) if matchACT and len(matchACT) > 0 else []
					sector_sei = re.compile(r'''<span class=["'](?:what )?light["']>Produktions(?:land|länder)(.+?)</div>''', re.S).findall(scraps) # Grab - Countries
					matchCOU = re.compile(r'''<span class=["']ACr.*?nationality["']>(.+?)</span>''', re.S).findall(sector_sei[0]) if sector_sei else None
					if sdlink_tre and ('/serien' in sdlink_tre or matchCOU is None):
						sector_sette = re.compile(r'''<span class=["'](?:what )?light["']>Produktions(?:land|länder)(.+?)</div>''', re.S).findall(item) # Grab - Countries
						matchCOU = re.compile(r'''<span class=["']ACr.*?["']>(.+?)</span>''', re.S).findall(sector_sette[0]) if sector_sette else None
					land_due = ', '.join(sorted([cleaning(cous, True) for cous in matchCOU])) if matchCOU else [] # Deutschland
					matchAGE = re.compile(r'''<span class=["']certificate-text(?: )?["']>(.+?)</span>''', re.S).findall(item) # Grab - Mpaa
					mpaa = cleaning(matchAGE[0]) if matchAGE else None # FSK ab 18
					matchDES = re.compile(r'''<div class=["']content-txt(?: )?["']>(.+?)</div>''', re.S).findall(item) # Grab - Plot
					desc_due = cleaning(matchDES[0], True) if matchDES else ""
					sector_otto = re.compile(r'''class=["']stats-numbers-row stats-numbers-seriespage(.+?)class=["']end-section-link-container''', re.S).findall(item) # Grab - Seasons + Episodes
					matchSEA = re.compile(r'''<div class=["']stats-item(?: )?["']>(.+?)</div>''', re.S).findall(sector_otto[0]) if sector_otto else []
					seasons = ' • '.join([cleaning(seas) for seas in matchSEA]) if matchSEA else [] # 20 Staffeln • 420 Episoden
					matchDAT = re.compile(r'''<span class=["'](?:ACr.*?)?date(?: blue-link| )?["']>(.+?)</span>''', re.S).findall(item) # Grab - Date
					if sdlink_tre and ('/serien' in sdlink_tre or not matchDAT):
						matchDAT = re.compile(r'''<div class=["']meta-body-item meta-body-info["']>(.+?)<span class=["']spacer["']>''', re.S).findall(item) # Grab - Date
					date_due = cleaning(re.sub(r'\n|\<.*?\>|Im Kino|als VoD', '', matchDAT[0])) if matchDAT and len(matchDAT[0]) > 0 else None # 20. Februar 2024 auf Amazon
					try:
						sector_nove = (item[item.find('User-Wertung')+1:] or item[item.find('Pressekritiken')+1:]) # Grab - Rating
						rate_due = re.compile(r'''class=["']stareval-note["']>([^<]+)</span>''', re.S).findall(sector_nove)[0].strip().replace(',', '.') # 2,5
					except: pass
					sector_diec = re.compile(r'''class=["']card video-card video-card-col(.+?)</section>''', re.S).findall(item) # Grab - Videos
					matchTR1 = re.compile(r'''<span class=["']ACr([^ "']+) meta-title-link["']>([^<]+)</span>''', re.S).findall(sector_diec[0]) if sector_diec else [] # <span class="ACrL2tACryaXRpa2VuLzMwODMxNi90cmFpbGVyLzE5NTk0NjgxLmh0bWw= meta-title-link">
					matchTR2 = re.compile(r'''class=["']meta-title-link["'] href=["'](.+?)["'](?: )?>([^<]+)</a>''', re.S).findall(sector_diec[0]) if sector_diec else [] # <a class="meta-title-link" href="/kritiken/308316/trailer/19594681.html">
					if extras != 'ARCHIVES':
						spot_due = BASE_URL+convert64(matchTR1[0][0]) if matchTR1 else BASE_URL+matchTR2[0][0] if matchTR2 else False
					auxiliary = cleaning(matchTR1[0][1]) if matchTR1 else cleaning(matchTR2[0][1]) if matchTR2 else name
					title_due = f"{name} - {auxiliary}" if not name in auxiliary else auxiliary
					work_due = True if spot_due and any(rai in spot_due for rai in ['teaser', 'trailer', 'videos']) else False
					matchDUR = re.compile(r'''class=["']thumbnail-count["']>([^<]+)</span>''', re.S).findall(sector_diec[0]) if sector_diec else [] # Grab - Duration
					dura_due = get_seconds(matchDUR[0]) if matchDUR and len(matchDUR[0]) > 0 else None # 1:55
					embrace = {'Count_2': int(points), 'Extra_2': extras, 'Book_2': books, 'Book_3': sdlink_tre, 'Title_2': title_due, 'Original': original, 'Seasons': seasons,
						'Date_2': date_due, 'Story_2': desc_due, 'Time_2': dura_due, 'Genre_2': genre_due, 'Country_2': land_due, 'Director_2': director_due, 'Writer_2': writer_due,
						'Staff_2': staff_due, 'Rate_2': rate_due, 'Mpaa': mpaa, 'Thumb_2': thumb_due, 'Spot_2': spot_due, 'Available_2': work_due}
					debug_MS("----------------------------------------------")
					debug_MS(f"(navigator.fetch_pages[2]) ### COUNT-02 : {points} || LINK-02 : {books} || ENTRY-02 : {embrace} ###")
					secondo.append(embrace)
	return secondo

def playCODE(source):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### TRAILER_SOURCE : {source} ###")
	masters, unikat, (teaser_link, stream, final_link) = [], set(), (False for _ in range(3))
	for worx in preserve(WORKS_FILE):
		if worx['filtrate'] != '00' and worx['filtrate'] == source:
			teaser_link, title_clear, photo, genre = worx['filtrate'], worx['title'], worx['photo'], worx['genre']
			debug_MS(f"(navigator.playCODE[1]) ### WORKS_FILE-Line : {worx} ###")
	if teaser_link:
		template = track_content(teaser_link, headers=WEB_HEADER)
		sector_uno = re.compile(r'''(?:class=["']player  js-player["']|class=["']player player-auto-play js-player["']|<div id=["']btn-export-player["'].*?) data-model=["'](.+?),&quot;disablePostroll&quot;''', re.S).findall(template)
		metadata = sector_uno[0].replace('&quot;', '"')+'}' if sector_uno else None
		debug_MS(f"(navigator.playCODE[2]) +++ GET METADATA FOR stream : {metadata} +++")
		if metadata:
			motion_code = json.loads(metadata)['videos'][0]['idDailymotion']
			debug_MS(f"(navigator.playCODE[3]) ~~~ DAILYMOTION_CODE EXTRACTED : {motion_code} ~~~")
			# >>> START of workaround to fix Cloudflare-Fingerprinting-Error 403 during Playback // created: 21.03.2026 >>>
			measure_headers = [('User-Agent', get_driftless()), ('Referer', BASE_DAILY), ('Accept', '*/*'), ('DNT', '1'), ('x-cache-internal', 'true'), ('x-cache-max-age', '-1')]
			opener = build_opener(HTTPCookieProcessor(CookieJar())) # FROM: https://github.com/Catch-up-TV-and-More/plugin.video.catchuptvandmore/blob/dev/resources/lib/resolver_proxy.py#L347
			opener.addheaders = measure_headers
			with opener.open(META_DAILY.format(motion_code), timeout=12) as auto:
				choosen_link = json.loads(auto.read().decode('utf-8'))['qualities']['auto'][0]['url']
				debug_MS(f"(navigator.playCODE[4]) === DAILYMOTION_AUTO-URL : {choosen_link} ===")
			patching = Request(choosen_link, None, dict(measure_headers[:]))
			CookieJar().add_cookie_header(patching)
			with opener.open(patching, timeout=12) as m3u8:
				sector_due = re.findall(r'NAME="([0-9]+).*?(http.*?.m3u8)', m3u8.read().decode('utf-8'), re.S)
				for qualities, links in sector_due:
					if str(qualities).isdecimal() and qualities not in unikat:
						unikat.add(qualities)
						masters.append({'link': links, 'quality': qualities})
				masters.sort(key=lambda pms: int(pms.get('quality', 0)), reverse=True)
				debug_MS(f"(navigator.playCODE[5]) SORTED_LIST | M3U8 ### MASTER : {masters} ###")
	if prefer_quality == 0 and masters:
		video_Index = dialog.select(translation(30850), [f"[B]{xq['quality']}p[/B]" for xq in masters], preselect=0)
		video_Select = list(xs['link'] for xs in masters)[video_Index] if video_Index > -1 else None
		stream, final_link = 'HLS' if prefer_player == 1 else 'M3U8', video_Select
		debug_MS(f"(navigator.playCODE[6.1]) ***** TAKE - {'FFmpegDirect (hls)' if stream == 'HLS' else 'Standard (m3u8)'} || Position : {video_Index} || File (Dailymotion) : {video_Select} *****")
	elif prefer_quality == 1 and masters: # <<< END of workaround to fix Cloudflare-Fingerprinting-Error 403 during Playback <<<
		stream, final_link = 'HLS' if prefer_player == 1 else 'M3U8', masters[0]['url']
		debug_MS(f"(navigator.playCODE[6.2]) ***** TAKE - {'FFmpegDirect (hls)' if stream == 'HLS' else 'Standard (m3u8)'} || Quality : {masters[0]['quality']}p || File (Dailymotion) : {final_link} *****")
	if stream and final_link:
		LPM = xbmcgui.ListItem(title_clear, path=final_link, offscreen=True)
		if prefer_player == 1 and xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)') and '.m3u8' in final_link:
			IA_NAME = 'inputstream.ffmpegdirect'
			LPM.setMimeType('application/vnd.apple.mpegurl'); LPM.setContentLookup(False); LPM.setProperty('inputstream', IA_NAME)
			LPM.setProperty(f'{IA_NAME}.stream_mode', 'default')
			LPM.setProperty(f'{IA_NAME}.manifest_type', 'hls')
			LPM.setProperty(f'{IA_NAME}.is_realtime_stream', 'true')
			if open_modus != 0:
				LPM.setProperty(f'{IA_NAME}.open_mode', 'ffmpeg' if open_modus == 1 else 'curl')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		log(f"(navigator.playCODE) {stream}_stream : {final_link}")
	else:
		failing(f"(navigator.playCODE[3]) ##### Die angeforderte Video-Url wurde NICHT gefunden !!! #####\n ##### URL : {source} #####")
		return dialog.notification(translation(30521).format('PLAY'), translation(30527), icon, 10000)

def add_views(params, listitem, folder=True, higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enable_decrease and button_place == 1 and higher is True:
		entries.append([translation(30650), f"RunPlugin({build_mass({'mode': 'calling_main'})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
