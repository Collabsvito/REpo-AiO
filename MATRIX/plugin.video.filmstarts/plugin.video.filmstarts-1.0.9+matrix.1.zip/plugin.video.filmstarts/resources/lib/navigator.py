﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
from urllib.parse import urlencode
from urllib.request import urlopen

from .common import *


def mainMenu():
	addDir(translation(30601), icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
	addDir(translation(30602), icon, {'mode': 'trailer', 'extras': 'MOVIE'})
	addDir(translation(30603), icon, {'mode': 'movies'})
	addDir(translation(30604), icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
	addDir(translation(30605), icon, {'mode': 'trailer', 'extras': 'SERIE'})
	addDir(translation(30606), icon, {'mode': 'series'})
	addDir(translation(30607), icon, {'mode': 'listNews', 'url': BASE_URL+'/trailer/interviews/'})
	if enableADJUSTMENT:
		addDir(translation(30608), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def trailer(CAT):
	if CAT == 'MOVIE':
		addDir(translation(30621), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/beliebteste.html'})
		addDir(translation(30622), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/imkino/'})
		addDir(translation(30623), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/bald/'})
		addDir(translation(30624), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/neu/'})
		addDir(translation(30625), icon, {'mode': 'filtrateTrailer', 'url': BASE_URL+'/trailer/archiv/'})
	else:
		addDir(translation(30626), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/serien/kurz/'})
		addDir(translation(30627), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/serien/meisterwartete/'})
		addDir(translation(30628), icon, {'mode': 'listTrailer', 'url': BASE_URL+'/trailer/serien/neueste/'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def movies():
	addDir(translation(30631), icon, {'mode': 'listKino_small', 'url': BASE_URL+'/filme-imkino/vorpremiere/'})
	addDir(translation(30632), icon, {'mode': 'listKino_big', 'url': BASE_URL+'/filme-imkino/kinostart/'})
	addDir(translation(30633), icon, {'mode': 'listKino_big', 'url': BASE_URL+'/filme-imkino/neu/'})
	addDir(translation(30634), icon, {'mode': 'listKino_big', 'url': BASE_URL+'/filme-imkino/besten-filme/user-wertung/'})
	addDir(translation(30635), icon, {'mode': 'selectionWeek', 'url': BASE_URL+'/filme-vorschau/de/'})
	addDir(translation(30636), icon, {'mode': 'filtrateKinSer', 'url': BASE_URL+'/kritiken/filme-alle/user-wertung/'})
	addDir(translation(30637), icon, {'mode': 'filtrateKinSer', 'url': BASE_URL+'/kritiken/filme-alle/'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def series():
	addDir(translation(30641), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/top/'})
	addDir(translation(30642), icon, {'mode': 'filtrateKinSer', 'url': BASE_URL+'/serien/beste/'})
	addDir(translation(30643), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/top/populaerste/'})
	addDir(translation(30644), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/kommende-staffeln/meisterwartete/'})
	addDir(translation(30645), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/kommende-staffeln/'})
	addDir(translation(30646), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/kommende-staffeln/demnaechst/'})
	addDir(translation(30647), icon, {'mode': 'listSeries_big', 'url': BASE_URL+'/serien/neue/'})
	addDir(translation(30648), icon, {'mode': 'filtrateKinSer', 'url': BASE_URL+'/serien-archiv/'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def filtrateTrailer(url):
	debug_MS("(navigator.filtrateTrailer) -------------------------------------------------- START = filtrateTrailer --------------------------------------------------")
	debug_MS("(navigator.filtrateTrailer) ##### URL = {0} #####".format(url))
	if not "genre-" in url:
		addDir(translation(30801), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateTrailer', 'extras': 'Nach Genre'})
	if not "sprache-" in url:
		addDir(translation(30802), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateTrailer', 'extras': 'Nach Sprache'})
	if not "format-" in url:
		addDir(translation(30803), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateTrailer', 'extras': 'Nach Typ'})
	addDir(translation(30810), icon, {'mode': 'listTrailer', 'url': url})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def filtrateKinSer(url):
	debug_MS("(navigator.filtrateKinSer) -------------------------------------------------- START = filtrateKinSer --------------------------------------------------")
	debug_MS("(navigator.filtrateKinSer) ##### URL = {0} #####".format(url))
	if not "genre-" in url:
		addDir(translation(30801), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateKinSer', 'extras': 'Nach Genre'})
	if not "jahrzehnt" in url:
		addDir(translation(30804), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateKinSer', 'extras': 'Nach Produktionsjahr'})
	if not "produktionsland-" in url:
		addDir(translation(30805), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateKinSer', 'extras': 'Nach Land'})
	addDir(translation(30810), icon, {'mode': 'listSeries_big', 'url': url})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selectionCategories(url, TYPE, CATEGORY):
	debug_MS("(navigator.selectionCategories) -------------------------------------------------- START = selectionCategories --------------------------------------------------")
	debug_MS("(navigator.selectionCategories) ##### URL = {0} ##### TYPE = {1} ##### CATEGORY = {2} #####".format(url, TYPE, CATEGORY))
	content = getUrl(url)
	result = content[content.find('data-name="'+CATEGORY+'"')+1:]
	result = result[:result.find('</ul>')]
	part = result.split('class="filter-entity-item"')
	for i in range(1,len(part),1):
		element = re.sub(r'</?strong>', '', part[i])
		matchNO = re.compile(r'<span class=["\'](?:light|lighten)["\']>\(([^<]+?)\)</span>', re.S).findall(element)
		number = matchNO[0].strip() if matchNO else None
		if 'href=' in element:
			matchUN = re.compile(r'href=["\']([^"]+)["\'](?: title=.+?["\']>|>)([^<]+?)</a>', re.S).findall(element)
			link = BASE_URL+matchUN[0][0]
			name = cleaning(matchUN[0][1])
		else:
			matchH1 = re.compile(r'<span class=["\']ACr([^"]+) item-content["\'] title=.+?["\']>([^<]+?)</span>', re.S).findall(element)
			matchH2 = re.compile(r'<span class=["\']acLnk ([^"]+)["\']>([^<]+?)</span>', re.S).findall(element)
			link = BASE_URL+convert64(matchH1[0][0]) if matchH1 else BASE_URL+decodeURL(matchH2[0][0])
			name = cleaning(matchH1[0][1]) if matchH1 else cleaning(matchH2[0][1])
		if number: name += "   ("+str(number)+")"
		debug_MS("(navigator.selectionCategories) Title : {0} || Link : {1}".format(name, link))
		addDir(name, icon, {'mode': TYPE, 'url': link})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selectionWeek(url):
	debug_MS("(navigator.selectionWeek) -------------------------------------------------- START = selectionWeek --------------------------------------------------")
	debug_MS("(navigator.selectionWeek) ##### URL = {0} #####".format(url))
	content = getUrl(url)
	result = content[content.find('<div class="pagination pagination-select">')+1:]
	result = result[:result.find('<span class="txt">Nächste</span><i class="icon icon-right icon-arrow-right-a">')]
	matchUN = re.compile(r'<option value=["\']ACr([^"]+)["\']([^<]+)</option>', re.S).findall(result)
	for link, title in matchUN:
		link = convert64(link)
		xDate = re.sub(r'filme-vorschau/de/week-|/', '', link)
		title = title.replace('>', '')
		name = translation(30831).format(cleaning(title.replace('selected', ''))) if "selected" in title else cleaning(title)
		debug_MS("(navigator.selectionWeek) Title : {0} || Datum : {1}".format(name, xDate))
		addDir(name, icon, {'mode': 'listKino_big', 'url': BASE_URL+link, 'extras': xDate})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTrailer(url, PAGE, POS):
	debug_MS("(navigator.listTrailer) -------------------------------------------------- START = listTrailer --------------------------------------------------")
	newURL = '{}?page={}'.format(url, PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listTrailer) ##### URL = {0} ##### PAGE = {1} #####".format(newURL, str(PAGE)))
	content = getUrl(newURL)
	matchPG = re.findall('<nav class="pagination(.+?)</section>', content, re.S)
	if int(POS) == 0 and matchPG:
		PG_ONE = re.compile(r'<a class="button button-md item" href=.+?page=[0-9]+">([0-9]+)</a></div></nav>', re.S).findall(matchPG[0])
		PG_TWO = re.compile(r'<span class="ACr.+?button-md item">([0-9]+)</span></div></nav>', re.S).findall(matchPG[0])
		POS = PG_ONE[0] if PG_ONE else PG_TWO[0] if PG_TWO else POS
		debug_MS("(navigator.listTrailer) *RESULT* Pages-Maximum : {0}".format(str(POS)))
	result = content[content.find('<main id="content-layout" class="content-layout cf">')+1:]
	result = result[:result.find('<div class="mdl-rc">')]
	part = result.split('<figure class="thumbnail ">')
	for i in range(1,len(part),1):
		element = re.sub(r'</?strong>', '', part[i])
		duration = '0'
		image = re.compile(r'(?:src=|"src":)"(https?://.+?[a-z0-9]+(?:\.png|\.jpg|\.jpeg|\.gif))["\'\?]', re.S|re.IGNORECASE).findall(element)[0]
		photo = enlargeIMG(image)
		RunTime = re.compile(r'class="thumbnail-count">(.+?)</span>', re.S).findall(element)
		if RunTime and ":" in RunTime[0]:
			running = re.compile(r'([0-9]+):([0-9]+)', re.S).findall(RunTime[0])
			duration = int(running[0][0])*60+int(running[0][1])
		elif RunTime and str(RunTime[0]).isdigit():
			duration = int(RunTime[0])
		matchH1 = re.compile(r'(?:class="meta-title-link"|<a) href="([^"]+)"(?: class="layer-link")?>([^<]+)</a>', re.S).findall(element)
		matchH2 = re.compile(r'class="ACr([^ "]+) thumbnail-container thumbnail-link" title="([^"]+)"', re.S).findall(element)
		link = BASE_URL+matchH1[0][0] if matchH1 else BASE_URL+convert64(matchH2[0][0])
		name = cleaning(matchH1[0][1]) if matchH1 else cleaning(matchH2[0][1])
		debug_MS("(navigator.listTrailer) Name : {0} || Link : {1}".format(name, link))
		debug_MS("(navigator.listTrailer) Duration : {0} || Thumb : {1}".format(str(duration), photo))
		addLink(name, photo, {'mode': 'playVideo', 'url': link, 'extras': url}, duration=duration)
	if int(POS) > int(PAGE):
		debug_MS("(navigator.listTrailer) Now show NextPage ...")
		addDir(translation(30832).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listTrailer', 'url': url, 'page': int(PAGE)+1, 'position': int(POS)})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listKino_big(url, PAGE, POS):
	debug_MS("(navigator.listKino_big) -------------------------------------------------- START = listKino_big --------------------------------------------------")
	FOUND = 0
	newURL = '{}?page={}'.format(url, PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listKino_big) ##### URL = {0} ##### PAGE = {1} #####".format(newURL, str(PAGE)))
	content = getUrl(newURL)
	matchPG = re.findall('<nav class="pagination(.+?)</section>', content, re.S)
	if int(POS) == 0 and matchPG:
		PG_ONE = re.compile(r'<a class=["\']button button-md item["\'] href=.+?page=[0-9]+["\']>([0-9]+)</a></div></nav>', re.S).findall(matchPG[0])
		PG_TWO = re.compile(r'<span class=["\']ACr.+?button-md item["\']>([0-9]+)</span></div></nav>', re.S).findall(matchPG[0])
		POS = PG_ONE[0] if PG_ONE else PG_TWO[0] if PG_TWO else POS
		debug_MS("(navigator.listKino_big) *RESULT* Pages-Maximum : {0}".format(str(POS)))
	result = content[content.find('<main id="content-layout" class="content-layout cf">')+1:]
	result = result[:result.find('<div class="mdl-rc">')]
	part = result.split('<figure class="thumbnail ">')
	for i in range(1,len(part),1):
		element = part[i]
		movieDATE, genre, director, rating = (None for _ in range(4))
		genreLIST, directorLIST, castLIST, castLOGG = ([] for _ in range(4))
		FOUND += 1
		matchUN = re.compile(r'class=["\']ACr([^ "]+) thumbnail-container thumbnail-link["\'] title=["\'](.+?)["\']>', re.S).findall(element)
		link = BASE_URL+convert64(matchUN[0][0])
		name = cleaning(matchUN[0][1])
		image = re.compile(r'src=["\'](https?://.+?[a-z0-9]+(?:\.png|\.jpg|\.jpeg|\.gif))["\'\?]', re.S|re.IGNORECASE).findall(element)[0]
		photo = enlargeIMG(image)
		if "/serien" in newURL:
			matchDT = re.compile(r'<div class=["\']meta-body-item meta-body-info["\']>([^<]+?)<span class=["\']spacer["\']>/</span>', re.S).findall(element)
		else:
			matchDT = re.compile(r'<span class=["\']date["\']>.*?([a-zA-Zä]+ [0-9]+)</span>', re.S).findall(element)
		movieDATE = matchDT[0] if matchDT else None
		if movieDATE and "/serien" in newURL:
			name += "   ("+str(movieDATE.replace('\n', '').replace(' - ', ' ~ ').replace('läuft seit', 'ab').strip())+")"
		elif movieDATE and "user-wertung/" in newURL:
			newDATE = cleanMonth(movieDATE.lower())
			name += "   ("+str(newDATE)+")"
		try: # Grab - Genres
			if '<span class="spacer">' in element:
				result_1 = re.compile(r'<span class=["\']spacer["\']>/</span>(.+?)</div>', re.S).findall(element)[-1]
			else:
				result_1 = re.compile(r'<div class=["\']meta-body-item meta-body-info["\']>(.+?)</div>', re.S).findall(element)[-1]
			matchG = re.compile(r'<span class=["\']ACr.*?["\']>(.+?)</span>', re.S).findall(result_1)
			for gNames in matchG:
				genreLIST.append(cleaning(gNames))
			if genreLIST: genre = ' / '.join(sorted(genreLIST))
		except: pass
		try: # Grab - Directors
			result_2 = re.compile(r'<div class=["\']meta-body-item meta-body-direction["\']>(.+?)</div>', re.S).findall(element)[-1]
			matchD = re.compile(r'(?:<span class=["\']ACr|href=["\']/personen).*?["\']>(.+?)(?:</span>|</a>)', re.S).findall(result_2)
			for dNames in matchD:
				directorLIST.append(cleaning(dNames))
			if directorLIST: director = ', '.join(sorted(directorLIST))
		except: pass
		try: # Grab - Casts
			result_3 = re.compile(r'<div class=["\']meta-body-item meta-body-actor["\']>(.+?)</div>', re.S).findall(element)[-1]
			matchC = re.compile(r'(?:<span class=["\']ACr|href=["\']/personen).*?["\']>(.+?)(?:</span>|</a>)', re.S).findall(result_3)
			for index, person in enumerate(matchC, 1):
				actor = {'name': cleaning(re.sub(r'\<.*?>', '', person)), 'role': '', 'order': index, 'thumb': ''}
				if actor['name'] not in ['' , None]:
					castLOGG.append(actor)
					if KODI_ov20:
						castLIST.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
					else: castLIST.append(actor)
		except: pass
		try: # Grab - Plot
			desc = re.compile(r'<div class=["\']synopsis["\']>(.+?)</div>', re.S).findall(element)[0]
			plot = cleaning(re.sub(r'\<.*?\>', '', desc))
		except: plot=""
		try: # Grab - Rating
			result_4 = (element[element.find('User-Wertung')+1:] or element[element.find('Pressekritiken')+1:])
			rating = re.compile(r'class=["\']stareval-note["\']>([^<]+?)</span></div>', re.S).findall(result_4)[0].strip().replace(',', '.')
			# vtag.setRating(rating, votes=votes, type=rating_type, isdefault=first) NEXUS+OMEGA
			# rating = float - the value of the rating. // votes = int - the number of votes. Default 0. // type = string - the type of the rating. Any string. // defaultt = bool - is the default rating? = True or False. Default False.
			# listitem.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		except: pass
		matchTT = re.compile(r'<div class=["\']buttons-holder["\']>(.+?)</div>', re.S).findall(element)
		TRAILER = True if matchTT and ("Trailer" in matchTT[0] or "Teaser" in matchTT[0]) else False
		debug_MS("(navigator.listKino_big) Name : {0} || Link : {1}".format(name, link))
		debug_MS("(navigator.listKino_big) Genre : {0} || Thumb : {1}".format(genre, photo))
		debug_MS("(navigator.listKino_big) Regie : {0} || Cast : {1}".format(director, str(castLOGG)))
		if 'filme-vorschau/' in newURL or 'serien/beste/' in newURL:
			addLink(name, photo, {'mode': 'playVideo', 'url': link, 'target': 'VORSCHAU', 'extras': url}, plot, genre, director, castLIST, rating)
		else:
			if (TRAILER or '<span class="ico-play-inner"></span>' in element) and not 'button btn-disabled' in element:
				addLink(name, photo, {'mode': 'playVideo', 'url': link, 'extras': url}, plot, genre, director, castLIST, rating)
			else:
				addDir(translation(30835).format(name), photo, {'mode': 'blankFUNC', 'url': '00'}, plot, genre, director, castLIST, rating, False)
	if FOUND == 0:
		return dialog.notification(translation(30524), translation(30525), icon, 8000)
	if BEFORE_AND_AFTER and 'filme-vorschau/' in newURL:
		try:
			LEFT = convert64(re.compile(r'<span class=["\']ACr([^ "]+) button button-md button-primary-full button-left["\']>.*?span class=["\']txt["\']>Vorherige</span>', re.S).findall(result)[0])
			RIGHT = convert64(re.compile(r'<span class=["\']ACr([^ "]+) button button-md button-primary-full button-right["\']>.*?span class=["\']txt["\']>Nächste</span>', re.S).findall(result)[0])
			BeforeDAY, AfterDAY = re.sub(r'filme-vorschau/de/week-|/', '', LEFT), re.sub(r'filme-vorschau/de/week-|/', '', RIGHT)
			before, after = datetime(*(time.strptime(BeforeDAY, '%Y-%m-%d')[0:6])), datetime(*(time.strptime(AfterDAY, '%Y-%m-%d')[0:6]))
			bxORG, axORG = before.strftime('%Y-%m-%d'), after.strftime('%Y-%m-%d')
			bxNEW, axNEW = before.strftime('%d.%m.%Y'), after.strftime('%d.%m.%Y')
			addDir(translation(30833).format(str(axNEW)), icon, {'mode': 'listKino_big', 'url': BASE_URL+RIGHT, 'extras': axORG})
			addDir(translation(30834).format(str(bxNEW)), icon, {'mode': 'listKino_big', 'url': BASE_URL+LEFT, 'extras': bxORG})
		except: pass
	if int(POS) > int(PAGE) and not 'filme-vorschau/' in newURL:
		debug_MS("(navigator.listKino_big) Now show NextPage ...")
		addDir(translation(30832).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listKino_big', 'url': url, 'page': int(PAGE)+1, 'position': int(POS)})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listKino_small(url, PAGE):
	debug_MS("(navigator.listKino_small) -------------------------------------------------- START = listKino_small --------------------------------------------------")
	FOUND = 0
	newURL = '{}?page={}'.format(url, PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listKino_small) ##### URL = {0} ##### PAGE = {1} #####".format(newURL, str(PAGE)))
	content = getUrl(newURL)
	part = content.split('<div class="data_box">')
	for i in range(1,len(part),1):
		element = part[i]
		movieDATE, genre, director, rating = (None for _ in range(4))
		genreLIST, directorLIST, castLIST, castLOGG = ([] for _ in range(4))
		FOUND += 1
		matchH1 = re.compile(r'class=["\']acLnk ([^ ]+?) button btn-primary', re.S).findall(element)
		matchH2 = re.compile(r'button btn-primary ["\'] href=["\']([^"]+?)["\']', re.S).findall(element)
		link = BASE_URL+decodeURL(matchH1[0]) if matchH1 else BASE_URL+matchH2[0] if matchH2 else None
		image = re.compile(r'src=["\'](https?://.+?[a-z0-9]+(?:\.png|\.jpg|\.jpeg|\.gif))["\'\?]', re.S|re.IGNORECASE).findall(element)[0]
		photo = enlargeIMG(image)
		title = re.compile(r'alt=["\'](.+?)["\'] title=', re.S).findall(element)[0]
		name = cleaning(title)
		matchDT = re.compile(r'<span class=["\']film_info lighten fl["\']>Starttermin(.+?)</div>', re.S).findall(element)
		movieDATE =re.sub(r'\<.*?\>', '', matchDT[0]) if matchDT else None
		if movieDATE and not "unbekannt" in movieDATE.lower():
			name += "   ("+movieDATE.replace('\n', '').replace('.', '-').strip()[0:10]+")"
		try: # Grab - Directors
			result_1 = re.compile(r'<span class=["\']film_info lighten fl["\']>Von </span>(.+?)</div>', re.S).findall(element)[0]
			matchD = re.compile(r'(?:<span title=|<a title=)["\'](.+?)["\'] (?:class=|href=)', re.S).findall(result_1)
			for dNames in matchD:
				directorLIST.append(cleaning(dNames))
			if directorLIST: director = ', '.join(sorted(directorLIST))
		except: pass
		try: # Grab - Casts
			result_2 = re.compile(r'<span class=["\']film_info lighten fl["\']>Mit </span>(.+?)</div>', re.S).findall(element)[0]
			matchC = re.compile(r'(?:<span title=|<a title=)["\'](.+?)["\'] (?:class=|href=)', re.S).findall(result_2)
			for index, person in enumerate(matchC, 1):
				actor = {'name': cleaning(re.sub(r'\<.*?>', '', person)), 'role': '', 'order': index, 'thumb': ''}
				if actor['name'] not in ['' , None]:
					castLOGG.append(actor)
					if KODI_ov20:
						castLIST.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
					else: castLIST.append(actor)
		except: pass
		try: # Grab - Genres
			result_3 = re.compile(r'<span class=["\']film_info lighten fl["\']>Genre</span>(.+?)</div>', re.S).findall(element)[0]
			matchG = re.compile(r'<span itemprop=["\']genre["\']>([^<]+?)</span>', re.S).findall(result_3)
			for gNames in matchG:
				genreLIST.append(cleaning(gNames))
			if genreLIST: genre = ' / '.join(sorted(genreLIST))
		except: pass
		try: # Grab - Plot
			desc = re.compile(r"<p[^>]*>([^<]+)<", re.S).findall(element)[0]
			plot = cleaning(desc)
		except: plot=""
		try: # Grab - Rating
			result_4 = (element[element.find('User-Wertung')+1:] or element[element.find('Pressekritiken')+1:])
			rating = re.compile(r'<span class=["\']note["\']>([^<]+?)</span></span>', re.S).findall(result_4)[0].strip().replace(',', '.')
			# vtag.setRating(rating, votes=votes, type=rating_type, isdefault=first) NEXUS+OMEGA
			# rating = float - the value of the rating. // votes = int - the number of votes. Default 0. // type = string - the type of the rating. Any string. // defaultt = bool - is the default rating? = True or False. Default False.
			# listitem.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		except: pass
		debug_MS("(navigator.listKino_small) Name : {0} || Link : {1}".format(name, link))
		debug_MS("(navigator.listKino_small) Genre : {0} || Thumb : {1}".format(genre, photo))
		debug_MS("(navigator.listKino_small) Regie : {0} || Cast : {1}".format(director, str(castLOGG)))
		if link and not 'button btn-disabled' in element:
			addLink(name, photo, {'mode': 'playVideo', 'url': link, 'extras': url}, plot, genre, director, castLIST, rating)
		else:
			addDir(translation(30835).format(name), photo, {'mode': 'blankFUNC', 'url': '00'}, plot, genre, director, castLIST, rating, False)
	if FOUND == 0:
		return dialog.notification(translation(30524), translation(30525), icon, 8000)
	if 'fr">Nächste<i class="icon-arrow-right">' in content:
		debug_MS("(navigator.listKino_small) Now show NextPage ...")
		addDir(translation(30832).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listKino_small', 'url': url, 'page': int(PAGE)+1})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listNews(url, PAGE):
	debug_MS("(navigator.listNews) -------------------------------------------------- START = listNews --------------------------------------------------")
	newURL = '{}?page={}'.format(url, PAGE) if int(PAGE) > 1 else url
	debug_MS("(navigator.listNews) ##### URL = {0} ##### PAGE = {1} #####".format(newURL, str(PAGE)))
	content = getUrl(newURL)
	result = content[content.find('<div class="colcontent">')+1:]
	result = result[:result.find('class="centeringtable">')]
	part = result.split('<div class="datablock')
	for i in range(1,len(part),1):
		element = part[i]
		image = re.compile(r'src=["\'](https?://.+?[a-z0-9]+(?:\.png|\.jpg|\.jpeg|\.gif))["\'\?]', re.S|re.IGNORECASE).findall(element)[0]
		photo = enlargeIMG(image)
		matchUN = re.compile(r'href=["\'](.+?)["\'](?: class=.*?</strong)?>(.+?)</a>', re.S).findall(element)
		link = BASE_URL+matchUN[0][0]
		title = matchUN[0][1].replace('\n', '').strip()
		name = cleaning(re.sub(r'\<.*?\>', '', title))
		if 'Interviews' in name:
			plot, name = name, 'Interviews'+name.split('- Interviews')[1]
		else:
			try: # Grab - Plot
				desc = re.compile(r'class=["\']fs11 purehtml["\']>(.+?)<div class=["\']spacer["\']></div>', re.S).findall(element)[0]
				plot = cleaning(re.sub(r'\<.*?\>', '', desc))
			except: plot = name
		debug_MS("(navigator.listNews) Name : {0} || Link : {1}".format(name, link))
		debug_MS("(navigator.listNews) Thumb : {0}".format(photo))
		addLink(name, photo, {'mode': 'playVideo', 'url': link, 'extras': url}, plot)
	try:
		nextPG = re.compile(r'(<li class="navnextbtn">[^<]+<span class="acLnk)', re.S).findall(content)[0]
		debug_MS("(navigator.listNews) Now show NextPage ...")
		addDir(translation(30832).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listNews', 'url': url, 'page': int(PAGE)+1})
	except: pass
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url, TYPE, REF):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS("(navigator.playVideo) ##### URL = {0} ##### TYPE = {1} ##### REFERER = {2} ##### ".format(url, TYPE, REF))
	MEDIAS = []
	END_URL, FINAL_URL = (False for _ in range(2))
	if TYPE == 'VORSCHAU':
		content = getUrl(url)
		FIRST = re.compile(r'class=["\']trailer item["\']   href=["\']([^"]+?)["\'] title=["\']Trailer["\']>', re.S).findall(content)
		END_URL = FIRST[0] if FIRST else False # <a class="trailer item"   href="/kritiken/278374/trailer/19576405.html" title="Trailer"
		if not END_URL:
			selection = re.findall(r'<main id="content-layout" class="content-layout entity movie cf(.+?)<div class="rc-content">', content, re.S)
			for chtml in selection:
				SECOND = re.compile(r'<span class=["\']ACr([^ ]+?) button button-sm button-primary-full["\']>', re.S).findall(chtml)
				END_URL = convert64(SECOND[0]) if SECOND else False
	result = getUrl(BASE_URL+END_URL, {'Referer': url}) if END_URL else getUrl(url, {'Referer': REF})
	mp4_QUALITIES = ['high', 'standard', 'medium', 'low'] # high=_hd_013.mp4 // low=_l_013.mp4 // medium=_m_013.mp4 // standard=_sd_013.mp4
	THIRD = re.compile(r'(?:class=["\']player  js-player["\']|class=["\']player player-auto-play js-player["\']|<div id=["\']btn-export-player["\'].*?) data-model=["\'](.+?),&quot;disablePostroll&quot;', re.S).findall(result)
	STREAMS = THIRD[0].replace('&quot;', '"')+"}" if THIRD else None
	debug_MS("(navigator.playVideo) ##### Extraction of Stream-Links : {0} #####".format(str(STREAMS)))
	if STREAMS:
		DATA = json.loads(STREAMS)
		for item in DATA.get('videos', []):
			vidQualities = item.get('sources', '')
			for found in mp4_QUALITIES:
				for quality in vidQualities:
					if quality == found:
						MEDIAS.append({'url': vidQualities[quality], 'quality': quality, 'mimeType': 'video/mp4'})
	FINAL_URL = VideoBEST(MEDIAS[0]['url']) if MEDIAS else FINAL_URL
	if FINAL_URL:
		FINAL_URL = 'https:'+FINAL_URL.replace(' ', '%20') if FINAL_URL[:4] != 'http' else FINAL_URL.replace(' ', '%20')
		log("(navigator.playVideo) StreamURL : {0}".format(FINAL_URL))
		listitem = xbmcgui.ListItem(path=FINAL_URL)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playVideo) ##### Die angeforderte Video-Url wurde leider NICHT gefunden !!! #####\n   ##### URL : {0} #####".format(url))
		return dialog.notification(translation(30521).format('PLAY'), translation(30526), icon, 8000)

def VideoBEST(best_url):
	standards = [best_url, '', ''] # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	standards[1] = standards[0].replace('_l_', '_sd_').replace('_m_', '_sd_')
	standards[2] = standards[1].replace('_sd_', '_hd_')
	if standards[0] not in [standards[1], standards[2]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if str(code) == '200':
					return element
			except: pass
	return best_url

def addDir(name, image, params={}, plot=None, genre=None, director=None, cast=None, rating=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name)
		videoInfoTag.setPlot(plot)
		videoInfoTag.setGenres([genre])
		videoInfoTag.setDirectors([director])
		if isinstance(cast, (list, tuple)): videoInfoTag.setCast(cast)
		if rating: videoInfoTag.setRating(float(rating), 0, 'Wertung', True)
	else:
		info = {}
		if isinstance(cast, (list, tuple)): liz.setCast(cast)
		info['Title'] = name
		info['Plot'] = plot
		info['Genre'] = [genre]
		info['Director'] = [director]
		if rating: info['Rating'] = float(rating)
		liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, genre=None, director=None, cast=None, rating=None, duration=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name)
		videoInfoTag.setTagLine(None)
		videoInfoTag.setPlot(plot)
		if duration: videoInfoTag.setDuration(int(duration))
		videoInfoTag.setGenres([genre])
		videoInfoTag.setDirectors([director])
		if isinstance(cast, (list, tuple)): videoInfoTag.setCast(cast)
		if rating: videoInfoTag.setRating(float(rating), 0, 'Wertung', True)
		videoInfoTag.setMediaType('movie')
	else:
		info = {}
		if isinstance(cast, (list, tuple)): liz.setCast(cast)
		info['Title'] = name
		info['Tagline'] = None
		info['Plot'] = plot
		if duration: info['Duration'] = duration
		info['Genre'] = [genre]
		info['Director'] = [director]
		if rating: info['Rating'] = float(rating)
		info['Mediatype'] = 'movie'
		liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
