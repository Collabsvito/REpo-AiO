﻿# -*- coding: utf-8 -*-

from .common import *


def mainMenu():
	addDir(translation(30601), icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
	addDir(translation(30602), icon, {'mode': 'trailer', 'extras': 'MOVIE'})
	addDir(translation(30603), icon, {'mode': 'movies'})
	addDir(translation(30604), icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
	addDir(translation(30605), icon, {'mode': 'trailer', 'extras': 'SERIE'})
	addDir(translation(30606), icon, {'mode': 'series'})
	addDir(translation(30607), icon, {'mode': 'listTrailer', 'url': f"{BASE_URL}/trailer/interviews/"})
	if enableADJUSTMENT:
		addDir(translation(30608), f"{artpic}settings.png", {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def trailer(CAT):
	if CAT == 'MOVIE':
		addDir(translation(30621), icon, {'mode': 'listTrailer', 'url': f"{BASE_URL}/trailer/beliebteste.html"})
		addDir(translation(30622), icon, {'mode': 'listTrailer', 'url': f"{BASE_URL}/trailer/imkino/"})
		addDir(translation(30623), icon, {'mode': 'listTrailer', 'url': f"{BASE_URL}/trailer/bald/"})
		addDir(translation(30624), icon, {'mode': 'listTrailer', 'url': f"{BASE_URL}/trailer/neu/"})
		addDir(translation(30625), icon, {'mode': 'filtrateTrailer', 'url': f"{BASE_URL}/trailer/archiv/"})
	else:
		addDir(translation(30626), icon, {'mode': 'listTrailer', 'url': f"{BASE_URL}/trailer/serien/kurz/"})
		addDir(translation(30627), icon, {'mode': 'listTrailer', 'url': f"{BASE_URL}/trailer/serien/meisterwartete/"})
		addDir(translation(30628), icon, {'mode': 'listTrailer', 'url': f"{BASE_URL}/trailer/serien/neueste/"})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def movies():
	addDir(translation(30631), icon, {'mode': 'listMovies', 'url': f"{BASE_URL}/filme-imkino/vorpremiere/"})
	addDir(translation(30632), icon, {'mode': 'listMovies', 'url': f"{BASE_URL}/filme-imkino/kinostart/"})
	addDir(translation(30633), icon, {'mode': 'listMovies', 'url': f"{BASE_URL}/filme-imkino/neu/"})
	addDir(translation(30634), icon, {'mode': 'listMovies', 'url': f"{BASE_URL}/filme-imkino/besten-filme/user-wertung/"})
	addDir(translation(30635), icon, {'mode': 'selectionWeek', 'url': f"{BASE_URL}/filme-vorschau/de/"})
	addDir(translation(30636), icon, {'mode': 'filtrateMovSer', 'url': f"{BASE_URL}/kritiken/filme-alle/user-wertung/"})
	addDir(translation(30637), icon, {'mode': 'filtrateMovSer', 'url': f"{BASE_URL}/kritiken/filme-alle/"})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def series():
	addDir(translation(30641), icon, {'mode': 'listSeries', 'url': f"{BASE_URL}/serien/top/"})
	addDir(translation(30642), icon, {'mode': 'filtrateMovSer', 'url': f"{BASE_URL}/serien/beste/"})
	addDir(translation(30643), icon, {'mode': 'listSeries', 'url': f"{BASE_URL}/serien/top/populaerste/"})
	addDir(translation(30644), icon, {'mode': 'listSeries', 'url': f"{BASE_URL}/serien/kommende-staffeln/meisterwartete/"})
	addDir(translation(30645), icon, {'mode': 'listSeries', 'url': f"{BASE_URL}/serien/kommende-staffeln/"})
	addDir(translation(30646), icon, {'mode': 'listSeries', 'url': f"{BASE_URL}/serien/kommende-staffeln/demnaechst/"})
	addDir(translation(30647), icon, {'mode': 'listSeries', 'url': f"{BASE_URL}/serien/neue/"})
	addDir(translation(30648), icon, {'mode': 'filtrateMovSer', 'url': f"{BASE_URL}/serien-archiv/"})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def filtrateTrailer(url):
	debug_MS("(navigator.filtrateTrailer) -------------------------------------------------- START = filtrateTrailer --------------------------------------------------")
	debug_MS(f"(navigator.filtrateTrailer) ### URL = {url} ###")
	if not 'genre-' in url:
		addDir(translation(30801), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateTrailer', 'extras': 'Nach Genre'})
	if not 'sprache-' in url:
		addDir(translation(30802), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateTrailer', 'extras': 'Nach Sprache'})
	if not 'format-' in url:
		addDir(translation(30803), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateTrailer', 'extras': 'Nach Typ'})
	addDir(translation(30810), icon, {'mode': 'listTrailer', 'url': url})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def filtrateMovSer(url):
	debug_MS("(navigator.filtrateMovSer) -------------------------------------------------- START = filtrateMovSer --------------------------------------------------")
	debug_MS(f"(navigator.filtrateMovSer) ### URL = {url} ###")
	if not 'genre-' in url:
		addDir(translation(30801), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateMovSer', 'extras': 'Nach Genre'})
	if not 'jahrzehnt' in url:
		addDir(translation(30804), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateMovSer', 'extras': 'Nach Produktionsjahr'})
	if not 'produktionsland-' in url:
		addDir(translation(30805), icon, {'mode': 'selectionCategories', 'url': url, 'target': 'filtrateMovSer', 'extras': 'Nach Land'})
	addDir(translation(30810), icon, {'mode': 'listSeries', 'url': url})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selectionCategories(url, TYPE, CATEGORY):
	debug_MS("(navigator.selectionCategories) -------------------------------------------------- START = selectionCategories --------------------------------------------------")
	debug_MS(f"(navigator.selectionCategories) ### URL = {url} ### TYPE = {TYPE} ### CATEGORY = {CATEGORY} ###")
	content = getUrl(url, 'LOAD')
	result = content[content.find('data-name="'+CATEGORY+'"')+1:]
	result = result[:result.find('</ul>')]
	part = result.split('class="filter-entity-item"')
	for i in range(1, len(part), 1):
		element = re.sub(r'</?strong>', '', part[i])
		matchNO = re.compile(r'''<span class=["'](?:light|lighten)["']>\(([^<]+?)\)</span>''', re.S).findall(element)
		NUMBER = matchNO[0].strip() if matchNO else None
		if 'href=' in element:
			matchUN = re.compile(r'''href=["']([^"']+)["'](?: title=.+?["']>|>)([^<]+?)</a>''', re.S).findall(element)
			LINK = BASE_URL+matchUN[0][0]
			NAME = cleaning(matchUN[0][1])
		else:
			matchH1 = re.compile(r'''<span class=["']ACr([^"']+) item-content["'] title=.+?["']>([^<]+?)</span>''', re.S).findall(element)
			matchH2 = re.compile(r'''<span class=["']acLnk ([^"']+)["']>([^<]+?)</span>''', re.S).findall(element)
			LINK = BASE_URL+convert64(matchH1[0][0]) if matchH1 else BASE_URL+decodeURL(matchH2[0][0])
			NAME = cleaning(matchH1[0][1]) if matchH1 else cleaning(matchH2[0][1])
		if NUMBER: NAME += f"   [B][COLOR yellow]({str(NUMBER)})[/COLOR][/B]"
		debug_MS(f"(navigator.selectionCategories[1]) ##### NAME : {NAME} || LINK : {LINK} #####")
		addDir(NAME, icon, {'mode': TYPE, 'url': LINK})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selectionWeek(url):
	debug_MS("(navigator.selectionWeek) -------------------------------------------------- START = selectionWeek --------------------------------------------------")
	debug_MS(f"(navigator.selectionWeek) ### URL = {url} ###")
	content = getUrl(url, 'LOAD')
	result = content[content.find('<div class="pagination pagination-select">')+1:]
	result = result[:result.find('<span class="txt">Nächste</span><i class="icon icon-right icon-arrow-right-a">')]
	matchUN = re.compile(r'''<option value=["']ACr([^"']+)["']([^<]+)</option>''', re.S).findall(result)
	for link, title in matchUN:
		LINK = convert64(link)
		xDate = re.sub(r'filme-vorschau/de/week-|/', '', link)
		title = title.replace('>', '')
		NAME = translation(30831).format(cleaning(title.replace('selected', ''))) if "selected" in title else cleaning(title)
		debug_MS(f"(navigator.selectionWeek[1]) ##### NAME : {NAME} || DATE : {xDate} #####")
		addDir(NAME, icon, {'mode': 'listMovies', 'url': BASE_URL+LINK, 'extras': xDate})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTrailer(url, PAGE, POS):
	debug_MS("(navigator.listTrailer) -------------------------------------------------- START = listTrailer --------------------------------------------------")
	NEW_URL = f"{url}?page={PAGE}" if int(PAGE) > 1 else url
	debug_MS(f"(navigator.listTrailer) ### URL = {NEW_URL} ### PAGE = {PAGE} ###")
	content = getUrl(NEW_URL, 'LOAD')
	if enableBACK and PLACEMENT == '0' and int(PAGE) > 1:
		addDir(translation(30832), f"{artpic}backmain.png", {'mode': 'callingMain'})
	matchPG = re.findall(r'''<nav class=["']pagination(.+?)<div class=["']mdl-rc["']>''', content, re.S)
	if int(POS) == 0 and matchPG:
		PG_ONE = re.compile(r'''<a class=["']button button-md item["'] href=.+?page=[0-9]+["']>([0-9]+)</a></div></nav>''', re.S).findall(matchPG[0])
		PG_TWO = re.compile(r'''<span class=["']ACr.+?button-md item["']>([0-9]+)</span></div></nav>''', re.S).findall(matchPG[0])
		POS = PG_ONE[0] if PG_ONE else PG_TWO[0] if PG_TWO else POS
		debug_MS(f"(navigator.listTrailer[1]) NEXTPAGES ### Pages-Maximum : {str(POS)} ###")
	result = content[content.find('<main id="content-layout" class="content-layout cf">')+1:]
	result = result[:result.find('<div class="mdl-rc">')]
	part = result.split('<figure class="thumbnail')
	for i in range(1, len(part), 1):
		element = re.sub(r'</?strong>', '', part[i])
		IMAGE = re.compile(r'''(?:src=|["']src["']:)["'](https?://.+?[a-z0-9]+(?:\.png|\.jpg|\.jpeg|\.gif))["'?]''', re.S|re.IGNORECASE).findall(element)[0]
		THUMB = enlargeIMG(IMAGE)
		RUNTIME = re.compile(r'''class=["']thumbnail-count["']>([^<]+?)</span>''', re.S).findall(element)
		DURATION = get_Time(RUNTIME[0]) if RUNTIME else None
		matchH1 = re.compile(r'''(?:class=["']meta-title-link["']|<a) href=["']([^"']+)["'](?: class=["']layer-link["'])?>([^<]+)</a>''', re.S).findall(element)
		matchH2 = re.compile(r'''class=["']ACr([^ "']+) thumbnail-container thumbnail-link["'] title=["']([^"']+)["']''', re.S).findall(element)
		LINK = BASE_URL+matchH1[0][0] if matchH1 else BASE_URL+convert64(matchH2[0][0])
		NAME = cleaning(matchH1[0][1]) if matchH1 else cleaning(matchH2[0][1])
		VIEWS = re.compile(r'''class=["']meta-sub light["']>(.+?)</div>''', re.S).findall(element)
		VISITORS = cleaning(re.sub(r'\<.*?\>', '', VIEWS[0])) if VIEWS else None
		if '/interviews' in NEW_URL:
			PLOT, NAME = NAME, 'FILMSTARTS - Interview'
			PLOT += f"[CR][CR][COLOR gold]{VISITORS}[/COLOR]" if VISITORS else ""
		else: PLOT = f"[COLOR gold]{VISITORS}[/COLOR]" if VISITORS else ""
		debug_MS(f"(navigator.listTrailer[2]) ##### NAME : {NAME} || LINK : {LINK} #####")
		debug_MS(f"(navigator.listTrailer[2]) ##### DURATION : {str(DURATION)} || THUMB : {THUMB} #####")
		addLink(NAME, THUMB, {'mode': 'playVideo', 'url': LINK, 'extras': url}, PLOT, duration=DURATION)
	if int(POS) > int(PAGE):
		debug_MS(f"(navigator.listTrailer[3]) NEXTPAGES ### Now show NextPage ... No.{str(int(PAGE)+1)} ... ###")
		addDir(translation(30833).format(int(PAGE)+1), f"{artpic}nextpage.png", {'mode': 'listTrailer', 'url': url, 'page': int(PAGE)+1, 'position': int(POS)})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listMovies(url, PAGE, POS):
	debug_MS("(navigator.listMovies) -------------------------------------------------- START = listMovies --------------------------------------------------")
	FOUND = 0
	NEW_URL = f"{url}?page={PAGE}" if int(PAGE) > 1 else url
	debug_MS(f"(navigator.listMovies) ### URL = {NEW_URL} ### PAGE = {PAGE} ###")
	content = getUrl(NEW_URL, 'LOAD')
	if enableBACK and PLACEMENT == '0' and ((int(PAGE) > 1 and not 'filme-vorschau/' in NEW_URL) or ('filme-vorschau/' in NEW_URL)):
		addDir(translation(30832), f"{artpic}backmain.png", {'mode': 'callingMain'})
	matchPG = re.findall(r'''<nav class=["']pagination(.+?)<div class=["']mdl-rc["']>''', content, re.S)
	if int(POS) == 0 and matchPG:
		PG_ONE = re.compile(r'''<a class=["']button button-md item["'] href=.+?page=[0-9]+["']>([0-9]+)</a></div></nav>''', re.S).findall(matchPG[0])
		PG_TWO = re.compile(r'''<span class=["']ACr.+?button-md item["']>([0-9]+)</span></div></nav>''', re.S).findall(matchPG[0])
		POS = PG_ONE[0] if PG_ONE else PG_TWO[0] if PG_TWO else POS
		debug_MS(f"(navigator.listMovies[1]) NEXTPAGES ### Pages-Maximum : {str(POS)} ###")
	result = content[content.find('<main id="content-layout" class="content-layout cf">')+1:]
	result = result[:result.find('<div class="mdl-rc">')]
	part = result.split('<figure class="thumbnail')
	for i in range(1, len(part), 1):
		element = part[i]
		movieDATE, genre, director, rating = (None for _ in range(4))
		genreLIST, directorLIST, castLIST = ([] for _ in range(3))
		FOUND += 1
		matchH1 = re.compile(r'''class=["']thumbnail-container thumbnail-link["'] href=["']([^"']+?)["'] title=["'](.+?)["']>''', re.S).findall(element)
		matchH2 = re.compile(r'''class=["']ACr([^ "']+) thumbnail-container thumbnail-link["'] title=["'](.+?)["']>''', re.S).findall(element)
		LINK = BASE_URL+matchH1[0][0] if matchH1 else BASE_URL+convert64(matchH2[0][0])
		NAME = cleaning(matchH1[0][1]) if matchH1 else cleaning(matchH2[0][1])
		IMAGE = re.compile(r'''src=["'](https?://.+?[a-z0-9]+(?:\.png|\.jpg|\.jpeg|\.gif))["'?]''', re.S|re.IGNORECASE).findall(element)[0]
		THUMB = enlargeIMG(IMAGE)
		SECTOR_1 = re.compile(r'''<div class=["']meta-body-item meta-body-info["']>(.+?)</div>''', re.S).findall(element) # Grab - Genres
		if '<span class="spacer">' in element:
			SECTOR_1 = re.compile(r'''<span class=["']spacer["']>/</span>(.+?)</div>''', re.S).findall(element)
		matchG = re.compile(r'''<span class=["']ACr.*?["']>(.+?)</span>''', re.S).findall(SECTOR_1[-1]) if SECTOR_1 else []
		genreLIST = [cleaning(gNames) for gNames in matchG if matchG]
		if genreLIST: genre = ' / '.join(sorted(genreLIST))
		SECTOR_2 = re.compile(r'''<div class=["']meta-body-item meta-body-direction["']>(.+?)</div>''', re.S).findall(element) # Grab - Directors
		matchD = re.compile(r'''(?:<span class=["']ACr|href=["']/personen).*?["']>(.+?)(?:</span>|</a>)''', re.S).findall(SECTOR_2[-1]) if SECTOR_2 else []
		directorLIST = [cleaning(dNames) for dNames in matchD if matchD]
		if directorLIST: director = ', '.join(sorted(directorLIST))
		SECTOR_3 = re.compile(r'''<div class=["']meta-body-item meta-body-actor["']>(.+?)</div>''', re.S).findall(element) # Grab - Casts
		matchC = re.compile(r'''(?:<span class=["']ACr|href=["']/personen).*?["']>(.+?)(?:</span>|</a>)''', re.S).findall(SECTOR_3[-1]) if SECTOR_3 else []
		if matchC and len(matchC) > 0:
			for index, person in enumerate(matchC, 1):
				actor = {'name': cleaning(re.sub(r'\<.*?>', '', person)), 'role': '', 'order': index, 'thumb': ''}
				if actor['name'] not in ['' , None]:
					if KODI_ov20:
						castLIST.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
					else: castLIST.append(actor)
		DESC = re.compile(r'''<div class=["']synopsis["']>(.+?)</div>''', re.S).findall(element) # Grab - Plot
		PLOT = cleaning(re.sub(r'\<.*?\>', '', DESC[0])) if DESC else None
		movieDATE = re.compile(r'''<span class=["']date["']>([^<]+?)</span>''', re.S).findall(element)
		if '/serien' in NEW_URL:
			movieDATE = re.compile(r'''<div class=["']meta-body-item meta-body-info["']>([^<]+?)<span class=["']spacer["']>/</span>''', re.S).findall(element)
		if movieDATE and len(movieDATE[0]) > 0:# and ('/serien' in NEW_URL or '/vorpremiere' in NEW_URL):
			if DESC and len(DESC[0]) > 10: PLOT += "[CR][CR][B][COLOR gold]"+str(movieDATE[0].replace('\n', '').replace(' - ', ' ~ ').strip())+"[/COLOR][/B]"
			else: PLOT = "[B][COLOR gold]"+str(movieDATE[0].replace('\n', '').replace(' - ', ' ~ ').strip())+"[/COLOR][/B]"
		try:
			SECTOR_4 = (element[element.find('User-Wertung')+1:] or element[element.find('Pressekritiken')+1:]) # Grab - Rating
			rating = re.compile(r'''class=["']stareval-note["']>([^<]+?)</span></div>''', re.S).findall(SECTOR_4)[0].strip().replace(',', '.')
		except: pass
		matchTT = re.compile(r'''<div class=["']buttons-holder["']>(.+?)</div>''', re.S).findall(element)
		TRAILER = True if matchTT and ('Trailer' in matchTT[0] or 'Teaser' in matchTT[0]) else False
		debug_MS(f"(navigator.listMovies[2]) ##### NAME : {NAME} || LINK : {LINK} #####")
		debug_MS(f"(navigator.listMovies[2]) ##### GENRE : {str(genre)} || THUMB : {THUMB} #####")
		debug_MS(f"(navigator.listMovies[2]) ##### REGIE : {str(director)} || CAST : {str(castLIST)} #####")
		if 'filme-vorschau/' in NEW_URL or '/vorpremiere' in NEW_URL or 'serien/beste/' in NEW_URL:
			addLink(NAME, THUMB, {'mode': 'playVideo', 'url': LINK, 'target': 'VORSCHAU', 'extras': url}, PLOT, genre, director, castLIST, rating)
		else:
			if (TRAILER or '<span class="ico-play-inner"></span>' in element) and not 'button btn-disabled' in element:
				addLink(NAME, THUMB, {'mode': 'playVideo', 'url': LINK, 'extras': url}, PLOT, genre, director, castLIST, rating)
			else:
				addDir(translation(30836).format(NAME), THUMB, {'mode': 'blankFUNC', 'url': 'NO VIDEO'}, PLOT, genre, director, castLIST, rating, False)
	if FOUND == 0:
		return dialog.notification(translation(30524), translation(30525), icon, 8000)
	if BEFORE_AND_AFTER and 'filme-vorschau/' in NEW_URL:
		try:
			LEFT = convert64(re.compile(r'''<span class=["']ACr([^ "']+) button button-md button-primary-full button-left["']>.*?span class=["']txt["']>Vorherige</span>''', re.S).findall(result)[0])
			RIGHT = convert64(re.compile(r'''<span class=["']ACr([^ "']+) button button-md button-primary-full button-right["']>.*?span class=["']txt["']>Nächste</span>''', re.S).findall(result)[0])
			BeforeDAY, AfterDAY = re.sub(r'filme-vorschau/de/week-|/', '', LEFT), re.sub(r'filme-vorschau/de/week-|/', '', RIGHT)
			before, after = datetime(*(time.strptime(BeforeDAY, '%Y-%m-%d')[0:6])), datetime(*(time.strptime(AfterDAY, '%Y-%m-%d')[0:6]))
			bxORG, axORG = before.strftime('%Y-%m-%d'), after.strftime('%Y-%m-%d')
			bxNEW, axNEW = before.strftime('%d.%m.%Y'), after.strftime('%d.%m.%Y')
			addDir(translation(30834).format(str(axNEW)), icon, {'mode': 'listMovies', 'url': BASE_URL+RIGHT, 'extras': axORG})
			addDir(translation(30835).format(str(bxNEW)), icon, {'mode': 'listMovies', 'url': BASE_URL+LEFT, 'extras': bxORG})
		except: pass
	if int(POS) > int(PAGE) and not 'filme-vorschau/' in NEW_URL:
		debug_MS(f"(navigator.listMovies[3]) NEXTPAGES ### Now show NextPage ... No.{str(int(PAGE)+1)} ... ###")
		addDir(translation(30833).format(int(PAGE)+1), f"{artpic}nextpage.png", {'mode': 'listMovies', 'url': url, 'page': int(PAGE)+1, 'position': int(POS)})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url, TYPE, REFER):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### URL = {url} ### TYPE = {TYPE} ### REFERER = {REFER} ### ")
	MEDIAS = []
	END_URL, FINAL_URL = (False for _ in range(2))
	if xbmc.Player().isPlaying():
		xbmc.Player().stop()
	if TYPE == 'VORSCHAU':
		content = getUrl(url, 'LOAD')
		FIRST = re.compile(r'''class=["']trailer item["'] href=["']([^"']+?)["'] title=["']Trailer["']>''', re.S).findall(content)
		END_URL = FIRST[0] if FIRST else False # <a class="trailer item" href="/kritiken/187945/trailer/19594426.html" title="Trailer">
		if not END_URL:
			selection = re.findall(r'''<main id=["']content-layout["'] class=["']content-layout entity movie cf(.+?)<div class=["']rc-content["']>''', content, re.S)
			for chtml in selection: # <span class="ACrL2tACryaXRpa2VuLzE4Nzk0NS90cmFpbGVyLzE5NTk0NDI2Lmh0bWw= button button-sm button-primary-full">
				SECOND = re.compile(r'''<span class=["']ACr([^ "']+?) button button-sm button-primary-full["']>''', re.S).findall(chtml)
				END_URL = convert64(SECOND[0]) if SECOND else False
	result = getUrl(BASE_URL+END_URL, method='LOAD', REF=url) if END_URL else getUrl(url, method='LOAD', REF=REFER)
	MP4_QUALITIES = ['high', 'standard', 'medium', 'low'] # high=_hd_013.mp4 // low=_l_013.mp4 // medium=_m_013.mp4 // standard=_sd_013.mp4
	THIRD = re.compile(r'''(?:class=["']player  js-player["']|class=["']player player-auto-play js-player["']|<div id=["']btn-export-player["'].*?) data-model=["'](.+?),&quot;disablePostroll&quot;''', re.S).findall(result)
	STREAMS = THIRD[0].replace('&quot;', '"')+"}" if THIRD else None
	debug_MS(f"(navigator.playVideo[1]) ##### Extraction of Stream-Links : {str(STREAMS)} #####")
	if STREAMS:
		DATA = json.loads(STREAMS)
		for item in DATA.get('videos', []):
			vidQualities = item.get('sources', '')
			for found in MP4_QUALITIES:
				for quality in vidQualities:
					if quality == found:
						MEDIAS.append({'url': vidQualities[quality], 'quality': quality, 'mimeType': 'video/mp4'})
	if MEDIAS:
		FINAL_URL = VideoBEST(MEDIAS[0]['url'])
		FINAL_URL = f"https:{FINAL_URL.replace(' ', '%20')}" if FINAL_URL[:4] != 'http' else FINAL_URL.replace(' ', '%20')
		log(f"(navigator.playVideo) StreamURL : {FINAL_URL}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL))
	else:
		failing(f"(navigator.playVideo[2]) ##### Die angeforderte Video-Url wurde leider NICHT gefunden !!! #####\n ##### URL : {url} #####")
		return dialog.notification(translation(30521).format('PLAY'), translation(30526), icon, 8000)

def VideoBEST(highest):
	standards = [highest, '', ''] # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	standards[1] = standards[0].replace('_l_', '_sd_').replace('_m_', '_sd_')
	standards[2] = standards[1].replace('_sd_', '_hd_')
	if standards[0] not in [standards[1], standards[2]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def addDir(name, image, params={}, plot=None, genre=None, director=None, cast=None, rating=None, folder=True):
	u = build_mass(params)
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name)
		vinfo.setPlot(plot)
		if genre and len(genre) > 3: vinfo.setGenres([genre])
		if director: vinfo.setDirectors([director])
		if isinstance(cast, (list, tuple)): vinfo.setCast(cast)
		if rating and str(rating.replace('.', '')).isdigit(): vinfo.setRating(float(rating), 0, 'Wertung', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
	else:
		vinfo = {}
		if isinstance(cast, (list, tuple)): liz.setCast(cast)
		vinfo['Title'] = name
		vinfo['Plot'] = plot
		if genre and len(genre) > 3: vinfo['Genre'] = genre
		if director: vinfo['Director'] = director
		if rating and str(rating.replace('.', '')).isdigit(): liz.setRating('Wertung', float(rating), 0, True) # liz.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
		liz.setInfo(type='Video', infoLabels=vinfo)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if enableBACK and PLACEMENT == '1' and params.get('url') == 'NO VIDEO':
		liz.addContextMenuItems([(translation(30650), 'RunPlugin({})'.format(build_mass({'mode': 'callingMain'})))])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, genre=None, director=None, cast=None, rating=None, duration=None):
	u = build_mass(params)
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name)
		vinfo.setPlot(plot)
		if str(duration).isdigit(): vinfo.setDuration(int(duration))
		if genre and len(genre) > 3: vinfo.setGenres([genre])
		if director: vinfo.setDirectors([director])
		if isinstance(cast, (list, tuple)): vinfo.setCast(cast)
		if rating and str(rating.replace('.', '')).isdigit(): vinfo.setRating(float(rating), 0, 'Wertung', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		vinfo.setMediaType('movie')
	else:
		vinfo = {}
		if isinstance(cast, (list, tuple)): liz.setCast(cast)
		vinfo['Title'] = name
		vinfo['Plot'] = plot
		if str(duration).isdigit(): vinfo['Duration'] = duration
		if genre and len(genre) > 3: vinfo['Genre'] = genre
		if director: vinfo['Director'] = director
		if rating and str(rating.replace('.', '')).isdigit(): liz.setRating('Wertung', float(rating), 0, True) # liz.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
		vinfo['Mediatype'] = 'movie'
		liz.setInfo(type='Video', infoLabels=vinfo)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	entries = []
	if enableBACK and PLACEMENT == '1':
		entries.append([translation(30650), 'RunPlugin({})'.format(build_mass({'mode': 'callingMain'}))])
	entries.append([translation(30654), 'Action(Queue)'])
	liz.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
