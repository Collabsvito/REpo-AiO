﻿# -*- coding: utf-8 -*-

from .common import *


def main_menu():
	if kistarter: add_views({'mode': 'list_categories', 'link': KIKA_CHAN.format('kp-app-start-channel-100', 'app'), 'route': 'extract'}, create_entries({'Title': translation(30601)}))
	if kibroads: add_views({'mode': 'list_categories', 'link': KIKA_CATS.format('broadcastSearch', 'app')}, create_entries({'Title': translation(30602)}))
	if kiserien: add_views({'mode': 'list_categories', 'link': KIKA_CHAN.format('kinderserien-100', 'de'), 'route': 'extract'}, create_entries({'Title': translation(30603)}))
	if kishows: add_views({'mode': 'list_categories', 'link': KIKA_CHAN.format('kindershows-100', 'de'), 'route': 'extract'}, create_entries({'Title': translation(30604)}))
	if kisports: add_views({'mode': 'list_categories', 'link': KIKA_CHAN.format('alle-videos-202', 'de'), 'route': 'extract'}, create_entries({'Title': translation(30605)}))
	if kimove1: add_views({'mode': 'list_categories', 'link': KIKA_CHAN.format('kinderfilme-100', 'de'), 'route': 'extract'}, create_entries({'Title': translation(30606)}))
	if kiwissen: add_views({'mode': 'list_categories', 'link': KIKA_CHAN.format('wissenssendung-kinder-100', 'de'), 'route': 'extract'}, create_entries({'Title': translation(30607)}))
	if addition: add_views({'mode': 'list_suthemes'}, create_entries({'Title': translation(30608)}))
	if audiovisu: add_views({'mode': 'list_categories', 'link': KIKA_CHAN.format('videos-mit-hoerfassung-102', 'de'), 'route': 'extract'}, create_entries({'Title': translation(30609)}))
	if audiovisu: add_views({'mode': 'list_categories', 'link': KIKA_CHAN.format('videos-mit-gebaerdensprache-102', 'de'), 'route': 'extract'}, create_entries({'Title': translation(30610)}))
	add_views({'mode': 'play_live', 'link': BASE_LIVE}, create_entries({'Title': translation(30611), 'Image': f"{artpic}livestream.png"}), False)
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30612), 'Image': f"{artpic}settings.png"}), False)
		if plugin_operate('inputstream.adaptive'):
			add_views({'mode': 'ietuning'}, create_entries({'Title': translation(30613), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_categories(target, sector, phase, extra, route):
	debug_MS("(navigator.list_categories) ------------------------------------------------ START = list_categories -----------------------------------------------")
	debug_MS(f"(navigator.list_categories) ### URL = {target} ### SECTOR = {sector} ### PHASE = {phase} ### EXTRA = {extra} ### ROUTE = {route} ###")
	if route == 'default':
		xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
		scrolling, page, block_table, suffix = 1, 0, None, 'app' if 'platform=kikaapp' in target else 'de'
		while scrolling > 0:
			block_table = track_content(target if scrolling == 1 else next_page, headers=WEB_HEADER)
			elements = 'plusContent' if block_table.get('plusContent', {}) else 'seasonEntries' if block_table.get('seasonEntries', {}) else 'content'
			for item in block_table.get(elements, []):
				if (sector != 'content' and phase == item.get('title') and item.get('teasers', {})) or sector == 'content':
					slices_table = item.get('teasers', []) if sector != 'content' and item.get('teasers', {}) else [item]
					for parts in slices_table:
						uuid, fanart = parts.get('uuid', None), None
						title = parts['title']
						teaser = parts.get('teaserText', None)
						models = parts.get('docType', None)
						genre = parts.get('contentCategoryTitle', None)
						pictures = (parts.get('teaserImage', None) or parts.get('image', None))
						pic_code = pictures.get('id', {}) if pictures else None
						thumb = f"{KIKA_ARTS}{pic_code}-resimage_v-tportrait34_w-640.jpg" if pic_code else icon
						clogo = f"{KIKA_ARTS}{parts['logo']['id']}-resimage_v-cropped_w-384.png" if parts.get('logo', {}) and parts['logo'].get('id', {}) else None
						if pic_code and any(pt.get('imageType') == 'tlargeWithLogo169' for pt in pictures.get('variants', {})):
							fanart = f"{KIKA_ARTS}{pic_code}-resimage_v-tlargeWithLogo169_w-1280.jpg"
						action, section, trails, lanes = 'list_episodes', 'videos', parts['title'], 'default'
						if elements in ['content','plusContent'] and models == 'broadcastSeries' and parts.get('api', {}) and parts['api'].get('id', {}):
							if parts.get('brandDetails', {}) and parts['brandDetails'].get('videoSubchannel', {}) and \
								parts['brandDetails']['videoSubchannel'].get('id', {}) and parts['brandDetails'].get('showSeason', True) is False:
								link = KIKA_VIDS.format(parts['brandDetails']['videoSubchannel']['id'])
							else: link = KIKA_BRAN.format(parts['api']['id'])
						elif elements in ['content','plusContent'] and models == 'channel' and parts.get('api', {}) and parts['api'].get('id', {}):
							action, link, section, trails, lanes = 'list_categories', KIKA_CHAN.format(parts['api']['id'], suffix), 'channel', parts['title'], 'extract' # Nochmal 'list_categories' da nur Ordner und keine Links in 'Channel' enthalten sind
						elif elements == 'seasonEntries' and parts.get('videosPageUrl', {}) and len(block_table.get('seasonEntries', {})) > 1:
							link = parts['videosPageUrl']
						elif elements == 'seasonEntries' and parts.get('videosPageUrl', {}) and len(block_table.get('seasonEntries', {})) == 1:
							return list_episodes(parts['videosPageUrl'], 0, 'videos', extra if extra else parts['title'], 'unk')
						else: continue
						fetch_items = {'Title': title, 'Plot': teaser, 'Image': thumb, 'Logo': clogo, 'Fanback': fanart}
						add_views({'mode': action, 'link': link, 'sector': section, 'phase': trails, 'extra': extra, 'route': lanes}, create_entries(fetch_items))
						debug_MS("-------------------------------------------------")
						debug_MS(f"(navigator.list_categories[1.1]) ##### TYPES : {models} || TITLE : {title} || LINK : {link} #####")
						debug_MS(f"(navigator.list_categories[1.1]) ##### SECTOR : {section} || PHASE : {trails} || EXTRA : {extra} || ROUTE : {lanes} || THUMB : {thumb} #####")
			if block_table and block_table.get('links', {}) and block_table['links'].get('next', {}):
				debug_MS("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~")
				scrolling, page = int(scrolling).__add__(1), int(page).__add__(1)
				next_page = re.sub(r'page=[0-9]+', f'page={int(page)}', target)
				debug_MS(f"(navigator.list_categories[2]) PAGES ### NOW GET NEXTPAGE : {next_page} ###")
			else: break
	else:
		results = track_content(target, headers=WEB_HEADER)
		if results.get('channelType') == 'brand' and results.get('id') == 'schloss-einstein-190':
			return list_categories(KIKA_SEAS.format('schloss-einstein-122', 'de'), 'content', results.get('title', {}), None, 'default')
		for item in results.get('plusContent', []):
			action, title, link, section = 'list_episodes', (item.get('title', '') or item.get('channelLinkTitle', '')), target, sector if sector == 'secondo' else 'content'
			if title in ['', None] or (item.get('boxType') == 'Channel' and not any(docs.get('docType') == 'broadcastSeries' for \
				docs in item.get('teasers', {}))) or (item.get('boxType') not in ['Channel', 'MainVideo', 'RelatedVideo']): continue # Ordner ohne ['Channel', 'MainVideo', 'RelatedVideo'] oder 'broadcastSeries' im Inhalt ausblenden
			if item.get('boxType') in ['MainVideo', 'RelatedVideo'] and not title.upper().startswith('NEUESTE ') and item.get('channelLink', {}) and \
				item['channelLink'].get('brandDetails', {}) and item['channelLink']['brandDetails'].get('videoSubchannel', {}) and \
				item['channelLink']['brandDetails']['videoSubchannel'].get('id', {}) and item['channelLink']['brandDetails'].get('showSeason', True) is False:
				link, section = KIKA_VIDS.format(item['channelLink']['brandDetails']['videoSubchannel']['id']), 'videos' # Keine Seasons vorhanden daher direkt Episoden auflisten
			extras = 'adContent' if 'hoerfassung' in target else 'dgsContent' if 'gebaerden' in target else 'mainContent'
			if item.get('boxType') == 'Channel':
				if 'hoerfassung' in target or 'gebaerden' in target: continue
				if item.get('channelLink', {}) and item['channelLink'].get('broadcastSeriesId', {}) and item.get('channelLinkTitle') == 'Staffelübersicht':
					action, link, section = 'list_categories', KIKA_SEAS.format(item['channelLink']['broadcastSeriesId'], 'de').replace('mainContent', extras), 'content' # Nochmal 'list_categories' da die Serien-Staffeln direkt angezeigt werden
				else: action, section = 'list_categories', 'channel' # Nochmal 'list_categories' da nur Ordner und keine Links in 'Channel' enthalten sind
			add_views({'mode': action, 'link': link, 'sector': section, 'phase': title, 'extra': extras}, create_entries({'Title': title}))
			debug_MS(f"(navigator.list_categories[1.2]) ##### TITLE/PHASE : {title} || LINK : {link} || SECTOR : {section} || EXTRA : {extras} || ROUTE : default #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin(f"Container.SetViewMode({viewsShows})")

def list_suthemes():
	debug_MS("(navigator.list_suthemes) ------------------------------------------------ START = list_suthemes -----------------------------------------------")
	if kimeiste: add_views({'mode': 'list_categories', 'link': KIKA_SUBS.format('meistgesucht-100', 'app'), 'sector': 'content', 'phase': translation(30621)}, create_entries({'Title': f"[B]{translation(30621)}[/B]"}))
	if kimove2: add_views({'mode': 'list_episodes', 'link': KIKA_SUBS.format('filme-und-maerchen-100', 'app'), 'phase': translation(30622)}, create_entries({'Title': f"[B]{translation(30622)}[/B]"}))
	if kireales: add_views({'mode': 'list_categories', 'link': KIKA_CATS.format('finiteSeriesReal', 'app'), 'sector': 'content', 'phase': translation(30623)}, create_entries({'Title': f"[B]{translation(30623)}[/B]"}))
	if kianime: add_views({'mode': 'list_categories', 'link': KIKA_CATS.format('finiteSeriesNonreal', 'app'), 'sector': 'content', 'phase': translation(30624)}, create_entries({'Title': f"[B]{translation(30624)}[/B]"}))
	if kidokus: add_views({'mode': 'list_categories', 'link': KIKA_SUBS.format('doku-100', 'app'), 'sector': 'content', 'phase': translation(30625)}, create_entries({'Title': f"[B]{translation(30625)}[/B]"}))
	if kilernen: add_views({'mode': 'list_categories', 'link': KIKA_SUBS.format('lernen-100', 'app'), 'sector': 'content', 'phase': translation(30626)}, create_entries({'Title': f"[B]{translation(30626)}[/B]"}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes(target, page, sector, phase, extra):
	debug_MS("(navigator.list_episodes) ------------------------------------------------ START = list_episodes -----------------------------------------------")
	debug_MS(f"(navigator.list_episodes) ### URL = {target} ### PAGE = {page} ### SECTOR = {sector} ### PHASE = {phase} ### EXTRA = {extra} ###")
	scrolling, counter, unikat, forward, block_table, following = 1, 0, set(), None, None, False
	if '/brands' in target and sector != 'secondo':
		data_uno = track_content(target, headers=WEB_HEADER)
		if data_uno.get('seasons', {}) and data_uno['seasons'].get('id', {}):
			return list_categories(KIKA_SEAS.format(data_uno['seasons']['id'], 'de'), 'content', data_uno.get('title', {}), None, 'default')
		elif data_uno.get('videoSubchannel', {}) and data_uno['videoSubchannel'].get('id', {}):
			forward = KIKA_VIDS.format(data_uno['videoSubchannel']['id'])
		elif data_uno.get('plusContent', {}) and len(data_uno['plusContent']) > 0:
			return list_categories(target, 'secondo', data_uno.get('title', {}), None, 'extract')
	elif '/channels' in target and not phase.upper().startswith('NEUESTE '):
		data_due = track_content(target, headers=WEB_HEADER)
		detect_uno = next(filter(lambda cmx: cmx.get('title') == phase and cmx.get('channelLink', {}) and cmx['channelLink'].get('docType') == 'subchannel', data_due.get('plusContent', [])), None)
		detect_due = next(filter(lambda cmx: cmx.get('title') == phase and cmx.get('channelLink', {}) and cmx['channelLink'].get('docType') == 'videoSubchannel', data_due.get('plusContent', [])), None)
		if detect_uno and extra in ['adContent', 'dgsContent', 'mainContent']:
			forward = KIKA_SUBS.format(detect_uno['channelLink']['id'], 'de').replace('mainContent', extra)
		elif detect_due and extra in ['adContent', 'dgsContent', 'mainContent']:
			if detect_due['channelLink'].get('videoSubchannelDetails', {}) and detect_due['channelLink']['videoSubchannelDetails'].get('showVideosInBrand', True) is False and \
				detect_due['channelLink'].get('broadcastSeriesId', {}) and not any(sox in detect_due['channelLink']['broadcastSeriesId'] for \
				sox in ['beutolomaeus', 'der-maus', 'dem-elefanten', 'logo-die-welt', 'said-und-anna']):
				return list_categories(KIKA_SEAS.format(detect_due['channelLink']['broadcastSeriesId'], 'de').replace('mainContent', extra), 'content', detect_due.get('title', {}), None, 'default')
			else: forward = KIKA_VIDS.format(detect_due['channelLink']['id']).replace('mainContent', extra)
	outpace = forward if forward else target
	while scrolling > 0:
		block_table = track_content(outpace if scrolling == 1 else next_page, headers=WEB_HEADER)
		elements = 'plusContent' if block_table.get('plusContent', {}) else 'content'
		for item in block_table.get(elements, []):
			if (elements == 'plusContent' and item.get('boxType') not in ['MainVideo', 'RelatedVideo']) or (elements == 'content' and not 'VIDEO' in item.get('docType', '').upper()): continue # Blende Einträge ohne Video aus
			if (sector != 'videos' and (phase == item.get('title') or phase == item.get('channelLinkTitle'))) or ('/channels' in target and forward) or sector == 'videos':
				slices_table = item.get('teasers', []) if sector != 'videos' and item.get('teasers', {}) else [item]
				for parts in slices_table:
					for method in get_sorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
					desc, (serie, start_times, airing, starting, ends_times, teaser, season, episode, duration, mpaa) = "", (None for _ in range(10))
					uuid, fanart = parts.get('uuid', None), None
					title = cleaning(parts['title'])
					if parts.get('broadcastSeriesTitle', {}):
						serie = cleaning(parts['broadcastSeriesTitle'])
						desc += translation(30641).format(serie)
						title = title if any(vs in outpace for vs in ['/teasers', '/videos']) and not 'filme-' in outpace else f"{title} - {serie}"
					video_code = parts.get('id', None)
					if str(parts.get('date'))[:4].isdecimal() and str(parts.get('date'))[:4] not in ['0000','1970'] and str(parts.get('date'))[:1] != '0': # 2020-05-08T07:45:00+02:00
						broadcast = datetime(*(time.strptime(parts['date'][:19], '%Y-%m-%dT%H:%M:%S')[0:6])) # 2022-03-28T19:50:00+02:00
						start_times = broadcast.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						airing = broadcast.strftime('%d.%m.%Y') # FirstAired
						starting = broadcast.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else broadcast.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
					if str(parts.get('endDate'))[:4].isdecimal() and str(parts.get('endDate'))[:4] not in ['0000','1970'] and str(parts.get('endDate'))[:1] != '0': # 2020-05-08T07:45:00+02:00
						available = datetime(*(time.strptime(parts['endDate'][:19], '%Y-%m-%dT%H:%M:%S')[0:6])) # 2023-03-28T19:50:00+02:00
						ends_times = available.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
					teaser = parts.get('teaserText', None)
					feature = (parts.get('videoDetails', '') or parts.get('relatedVideoDetails', ''))
					if feature:
						season = f"{int(feature['season']):02}" if str(feature.get('season')).isdecimal() and int(feature['season']) != 0 else None
						episode = f"{int(feature['episodeNumber']):02}" if str(feature.get('episodeNumber')).isdecimal() and int(feature['episodeNumber']) != 0 else None
						if season and episode: desc += translation(30642).format(season, episode)
						elif season is None and episode: desc += translation(30643).format(episode)
						teaser = feature['description'] if feature.get('description', {}) else teaser
						duration = feature['durationInSeconds'] if str(feature.get('durationInSeconds')).isdecimal() else None
						mpaa = str(feature['fsk']) if str(feature.get('fsk')).isdecimal() and int(feature['fsk']) != 0 else None
					if start_times and ends_times: desc += translation(30644).format(start_times, ends_times)
					elif start_times and ends_times is None: desc += translation(30645).format(start_times)
					if teaser: desc += f"[CR]{cleaning(teaser)}"
					if parts.get('logo', {}) and parts['logo'].get('title', {}):
						station = parts['logo']['title'].split('Rechte: ')[1].split('/')[0] if 'Rechte:' in parts['logo']['title'] else None
						if station: desc += translation(30646).format(station) if teaser else translation(30647).format(station)
					pictures = (parts.get('teaserImage', None) or parts.get('image', None))
					pic_code = pictures.get('id', {}) if pictures else None
					thumb = f"{KIKA_ARTS}{pic_code}-resimage_v-original.jpg" if pic_code else icon
					clogo = f"{KIKA_ARTS}{parts['logo']['id']}-resimage_v-cropped_w-384.png" if parts.get('logo', {}) and parts['logo'].get('id', {}) else None
					if pic_code and any(pt.get('imageType') == 'tlargeWithLogo169' for pt in pictures.get('variants', {})):
						fanart = f"{KIKA_ARTS}{pic_code}-resimage_v-tlargeWithLogo169_w-1280.jpg"
					counter += 1
					fetch_parts = {'Title': title, 'TvShowTitle': None if serie and serie in title else serie,'Plot': desc, 'Season': season, 'Episode': episode, \
						'Duration': duration, 'Date': starting, 'Aired': airing, 'Mpaa': mpaa, 'Mediatype': 'episode' if episode else 'movie', \
						'Image': thumb, 'Logo': clogo, 'Fanback': fanart, 'Reference': 'Single'}
					debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
					debug_MS(f"(navigator.list_episodes[2]) ### COUNT-02 : {counter} || ENTRY-02 : {fetch_parts} ###")
					add_views({'mode': 'play_video', 'link': video_code}, create_entries(fetch_parts), False)
		if block_table and block_table.get('links', {}) and block_table['links'].get('next', {}):
			if int(scrolling) < 4: # Maximum of total 4 Pages
				debug_MS("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~")
				scrolling, page = int(scrolling).__add__(1), int(page).__add__(1)
				next_page = re.sub(r'page=[0-9]+', f'page={int(page)}', outpace)
				debug_MS(f"(navigator.list_episodes[3]) PAGES ### NOW GET NEXTPAGE : {next_page} ###")
			else: following = True; break
		else: break
	if block_table and following is True:
		debug_MS("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~")
		debug_MS(f"(navigator.list_episodes[4]) PAGES ### ADDING NEXTPAGE ... No.{int(page)+1} ... ###")
		next_link, matches = re.sub(r'page=[0-9]+', f'page={int(page)+1}', outpace), 2 if int(page) == 3 else int(page+1) // 4 + 1
		section = 'videos' if any(tvx in outpace for tvx in ['/teasers', '/videos']) else sector
		fetch_items = create_entries({'Title': translation(30650).format(matches), 'Image': f"{artpic}nextpage.png"})
		add_views({'mode': 'list_episodes', 'link': next_link, 'page': int(page)+1, 'sector': section, 'phase': phase, 'extra': extra}, fetch_items)
	if counter == 0:
		return dialog.notification(translation(30525), translation(30526).format(phase), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin(f"Container.SetViewMode({viewsVideos})")

def play_video(videoID):
	debug_MS("(navigator.play_video) ------------------------------------------------ START = play_video -----------------------------------------------")
	debug_MS(f"(navigator.play_video) ### ORIGIN : {PLAY_ANDO.format(videoID)} ###")
	KiKA_QUALITIES = [5, 4, 3, 2, 1, 0, 'uhd', 'fhd', 'hd', 'veryhigh', 'high', 'med', 'low', 3840, 2560, 1920, 1280, 1024, 960, 852, 720, 640, 512, 480, 320]
	(default, STREAM, FINAL_URL), (MEDIAS, SELECTION) = (False for _ in range(3)), ([] for _ in range(2))
	data_uno = track_content(PLAY_ANDO.format(videoID), headers=WEB_HEADER)
	for asset in data_uno.get('assets', []):
		automatic = (asset.get('quality', '') or asset.get('type', '') or 'unknown')
		default = asset['url'] if automatic == 'auto' and 'm3u8' in asset.get('url') else False
		variable = (asset.get('url', None) or None)
		delivery = (asset.get('delivery', '') or asset.get('type', '') or 'unknown')
		quality = (asset.get('width', None) or asset.get('frameWidth', None))
		if variable and quality:
			MEDIAS.append({'url': variable, 'delivery': delivery, 'quality': quality, 'document': 'ANDROID'})
	if MEDIAS:
		debug_MS(f"(navigator.play_video[1]) ORIGINAL_MP4 ### unsorted_LIST : {MEDIAS} ###")
		order_dict = {qual: index for index, qual in enumerate(KiKA_QUALITIES)}
		SELECTION = sorted(MEDIAS, key=lambda xs: order_dict.get(xs['quality'], float('inf')))
		debug_MS(f"(navigator.play_video[1]) SORTED_MP4 ###### sorted_LIST : {SELECTION} ###")
	if (enable_adaptive or prefer_stream == 0) and default:
		debug_MS("(navigator.play_video[2]) ~~~~~ TRY NUMBER ONE TO GET THE FINALURL (m3u8) ~~~~~")
		STREAM = 'HLS' if enable_adaptive else 'M3U8'
		MIME, QUALITY, FINAL_URL = 'application/vnd.apple.mpegurl', 'AUTO', default
	if not FINAL_URL and SELECTION:
		debug_MS("(navigator.play_video[3]) ~~~~~ TRY NUMBER TWO TO GET THE FINALURL (mp4) ~~~~~")
		kika_link = f"https:{SELECTION[0]['url']}" if SELECTION[0]['url'][:4] != 'http' else SELECTION[0]['url']
		STREAM, MIME, QUALITY, FINAL_URL = 'MP4', 'video/mp4', f"{str(SELECTION[0]['quality'])}p", improve_video(kika_link) # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	if FINAL_URL and STREAM:
		LSM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		LSM.setMimeType(MIME); LSM.setContentLookup(False)
		if plugin_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			IA_NAME = 'inputstream.adaptive'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			LSM.setProperty('inputstream', IA_NAME)
			if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", STREAM.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
			LSM.setProperty(f"{IA_NAME}.{PHRASE}_headers", f"User-Agent={WEB_AGENT}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
			if int(IA_VERSION) >= 2150:
				LSM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey') # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.play_video) [{QUALITY}] {STREAM}_stream : {FINAL_URL}")
	else:
		failing(f"(navigator.play_video) ##### Abspielen des Streams NICHT möglich ##### URL : {PLAY_ANDO.format(videoID)} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *kika.de* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('PLAYER'), translation(30527), icon, 10000)

def play_live(target):
	debug_MS("(navigator.play_live) ------------------------------------------------ START = play_live -----------------------------------------------")
	LTM = xbmcgui.ListItem(re.sub(r'\[/?B\]', '', translation(30611)), path=target, offscreen=True)
	LTM.setArt({'icon': icon, 'thumb': f"{artpic}livestream.png", 'poster': f"{artpic}livestream.png"})
	LTM.setMimeType('application/vnd.apple.mpegurl')
	if plugin_operate('inputstream.adaptive'):
		LTM.setProperty('inputstream', 'inputstream.adaptive')
		if KODI_BUILD in [19, 20]: LTM.setProperty('inputstream.adaptive.manifest_type', 'hls') # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
		PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
		LTM.setProperty(f"inputstream.adaptive.{PHRASE}_headers", f"User-Agent={WEB_AGENT}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
	xbmc.Player().play(item=target, listitem=LTM)

def improve_video(highest):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen // aktualisiert am 23.11.2024
	standards = [highest, '', '', ''] # Seite zur Überprüfung : https://github.com/mediathekview/MServer/blob/master/src/main/java/mServer/crawler/sender/zdf/ZdfVideoUrlOptimizer.java
	route_one = (('808k_p11v15', '2360k_p35v15'), ('1456k_p13v11', '2328k_p35v11'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'), ('1628k_p13v15', '2360k_p35v15'),
							('1628k_p13v17', '2360k_p35v17'), ('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
	route_two = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'), ('2360k_p35v17', '3360k_p36v17'))
	route_tree = (('3360k_p36v15', '4692k_p72v16'), ('3360k_p36v17', '6660k_p37v17'))
	standards[1] = reduce(lambda m, kv: m.replace(*kv), route_one, standards[0])
	standards[2] = reduce(lambda n, kv: n.replace(*kv), route_two, standards[1])
	standards[3] = reduce(lambda o, kv: o.replace(*kv), route_tree, standards[2])
	if standards[0] not in [standards[1], standards[2], standards[3]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def add_views(params, listitem, folder=True):
	uws = build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
