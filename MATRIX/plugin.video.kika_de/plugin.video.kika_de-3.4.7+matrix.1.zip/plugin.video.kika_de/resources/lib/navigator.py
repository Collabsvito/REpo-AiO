﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import time
from datetime import datetime, timedelta
from urllib.parse import urlencode
from urllib.request import urlopen
from functools import reduce

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin('Addon.OpenSettings({})'.format(addon_id))

def mainMenu():
	if newest: addDir(translation(30601), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&orderBy=appearDate&orderDirection=desc', 'extras': 'nopager'})
	if viewed: addDir(translation(30602), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&orderBy=viewCount&orderDirection=desc', 'extras': 'nopager'})
	if chance: addDir(translation(30603), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&orderBy=expirationDate&orderDirection=asc', 'extras': 'nopager'})
	if kikaninchen: 
		addDir(translation(30604), artpic+'kikaninchen.jpg', {'mode': 'listEpisodes', 'url': '/api/brands/ebb32e6f-511f-450d-9519-5cbf50d4b546/videos', 'transmit': 'Kikaninchen'})
		addDir(translation(30605), artpic+'freunde.jpg', {'mode': 'listEpisodes', 'url': '/api/brands/9ed5cf37-2e09-4074-9935-f51ae06e45b1/videos', 'transmit': 'Kikaninchen und Freunde'})
	if sesamstrasse: addDir(translation(30606), artpic+'sesamstrasse.jpg', {'mode': 'listEpisodes', 'url': '/api/brands/3e3e70b3-62a2-40cb-856d-a46d3e210e9c/videos', 'transmit': 'Sesamstrasse'})
	if lollywood: addDir(translation(30607), artpic+'filme.jpg', {'mode': 'listEpisodes', 'url': '/api/brands/a4b0918c-0d21-4160-afb0-2dc789534a8e/videos', 'transmit': 'Lollywood'})
	if till03: addDir(translation(30608), icon, {'mode': 'listShows', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc&userAge=3'})
	if till06: addDir(translation(30609), icon, {'mode': 'listShows', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc&userAge=6'})
	if till10: addDir(translation(30610), icon, {'mode': 'listShows', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc&userAge=9'})
	if tillAll: addDir(translation(30611), icon, {'mode': 'listShows', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc'})
	if especials:
		addDir(translation(30612), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&videoTypes=dgsContent&orderBy=title&orderDirection=asc', 'extras': 'LongTitle'})
		addDir(translation(30613), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&videoTypes=adContent&orderBy=title&orderDirection=asc', 'extras': 'LongTitle'})
	addDir(translation(30614), artpic+'livestream.png', {'mode': 'playLIVE', 'url': BASE_LIVE}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30615), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30616), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listShows(url, EXTRA):
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listShows) ------------------------------------------------ START = listShows -----------------------------------------------")
	content = {'_links': {'next': {'href': url}}}
	while 'next' in content['_links']:
		content = getUrl(MOBIL_API+content['_links']['next']['href'])
		for item in content['_embedded']['items']:
			name = translation(30621).format(item['title'], str(item['totalVideos'])) if item.get('totalVideos', '') else item['title']
			addDir(name, item['mediumBrandImageUrl'], {'mode': 'listEpisodes', 'url': item['_links']['videos']['href']}, item['description'], item['largeTeaserImageUrl'])
			debug_MS("(navigator.listShows[1]) no.01 ##### GROUP : {} || TITLE : {} || THUMB : {} #####".format(str(item['targetGroup']), name, item['mediumBrandImageUrl']))
		if EXTRA == 'nopager':
			break
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDShows+')')

def listEpisodes(url, EXTRA, TRANS):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### URL : {} ### EXTRA : {} ### SERIE : {} ###".format(url, EXTRA, TRANS))
	COMBI_EPISODE = []
	SingleENTRY = set()
	pos1 = 0
	content = {'_links': {'next': {'href': url}}}
	while 'next' in content['_links']:
		content = getUrl(MOBIL_API+content['_links']['next']['href'])
		for item in content['_embedded']['items']:
			debug_MS("(navigator.listEpisodes[1]) no.01 ### ITEM-01 : {} ###".format(str(item)))
			SERIE_1, VIEWS, startTIMES, BEGINS_1, endTIMES, STUDIO_1 = (None for _ in range(6))
			DESC_1 = ""
			TITLE_1 = cleaning(item['title'])
			if item.get('_embedded', '') and item['_embedded'].get('brand', '') and item['_embedded']['brand'].get('title', ''):
				SERIE_1 = cleaning(item['_embedded']['brand']['title'])
				if EXTRA in ['nopager', 'LongTitle']:
					TITLE_1 += ' - '+SERIE_1
			if item['videoType'] != 'mainContent' and not especials:
				continue
			IDD_1 = (item.get('id', None) or None)
			THUMB_1 = (item.get('largeTeaserImageUrl', '') or icon)
			VIEWS = (item.get('viewCount', None) or None)
			SEAS_1 = (item.get('seasonNumber', None) or None)
			EPIS_1 = (item.get('episodeNumber', None) or None)
			TAGLINE_2 = translation(30622).format(str(SEAS_1).zfill(2), str(EPIS_1).zfill(2)) if SEAS_1 and EPIS_1 else translation(30623).format(str(EPIS_1).zfill(2)) if SEAS_1 is None and EPIS_1 else None
			if SERIE_1 and VIEWS: DESC_1 += translation(30624).format(str(SERIE_1), str(VIEWS))
			elif SERIE_1 and VIEWS is None: DESC_1 += translation(30625).format(str(SERIE_1))
			if str(item.get('appearDate'))[:4].isdigit(): # 2020-05-08T07:45:00+02:00
				try:
					startDates = datetime(*(time.strptime(item['appearDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2022-03-28T19:50:00+02:00
					startTIMES = startDates.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
					BEGINS_1 = startDates.strftime('%d{0}%m{0}%Y').format('.')
				except: pass
			if str(item.get('expirationDate'))[:4].isdigit(): # 2020-05-08T07:45:00+02:00
				try:
					endDates = datetime(*(time.strptime(item['expirationDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2023-03-28T19:50:00+02:00
					endTIMES = endDates.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				except: pass
			if startTIMES and endTIMES: DESC_1 += translation(30626).format(str(startTIMES), str(endTIMES))
			elif startTIMES and endTIMES is None: DESC_1 += translation(30627).format(str(startTIMES))
			if item.get('description', ''): DESC_1 += '[CR]'+cleaning(item['description'])
			if item.get('broadcaster', ''):
				DESC_1 += translation(30628).format(cleaning(item['broadcaster'])) if item.get('description', '') else translation(30629).format(cleaning(item['broadcaster']))
				STUDIO_1 = cleaning(item['broadcaster'])
			DURATION_1 = get_Time(item['duration']) if item.get('duration', '') else None
			pos1 += 1
			COMBI_EPISODE.append([int(pos1), IDD_1, STUDIO_1, TITLE_1, SERIE_1, SEAS_1, EPIS_1, THUMB_1, DESC_1, TAGLINE_2, DURATION_1, BEGINS_1])
		if EXTRA == 'nopager':
			break
	if COMBI_EPISODE:
		for position, PLAYLINK, studio, name, seriesname, season, episode, photo, plot, tagline, duration, begins in COMBI_EPISODE:
			for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			if PLAYLINK is not None and PLAYLINK in SingleENTRY:
				continue
			SingleENTRY.add(PLAYLINK)
			debug_MS("(navigator.listEpisodes[2]) no.02 ##### TITLE : {} || SERIE : {} || THUMB : {} #####".format(name, str(seriesname), photo))
			debug_MS("(navigator.listEpisodes[2]) no.02 ##### VIDID : {} || EPISODE : {} || STUDIO : {} #####".format(str(PLAYLINK), str(episode), str(studio)))
			addLink(name, photo, {'mode': 'playVideo', 'url': PLAYLINK, 'extras': 'ANDROID'}, plot, tagline, duration, seriesname, season, episode, studio, begins)
	else:
		dialog.notification(translation(30525), translation(30526).format(TRANS), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')

def playVideo(videoID, EXTRA):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS("(navigator.playVideo) ### videoID : {} ### EXTRA : {} ###".format(videoID, EXTRA))
	All_QUALITIES = [5, 4, 3, 2, 1, 0, 'hd', 'veryhigh', 'high', 'med', 'low', 3840, 2560, 1920, 1280, 1024, 960, 852, 720, 640, 512, 480, 320]
	M3U8_Url, finalURL, QUALITY, STREAM = (False for _ in range(4))
	MEDIAS, bestMEDIA = ([] for _ in range(2))
	if EXTRA == 'DEFAULT':
		content = getUrl(videoID, 'LOAD')
		docuID = re.compile(r'{"docType":"externalVideo","id":"([^"]+)","uuid"', re.S).findall(content)
		videoID = docuID[0] if docuID else None# https://www.kika.de/_next-api/proxy/v1/videos/zehn-aufgeregt-ins-halbfinale-100/assets
	if videoID not in [None, 'None']:
		DATA_ONE = getUrl(MOBIL_PLAYER.format(videoID)) if EXTRA == 'ANDROID' else getUrl(API_PLAYER.format(videoID))
		for entry in DATA_ONE['assets']:
			AUTO = (entry.get('quality', '') or entry.get('type', '') or 'Unknown')
			if AUTO == 'auto' and 'm3u8' in entry.get('url'):
				M3U8_Url = entry['url']
		DATA_TWO = DATA_ONE['hbbtvAssets'] if EXTRA == 'ANDROID' else DATA_ONE['assets']
		for item in DATA_TWO:
			DOC = 'API_DROID' if EXTRA == 'ANDROID' else 'API_WEB'
			MP4 = (item.get('url', None) or None)
			TYPE = (item.get('delivery', '') or item.get('type', '') or 'Unknown')
			QUAL = (item.get('width', None) or item.get('frameWidth', None) or None)
			if MP4 and QUAL:
				MEDIAS.append({'url': MP4, 'delivery': TYPE, 'quality': QUAL, 'document': DOC})
	if MEDIAS:
		debug_MS("(navigator.playVideo[1]) ORIGINAL_MP4 ### unsorted_LIST : {0} ###".format(str(MEDIAS)))
		order_dict = {qual: index for index, qual in enumerate(All_QUALITIES)}
		bestMEDIA = sorted(MEDIAS, key=lambda x: order_dict.get(x['quality'], float('inf')))
		debug_MS("(navigator.playVideo[1]) SORTED_MP4 ###### sorted_LIST : {0} ###".format(str(bestMEDIA)))
	if (enableINPUTSTREAM or prefSTREAM == '0') and M3U8_Url:
		debug_MS("(navigator.playVideo[2]) ~~~~~ TRY NUMBER ONE TO GET THE FINALURL (m3u8) ~~~~~")
		STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
		MIME, QUALITY, finalURL = 'application/vnd.apple.mpegurl', 'AUTO', M3U8_Url
	if not finalURL and bestMEDIA:
		debug_MS("(navigator.playVideo[3]) ~~~~~ TRY NUMBER TWO TO GET THE FINALURL (mp4) ~~~~~")
		MP4_Url = bestMEDIA[0]['url'] if bestMEDIA[0]['url'].startswith('http') else 'https:'+bestMEDIA[0]['url']
		STREAM, MIME, QUALITY, finalURL = 'MP4', 'video/mp4', str(bestMEDIA[0]['quality'])+'p', VideoBEST(MP4_Url) # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	if finalURL and STREAM:
		LSM = xbmcgui.ListItem(path=finalURL)
		LSM.setMimeType(MIME)
		if ADDON_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			LSM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log("(navigator.playVideo) [{0}] {1}_stream : {2} ".format(QUALITY, STREAM, finalURL))
	else:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *kika.de* gefunden !!! ##########".format(str(videoURL)))
		return dialog.notification(translation(30521).format('STREAM'), translation(30527), icon, 8000)

def playLIVE(url):
	debug_MS("(navigator.playLIVE) ------------------------------------------------ START = playLIVE -----------------------------------------------")
	LTM = xbmcgui.ListItem(path=url, label=translation(30614))
	LTM.setMimeType('application/vnd.apple.mpegurl')
	if ADDON_operate('inputstream.adaptive'):
		LTM.setProperty('inputstream', 'inputstream.adaptive')
		LTM.setProperty('inputstream.adaptive.manifest_type', 'hls')
		LTM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
	xbmc.Player().play(item=url, listitem=LTM)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def VideoBEST(highest):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen // aktualisiert am 28.03.2023
	standards = [highest, '', '', ''] # Seite zur Überprüfung : https://github.com/mediathekview/MServer/blob/master/src/main/java/mServer/crawler/sender/zdf/ZdfVideoUrlOptimizer.java
	route_one = (('808k_p11v15', '2360k_p35v15'), ('1456k_p13v11', '2328k_p35v11'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'), ('1628k_p13v15', '2360k_p35v15'),
							('1628k_p13v17', '2360k_p35v17'), ('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
	route_two = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'), ('2360k_p35v17', '3360k_p36v17'))
	route_tree = (('3360k_p36v15', '4692k_p72v16'), ('3360k_p36v17', '6660k_p37v17'))
	standards[1] = reduce(lambda m, kv: m.replace(*kv), route_one, standards[0])
	standards[2] = reduce(lambda n, kv: n.replace(*kv), route_two, standards[1])
	standards[3] = reduce(lambda o, kv: o.replace(*kv), route_tree, standards[2])
	if standards[0] not in [standards[1], standards[2], standards[3]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, background=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot)
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if background and useThumbAsFanart and background != icon:
		liz.setArt({'fanart': background})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, tagline=None, duration=None, seriesname=None, season=None, episode=None, studio=None, begins=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	cineType = 'episode' if episode not in [0, None] else 'movie'
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		if season not in [0, None]: videoInfoTag.setSeason(int(season))
		if episode not in [0, None]: videoInfoTag.setEpisode(int(episode))
		videoInfoTag.setTvShowTitle(seriesname)
		videoInfoTag.setTitle(name)
		videoInfoTag.setTagLine(tagline)
		videoInfoTag.setPlot(plot)
		if duration not in [0, None]: videoInfoTag.setDuration(int(duration))
		if begins: videoInfoTag.setDateAdded(begins)
		if begins: videoInfoTag.setFirstAired(begins)
		videoInfoTag.setGenres(['Kinder'])
		videoInfoTag.setStudios([studio])
		videoInfoTag.setMediaType(cineType)
	else:
		info = {}
		if season not in [0, None]: info['Season'] = season
		if episode not in [0, None]: info['Episode'] = episode
		info['Tvshowtitle'] = seriesname
		info['Title'] = name
		info['Tagline'] = tagline
		info['Plot'] = plot
		if duration not in [0, None]: info['Duration'] = duration
		if begins: info['Date'] = begins
		if begins: info['Aired'] = begins
		info['Genre'] = 'Kinder'
		info['Studio'] = studio
		info['Mediatype'] = cineType
		liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, 'mode=AddToQueue'))])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
