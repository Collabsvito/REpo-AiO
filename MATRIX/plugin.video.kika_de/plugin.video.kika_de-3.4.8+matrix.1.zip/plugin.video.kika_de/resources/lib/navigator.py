﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	if newest: addDir(translation(30601), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&orderBy=appearDate&orderDirection=desc', 'extras': 'nopager'})
	if viewed: addDir(translation(30602), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&orderBy=viewCount&orderDirection=desc', 'extras': 'nopager'})
	if chance: addDir(translation(30603), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&orderBy=expirationDate&orderDirection=asc', 'extras': 'nopager'})
	if kikaninchen:
		addDir(translation(30604), f"{artpic}kikaninchen.jpg", {'mode': 'listEpisodes', 'url': '/api/brands/ebb32e6f-511f-450d-9519-5cbf50d4b546/videos', 'transmit': 'Kikaninchen'})
		addDir(translation(30605), f"{artpic}freunde.jpg", {'mode': 'listEpisodes', 'url': '/api/brands/9ed5cf37-2e09-4074-9935-f51ae06e45b1/videos', 'transmit': 'Kikaninchen und Freunde'})
	if sesamstrasse: addDir(translation(30606), f"{artpic}sesamstrasse.jpg", {'mode': 'listEpisodes', 'url': '/api/brands/3e3e70b3-62a2-40cb-856d-a46d3e210e9c/videos', 'transmit': 'Sesamstrasse'})
	if lollywood: addDir(translation(30607), f"{artpic}filme.jpg", {'mode': 'listEpisodes', 'url': '/api/brands/a4b0918c-0d21-4160-afb0-2dc789534a8e/videos', 'transmit': 'Lollywood'})
	if till03: addDir(translation(30608), icon, {'mode': 'listShows', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc&userAge=3'})
	if till06: addDir(translation(30609), icon, {'mode': 'listShows', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc&userAge=6'})
	if till10: addDir(translation(30610), icon, {'mode': 'listShows', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc&userAge=9'})
	if tillAll: addDir(translation(30611), icon, {'mode': 'listShows', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc'})
	if especials:
		addDir(translation(30612), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&videoTypes=dgsContent&orderBy=title&orderDirection=asc', 'extras': 'LongTitle'})
		addDir(translation(30613), icon, {'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&videoTypes=adContent&orderBy=title&orderDirection=asc', 'extras': 'LongTitle'})
	addDir(translation(30614), f"{artpic}livestream.png", {'mode': 'playLIVE', 'url': BASE_LIVE}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30615), f"{artpic}settings.png", {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30616), f"{artpic}settings.png", {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listShows(url, EXTRA):
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listShows) ------------------------------------------------ START = listShows -----------------------------------------------")
	content = {'_links': {'next': {'href': url}}}
	while 'next' in content['_links']:
		content = getUrl(MOBIL_API+content['_links']['next']['href'])
		for item in content['_embedded']['items']:
			TITLE = translation(30621).format(item['title'], str(item['totalVideos'])) if item.get('totalVideos', '') else item['title']
			THUMB = (item.get('mediumBrandImageUrl', '') or icon)
			DESC = item.get('description', None)
			BACK = item.get('largeTeaserImageUrl', None)
			GROUP = item.get('targetGroup', None)
			addDir(TITLE, THUMB, {'mode': 'listEpisodes', 'url': item['_links']['videos']['href']}, DESC, BACK)
			debug_MS(f"(navigator.listShows[1]) ##### GROUP : {str(GROUP)} || TITLE : {TITLE} || THUMB : {THUMB} #####")
		if EXTRA == 'nopager':
			break
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDShows+')')

def listEpisodes(url, EXTRA, TRANS):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL = {url} ### EXTRA = {EXTRA} ### SERIE = {TRANS} ###")
	COMBI_EPISODE = []
	UNIKAT = set()
	counter = 0
	content = {'_links': {'next': {'href': url}}}
	while 'next' in content['_links']:
		content = getUrl(MOBIL_API+content['_links']['next']['href'])
		for item in content['_embedded']['items']:
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listEpisodes[1]) XXXXX ITEM-01 : {str(item)} XXXXX")
			SERIE, VIEWS, startTIMES, BEGINS, endTIMES, STUDIO = (None for _ in range(6))
			DESC = ""
			TITLE = cleaning(item['title'])
			if item.get('_embedded', '') and item['_embedded'].get('brand', '') and item['_embedded']['brand'].get('title', ''):
				SERIE = cleaning(item['_embedded']['brand']['title'])
				if EXTRA in ['nopager', 'LongTitle']:
					TITLE += f" - {SERIE}"
			if item['videoType'] != 'mainContent' and not especials:
				continue
			VIDEO_CODE = item.get('id', None)
			THUMB = (item.get('largeTeaserImageUrl', '') or icon)
			VIEWS = item.get('viewCount', None)
			SEAS = item['seasonNumber'] if item.get('seasonNumber', '') else None
			EPIS = item['episodeNumber'] if item.get('episodeNumber', '') else None
			TAGLINE = translation(30622).format(str(SEAS).zfill(2), str(EPIS).zfill(2)) if SEAS and EPIS else translation(30623).format(str(EPIS).zfill(2)) if SEAS is None and EPIS else None
			if SERIE and VIEWS: DESC += translation(30624).format(str(SERIE), str(VIEWS))
			elif SERIE and VIEWS is None: DESC += translation(30625).format(str(SERIE))
			if str(item.get('appearDate'))[:4].isdigit(): # 2020-05-08T07:45:00+02:00
				try:
					broadcast = datetime(*(time.strptime(item['appearDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2022-03-28T19:50:00+02:00
					startTIMES = broadcast.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
					BEGINS = broadcast.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
					if KODI_ov20:
						BEGINS = broadcast.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
				except: pass
			if str(item.get('expirationDate'))[:4].isdigit(): # 2020-05-08T07:45:00+02:00
				try:
					available = datetime(*(time.strptime(item['expirationDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2023-03-28T19:50:00+02:00
					endTIMES = available.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				except: pass
			if startTIMES and endTIMES: DESC += translation(30626).format(str(startTIMES), str(endTIMES))
			elif startTIMES and endTIMES is None: DESC += translation(30627).format(str(startTIMES))
			if item.get('description', ''): DESC += '[CR]'+cleaning(item['description'])
			if item.get('broadcaster', ''):
				DESC += translation(30628).format(cleaning(item['broadcaster'])) if item.get('description', '') else translation(30629).format(cleaning(item['broadcaster']))
				STUDIO = cleaning(item['broadcaster'])
			DURATION = item['duration'] if str(item.get('duration')).isdigit() else None
			counter += 1
			COMBI_EPISODE.append([int(counter), VIDEO_CODE, STUDIO, TITLE, SERIE, SEAS, EPIS, THUMB, DESC, TAGLINE, DURATION, BEGINS])
		if EXTRA == 'nopager':
			break
	if COMBI_EPISODE:
		for counter, VIDEO_CODE, STUDIO, TITLE, SERIE, SEAS, EPIS, THUMB, DESC, TAGLINE, DURATION, BEGINS in COMBI_EPISODE:
			for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			if VIDEO_CODE is None or VIDEO_CODE in UNIKAT:
				continue
			UNIKAT.add(VIDEO_CODE)
			debug_MS("*****************************************")
			debug_MS(f"(navigator.listEpisodes[2]) ##### TITLE : {TITLE} || SERIE : {str(SERIE)} || THUMB : {THUMB} #####")
			debug_MS(f"(navigator.listEpisodes[2]) ##### VIDEO-ID : {str(VIDEO_CODE)} || EPISODE : {str(EPIS)} || STUDIO : {str(STUDIO)} #####")
			addLink(TITLE, THUMB, {'mode': 'playVideo', 'url': VIDEO_CODE, 'extras': 'ANDROID'}, DESC, TAGLINE, DURATION, SERIE, SEAS, EPIS, STUDIO, BEGINS)
	else:
		dialog.notification(translation(30525), translation(30526).format(TRANS), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin('Container.SetViewMode('+viewIDVideos+')')

def playVideo(videoID, EXTRA):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### videoID : {videoID} ### EXTRA : {EXTRA} ###")
	All_QUALITIES = [5, 4, 3, 2, 1, 0, 'uhd', 'fhd', 'hd', 'veryhigh', 'high', 'med', 'low', 3840, 2560, 1920, 1280, 1024, 960, 852, 720, 640, 512, 480, 320]
	M3U8, FINAL_URL, QUALITY, STREAM = (False for _ in range(4))
	MEDIAS, bestMEDIA = ([] for _ in range(2))
	if EXTRA == 'DEFAULT':
		content = getUrl(videoID, 'LOAD')
		docuID = re.compile(r'{"docType":"(?:video|externalVideo)","id":"([^"]+)","uuid"', re.S).findall(content)
		videoID = docuID[0] if docuID else None# https://www.kika.de/_next-api/proxy/v1/videos/zehn-aufgeregt-ins-halbfinale-100/assets
	if videoID not in [None, 'None']:
		DATA_ONE = getUrl(MOBIL_PLAYER.format(videoID)) if EXTRA == 'ANDROID' else getUrl(API_PLAYER.format(videoID))
		for entry in DATA_ONE.get('assets', []):
			AUTO = (entry.get('quality', '') or entry.get('type', '') or 'Unknown')
			if AUTO == 'auto' and 'm3u8' in entry.get('url'):
				M3U8 = entry['url']
		DATA_TWO = DATA_ONE.get('hbbtvAssets', []) if EXTRA == 'ANDROID' else DATA_ONE.get('assets', [])
		for item in DATA_TWO:
			DOC = 'API_DROID' if EXTRA == 'ANDROID' else 'API_WEB'
			MP4 = (item.get('url', None) or None)
			TYPE = (item.get('delivery', '') or item.get('type', '') or 'Unknown')
			QUAL = (item.get('width', None) or item.get('frameWidth', None))
			if MP4 and QUAL:
				MEDIAS.append({'url': MP4, 'delivery': TYPE, 'quality': QUAL, 'document': DOC})
	if MEDIAS:
		debug_MS(f"(navigator.playVideo[1]) ORIGINAL_MP4 ### unsorted_LIST : {str(MEDIAS)} ###")
		order_dict = {qual: index for index, qual in enumerate(All_QUALITIES)}
		bestMEDIA = sorted(MEDIAS, key=lambda x: order_dict.get(x['quality'], float('inf')))
		debug_MS(f"(navigator.playVideo[1]) SORTED_MP4 ###### sorted_LIST : {str(bestMEDIA)} ###")
	if (enableINPUTSTREAM or prefSTREAM == '0') and M3U8:
		debug_MS("(navigator.playVideo[2]) ~~~~~ TRY NUMBER ONE TO GET THE FINALURL (m3u8) ~~~~~")
		STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
		MIME, QUALITY, FINAL_URL = 'application/vnd.apple.mpegurl', 'AUTO', M3U8
	if not FINAL_URL and bestMEDIA:
		debug_MS("(navigator.playVideo[3]) ~~~~~ TRY NUMBER TWO TO GET THE FINALURL (mp4) ~~~~~")
		MP4_END = f"https:{bestMEDIA[0]['url']}" if bestMEDIA[0]['url'][:4] != 'http' else bestMEDIA[0]['url']
		STREAM, MIME, QUALITY, FINAL_URL = 'MP4', 'video/mp4', str(bestMEDIA[0]['quality'])+'p', VideoBEST(MP4_END) # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	if FINAL_URL and STREAM:
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		LSM.setMimeType(MIME)
		if ADDON_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LSM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.playVideo) [{QUALITY}] {STREAM}_stream : {FINAL_URL}")
	else:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {str(videoURL)} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *kika.de* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('STREAM'), translation(30527), icon, 8000)

def playLIVE(url):
	debug_MS("(navigator.playLIVE) ------------------------------------------------ START = playLIVE -----------------------------------------------")
	LTM = xbmcgui.ListItem(path=url, label=translation(30614))
	LTM.setMimeType('application/vnd.apple.mpegurl')
	if ADDON_operate('inputstream.adaptive'):
		LTM.setProperty('inputstream', 'inputstream.adaptive')
		if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			LTM.setProperty('inputstream.adaptive.manifest_type', 'hls')
			 # THE "full" BEHAVIOUR PARAM HAS BEEN REMOVED ON Kodi v21 because now enabled by default.
			LTM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
	xbmc.Player().play(item=url, listitem=LTM)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def VideoBEST(highest):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen // aktualisiert am 28.03.2023
	standards = [highest, '', '', ''] # Seite zur Überprüfung : https://github.com/mediathekview/MServer/blob/master/src/main/java/mServer/crawler/sender/zdf/ZdfVideoUrlOptimizer.java
	route_one = (('808k_p11v15', '2360k_p35v15'), ('1456k_p13v11', '2328k_p35v11'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'), ('1628k_p13v15', '2360k_p35v15'),
							('1628k_p13v17', '2360k_p35v17'), ('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
	route_two = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'), ('2360k_p35v17', '3360k_p36v17'))
	route_tree = (('3360k_p36v15', '4692k_p72v16'), ('3360k_p36v17', '6660k_p37v17'))
	standards[1] = reduce(lambda m, kv: m.replace(*kv), route_one, standards[0])
	standards[2] = reduce(lambda n, kv: n.replace(*kv), route_two, standards[1])
	standards[3] = reduce(lambda o, kv: o.replace(*kv), route_tree, standards[2])
	if standards[0] not in [standards[1], standards[2], standards[3]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def addDir(name, image, params={}, plot=None, background=None, folder=True):
	u = build_mass(params)
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot)
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if background and useThumbAsFanart and background != icon:
		liz.setArt({'fanart': background})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, tagline=None, duration=None, seriesname=None, season=None, episode=None, studio=None, begins=None):
	u = build_mass(params)
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	cineType = 'episode' if episode else 'movie'
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		if str(season).isdigit(): vinfo.setSeason(int(season))
		if str(episode).isdigit(): vinfo.setEpisode(int(episode))
		vinfo.setTvShowTitle(seriesname)
		vinfo.setTitle(name)
		vinfo.setTagLine(tagline)
		vinfo.setPlot(plot)
		if str(duration).isdigit(): vinfo.setDuration(int(duration))
		if begins: liz.setDateTime(begins)
		vinfo.setGenres(['Kinder'])
		vinfo.setStudios([studio])
		vinfo.setMediaType(cineType)
	else:
		vinfo = {}
		if str(season).isdigit(): vinfo['Season'] = season
		if str(episode).isdigit(): vinfo['Episode'] = episode
		vinfo['Tvshowtitle'] = seriesname
		vinfo['Title'] = name
		vinfo['Tagline'] = tagline
		vinfo['Plot'] = plot
		if str(duration).isdigit(): vinfo['Duration'] = duration
		if begins: vinfo['Date'] = begins
		vinfo['Genre'] = 'Kinder'
		vinfo['Studio'] = studio
		vinfo['Mediatype'] = cineType
		liz.setInfo(type='Video', infoLabels=vinfo)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'Action(Queue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
