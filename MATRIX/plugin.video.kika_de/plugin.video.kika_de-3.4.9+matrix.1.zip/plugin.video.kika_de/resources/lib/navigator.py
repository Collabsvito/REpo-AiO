﻿# -*- coding: utf-8 -*-

from .common import *


def mainMenu():
	if newest: addDir({'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&orderBy=appearDate&orderDirection=desc', 'extras': 'nopager'}, create_entries({'Title': translation(30601)}))
	if viewed: addDir({'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&orderBy=viewCount&orderDirection=desc', 'extras': 'nopager'}, create_entries({'Title': translation(30602)}))
	if chance: addDir({'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&orderBy=expirationDate&orderDirection=asc', 'extras': 'nopager'}, create_entries({'Title': translation(30603)}))
	if kikaninchen:
		addDir({'mode': 'listEpisodes', 'url': '/api/brands/ebb32e6f-511f-450d-9519-5cbf50d4b546/videos', 'transmit': 'Kikaninchen'}, create_entries({'Title': translation(30604), 'Image': f"{artpic}kikaninchen.jpg"}))
		addDir({'mode': 'listEpisodes', 'url': '/api/brands/3e6c8500-5a19-4005-9c1e-227cd687c1fb/videos', 'transmit': 'Kikaninchen und Freunde'}, create_entries({'Title': translation(30605), 'Image': f"{artpic}freunde.jpg"}))
	if sesamstrasse: addDir({'mode': 'listEpisodes', 'url': '/api/brands/3e3e70b3-62a2-40cb-856d-a46d3e210e9c/videos', 'transmit': 'Sesamstrasse'}, create_entries({'Title': translation(30606), 'Image': f"{artpic}sesamstrasse.jpg"}))
	if lollywood: addDir({'mode': 'listEpisodes', 'url': '/api/brands/a4b0918c-0d21-4160-afb0-2dc789534a8e/videos', 'transmit': 'Lollywood'}, create_entries({'Title': translation(30607), 'Image': f"{artpic}filme.jpg"}))
	if till03: addDir({'mode': 'listBroadcasts', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc&userAge=3'}, create_entries({'Title': translation(30608)}))
	if till06: addDir({'mode': 'listBroadcasts', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc&userAge=6'}, create_entries({'Title': translation(30609)}))
	if till10: addDir({'mode': 'listBroadcasts', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc&userAge=9'}, create_entries({'Title': translation(30610)}))
	if tillAll: addDir({'mode': 'listBroadcasts', 'url': '/api/brands?offset=0&limit=100&orderBy=title&orderDirection=asc'}, create_entries({'Title': translation(30611)}))
	if especials:
		addDir({'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&videoTypes=dgsContent&orderBy=title&orderDirection=asc', 'extras': 'LongTitle'}, create_entries({'Title': translation(30612)}))
		addDir({'mode': 'listEpisodes', 'url': '/api/videos?offset=0&limit=100&videoTypes=adContent&orderBy=title&orderDirection=asc', 'extras': 'LongTitle'}, create_entries({'Title': translation(30613)}))
	addDir({'mode': 'playLive', 'url': BASE_LIVE}, create_entries({'Title': translation(30614), 'Image': f"{artpic}livestream.png"}), folder=False)
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30615), 'Image': f"{artpic}settings.png"}), folder=False)
		if enableINPUTSTREAM and plugin_operate('inputstream.adaptive'):
			addDir({'mode': 'iConfigs'}, create_entries({'Title': translation(30616), 'Image': f"{artpic}settings.png"}), folder=False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(TARGET):
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listBroadcasts) ------------------------------------------------ START = listBroadcasts -----------------------------------------------")
	results = {'_links': {'next': {'href': TARGET}}}
	while 'next' in results['_links']:
		results = getContent(API_DROID+results['_links']['next']['href'])
		for item in results['_embedded']['items']:
			TITLE = translation(30621).format(item['title'], item['totalVideos']) if str(item.get('totalVideos')).isdecimal() else item['title']
			THUMB = (item.get('mediumBrandImageUrl', '') or icon)
			DESC = item.get('description', None)
			BACK = item.get('largeTeaserImageUrl', None)
			GROUP = item.get('targetGroup', None)
			FETCH_UNO = create_entries({'Title': TITLE, 'TvShowTitle': item['title'],'Plot': DESC, 'Image': THUMB, 'Fanback': BACK})
			addDir({'mode': 'listEpisodes', 'url': item['_links']['videos']['href'], 'transmit': item['title']}, FETCH_UNO)
			debug_MS(f"(navigator.listBroadcasts[1]) ##### GROUP : {GROUP} || TITLE : {TITLE} || THUMB : {THUMB} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin(f"Container.SetViewMode({viewIDShows})")

def listEpisodes(TARGET, EXTRA, TRANS):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL = {TARGET} ### EXTRA = {EXTRA} ### SERIE = {TRANS} ###")
	COMBI_EPISODE, counter, UNIKAT = [], 0, set()
	results = {'_links': {'next': {'href': TARGET}}}
	while 'next' in results['_links']:
		results = getContent(API_DROID+results['_links']['next']['href'])
		for item in results['_embedded']['items']:
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listEpisodes[1]) XXXXX ITEM-01 : {item} XXXXX")
			DESC, (SERIE, startTIMES, AIRED, BEGINS, endTIMES, STUDIO) = "", (None for _ in range(6))
			TITLE = cleaning(item['title'])
			if item.get('_embedded', '') and item['_embedded'].get('brand', '') and item['_embedded']['brand'].get('title', ''):
				SERIE = cleaning(item['_embedded']['brand']['title'])
				TITLE = f"{TITLE} - {SERIE}" if EXTRA in ['nopager', 'LongTitle'] else TITLE
			if item['videoType'] != 'mainContent' and not especials:
				continue
			VIDEO_CODE = item.get('id', None)
			THUMB = (item.get('largeTeaserImageUrl', '') or icon)
			VIEWS = int(item['viewCount']) if str(item.get('viewCount')).isdecimal() and int(item.get('viewCount')) != 0 else None
			if SERIE and VIEWS: DESC += translation(30622).format(SERIE, VIEWS)
			elif SERIE and VIEWS is None: DESC += translation(30623).format(SERIE)
			SEAS = f"{int(item['seasonNumber']):02}" if str(item.get('seasonNumber')).isdecimal() and int(item.get('seasonNumber')) != 0 else None
			EPIS = f"{int(item['episodeNumber']):02}" if str(item.get('episodeNumber')).isdecimal() and int(item.get('episodeNumber')) != 0 else None
			if SEAS and EPIS: DESC += translation(30624).format(SEAS, EPIS)
			elif SEAS is None and EPIS: DESC += translation(30625).format(EPIS)
			if str(item.get('appearDate'))[:4].isdecimal() and str(item.get('appearDate'))[:4] not in ['0', '0000','1970']: # 2020-05-08T07:45:00+02:00
				broadcast = datetime(*(time.strptime(item['appearDate'][:19], '%Y-%m-%dT%H:%M:%S')[0:6])) # 2022-03-28T19:50:00+02:00
				startTIMES = broadcast.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				AIRED = broadcast.strftime('%d.%m.%Y') # FirstAired
				BEGINS = broadcast.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else broadcast.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
			if str(item.get('expirationDate'))[:4].isdecimal() and str(item.get('expirationDate'))[:4] not in ['0', '0000','1970']: # 2020-05-08T07:45:00+02:00
				available = datetime(*(time.strptime(item['expirationDate'][:19], '%Y-%m-%dT%H:%M:%S')[0:6])) # 2023-03-28T19:50:00+02:00
				endTIMES = available.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			if startTIMES and endTIMES: DESC += translation(30626).format(startTIMES, endTIMES)
			elif startTIMES and endTIMES is None: DESC += translation(30627).format(startTIMES)
			if item.get('description', ''): DESC += f"[CR]{cleaning(item['description'])}"
			if item.get('broadcaster', ''):
				DESC += translation(30628).format(cleaning(item['broadcaster'])) if item.get('description', '') else translation(30629).format(cleaning(item['broadcaster']))
				STUDIO = cleaning(item['broadcaster'])
			MPAA = str(item['fsk']) if str(item.get('fsk')).isdecimal() else None
			DURATION = item['duration'] if str(item.get('duration')).isdecimal() else None
			counter += 1
			COMBI_EPISODE.append([int(counter), VIDEO_CODE, TITLE, SERIE, DESC, DURATION, SEAS, EPIS, BEGINS, AIRED, STUDIO, MPAA, THUMB])
		if EXTRA == 'nopager':
			break
	if COMBI_EPISODE:
		for counter, VIDEO_CODE, TITLE, SERIE, DESC, DURATION, SEAS, EPIS, BEGINS, AIRED, STUDIO, MPAA, THUMB in COMBI_EPISODE:
			for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			if VIDEO_CODE is None or VIDEO_CODE in UNIKAT:
				continue
			UNIKAT.add(VIDEO_CODE)
			debug_MS("*****************************************")
			debug_MS(f"(navigator.listEpisodes[2]) ##### TITLE : {TITLE} || SERIE : {SERIE} || THUMB : {THUMB} #####")
			debug_MS(f"(navigator.listEpisodes[2]) ##### VIDEO-ID : {VIDEO_CODE} || SEASON : {SEAS} || EPISODE : {EPIS} || MPAA : {MPAA} || STUDIO : {STUDIO} #####")
			FETCH_UNO = create_entries({'Title': TITLE, 'TvShowTitle': SERIE,'Plot': DESC, 'Season': SEAS, 'Episode': EPIS, 'Duration': DURATION, 'Date': BEGINS, \
				'Aired': AIRED, 'Studio': STUDIO, 'Mpaa': MPAA, 'Mediatype': 'episode' if EPIS else 'movie', 'Image': THUMB, 'Fanback': THUMB, 'Reference': 'Single'})
			addDir({'mode': 'playVideo', 'url': VIDEO_CODE, 'extras': 'ANDROID'}, FETCH_UNO, folder=False)
	else:
		dialog.notification(translation(30525), translation(30526).format(TRANS), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if forceView:
		xbmc.executebuiltin(f"Container.SetViewMode({viewIDVideos})")

def playVideo(videoID, EXTRA):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### videoID : {videoID} ### EXTRA : {EXTRA} ###")
	All_QUALITIES = [5, 4, 3, 2, 1, 0, 'uhd', 'fhd', 'hd', 'veryhigh', 'high', 'med', 'low', 3840, 2560, 1920, 1280, 1024, 960, 852, 720, 640, 512, 480, 320]
	(M3U8, FINAL_URL, QUALITY, STREAM), (MEDIAS, SELECTION) = (False for _ in range(4)), ([] for _ in range(2))
	if EXTRA == 'DEFAULT':
		results = getContent(videoID, queries='TEXT')
		docuID = re.compile(r'{"docType":"(?:video|externalVideo)","id":"([^"]+)","uuid"', re.S).findall(results)
		videoID = docuID[0] if docuID else None# https://www.kika.de/_next-api/proxy/v1/videos/zehn-aufgeregt-ins-halbfinale-100/assets
	if videoID not in [None, 'None']:
		DATA_ONE = getContent(PLAYER_DROID.format(videoID)) if EXTRA == 'ANDROID' else getContent(PLAYER_NEXT.format(videoID))
		for entry in DATA_ONE.get('assets', []):
			AUTO = (entry.get('quality', '') or entry.get('type', '') or 'Unknown')
			if AUTO == 'auto' and 'm3u8' in entry.get('url'):
				M3U8 = entry['url']
		DATA_TWO = DATA_ONE.get('hbbtvAssets', []) if EXTRA == 'ANDROID' else DATA_ONE.get('assets', [])
		for item in DATA_TWO:
			DOC = 'MOBIL_VERSION' if EXTRA == 'ANDROID' else 'WEB_VERSION'
			MP4 = (item.get('url', None) or None)
			TYPE = (item.get('delivery', '') or item.get('type', '') or 'Unknown')
			QUAL = (item.get('width', None) or item.get('frameWidth', None))
			if MP4 and QUAL:
				MEDIAS.append({'url': MP4, 'delivery': TYPE, 'quality': QUAL, 'document': DOC})
	if MEDIAS:
		debug_MS(f"(navigator.playVideo[1]) ORIGINAL_MP4 ### unsorted_LIST : {MEDIAS} ###")
		order_dict = {qual: index for index, qual in enumerate(All_QUALITIES)}
		SELECTION = sorted(MEDIAS, key=lambda x: order_dict.get(x['quality'], float('inf')))
		debug_MS(f"(navigator.playVideo[1]) SORTED_MP4 ###### sorted_LIST : {SELECTION} ###")
	if (enableINPUTSTREAM or prefSTREAM == 0) and M3U8:
		debug_MS("(navigator.playVideo[2]) ~~~~~ TRY NUMBER ONE TO GET THE FINALURL (m3u8) ~~~~~")
		STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
		MIME, QUALITY, FINAL_URL = 'application/vnd.apple.mpegurl', 'AUTO', M3U8
	if not FINAL_URL and SELECTION:
		debug_MS("(navigator.playVideo[3]) ~~~~~ TRY NUMBER TWO TO GET THE FINALURL (mp4) ~~~~~")
		FULL_MP4 = f"https:{SELECTION[0]['url']}" if SELECTION[0]['url'][:4] != 'http' else SELECTION[0]['url']
		STREAM, MIME, QUALITY, FINAL_URL = 'MP4', 'video/mp4', f"{str(SELECTION[0]['quality'])}p", VideoBEST(FULL_MP4) # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	if FINAL_URL and STREAM:
		LSM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		LSM.setMimeType(MIME), LSM.setContentLookup(False)
		if plugin_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			IA_NAME = 'inputstream.adaptive'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			LSM.setProperty('inputstream', IA_NAME)
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LSM.setProperty(f"{IA_NAME}.manifest_type", STREAM.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			if KODI_ov20:
				LSM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={get_userAgent()}") # On KODI v20 and above
			else: LSM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={get_userAgent()}") # On KODI v19 and below
			if int(IA_VERSION) >= 2150:
				LSM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey') # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.playVideo) [{QUALITY}] {STREAM}_stream : {FINAL_URL}")
	else:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {videoURL} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *kika.de* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('STREAM'), translation(30527), icon, 8000)

def playLive(url):
	debug_MS("(navigator.playLive) ------------------------------------------------ START = playLive -----------------------------------------------")
	LTM = xbmcgui.ListItem(translation(30614), path=url, offscreen=True)
	LTM.setArt({'icon': icon, 'thumb': f"{artpic}livestream.png", 'poster': f"{artpic}livestream.png"})
	LTM.setMimeType('application/vnd.apple.mpegurl')
	if plugin_operate('inputstream.adaptive'):
		IA_NAME = 'inputstream.adaptive'
		IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
		LTM.setProperty('inputstream', IA_NAME)
		if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			LTM.setProperty(f"{IA_NAME}.manifest_type", 'hls') # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
		if KODI_ov20:
			LTM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={get_userAgent()}") # On KODI v20 and above
		else: LTM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={get_userAgent()}") # On KODI v19 and below
		if int(IA_VERSION) >= 2150:
			LTM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey') # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
	xbmc.Player().play(item=url, listitem=LTM)

def VideoBEST(highest):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen // aktualisiert am 23.11.2024
	standards = [highest, '', '', ''] # Seite zur Überprüfung : https://github.com/mediathekview/MServer/blob/master/src/main/java/mServer/crawler/sender/zdf/ZdfVideoUrlOptimizer.java
	route_one = (('808k_p11v15', '2360k_p35v15'), ('1456k_p13v11', '2328k_p35v11'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'), ('1628k_p13v15', '2360k_p35v15'),
							('1628k_p13v17', '2360k_p35v17'), ('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
	route_two = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'), ('2360k_p35v17', '3360k_p36v17'))
	route_tree = (('3360k_p36v15', '4692k_p72v16'), ('3360k_p36v17', '6660k_p37v17'))
	standards[1] = reduce(lambda m, kv: m.replace(*kv), route_one, standards[0])
	standards[2] = reduce(lambda n, kv: n.replace(*kv), route_two, standards[1])
	standards[3] = reduce(lambda o, kv: o.replace(*kv), route_tree, standards[2])
	if standards[0] not in [standards[1], standards[2], standards[3]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def addDir(params, listitem, folder=True):
	uws = build_mass(params)
	listitem.setPath(uws)
	if params.get('mode') == 'playVideo':
		listitem.addContextMenuItems([(translation(30654), 'Action(Queue)')])
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
