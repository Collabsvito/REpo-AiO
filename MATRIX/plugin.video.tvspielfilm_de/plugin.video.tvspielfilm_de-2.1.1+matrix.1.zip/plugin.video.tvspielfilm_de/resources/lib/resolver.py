﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
from urllib.parse import urlencode, quote_plus
from urllib.request import urlopen
from functools import reduce

from .common import *


def ArdGetVideo(videoURL):
	debug_MS("(resolver.ArdGetVideo) ------------------------------------------------ START = ArdGetVideo -----------------------------------------------")
	MEDIAS = []
	player_PAGE, STREAM, finalURL = (False for _ in range(3))
	All_QUALITIES = ['auto', 5, 4, 3, 2, 1, 0]
	docuID = re.compile('ardmediathek.de/video/([A-Za-z0-9_]+)', re.S).findall(videoURL)# https://www.ardmediathek.de/video/Y3JpZDovL2Rhc2Vyc3RlLmRlL3RhdG9ydC9kYzYwZGU0Zi0zYzRlLTRiNjQtOTgxYi02ZWIwYjYzY2MyOTA
	if docuID:# https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL2Rhc2Vyc3RlLmRlL3RhdG9ydC9kYzYwZGU0Zi0zYzRlLTRiNjQtOTgxYi02ZWIwYjYzY2MyOTA?devicetype=pc&embedded=false
		player_PAGE = '{0}ard/item/{1}?devicetype=pc&embedded=false'.format(API_ARD, docuID[0])
	else:
		req_FIRST = getUrl(videoURL, method='LOAD')
		docuLINK = re.compile(r'<script id="fetchedContextValue" type="application/json">.+?"href":"(https?://.*?/item/.*?)".+?</script>', re.S).findall(req_FIRST)
		player_PAGE = docuLINK[0] if docuLINK else False
	debug_MS("(resolver.ArdGetVideo) ##### videoPAGE : {0} #####".format(str(player_PAGE)))
	if player_PAGE:
		content = getUrl(player_PAGE, method='TRACK')
		if content.status_code == 200:
			DATA = content.json()
			debug_MS("++++++++++++++++++++++++")
			debug_MS("(resolver.ArdGetVideo) XXXXX CONTENT : {0} XXXXX".format(str(DATA)))
			debug_MS("++++++++++++++++++++++++")
			if DATA is not None and DATA.get('widgets', '') and len(DATA['widgets']) > 0:
				for elem in DATA.get('widgets', []):
					if elem.get('type', '') == 'player_ondemand' and elem.get('mediaCollection', ''):
						SHORT = elem['mediaCollection']['embedded']['_mediaArray'][1] if len(elem['mediaCollection']['embedded']['_mediaArray']) > 1 else elem['mediaCollection']['embedded']['_mediaArray'][0]
						for found in All_QUALITIES:
							for quality in SHORT.get('_mediaStreamArray', []):
								if quality['_quality'] == found and '_stream' in quality and quality['_stream']:
									if (enableINPUTSTREAM or prefSTREAM == '0') and quality['_quality'] == 'auto' and 'm3u8' in quality['_stream']:
										STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
										finalURL = 'https:'+quality['_stream'] if quality['_stream'][:4] != 'http' else quality['_stream']
										log("(resolver.ArdGetVideo) Auswahl vom *m3u8-Stream* (ARD+3) : {0}".format(finalURL))
									if quality['_quality'] != 'auto' and '.mp4' in quality['_stream']:
										MEDIAS.append({'url': quality['_stream'], 'quality': quality['_quality'], 'mimeType': 'mp4', 'height': (quality.get('_height', 'Unknown') or 'Unknown')})
					elif elem.get('blockedByFsk', '') is True:
						log("(resolver.ArdGetVideo) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Alterbeschränkungen geblockt !!!")
						return dialog.notification(translation(30528), translation(30529), icon, 8000)
					elif elem.get('geoblocked', '') is True:
						log("(resolver.ArdGetVideo) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Geo-Sperren geblockt !!!")
						return dialog.notification(translation(30528), translation(30530), icon, 8000)
	if not finalURL and MEDIAS:
		ARD_Url = 'https:'+MEDIAS[0]['url'] if MEDIAS[0]['url'][:4] != 'http' else MEDIAS[0]['url']
		debug_MS("(resolver.ArdGetVideo) SORTED_LIST | MP4 ### MEDIAS : {0} ###".format(str(MEDIAS)))
		log("(resolver.ArdGetVideo) Auswahl vom *mp4-Stream* (ARD+3) : {0}".format(ARD_Url))
		STREAM, finalURL = 'MP4', VideoBEST(ARD_Url, improve='DasErste') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	return playRESOLVED(finalURL, STREAM, 'ARD+3', 'ARD - Intern')

def RtlGetVideo(videoURL):
	debug_MS("(resolver.RtlGetVideo) ------------------------------------------------ START = RtlGetVideo -----------------------------------------------")
	finalURL = False # https://bff.apigw.tvnow.de/player/%d" % int(streamID)
	req_FIRST = getUrl(videoURL, method='LOAD').replace('&q;', '"')
	docuID = re.compile(',"moduleUrl":"/player/([0-9_]+)","type":"player"', re.S).findall(req_FIRST) # https://bff.apigw.tvnow.de/player/5230201 // ,"moduleUrl":"/player/5230201","type":"player"
	target_RTL = docuID[0] if docuID else None
	premium = re.compile(',"statusCode":[0-9]+,"isPremium":([^,]+),"loggedIn"', re.S).findall(req_FIRST) # ,"statusCode":3,"isPremium":false,"loggedIn"
	PayType = premium[0] if premium else 'true'
	if target_RTL:
		log("(resolver.RtlGetVideo) --- RTL-Daten : ### Request = https://bff.apigw.tvnow.de/player/{0} ### Episode = {0} ### Premium = {1} ### ---".format(target_RTL, str(PayType)))
		finalURL = '{0}?{1}'.format('plugin://plugin.video.rtlgroup.de/', urlencode({'mode': 'playDash', 'xcode': target_RTL}))
	return playRESOLVED(finalURL, 'TRANSMIT', 'RTLPLUS - V.3', 'RTLPLUS - V.3 - Plugin')

def ToggoGetVideo(videoURL):
	debug_MS("(resolver.ToggoGetVideo) ------------------------------------------------ START = ToggoGetVideo -----------------------------------------------")
	POLICY, brightcoveID, STREAM, finalURL, WAKEY = (False for _ in range(5)) # !!! TOGGO.de - AccountID = 6057955896001 !!!
	MIME = 'application/vnd.apple.mpegurl'
	def extractPolKey():
		DATA_ONE = getUrl('https://players.brightcove.net/6057955896001/default_default/config.json') # https://players.brightcove.net/6057955896001/default_default/config.json
		if DATA_ONE is not None and DATA_ONE.get('video_cloud', '') and DATA_ONE.get('video_cloud', {}).get('policy_key', ''):
			POLICY = DATA_ONE['video_cloud']['policy_key']
		else:
			DATA_TWO = getUrl('https://players.brightcove.net/6057955896001/default_default/index.min.js', method='LOAD') # https://players.brightcove.net/6057955896001/default_default/index.min.js
			PLK = re.compile(r'accountId:"6057955896001",policyKey:"([^"]+)"}?', re.S).findall(DATA_TWO)
			POLICY = PLK[0] if PLK else None
		return POLICY
	DATA_ASSET = getUrl('https://production-n.toggo.de/api/assetstore/vod/asset/'+videoURL.split('/')[-1])
	if DATA_ASSET is not None:
		brightcoveID = next(x.get('value') for x in DATA_ASSET['data'].get('custom_fields', []) if x.get('key') == 'video-cloud-id')
	personalID = extractPolKey()
	if brightcoveID and personalID: # https://edge.api.brightcove.com/playback/v1/accounts/6057955896001/videos/6301101396001?config_id=6653bcfa-b258-4bc9-8f30-4b702ead02d8
		req_FOUR = 'https://edge.api.brightcove.com/playback/v1/accounts/6057955896001/videos/'+str(brightcoveID)
		DATA_VIDEO = getUrl(req_FOUR, REF='https://www.toggo.de/', WAY='bcov-policy', AUTH=personalID)
		debug_MS("(resolver.ToggoGetVideo) ##### DATA_BRIGHTCOVE : {0} #####".format(str(DATA_VIDEO)))
		if DATA_VIDEO is not None and DATA_VIDEO.get('sources', '') and len(DATA_VIDEO['sources']) > 0:
			for elem in DATA_VIDEO.get('sources', []):
				if elem.get('key_systems', '') and elem.get('key_systems', {}).get('com.widevine.alpha', '') and elem.get('key_systems', []).get('com.widevine.alpha', {}).get('license_url', ''):
					if elem.get('type') == 'application/dash+xml' and elem.get('src', ''):
						STREAM, MIME, finalURL = 'MPD', 'application/dash+xml', elem['src']
						debug_MS("(resolver.ToggoGetVideo) TAKE - Inputstream (mpd) - FILE (Toggo.de) : {0}".format(finalURL))
						WALU = elem['key_systems']['com.widevine.alpha']['license_url']
						WAKEY = u'{0}|User-Agent={1}&Content-Type=application/octet-stream|{2}|'.format(WALU, get_userAgent(), 'R{SSM}') if WALU else None
						break
				if not finalURL and elem.get('type') == 'application/x-mpegURL' and not '/fairplay/' in elem.get('src', '') and not WAKEY:
					STREAM, MIME, finalURL = 'HLS', 'application/vnd.apple.mpegurl', elem['src']
					debug_MS("(resolver.ToggoGetVideo) TAKE - Inputstream (hls) - FILE (Toggo.de) : {0}".format(finalURL))
					break
	return playRESOLVED(finalURL, STREAM, 'TOGGO', 'TOGGO - Intern', MIME, WAKEY)

def WeltGetVideo(videoURL):
	debug_MS("(resolver.WeltGetVideo) ------------------------------------------------ START = WeltGetVideo -----------------------------------------------")
	M3U8_Url, MP4_Url, STREAM, finalURL = (False for _ in range(4))
	req_FIRST = getUrl(videoURL, method='LOAD', REF=videoURL)
	docuLINK = re.compile(r'(?s)<script type="application/json" data-content="VideoPlayer.Config" data-qa="VideoPlayer.Config">\s+(?P<json>{.+?})\s+</script>', re.S).findall(req_FIRST)
	target_WELT = docuLINK[0] if docuLINK else False
	debug_MS("(resolver.WeltGetVideo) ##### DATA_WELT : {0} #####".format(str(target_WELT)))
	if target_WELT:
		DATA = json.loads(target_WELT)
		if DATA.get('sources', '') and len(DATA['sources']) > 0:
			for elem in DATA.get('sources', []):
				if (enableINPUTSTREAM or prefSTREAM == '0') and elem.get('extension') == 'm3u8' and elem.get('src', ''):
					STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
					finalURL = 'https://www.welt.de/onward/video/play/'+quote_plus(elem['src'])
					debug_MS("(resolver.WeltGetVideo) TAKE - (m3u8) - FILE (Welt.de) : {0}".format(finalURL))
					break
				if not finalURL and elem.get('extension') == 'mp4' and elem.get('src', ''):
					STREAM, finalURL = 'MP4', 'https://www.welt.de/onward/video/play/'+quote_plus(elem['src'])
					debug_MS("(resolver.WeltGetVideo) TAKE - (mp4) - FILE (Welt.de) : {0}".format(finalURL))
					break
	return playRESOLVED(finalURL, STREAM, 'WELT', 'WELT - Intern')

def ZdfGetVideo(videoURL):
	debug_MS("(resolver.ZdfGetVideo) ------------------------------------------------ START = ZdfGetVideo -----------------------------------------------")
	episID, DATA_ONE, teaser, videoFOUND = (False for _ in range(4))
	if videoURL.startswith('https://www.phoenix.de'):
		docuID = re.compile('-a-([0-9]+).', re.S).findall(videoURL)# https://www.phoenix.de/sendungen/dokumentationen/amerikas-legendaere-strassen-55-a-793934.html
		target_PHOE = 'https://www.phoenix.de/response/id/{0}/refid/suche'.format(docuID[0]) if docuID else False# https://www.phoenix.de/response/id/793934/refid/suche
		debug_MS("(resolver.ZdfGetVideo) ##### target_PHOE : {0} #####".format(str(target_PHOE)))
		if target_PHOE:
			firstURL = getUrl(target_PHOE)
			for elem in firstURL.get('absaetze', []):
				if str(elem.get('content'))[:4].isdigit():
					episID = str(elem.get('content'))# https://www.phoenix.de/php/mediaplayer/data/beitrags_details.php?id=2403864&profile=player2
					debug_MS("(resolver.ZdfGetVideo) ##### TEASER : https://www.phoenix.de/php/mediaplayer/data/beitrags_details.php?id={0}&profile=player2 #####".format(episID))
					break
			if episID: DATA_ONE = getUrl('https://www.phoenix.de/php/mediaplayer/data/beitrags_details.php?id={0}&profile=player2'.format(episID))
	else:
		req_FIRST = getUrl(videoURL, method='LOAD')
		docuLINK = re.compile(r'(?s)data-zdfplayer-jsb=["\'](?P<json>{.+?})["\']', re.S).findall(req_FIRST)
		target_ZDF = docuLINK[0] if docuLINK else False
		debug_MS("(resolver.ZdfGetVideo) ##### targetLINKS : {0} #####".format(str(target_ZDF)))
		if target_ZDF:
			firstURL = json.loads(target_ZDF)
			teaser = firstURL['content']
			secret = firstURL['apiToken']
			log("(resolver.ZdfGetVideo) SECRET gefunden (ZDF+3) : ***** {0} *****".format(str(secret)))
			teaser = API_ZDF+teaser if teaser[:4] != 'http' else teaser
			debug_MS("(resolver.ZdfGetVideo) ##### TEASER : {0} #####".format(teaser))
			DATA_ONE = getUrl(teaser, WAY='Api-Auth', AUTH='Bearer '+secret)
	if DATA_ONE and (DATA_ONE.get('profile') == 'http://zdf.de/rels/not-found' or not ('contentType' in DATA_ONE)):
		videoFOUND = False
	else:
		if DATA_ONE and DATA_ONE.get('contentType') in ['clip', 'episode']:
			START_URL = 'https://api.3sat.de' if teaser and teaser.startswith('https://api.3sat.de') else 'https://api.zdf.de' if teaser and teaser.startswith('https://api.zdf.de') else ""
			videoFOUND = START_URL+DATA_ONE['mainVideoContent']['http://zdf.de/rels/target']['http://zdf.de/rels/streams/ptmd-template'].replace('{playerId}', 'ngplayer_2_4').replace('\/', '/')
			debug_MS("(resolver.ZdfGetVideo) ##### videoFOUND : {0} #####".format(videoFOUND))
			step_THIRD = ZdfExtractQuality(videoFOUND, 'Api-Auth', 'Bearer '+secret) if START_URL != "" else ZdfExtractQuality(videoFOUND, None, None)
			return step_THIRD
	if not target_ZDF or not videoFOUND:
		failing("(resolver.ZdfGetVideo) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
		log("(resolver.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")
		dialog.notification(translation(30521).format('ZDF - Intern'), translation(30527), icon, 8000)

def ZdfExtractQuality(req_THIRD, PREFIX, TOKEN):
	debug_MS("(resolver.ZdfExtractQuality) ------------------------------------------------ START = ZdfExtractQuality -----------------------------------------------")
	DATA_TWO = getUrl(req_THIRD) if TOKEN is None else getUrl(req_THIRD, WAY=PREFIX, AUTH=TOKEN)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(resolver.ZdfExtractQuality) XXXXX CONTENT : {0} XXXXX".format(str(DATA_TWO)))
	debug_MS("++++++++++++++++++++++++")
	MEDIAS = []
	STREAM, finalURL = (False for _ in range(2))
	m3u8_QUALITIES = ['auto', 'veryhigh', 'high', 'med']
	mp4_QUALITIES = ['fhd', 'hd', 'veryhigh', 'high', 'low']
	if DATA_TWO is not None:
		for each in DATA_TWO.get('priorityList', []):
			formitaeten = each.get('formitaeten')
			if not isinstance(formitaeten, list):
				continue
			for item in formitaeten:
				if (enableINPUTSTREAM or prefSTREAM == '0') and item.get('type') == 'h264_aac_ts_http_m3u8_http' and item.get('mimeType').lower() == 'application/x-mpegurl':
					for found in m3u8_QUALITIES:
						for quality in item.get('qualities', []):
							if quality['quality'] == found and 'mil/master.m3u8' in quality['audio']['tracks'][0]['uri']:
								MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': item.get('mimeType').lower(), 'language': quality['audio']['tracks'][0]['language']})
					debug_MS("(resolver.ZdfExtractQuality) SORTED_LIST | M3U8 ### MEDIAS : {0} ###".format(str(MEDIAS)))
					log("(resolver.ZdfExtractQuality) Auswahl vom *m3u8-Stream* (ZDF+3) : {0}".format(MEDIAS[0]['url']))
					STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
					finalURL = MEDIAS[0]['url']
				if not finalURL and item.get('type') == 'h264_aac_mp4_http_na_na' and 'progressive' in item.get('facets', []) and item.get('mimeType').lower() == 'video/mp4':
					for found in mp4_QUALITIES:
						for quality in item.get('qualities', []):
							if quality['quality'] == found:
								MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': item.get('mimeType').lower(), 'language': quality['audio']['tracks'][0]['language']})
					debug_MS("(resolver.ZdfExtractQuality) SORTED_LIST | MP4 ### MEDIAS : {0} ###".format(str(MEDIAS)))
					log("(resolver.ZdfExtractQuality) Auswahl vom *mp4-Stream* (ZDF+3) : {0}".format(MEDIAS[0]['url']))
					STREAM, finalURL = 'MP4', VideoBEST(MEDIAS[0]['url'], improve='DasZweite') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	return playRESOLVED(finalURL, STREAM, 'ZDF+3', 'ZDF - Intern')

def VideoBEST(highest, improve=False):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen // aktualisiert am 28.03.2023
	standards = [highest, '', '', ''] # Seite zur Überprüfung : https://github.com/mediathekview/MServer/blob/master/src/main/java/mServer/crawler/sender/zdf/ZdfVideoUrlOptimizer.java
	if improve == 'DasErste':
		route_one = (('/960', '/1280'), ('.hq.mp4', '.hd.mp4'), ('.l.mp4', '.xl.mp4'), ('_C.mp4', '_X.mp4'))
		route_two = (('/1280', '/1920'), ('.xl.mp4', '.xxl.mp4'))
		route_tree = (('/1920', '/3840'), ('.xl.mp4', '.xxl.mp4'))
	elif improve == 'DasZweite':
		route_one = (('808k_p11v15', '2360k_p35v15'), ('1456k_p13v11', '2328k_p35v11'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'), ('1628k_p13v15', '2360k_p35v15'),
								('1628k_p13v17', '2360k_p35v17'), ('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
		route_two = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'), ('2360k_p35v17', '3360k_p36v17'))
		route_tree = (('3360k_p36v15', '4692k_p72v16'), ('3360k_p36v17', '6660k_p37v17'))
	standards[1] = reduce(lambda m, kv: m.replace(*kv), route_one, standards[0])
	standards[2] = reduce(lambda n, kv: n.replace(*kv), route_two, standards[1])
	standards[3] = reduce(lambda o, kv: o.replace(*kv), route_tree, standards[2])
	if standards[0] not in [standards[1], standards[2], standards[3]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def playRESOLVED(finalURL, STREAM, MARKING, NOTE, MIME='application/vnd.apple.mpegurl', LICE=None):
	if finalURL and STREAM:
		LSM = xbmcgui.ListItem(path=finalURL)
		if ADDON_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			LSM.setMimeType(MIME)
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			LSM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
			if LICE:
				LSM.setProperty('inputstream.adaptive.license_key', LICE)
				debug_MS("(resolver.playRESOLVED) LICENSE : {0}".format(str(LICE)))
				LSM.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log("(resolver.playRESOLVED) END-AbspielLink ({0}) : {1}_stream : {2}".format(MARKING, STREAM, finalURL))
	else:
		failing("(resolver.playRESOLVED) AbspielLink-00 ({0}) : *{1}* Der angeforderte -VideoLink- existiert NICHT !!!".format(MARKING, NOTE))
		dialog.notification(translation(30521).format(NOTE), translation(30527), icon, 8000)
	log("(resolver.playRESOLVED) --- ENDE WIEDERGABE ANFORDERUNG ---")
