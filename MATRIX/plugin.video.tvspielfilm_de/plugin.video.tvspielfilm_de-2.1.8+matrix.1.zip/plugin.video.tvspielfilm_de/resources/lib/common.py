﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import time
from datetime import datetime, timedelta
import requests
from urllib.parse import parse_qsl, urlparse, urlencode, quote_plus, unquote_plus
from urllib.request import urlopen
from functools import reduce
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


socket.setdefaulttimeout(30)
HOST_AND_PATH                  = sys.argv[0]
ADDON_HANDLE                   = int(sys.argv[1])
dialog                                      = xbmcgui.Dialog()
addon                                     = xbmcaddon.Addon()
addon_id                                = addon.getAddonInfo('id')
addon_name                         = addon.getAddonInfo('name')
addon_version                      = addon.getAddonInfo('version')
addonPath                             = xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                                = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
defaultFanart                         = os.path.join(addonPath, 'resources', 'media', 'fanart.jpg')
icon                                         = os.path.join(addonPath, 'resources', 'media', 'icon.png')
artpic                                      = os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
enableINPUTSTREAM           = addon.getSetting('useInputstream') == 'true'
prefSTREAM                           = addon.getSetting('prefer_stream')
showDATE                              = addon.getSetting('show_dates') == 'true'
showCHANNEL                      = addon.getSetting('show_channel') == 'true'
showARTE                              = (True if addon.getSetting('show_ARTE') == 'true' else False)
showJOYN                             = (True if addon.getSetting('show_JOYN') == 'true' else False)
showSERVUS                         = (True if addon.getSetting('show_SERVUS') == 'true' else False)
showTELE                               = (True if addon.getSetting('show_TELE5') == 'true' else False)
showNOW                              = (True if addon.getSetting('show_TVNOW') == 'true' else False)
useThumbAsFanart               = addon.getSetting('useThumbAsFanart') == 'true'
enableADJUSTMENT             = addon.getSetting('show_settings') == 'true'
DEB_LEVEL                             = (xbmc.LOGINFO if addon.getSetting('enableDebug') == 'true' else xbmc.LOGDEBUG)
TVS_staticCODE                     = addon.getSetting('new_staticCODE')
ARTEEX                                   = ['ARTE']
JOYNEX                                  = ['DMAX', 'KABEL 1', 'PROSIEBEN', 'PROSIEBEN MAXX', 'SAT.1', 'SAT.1 GOLD', 'SIXX']
SERVUSEX                              = ['SERVUSTV DEUTSCHLAND']
TELEEX                                    = ['TELE 5']
NOWEX                                   = ['NITRO', 'RTL', 'RTL 2', 'RTLUP', 'VOX', 'SRTL', 'TOGGO PLUS']
KODI_ov20                            = int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
KODI_un21                            = int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) <= 20
BASE_URL                              = 'https://www.tvspielfilm.de'
BASE_JOYN                            = 'https://www.joyn.de/'
API_ARD                                = 'https://api.ardmediathek.de/page-gateway/pages/'
API_ZDF                                 = 'https://api.zdf.de'
API_JOYN                               = 'https://www.joyn.de/_next/data/' # bSD_wV8RvFrdlX8nHD5vh # CODE of the Webpage

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log('[{} v.{}]{}'.format(addon_id, addon_version, str(msg)), level)

def get_userAgent(REV='109.0', VER='112.0'):
	base = 'Mozilla/5.0 {} Gecko/20100101 Firefox/'+VER
	if xbmc.getCondVisibility('System.Platform.Android'):
		if 'arm' in os.uname()[4]: return base.format('(X11; Linux arm64; rv:'+REV+')') # ARM based Linux
		return base.format('(X11; Linux x86_64; rv:'+REV+')') # x64 Linux
	elif xbmc.getCondVisibility('System.Platform.Windows'):
		return base.format('(Windows NT 10.0; Win64; x64; rv:'+REV+')') # Windows
	elif xbmc.getCondVisibility('System.Platform.IOS'):
		return 'Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0 Mobile/15E148 Safari/604.1' # iOS iPhone/iPad
	elif xbmc.getCondVisibility('System.Platform.Darwin') or xbmc.getCondVisibility('System.Platform.OSX'):
		return base.format('(Macintosh; Intel Mac OS X 10.15; rv:'+REV+')') # Mac OSX
	return base.format('(X11; Linux x86_64; rv:'+REV+')') # x64 Linux

def _header(REFERRER=None, CODE=None, USERTOKEN=None):
	header = {}
	header['Pragma'] = 'no-cache'
	header['Accept'] = '*/*'
	header['User-Agent'] = get_userAgent()
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	header['Accept-Language'] = 'en-US,en;q=0.8,de;q=0.7'
	if REFERRER:
		header['Referer'] = REFERRER
	if CODE and USERTOKEN:
		header[CODE] = USERTOKEN
	return header

def getMultiData(MURLS, method='GET', REF=None, WAY=None, AUTH=None, fields=None):
	COMBI_NEW = []
	number = len(MURLS)
	counter = 0
	def download(pos, url, cmanager):
		response = cmanager.request(method, url, fields, headers=_header(REF, WAY, AUTH), timeout=5, retries=2)
		if response and response.status == 200:
			debug_MS(f"(common.getMultiData) === URL that wanted : {url} ===")
			return [pos, url, py3_dec(response.data)]
		else:
			failing(f"(common.getMultiData) ERROR - ERROR - ERROR ##### pos : {str(pos)} === status : {str(response.status)} === url : {url} #####")
			return [pos, url, None]
	with ThreadPoolExecutor() as executor:
		conn_mgr = urllib3.PoolManager(maxsize=10, block=True)
		future_connect = [executor.submit(download, pos, url, conn_mgr) for pos, url in MURLS]
		wait(future_connect, timeout=30, return_when=ALL_COMPLETED)
		for ii, future in enumerate(as_completed(future_connect), 1):
			try:
				COMBI_NEW.append(future.result())
				if ii == number:
					for item in COMBI_NEW:
						if item[2] is None: counter += 1
					if counter == number:
						dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 10000)
			except Exception as e:
				failing(f"(common.getMultiData) ERROR - ERROR - ERROR ##### no : {str(ii)} === url : {url} === error : {str(e)} #####")
				dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(str(e)), icon, 10000)
				executor.shutdown()
		return COMBI_NEW

def getUrl(url, method='GET', REF=None, WAY=None, AUTH=None, headers=None, cookies=None, allow_redirects=True, verify=True, stream=None, data=None, json=None):
	simple = requests.Session()
	ANSWER, NEW_CODING = (None for _ in range(2))
	simple.keep_alive = False
	retries = 0
	if url[:4] == 'http':
		try:
			response = simple.get(url, headers=_header(REF, WAY, AUTH), allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=30)
			ANSWER = response.json() if method in ['GET', 'POST'] else response.text if method == 'LOAD' else response
			debug_MS(f"(common.getUrl) === CALLBACK === status : {str(response.status_code)} || url : {response.url} || header : {_header(REF, WAY, AUTH)} ===")
		except requests.exceptions.RequestException as e:
			failing(f"(common.getUrl) ERROR - ERROR - ERROR ##### url : {url} === error : {str(e)} #####")
			dialog.notification(translation(30521).format('URL'), translation(30523).format(str(e)), icon, 10000)
			return sys.exit(0)
	else:
		def getCollected(suffix_URL, token_TRANSFER=None):
			debug_MS(f"(common.getCollected) === suffix_URL : {suffix_URL} || token_TRANSFER : {str(token_TRANSFER)} ===")
			recentURL = API_JOYN+token_TRANSFER+suffix_URL if token_TRANSFER else API_JOYN+TVS_staticCODE+suffix_URL
			return recentURL
		while not ANSWER and retries < 3: # 2 x Wiederholungen (gesamt=3) für den URL-Request ::: da der Code für die API_BASE evtl. wieder geändert wurde
			retries += 1
			try:
				endURL = getCollected(url, NEW_CODING)
				response = simple.get(endURL, headers=_header(REF, WAY, AUTH), allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=30)
				ANSWER = response.json() if method in ['GET', 'POST'] else response.text
				debug_MS(f"(common.getUrl) === CALLBACK === retries_no : {str(retries)} === status : {str(response.status_code)} || url : {response.url} || header : {_header(REF, WAY, AUTH)} ===")
			except Exception as e: # No JSON object could be decoded
				failing(f"(common.getUrl) ERROR - CURRENT_TOKEN - ERROR ##### retries_no : {str(retries)} === status : {str(response.status_code)} === url : {response.url} === error : {str(e)} #####")
				CONTENT = simple.get(BASE_JOYN, headers=_header(REF, WAY, AUTH), allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=10)
				SCAN_REQ = re.compile('</script><script src="/_next/static/([^/]+?)/_ssgManifest.js" defer=', re.S).findall(CONTENT.text)
				#SCAN_REQ = re.compile('"query":{},"buildId":"([^"]+?)","isFallback"', re.S).findall(CONTENT.text)
				if SCAN_REQ:
					NEW_CODING = SCAN_REQ[0]
					addon.setSetting('new_staticCODE', NEW_CODING)
				elif retries > 1 and not SCAN_REQ:
					retries += 2
					dialog.notification(translation(30521).format('URL'), translation(30524), icon, 10000)
					break
				time.sleep(2)
	return ANSWER

def ADDON_operate(IDD):
	check_1 = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.GetAddonDetails", "params":{{"addonid":"{IDD}", "properties":["enabled"]}}}}')
	check_2 = 'undone'
	if '"enabled":false' in check_1:
		try:
			xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.SetAddonEnabled", "params":{{"addonid":"{IDD}", "enabled":true}}}}')
			failing(f"(common.ADDON_operate) ERROR - ERROR - ERROR :\n##### Das benötigte Addon : *{IDD}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####")
		except: pass
		check_2 = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.GetAddonDetails", "params":{{"addonid":"{IDD}", "properties":["enabled"]}}}}')
	if '"error":' in check_1 or '"error":' in check_2:
		dialog.ok(addon_id, translation(30501).format(IDD))
		failing(f"(common.ADDON_operate) ERROR - ERROR - ERROR :\n##### Das benötigte Addon : *{IDD}* ist NICHT installiert !!! #####")
		return False
	if '"enabled":true' in check_1 or '"enabled":true' in check_2:
		return True
	if '"enabled":false' in check_2:
		dialog.ok(addon_id, translation(30502).format(IDD))
		failing(f"(common.ADDON_operate) ERROR - ERROR - ERROR :\n##### Das benötigte Addon : *{IDD}* ist NICHT aktiviert !!! #####\n##### Eine automatische Aktivierung ist leider NICHT möglich !!! #####")
	return False

def cleaning(text):
	if text is not None:
		for n in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\xc2\xb7', '-'),
					("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''),
					('&#xC4;', 'Ä'), ('&#xE4;', 'ä'), ('&#xD6;', 'Ö'), ('&#xF6;', 'ö'), ('&#xDC;', 'Ü'), ('&#xFC;', 'ü'), ('&#xDF;', 'ß'), ('&#x201E;', '„'), ('&#xB4;', '´'), ('&#x2013;', '-'), ('&#xA0;', ' '),
					('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
					('&agrave;', 'à'), ('&Agrave;', 'À'), ('&aacute;', 'á'), ('&Aacute;', 'Á'), ('&acirc;', 'â'), ('&Acirc;', 'Â'), ('&egrave;', 'è'), ('&Egrave;', 'È'), ('&eacute;', 'é'), ('&Eacute;', 'É'), ('&ecirc;', 'ê'), ('&Ecirc;', 'Ê'),
					('&igrave;', 'ì'), ('&Igrave;', 'Ì'), ('&iacute;', 'í'), ('&Iacute;', 'Í'), ('&icirc;', 'î'), ('&Icirc;', 'Î'), ('&ograve;', 'ò'), ('&Ograve;', 'Ò'), ('&oacute;', 'ó'), ('&Oacute;', 'Ó'), ('&ocirc;', 'ô'), ('&Ocirc;', 'Ô'),
					('&ugrave;', 'ù'), ('&Ugrave;', 'Ù'), ('&uacute;', 'ú'), ('&Uacute;', 'Ú'), ('&ucirc;', 'û'), ('&Ucirc;', 'Û'), ('&yacute;', 'ý'), ('&Yacute;', 'Ý'),
					('&atilde;', 'ã'), ('&Atilde;', 'Ã'), ('&ntilde;', 'ñ'), ('&Ntilde;', 'Ñ'), ('&otilde;', 'õ'), ('&Otilde;', 'Õ'), ('&Scaron;', 'Š'), ('&scaron;', 'š'), ('&ccedil;', 'ç'), ('&Ccedil;', 'Ç'),
					("\\'", "'"), ('&shy;', ''), ('<br/> ', '[CR]'), ('<br/>', '[CR]'), ('Ã¶', 'ö')):
					text = text.replace(*n)
		text = text.strip()
	return text

def cleanStation(channelID):
	# ARD, ZDF, RTL, SAT1, PRO7, K1, RTL2, VOX, TELE5, 3SAT, ARTE, 2NEO, FES, SERVU, RTL-N, DMAX, SIXX, SAT1G, PRO7M, RTLPL, WDR, N3, BR, SWR, HR, MDR, RBB, ALPHA, ZINFO, SUPER, KIKA
	channelID = channelID.replace(' Programm', '').replace(' programm', '').replace(' Mediathek', '')
	ChannelCode = ('ARD','Das Erste','ONE','FES','ZDF','2NEO','ZNEO','2INFO','ZINFO','3SAT','ALPHA','Arte','ARTE','BR','DMAX','HR','kabel eins','K1','KIKA','KiKA','MDR','NDR','N3','ORF','PHOEN',\
								'PRO7','PRO7M','RBB','SAT1','SAT1G','SAT.1G','SERVU','SIXX','SR','SWR','SWR/SR','WDR','RTL','RTL2','RTL II','RTLPL','RTL-N','SRTL','SUPER RTL','SUPER','TOGGO','TELE5','WELT','VOX')
	if channelID in ChannelCode and channelID != "":
		for n in ((' ', ''), ('ARD', 'Das Erste'), ('DasErste', 'Das Erste'), ('FES', 'ONE'), ('Arte', 'ARTE'), ('K1', 'Kabel 1'), ('kabeleins', 'Kabel 1'), ('KIKA', 'KiKA'), ('2INFO', 'ZDFinfo'), ('ZINFO', 'ZDFinfo'),\
					('2NEO', 'ZDFneo'), ('ZNEO', 'ZDFneo'), ('3SAT', '3sat'), ('N3', 'NDR'), ('PHOEN', 'PHOENIX'), ('PRO7M', 'ProSieben MAXX'), ('PRO7', 'ProSieben'), ('RTLII', 'RTL 2'), ('RTL-N', 'NITRO'), ('RTLPL', 'RTLup'),\
					('SAT.1G', 'SAT.1 Gold'), ('SAT1G', 'SAT.1 Gold'), ('SAT1', 'SAT.1'), ('SERVU', 'ServusTV Deutschland'), ('SUPERRTL', 'SRTL'), ('SUPER', 'SRTL'), ('TELE5', 'TELE 5'), ('TOGGO', 'TOGGO plus')):
					channelID = channelID.replace(*n)
	if channelID in ['ARD-alpha', 'ALPHA']: channelID = 'ARD alpha'
	if channelID in ['SWR', 'SR', 'SWR/SR']: channelID = 'SWR'
	channelID = '  ('+channelID+')' if channelID != "" else channelID
	studio = channelID.replace('(', '').replace(')', '').replace('  ', '')
	return (channelID, studio)

params = dict(parse_qsl(sys.argv[2][1:]))
url = unquote_plus(params.get('url', ''))
mode = unquote_plus(params.get('mode', 'root'))
extras = unquote_plus(params.get('extras', '')) if params.get('extras') not in ['None', None] else None
