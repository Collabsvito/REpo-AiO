﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import time
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, unquote_plus  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else: 
	from urllib.parse import urlencode, unquote_plus  # Python 3.X
	from urllib.request import urlopen  # Python 3.X
	from functools import reduce  # Python 3.X

from .common import *


def mainMenu():
	i = 1
	while i <= 5:
		WU = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
		WT = (datetime.now() - timedelta(days=i)).strftime('%w~%d.%m.%Y')
		MD = WT.split('~')[0].replace('1', translation(30601)).replace('2', translation(30602)).replace('3', translation(30603)).replace('4', translation(30604)).replace('5', translation(30605)).replace('6', translation(30606)).replace('0', translation(30607))
		addDir(translation(30608).format(MD, WT.split('~')[1]), icon, {'mode': 'listVideos_HighDayChannel', 'url': BASE_URL+'/mediathek/nach-datum/?date='+WU})
		i += 1
	addDir(translation(30609), icon, {'mode': 'listChannel', 'url': BASE_URL+'/mediathek/nach-sender/'})
	addDir(translation(30610), icon, {'mode': 'listVideos_HighDayChannel', 'url': BASE_URL+'/mediathek/'})
	addDir(translation(30611), icon, {'mode': 'listVideos_Genre', 'url': 'Spielfilm'})
	addDir(translation(30612), icon, {'mode': 'listVideos_Genre', 'url': 'Serie'})
	addDir(translation(30613), icon, {'mode': 'listVideos_Genre', 'url': 'Report'})
	addDir(translation(30614), icon, {'mode': 'listVideos_Genre', 'url': 'Unterhaltung'})
	addDir(translation(30615), icon, {'mode': 'listVideos_Genre', 'url': 'Kinder'})
	addDir(translation(30616), icon, {'mode': 'listVideos_Genre', 'url': 'Sport'})
	if enableADJUSTMENT:
		addDir(translation(30617), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listChannel(url):
	debug_MS("(navigator.listChannel) -------------------------------------------------- START = listChannel --------------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listChannel) SENDER-SORTIERUNG : Alle Sender in TV-Spielfilm")
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listChannel) --- TVNOW - Sender {0} ---".format(STATUS))
	html = getUrl(url)
	content = html[html.find('<section class="mediathek-channels">'):]
	content = content[:content.find('</section>')]
	spl = content.split('<a title=')
	for i in range(1, len(spl), 1):
		entry = spl[i]
		urlFW = re.compile(r'href=["\'](https?://.*?mediathek/.*?)["\']>', re.S).findall(entry)[0]
		channel = urlFW.split('channel=')[1].strip()
		channelID, name = cleanStation(channel)
		if showNOW is False:
			if name.upper() in ['RTL', 'RTL2', 'VOX', 'SRTL']: continue
		debug_MS("(navigator.listChannel) Link : {0}{1}".format(urlFW, channelID))
		addDir('[COLOR lime]'+name+'[/COLOR]', artpic+name.lower().replace(' ', '')+'.png', {'mode': 'listVideos_HighDayChannel', 'url': urlFW}, studio=name)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos_HighDayChannel(url):
	debug_MS("(navigator.listVideos_HighDayChannel) -------------------------------------------------- START = listVideos_HighDayChannel --------------------------------------------------")
	debug_MS("(navigator.listVideos_HighDayChannel) MEDIATHEK : {0}".format(url))
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listVideos_HighDayChannel) --- TVNOW - Sender {0} ---".format(STATUS))
	content = getUrl(url)
	if '?date=' in url or '?channel=' in url:
		results = re.findall('<section class="teaser-section">(.+?)</section>', content, re.S)
	else:
		results = re.findall('<div class="swiper-container"(.+?)<div class="swiper-button-prev"></div>', content, re.S)
	for chtml in results:
		spl = chtml.split('<div class="content-teaser') if '?date=' in url or '?channel=' in url else chtml.split('<div class="swiper-slide">')
		for i in range(1,len(spl),1):
			entry = spl[i]
			title = re.compile(r'<span class=["\']headline["\']>(.*?)</span>', re.S).findall(entry)
			subtitle = re.compile(r'target=["\']_self["\'] title=["\'](.*?)["\']', re.S).findall(entry)
			special= re.compile(r'<span class=["\']subline.+?>(.*?)</span>', re.S).findall(entry)
			added = ""
			if (title and subtitle and not special):
				FIRST, SECOND = title[0].replace('…', '').replace('...', '').strip(), subtitle[0].replace('…', '').replace('...', '').strip()
				name = cleaning(FIRST) if FIRST == SECOND else cleaning(FIRST)+" - "+cleaning(SECOND.replace(FIRST, ""))
				channel = url.split('/')[-1].replace('?channel=', '')
			elif (title and not subtitle and special):
				name = cleaning(title[0])+" - "+cleaning(special[0].split('|')[-1])
				added = special[0].split('|')[0].strip()
				channel = cleaning(special[0].split('|')[1])
			elif (title and subtitle and special):
				FIRST, SECOND = title[0].replace('…', '').replace('...', '').strip(), subtitle[0].replace('…', '').replace('...', '').strip()
				if FIRST == SECOND: name = cleaning(FIRST)
				else:
					test_SUB = cleaning(SECOND.replace(FIRST, ""))
					name = cleaning(FIRST) if test_SUB == "" else cleaning(FIRST)+" - "+test_SUB
				added = special[0].split('|')[0].strip()
				channel = cleaning(special[0].split('|')[1])
			channelID, studio = cleanStation(channel)
			if showDATE and added != "":
				name = added.strip()+"  "+name
			urlFW = re.compile(r'<a href=["\'](https?://.*?mediathek/.*?)["\']', re.S).findall(entry)[0]
			img = re.compile(r'<img src=["\'](https?://.*?imedia/.*?.jpg)["\']', re.S).findall(entry)
			photo = img[0] if img else ""
			# 964 x 510 px = ,kpQ8aJYzw6ynhaO4Y2_vH8a7z2Do1GgrS8XBm_WNST4qVJPG6q9MH034hLE201uS129d8PUi_w_DKV5EjyOMMA==.jpg || 1280 x 720 px = ,dim:1280x720,mode:exact,center:640x254,thumb:1.jpg
			photo = photo.split(',')[0].rstrip()+',dim:1280x720,mode:exact,center:640x360,thumb:1.jpg' if ',' in photo else photo
			if showCHANNEL and studio != "":
				name += channelID
			if showNOW is False:
				if studio.upper() in ['RTL', 'RTL2', 'VOX', 'SRTL']: continue
			debug_MS("(navigator.listVideos_HighDayChannel) Name : {0}".format(name))
			debug_MS("(navigator.listVideos_HighDayChannel) Link : {0}".format(urlFW))
			debug_MS("(navigator.listVideos_HighDayChannel) Icon : {0}".format(photo))
			addLink(name, photo, {'mode': 'playVideo', 'url': urlFW}, studio)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos_Genre(category):
	debug_MS("(navigator.listVideos_Genre) -------------------------------------------------- START = listVideos_Genre --------------------------------------------------")
	debug_MS("(navigator.listVideos_Genre) MEDIATHEK : {0}/mediathek/ - Genre = *{1}*".format(BASE_URL, category.upper()))
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listVideos_Genre) --- TVNOW - Sender {0} ---".format(STATUS))
	content = getUrl(BASE_URL+'/mediathek/')
	results = re.findall('<span>'+category+'</span>(.+?)<div class="scroll-box">', content, re.S)
	for chtml in results:
		spl = chtml.split('<li>')
		for i in range(1,len(spl),1):
			entry = spl[i]
			name = ""
			all_TITLES = re.compile(r'<div class=["\']text-holder["\']>(.*?)</a>', re.S).findall(entry)[0]
			title = re.compile(r'<strong>(.*?)</strong>', re.S).findall(all_TITLES)
			subtitle = re.compile(r'<span>(.*?)</span>', re.S).findall(all_TITLES)
			reserve = re.compile(r'class=["\']aholder["\'] title=["\'](.*?)["\']>', re.S).findall(entry)
			if title and subtitle and reserve:
				FIRST, SECOND, THIRD = title[0].strip(), subtitle[0].strip(), reserve[0].strip()
				if FIRST.lower() == THIRD.lower(): name = cleaning(THIRD)
				elif ('...' in FIRST and not '...' in SECOND):
					name = cleaning(THIRD.replace(SECOND, ""))+" - "+cleaning(SECOND)
				elif ('...' in FIRST and '...' in SECOND):
					name = cleaning(FIRST)
				else:
					checking = FIRST.lower()+' '+SECOND.lower()
					name = cleaning(FIRST) if checking == THIRD.lower() else cleaning(FIRST)+" - "+cleaning(THIRD.replace(FIRST, ""))
			elif title and subtitle and not reserve:
				FIRST, SECOND = title[0].strip(), subtitle[0].strip()
				name = cleaning(FIRST) if FIRST.lower() == SECOND.lower() else cleaning(FIRST)+" - "+cleaning(SECOND.replace(FIRST, ""))
			else: name = cleaning(title[0])
			added = re.compile(r'<div class=["\']col["\']>(.*?)</div>', re.S).findall(entry)[0]
			if showDATE and added != "":
				name = added.strip()+"  "+name
			channel = re.compile(r'target=["\']_self["\'] title=["\'](.*?)["\']>', re.S).findall(entry)[0]
			channelID, studio = cleanStation(channel)
			urlFW = re.compile(r'<a href=["\'](https?://.*?mediathek/.*?)["\']', re.S).findall(entry)[0]
			img = re.compile(r'src=["\'](https?://.*?imedia/.*?.jpg)["\']', re.S).findall(entry)
			photo = img[0] if img else ""
			# 964 x 510 px = ,kpQ8aJYzw6ynhaO4Y2_vH8a7z2Do1GgrS8XBm_WNST4qVJPG6q9MH034hLE201uS129d8PUi_w_DKV5EjyOMMA==.jpg || 1280 x 720 px = ,dim:1280x720,mode:exact,center:640x254,thumb:1.jpg
			photo = photo.split(',')[0].rstrip()+',dim:1280x720,mode:exact,center:640x360,thumb:1.jpg' if ',' in photo else photo
			if showCHANNEL and studio != "":
				name += channelID
			if showNOW is False:
				if studio.upper() in ['RTL', 'RTL2', 'VOX', 'SRTL']: continue
			debug_MS("(navigator.listVideos_Genre) Name : {0}".format(name))
			debug_MS("(navigator.listVideos_Genre) Link : {0}".format(urlFW))
			debug_MS("(navigator.listVideos_Genre) Icon : {0}".format(photo))
			addLink(name, photo, {'mode': 'playVideo', 'url': urlFW}, studio)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url):
	ARD_SCHEMES = ('http://www.ardmediathek.de', 'https://www.ardmediathek.de', 'http://mediathek.daserste.de', 'https://mediathek.daserste.de')
	RTL_SCHEMES = ('http://www.nowtv.de', 'https://www.nowtv.de', 'http://www.tvnow.de', 'https://www.tvnow.de')
	log("(navigator.playVideo) --- START WIEDERGABE ANFORDERUNG ---")
	log("(navigator.playVideo) frei")
	finalURL = False
	LINK = ""
	try:
		content = getUrl(url)
		LINK = re.compile('<header class="broadcast-detail__header">.+?<a href="([^"]+)" class="mediathek-open col-hover-thek', re.S).findall(content)[0]
		log("(navigator.playVideo) AbspielLink (Original) : {0}".format(LINK))
	except:
		log("(navigator.playVideo) MediathekLink-00 : MediathekLink der Sendung in TV-Spielfilm NICHT gefunden !!!")
		return dialog.notification(translation(30521), translation(30522), icon, 8000)
	log("(navigator.playVideo) frei")
	if LINK.startswith('https://www.arte.tv'):
		try:
			videoID = re.compile('arte.tv/de/videos/([^/]+?)/', re.S).findall(LINK)[0]
			if xbmc.getCondVisibility('System.HasAddon(plugin.video.tyl0re.arte)'):
				finalURL = 'plugin://plugin.video.tyl0re.arte/?mode=playVideo&url='+str(videoID)
				log("(navigator.playVideo) AbspielLink-1 (ARTE-TV) : {0}".format(finalURL))
			elif xbmc.getCondVisibility('System.HasAddon(plugin.video.arteplussept)'):
				finalURL = 'plugin://plugin.video.arteplussept/play/SHOW/'+str(videoID)
				log("(navigator.playVideo) AbspielLink-2 (ARTE-plussept) : {0}".format(finalURL))
			if not finalURL:
				log("(navigator.playVideo) AbspielLink-00 (ARTE) : KEIN *ARTE-Addon* zur Wiedergabe vorhanden !!!")
				dialog.notification(translation(30523).format('ARTE - Addon'), translation(30524).format('ARTE-Addon'), icon, 8000)
			else:
				listitem = xbmcgui.ListItem(path=finalURL)
				xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
		except:
			log("(navigator.playVideo) AbspielLink-00 (ARTE) : *ARTE-Plugin* Der angeforderte -VideoLink- existiert NICHT !!!")
			dialog.notification(translation(30523).format('ARTE - Plugin'), translation(30525), icon, 8000)
	elif LINK.startswith(ARD_SCHEMES):
		videoURL = LINK
		return ArdGetVideo(videoURL)
	elif LINK.startswith('https://www.zdf.de'):
		videoURL = LINK[:LINK.find('.html')]+'.html'
		return ZdfGetVideo(videoURL)
	elif LINK.startswith(RTL_SCHEMES):
		LINK = LINK.replace('http://', 'https://').replace('www.nowtv.de/', 'www.tvnow.de/').replace('list/aktuell/', '').replace('/player', '')
		videoEP = LINK.split('-')[-1].strip()
		videoSE = LINK.split('/')[4].replace('-tvnow-', '').replace(videoEP, '').strip()
		log("(navigator.playVideo) --- RTL-Daten : ### Serie [{0}] ### Episode [{1}] ### ---".format(videoSE, videoEP))
		return RtlGetVideo(videoSE, videoEP, LINK)
	log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")

def ArdGetVideo(videoURL):
	finalURL = False
	m3u8_List = []
	ARD_Url = ""
	try:
		docuID = re.search(r'documentId=([0-9]+)', videoURL)
		if docuID:
			videoID = docuID.group(1)
		else:
			secondURL = getUrl(videoURL)
			videoID = re.compile(r'["\']contentId["\']:([^,]+?),["\']metadataId["\']:', re.S).findall(secondURL)[0].replace('"', '').replace("'", "")
		debug_MS("(navigator.ArdGetVideo) ***** Extracted-videoID : {0} *****".format(videoID))
		# evtl. OLD = https://classic.ardmediathek.de/play/media/66597424 #
		content = getUrl('https://appdata.ardmediathek.de/appdata/servlet/play/media/'+videoID)
		debug_MS("(navigator.ArdGetVideo) ##### CONTENT : {0} #####".format(str(content)))
		result = json.loads(content)
		video_data = result['_mediaArray'][1] if len(result['_mediaArray']) > 1 else result['_mediaArray'][0]
		if prefSTREAM == '0' and str(video_data['_mediaStreamArray'][0]['_quality']) == 'auto':
			if isinstance(video_data['_mediaStreamArray'][0]['_stream'], list):
				finalURL = str(video_data['_mediaStreamArray'][0]['_stream'][0])
				log("(navigator.ArdGetVideo) Wir haben mehrere *m3u8-Streams* in der Liste (ARD+3) - wähle den Ersten : {0}".format(finalURL))
			else:
				finalURL = str(video_data['_mediaStreamArray'][0]['_stream'])
				log("(navigator.ArdGetVideo) Wir haben 1 *m3u8-Stream* (ARD+3) - wähle Diesen : {0}".format(finalURL))
			if finalURL:
				finalURL = 'https:'+finalURL if finalURL[:4] != 'http' else finalURL
		if not finalURL:
			if isinstance(video_data['_mediaStreamArray'][-1]['_stream'], list):
				ARD_Url = str(video_data['_mediaStreamArray'][-1]['_stream'][-1])
				log("(navigator.ArdGetVideo) Wir haben mehrere *mp4-Streams* in der Liste (ARD+3) - wähle den Zweiten : {0}".format(ARD_Url))
			else:
				ARD_Url = str(video_data['_mediaStreamArray'][-1]['_stream'])
				log("(navigator.ArdGetVideo) Wir haben nur 1 *mp4-Stream* (ARD+3) - wähle Diesen : {0}".format(ARD_Url))
			if ARD_Url != "":
				ARD_Url = 'https:'+ARD_Url if ARD_Url[:4] != 'http' else ARD_Url
				finalURL = VideoBEST(ARD_Url, improve='ard-YES') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
		if not finalURL:
			log("(navigator.ArdGetVideo) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
			dialog.notification(translation(30523).format('ARD - Intern'), translation(30525), icon, 8000)
		else:
			listitem = xbmcgui.ListItem(path=finalURL)
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
			log("(navigator.ArdGetVideo) END-Qualität (ARD+3) : {0}".format(finalURL))
	except:
		failing("(ArdGetVideo) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
		dialog.notification(translation(30523).format('ARD - Intern'), translation(30525), icon, 8000)
	log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")

def RtlGetVideo(SERIES, EPISODE, REFERER):
	if xbmc.getCondVisibility('System.HasAddon(plugin.video.rtlgroup.de)'):
		# OLD = http://api.tvnow.de/v3/movies/shopping-queen/2361-lisa-marie-nuernberg-flower-power-praesentiere-dich-in-deinem-neuen-bluetenkleid?fields=manifest,isDrm,free,payed
		# NEW = https://api.tvnow.de/v3/movies?filter={%22FormatId%22:%2219022%22}&fields=manifest,id,isDrm,free,payed
		try: # https://bff.apigw.tvnow.de/module/player/%d" % int(assetID)
			StreamID = SERIES.split('-')[-1].strip() if len(EPISODE) > 6 else EPISODE
			content = getUrl('https://api.tvnow.de/v3/movies?filter={%22FormatId%22:%22'+StreamID+'%22}&fields=manifest,id,isDrm,free,payed&maxPerPage=500')
			DATA = json.loads(content)
			MoreThanOne = (True if len(DATA['items']) > 1 else False)
			for item in DATA['items']:
				videoFREE, videoHD = ("" for _ in range(2))
				if (MoreThanOne is True and str(item.get('id', '0')) == EPISODE) or MoreThanOne is False:
					EPnumber = (str(item.get('id', '0')) or '0')
					PayType = (item.get('payed', True) or item.get('free', True) or True)
					protected = (item.get('isDrm', False) or False)
					log("(navigator.RtlGetVideo) ~~~ Ist dieses Video DRM - geschützt ??? = {0} ~~~".format(str(protected)))
					if item.get('manifest', '') and item.get('manifest', {}).get('dash', ''): # Normal-Play without Account
						videoFREE = item['manifest']['dash'].replace('dash.secure.footprint.net', 'dash-a.akamaihd.net')
						debug_MS("(navigator.RtlGetVideo) videoFREE : {0}".format(videoFREE))
					if item.get('manifest', '') and item.get('manifest', {}).get('dashhd', ''): # HD-Play with Pay-Account
						videoHD = item['manifest']['dashhd'].replace('dash.secure.footprint.net', 'dash-a.akamaihd.net').split('.mpd')[0]+'.mpd'
						debug_MS("(navigator.RtlGetVideo) videoHD : {0}".format(videoHD))
					listitem = xbmcgui.ListItem(path='{0}?{1}'.format('plugin://plugin.video.rtlgroup.de/', urlencode({'mode': 'playDash', 'xnormSD': videoFREE, 'xhighHD': videoHD, 'xcode': EPnumber, 'xlink': REFERER, 'xdrm': protected, 'xstat': PayType})))
					xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
		except:
			failing("(RtlGetVideo) AbspielLink-00 (TV-Now) : *TVNOW-Plugin* Der angeforderte -VideoLink- existiert NICHT !!!")
			dialog.notification(translation(30523).format('TVNOW - Plugin'), translation(30525), icon, 8000)
	else:
		failing("(navigator.RtlGetVideo) AbspielLink-00 (TVNOW) : KEIN *TVNOW - VERSION(3) - Addon* zur Wiedergabe vorhanden !!!")
		dialog.notification(translation(30523).format('TVNOW - Addon'), translation(30524).format('TVNOW - VERSION(3)'), icon, 8000)
	log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")

def ZdfGetVideo(videoURL):
	videoFOUND = False
	try: 
		content = getUrl(videoURL)
		response = re.compile(r'(?s)data-zdfplayer-jsb=["\'](?P<json>{.+?})["\']', re.S).findall(content)[0]
		firstURL = json.loads(response)
		if firstURL:
			teaser = firstURL['content']
			secret = firstURL['apiToken']
			headerfields = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0'), ('Api-Auth', 'Bearer '+secret)]
			log("(navigator.ZdfGetVideo) SECRET gefunden (ZDF+3) : ***** {0} *****".format(str(secret)))
			teaser = API_ZDF+teaser if teaser[:4] != 'http' else teaser
			debug_MS("(navigator.ZdfGetVideo) ##### TEASER : {0} #####".format(teaser))
			secondURL = getUrl(teaser, header=headerfields)
			element = json.loads(secondURL)
			if element['profile'] == 'http://zdf.de/rels/not-found':
				return False
			if element['contentType'] == 'clip':
				component = element['mainVideoContent']['http://zdf.de/rels/target']
				#videoFOUND1 = API_ZDF+element['mainVideoContent']['http://zdf.de/rels/target']['http://zdf.de/rels/streams/ptmd']
				#videoFOUND2 = API_ZDF+element['mainVideoContent']['http://zdf.de/rels/target']['http://zdf.de/rels/streams/ptmd-template'].replace('{playerId}', 'ngplayer_2_4')
			elif element['contentType'] == 'episode':
				if 'mainVideoContent' in element:
					component = element['mainVideoContent']['http://zdf.de/rels/target']
				elif 'mainContent' in element:
					component = element['mainContent'][0]['videoContent'][0]['http://zdf.de/rels/target']
			if 'http://zdf.de/rels/streams/ptmd-template' in component and component['http://zdf.de/rels/streams/ptmd-template'] != "":
				videoFOUND = API_ZDF+component['http://zdf.de/rels/streams/ptmd-template'].replace('{playerId}', 'ngplayer_2_4').replace('\/', '/')
			if videoFOUND:
				debug_MS("(navigator.ZdfGetVideo) ##### videoFOUND : {0} #####".format(videoFOUND))
				thirdURL = getUrl(videoFOUND, header=headerfields)
				return ZdfExtractQuality(thirdURL)
	except:
		failing("(ZdfGetVideo) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
		log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")
		dialog.notification(translation(30523).format('ZDF - Intern'), translation(30525), icon, 8000)

def ZdfExtractQuality(thirdURL):
	jsonObject = json.loads(thirdURL)
	MEDIAS = []
	m3u8_QUALITIES = ['auto', 'veryhigh', 'high', 'med']
	mp4_QUALITIES = ['hd', 'veryhigh', 'high', 'low']
	finalURL = False
	try:
		for each in jsonObject['priorityList']:
			formitaeten = each.get('formitaeten')
			if not isinstance(formitaeten, list):
				continue
			for item in formitaeten:
				vidForm = item.get('type')
				vidType = item.get('mimeType').lower()
				vidQuality = item.get('qualities')
				vidMode = item.get('facets', [])
				if prefSTREAM == '0' and vidForm == 'h264_aac_ts_http_m3u8_http' and vidType == 'application/x-mpegurl':
					for found in m3u8_QUALITIES:
						for quality in vidQuality:
							if quality['quality'] == found and 'mil/master.m3u8' in quality['audio']['tracks'][0]['uri']:
								MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': vidType, 'language': quality['audio']['tracks'][0]['language']})
					finalURL = MEDIAS[0]['url']
					log("(navigator.ZdfExtractQuality) m3u8-Stream (ZDF+3) : {0}".format(finalURL))
				if not finalURL and vidForm == 'h264_aac_mp4_http_na_na' and 'progressive' in vidMode and vidType == 'video/mp4':
					for found in mp4_QUALITIES:
						for quality in vidQuality:
							if quality['quality'] == found:
								MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': vidType, 'language': quality['audio']['tracks'][0]['language']})
					log("(navigator.ZdfExtractQuality) ZDF-STANDARDurl : {0}".format(MEDIAS[0]['url']))
					finalURL = VideoBEST(MEDIAS[0]['url'], improve='zdf-YES') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
		if not finalURL:
			log("(navigator.ZdfExtractQuality) AbspielLink-00 (ZDF+3) : *ZDF-Intern* VIDEO konnte NICHT abgespielt werden !!!")
		else:
			listitem = xbmcgui.ListItem(path=finalURL)
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
			log("(navigator.ZdfExtractQuality) END-Qualität (ZDF+3) : {0}".format(finalURL))
	except:
		failing("(ZdfExtractQuality) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Fehler bei Anforderung des AbspielLinks !!!")
	log("(navigator.playVideo) --- ENDE WIEDERGABE ANFORDERUNG ---")

def VideoBEST(best_url, improve=False):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	standards = [best_url, "", ""]
	if improve == 'ard-YES':
		first_repls = (('/960', '/1280'), ('.hq.mp4', '.hd.mp4'), ('.l.mp4', '.xl.mp4'), ('_C.mp4', '_X.mp4'))
		second_repls = (('/1280', '/1920'), ('.xl.mp4', '.xxl.mp4'))
	elif improve == 'zdf-YES':
		first_repls = (('808k_p11v15', '2360k_p35v15'), ('1628k_p13v15', '2360k_p35v15'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'),
								('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
		second_repls = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'))
	standards[1] = reduce(lambda a, kv: a.replace(*kv), first_repls, standards[0])
	standards[2] = reduce(lambda b, kv: b.replace(*kv), second_repls, standards[1])
	for element in reversed(standards):
		if len(element) > 0:
			try:
				code = urlopen(element).getcode()
				if str(code) == '200':
					return element
			except: pass
	return best_url

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, studio=None, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': studio})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, studio=None, plot=None, duration=None, seriesname=None, genre=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Tvshowtitle'] = seriesname
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Genre'] = genre
	info['Studio'] = studio
	info['Mediatype'] = 'tvshow'
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
