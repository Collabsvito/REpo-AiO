﻿# -*- coding: utf-8 -*-

from .common import *
from .resolver import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/", 'extras': 'AKTUELL BELIEBT'})
	addDir(translation(30602), icon, {'mode': 'listDates'})
	addDir(translation(30603), icon, {'mode': 'listChannels', 'url': f"{BASE_URL}/mediathek/nach-sender/"})
	addDir(translation(30604), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/spielfilme/", 'extras': 'SPIELFILME'})
	addDir(translation(30605), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/serien/", 'extras': 'SERIEN'})
	addDir(translation(30606), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/dokus/", 'extras': 'DOKUS'})
	addDir(translation(30607), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/unterhaltung/", 'extras': 'UNTERHALTUNG'})
	addDir(translation(30608), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/kinder/", 'extras': 'KINDER'})
	addDir(translation(30609), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/sport/", 'extras': 'SPORT'})
	addDir(translation(30610), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/filter/?irating=6&filtertype=filter", 'extras': 'TOP IMDB BEWERTET'})
	addDir(translation(30611), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/filter/?timeFrom=20:15&timeTo=23:58&channels=ARD,WDR,N3,BR,SWR,HR,MDR,RBB,FES", 'extras': 'PRIMETIME-HIGHLIGHTS ARD+'})
	addDir(translation(30612), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/filter/?timeFrom=20:15&timeTo=23:58&channels=ZDF,2NEO,ZINFO,3SAT,ARTE", 'extras': 'PRIMETIME-HIGHLIGHTS ZDF+'})
	addDir(translation(30613), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/filter/?timeFrom=20:15&timeTo=23:58&channels=RTL-N,RTL,RTL2,RTLPL,VOX,SUPER,K1,PRO7,PRO7M,SAT1,SAT1G,SIXX,SERVU,TELE5,WELT", 'extras': 'PRIMETIME-HIGHLIGHTS PRIVATE'})
	if enableADJUSTMENT:
		addDir(translation(30614), f"{artpic}settings.png", {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30615), f"{artpic}settings.png", {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listDates():
	for ii in range(-14, 15, 1):
		WU = (datetime.now() - timedelta(days=ii)).strftime('%Y-%m-%d') # Datum für URL // 2023-07-12
		WD = (datetime.now() - timedelta(days=ii)).strftime('%a, %d.%m.') # Datum mit engl. Wochentagskürzel ohne Jahr // Sun, 16.07.
		for tt in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), ('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))):
			WD = WD.replace(*tt)
		if ii == 0: addDir(translation(32108).format(WD), icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/nach-datum/?date={WU}", 'extras': WD})
		else: addDir(WD, icon, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/nach-datum/?date={WU}", 'extras': WD})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listChannels(url):
	debug_MS("(navigator.listChannels) -------------------------------------------------- START = listChannels --------------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listChannels) SENDER-SORTIERUNG : Alle Sender in TV-Spielfilm")
	STATE_JN = 'EINGEBLENDET' if showJOYN is True else 'AUSGEBLENDET'
	STATE_RT = 'EINGEBLENDET' if showRTL is True else 'AUSGEBLENDET'
	debug_MS(f"(navigator.listChannels) --- JOYN Mediathek  - Sender {STATE_JN} ---")
	debug_MS(f"(navigator.listChannels) --- RTLPLUS Mediathek - Sender {STATE_RT} ---")
	content = getUrl(url, 'LOAD')
	results = re.findall(r'''<div class=["']mediathek-channel-slider__container["'](.*?)</div>''', content, re.S)[0]
	NaviItem = re.findall(r'''title=["']([^"']+)" href=["'](https?://.*?mediathek/.*?)["']\s*class=["']js-track-link''', results, re.S)
	for TITLE, ULINK in NaviItem:
		channelID, name = cleanStation(TITLE) # SUPER RTL Mediathek
		if showARTE is False and name.upper() in ARTEEX: continue
		if showJOYN is False and name.upper() in JOYNEX: continue
		if showSERVUS is False and name.upper() in SERVUSEX: continue
		if showTELE is False and name.upper() in TELEEX: continue
		if showRTL is False and name.upper() in RTLEX: continue
		debug_MS(f"(navigator.listChannels[1]) ##### NAME : {name} || LINK : {ULINK} ##### ")
		addDir(translation(30621).format(name), f"{artpic}{name.lower().replace(' ', '')}.png", {'mode': 'listBroadcasts', 'url': ULINK, 'extras': f"{name} - Mediathek"}, studio=name)
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(url, CATI):
	debug_MS("(navigator.listBroadcasts) -------------------------------------------------- START = listBroadcasts --------------------------------------------------")
	debug_MS(f"(navigator.listBroadcasts) MEDIATHEK : {url}")
	STATE_JN = 'EINGEBLENDET' if showJOYN is True else 'AUSGEBLENDET'
	STATE_RT = 'EINGEBLENDET' if showRTL is True else 'AUSGEBLENDET'
	debug_MS(f"(navigator.listChannels) --- JOYN Mediathek  - Sender {STATE_JN} ---")
	debug_MS(f"(navigator.listChannels) --- RTLPLUS Mediathek - Sender {STATE_RT} ---")
	PIC_QUALITIES = ['_159.jpg', '_164.jpg', '_245.jpg', '_300.jpg', '_456.jpg', '_476.jpg', '_600.jpg', '_632.jpg', '_640.jpg']
	SEND, UNIKAT = {}, set()
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, SEND['videos'] = ([] for _ in range(4))
	PAGE_NUMBER, NEXT_PAGE, counter = 1, None, 0
	while PAGE_NUMBER > 0:
		content = getUrl(url, 'LOAD') if PAGE_NUMBER == 1 else getUrl(NEXT_PAGE, 'LOAD')
		if '?date=' in url or 'nach-sender' in url:
			results = re.findall(r'''<div class=["']tips-teaser-container["'](.*?)</section>''', content, re.S)
		elif url.endswith('mediathek/'):
			results = re.findall(r'''<div class=["']content-area["']>(.*?)<div class=["']swiper-pagination["']>''', content, re.S)
		else:
			results = re.findall(r'''<div id=["']mediacenter-genre-container["']>(.*?)</section>''', content, re.S)
		for chtml in results:
			spl = chtml.split('tips-teaser category-tips js-track-link')
			for i in range(1, len(spl), 1):
				entry = spl[i]
				debug_MS(f"(navigator.listBroadcasts[1]) xxxxx ENTRY-01 : {str(entry)} xxxxx")
				DATE_1, SORTDAY_1 = (None for _ in range(2))
				title = re.compile(r'''class=["']tips-teaser__bottom__title["'].+?>([^<]+)</span>''', re.S).findall(entry)
				reserve = re.compile(r''' title=["']([^"']+)"''', re.S).findall(entry)
				datum = re.compile(r'Ausstrahlung:\ ([^<]+)</span>', re.S).findall(entry) # TV-Ausstrahlung: 11.02.2023
				TITLE_1, TVSHOW_1 = cleaning(title[0]), cleaning(title[0])
				if '?date=' in url and title and datum:
					DEFAULT = datum[0][:6].strip()
					WANTED = url.split('?date=')[1][8:10]+'.'+url.split('?date=')[1][5:7]+'.'
					#log(f"(navigator.listBroadcasts[2]) FilterDate ### DEFAULT : {DEFAULT} || WANTED : {WANTED} || NAME : {TITLE_1} ###")
					if DEFAULT != WANTED: continue
				if title and reserve:
					FIRST, SECOND = title[0].strip(), reserve[0].strip()
					checking = cleaning(SECOND.replace(FIRST, ''))
					TITLE_1 = cleaning(FIRST) if checking == "" else cleaning(FIRST)+" - "+checking
				matchCOU = re.compile(r'''class=["']detail-info["']>([^<]+)</span>''', re.S).findall(entry)
				COUNTRY_1 = cleaning(matchCOU[0].split('|')[0]) if matchCOU else None # D/L 2019 | 86 Min.
				matchGEN = re.compile(r'''class=["']tips-teaser__bottom__category["']>([^<]+)</span>''', re.S).findall(entry)
				GENRE_1 = cleaning(matchGEN[0]) if matchGEN else None # Mysteryabenteuer
				plus_INFOS_1 = COUNTRY_1+' | '+GENRE_1 if COUNTRY_1 and GENRE_1 else None # D 2021 | Krimi
				matchDAT = re.compile(r'Ausstrahlung:\ ([^<]+)</span>', re.S).findall(entry) # TV-Ausstrahlung: 11.02.2023
				if matchDAT and str(matchDAT[0])[:10].replace('.', '').replace('-', '').replace(' ', '').isdigit():
					timing = datetime(*(time.strptime(matchDAT[0][:10], '%d{0}%m{0}%Y'.format('.'))[0:6])) # 18.01.
					DATE_1 = timing.strftime('%a{0} %d{0}%m{0}%Y').format('.')
					SORTDAY_1 = timing.strftime('%Y{0}%m{0}%d').format('.')
					for tg in (('Mon', translation(32201)), ('Tue', translation(32202)), ('Wed', translation(32203)), ('Thu', translation(32204)), ('Fri', translation(32205)), ('Sat', translation(32206)), ('Sun', translation(32207))):
						DATE_1 = DATE_1.replace(*tg)
				matchRAT = re.compile(r'''class=["']tips-teaser__bottom__imdb-rating["']>IMDb-Bewertung:([^<]+)</div>''', re.S).findall(entry)
				RATING_1 = matchRAT[0].strip().replace(',', '.') if matchRAT else None # IMDb-Bewertung: 6,2
				all_CHANNELS = re.compile(r'''<div class=["']channel-logo["']>(.*?)</div>''', re.S).findall(entry)[0]
				matchCHA = re.compile(r'''title=["'](.*?)["'] loading=''', re.S).findall(all_CHANNELS)[0]
				CHANNEL_1, STUDIO_1 = cleanStation(matchCHA)
				# "event_label":"https:\/\/www.tvspielfilm.de\/mediathek\/mein-suesses-geheimnis,11656496.html",
				matchEVT = re.compile(r'''["']event_label["']:["'](https:\\/\\/www.tvspielfilm.de\\/mediathek.*?)["'],''', re.S).findall(entry)
				WLINK_1 = matchEVT[0].replace('\/', '/') if matchEVT else None
				if WLINK_1 is None or WLINK_1 and (WLINK_1 in UNIKAT or WLINK_1[:-1].endswith('mediathek')):
					continue
				UNIKAT.add(WLINK_1)
				# background-image: url(https://a2.tvspielfilm.de/itv_sofa/mediathek/2023-07-24/649ed9e58b43ee280977e6b0_632.jpg);
				img = re.compile(r'background-image: url\((https://a2.tvspielfilm.de/itv_sofa/.*?.jpg)\)', re.S).findall(entry)
				# vorh. Bild-Grössen (ab 16.07.23): _159.jpg // _164.jpg // _245.jpg // _300.jpg // _456.jpg // _476.jpg // _600.jpg // _632.jpg // _640.jpg // _780.jpg
				THUMB_1 = re.sub(r'_[0-9]+.jpg', '_780.jpg', img[0]) if img and any(nb in img[0] for nb in PIC_QUALITIES) else img[0] if img else ""
				if showARTE is False and STUDIO_1.upper() in ARTEEX: continue
				if showJOYN is False and STUDIO_1.upper() in JOYNEX: continue
				if showSERVUS is False and STUDIO_1.upper() in SERVUSEX: continue
				if showTELE is False and STUDIO_1.upper() in TELEEX: continue
				if showRTL is False and STUDIO_1.upper() in RTLEX: continue
				counter += 1
				COMBI_FIRST.append([int(counter), TITLE_1, TVSHOW_1, THUMB_1, WLINK_1, DATE_1, SORTDAY_1, plus_INFOS_1, RATING_1, STUDIO_1, CHANNEL_1])
				COMBI_LINKS.append([int(counter), WLINK_1])
		LOAD_MORE = re.compile(r'''<a href=["']([^"']+)["'] class=["']load-more["'] id=["'](?:tips-teaser-load-more|mediacenter-genre-load-more)["']''', re.S).findall(content)
		if LOAD_MORE and len(LOAD_MORE[0]) > 0: # id="tips-teaser-load-more" || id="mediacenter-genre-load-more"
			NEXT_PAGE = BASE_URL+LOAD_MORE[0] if LOAD_MORE and LOAD_MORE[0][:4] != 'http' else LOAD_MORE[0] if LOAD_MORE and LOAD_MORE[0][:4] == 'http' else None
			debug_MS(f"(navigator.listBroadcasts[1]) PAGES ### NOW GET NEXTPAGE : {str(NEXT_PAGE)} ###")
			PAGE_NUMBER += 1
		else: 
			PAGE_NUMBER = 0
			break
	if COMBI_FIRST:
		COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_FIRST or COMBI_SECOND: # Zähler NULL ist immer die Nummerierungder Listen 1+2
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_SECOND if a[0] == b[0] and a[4] == b[3]] # Zusammenführung von Liste1 und Liste2 - wenn die Nummer an erster Stelle(0) und die LINK-ID an vierter Stelle(3) überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listBroadcasts[3]) XXXXX RESULT-03 : {str(RESULT)} XXXXX")
		if url.endswith('mediathek/'):
			RESULT = sorted(RESULT, key=lambda e: (e[6] if e[6] is not None else e[17]), reverse=True)
		else:
			RESULT = sorted(RESULT, key=lambda k: int(k[0]), reverse=False)
		for da in RESULT: # 0-7 = Liste1 || 8-19 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listBroadcasts[3]) ### Anzahl = {str(len(da))} || Eintrag : {str(da)} ###")
			Note_1, Note_2, Note_3 = ("" for _ in range(3))
			season, episode, aired, year, mpaa = (None for _ in range(5))
			if len(da) > 11: ### Liste2 beginnt mit Nummer:11 ###
				name, seriesname, image, Link1, Added1, OrderDay1, YearGenre1, rating, studio, ChannelID = da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10]
				description, tagline, Link2, SerieEpis, Added2, OrderDay2, duration, YearGenre2, genre, mpaa, cast, director, play_LINK = da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19], da[20], da[21], da[22], da[23], da[24]
			else:
				name, seriesname, image, Link1, Added1, OrderDay1, YearGenre1, rating, studio, ChannelID = da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10]
				description, tagline, Link2, SerieEpis, Added2, OrderDay2, duration, YearGenre2, genre, mpaa, cast, director, play_LINK = "", None, "", None, None, "", None, None, None, None, [], [], None
			if SerieEpis:
				matchSE = re.search('(Staffel:? |S)(\d+)', SerieEpis) # Staffel 12, Folge 05 // Staffel 14, Folge 9b/8 // Folge 1022
				if matchSE: season = matchSE.group(2).zfill(2)
				matchEP = re.search('(Episode:? |Folge:? |E)(\d+)', SerieEpis) # Staffel 12, Folge 05 // Staffel 14, Folge 9b/8 // Folge 1022
				if matchEP: episode = matchEP.group(2).zfill(2)
				Note_1 = translation(30622).format(str(SerieEpis))
			if Added1 or Added2:
				aired = Added1[4:14] if Added1 else Added2[4:14] # FirstAired
				Note_2 = translation(30623).format(Added1) if Added1 else translation(30623).format(Added2)
				if showDATE:
					name = f"{Added1[4:10]}  {name}" if Added1 else f"{Added2[4:10]}  {name}" # Added1 = Sa. 11.02.2023 || Added2 = Sa. 11.02.2023 || ergebnis = 11.02.
			if YearGenre1 or YearGenre2:
				marking = YearGenre1 if YearGenre1 else YearGenre2
				matchYR = re.search('(\d+)', marking) # D 2021 | Krimi
				if matchYR: year = matchYR.group(1)
				name += f" - {marking}"
			if studio != "":
				Note_3 = translation(30624).format(studio) if description != "" else translation(30625).format(studio)
			mpaa = None if mpaa and str(mpaa).startswith('0 ') else mpaa
			if showCHANNEL and ChannelID != "":
				name += ChannelID.replace('ServusTV Deutschland', 'ServusTV').replace('TOGGO plus', 'TOGGO')
			#if play_LINK and play_LINK.startswith('https://plus.rtl.de'):
				#videoHUB = re.search('(\d+)', play_LINK.split('-')[-1]) # https://plus.rtl.de/video-tv/shows/denn-sie-wissen-nicht-was-passiert-die-jauch-gottschalk-schoeneberger-show-803481
				#if videoHUB:
					#PREDICATE = 'movie' if 'filme/' in LINK else 'episode' # shows + serien
					#uvz = f"plugin://plugin.video.tvnow.de/?action=listPage&id=rrn:watch:videohub:format:{videoHUB.group(1)}"
					#folder = True
				#else: continue
			#else:
			uvz = build_mass({'mode': 'playCODE', 'IDENTiTY': Link1})
			folder = False
			plot = Note_1+Note_2+description+Note_3
			debug_MS(f"(navigator.listBroadcasts[4]) ##### TITLE : {name} || STAFFEL : {str(season)} || EPISODE : {str(episode)} || YEAR : {str(year)} || THUMB : {image} #####")
			debug_MS(f"(navigator.listBroadcasts[4]) ##### OR-LINK : {Link1} || VIDEO : {str(play_LINK)} || STUDIO : {studio} || RATING : {str(rating)} #####")
			LSM = xbmcgui.ListItem(name)
			cineType = 'episode' if str(episode).isdigit() else 'movie'
			if plot in ['', 'None', None]: plot = "..."
			if KODI_ov20:
				vinfo = LSM.getVideoInfoTag()
				if str(season).isdigit(): vinfo.setSeason(int(season))
				if str(episode).isdigit(): vinfo.setEpisode(int(episode))
				vinfo.setTitle(name)
				vinfo.setTagLine(tagline)
				vinfo.setPlot(plot)
				if str(duration).isdigit(): vinfo.setDuration(int(duration))
				if aired: vinfo.setFirstAired(aired)
				if year: vinfo.setYear(int(year))
				if genre and len(genre) > 2: vinfo.setGenres([genre])
				if director: vinfo.setDirectors([director])
				if isinstance(cast, (list, tuple)): vinfo.setCast(cast)
				if rating and str(rating).replace('.', '').isdigit(): vinfo.setRating(float(rating), 0, 'imdb', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
				vinfo.setStudios([studio])
				if mpaa: vinfo.setMpaa(mpaa)
				vinfo.setMediaType(cineType)
			else:
				vinfo = {}
				if isinstance(cast, (list, tuple)): LSM.setCast(cast)
				if str(season).isdigit(): vinfo['Season'] = season
				if str(episode).isdigit(): vinfo['Episode'] = episode
				vinfo['Title'] = name
				vinfo['Tagline'] = tagline
				vinfo['Plot'] = plot
				if str(duration).isdigit(): vinfo['Duration'] = duration
				if aired: vinfo['Aired'] = aired
				if year: vinfo['Year'] = year
				if genre and len(genre) > 2: vinfo['Genre'] = genre
				if director: vinfo['Director'] = director
				if rating and str(rating).replace('.', '').isdigit(): LSM.setRating('imdb', float(rating), 0, True) # LSM.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
				vinfo['Studio'] = studio
				if mpaa: vinfo['Mpaa'] = mpaa
				vinfo['Mediatype'] = cineType
				LSM.setInfo('Video', vinfo)
			LSM.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
			if image and useThumbAsFanart and image != icon and not artpic in image:
				LSM.setArt({'fanart': image})
			if not folder:
				LSM.setProperty('IsPlayable', 'true')
				LSM.setContentLookup(False)
			LSM.addContextMenuItems([(translation(30654), 'Action(Queue)')])
			SEND['videos'].append({'filter': Link1, 'direct': play_LINK, 'name': name, 'tvshow': seriesname, 'station': studio})
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LSM, isFolder=folder)
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	else:
		debug_MS("(navigator.listBroadcasts[2]) ##### COMBI_EPISODE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525), translation(30526).format(CATI), icon, 8000)
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSubstances(MURLS):
	debug_MS("(navigator.listSubstances) -------------------------------------------------- START = listSubstances --------------------------------------------------")
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	GENCATEGORIES = ['Abenteuer', 'Action', 'Animation', 'Anwalt', 'Bericht', 'Boxen', 'Casting', 'Comedy', 'Diskussion', 'Doku', 'Drama', 'Eishockey', 'Eiskunstlauf', 'Familie', 'Fantasy', 'Freizeit', 'Fußball',\
										'Gala', 'Gesundheit', 'Groteske', 'Handball', 'Heimat', 'Horror', 'Kabarett', 'Kinder', 'Kochduell', 'Komödie', 'Konzert', 'Krankenhaus', 'Krimi', 'Kultur', 'Märchen', 'Magazin', 'Melodram',\
										'Motorrad', 'Musik', 'Mystery', 'Nachrichten', 'Natur', 'Polizei', 'Porträt', 'Psychodrama', 'Quiz', 'Ratgeber', 'Reality', 'Reiten', 'Reportage', 'Roadmovie', 'Romanze', 'Satire', 'Sci-Fi', 'Show',\
										'Sitcom', 'Ski', 'Soap', 'Sondersendung', 'Sport', 'Talk', 'Theater', 'Tragikomödie', 'Tragödie', 'Thriller', 'Umwelt', 'Verbraucher', 'Vorschulreihe', 'Western', 'Wetter', 'Wissen', 'Zeichentrick']
	if COMBI_DETAILS:
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.llistSubstances[2]) XXXXX CONTENT-02 : {str(COMBI_DETAILS)} XXXXX")
		debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
		for number, WLINK_2, elem in COMBI_DETAILS:
			if elem is not None:
				DESC_2, SORTDAY_2 = ("" for _ in range(2))
				STORY_01, TAG_MARKER, TAGLINE_2, EPIS_2, DATE_2, DURATION_2, plus_INFOS_2, GENRE_2, MPAA_2, PLAYLINK_2 = (None for _ in range(10))
				CASTING_2, DIRECTOR_2 = ([] for _ in range(2))
				details = re.findall(r'''<article class=["']broadcast-detail["'](.*?)</article>''', elem, re.S)
				for item in details:
					debug_MS(f"(navigator.listSubstances[2]) xxxxx ITEM-02 : {str(item)} xxxxx")
					TEASER = re.findall(r'''<section class=["']broadcast-detail__description["'](.*?)</section>''', item, re.S)[0]
					TAG_01 = re.compile(r'''<p class=["']headline["']>([^<]+)</p>''', re.S).findall(TEASER) # Filme & Serien
					TAG_02 = re.compile(r'''<h2 class=["']broadcast-info["']>([^<]+)</h2>''', re.S).findall(item) # z.B. Neuanfänge (2)
					TAG_03 = re.compile(r'''<ul class=["']headline prelude["']>(.*?)</ul>''', re.S).findall(TEASER) # z.B. Küchlein, Kopfstand und Krokan
					if TAG_03 and len(TAG_03[0]) > 10:
						TAG_SPECIAL = re.compile(r'<li[^>]*>(.*?)</li>', re.S).findall(TAG_03[0])
						TAG_MARKER = '[CR]'.join(['• '+cleaning(re.sub(' +', ' ', tagpart.replace('\n', ' ').replace('\t', ' '))) for tagpart in TAG_SPECIAL])
					TAGLINE_2 = cleaning(TAG_01[0].replace('\n', ' ').replace('\t', ' ')) if TAG_01 else cleaning(TAG_02[0].replace('\n', ' ').replace('\t', ' ')) if TAG_02 and \
						not TAG_02[0].startswith('Mehr zu ') else TAG_MARKER if TAG_MARKER else None
					if TAGLINE_2 and len(TAGLINE_2) > 125 and TAG_MARKER is None:
						TAGLINE_2 = TAGLINE_2[:125]+'...'
					STORY_01 = re.compile(r'<p>(.*?)</p>', re.S).findall(TEASER)
					if STORY_01 and len(STORY_01[0]) > 10:
						DESC_2 += '[CR][CR]'.join([cleaning(re.sub(' +', ' ', teapart.replace('\n', ' ').replace('\t', ' '))) for teapart in STORY_01])
						DESC_2 = DESC_2.rstrip()[:-4] if DESC_2.endswith('[CR]') else DESC_2
					GUESTS = re.compile(r'''<div class=["']broadcast-info-guests["']>(.*?)</section>''', re.S).findall(item)
					if GUESTS and '<li' in GUESTS[0]:
						STORY_02 = re.compile(r'<li[^>]*>(.*?)</li>', re.S).findall(GUESTS[0])
						if STORY_02 and len(STORY_02[0]) > 1:
							prefix = '[CR][CR]' if STORY_01 and len(STORY_01[0]) > 10 else ""
							DESC_2 += prefix+'[CR]'.join([cleaning(cleanGuest(modpart)) for modpart in STORY_02])
							DESC_2 = DESC_2.rstrip()[:-4] if DESC_2.endswith('[CR]') else DESC_2
					SERIE_2 = re.compile(r'''<section class=["']serial-info["']>(.*?)</section>''', re.S).findall(item)
					EPIS_2 = cleaning(re.sub(r'\<.*?>', '', SERIE_2[0])) if SERIE_2 else None # Folge 4
					SECTOR_1 = re.compile(r'''<div class=["']text-wrapper["']>(.*?)<section class=["']broadcast-detail__stage''', re.S).findall(item)
					matchONE = cleaning(SECTOR_1[0]) if SECTOR_1 else None
					if matchONE:
						TIME_2 = re.compile(r'Ausstrahlung:\ ([^<]+)</span>', re.S).findall(matchONE)
						matchDT = TIME_2[0].strip()[:6] if TIME_2 else None # TV-Ausstrahlung: 18.01. | 90 Min.
						if matchDT and str(matchDT.replace('.', '').replace('-', '').replace(' ', '')).isdigit():
							dt_year = (datetime.now() + timedelta(days=32)).strftime('%Y') if str(datetime.now().month) == '12' and str(matchDT[3:5]) == '01' else datetime.now().strftime('%Y') # Jahreswechsel berücksichtigen und ein Jahr weiter schalten
							dt_string = matchDT+str(dt_year)
							available = datetime(*(time.strptime(dt_string, '%d{0}%m{0}%Y'.format('.'))[0:6])) # 18.01.
							DATE_2 = available.strftime('%a{0} %d{0}%m{0}%Y').format('.')
							SORTDAY_2 = available.strftime('%Y{0}%m{0}%d').format('.')
							for av in (('Mon', translation(32201)), ('Tue', translation(32202)), ('Wed', translation(32203)), ('Thu', translation(32204)), ('Fri', translation(32205)), ('Sat', translation(32206)), ('Sun', translation(32207))):
								DATE_2 = DATE_2.replace(*av)
						MINS_2 = re.search('([0-9]+) Min.', TIME_2[0]) if TIME_2 else None # 90 Min.
						DURATION_2 = str(int(MINS_2.group(1)) * 60) if MINS_2 else None
						CAT_2 = re.compile(r'''<span class=["']text-row["']>([^<]+)</span>''', re.S).findall(matchONE)
						matchCG = CAT_2[0] if CAT_2 else None # D 2021 | Krimi
						plus_INFOS_2 = cleaning(CAT_2[0]) if CAT_2 else None # D 2021 | Krimi
						GENRE_2 = ' / '.join(sorted([tg for tg in GENCATEGORIES if tg.lower() in matchCG.lower()]))
					if DURATION_2 is None and DESC_2 == "": continue # Quelltextleichen ohne weiterführende Verbindung entfernen
					try: SECTOR_2 = re.findall(r'''<section class=["']cast(?: visible)?["'] id=["']inline-section_crew["'](.*?)</section>''', item, re.S)[0]
					except: SECTOR_2 = None
					if SECTOR_2:
						AGES_2 = re.compile(r'<dt>FSK:</dt>\s*<dd>([^<]+)</dd>', re.S).findall(SECTOR_2)
						MPAA_2 = cleaning(AGES_2[0]) if AGES_2 else None # <dd>ab 10 Jahren</dd>
						STEP_2 = re.compile(r'''class=["']headline["']>Cast & Crew:(.*?)</div>''', re.S).findall(SECTOR_2)
						matchTWO = cleaning(STEP_2[0]) if STEP_2 else None
						if matchTWO: # <dt class="role">Ellen Berlinger</dt> # <dd class="name">Heike Makatsch</dd>
							CAST_2 = re.compile(r'''<dt class=["']role["']>(.*?)</dt>\s*<dd class=["']name["']>(.*?)</dd>''', re.S).findall(matchTWO)
							for index, person in enumerate(CAST_2, 1):
								actor = {'name': cleaning(re.sub(r'\<.*?>', '', person[1])), 'role': cleaning(re.sub(r'\<.*?>', '', person[0])), 'order': index, 'thumb': ''}
								if actor['name'] not in ['' , None]:
									if KODI_ov20:
										CASTING_2.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
									else: CASTING_2.append(actor)
							DIR_2 = re.compile(r'<dt>Regie:</dt>\s*<dd>(.*?)</dd>', re.S).findall(matchTWO) # <dt>Regie:</dt> # <dd>Philipp Osthus, Andreas Menck, Florian Gottschick, Felix Ahrens</dd>
							DIRECTOR_2 = ', '.join([cleaning(re.sub(r'\<.*?>', '', dirpart.replace('\n', ' ').replace('\t', ' ').replace('  ', ''))) for dirpart in DIR_2]) if DIR_2 else []
					PLAY_2 = re.compile(r'''["']event_action["']:["']pageElement.clickExternal["'],["']event_label["']:["'](http[^"']+)["'],["']pageElementId["']:''', re.S).findall(item)
					PLAYLINK_2 = PLAY_2[0].replace('\/', '/') if PLAY_2 else None
					COMBI_THIRD.append([int(number), DESC_2, TAGLINE_2, WLINK_2, EPIS_2, DATE_2, SORTDAY_2, DURATION_2, plus_INFOS_2, GENRE_2, MPAA_2, CASTING_2, DIRECTOR_2, PLAYLINK_2])
	return COMBI_THIRD

def playCODE(SOURCE):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### SOURCE = {SOURCE} ###")
	FINAL_URL, LINK, CLEAR_TITLE, TVSHOW = (False for _ in range(4))
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == SOURCE:
				DIRECT = elem['direct']
				CLEAR_TITLE = re.sub('\[.*?\]', '', elem['name']) if elem.get('name', '') else False
				TVSHOW = elem['tvshow']
				STATION = elem['station']
				debug_MS(f"(navigator.playCODE) ### WORKFILE-Line : {str(elem)} ###")
	log("(navigator.playCODE) --- START WIEDERGABE ANFORDERUNG ---")
	log("(navigator.playCODE) frei")
	if CLEAR_TITLE and TVSHOW:
		if DIRECT is None:
			try:
				content = getUrl(SOURCE, 'LOAD')
				LINK = re.compile(r'''["']event_action["']:["']pageElement.clickExternal["'],["']event_label["']:["'](http[^"']+)["'],["']pageElementId["']:''', re.S).findall(content)[0].replace('\/', '/')
				log(f"(navigator.playCODE[1]) ~~~ AbspielLink-01 (Original) : {str(LINK)} ~~~")
			except:
				log("(navigator.playCODE[1]) MediathekLink-00 : MediathekLink der Sendung in TV-Spielfilm NICHT gefunden !!!")
				log("(navigator.playCODE[1]) --- ENDE WIEDERGABE ANFORDERUNG ---")
				return dialog.notification(translation(30521).format('LINK'), translation(30527), icon, 8000)
		else: 
			LINK = DIRECT
			log(f"(navigator.playCODE[1]) ~~~ AbspielLink-02 (Original) : {LINK} ~~~")
	log("(navigator.playCODE) frei")
	LINK = LINK.replace('http://', 'https://') if LINK and LINK[:7] == 'http://' else LINK
	if LINK and LINK.startswith('https://www.ardmediathek.de'):
		return ArdGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.arte.tv'):
		videoID = re.compile('arte.tv/de/videos/([^/]+?)/', re.S).findall(LINK)[0]
		FINAL_URL = f"plugin://plugin.video.tyl0re.arte/?mode=playVideo&url={videoID}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'ARTE.TV', 'ARTE.TV - Plugin')
	elif LINK and LINK.startswith('https://www.joyn.de'):
		return JoynGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.servustv.com'):
		videoID = LINK.split('/')[-2].replace('/', '').upper()
		FINAL_URL = f"plugin://plugin.video.servustv_com/?mode=playVideo&url={videoID}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'ServusTV.com', 'ServusTV - Plugin')
	elif LINK and LINK.startswith('https://tele5.de'): # Original: https://tele5.de/mediathek/william-shatners-the-captains-close-up/william-shatners-the-captains-close-up-scott-bakula
		# REQUEST: https://de-api.loma-cms.com/feloma/videos/william-shatners-the-captains-close-up-scott-bakula/?filter[show.slug]=william-shatners-the-captains-close-up&environment=tele5
		show, folge = LINK.split('mediathek/')[1].split('/')[0], LINK.split('/')[-1].replace('/', '')
		result = getUrl(f"https://de-api.loma-cms.com/feloma/videos/{folge}/?filter[show.slug]={show}&environment=tele5", REF=LINK)
		if result.get('blocks', '') and result.get('blocks', {})[0].get('videoId', '') and str(result['blocks'][0]['videoId']).isdigit():
			FINAL_URL = f"plugin://plugin.video.tele5_de/play/{result['blocks'][0]['videoId']}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'TELE 5 Mediathek', 'TELE 5 - Plugin')
	elif LINK and LINK.startswith('https://www.toggo.de'):
		return ToggoGetVideo(LINK)
	#elif LINK and LINK.startswith('https://plus.rtl.de'):
	#	return FINAL_URL
	elif LINK and LINK.startswith('https://www.welt.de'):
		return WeltGetVideo(LINK)
	elif LINK and LINK.startswith(('https://www.3sat.de', 'https://www.phoenix.de', 'https://www.zdf.de')):
		return ZdfGetVideo(LINK)
	else:
		failing(f"(navigator.playCODE[2]) AbspielLink-00 : Der Provider *{urlparse(LINK).netloc}* konnte nicht aufgelöst werden !!!")
		dialog.notification(translation(30521).format('LINK'), translation(30528).format(urlparse(LINK).netloc), icon, 8000)
		log("(navigator.playCODE[2]) --- ENDE WIEDERGABE ANFORDERUNG ---")

def addDir(name, image, params={}, plot=None, studio=None, folder=True):
	u = build_mass(params)
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setStudios([studio])
	else:
		liz.setInfo('Video', {'Title': name, 'Plot': plot, 'Studio': studio})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
