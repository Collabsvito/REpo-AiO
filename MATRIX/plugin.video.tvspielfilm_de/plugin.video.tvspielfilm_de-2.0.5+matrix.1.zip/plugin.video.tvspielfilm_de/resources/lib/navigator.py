﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
	from urlparse import urljoin, urlparse  # Python 2.X
else: 
	from urllib.parse import urljoin, urlparse, urlencode  # Python 3.X

from .common import *
from .resolver import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin('addon.openSettings({0})'.format(addon_id))

def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listLeftovers', 'url': BASE_URL+'/mediathek/'})
	addDir(translation(30602), icon, {'mode': 'listDates'})
	addDir(translation(30603), icon, {'mode': 'listChannels', 'url': BASE_URL+'/mediathek/nach-sender/'})
	addDir(translation(30604), icon, {'mode': 'listGenres', 'url': 'Spielfilm'})
	addDir(translation(30605), icon, {'mode': 'listGenres', 'url': 'Serie'})
	addDir(translation(30606), icon, {'mode': 'listGenres', 'url': 'Report'})
	addDir(translation(30607), icon, {'mode': 'listGenres', 'url': 'Unterhaltung'})
	addDir(translation(30608), icon, {'mode': 'listGenres', 'url': 'Kinder'})
	addDir(translation(30609), icon, {'mode': 'listGenres', 'url': 'Sport'})
	if enableADJUSTMENT:
		addDir(translation(30610), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30611), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listDates():
	i = -8
	while i <= 8:
		WU = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d') # Datum für URL
		WD = (datetime.now() - timedelta(days=i)).strftime('%d.%m') # Datum ohne Jahr, z.B. 15.08.
		WT = (datetime.now() - timedelta(days=i)).strftime('%w') # Wochentag als Zahlencode
		for tt in (('1', translation(32101)), ('2', translation(32102)), ('3', translation(32103)), ('4', translation(32104)), ('5', translation(32105)), ('6', translation(32106)), ('0', translation(32107))):
			WT = WT.replace(*tt)
		if i == 0: addDir(translation(32108).format(WT, WD), icon, {'mode': 'listLeftovers', 'url': BASE_URL+'/mediathek/nach-datum/?date='+WU})
		else: addDir(translation(32109).format(WT, WD), icon, {'mode': 'listLeftovers', 'url': BASE_URL+'/mediathek/nach-datum/?date='+WU})
		i += 1
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listChannels(url):
	debug_MS("(navigator.listChannels) -------------------------------------------------- START = listChannels --------------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listChannels) SENDER-SORTIERUNG : Alle Sender in TV-Spielfilm")
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listChannels) --- RTLPLUS (TVNOW) - Sender {0} ---".format(STATUS))
	content = getUrl(url, method='LOAD')
	results = re.findall(r'<section class="mediathek-channels">(.+?)</section>', content, re.S)[0]
	NaviItem = re.findall(r'<a title="([^"]+)" href="(https?://.*?mediathek/.*?)">', results, re.S)
	for TITLE, ULINK in NaviItem:
		channelID, name = cleanStation(TITLE)# SUPER RTL Mediathek
		if showARTE is False and name.upper() in ARTEEX: continue
		if showJOYN is False and name.upper() in JOYNEX: continue
		if showSERVUS is False and name.upper() in SERVUSEX: continue
		if showTELE is False and name.upper() in TELEEX: continue
		if showNOW is False and name.upper() in NOWEX: continue
		debug_MS("(navigator.listChannels) ##### NAME : {0} || LINK : {1} ##### ".format(name, ULINK))
		addDir(translation(30621).format(name), artpic+name.lower().replace(' ', '')+'.png', {'mode': 'listLeftovers', 'url': ULINK}, studio=name)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGenres(CAT):
	debug_MS("(navigator.listGenres) -------------------------------------------------- START = listGenres --------------------------------------------------")
	debug_MS("(navigator.listGenres) MEDIATHEK : {0}/mediathek/ - Genre = *{1}*".format(BASE_URL, CAT.upper()))
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listGenres) --- RTLPLUS (TVNOW) - Sender {0} ---".format(STATUS))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND = ([] for _ in range(3))
	counter = 0
	content = getUrl(BASE_URL+'/mediathek/', method='LOAD')
	results = re.findall(r'<span>'+CAT+'</span>(.+?)<div class="scroll-box">', content, re.S)
	for chtml in results:
		spl = chtml.split('<li>')
		for i in range(1,len(spl),1):
			entry = spl[i]
			debug_MS("(navigator.listGenres[1]) no.01 xxxxx ENTRY-01 : {0} xxxxx".format(str(entry)))
			TITLE_1 = ""
			all_TITLES = re.compile(r'<div class="text-holder">(.*?)</a>', re.S).findall(entry)[0]
			title = re.compile(r'<strong>(.*?)</strong>', re.S).findall(all_TITLES)
			subtitle = re.compile(r'<span>(.*?)</span>', re.S).findall(all_TITLES)
			reserve = re.compile(r'class="aholder" title="(.*?)">', re.S).findall(entry)
			if title and subtitle and reserve:
				FIRST, SECOND, THIRD = title[0].strip(), subtitle[0].strip(), reserve[0].strip()
				if FIRST.lower() == THIRD.lower(): TITLE_1 = cleaning(THIRD)
				elif ('...' in FIRST and not '...' in SECOND):
					TITLE_1 = cleaning(THIRD.replace(SECOND, ""))+" - "+cleaning(SECOND)
				elif ('...' in FIRST and '...' in SECOND):
					TITLE_1 = cleaning(FIRST)
				else:
					checking = FIRST.lower()+' '+SECOND.lower()
					TITLE_1 = cleaning(FIRST) if checking == THIRD.lower() else cleaning(FIRST)+" - "+cleaning(THIRD.replace(FIRST, ""))
			elif title and subtitle and not reserve:
				FIRST, SECOND = title[0].strip(), subtitle[0].strip()
				TITLE_1 = cleaning(FIRST) if FIRST.lower() == SECOND.lower() else cleaning(FIRST)+" - "+cleaning(SECOND.replace(FIRST, ""))
			else: TITLE_1 = cleaning(title[0])
			DATE_1 = re.compile(r'<div class="col">(.*?)</div>', re.S).findall(entry)[0].strip()
			all_CHANNELS = re.compile(r'<span class="logotype">(.*?)</span>', re.S).findall(entry)[0]
			channel = re.compile(r'title="(.*?)" loading=', re.S).findall(all_CHANNELS)[0]
			CHANNEL_1, STUDIO_1 = cleanStation(channel)
			WLINK_1 = re.compile(r'<a href="(https?://.*?mediathek/.*?)"', re.S).findall(entry)[0]
			img = re.compile(r'src="(https://a2.tvspielfilm.de/imedia/.*?.jpg)"', re.S).findall(entry)
			THUMB_1 = img[0] if img else ""
			# 964 x 510 px = ,kpQ8aJYzw6ynhaO4Y2_vH8a7z2Do1GgrS8XBm_WNST4qVJPG6q9MH034hLE201uS129d8PUi_w_DKV5EjyOMMA==.jpg || 1280 x 720 px = ,dim:1280x720,mode:exact,center:640x254,thumb:1.jpg
			THUMB_1 = THUMB_1.split(',')[0].rstrip()+',dim:1280x720,mode:exact,center:640x360,thumb:1.jpg' if ',' in THUMB_1 else THUMB_1
			if showARTE is False and STUDIO_1.upper() in ARTEEX: continue
			if showJOYN is False and STUDIO_1.upper() in JOYNEX: continue
			if showSERVUS is False and STUDIO_1.upper() in SERVUSEX: continue
			if showTELE is False and STUDIO_1.upper() in TELEEX: continue
			if showNOW is False and STUDIO_1.upper() in NOWEX: continue
			counter += 1
			COMBI_FIRST.append([int(counter), TITLE_1, THUMB_1, WLINK_1, DATE_1, STUDIO_1, CHANNEL_1])
			COMBI_LINKS.append([int(counter), WLINK_1])
	if COMBI_FIRST:
		COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_SECOND or (not COMBI_SECOND and COMBI_FIRST):
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_SECOND if a[3] == b[4]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		RESULT += [c for c in COMBI_FIRST if all(d[4] != c[3] for d in COMBI_SECOND)] # Der übriggebliebene Rest von Liste1 - wenn die ID nicht in der Liste2 vorkommt !!!
		#log("++++++++++++++++++++++++")
		#log("(navigator.listGenres[3]) no.03 XXXXX RESULT-03 : {0} XXXXX".format(str(RESULT)))
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda k: int(k[0]), reverse=False): # 0-6 = Liste1 || 7-13 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS("(navigator.listGenres[3]) no.03 ### Anzahl = {0} || Eintrag : {1} ###".format(str(len(da)), str(da)))
			Note_1, Note_2 = ("" for _ in range(2))
			if len(da) > 7: ### Liste2 beginnt mit Nummer:07 ###
				name, photo, link1, added1, studio, CHID_1 = da[1], da[2], da[3], da[4], da[5], da[6]
				DESC_2, tagline, genre, duration, link2, added2, play_LINK = da[7], da[8], da[9], da[10], da[11], da[12], da[13]
			else:
				name, photo, link1, added1, studio, CHID_1 = da[1], da[2], da[3], da[4], da[5], da[6]
				DESC_2, tagline, genre, duration, link2, added2, play_LINK = "", None, None, None, "", "", None
			if added1 != "" or added2 != "":
				Note_1 = translation(30622).format(str(added2)) if added2 != "" else translation(30622).format(str(added1))
				if showDATE:
					name = added1+"  "+name if added1 != "" else added2[3:9]+"  "+name
			if studio != "":
				Note_2 = translation(30623).format(studio) if DESC_2 != "" else translation(30624).format(studio)
			if showCHANNEL and CHID_1 != "":
				name += CHID_1.replace('ServusTV Deutschland', 'ServusTV').replace('TOGGO plus', 'TOGGO')
			plot = Note_1+DESC_2+Note_2
			debug_MS("(navigator.listGenres[4]) no.04 ##### TITLE : {0} || DATE : {1} || THUMB : {2} #####".format(str(name), Note_1, photo))
			debug_MS("(navigator.listGenres[4]) no.04 ##### OR-LINK : {0} || VIDEO : {1} || STUDIO : {2} #####".format(link1, play_LINK, studio))
			addLink(name, photo, {'mode': 'playVideo', 'url': link1, 'extras': play_LINK}, plot, tagline, duration, genre, studio)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listLeftovers(url):
	debug_MS("(navigator.listLeftovers) -------------------------------------------------- START = listLeftovers --------------------------------------------------")
	debug_MS("(navigator.listLeftovers) MEDIATHEK : {0}".format(url))
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listLeftovers) --- RTLPLUS (TVNOW) - Sender {0} ---".format(STATUS))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND = ([] for _ in range(3))
	counter = 0
	content = getUrl(url, method='LOAD')
	if '?date=' in url or 'nach-sender' in url:
		results = re.findall(r'<section class="teaser-section">(.+?)</section>', content, re.S)
	else:
		results = re.findall(r'<p class="h2nav">MEDIATHEKEN</p>(.+?)<div class="navigation-display-cell has-dropdown', content, re.S)
	for chtml in results:
		spl = chtml.split('<div class="content-teaser')
		for i in range(1,len(spl),1):
			entry = spl[i]
			debug_MS("(navigator.listLeftovers[1]) no.01 xxxxx ENTRY-01 : {0} xxxxx".format(str(entry)))
			title = re.compile(r'<span class="headline">(.*?)</span>', re.S).findall(entry)
			subtitle = re.compile(r'target="_self" title="(.*?)"', re.S).findall(entry)
			special= re.compile(r'<span class="subline.+?>(.*?)</span>', re.S).findall(entry)
			added = ""
			if (title and subtitle and not special):
				FIRST, SECOND = title[0].replace('…', '').replace('...', '').strip(), subtitle[0].replace('…', '').replace('...', '').strip()
				TITLE_1 = cleaning(FIRST) if FIRST == SECOND else cleaning(FIRST)+" - "+cleaning(SECOND.replace(FIRST, ""))
				channel = url.split('sender/')[1].replace('/', '').strip()
			elif (title and not subtitle and special):
				TITLE_1 = cleaning(title[0])+" - "+cleaning(special[0].split('|')[-1])
				DATE_1 = special[0].split('|')[0].strip()
				channel = cleaning(special[0].split('|')[1])
			elif (title and subtitle and special):
				FIRST, SECOND = title[0].replace('…', '').replace('...', '').strip(), subtitle[0].replace('…', '').replace('...', '').strip()
				if FIRST == SECOND: TITLE_1 = cleaning(FIRST)
				else:
					test_SUB = cleaning(SECOND.replace(FIRST, ""))
					TITLE_1 = cleaning(FIRST) if test_SUB == "" else cleaning(FIRST)+" - "+test_SUB
				DATE_1 = special[0].split('|')[0].strip()
				channel = cleaning(special[0].split('|')[1])
			CHANNEL_1, STUDIO_1 = cleanStation(channel)
			WLINK_1 = re.compile(r'<a href="(https?://.*?mediathek/.*?)"', re.S).findall(entry)[0]
			img = re.compile(r'src="(https://a2.tvspielfilm.de/imedia/.*?.jpg)"', re.S).findall(entry)
			THUMB_1 = img[0] if img else ""
			# 964 x 510 px = ,kpQ8aJYzw6ynhaO4Y2_vH8a7z2Do1GgrS8XBm_WNST4qVJPG6q9MH034hLE201uS129d8PUi_w_DKV5EjyOMMA==.jpg || 1280 x 720 px = ,dim:1280x720,mode:exact,center:640x254,thumb:1.jpg
			THUMB_1 = THUMB_1.split(',')[0].rstrip()+',dim:1280x720,mode:exact,center:640x360,thumb:1.jpg' if ',' in THUMB_1 else THUMB_1
			if showARTE is False and STUDIO_1.upper() in ARTEEX: continue
			if showJOYN is False and STUDIO_1.upper() in JOYNEX: continue
			if showSERVUS is False and STUDIO_1.upper() in SERVUSEX: continue
			if showTELE is False and STUDIO_1.upper() in TELEEX: continue
			if showNOW is False and STUDIO_1.upper() in NOWEX: continue
			counter += 1
			COMBI_FIRST.append([int(counter), TITLE_1, THUMB_1, WLINK_1, DATE_1, STUDIO_1, CHANNEL_1])
			COMBI_LINKS.append([int(counter), WLINK_1])
	if COMBI_FIRST:
		COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_SECOND or (not COMBI_SECOND and COMBI_FIRST):
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_SECOND if a[3] == b[4]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		RESULT += [c for c in COMBI_FIRST if all(d[4] != c[3] for d in COMBI_SECOND)] # Der übriggebliebene Rest von Liste1 - wenn die ID nicht in der Liste2 vorkommt !!!
		#log("++++++++++++++++++++++++")
		#log("(navigator.listLeftovers[3]) no.03 XXXXX RESULT-03 : {0} XXXXX".format(str(RESULT)))
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda k: int(k[0]), reverse=False): # 0-6 = Liste1 || 7-13 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS("(navigator.listLeftovers[3]) no.03 ### Anzahl = {0} || Eintrag : {1} ###".format(str(len(da)), str(da)))
			Note_1, Note_2 = ("" for _ in range(2))
			if len(da) > 7: ### Liste2 beginnt mit Nummer:07 ###
				name, photo, link1, added1, studio, CHID_1 = da[1], da[2], da[3], da[4], da[5], da[6]
				DESC_2, tagline, genre, duration, link2, added2, play_LINK = da[7], da[8], da[9], da[10], da[11], da[12], da[13]
			else:
				name, photo, link1, added1, studio, CHID_1 = da[1], da[2], da[3], da[4], da[5], da[6]
				DESC_2, tagline, genre, duration, link2, added2, play_LINK = "", None, None, None, "", "", None
			if added1 != "" or added2 != "":
				Note_1 = translation(30622).format(str(added2)) if added2 != "" else translation(30622).format(str(added1))
				if showDATE:
					name = added1+"  "+name if added1 != "" else added2[3:9]+"  "+name
			if studio != "":
				Note_2 = translation(30623).format(studio) if DESC_2 != "" else translation(30624).format(studio)
			if showCHANNEL and CHID_1 != "":
				name += CHID_1.replace('ServusTV Deutschland', 'ServusTV').replace('TOGGO plus', 'TOGGO')
			plot = Note_1+DESC_2+Note_2
			debug_MS("(navigator.listLeftovers[4]) no.04 ##### TITLE : {0} || DATE : {1} || THUMB : {2} #####".format(str(name), Note_1, photo))
			debug_MS("(navigator.listLeftovers[4]) no.04 ##### OR-LINK : {0} || VIDEO : {1} || STUDIO : {2} #####".format(link1, play_LINK, studio))
			addLink(name, photo, {'mode': 'playVideo', 'url': link1, 'extras': play_LINK}, plot, tagline, duration, genre, studio)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSubstances(MURLS):
	debug_MS("(navigator.listSubstances) -------------------------------------------------- START = listSubstances --------------------------------------------------")
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	GENCATEGORIES = ['Abenteuer', 'Action', 'Animation', 'Anwalt', 'Bericht', 'Boxen', 'Casting', 'Comedy', 'Diskussion', 'Doku', 'Drama', 'Eishockey', 'Eiskunstlauf', 'Familie', 'Fantasy', 'Freizeit',\
										'Fußball', 'Gala', 'Groteske', 'Handball', 'Heimat', 'Kabarett', 'Kinder', 'Kochduell', 'Komödie', 'Konzert', 'Krankenhaus', 'Krimi', 'Märchen', 'Magazin', 'Melodram', 'Motorrad',\
										'Musik', 'Mystery', 'Natur', 'Polizei', 'Porträt', 'Psychodrama', 'Quiz', 'Ratgeber', 'Reality', 'Reportage', 'Roadmovie', 'Romanze', 'Satire', 'Sci-Fi', 'Show', 'Sitcom', 'Soap',\
										'Sondersendung', 'Sport', 'Talk', 'Theater', 'Tragikomödie', 'Tragödie', 'Thriller', 'Umwelt', 'Verbraucher', 'Vorschulreihe', 'Western', 'Wetter', 'Wissen', 'Zeichentrick']
	if COMBI_DETAILS:
		#log("++++++++++++++++++++++++")
		#log("(navigator.llistSubstances[2]) no.02 XXXXX CONTENT-02 : {0} XXXXX".format(str(COMBI_DETAILS)))
		#log("++++++++++++++++++++++++")
		for num, WLINK_2, elem in COMBI_DETAILS:
			if elem is not None:
				DESC_2, DATE_2 = ("" for _ in range(2))
				TAGLINE_2, GENRE_2, DURATION_2, PLAYLINK_2 = (None for _ in range(4))
				debug_MS("(navigator.listSubstances[2]) no.02 xxxxx ELEM-02 : {0} xxxxx".format(str(elem)))
				details = re.findall(r'<article class="broadcast-detail mediathek-detail"(.*?)</article>', elem, re.S)
				for item in details:
					TEASER = re.findall(r'<section class="broadcast-detail__description"(.*?)</section>', item, re.S)[0]
					TAG_2 = re.compile(r'<h3 class="headline">([^<]+)</h3>', re.S).findall(TEASER)
					STORY_2 = re.compile(r'<p[^>]*>(.*?)</p>', re.S).findall(TEASER)
					if STORY_2:
						DESC_2 = '[CR][CR]'.join([cleaning(re.sub(' +', ' ',(teapart.replace('\n',' ').replace('\t',' ')))).strip() for teapart in STORY_2])
						DESC_2 = DESC_2.rstrip()[:-4] if DESC_2.endswith('[CR]') else DESC_2
					TAGLINE_2 = cleaning(TAG_2[0]).replace('\n',' ').replace('\t',' ') if TAG_2 else None
					if TAGLINE_2 and len(TAGLINE_2) > 125:
						TAGLINE_2 = TAGLINE_2[:125]+'...'
					CON_2 = re.compile(r'</span><span class="text-row">([^<]+)</span>', re.S).findall(item)
					matchGM = py2_enc(CON_2[0]) if CON_2 else None # Romanze, D/A 2017, 88 min
					if matchGM:
						GENRE_2 = ' / '.join(sorted([tg for tg in GENCATEGORIES if tg.lower() in matchGM.lower()]))
						MINS_2 = re.search(',\ (\d+)\ min', matchGM)
						DURATION_2 = str(int(MINS_2.group(1)) * 60) if MINS_2 else None
					TIME_2 = re.compile(r'</span><span class="time"></span>([^<]+)</?span', re.S).findall(item)
					matchDT = py2_enc(TIME_2[0]).split(',&nbsp;') if TIME_2 else None # Mo 21.03.,&nbsp;12:30,&nbsp;MDR
					if matchDT and len(matchDT) > 2: DATE_2 = '{0} {1} {2} Uhr'.format(matchDT[0], '*', matchDT[1])
					PLAY_2 = re.compile(r'<div class="mediatheken-partner">\s*<a href="([^"]+)" target="_blank" class="js-track-link"', re.S).findall(item)
					PLAYLINK_2 = PLAY_2[0] if PLAY_2 else None
					COMBI_THIRD.append([DESC_2, TAGLINE_2, GENRE_2, DURATION_2, WLINK_2, DATE_2, PLAYLINK_2])
	return COMBI_THIRD

def playVideo(url, EXTRA):
	log("(navigator.playVideo) --- START WIEDERGABE ANFORDERUNG ---")
	log("(navigator.playVideo) frei")
	finalURL, LINK = (False for _ in range(2))
	if EXTRA is None:
		try:
			content = getUrl(url, method='LOAD')
			LINK = re.compile(r'<div class="mediatheken-partner">\s*<a href="([^"]+)" target="_blank" class="js-track-link"', re.S).findall(content)[0]
			log("(navigator.playVideo[1]) no.01 ~~~ AbspielLink (Original) : {0} ~~~".format(LINK))
		except:
			log("(navigator.playVideo[1]) MediathekLink-00 : MediathekLink der Sendung in TV-Spielfilm NICHT gefunden !!!")
			log("(navigator.playVideo[1]) --- ENDE WIEDERGABE ANFORDERUNG ---")
			return dialog.notification(translation(30521).format('LINK'), translation(30525), icon, 8000)
	else: 
		LINK = EXTRA
		log("(navigator.playVideo[2]) no.02 ~~~ AbspielLink (Original) : {0} ~~~".format(LINK))
	log("(navigator.playVideo) frei")
	LINK = LINK.replace('http://', 'https://') if LINK and LINK[:7] == 'http://' else LINK
	if LINK and LINK.startswith('https://www.ardmediathek.de'):
		return ArdGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.arte.tv'):
		videoID = re.compile('arte.tv/de/videos/([^/]+?)/', re.S).findall(LINK)[0]
		finalURL = '{0}?mode=playVideo&url={1}'.format('plugin://plugin.video.tyl0re.arte/', str(videoID))
		return playRESOLVED(finalURL, 'TRANSMIT', 'ARTE.TV', 'ARTE.TV - Plugin')
	elif LINK and LINK.startswith(('https://www.3sat.de', 'https://www.phoenix.de', 'https://www.zdf.de')):
		videoURL = LINK[:LINK.find('.html')]+'.html'
		return ZdfGetVideo(videoURL)
	elif LINK and LINK.startswith(('https://www.nowtv.de', 'https://www.tvnow.de')):
		return RtlGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.servustv.com'):
		videoID = LINK.split('/')[-2].replace('/', '').upper()
		finalURL = '{0}?mode=playVideo&url={1}'.format('plugin://plugin.video.servustv_com/', str(videoID))
		return playRESOLVED(finalURL, 'TRANSMIT', 'ServusTV.com', 'ServusTV - Plugin')
	elif LINK and LINK.startswith('https://tele5.de'):
		videoURL = getUrl(LINK, method='LOAD')
		videoID = re.compile(r'playertype="videoPlayer"\s+assetid="([^"]+)"', re.S).findall(videoURL)
		finalURL = '{0}play/{1}'.format('plugin://plugin.video.tele5_de/', str(videoID[0])) if videoID else False
		return playRESOLVED(finalURL, 'TRANSMIT', 'TELE 5 Mediathek', 'TELE 5 - Plugin')
	elif LINK and LINK.startswith('https://www.toggo.de'):
		return ToggoGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.welt.de'):
		return WeltGetVideo(LINK)
	else:
		failing("(navigator.playVideo[3]) AbspielLink-00 : Der Provider *{0}* konnte nicht aufgelöst werden !!!".format(urlparse(LINK).netloc))
		dialog.notification(translation(30521).format('LINK'), translation(30526).format(urlparse(LINK).netloc), icon, 8000)
		log("(navigator.playVideo[3]) --- ENDE WIEDERGABE ANFORDERUNG ---")

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, studio=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot), videoInfoTag.setStudios([studio])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': studio})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, tagline=None, duration=None, genre=None, studio=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name)
		videoInfoTag.setTagLine(tagline)
		videoInfoTag.setPlot(plot)
		if duration: videoInfoTag.setDuration(int(duration))
		videoInfoTag.setGenres([genre])
		videoInfoTag.setStudios([studio])
		videoInfoTag.setMediaType('movie')
	else:
		info = {}
		info['Title'] = name
		info['Tagline'] = tagline
		info['Plot'] = plot
		if duration: info['Duration'] = duration
		info['Genre'] = [genre]
		info['Studio'] = [studio]
		info['Mediatype'] = 'movie'
		liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, 'mode=AddToQueue'))])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
