﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
from urllib.parse import urlparse, urlencode

from .common import *
from .resolver import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin('Addon.OpenSettings({})'.format(addon_id))

def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listLeftovers', 'url': BASE_URL+'/mediathek/'})
	addDir(translation(30602), icon, {'mode': 'listDates'})
	addDir(translation(30603), icon, {'mode': 'listChannels', 'url': BASE_URL+'/mediathek/nach-sender/'})
	addDir(translation(30604), icon, {'mode': 'listGenres', 'url': BASE_URL+'/mediathek/spielfilme/'})
	addDir(translation(30605), icon, {'mode': 'listGenres', 'url': BASE_URL+'/mediathek/serien/'})
	addDir(translation(30606), icon, {'mode': 'listGenres', 'url': BASE_URL+'/mediathek/dokus/'})
	addDir(translation(30607), icon, {'mode': 'listGenres', 'url': BASE_URL+'/mediathek/comedy/'})
	addDir(translation(30608), icon, {'mode': 'listGenres', 'url': BASE_URL+'/mediathek/kinder/'})
	addDir(translation(30609), icon, {'mode': 'listGenres', 'url': BASE_URL+'/mediathek/sport/'})
	if enableADJUSTMENT:
		addDir(translation(30610), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30611), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listDates():
	i = -8
	while i <= 8:
		WU = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d') # Datum für URL
		WD = (datetime.now() - timedelta(days=i)).strftime('%d.%m.') # Datum ohne Jahr, z.B. 15.08.
		WT = (datetime.now() - timedelta(days=i)).strftime('%w') # Wochentag als Zahlencode
		for tt in (('1', translation(32101)), ('2', translation(32102)), ('3', translation(32103)), ('4', translation(32104)), ('5', translation(32105)), ('6', translation(32106)), ('0', translation(32107))):
			WT = WT.replace(*tt)
		if i == 0: addDir(translation(32108).format(WT, WD), icon, {'mode': 'listLeftovers', 'url': BASE_URL+'/mediathek/nach-datum/?date='+WU})
		else: addDir(translation(32109).format(WT, WD), icon, {'mode': 'listLeftovers', 'url': BASE_URL+'/mediathek/nach-datum/?date='+WU})
		i += 1
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listChannels(url):
	debug_MS("(navigator.listChannels) -------------------------------------------------- START = listChannels --------------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listChannels) SENDER-SORTIERUNG : Alle Sender in TV-Spielfilm")
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listChannels) --- RTLPLUS (TVNOW) - Sender {0} ---".format(STATUS))
	content = getUrl(url, method='LOAD')
	results = re.findall(r'<section class="mediathek-channels">(.+?)</section>', content, re.S)[0]
	NaviItem = re.findall(r'<a title="([^"]+)" href="(https?://.*?mediathek/.*?)">', results, re.S)
	for TITLE, ULINK in NaviItem:
		channelID, name = cleanStation(TITLE)# SUPER RTL Mediathek
		if showARTE is False and name.upper() in ARTEEX: continue
		if showJOYN is False and name.upper() in JOYNEX: continue
		if showSERVUS is False and name.upper() in SERVUSEX: continue
		if showTELE is False and name.upper() in TELEEX: continue
		if showNOW is False and name.upper() in NOWEX: continue
		debug_MS("(navigator.listChannels) ##### NAME : {0} || LINK : {1} ##### ".format(name, ULINK))
		addDir(translation(30621).format(name), artpic+name.lower().replace(' ', '')+'.png', {'mode': 'listLeftovers', 'url': ULINK}, studio=name)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGenres(url):
	debug_MS("(navigator.listGenres) -------------------------------------------------- START = listGenres --------------------------------------------------")
	debug_MS("(navigator.listGenres) MEDIATHEK : {0}".format(url))
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listGenres) --- RTLPLUS (TVNOW) - Sender {0} ---".format(STATUS))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND = ([] for _ in range(3))
	counter = 0
	pageNUMBER = 1
	foundMORE = True
	while foundMORE is True:
		newURL = url+'?page='+str(pageNUMBER) if pageNUMBER > 1 else url
		content = getUrl(newURL, method='LOAD')
		results = re.findall(r'<div id="mediacenter-genre-container">(.+?)</section>', content, re.S)
		for chtml in results:
			spl = chtml.split('tips-teaser js-track-link')
			for i in range(1,len(spl),1):
				entry = spl[i]
				debug_MS("(navigator.listGenres[1]) no.01 xxxxx ENTRY-01 : {0} xxxxx".format(str(entry)))
				title = re.compile(r'class="tips-teaser__bottom__title".+?>([^<]+)</span>', re.S).findall(entry)
				reserve = re.compile(r' title="([^"]+)"', re.S).findall(entry)
				TITLE_1 = cleaning(title[0])
				if title and reserve:
					FIRST, SECOND = title[0].strip(), reserve[0].strip()
					checking = cleaning(SECOND.replace(FIRST, ''))
					TITLE_1 = cleaning(FIRST) if checking == "" else cleaning(FIRST)+" - "+checking
				matchCOU = re.compile(r'class="detail-info">([^<]+)</span>', re.S).findall(entry)
				COUNTRY_1 = cleaning(matchCOU[0].split('|')[0]) if matchCOU else None # D/L 2019 | 86 Min.
				matchGEN = re.compile(r'class="tips-teaser__category">([^<]+)</span>', re.S).findall(entry)
				GENRE_1 = cleaning(matchGEN[0]) if matchGEN else None # Mysteryabenteuer
				plus_INFOS_1 = COUNTRY_1+' | '+GENRE_1 if COUNTRY_1 and GENRE_1 else None # D 2021 | Krimi
				matchDAT = re.compile(r'Ausstrahlung:\ ([^<]+)</span>', re.S).findall(entry) # TV-Ausstrahlung: 11.02.2023
				DATE_1 = matchDAT[0][:10] if matchDAT and str(matchDAT[0])[:10].replace('.', '').replace('-', '').replace(' ', '').isdigit() else ""
				all_CHANNELS = re.compile(r'<div class="channel-logo">(.*?)</div>', re.S).findall(entry)[0]
				matchCHA = re.compile(r'title="(.*?)" loading=', re.S).findall(all_CHANNELS)[0]
				CHANNEL_1, STUDIO_1 = cleanStation(matchCHA)
				# "event_label":"https:\/\/www.tvspielfilm.de\/mediathek\/mein-suesses-geheimnis,11656496.html",
				WLINK_1 = re.compile(r'"event_label":"(https:\\/\\/www.tvspielfilm.de\\/mediathek.*?)",', re.S).findall(entry)[0].replace('\/', '/')
				# background-image: url(https://a2.tvspielfilm.de/imedia/6497/11656497,90MM4fb1lM5CH2xWrBdX9v6xyeSi9rNjaYADQTtlRc9Gfv8LF5v0XYqYLNQ23z9MmsTDWuaKC2MoP7h8BkmJuA==.jpg);"
				img = re.compile(r'background-image: url\((https://a2.tvspielfilm.de/imedia/.*?.jpg)\)', re.S).findall(entry)
				# 964 x 510 px = ,kpQ8aJYzw6ynhaO4Y2_vH8a7z2Do1GgrS8XBm_WNST4qVJPG6q9MH034hLE201uS129d8PUi_w_DKV5EjyOMMA==.jpg || 1280 x 720 px = ,dim:1280x720,mode:exact,center:640x254,thumb:1.jpg
				THUMB_1 = img[0].split(',')[0].rstrip()+',thumb:1.jpg' if img and ',' in img[0] else img[0] if img else ""
				if showARTE is False and STUDIO_1.upper() in ARTEEX: continue
				if showJOYN is False and STUDIO_1.upper() in JOYNEX: continue
				if showSERVUS is False and STUDIO_1.upper() in SERVUSEX: continue
				if showTELE is False and STUDIO_1.upper() in TELEEX: continue
				if showNOW is False and STUDIO_1.upper() in NOWEX: continue
				counter += 1
				COMBI_FIRST.append([int(counter), TITLE_1, THUMB_1, WLINK_1, DATE_1, plus_INFOS_1, STUDIO_1, CHANNEL_1])
				COMBI_LINKS.append([int(counter), WLINK_1])
		searchMORE = re.compile(r'<a href="([^"]+)" class="load-more" id="mediacenter-genre-load-more"', re.S).findall(content)
		if searchMORE:
			nextPAGE = BASE_URL+searchMORE[0] if searchMORE[0][:4] != 'http' else searchMORE[0]
			debug_MS("(navigator.listGenres[2]) PAGES ### NOW GET NEXTPAGE : {0} ###".format(nextPAGE))
			pageNUMBER += 1
		else: foundMORE = False
	if COMBI_FIRST:
		COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_SECOND or (not COMBI_SECOND and COMBI_FIRST):
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_SECOND if a[3] == b[3]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		RESULT += [c for c in COMBI_FIRST if all(d[3] != c[3] for d in COMBI_SECOND)] # Der übriggebliebene Rest von Liste1 - wenn die ID nicht in der Liste2 vorkommt !!!
		#log("++++++++++++++++++++++++")
		#log("(navigator.listGenres[3]) no.03 XXXXX RESULT-03 : {0} XXXXX".format(str(RESULT)))
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda k: int(k[0]), reverse=False): # 0-7 = Liste1 || 8-18 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS("(navigator.listGenres[3]) no.03 ### Anzahl = {0} || Eintrag : {1} ###".format(str(len(da)), str(da)))
			Note_1, Note_2, Note_3 = ("" for _ in range(3))
			if len(da) > 8: ### Liste2 beginnt mit Nummer:08 ###
				name, photo, link1, added1, YearGenre1, studio, ChannelID = da[1], da[2], da[3], da[4], da[5], da[6], da[7]
				DESC_2, tagline, SerieEpis, link2, added2, duration, YearGenre2, genre, cast, director, play_LINK = da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18]
			else:
				name, photo, link1, added1, YearGenre1, studio, ChannelID = da[1], da[2], da[3], da[4], da[5], da[6], da[7]
				DESC_2, tagline, SerieEpis, link2, added2, duration, YearGenre2, genre, cast, director, play_LINK = "", None, None, "", "", None, None, None, [], "", None
			if SerieEpis:
				Note_1 = translation(30622).format(str(SerieEpis))
			if added1 != "" or added2 != "":
				Note_2 = translation(30623).format(str(added2)) if added2 != "" else translation(30623).format(str(added1))
				if showDATE:
					name = added1[0:6]+"  "+name if added1 != "" else added2[4:10]+"  "+name # added1 = 11.02.2023 || added2 = Sa. 11.02.2023 || ergebnis = 11.02.
			if YearGenre1 or YearGenre2:
				name += ' - '+YearGenre1 if YearGenre1 else ' - '+YearGenre2
			if studio != "":
				Note_3 = translation(30624).format(studio) if DESC_2 != "" else translation(30625).format(studio)
			if showCHANNEL and ChannelID != "":
				name += ChannelID.replace('ServusTV Deutschland', 'ServusTV').replace('TOGGO plus', 'TOGGO')
			plot = Note_1+Note_2+DESC_2+Note_3
			debug_MS("(navigator.listGenres[4]) no.04 ##### TITLE : {0} || EPISODE : {1} || THUMB : {2} #####".format(str(name), Note_1, photo))
			debug_MS("(navigator.listGenres[4]) no.04 ##### OR-LINK : {0} || VIDEO : {1} || STUDIO : {2} #####".format(link1, play_LINK, studio))
			addLink(name, photo, {'mode': 'playVideo', 'url': link1, 'extras': play_LINK}, plot, tagline, duration, genre, director, cast, studio)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listLeftovers(url):
	debug_MS("(navigator.listLeftovers) -------------------------------------------------- START = listLeftovers --------------------------------------------------")
	debug_MS("(navigator.listLeftovers) MEDIATHEK : {0}".format(url))
	STATUS = 'EINGEBLENDET' if showNOW is True else 'AUSGEBLENDET'
	debug_MS("(navigator.listLeftovers) --- RTLPLUS (TVNOW) - Sender {0} ---".format(STATUS))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND = ([] for _ in range(3))
	counter = 0
	content = getUrl(url, method='LOAD')
	if '?date=' in url or 'nach-sender' in url:
		results = re.findall(r'<section class="teaser-section">(.+?)</section>', content, re.S)
	else:
		results = re.findall(r'<p class="h2nav">MEDIATHEKEN</p>(.+?)<div class="navigation-display-cell has-dropdown', content, re.S)
	for chtml in results:
		spl = chtml.split('<div class="content-teaser')
		for i in range(1,len(spl),1):
			entry = spl[i]
			debug_MS("(navigator.listLeftovers[1]) no.01 xxxxx ENTRY-01 : {0} xxxxx".format(str(entry)))
			all_TITLES = re.compile(r'<div class="text-holder">(.*?)</a>', re.S).findall(entry)[0]
			title = re.compile(r'<span class="headline">(.*?)</span>', re.S).findall(all_TITLES)
			subtitle = re.compile(r'<span class="subline.+?>(.*?)</span>', re.S).findall(all_TITLES)
			reserve = re.compile(r'target="_self" title="(.*?)"', re.S).findall(entry)
			DATE_1 = ""
			if '?date=' in url and title and subtitle:
				DEFAULT = subtitle[0].split('|')[0].strip()
				WANTED = url.split('?date=')[1][8:10]+'.'+url.split('?date=')[1][5:7]+'.'
				NAME = cleaning(title[0])
				#log("(navigator.listLeftovers[2]) FilterDate ### DEFAULT : {0} || WANTED : {1} || NAME : {2} ###".format(DEFAULT, WANTED, NAME))
				if DEFAULT != WANTED: continue
			if title and subtitle and reserve:
				FIRST, SECOND, THIRD = title[0].strip(), subtitle[0].strip(), reserve[0].strip()
				checking = cleaning(THIRD.replace(FIRST, ''))
				TITLE_1 = cleaning(FIRST) if checking == "" else cleaning(FIRST)+" - "+checking
				DATE_1 = SECOND.split('|')[0].strip()
				channel = cleaning(SECOND.split('|')[1])
			elif title and subtitle and not reserve:
				FIRST, SECOND = title[0].strip(), subtitle[0].strip()
				TITLE_1 = cleaning(FIRST)+" - "+cleaning(SECOND.split('|')[-1])
				DATE_1 = SECOND.split('|')[0].strip()
				channel = cleaning(SECOND.split('|')[1])
			else:
				FIRST, THIRD = title[0].strip(), reserve[0].strip()
				TITLE_1 = cleaning(FIRST) if FIRST == THIRD else cleaning(FIRST)+" - "+cleaning(THIRD.replace(FIRST, ''))
				channel = url.split('sender/')[1].replace('/', '').strip()
			CHANNEL_1, STUDIO_1 = cleanStation(channel)
			WLINK_1 = re.compile(r'<a href="(https?://.*?mediathek/.*?)"', re.S).findall(entry)[0]
			img = re.compile(r'src="(https://a2.tvspielfilm.de/imedia/.*?.jpg)"', re.S).findall(entry)
			# 964 x 510 px = ,kpQ8aJYzw6ynhaO4Y2_vH8a7z2Do1GgrS8XBm_WNST4qVJPG6q9MH034hLE201uS129d8PUi_w_DKV5EjyOMMA==.jpg || 1280 x 720 px = ,dim:1280x720,mode:exact,center:640x254,thumb:1.jpg
			THUMB_1 = img[0].split(',')[0].rstrip()+',thumb:1.jpg' if img and ',' in img[0] else img[0] if img else ""
			if showARTE is False and STUDIO_1.upper() in ARTEEX: continue
			if showJOYN is False and STUDIO_1.upper() in JOYNEX: continue
			if showSERVUS is False and STUDIO_1.upper() in SERVUSEX: continue
			if showTELE is False and STUDIO_1.upper() in TELEEX: continue
			if showNOW is False and STUDIO_1.upper() in NOWEX: continue
			counter += 1
			COMBI_FIRST.append([int(counter), TITLE_1, THUMB_1, WLINK_1, DATE_1, STUDIO_1, CHANNEL_1])
			COMBI_LINKS.append([int(counter), WLINK_1])
	if COMBI_FIRST:
		COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_SECOND or (not COMBI_SECOND and COMBI_FIRST):
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_SECOND if a[3] == b[3]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		RESULT += [c for c in COMBI_FIRST if all(d[3] != c[3] for d in COMBI_SECOND)] # Der übriggebliebene Rest von Liste1 - wenn die ID nicht in der Liste2 vorkommt !!!
		#log("++++++++++++++++++++++++")
		#log("(navigator.listLeftovers[3]) no.03 XXXXX RESULT-03 : {0} XXXXX".format(str(RESULT)))
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda k: int(k[0]), reverse=False): # 0-6 = Liste1 || 7-17 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS("(navigator.listLeftovers[3]) no.03 ### Anzahl = {0} || Eintrag : {1} ###".format(str(len(da)), str(da)))
			Note_1, Note_2, Note_3 = ("" for _ in range(3))
			if len(da) > 7: ### Liste2 beginnt mit Nummer:07 ###
				name, photo, link1, added1, studio, ChannelID = da[1], da[2], da[3], da[4], da[5], da[6]
				DESC_2, tagline, SerieEpis, link2, added2, duration, YearGenre, genre, cast, director, play_LINK = da[7], da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17]
			else:
				name, photo, link1, added1, studio, ChannelID = da[1], da[2], da[3], da[4], da[5], da[6]
				DESC_2, tagline, SerieEpis, link2, added2, duration, YearGenre, genre, cast, director, play_LINK = "", None, None, "", "", None, None, None, [], "", None
			if SerieEpis:
				Note_1 = translation(30622).format(str(SerieEpis))
			if added1 != "" or added2 != "":
				Note_2 = translation(30623).format(str(added2)) if added2 != "" else translation(30623).format(str(added1))
				if showDATE:
					name = added1+"  "+name if added1 != "" else added2[4:10]+"  "+name # Mi. 18.01.2023 // 18.01.
			if YearGenre and YearGenre not in name:
				name += ' - '+YearGenre
			if studio != "":
				Note_3 = translation(30624).format(studio) if DESC_2 != "" else translation(30625).format(studio)
			if showCHANNEL and ChannelID != "":
				name += ChannelID.replace('ServusTV Deutschland', 'ServusTV').replace('TOGGO plus', 'TOGGO')
			plot = Note_1+Note_2+DESC_2+Note_3
			debug_MS("(navigator.listLeftovers[4]) no.04 ##### TITLE : {0} || EPISODE : {1} || THUMB : {2} #####".format(str(name), Note_1, photo))
			debug_MS("(navigator.listLeftovers[4]) no.04 ##### OR-LINK : {0} || VIDEO : {1} || STUDIO : {2} #####".format(link1, play_LINK, studio))
			addLink(name, photo, {'mode': 'playVideo', 'url': link1, 'extras': play_LINK}, plot, tagline, duration, genre, director, cast, studio)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSubstances(MURLS):
	debug_MS("(navigator.listSubstances) -------------------------------------------------- START = listSubstances --------------------------------------------------")
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	GENCATEGORIES = ['Abenteuer', 'Action', 'Animation', 'Anwalt', 'Bericht', 'Boxen', 'Casting', 'Comedy', 'Diskussion', 'Doku', 'Drama', 'Eishockey', 'Eiskunstlauf', 'Familie', 'Fantasy', 'Freizeit',\
										'Fußball', 'Gala', 'Groteske', 'Handball', 'Heimat', 'Kabarett', 'Kinder', 'Kochduell', 'Komödie', 'Konzert', 'Krankenhaus', 'Krimi', 'Märchen', 'Magazin', 'Melodram', 'Motorrad',\
										'Musik', 'Mystery', 'Natur', 'Polizei', 'Porträt', 'Psychodrama', 'Quiz', 'Ratgeber', 'Reality', 'Reportage', 'Roadmovie', 'Romanze', 'Satire', 'Sci-Fi', 'Show', 'Sitcom', 'Soap',\
										'Sondersendung', 'Sport', 'Talk', 'Theater', 'Tragikomödie', 'Tragödie', 'Thriller', 'Umwelt', 'Verbraucher', 'Vorschulreihe', 'Western', 'Wetter', 'Wissen', 'Zeichentrick']
	if COMBI_DETAILS:
		#log("++++++++++++++++++++++++")
		#log("(navigator.llistSubstances[2]) no.02 XXXXX CONTENT-02 : {0} XXXXX".format(str(COMBI_DETAILS)))
		#log("++++++++++++++++++++++++")
		for num, WLINK_2, elem in COMBI_DETAILS:
			if elem is not None:
				DESC_2, DATE_2, DIRECTOR_2 = ("" for _ in range(3))
				TAGLINE_2, EPIS_2, DURATION_2, plus_INFOS, GENRE_2, DIR_2, PLAYLINK_2 = (None for _ in range(7))
				castLIST_2 = []
				details = re.findall(r'<article class="broadcast-detail"(.*?)</article>', elem, re.S)
				for item in details:
					debug_MS("(navigator.listSubstances[2]) no.02 xxxxx ITEM-02 : {0} xxxxx".format(str(item)))
					TEASER = re.findall(r'<section class="broadcast-detail__description"(.*?)</section>', item, re.S)[0]
					TAG_01 = re.compile(r'<p class="headline">([^<]+)</p>', re.S).findall(TEASER) # Filme & Serien
					TAG_02 = re.compile(r'<h2 class="broadcast-info">([^<]+)</h2>', re.S).findall(item) # z.B. Reportagen
					STORY_01 = re.compile(r'<p>(.*?)</p>', re.S).findall(TEASER)
					if STORY_01:
						DESC_2 = '[CR][CR]'.join([cleaning(re.sub(' +', ' ', (teapart.replace('\n', ' ').replace('\t', ' ')))).strip() for teapart in STORY_01])
						DESC_2 = DESC_2.rstrip()[:-4] if DESC_2.endswith('[CR]') else DESC_2
					if '<div class="broadcast-info-guests">' in TEASER:
						STORY_02 = re.compile(r'<li[^>]*>(.*?)</li>', re.S).findall(TEASER)
						if STORY_02:
							DESC_2 += '[CR][CR]'+'[CR]'.join([cleaning(modpart.replace('\n', ' ').replace('\t', ' ')).strip() for modpart in STORY_02])
							DESC_2 = DESC_2.rstrip()[:-4] if DESC_2.endswith('[CR]') else DESC_2
					TAGLINE_2 = cleaning(TAG_01[0]).replace('\n', ' ').replace('\t', ' ') if TAG_01 else cleaning(TAG_02[0]).replace('\n', ' ').replace('\t', ' ') if TAG_02 and not TAG_02[0].startswith('Mehr zu ') else None
					if TAGLINE_2 and len(TAGLINE_2) > 125:
						TAGLINE_2 = TAGLINE_2[:125]+'...'
					SERIE_2 = re.compile(r'<section class="serial-info">(.*?)</section>', re.S).findall(item)
					EPIS_2 = cleaning(re.sub(r'\<.*?>', '', SERIE_2[0])) if SERIE_2 else None # Folge 4
					SECTOR_1 = re.compile(r'<div class="text-wrapper">(.*?)<section class="broadcast-detail__stage', re.S).findall(item)
					matchONE = cleaning(SECTOR_1[0]) if SECTOR_1 else None
					if matchONE:
						TIME_2 = re.compile(r'Ausstrahlung:\ ([^<]+)</span>', re.S).findall(matchONE)
						matchDT = TIME_2[0].split('|')[0].strip() if TIME_2 and '|' in TIME_2[0] else None # TV-Ausstrahlung: 18.01. | 90 Min.
						if matchDT and str(matchDT)[:6].replace('.', '').replace('-', '').replace(' ', '').isdigit():
							dt_year = (datetime.now() + timedelta(days=60)).strftime('%Y') if str(datetime.now().month) == '12' and str(matchDT[3:5]) == '01' else datetime.now().strftime('%Y') # Jahreswechsel berücksichtigen und ein Jahr weiter schalten
							dt_string = matchDT[:6]+str(dt_year)
							available = datetime(*(time.strptime(dt_string, '%d{0}%m{0}%Y'.format('.'))[0:6])) # 18.01.
							DATE_2 = available.strftime('%a{0} %d{0}%m{0}%Y').format('.')
							for av in (('Mon.', translation(32201)), ('Tue.', translation(32202)), ('Wed.', translation(32203)), ('Thu.', translation(32204)), ('Fri.', translation(32205)), ('Sat.', translation(32206)), ('Sun.', translation(32207))):
								DATE_2 = DATE_2.replace(*av)
						MINS_2 = re.search('\ (\d+)\ Min.', TIME_2[0]) if TIME_2 else None # 90 Min.
						DURATION_2 = str(int(MINS_2.group(1)) * 60) if MINS_2 else None
						CAT_2 = re.compile(r'<span class="text-row">([^<]+)</span>', re.S).findall(matchONE)
						matchCG = CAT_2[0] if CAT_2 else None # D 2021 | Krimi
						plus_INFOS_2 = cleaning(CAT_2[0]) if CAT_2 else None # D 2021 | Krimi
						GENRE_2 = ' / '.join(sorted([tg for tg in GENCATEGORIES if tg.lower() in matchCG.lower()]))
					try: SECTOR_2 = re.findall(r'<section class="cast(?: visible)?" id="inline-section_crew"(.*?)</section>', item, re.S)[0]
					except: SECTOR_2 = None
					if SECTOR_2:
						STEP_2 = re.compile(r'class="headline">Cast & Crew:(.*?)</div>', re.S).findall(SECTOR_2)
						matchTWO = cleaning(STEP_2[0]) if STEP_2 else None
						if matchTWO: # <dt class="role">Ellen Berlinger</dt> # <dd class="name">Heike Makatsch</dd>
							CAST_2 = re.compile(r'<dt class="role">(.*?)</dt>\s*<dd class="name">(.*?)</dd>', re.S).findall(matchTWO)
							for index, person in enumerate(CAST_2, 1):
								actor = {'name': cleaning(re.sub(r'\<.*?>', '', person[1])), 'role': cleaning(re.sub(r'\<.*?>', '', person[0])), 'order': index, 'thumb': ''}
								if actor['name'] not in ['' , None]:
									if KODI_ov20:
										castLIST_2.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
									else: castLIST_2.append(actor)
							DIR_2 = re.compile(r'<dt>Regie:</dt>\s*<dd>(.*?)</dd>', re.S).findall(matchTWO) # <dt>Regie:</dt> # <dd>Philipp Osthus, Andreas Menck, Florian Gottschick, Felix Ahrens</dd>
							DIRECTOR_2 = ', '.join([cleaning(re.sub(r'\<.*?>', '', (dirpart.replace('\n', ' ').replace('\t', ' ').replace('  ', '')))).strip() for dirpart in DIR_2]) if DIR_2 else ""
					PLAY_2 = re.compile(r'<div class="mediatheken-partner">\s*<a href="([^"]+)" target="_blank"', re.S).findall(item)
					PLAYLINK_2 = PLAY_2[0] if PLAY_2 else None
					COMBI_THIRD.append([DESC_2, TAGLINE_2, EPIS_2, WLINK_2, DATE_2, DURATION_2, plus_INFOS_2, GENRE_2, castLIST_2, DIRECTOR_2, PLAYLINK_2])
	return COMBI_THIRD

def playVideo(url, EXTRA):
	log("(navigator.playVideo) --- START WIEDERGABE ANFORDERUNG ---")
	log("(navigator.playVideo) frei")
	finalURL, LINK = (False for _ in range(2))
	if EXTRA is None:
		try:
			content = getUrl(url, method='LOAD')
			LINK = re.compile(r'<div class="mediatheken-partner">\s*<a href="([^"]+)" target="_blank"', re.S).findall(content)[0]
			log("(navigator.playVideo[1]) no.01 ~~~ AbspielLink (Original) : {0} ~~~".format(LINK))
		except:
			log("(navigator.playVideo[1]) MediathekLink-00 : MediathekLink der Sendung in TV-Spielfilm NICHT gefunden !!!")
			log("(navigator.playVideo[1]) --- ENDE WIEDERGABE ANFORDERUNG ---")
			return dialog.notification(translation(30521).format('LINK'), translation(30525), icon, 8000)
	else: 
		LINK = EXTRA
		log("(navigator.playVideo[2]) no.02 ~~~ AbspielLink (Original) : {0} ~~~".format(LINK))
	log("(navigator.playVideo) frei")
	LINK = LINK.replace('http://', 'https://') if LINK and LINK[:7] == 'http://' else LINK
	if LINK and LINK.startswith('https://www.ardmediathek.de'):
		return ArdGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.arte.tv'):
		videoID = re.compile('arte.tv/de/videos/([^/]+?)/', re.S).findall(LINK)[0]
		finalURL = '{0}?mode=playVideo&url={1}'.format('plugin://plugin.video.tyl0re.arte/', str(videoID))
		return playRESOLVED(finalURL, 'TRANSMIT', 'ARTE.TV', 'ARTE.TV - Plugin')
	elif LINK and LINK.startswith(('https://www.3sat.de', 'https://www.phoenix.de', 'https://www.zdf.de')):
		videoURL = LINK[:LINK.find('.html')]+'.html'
		return ZdfGetVideo(videoURL)
	elif LINK and LINK.startswith(('https://www.nowtv.de', 'https://www.tvnow.de')):
		return RtlGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.servustv.com'):
		videoID = LINK.split('/')[-2].replace('/', '').upper()
		finalURL = '{0}?mode=playVideo&url={1}'.format('plugin://plugin.video.servustv_com/', str(videoID))
		return playRESOLVED(finalURL, 'TRANSMIT', 'ServusTV.com', 'ServusTV - Plugin')
	elif LINK and LINK.startswith('https://tele5.de'):
		videoURL = getUrl(LINK, method='LOAD')
		videoID = re.compile(r'playertype="videoPlayer"\s+assetid="([^"]+)"', re.S).findall(videoURL)
		finalURL = '{0}play/{1}'.format('plugin://plugin.video.tele5_de/', str(videoID[0])) if videoID else False
		return playRESOLVED(finalURL, 'TRANSMIT', 'TELE 5 Mediathek', 'TELE 5 - Plugin')
	elif LINK and LINK.startswith('https://www.toggo.de'):
		return ToggoGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.welt.de'):
		return WeltGetVideo(LINK)
	else:
		failing("(navigator.playVideo[3]) AbspielLink-00 : Der Provider *{0}* konnte nicht aufgelöst werden !!!".format(urlparse(LINK).netloc))
		dialog.notification(translation(30521).format('LINK'), translation(30526).format(urlparse(LINK).netloc), icon, 8000)
		log("(navigator.playVideo[3]) --- ENDE WIEDERGABE ANFORDERUNG ---")

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, studio=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot), videoInfoTag.setStudios([studio])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': studio})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, tagline=None, duration=None, genre=None, director=None, cast=None, studio=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name)
		videoInfoTag.setTagLine(tagline)
		videoInfoTag.setPlot(plot)
		if duration: videoInfoTag.setDuration(int(duration))
		videoInfoTag.setGenres([genre])
		videoInfoTag.setDirectors([director])
		if isinstance(cast, (list, tuple)): videoInfoTag.setCast(cast)
		videoInfoTag.setStudios([studio])
		videoInfoTag.setMediaType('movie')
	else:
		info = {}
		if isinstance(cast, (list, tuple)): liz.setCast(cast)
		info['Title'] = name
		info['Tagline'] = tagline
		info['Plot'] = plot
		if duration: info['Duration'] = duration
		info['Genre'] = [genre]
		info['Director'] = [director]
		info['Studio'] = [studio]
		info['Mediatype'] = 'movie'
		liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, 'mode=AddToQueue'))])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
