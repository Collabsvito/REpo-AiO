﻿# -*- coding: utf-8 -*-

from .common import *


def ArdGetVideo(video_origin):
	debug_MS("(resolver.ArdGetVideo) ------------------------------------------------ START = ArdGetVideo -----------------------------------------------")
	MEDIAS, (STREAM, FINAL_URL) = [], (False for _ in range(2))
	ARD_QUALITIES = ['Auto', 2560, 1920, 1280, 960, 640] # ARD_QUALITIES = ['auto', 5, 4, 3, 2, 1, 0]
	code_one = next(filter(lambda vx: 'Y3JpZDov' in vx, video_origin.split('/')), None)
	# https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL3JhZGlvYnJlbWVuLmRlLzgyYzhkMjE0LTFhM2YtNDU3NC1iOWMwLTdjODlmYWIzNDYyNi9lcGlzb2RlL3VybjphcmQ6c2hvdzo2MjA5YjVhYmQ4ODZhN2Fj?devicetype=pc&embedded=true = Nicht immer Videoeinträge vorhanden !!!
	# https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL3JhZGlvYnJlbWVuLmRlLzgyYzhkMjE0LTFhM2YtNDU3NC1iOWMwLTdjODlmYWIzNDYyNi9lcGlzb2RlL3VybjphcmQ6c2hvdzo2MjA5YjVhYmQ4ODZhN2Fj?embedded=true&mcV6=true = Alle Videoeinträge = Fremdsprachen, Deutsch Standard, Deutsch mit Audiodescription, Deutsch mit Unterttiteln
	debug_MS(f"(resolver.ArdGetVideo[1]) ##### REQUEST_ONE : {API_ARD}ard/item/{code_one}?embedded=true&mcV6=true #####")
	if code_one:
		content_one = getContent(f"{API_ARD}ard/item/{code_one}?embedded=true&mcV6=true", 'TRACK')
		if content_one.status_code in [200, 201, 202]:
			DATA_ONE = content_one.json()
			debug_MS("++++++++++++++++++++++++")
			debug_MS(f"(resolver.ArdGetVideo[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
			debug_MS("++++++++++++++++++++++++")
			if DATA_ONE is not None and DATA_ONE.get('widgets', '') and len(DATA_ONE['widgets']) > 0:
				if DATA_ONE.get('coreAssetType', '') == 'SECTION' and len(DATA_ONE['widgets']) > 1 and 'teasers' in str(DATA_ONE['widgets'][1]):
					broadcast = DATA_ONE['widgets'][0].get('broadcastedOn', 'UNKNOWN')
					code_two = next(filter(lambda cx: cx.get('coreAssetType', '') == 'EPISODE' and broadcast in cx.get('broadcastedOn', ''), DATA_ONE['widgets'][1].get('teasers', [])), None)
					debug_MS(f"(resolver.ArdGetVideo[1]) ##### DETECTED CODE FOR REQUEST_TWO : {code_two['id'] if code_two else '!!! ERROR !!! NO RESULTS !!! ERROR !!!'} #####")
					if code_two:
						content_two = getContent(f"{API_ARD}ard/item/{code_two['id']}?embedded=false&mcV6=true", 'TRACK')
						if content_two.status_code in [200, 201, 202]:
							DATA_TWO = content_two.json()
							debug_MS("++++++++++++++++++++++++")
							debug_MS(f"(resolver.ArdGetVideo[2]) XXXXX CONTENT-02 : {DATA_TWO} XXXXX")
							debug_MS("++++++++++++++++++++++++")
							if DATA_TWO is not None and DATA_TWO.get('widgets', '') and len(DATA_TWO['widgets']) > 0:
								full_video = DATA_TWO.get('widgets', [])
							else: full_video = DATA_ONE.get('widgets', [])
						else: full_video = DATA_ONE.get('widgets', [])
					else: full_video = DATA_ONE.get('widgets', [])
				else: full_video = DATA_ONE.get('widgets', [])
				for elem in full_video:
					if elem.get('mediaCollection', '') and len(elem['mediaCollection']) > 0:
						for ASSET in ARD_QUALITIES:
							for TOP in elem['mediaCollection']['embedded']['streams'][0].get('media', []):
								if TOP['maxHResolutionPx'] == ASSET and TOP.get('url', '') and TOP.get('audios', '') and len(TOP['audios']) > 0 and TOP['audios'][0].get('kind', 'unknown').lower() == 'standard' and TOP['audios'][0].get('languageCode', 'unknown').lower() == 'deu':
									if (enableINPUTSTREAM or prefSTREAM == 0) and TOP.get('forcedLabel', 'unknown').lower() == 'auto' and 'm3u8' in TOP['url']:
										STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
										FINAL_URL = f"https:{TOP['url']}" if TOP['url'][:4] != 'http' else TOP['url']
										debug_MS(f"(resolver.ArdGetVideo[3]) ***** TAKE - {'Inputstream (hls)' if STREAM == 'HLS' else 'Standard (m3u8)'} - FILE (Ard.de+3) *****")
									if TOP.get('forcedLabel', 'unknown').lower() != 'auto' and '.mp4' in TOP['url']:
										MEDIAS.append({'Video': TOP['url'], 'Quality': TOP.get('forcedLabel', 'unknown'), 'mimeType': TOP.get('mimeType', 'Unknown'), 'Height': TOP['maxHResolutionPx']})
					elif elem.get('blockedByFsk', '') is True:
						log("(resolver.ArdGetVideo[3]) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Alterbeschränkungen geblockt !!!")
						return dialog.notification(translation(30530), translation(30531), icon, 8000)
					elif elem.get('geoblocked', '') is True:
						log("(resolver.ArdGetVideo[3]) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Geo-Sperren geblockt !!!")
						return dialog.notification(translation(30530), translation(30532), icon, 8000)
	if not FINAL_URL and MEDIAS:
		ARD_URL = f"https:{MEDIAS[0]['Video']}" if MEDIAS[0]['Video'][:4] != 'http' else MEDIAS[0]['Video']
		debug_MS(f"(resolver.ArdGetVideo[4]) SORTED_LIST | MP4 ### MEDIAS : {MEDIAS} ###")
		debug_MS(f"(resolver.ArdGetVideo[4]) ***** TAKE - (mp4) - FILE (Ard.de+3) : {ARD_URL} *****")
		STREAM, FINAL_URL = 'MP4', VideoBEST(ARD_URL, improve='DasErste') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	return playRESOLVED(FINAL_URL, STREAM, 'ARD+3', 'ARD - Intern')

def JoynGetVideo(video_origin):
	debug_MS("(resolver.JoynGetVideo) ------------------------------------------------ START = JoynGetVideo -----------------------------------------------")
	# ORIGINAL = https://www.joyn.de/play/serien/sweet-easy-on-tour/2-5-schwarzwaelder-himbeertorte-aus-mailand
	# FINAL_URL = plugin://plugin.video.joyn/?mode=play_video&video_id=a_pbbt48zdo6a&client_data=%7B%22genre%22%3A+%5B%5D%2C+%22startTime%22%3A+0%2C+%22videoId%22%3A+%22a_pbbt48zdo6a%22%2C+%22npa%22%3A+false%2C+%22duration%22%3A+1490000%2C+%22brand%22%3A+%22%22%7D&stream_type=VOD&title=Schwarzw%C3%A4lder+Himbeertorte+aus+Mailand&movie_id=None&path=%2Fserien%2Fsweet-easy-on-tour%2F2-5-schwarzwaelder-himbeertorte-aus-mailand
	video_id, movie_id, route, FINAL_URL = (None for _ in range(4))
	sweep = urlparse(video_origin)
	DATA_ONE = getContent(f"{sweep.path.replace('play/', '')}.json", REF=video_origin)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(resolver.JoynGetVideo[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if DATA_ONE is not None and DATA_ONE.get('pageProps', ''):
		if DATA_ONE['pageProps'].get('__N_REDIRECT', ''):
			DATA_VIDEO = getContent(f"{DATA_ONE['pageProps']['__N_REDIRECT']}.json", REF=video_origin)
		else: DATA_VIDEO = DATA_ONE
		if DATA_VIDEO is not None and DATA_VIDEO.get('pageProps', '') and DATA_VIDEO['pageProps'].get('initialData', '') and DATA_VIDEO['pageProps']['initialData'].get('page', ''):
			SHORT = DATA_VIDEO['pageProps']['initialData']['page']
			if SHORT.get('movie', ''):
				video_id = SHORT['movie']['video']['id']
				runtime = SHORT['movie']['video']['duration'] if SHORT['movie']['video'].get('duration', '') else 0
				movie_id = SHORT['movie']['id']
				route = SHORT['movie']['path']
				title = SHORT['movie']['title'] if SHORT['movie'].get('title', '') else 'Unknown'
			elif SHORT.get('episode', ''):
				video_id = SHORT['episode']['video']['id']
				runtime = SHORT['episode']['video']['duration'] if SHORT['episode']['video'].get('duration', '') else 0
				route = SHORT['episode']['path']
				title = SHORT['episode']['title'] if SHORT['episode'].get('title', '') else 'Unknown'
			if video_id and route:
				CLIENT = f'{{"genre": [], "startTime": 0, "videoId": "{video_id}", "npa": false, "duration": {int(runtime) * 1000}, "brand": ""}}'
				debug_MS(f"(resolver.JoynGetVideo[2]) ##### CLIENT_DATA : {quote_plus(CLIENT)} #####")
				FINAL_URL = build_mass('plugin://plugin.video.joyn/', {'mode': 'play_video', 'movie_id': movie_id, 'video_id': video_id, 'stream_type': 'VOD', 'title': title, 'client_data': CLIENT, 'path': route})
				# JOYN-TRANSMIT : plugin://plugin.video.joyn/?mode=play_video&movie_id=&video_id=a_plf6fi6v9wq&stream_type=VOD&title=Young+Monaco&client_data=%7B%22genre%22%3A+%5B%5D%2C+%22startTime%22%3A+0%2C+%22videoId%22%3A+%22a_plf6fi6v9wq%22%2C+%22npa%22%3A+false%2C+%22duration%22%3A+2966000%2C+%22brand%22%3A+%22%22%7D&path=%2Fserien%2Fgalileo-stories%2F2024-32-young-monaco
	return playRESOLVED(FINAL_URL, 'TRANSMIT', 'JOYN - Mediathek', 'Joyn - Plugin')

def ToggoGetVideo(video_origin):
	debug_MS("(resolver.ToggoGetVideo) ------------------------------------------------ START = ToggoGetVideo -----------------------------------------------")
	POLICY, brightcoveID, STREAM, FINAL_URL, DRM_ENTRIES = (False for _ in range(5)) # !!! TOGGO.de - AccountID = 6057955896001 !!!
	MIME = 'application/vnd.apple.mpegurl'
	def extractPolKey():
		DATA_ONE = getContent('https://players.brightcove.net/6057955896001/default_default/config.json') # https://players.brightcove.net/6057955896001/default_default/config.json
		if DATA_ONE is not None and DATA_ONE.get('video_cloud', '') and DATA_ONE['video_cloud'].get('policy_key', ''):
			POLICY = DATA_ONE['video_cloud']['policy_key']
		else:
			DATA_TWO = getContent('https://players.brightcove.net/6057955896001/default_default/index.min.js', 'LOAD') # https://players.brightcove.net/6057955896001/default_default/index.min.js
			PLK = re.compile(r'''accountId:["']6057955896001["'],policyKey:["']([^"']+)["']}?''', re.S).findall(DATA_TWO)
			POLICY = PLK[0] if PLK else None
		return POLICY
	DATA_ASSET = getContent(f"https://production-n.toggo.de/api/assetstore/vod/asset/{video_origin.split('/')[-1]}")
	if DATA_ASSET is not None:
		brightcoveID = next(x.get('value') for x in DATA_ASSET['data'].get('custom_fields', []) if x.get('key') == 'video-cloud-id')
	personalID = extractPolKey()
	if brightcoveID and personalID: # https://edge.api.brightcove.com/playback/v1/accounts/6057955896001/videos/6301101396001?config_id=6653bcfa-b258-4bc9-8f30-4b702ead02d8
		req_FOUR = f"https://edge.api.brightcove.com/playback/v1/accounts/6057955896001/videos/{str(brightcoveID)}"
		DATA_VIDEO = getContent(req_FOUR, REF='https://www.toggo.de/', WAY='bcov-policy', AUTH=personalID)
		debug_MS(f"(resolver.ToggoGetVideo[1]) ##### DATA_BRIGHTCOVE : {str(DATA_VIDEO)} #####")
		if DATA_VIDEO is not None and DATA_VIDEO.get('sources', '') and len(DATA_VIDEO['sources']) > 0:
			for elem in DATA_VIDEO.get('sources', []):
				if elem.get('key_systems', '') and elem['key_systems'].get('com.widevine.alpha', '') and elem['key_systems']['com.widevine.alpha'].get('license_url', ''):
					if elem.get('type') == 'application/dash+xml' and elem.get('src', ''):
						STREAM, MIME, FINAL_URL = 'MPD', 'application/dash+xml', elem['src']
						debug_MS("(resolver.ToggoGetVideo[2]) ***** TAKE - Inputstream (mpd) - FILE (Toggo.de) *****")
						DRM_GUARD = elem['key_systems']['com.widevine.alpha']['license_url']
						DRM_HEADERS = {'User-Agent': get_userAgent(), 'Content-Type': 'application/octet-stream'}
						DRM_ENTRIES = f"{DRM_GUARD}|{urlencode(DRM_HEADERS)}|R{{SSM}}|" if DRM_GUARD else None
						break
				if not FINAL_URL and elem.get('type') == 'application/x-mpegURL' and not '/fairplay/' in elem.get('src', '') and not WAKEY:
					STREAM, MIME, FINAL_URL = 'HLS', 'application/vnd.apple.mpegurl', elem['src']
					debug_MS("(resolver.ToggoGetVideo[2]) ***** TAKE - Inputstream (hls) - FILE (Toggo.de) *****")
					break
	return playRESOLVED(FINAL_URL, STREAM, 'TOGGO', 'TOGGO - Intern', MIME, DRM_ENTRIES)

def WeltGetVideo(video_origin):
	debug_MS("(resolver.WeltGetVideo) ------------------------------------------------ START = WeltGetVideo -----------------------------------------------")
	M3U8_Url, MP4_Url, STREAM, FINAL_URL = (False for _ in range(4))
	content_one = getContent(video_origin, 'LOAD', REF=video_origin)
	target_WELT = re.compile(r'''(?s)<script type=["']application/json["'] data-content=["']VideoPlayer.Config["'] data-qa=["']VideoPlayer.Config["']>\s+(?P<json>{.+?})\s+</script>''', re.S).findall(content_one)
	if target_WELT:
		debug_MS(f"(resolver.WeltGetVideo[1]) ##### DATA_WELT-01 : {target_WELT[0]} #####")
		DATA_VIDEO = json.loads(target_WELT[0])
		if DATA_VIDEO.get('sources', '') and len(DATA_VIDEO['sources']) > 0:
			for elem in DATA_VIDEO.get('sources', []):
				if (enableINPUTSTREAM or prefSTREAM == 0) and elem.get('extension') == 'm3u8' and elem.get('src', ''):
					STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
					FINAL_URL = f"https://www.welt.de/onward/video/play/{quote_plus(elem['src'])}"
					debug_MS(f"(resolver.WeltGetVideo[2]) ***** TAKE - {'Inputstream (hls)' if STREAM == 'HLS' else 'Standard (m3u8)'} - FILE (Welt.de) *****")
					break
				if not FINAL_URL and elem.get('extension') == 'mp4' and elem.get('src', ''):
					STREAM, FINAL_URL = 'MP4', f"https://www.welt.de/onward/video/play/{quote_plus(elem['src'])}"
					debug_MS("(resolver.WeltGetVideo[2]) ***** TAKE - (mp4) - FILE (Welt.de) *****")
					break
	return playRESOLVED(FINAL_URL, STREAM, 'WELT', 'WELT - Intern')

def ZdfGetVideo(video_origin):
	debug_MS("(resolver.ZdfGetVideo) ------------------------------------------------ START = ZdfGetVideo -----------------------------------------------")
	DATA_ONE, TEASER, SECRET, videoFOUND = (False for _ in range(4))
	if video_origin.startswith('https://www.phoenix.de'):
		PHOEN_IDD = re.compile('-a-([0-9]+).', re.S).findall(video_origin) # https://www.phoenix.de/sendungen/ereignisse/phoenix-plus/gefahren-der-ki-a-3179773.html?ref=3163173
		if PHOEN_IDD:
			debug_MS(f"(resolver.ZdfGetVideo[1]) PHOENIX ##### TARGET : {str(PHOEN_IDD[0])} #####")
			FIRST = getContent(f"https://www.phoenix.de/response/id/{PHOEN_IDD[0]}/refid/suche") # https://www.phoenix.de/response/id/3179773/refid/suche
			CODING = FIRST['absaetze'][0]['content'] if FIRST.get('absaetze', '') and FIRST.get('absaetze', {})[0].get('content', '') and str(FIRST['absaetze'][0]['content'])[:4].isdecimal() else None
			if CODING:
				NEW_URL = f"https://www.phoenix.de/php/mediaplayer/data/beitrags_details.php?id={CODING}&profile=player2"
				debug_MS(f"(resolver.ZdfGetVideo[2]) ##### REQUEST_URL : {NEW_URL} #####")
				DATA_ONE = getContent(NEW_URL) # https://www.phoenix.de/php/mediaplayer/data/beitrags_details.php?id=3180917&profile=player2
	else:
		content_one = getContent(video_origin, 'LOAD').replace('\\', '')
		ZDF_OLD = re.compile(r'''(?s)data-zdfplayer-jsb=["'](?P<json>{.+?})["']''', re.S).findall(content_one)
		if ZDF_OLD:
			FIRST = json.loads(ZDF_OLD[0])
			TEASER, SECRET = FIRST['content'], FIRST['apiToken']
			debug_MS(f"(resolver.ZdfGetVideo[1]) ZDF_OLD ##### TEASER : {TEASER} || SECRET : {SECRET} #####")
		elif not ZDF_OLD:
			CONTENT = re.compile(r'''["']config["']:\{["']content["']:["']([^"']+)["'],''', re.S).findall(content_one)
			CODING = re.compile(r'''["']tokens["']:\{["']videoToken["']:\{["']apiToken["']:["']([^"']+)["'],''', re.S).findall(content_one)
			if CONTENT and CODING:
				debug_MS(f"(resolver.ZdfGetVideo[1]) ZDF_NEW ##### TEASER : {API_ZDF}/content/documents/{CONTENT[0]}.json || SECRET : {CODING[0]} #####")
				TEASER, SECRET = f"{API_ZDF}/content/documents/{CONTENT[0]}.json", CODING[0]
		if TEASER and SECRET:
			NEW_URL = API_ZDF+TEASER if TEASER[:4] != 'http' else TEASER
			debug_MS(f"(resolver.ZdfGetVideo[2]) ##### REQUEST_URL : {NEW_URL} #####")
			DATA_ONE = getContent(NEW_URL, WAY='Api-Auth', AUTH=f"Bearer {SECRET}")
	if DATA_ONE and DATA_ONE.get('contentType', '') in ['clip', 'episode'] and not DATA_ONE.get('profile') == 'http://zdf.de/rels/not-found':
		START_URL = 'https://api.3sat.de' if TEASER and TEASER.startswith('https://api.3sat.de') else 'https://api.zdf.de' if TEASER and TEASER.startswith('https://api.zdf.de') else ""
		BASIS = DATA_ONE['mainVideoContent']['http://zdf.de/rels/target']
		TOPICS = DATA_ONE['mainVideoContent']['http://zdf.de/rels/target']['streams']['default'] if BASIS.get('streams', '') and BASIS['streams'].get('default', '') else BASIS
		videoFOUND = START_URL+TOPICS['http://zdf.de/rels/streams/ptmd-template'].replace('{playerId}', 'ngplayer_2_5').replace('\/', '/')
		debug_MS(f"(resolver.ZdfGetVideo[3]) ##### videoFOUND : {videoFOUND} #####")
		return ZdfExtractQuality(videoFOUND, 'Api-Auth', f"Bearer {SECRET}") if START_URL != "" else ZdfExtractQuality(videoFOUND, None, None)
	if videoFOUND is False:
		failing("(resolver.ZdfGetVideo[4]) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
		log("(resolver.ZdfGetVideo[4]) --- ENDE WIEDERGABE ANFORDERUNG ---")
		dialog.notification(translation(30521).format('ZDF - Intern'), translation(30529), icon, 8000)

def ZdfExtractQuality(content_three, PREFIX, TOKEN):
	debug_MS("(resolver.ZdfExtractQuality) ------------------------------------------------ START = ZdfExtractQuality -----------------------------------------------")
	DATA_TWO = getContent(content_three) if TOKEN is None else getContent(content_three, WAY=PREFIX, AUTH=TOKEN)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(resolver.ZdfExtractQuality[1]) XXXXX CONTENT-01 : {DATA_TWO} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	MEDIAS, (STREAM, FINAL_URL) = [], (False for _ in range(2))
	M3U8_QUALITIES = ['auto', 'veryhigh', 'high', 'med']
	MP4_QUALITIES = ['uhd', 'fhd', 'hd', 'veryhigh', 'high', 'low']
	if DATA_TWO is not None:
		for each in DATA_TWO.get('priorityList', []):
			formitaeten = each.get('formitaeten')
			if not isinstance(formitaeten, list):
				continue
			for item in formitaeten:
				if (enableINPUTSTREAM or prefSTREAM == 0) and item.get('type') == 'h264_aac_ts_http_m3u8_http' and item.get('mimeType').lower() == 'application/x-mpegurl':
					for found in M3U8_QUALITIES:
						for quality in item.get('qualities', []):
							if quality['quality'] == found:
								MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': item.get('mimeType').lower(), 'language': quality['audio']['tracks'][0]['language']})
					debug_MS(f"(resolver.ZdfExtractQuality[2]) SORTED_LIST | M3U8 ### MEDIAS : {MEDIAS} ###")
					STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
					FINAL_URL = MEDIAS[0]['url']
					debug_MS(f"(resolver.ZdfExtractQuality[2]) ***** TAKE - {'Inputstream (hls)' if STREAM == 'HLS' else 'Standard (m3u8)'} - FILE (Zdf.de+3) *****")
				if not FINAL_URL and item.get('type') == 'h264_aac_mp4_http_na_na' and 'progressive' in item.get('facets', []) and item.get('mimeType').lower() == 'video/mp4':
					for found in MP4_QUALITIES:
						for quality in item.get('qualities', []):
							if quality['quality'] == found:
								MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': item.get('mimeType').lower(), 'language': quality['audio']['tracks'][0]['language']})
					debug_MS(f"(resolver.ZdfExtractQuality[3]) SORTED_LIST | MP4 ### MEDIAS : {MEDIAS} ###")
					debug_MS(f"(resolver.ZdfExtractQuality[3]) ***** TAKE - (mp4) - FILE (Zdf.de+3) : {MEDIAS[0]['url']} *****")
					STREAM, FINAL_URL = 'MP4', VideoBEST(MEDIAS[0]['url'], improve='DasZweite') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	return playRESOLVED(FINAL_URL, STREAM, 'ZDF+3', 'ZDF - Intern')

def VideoBEST(highest, improve=False):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen // aktualisiert am 23.11.2024
	standards = [highest, '', '', ''] # Seite zur Überprüfung : https://github.com/mediathekview/MServer/blob/master/src/main/java/mServer/crawler/sender/zdf/ZdfVideoUrlOptimizer.java
	if improve == 'DasErste':
		route_one = (('/960', '/1280'), ('.l.mp4', '.xl.mp4'), ('_C.mp4', '_X.mp4'))
		route_two = (('/1280', '/1920'), ('_X.mp4', '_HD.mp4'), ('x720-50p-3200kbit.mp4', 'x1080-50p-5000kbit.mp4'), ('.hd.mp4', '.1080.mp4'), ('hd1080-avc720.mp4', 'hd1080-avc1080.mp4'))
		route_tree = (('/1920', '/3840'), ('_P.mp4', '_H.mp4'), ('.xl.mp4', '.xxl.mp4'))
	elif improve == 'DasZweite':
		route_one = (('808k_p11v15', '2360k_p35v15'), ('1456k_p13v11', '2328k_p35v11'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'), ('1628k_p13v15', '2360k_p35v15'),
								('1628k_p13v17', '2360k_p35v17'), ('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
		route_two = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'), ('2360k_p35v17', '3360k_p36v17'))
		route_tree = (('3360k_p36v15', '4692k_p72v16'), ('3360k_p36v17', '6660k_p37v17'))
	standards[1] = reduce(lambda m, kv: m.replace(*kv), route_one, standards[0])
	standards[2] = reduce(lambda n, kv: n.replace(*kv), route_two, standards[1])
	standards[3] = reduce(lambda o, kv: o.replace(*kv), route_tree, standards[2])
	if standards[0] not in [standards[1], standards[2], standards[3]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def playRESOLVED(END_URL, PROTOCOL, MARKING, NOTE, MIME='application/vnd.apple.mpegurl', WIDEVINE=None):
	if END_URL and PROTOCOL:
		LSM = xbmcgui.ListItem(path=END_URL)
		if plugin_operate('inputstream.adaptive') and PROTOCOL in ['HLS', 'MPD']:
			IA_NAME, IA_SYSTEM = 'inputstream.adaptive', 'com.widevine.alpha'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			LSM.setMimeType(MIME), LSM.setContentLookup(False), LSM.setProperty('inputstream', IA_NAME)
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LSM.setProperty(f"{IA_NAME}.manifest_type", PROTOCOL.lower())
			if KODI_ov20:
				LSM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={get_userAgent()}") # On KODI v20 and above
			else: LSM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={get_userAgent()}") # On KODI v19 and below
			if int(IA_VERSION) >= 2150 and PROTOCOL == 'HLS':
				LSM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey')
			if PROTOCOL == 'MPD':
				if int(IA_VERSION) >= 2150:
					if WIDEVINE:
						DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Entries': WIDEVINE}
					else: DRM_SPECIES = {'DRM_System': IA_SYSTEM}
					LSM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
				else:
					LSM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
					if WIDEVINE:
						LSM.setProperty(f"{IA_NAME}.license_key", WIDEVINE) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
				if WIDEVINE: debug_MS(f"(resolver.playRESOLVED) LICENSE : {WIDEVINE}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(resolver.playRESOLVED) END-AbspielLink ({MARKING}) : {PROTOCOL}_stream : {END_URL}")
	else:
		failing(f"(resolver.playRESOLVED) AbspielLink-00 ({MARKING}) : *{NOTE}* Der angeforderte -VideoLink- existiert NICHT !!!")
		dialog.notification(translation(30521).format(NOTE), translation(30529), icon, 8000)
	log("(resolver.playRESOLVED) --- ENDE WIEDERGABE ANFORDERUNG ---")
