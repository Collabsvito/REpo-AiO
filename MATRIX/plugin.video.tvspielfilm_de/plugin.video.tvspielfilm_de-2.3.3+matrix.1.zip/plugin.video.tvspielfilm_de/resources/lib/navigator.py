﻿# -*- coding: utf-8 -*-

from .common import *
from .resolver import *


def mainMenu():
	for TITLE, PATH in [(30601, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/", 'extras': 'AKTUELL BELIEBT'}),
		(30602, {'mode': 'listDates', 'extras': 'PASSED'}), (30603, {'mode': 'listDates', 'extras': 'UPCOMING'}), (30604, {'mode': 'listDates', 'extras': 'OVERVIEW'}), 
		(30605, {'mode': 'listChannels', 'url': f"{BASE_URL}/mediathek/nach-sender/"}), (30606, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/spielfilme/", 'extras': 'SPIELFILME'}),
		(30607, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/serien/", 'extras': 'SERIEN'}), (30608, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/dokus/", 'extras': 'DOKUS'}), 
		(30609, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/unterhaltung/", 'extras': 'UNTERHALTUNG'}), (30610, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/kinder/", 'extras': 'KINDER'}),
		(30611, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/sport/", 'extras': 'SPORT'}), (30612, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/filter/?irating=6", 'extras': 'TOP IMDB BEWERTET'}), 
		(30613, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/filter/?timeFrom=20:15&timeTo=23:58&channels=ARD,WDR,N3,BR,SWR,HR,MDR,RBB,FES", 'extras': 'PRIMETIME-HIGHLIGHTS ARD+'}),
		(30614, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/filter/?timeFrom=20:15&timeTo=23:58&channels=ZDF,2NEO,ZINFO,3SAT,ARTE", 'extras': 'PRIMETIME-HIGHLIGHTS ZDF+'}),
		(30615, {'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/filter/?timeFrom=20:15&timeTo=23:58&channels=RTL-N,RTL,RTL2,RTLPL,VOX,SUPER,K1,PRO7,PRO7M,SAT1,SAT1G,SIXX,SERVU,TELE5,WELT", 'extras': 'PRIMETIME-HIGHLIGHTS PRIVATE'})]:
		addDir(PATH, create_entries({'Title': translation(TITLE)}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30616), 'Image': f"{artpic}settings.png"}), False)
		if enableINPUTSTREAM and plugin_operate('inputstream.adaptive'):
			addDir({'mode': 'iConfigs'}, create_entries({'Title': translation(30617), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listDates(EXTRA):
	if EXTRA == 'OVERVIEW':
		for ii in range(-14, 15, 1):
			WU = (datetime.now() - timedelta(days=ii)).strftime('%Y-%m-%d') # Datum für URL // 2023-07-12
			WD = (datetime.now() - timedelta(days=ii)).strftime('%a, %d.%m.') # Datum mit engl. Wochentagskürzel ohne Jahr // Sun, 16.07.
			for tt in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), \
				('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))):
				WD = WD.replace(*tt)
			if ii == 0: addDir({'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/nach-datum/?date={WU}", 'extras': WD}, create_entries({'Title': translation(32108).format(WD)}))
			else: addDir({'mode': 'listBroadcasts', 'url': f"{BASE_URL}/mediathek/nach-datum/?date={WU}", 'extras': WD}, create_entries({'Title': WD}))
	else:
		if EXTRA == 'PASSED':
			frames = ','.join([(datetime.now() - timedelta(days=ii)).strftime('%Y-%m-%d') for ii in reversed(range(0, 15, 1))]) # Immer höchstes Datum zuerst auflisten - daher hier 'reversed'
		elif EXTRA == 'UPCOMING':
			frames = ','.join([(datetime.now() + timedelta(days=ii)).strftime('%Y-%m-%d') for ii in range(1, 15, 1)]) # Immer höchstes Datum zuerst auflisten
		return listBroadcasts(f"{BASE_URL}/mediathek/filter/?dates={frames}", 'VERPASST IN DEN MEDIATHEKEN' if EXTRA == 'PASSED' else 'VORAB IN DEN MEDIATHEKEN')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listChannels(TARGET):
	debug_MS("(navigator.listChannels) -------------------------------------------------- START = listChannels --------------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listChannels) ### SENDER-SORTIERUNG = Alle Sender in TV-Spielfilm ###")
	STATE_JN = 'EINGEBLENDET' if showJOYN is True else 'AUSGEBLENDET'
	STATE_RT = 'EINGEBLENDET' if showRTL is True else 'AUSGEBLENDET'
	debug_MS(f"(navigator.listChannels) --- JOYN Mediathek  - Sender {STATE_JN} ---")
	debug_MS(f"(navigator.listChannels) --- RTLPLUS Mediathek - Sender {STATE_RT} ---")
	content = getContent(TARGET, queries='TEXT')
	results = re.findall(r'''<div class=["']mediathek-channel-slider__container["'](.*?)</div>''', content, re.S)[0]
	NavItem = re.findall(r'''title=["']([^"']+)" href=["'](https?://.*?mediathek/.*?)["']\s*class=["']js-track-link''', results, re.S)
	for TITLE, ULINK in NavItem:
		name, station = cleanStation(TITLE) # SUPER RTL Mediathek
		if showARTE is False and name.upper() in ARTEEX: continue
		if showJOYN is False and name.upper() in JOYNEX: continue
		if showSERVUS is False and name.upper() in SERVUSEX: continue
		if showTELE is False and name.upper() in TELEEX: continue
		if showRTL is False and name.upper() in RTLEX: continue
		debug_MS(f"(navigator.listChannels[1]) ##### NAME : {name} || LINK : {ULINK} ##### ")
		FETCH_UNO = create_entries({'Title': translation(30631).format(name), 'Image': f"{artpic}{name.lower().replace(' ', '')}.png", 'Studio': name})
		addDir({'mode': 'listBroadcasts', 'url': ULINK, 'extras': f"{name} - Mediathek"}, FETCH_UNO)
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(TARGET, CATI):
	debug_MS("(navigator.listBroadcasts) -------------------------------------------------- START = listBroadcasts --------------------------------------------------")
	debug_MS(f"(navigator.listBroadcasts) ### TARGET = {TARGET} ### GENRE = {CATI} ###")
	STATE_JN = 'EINGEBLENDET' if showJOYN is True else 'AUSGEBLENDET'
	STATE_RT = 'EINGEBLENDET' if showRTL is True else 'AUSGEBLENDET'
	debug_MS(f"(navigator.listChannels) --- JOYN Mediathek  - Sender {STATE_JN} ---")
	debug_MS(f"(navigator.listChannels) --- RTLPLUS Mediathek - Sender {STATE_RT} ---")
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, SENDING = ([] for _ in range(4))
	UNIKAT, PAGE_NUMBER, NEXT_PAGE, counter = set(), 1, None, 0
	while PAGE_NUMBER > 0:
		content = getContent(TARGET, queries='TEXT') if PAGE_NUMBER == 1 else getContent(NEXT_PAGE, queries='TEXT')
		if 'nach-datum/' in TARGET or 'nach-sender/' in TARGET:
			results = re.findall(r'''<div class=["']tips-teaser-container["'](.*?)</section>''', content, re.S)
		elif TARGET.endswith('mediathek/'):
			results = re.findall(r'''<div class=["']content-area["']>(.*?)<div class=["']swiper-pagination["']>''', content, re.S)
		else:
			results = re.findall(r'''<div id=["']mediacenter-genre-container["']>(.*?)</section>''', content, re.S)
		for chtml in results:
			spl = chtml.split('tips-teaser category-tips')
			for i in range(1, len(spl), 1):
				entry= spl[i].replace('\/', '/')
				if not re.search(r'''<div class=["']channel-logo["']>''', entry, re.S): continue
				dbg_section = '<div class="tips-teaser__bottom__wrapper">'
				debug_MS(f"(navigator.listBroadcasts[1]) xxxxx ENTRY-01 : {entry.split(dbg_section)[0]} xxxxx")
				matchNAE = re.compile(r'''class=["']tips-teaser__bottom__title["'].+?>([^<]+)</span>''', re.S).findall(entry)
				matchSUB = re.compile(r''' title=["']([^"']+)"''', re.S).findall(entry)
				TITLE_1 = TVSHOW_1 = cleaning(matchNAE[0])
				if matchNAE and matchSUB:
					FIRST, LAST = matchNAE[0].strip(), matchSUB[0].strip()
					checking = cleaning(LAST.replace(FIRST, ''))
					TITLE_1 = cleaning(FIRST) if checking == "" else f"{cleaning(FIRST)} - {checking}"
				matchGEN = re.compile(r'''class=["']detail-genre["']>([^<]+)</span>''', re.S).findall(entry)
				GENRE_1 = matchGEN[0] if matchGEN else None
				CHANNEL = re.compile(r'''<div class=["']channel-logo["']>(.*?)</div>''', re.S).findall(entry)[0]
				matchCHA = re.compile(r'''title=["'](.*?)["'] loading=''', re.S).findall(CHANNEL)[0]
				STUDIO_1, STATION_1 = cleanStation(matchCHA)
				# "event_label":"https:\/\/www.tvspielfilm.de\/mediathek\/mein-suesses-geheimnis,11656496.html",
				matchEVT = re.compile(r'''["']event_action["']:["']pageElement.clickInternal["'],["']event_label["']:["'](http[^"']+)["'],["']pageElementId["']:''', re.S).findall(entry)
				WLINK_1 = matchEVT[0] if matchEVT else None
				if WLINK_1 is None or WLINK_1 and (WLINK_1 in UNIKAT or WLINK_1[:-1].endswith('mediathek')):
					continue
				UNIKAT.add(WLINK_1)
				# background-image: url(https://img.tvspielfilm.de/3d/b6/1e/681463b4bbd6b704491eb63d.jpeg?im=Crop,rect=(0,0,1107,729),gravity=Center;Resize,width=632);
				matchIMG = re.compile(r'background-image: url\((https://img.tvspielfilm.de/.*?)\);', re.S).findall(entry)
				# vorh. Bild-Grössen (ab 16.07.23): _159.jpg // _164.jpg // _245.jpg // _300.jpg // _456.jpg // _476.jpg // _600.jpg // _632.jpg // _640.jpg // _780.jpg
				THUMB_1 = matchIMG[0].split('?im=')[0] if matchIMG else ""
				if showARTE is False and STUDIO_1.upper() in ARTEEX: continue
				if showJOYN is False and STUDIO_1.upper() in JOYNEX: continue
				if showSERVUS is False and STUDIO_1.upper() in SERVUSEX: continue
				if showTELE is False and STUDIO_1.upper() in TELEEX: continue
				if showRTL is False and STUDIO_1.upper() in RTLEX: continue
				counter += 1
				COMBI_FIRST.append([int(counter), TITLE_1, TVSHOW_1, THUMB_1, WLINK_1, GENRE_1, STUDIO_1, STATION_1])
				COMBI_LINKS.append([int(counter), WLINK_1])
		LOAD_MORE = re.compile(r'''<button data-url=["']([^"']+)["'] class=["']load-more["'] id=["'](?:tips-teaser-load-more|mediacenter-genre-load-more)["']''', re.S).findall(content)
		if LOAD_MORE and len(LOAD_MORE[0]) > 0: # id="tips-teaser-load-more" || id="mediacenter-genre-load-more"
			NEXT_PAGE = f"{BASE_URL}{LOAD_MORE[0]}" if LOAD_MORE[0][:4] != 'http' else LOAD_MORE[0] if LOAD_MORE[0][:4] == 'http' else None
			debug_MS(f"(navigator.listBroadcasts[1]) PAGES ### NOW GET NEXTPAGE : {NEXT_PAGE} ###")
			PAGE_NUMBER, FAILURE = PAGE_NUMBER.__add__(1) if NEXT_PAGE else 0, False if NEXT_PAGE else True
			if FAILURE is True: break
		else: break
	if COMBI_FIRST:
		COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_FIRST or COMBI_SECOND: # Zähler NULL ist immer die Nummerierungder Listen 1+2
		RESULT = [ac + bd for ac in COMBI_FIRST for bd in COMBI_SECOND if ac[0] == bd[0] and ac[4] == bd[3]] # Zusammenführung von Liste1 und Liste2 - wenn die Nummer an erster Stelle(0) und die LINK-ID an vierter Stelle(3) überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listBroadcasts[3]) XXXXX RESULT-03 : {RESULT} XXXXX")
		RESULT = sorted(RESULT, key=lambda vu: vu[15], reverse=True) if TARGET.endswith('mediathek/') else sorted(RESULT, key=lambda pn: int(pn[0]))
		for xev in RESULT: # 0-7 = Liste1 || 8-22 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listBroadcasts[3]) ### Anzahl : {len(xev)} || Eintrag : {xev} ###")
			(Note_1, Note_2, Note_3), (season, episode, aired, year, Genre2, genre, mpaa) = ("" for _ in range(3)), (None for _ in range(7))
			if len(xev) > 8: ### Liste2 beginnt mit Nummer:8 ###
				name, seriesname, image, Link1, Genre1, studio, station = xev[1], xev[2], xev[3], xev[4], xev[5], xev[6], xev[7]
				tagline, description, Link2, imdb, SerieEpis, added, OrderDay, duration, CouYearGen, director, writer, cast, mpaa, transmitter = \
					xev[9], xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18], xev[19], xev[20], xev[21], xev[22]
			else: continue
			if SerieEpis:
				matchSE = re.search('(Staffel:? |S)(\d+)', SerieEpis) # Staffel 12, Folge 05 // Staffel 14, Folge 9b/8 // Folge 1022
				if matchSE: season = matchSE.group(2).zfill(2)
				matchEP = re.search('(Episode:? |Folge:? |E)(\d+)', SerieEpis) # Staffel 12, Folge 05 // Staffel 14, Folge 9b/8 // Folge 1022
				if matchEP: episode = matchEP.group(2).zfill(2)
				Note_1 = translation(30632).format(SerieEpis)
			aired, Note_2 = added[4:14] if added else None, translation(30633).format(added) if added else "" # FirstAired
			if showDATE and added: name = f"{added[4:10]}  {name}" # Added1 = Sa. 11.02.2023 || Added2 = Sa. 11.02.2023 || ergebnis = 11.02.
			if CouYearGen:
				matchYR = re.search('(\d+)', CouYearGen) # D 2021 | Krimi
				year = matchYR.group(1) if matchYR else None
				name = f"{name} - {CouYearGen.split(' |')[0]}"
				Genre2 = CouYearGen.split('| ')[1] if '|' in CouYearGen else None
			if studio != "":
				Note_3 = translation(30634).format(studio) if description != "" else translation(30635).format(studio)
			FullGenres = Genre2 if Genre2 else Genre1
			if FullGenres:
				EditedGenres = FullGenres.replace('Krankenhaus', 'Krankenhauss').replace('nalfilm', '').replace('saga', '').replace('Sci-Fi', 'Science~Fiction').replace('TV-', '').replace('Vorschul', 'Vorschule')
				genre = ' / '.join(sorted([re.sub(r'(sserie|serie|sreihe|reihe)', '', eg) for eg in EditedGenres.split('-')])) # Krankenhausserie = 'serie+reihe' aus Genre entfernen
			mpaa = None if mpaa and str(mpaa).startswith('0 ') else mpaa
			name = f"{name}  {station}" if showCHANNEL and station != "" else name
			#if transmitter and transmitter.startswith('https://plus.rtl.de'):
				#videoHUB = re.search('(\d+)', transmitter.split('-')[-1]) # https://plus.rtl.de/video-tv/shows/denn-sie-wissen-nicht-was-passiert-die-jauch-gottschalk-schoeneberger-show-803481
				#if videoHUB:
					#PREDICATE = 'movie' if 'filme/' in LINK else 'episode' # shows + serien
					#uvz = f"plugin://plugin.video.tvnow.de/?action=listPage&id=rrn:watch:videohub:format:{videoHUB.group(1)}"
					#folder = True
				#else: continue
			#else:
			plot = Note_1+Note_2+description+Note_3
			cineType = 'episode' if str(episode).isdecimal() else 'movie'
			debug_MS(f"(navigator.listBroadcasts[4]) ##### TITLE : {name} || STAFFEL : {season} || EPISODE : {episode} || YEAR : {year} || THUMB : {image} #####")
			debug_MS(f"(navigator.listBroadcasts[4]) ##### OR-LINK : {Link1} || VIDEO : {transmitter} || STUDIO : {studio} || RATING : {imdb} #####")
			FETCH_UNO = create_entries({'Title': name, 'Tagline': tagline, 'Plot': plot, 'Duration': duration, 'Season': season, 'Episode': episode, 'Aired': aired, 'Year': year, \
				'Genre': genre, 'Director': director, 'Writer': writer, 'Cast': cast, 'Rating': imdb, 'Mpaa': mpaa, 'Studio': studio, 'Mediatype': cineType, 'Image': image, 'Reference': 'Single'})
			addDir({'mode': 'playCODE', 'IDENTiTY': Link1}, FETCH_UNO, False)
			SENDING.append({'filtrate': Link1, 'name': name, 'tvshow': seriesname, 'station': studio, 'direct': transmitter})
		preserve(WORKS_FILE, SENDING)
	else:
		failing(f'(navigator.listBroadcasts) ##### NO BROADCAST-LIST - NO ENTRY FOR: "{CATI}" FOUND #####')
		return dialog.notification(translation(30525), translation(30526).format(CATI), icon, 10000)
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSubstances(MURLS):
	debug_MS("(navigator.listSubstances) -------------------------------------------------- START = listSubstances --------------------------------------------------")
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.llistSubstances[2]) XXXXX CONTENT-02 : {COMBI_DETAILS} XXXXX")
		debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
		for number, WLINK_2, elem in COMBI_DETAILS:
			if elem is not None:
				(DESC_2, SORTDAY_2), (DIRECTOR_2, WRITER_2, STAFF_2) = ("" for _ in range(2)), ([] for _ in range(3))
				TAG_MARKER, TAGLINE_2, IMDB_2, EPIS_2, DATE_2, DURATION_2, INFOS_2, MPAA_2, PLAYLINK_2 = (None for _ in range(9))
				articles = re.findall(r'''<article class=["']broadcast-detail["'](.*?)</article>''', elem, re.S)
				for item in articles:
					item, dbg_section = item.replace('\/', '/'),'<section class="broadcast-detail__buttons">'
					debug_MS(f"(navigator.listSubstances[2]) xxxxx ITEM-02 : {item.split(dbg_section)[0]} xxxxx")
					TEASER = re.findall(r'''<section class=["']broadcast-detail__description["'](.*?)</section>''', item, re.S)[0]
					TAG_01 = re.compile(r'''<p class=["']headline["']>([^<]+)</p>''', re.S).findall(TEASER) # Filme & Serien
					TAG_02 = re.compile(r'''<h2 class=["']broadcast-info["']>([^<]+)</h2>''', re.S).findall(item) # z.B. Neuanfänge (2)
					TAG_03 = re.compile(r'''<ul class=["']headline prelude["']>(.*?)</ul>''', re.S).findall(TEASER) # z.B. Küchlein, Kopfstand und Krokan
					if TAG_03 and len(TAG_03[0]) > 10:
						TAG_SPECIAL = re.compile(r'<li[^>]*>(.*?)</li>', re.S).findall(TAG_03[0])
						TAG_MARKER = '[CR]'.join(['• '+cleaning(re.sub(' +', ' ', tagpart.replace('\n', ' ').replace('\t', ' '))) for tagpart in TAG_SPECIAL])
					TAGLINE_2 = cleaning(TAG_01[0].replace('\n', ' ').replace('\t', ' ')) if TAG_01 else cleaning(TAG_02[0].replace('\n', ' ').replace('\t', ' ')) if TAG_02 and \
						not TAG_02[0].startswith('Mehr zu ') else TAG_MARKER if TAG_MARKER else None
					if TAGLINE_2 and len(TAGLINE_2) > 125 and TAG_MARKER is None:
						TAGLINE_2 = TAGLINE_2[:125]+'...'
					agreeDESC = re.compile(r'<p>(.*?)</p>', re.S).findall(TEASER)
					if agreeDESC and len(agreeDESC[0]) > 10:
						DESC_2 += '[CR][CR]'.join([cleaning(re.sub(' +', ' ', teas.replace('\n', ' ').replace('\t', ' '))) for teas in agreeDESC])
						DESC_2 = DESC_2.rstrip()[:-4] if DESC_2.endswith('[CR]') else DESC_2
					agreeGUES = re.compile(r'''<div class=["']broadcast-info-guests["']>(.*?)</section>''', re.S).findall(item)
					if agreeGUES and '<li' in agreeGUES[0]:
						STORY_02 = re.compile(r'<li[^>]*>(.*?)</li>', re.S).findall(agreeGUES[0])
						if STORY_02 and len(STORY_02[0]) > 1:
							prefix = '[CR][CR]' if agreeDESC and len(agreeDESC[0]) > 10 else ""
							DESC_2 += prefix+'[CR]'.join([cleaning(cleanGuest(mods)) for mods in STORY_02])
							DESC_2 = DESC_2.rstrip()[:-4] if DESC_2.endswith('[CR]') else DESC_2
					agreeRAT = re.compile(r'''class=["']content-rating__imdb-rating__rating-value["']>([^<]+)</div>''', re.S).findall(item)
					IMDB_2 = agreeRAT[0].strip().replace(',', '.') if agreeRAT and str(agreeRAT[0]).strip().replace(',', '').isdecimal() else None # class="content-rating__imdb-rating__rating-value">7,3</div>
					agreeSER = re.compile(r'''<section class=["']serial-info["']>(.*?)</section>''', re.S).findall(item)
					EPIS_2 = cleaning(re.sub(r'\<.*?>', '', agreeSER[0])) if agreeSER else None # Folge 4
					SECTOR_1 = re.compile(r'''<div class=["']text-wrapper["']>(.*?)<section class=["']broadcast-detail__stage''', re.S).findall(item)
					matchONE = cleaning(SECTOR_1[0]) if SECTOR_1 else None
					if matchONE:
						agreeTIME = re.compile(r'Ausstrahlung:\ ([^<]+)</span>', re.S).findall(matchONE)
						agreeDT = agreeTIME[0].strip()[:6] if agreeTIME else None # TV-Ausstrahlung: 18.01. | 90 Min.
						if agreeDT and str(agreeDT)[:2].isdecimal():
							YEARS_2 = datetime.now().strftime('%Y') # Sendung aus diesem Monat = Aktuelles Jahr
							if str(datetime.now().month) == '12' and str(agreeDT[3:5]) == '01': # Sendung aus dem Monat Januar // Aktueller Monat ist Dezember = Aktuelles Datum plus 32 Tage
								YEARS_2 = (datetime.now() + timedelta(days=32)).strftime('%Y')
							elif str(datetime.now().month) == '1' and str(agreeDT[3:5]) == '12': # Sendung aus dem Monat Dezember // Aktueller Monat ist Januar = Aktuelles Datum minus 32 Tage
								YEARS_2 = (datetime.now() - timedelta(days=32)).strftime('%Y')
							available = datetime(*(time.strptime(f"{agreeDT}{str(YEARS_2)}", '%d.%m.%Y')[0:6])) # 18.01.+JAHR
							DATE_2 = available.strftime('%a. %d.%m.%Y')
							SORTDAY_2 = available.strftime('%Y.%m.%d')
							for av in (('Mon', translation(32201)), ('Tue', translation(32202)), ('Wed', translation(32203)), ('Thu', translation(32204)),\
								('Fri', translation(32205)), ('Sat', translation(32206)), ('Sun', translation(32207))):
								DATE_2 = DATE_2.replace(*av)
						MINS_2 = re.search('([0-9]+) Min.', agreeTIME[0]) if agreeTIME else None # 90 Min.
						DURATION_2 = str(int(MINS_2.group(1)) * 60) if MINS_2 else None
						agreeCYG = re.compile(r'''<span class=["']text-row["']>([^<]+)</span>''', re.S).findall(matchONE)
						INFOS_2 = cleaning(agreeCYG[0]) if agreeCYG else None # D 2021 | Krimi
					if DURATION_2 is None and DESC_2 == "": continue # Quelltextleichen ohne weiterführende Verbindung entfernen
					SECTOR_2 = re.compile(r'''broadcast-cast-crew-box["'] data-tracking-id=["']castAndCrew["'](.*?)</section>''', re.S).findall(item)
					matchTWO = cleaning(SECTOR_2[0]) if SECTOR_2 else None
					if matchTWO:
						AREA_UNO = re.compile(r'''<p class=["']headline(?: headline--spacing)?["']>Infos(.*?)</dl>''', re.S).findall(matchTWO)
						if AREA_UNO:
							agreeAGE = re.compile(r'<dt>FSK</dt>\s*<dd>([^<]+)</dd>', re.S).findall(AREA_UNO[0])
							MPAA_2 = cleaning(agreeAGE[0]) if agreeAGE else None # <dd>ab 10 Jahren</dd>
						AREA_DUE = re.compile(r'''<p class=["']headline(?: headline--spacing)?["']>Crew(.*?)</dl>''', re.S).findall(matchTWO)
						if AREA_DUE: # <dt>   Drehbuch   </dt> // <dd>Hans G. Raeth</dd>
							agreeDIR = re.compile(r'<dt>\s*Regie\s*</dt>\s*<dd>(.*?)</dd>', re.S).findall(AREA_DUE[0]) # <dt>Regie</dt> // <dd>Philipp Osthus, Andreas Menck, Florian Gottschick, Felix Ahrens</dd>
							DIRECTOR_2 = ', '.join([cleaning(re.sub(r'\<.*?>', '', dirs.replace('\n', ' ').replace('\t', ' ').replace('  ', ''))) for dirs in agreeDIR]) if agreeDIR else []
							agreeCREA = re.compile(r'<dt>\s*Drehbuch\s*</dt>\s*<dd>(.*?)</dd>', re.S).findall(AREA_DUE[0]) # <dt>Drehbuch</dt> // <dd>Philipp Osthus, Andreas Menck, Florian Gottschick, Felix Ahrens</dd>
							WRITER_2 = ', '.join([cleaning(re.sub(r'\<.*?>', '', creas.replace('\n', ' ').replace('\t', ' ').replace('  ', ''))) for creas in agreeCREA]) if agreeCREA else []
						AREA_TRE = re.compile(r'''<p class=["']headline(?: headline--spacing)?["']>Cast(.*?)</dl>''', re.S).findall(matchTWO)
						if AREA_TRE: # <dt>Ina Becker</dt> // <dd>Andrea Sawatzki</dd>
							agreeACT = re.compile(r'''<dt>(.*?)</dt>\s*<dd>(.*?)</dd>''', re.S).findall(AREA_TRE[0])
							for index, person in enumerate(agreeACT, 1):
								actor = {'name': cleaning(re.sub(r'\<.*?>', '', person[1])), 'role': cleaning(re.sub(r'\<.*?>', '', person[0])), 'order': index, 'thumb': ''}
								if actor['name'] not in ['' , None]:
									if KODI_ov20:
										STAFF_2.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
									else: STAFF_2.append(actor)
					agreePLAY = re.compile(r'''["']event_action["']:["']pageElement.clickExternal["'],["']event_label["']:["'](http[^"']+)["'],["']pageElementId["']:''', re.S).findall(item)
					PLAYLINK_2 = agreePLAY[0] if agreePLAY else None
					COMBI_THIRD.append([int(number), TAGLINE_2, DESC_2, WLINK_2, IMDB_2, EPIS_2, DATE_2, SORTDAY_2, DURATION_2, INFOS_2, DIRECTOR_2, WRITER_2, STAFF_2, MPAA_2, PLAYLINK_2])
	return COMBI_THIRD

def playCODE(ORIGIN):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	FINAL_URL, CLEAR_TITLE, TVSHOW, LINK = (False for _ in range(4))
	for elem in preserve(WORKS_FILE):
		if elem['filtrate'] != '00' and elem['filtrate'] == ORIGIN:
			CLEAR_TITLE = re.sub('\[.*?\]', '', elem['name']) if elem.get('name', '') else False
			TVSHOW, STATION, LINK = elem['tvshow'], elem['station'], elem['direct']
			debug_MS(f"(navigator.playCODE) ### WORKS_FILE-Line : {elem} ###")
	LINK = LINK.replace('http://', 'https://') if LINK and LINK[:7] == 'http://' else LINK
	log("(navigator.playCODE) --- START WIEDERGABE ANFORDERUNG ---")
	log("(navigator.playCODE[1]) frei")
	log(f"(navigator.playCODE[1]) ~~~ AbspielLink-01 (Original) : {LINK} ~~~")
	log("(navigator.playCODE[1]) frei")
	if LINK and LINK.startswith('https://www.ardmediathek.de'):
		return ArdGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.arte.tv'):
		submitCode = re.compile('arte.tv/de/videos/([^/]+)/', re.S).findall(LINK)[0]
		FINAL_URL = f"plugin://plugin.video.tyl0re.arte/?mode=playVideo&url={submitCode}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'ARTE.TV', 'ARTE.TV - Plugin')
	elif LINK and LINK.startswith('https://www.joyn.de'):
		return JoynGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.servustv.com'):
		submitCode = LINK.split('/')[-2].replace('/', '').upper()
		FINAL_URL = f"plugin://plugin.video.servustv_com/?mode=playVideo&url={submitCode}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'ServusTV.com', 'ServusTV - Plugin')
	elif LINK and LINK.startswith('https://tele5.de'): # Original: https://tele5.de/mediathek/william-shatners-the-captains-close-up/william-shatners-the-captains-close-up-scott-bakula
		# REQUEST: https://de-api.loma-cms.com/feloma/videos/william-shatners-the-captains-close-up-scott-bakula/?filter[show.slug]=william-shatners-the-captains-close-up&environment=tele5
		show, folge = LINK.split('mediathek/')[1].split('/')[0], LINK.split('/')[-1].replace('/', '')
		result = getContent(f"https://de-api.loma-cms.com/feloma/videos/{folge}/?filter[show.slug]={show}&environment=tele5", REF=LINK)
		if result.get('blocks', '') and result.get('blocks', {})[0].get('videoId', '') and str(result['blocks'][0]['videoId']).isdecimal():
			FINAL_URL = f"plugin://plugin.video.tele5_de/play/{result['blocks'][0]['videoId']}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'TELE 5 Mediathek', 'TELE 5 - Plugin')
	#elif LINK and LINK.startswith('https://plus.rtl.de'):
	#	return FINAL_URL
	elif LINK and LINK.startswith('https://www.welt.de'):
		return WeltGetVideo(LINK)
	elif LINK and LINK.startswith(('https://www.3sat.de', 'https://www.phoenix.de', 'https://www.zdf.de', 'https://www.zdfheute.de')):
		return ZdfGetVideo(LINK)
	else:
		failing(f"(navigator.playCODE[2]) AbspielLink-00 : Der Provider *{urlparse(LINK).netloc}* konnte nicht aufgelöst werden !!!")
		dialog.notification(translation(30521).format('LINK'), translation(30527).format(urlparse(LINK).netloc), icon, 10000)
		log("(navigator.playCODE[2]) --- ENDE WIEDERGABE ANFORDERUNG ---")

def addDir(params, listitem, folder=True):
	uws = build_mass(HOST_AND_PATH, params)
	listitem.setPath(uws)
	if params.get('mode') == 'playCODE':
		listitem.addContextMenuItems([(translation(30654), 'Action(Queue)')])
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
