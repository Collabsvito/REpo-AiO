﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import time
import base64
from datetime import datetime, timedelta
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import parse_qsl, urlparse, urlencode, quote_plus, unquote_plus
from urllib.request import urlopen
from functools import reduce
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


socket.setdefaulttimeout(30)
HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_folder						= xbmcvfs.translatePath(addon.getAddonInfo('path'))
addon_profile					= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
WORKS_FILE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'episode_data.json'))
defaultFanart						= os.path.join(addon_folder, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addon_folder, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addon_folder, 'resources', 'media', '')
enable_adaptive				= addon.getSetting('use_adaptive') == 'true'
prefer_stream					= int(addon.getSetting('prefer_stream'))
dates_linkes						= addon.getSetting('show_dates') == 'true'
canal_linkes						= addon.getSetting('show_channel') == 'true'
show_arte							= (True if addon.getSetting('show_ARTE') == 'true' else False)
show_joyn							= (True if addon.getSetting('show_JOYN') == 'true' else False)
show_servus						= (True if addon.getSetting('show_SERVUS') == 'true' else False)
show_rtlp							= (True if addon.getSetting('show_RTLPLUS') == 'true' else False)
using_fanart						= addon.getSetting('use_fanart') == 'true'
enable_tune						= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
JOYN_STATICS					= addon.getSetting('joyn_staticCODE')
ARTEEX								= ['ARTE']
JOYNEX								= ['DMAX', 'KABEL.1', 'PROSIEBEN', 'PROSIEBEN MAXX', 'SAT.1', 'SAT.1 GOLD', 'SIXX']
SERVUSEX							= ['SERVUSTV']
RTLPEX								= ['NITRO', 'RTL', 'RTL 2', 'RTLUP', 'VOX', 'SRTL', 'TOGGO']
KODI_BUILD						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2])
BASE_URL							= 'https://www.tvspielfilm.de'
BASE_JOYN						= 'https://www.joyn.de/'
WEB_AGENT						= 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:152.0) Gecko/20100101 Firefox/152.0'
WEB_HEADER					= {'User-Agent': WEB_AGENT, 'Cache-Control': 'public, max-age=300', 'Accept': '*/*', 'DNT': '1', 'Upgrade-Insecure-Requests': '1', 'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'sec-ch-ua-platform': 'Windows'}
API_ARD								= 'https://api.ardmediathek.de/page-gateway/pages/'
API_ZDF_OLD						= 'https://api.zdf.de'
API_ZDF_NEW					= 'https://zdf-prod-futura.zdf.de/mediathekV2'
API_JOYN							= 'https://www.joyn.de/_next/data/' # bSD_wV8RvFrdlX8nHD5vh # CODE of the Webpage

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(plugin, body):
	return f"{plugin}?{urlencode(body)}"

def track_several(stacks, method='GET', queries='TEXT', headers={}, timeout=5, redirects=True, workers=25):
	COMBI_NEW, number, counter, fixation = [], len(stacks), 0, requests.Session()
	fixation.mount('https://', HTTPAdapter(pool_connections=int(number), pool_maxsize=int(number), pool_block=True)) # Pool-Verbindungen und -Grösse auf tatsächlichen Inhalt festlegen, um Fehlermeldungen zu vermeiden
	def download(pos, link):
		try:
			response = fixation.request(method, link, headers=headers, allow_redirects=redirects, timeout=timeout)
			response.raise_for_status()
			debug_MS(f"(common.track_several[1]) === POS : {pos} || STATUS : {response.status_code} || URL : {link} || HEADER : {response.request.headers} ===")
			return [pos, link, response.text]
		except Exception as exc_uno:
			failing(f"(common.track_several[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === LINK : {link} === FAILURE : {exc_uno} #####")
			return [pos, link, None]
	with ThreadPoolExecutor(max_workers=workers) as executor:
		debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++++")
		picker = [executor.submit(download, single['Count_1'], single['Link_1']) for single in stacks]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for future, section in zip(as_completed(picker), stacks):
			counter += 1
			try:
				COMBI_NEW.append(future.result())
			except Exception as exc_due:
				if counter == 1:
					dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(exc_due), icon, 12000)
				failing(f"(common.track_several[2]) ERROR - EXEPTION - ERROR ##### POS : {section['Count_1']} === LINK : {section['Link_1']} === FAILURE : {exc_due} #####")
				executor.shutdown()
		if COMBI_NEW:
			matching = [flop for flop in COMBI_NEW[:] if flop[2] is None]
			if len(matching) == number or len(matching) > 9:
				dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 12000)
	return COMBI_NEW

def track_content(url, method='GET', queries='JSON', headers={}, redirects=True, data=None, json=None, timeout=30):
	attempts, (ANSWER, new_code) = 0, (None for _ in range(2))
	if url.startswith('http'):
		try:
			response = requests.request(method, url, headers=headers, allow_redirects=redirects, timeout=timeout)
			ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
			debug_MS(f"(common.track_content[1]) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
		except requests.exceptions.RequestException as exc:
			failing(f"(common.track_content[1]) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {exc} #####")
			dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 12000)
			return sys.exit(0)
	else:
		def _track_collect(link_suffix, beam_token=None):
			debug_MS(f"(common.collect_token[2]) === Link_Suffix : {link_suffix} || Transfer_Token : {beam_token} ===")
			recent_link = API_JOYN+beam_token+link_suffix if beam_token else API_JOYN+addon.getSetting('joyn_staticCODE')+link_suffix
			return recent_link
		while not ANSWER and attempts < 3: # 2 x Wiederholungen (gesamt=3) für den URL-Request ::: da der Code für die API_BASE evtl. wieder geändert wurde
			attempts += 1
			try:
				move_link = _track_collect(url, new_code)
				response = requests.request(method, move_link, headers=headers, allow_redirects=redirects, timeout=timeout)
				response.raise_for_status()
				VALID_JSON = response.json() if queries == 'JSON' else None
				ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
				debug_MS(f"(common.track_content[2]) === CALLBACK === RETRIES_no : {attempts} === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
			except Exception as exc: # No JSON object could be decoded
				failing(f"(common.track_content[2]) ERROR - CURRENT_TOKEN - ERROR ##### RETRIES_no : {attempts} === URL : {url} === FAILURE : {exc} #####")
				contents = requests.get(f"{BASE_JOYN}mediatheken", headers=headers, allow_redirects=redirects, timeout=10)
				scanning = re.compile(r'''</script><script src=["']/_next/static/([^/]+)/_ssgManifest.js["']''', re.S).findall(contents.text)
				#scanning = re.compile(r'''["']query["']:.*?,["']buildId["']:["']([^"']+)["'],["']isFallback["']''', re.S).findall(contents.text)
				if scanning:
					new_code = scanning[0]
					addon.setSetting('joyn_staticCODE', new_code)
				elif attempts > 1 and not scanning:
					attempts += 2
					dialog.notification(translation(30521).format('URL'), translation(30524), icon, 12000)
					break
				time.sleep(2)
	return ANSWER

def plugin_operate(MARKING):
	check_uno = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
	answer_uno, answer_due = json.loads(check_uno), json.loads(f'{{"error": "{MARKING} NOT FOUND"}}')
	if not "error" in answer_uno.keys() and answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is False:
		try:
			xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{MARKING}","enabled":true}}}}')
			failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####")
		except: pass
		del answer_due
		check_due = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
		answer_due = json.loads(check_due)
	if (answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is True) or (answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is True):
		return True
	if answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is False:
		dialog.ok(addon_id, translation(30501).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Eine automatische Aktivierung ist leider NICHT möglich !!! #####")
	if "error" in answer_uno.keys() or "error" in answer_due.keys():
		dialog.ok(addon_id, translation(30502).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - INSTALLED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT installiert !!! #####")
	return False

def preserve(storage, data=None):
	if data is not None:
		with open(storage, 'w') as topics:
			json.dump(data, topics, indent=2, sort_keys=True)
	else:
		with open(storage, 'r') as topics:
			arrive = json.load(topics)
		return arrive

def cleaning(text):
	if text is not None:
		for tx in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\xc2\xb7', '-'),
			("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''),
			('&#xC4;', 'Ä'), ('&#xE4;', 'ä'), ('&#xD6;', 'Ö'), ('&#xF6;', 'ö'), ('&#xDC;', 'Ü'), ('&#xFC;', 'ü'), ('&#xDF;', 'ß'), ('&#x201E;', '„'), ('&#xB4;', '´'), ('&#x2013;', '-'), ('&#xA0;', ' '),
			('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
			('&agrave;', 'à'), ('&Agrave;', 'À'), ('&aacute;', 'á'), ('&Aacute;', 'Á'), ('&acirc;', 'â'), ('&Acirc;', 'Â'), ('&egrave;', 'è'), ('&Egrave;', 'È'), ('&eacute;', 'é'), ('&Eacute;', 'É'), ('&ecirc;', 'ê'), ('&Ecirc;', 'Ê'),
			('&igrave;', 'ì'), ('&Igrave;', 'Ì'), ('&iacute;', 'í'), ('&Iacute;', 'Í'), ('&icirc;', 'î'), ('&Icirc;', 'Î'), ('&ograve;', 'ò'), ('&Ograve;', 'Ò'), ('&oacute;', 'ó'), ('&Oacute;', 'Ó'), ('&ocirc;', 'ô'), ('&Ocirc;', 'Ô'),
			('&ugrave;', 'ù'), ('&Ugrave;', 'Ù'), ('&uacute;', 'ú'), ('&Uacute;', 'Ú'), ('&ucirc;', 'û'), ('&Ucirc;', 'Û'), ('&yacute;', 'ý'), ('&Yacute;', 'Ý'),
			('&atilde;', 'ã'), ('&Atilde;', 'Ã'), ('&ntilde;', 'ñ'), ('&Ntilde;', 'Ñ'), ('&otilde;', 'õ'), ('&Otilde;', 'Õ'), ('&Scaron;', 'Š'), ('&scaron;', 'š'), ('&ccedil;', 'ç'), ('&Ccedil;', 'Ç'),
			('–', '-'), ("\\'", "'"), ('&shy;', ''), ('<br/> ', '[CR]'), ('<br/>', '[CR]'), ('Ã¶', 'ö')):
			text = text.replace(*tx)
		text = text.strip()
	return text

def clean_guest(text):
	if text is not None:
		for gt in (('Mit dabei:', '[B]Mit dabei:[/B]'), ('Experte:', '[B]Experte:[/B]'), ('Kommentiert von:', '[B]Kommentiert von:[/B]'),\
			('Moderation:', '[B]Moderation:[/B]'), ('Rateteam:', '[B]Rateteam:[/B]'), ('\n', ' '), ('\t', ' ')):
			text = text.replace(*gt)
	return text

def clean_sender(program):
	# ARD, ZDF, RTL, SAT1, PRO7, K1, RTL2, VOX, TELE5, 3SAT, ARTE, 2NEO, FES, SERVU, RTL-N, DMAX, SIXX, SAT1G, PRO7M, RTLPL, WDR, N3, BR, SWR, HR, MDR, RBB, ALPHA, ZINFO, SUPER, KIKA
	program = program.replace(' Programm', '').replace(' programm', '').replace(' Mediathek', '')
	ChannelCodes = ['ARD','Das Erste','ONE','FES','ZDF','2NEO','ZNEO','2INFO','ZINFO','3SAT','ALPHA','Arte','ARTE','BR','DMAX','HR','Kabel 1','kabel eins','K1',\
		'KIKA','KiKA','MDR','NDR','N3','ORF','PHOEN','PRO7', 'PRO7M','RBB','SAT1','SAT.1','SAT1G','SAT.1G','SERVU','SIXX','SR','SWR','SWR/SR'\
		'WDR','RTL','RTL II','RTL2','RTL Zwei','RTL-N','RTLPL','SRTL','SUPER RTL','SUPER','TOGGO','WELT','VOX']
	if program in ChannelCodes and program != "":
		for sn in ((' ', ''), ('ARD', 'Das Erste'), ('DasErste', 'Das Erste'), ('FES', 'ONE'), ('Arte', 'ARTE'), ('Kabel1', 'Kabel.1'), ('kabeleins', 'Kabel.1'), ('K1', 'Kabel.1'),\
			('KIKA', 'KiKA'), ('2INFO', 'ZDFinfo'), ('ZINFO', 'ZDFinfo'), ('2NEO', 'ZDFneo'), ('ZNEO', 'ZDFneo'), ('3SAT', '3sat'), ('N3', 'NDR'), ('PHOEN', 'PHOENIX'),\
			('PRO7M', 'ProSieben MAXX'), ('PRO7', 'ProSieben'), ('RTLII', 'RTL 2'), ('RTL2', 'RTL 2'), ('RTLZwei', 'RTL 2'), ('RTL-N', 'NITRO'), ('RTLPL', 'RTLup'),\
			('SAT.1G', 'SAT.1 Gold'), ('SAT1G', 'SAT.1 Gold'), ('SAT1', 'SAT.1'), ('SERVU', 'ServusTV'), ('SUPERRTL', 'SRTL'), ('SUPER', 'SRTL')):
			program = program.replace(*sn)
	if program in ['ARD-alpha', 'ALPHA']: program = 'ARD alpha'
	if program in ['SWR', 'SR', 'SWR/SR']: program = 'SWR'
	studio = program.replace('  ', '').strip()
	program = f"({program.strip()})" if program != "" else program
	return (studio, program)

def create_entries(metadata, SIGNS=None):
	listitem = xbmcgui.ListItem(metadata['Title'])
	vinfo = listitem.getVideoInfoTag() if KODI_BUILD >= 20 else {}
	if KODI_BUILD >= 20: vinfo.setTitle(metadata['Title'])
	else: vinfo['Title'] = metadata['Title']
	if metadata.get('Tagline', ''):
		if KODI_BUILD >= 20: vinfo.setTagLine(metadata['Tagline'])
		else: vinfo['Tagline'] = metadata['Tagline']
	description = metadata['Plot'] if metadata.get('Plot') not in ['', 'None', None] else ' '
	if KODI_BUILD >= 20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if str(metadata.get('Duration')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setDuration(int(metadata['Duration']))
		else: vinfo['Duration'] = metadata['Duration']
	if str(metadata.get('Season')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setSeason(int(metadata['Season']))
		else: vinfo['Season'] = metadata['Season']
	if str(metadata.get('Episode')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setEpisode(int(metadata['Episode']))
		else: vinfo['Episode'] = metadata['Episode']
	if metadata.get('Aired', ''):
		if KODI_BUILD >= 20: vinfo.setFirstAired(metadata['Aired'])
		else: vinfo['Aired'] = metadata['Aired']
	if str(metadata.get('Year')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setYear(int(metadata['Year']))
		else: vinfo['Year'] = metadata['Year']
	if metadata.get('Genre', ''):
		if KODI_BUILD >= 20: vinfo.setGenres([metadata['Genre']])
		else: vinfo['Genre'] = metadata['Genre']
	if metadata.get('Director', ''):
		if KODI_BUILD >= 20: vinfo.setDirectors([metadata['Director']])
		else: vinfo['Director'] = metadata['Director']
	if metadata.get('Writer', ''):
		if KODI_BUILD >= 20: vinfo.setWriters([metadata['Writer']])
		else: vinfo['Writer'] = metadata['Writer']
	if metadata.get('Cast', '') and isinstance(metadata.get('Cast'), (list, tuple)):
		if KODI_BUILD >= 20: vinfo.setCast(metadata['Cast'])
		else: listitem.setCast(metadata['Cast'])
	if metadata.get('Rating', ''):
		if KODI_BUILD >= 20: vinfo.setRating(float(metadata['Rating']), 0, 'imdb', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		else: listitem.setRating('imdb', float(metadata['Rating']), 0, True) # LSM.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
	if metadata.get('Mpaa', ''):
		if KODI_BUILD >= 20: vinfo.setMpaa(str(metadata['Mpaa']))
		else: vinfo['Mpaa'] = str(metadata['Mpaa'])
	if metadata.get('Studio', ''):
		if KODI_BUILD >= 20: vinfo.setStudios([metadata['Studio']])
		else: vinfo['Studio'] = metadata['Studio']
	if metadata.get('Mediatype', ''):
		if KODI_BUILD >= 20: vinfo.setMediaType(metadata['Mediatype'])
		else: vinfo['Mediatype'] = metadata['Mediatype']
	picture = metadata.get('Image', icon)
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'fanart': defaultFanart})
	if using_fanart and picture and not artpic in picture:
		listitem.setArt({'fanart': picture})
	if metadata.get('Reference') == 'Single':
		listitem.setProperty('IsPlayable', 'true')
	if KODI_BUILD < 20: listitem.setInfo('Video', vinfo)
	return listitem
