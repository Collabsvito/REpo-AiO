﻿# -*- coding: utf-8 -*-

from .common import *
from .resolver import *


def main_menu():
	for TITLE, PATH in [(30601, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/", 'phase': 'AKTUELL BELIEBT'}),
		(30602, {'mode': 'list_dates', 'extra': 'PASSED'}), (30603, {'mode': 'list_dates', 'extra': 'UPCOMING'}), (30604, {'mode': 'list_dates', 'extra': 'OVERVIEW'}), 
		(30605, {'mode': 'list_channels', 'link': f"{BASE_URL}/mediathek/nach-sender/"}), (30606, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/spielfilme/", 'phase': 'SPIELFILME'}),
		(30607, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/serien/", 'phase': 'SERIEN'}), (30608, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/dokus/", 'phase': 'DOKUS'}), 
		(30609, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/unterhaltung/", 'phase': 'UNTERHALTUNG'}), (30610, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/kinder/", 'phase': 'KINDER'}),
		(30611, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/sport/", 'phase': 'SPORT'}), (30612, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/filter/?irating=6", 'phase': 'TOP IMDB BEWERTET'}), 
		(30613, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/filter/?timeFrom=20:15&timeTo=23:58&channels=ARD,WDR,N3,BR,SWR,HR,MDR,RBB,FES", 'phase': 'PRIMETIME-HIGHLIGHTS ARD+'}),
		(30614, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/filter/?timeFrom=20:15&timeTo=23:58&channels=ZDF,2NEO,ZINFO,3SAT,ARTE", 'phase': 'PRIMETIME-HIGHLIGHTS ZDF+'}),
		(30615, {'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/filter/?timeFrom=20:15&timeTo=23:58&channels=RTL-N,RTL,RTL2,RTLPL,VOX,SUPER,K1,PRO7,PRO7M,SAT1,SAT1G,SIXX,SERVU,TELE5,WELT", 'phase': 'PRIMETIME-HIGHLIGHTS PRIVATE'})]:
		add_views(PATH, create_entries({'Title': translation(TITLE)}))
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30616), 'Image': f"{artpic}settings.png"}), False)
		if enable_adaptive and plugin_operate('inputstream.adaptive'):
			add_views({'mode': 'ietuning'}, create_entries({'Title': translation(30617), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_dates(extra):
	if extra == 'OVERVIEW':
		for ii in range(-14, 15, 1):
			WU = (datetime.now() - timedelta(days=ii)).strftime('%Y-%m-%d') # Datum für URL // 2023-07-12
			WD = (datetime.now() - timedelta(days=ii)).strftime('%a, %d.%m.') # Datum mit engl. Wochentagskürzel ohne Jahr // Sun, 16.07.
			for tt in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), \
				('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))): WD = WD.replace(*tt)
			if ii == 0: add_views({'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/nach-datum/?date={WU}", 'phase': WD}, create_entries({'Title': translation(32108).format(WD)}))
			else: add_views({'mode': 'list_broadcasts', 'link': f"{BASE_URL}/mediathek/nach-datum/?date={WU}", 'phase': WD}, create_entries({'Title': WD}))
	else:
		if extra == 'PASSED':
			frames = ','.join([(datetime.now() - timedelta(days=ii)).strftime('%Y-%m-%d') for ii in reversed(range(0, 15, 1))]) # Immer höchstes Datum zuerst auflisten - daher hier 'reversed'
		elif extra == 'UPCOMING':
			frames = ','.join([(datetime.now() + timedelta(days=ii)).strftime('%Y-%m-%d') for ii in range(1, 15, 1)]) # Immer höchstes Datum zuerst auflisten
		return list_broadcasts(f"{BASE_URL}/mediathek/filter/?dates={frames}", 'VERPASST IN DEN MEDIATHEKEN' if extra == 'PASSED' else 'VORAB IN DEN MEDIATHEKEN')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_channels(target):
	debug_MS("(navigator.list_channels) -------------------------------------------------- START = list_channels --------------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.list_channels) ### SENDER-SORTIERUNG = Alle Sender in TV-Spielfilm ###")
	STATE_JN, STATE_RT = 'EINGEBLENDET' if show_joyn is True else 'AUSGEBLENDET', 'EINGEBLENDET' if show_rtlp is True else 'AUSGEBLENDET'
	debug_MS(f"(navigator.list_channels) --- JOYN Mediathek  - Sender {STATE_JN} ---")
	debug_MS(f"(navigator.list_channels) --- RTLPLUS Mediathek - Sender {STATE_RT} ---")
	block_table = track_content(target, 'GET', 'TEXT', WEB_HEADER)
	results = re.findall(r'''<div class=["']mediathek-channel-slider__container["'](.*?)</div>''', block_table, re.S)[0]
	navigation = re.findall(r'''title=["']([^"']+)["'] href=["'](https?://.*?mediathek/.*?)["']\s*class=["']js-track-link''', results, re.S)
	for title, ulink in navigation:
		name, station = clean_sender(title) # SUPER RTL Mediathek
		if show_arte is False and name.upper() in ARTEEX: continue
		if show_joyn is False and name.upper() in JOYNEX: continue
		if show_servus is False and name.upper() in SERVUSEX: continue
		if show_rtlp is False and name.upper() in RTLPEX: continue
		debug_MS(f"(navigator.list_channels[1]) ##### NAME : {name} || LINK : {ulink} ##### ")
		fetch_items = create_entries({'Title': translation(30631).format(name), 'Image': f"{artpic}{name.lower().replace(' ', '')}.png", 'Studio': name})
		add_views({'mode': 'list_broadcasts', 'link': ulink, 'phase': f"{name} - Mediathek"}, fetch_items)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_broadcasts(target, phase):
	debug_MS("(navigator.list_broadcasts) -------------------------------------------------- START = list_broadcasts --------------------------------------------------")
	debug_MS(f"(navigator.list_broadcasts) ### TARGET = {target} ### RUBRIK = {phase} ###")
	STATE_JN, STATE_RT = 'EINGEBLENDET' if show_joyn is True else 'AUSGEBLENDET', 'EINGEBLENDET' if show_rtlp is True else 'AUSGEBLENDET'
	debug_MS(f"(navigator.list_channels) --- JOYN Mediathek  - Sender {STATE_JN} ---")
	debug_MS(f"(navigator.list_channels) --- RTLPLUS Mediathek - Sender {STATE_RT} ---")
	unikat, merging, scrolling, counter, (combo_links, combo_uno, combo_due, combo_send) = set(), {}, 1, 0, ([] for _ in range(4))
	while scrolling > 0:
		block_table = track_content(target if scrolling == 1 else next_page, 'GET', 'TEXT', WEB_HEADER)
		if 'nach-datum/' in target or 'nach-sender/' in target:
			results = re.findall(r'''<div class=["']tips-teaser-container["'](.*?)</section>''', block_table, re.S)
		elif target.endswith('mediathek/'):
			results = re.findall(r'''<div class=["']content-area["']>(.*?)<div class=["']swiper-pagination["']>''', block_table, re.S)
		else:
			results = re.findall(r'''<div id=["']mediacenter-genre-container["']>(.*?)</section>''', block_table, re.S)
		for chtml in results:
			part = chtml.split('tips-teaser category-tips')
			for i in range(1, len(part), 1):
				entry = part[i].replace('\/', '/')
				if not re.search(r'''<div class=["']channel-logo["']>''', entry, re.S): continue
				dbg_section = '<div class="tips-teaser__bottom__wrapper">'
				debug_MS(f"(navigator.list_broadcasts[1.1]) xxxxx ENTRY-01 : {entry.split(dbg_section)[0]} xxxxx")
				matchNAE = re.compile(r'''class=["']tips-teaser__bottom__title["'].+?>([^<]+)</span>''', re.S).findall(entry)
				matchSUB = re.compile(r''' title=["']([^"']+)["']''', re.S).findall(entry)
				title = tvshow = cleaning(matchNAE[0])
				if matchNAE and matchSUB:
					first, last = matchNAE[0].strip(), matchSUB[0].strip()
					checking = cleaning(last.replace(last, ''))
					title = cleaning(first) if checking == "" else f"{cleaning(first)} - {checking}"
				matchGEN = re.compile(r'''class=["']detail-genre["']>([^<]+)</span>''', re.S).findall(entry)
				genre = matchGEN[0] if matchGEN else None
				channel = re.compile(r'''<div class=["']channel-logo["']>(.*?)</div>''', re.S).findall(entry)[0]
				matchCHA = re.compile(r'''title=["'](.*?)["'] loading=''', re.S).findall(channel)[0]
				studio, station = clean_sender(matchCHA)
				# "event_label":"https:\/\/www.tvspielfilm.de\/mediathek\/mein-suesses-geheimnis,11656496.html",
				matchECI = re.compile(r'''["']event_action["']:["']pageElement.clickInternal["'],["']event_label["']:["'](http[^"']+)["'],["']pageElementId["']:''', re.S).findall(entry)
				forward = matchECI[0] if matchECI else None
				if forward is None or forward and (forward in unikat or forward[:-1].endswith('mediathek')):
					continue
				unikat.add(forward)
				# background-image: url(https://img.tvspielfilm.de/3d/b6/1e/681463b4bbd6b704491eb63d.jpeg?im=Crop,rect=(0,0,1107,729),gravity=Center;Resize,width=632);
				matchIMG = re.compile(r'background-image: url\((https://img.tvspielfilm.de/.*?)\);', re.S).findall(entry)
				# vorh. Bild-Grössen (ab 16.07.23): _159.jpg // _164.jpg // _245.jpg // _300.jpg // _456.jpg // _476.jpg // _600.jpg // _632.jpg // _640.jpg // _780.jpg
				thumb = matchIMG[0].split('?im=')[0] if matchIMG else ""
				if show_arte is False and studio.upper() in ARTEEX: continue
				if show_joyn is False and studio.upper() in JOYNEX: continue
				if show_servus is False and studio.upper() in SERVUSEX: continue
				if show_rtlp is False and studio.upper() in RTLPEX: continue
				counter += 1
				combo_uno.append({'Count_1': int(counter), 'Link_1': forward, 'Title': title, 'Show': tvshow, 'Genre': genre, 'Studio': studio, 'Station': station, 'Image': thumb})
				combo_links.append({'Count_1': int(counter), 'Link_1': forward})
		load_more = re.compile(r'''<button data-url=["']([^"']+)["'] class=["']load-more["'] id=["'](?:tips-teaser-load-more|mediacenter-genre-load-more)["']''', re.S).findall(block_table)
		if load_more and len(load_more[0]) > 0: # id="tips-teaser-load-more" || id="mediacenter-genre-load-more"
			next_page = f"{BASE_URL}{load_more[0]}" if load_more[0][:4] != 'http' else load_more[0] if load_more[0][:4] == 'http' else None
			debug_MS("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~")
			debug_MS(f"(navigator.list_broadcasts[1.2]) PAGES ### NOW GET NEXTPAGE : {next_page} ###")
			scrolling = int(scrolling).__add__(1) if next_page else 0
		else: break
	if combo_uno:
		combo_due = _fetch_pages(combo_links)
		merging = [{**uno, **due} for uno in combo_uno for due in combo_due if uno.get('Link_1') == due.get('Link_2')] # Merge List1 and List2 (dictionaries) by specific value if value exists else nothing !!!
		merging = sorted(merging, key=lambda sox: sox.get('Sorting', '2026.01.01'), reverse=True) if \
			target.endswith('mediathek/') else sorted(merging, key=lambda sox: int(sox.get('Count_1', 0)))
		for riders in merging: # List1 = 0-7 || List2 = 8-22
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
			debug_MS(f"(navigator.list_broadcasts[3]) ##### Anzahl : {len(riders)} || Eintrag : {riders} #####")
			(note_1, note_2, note_3), (season, episode, aired, year, genre_due, genre) = ("" for _ in range(3)), (None for _ in range(6))
			name = riders.get('Title')
			if riders.get('SeasEpis'):
				matchSE = re.search(r'(Staffel:? |S)(\d+)', riders['SeasEpis']) # Staffel 12, Folge 05 // Staffel 14, Folge 9b/8 // Folge 1022
				if matchSE: season = matchSE.group(2).zfill(2)
				matchEP = re.search(r'(Episode:? |Folge:? |E)(\d+)', riders['SeasEpis']) # Staffel 12, Folge 05 // Staffel 14, Folge 9b/8 // Folge 1022
				if matchEP: episode = matchEP.group(2).zfill(2)
				note_1 = translation(30632).format(riders['SeasEpis'])
			if riders.get('Added'):
				aired, note_2 = riders['Added'][4:14], translation(30633).format(riders['Added']) # FirstAired
				if dates_linkes: name = f"{riders['Added'][4:10]}  {name}" # Added = Sa. 11.02.2023 || ergebnis = 11.02.
			if riders.get('Infos'):
				matchYR = re.search(r'(\d+)', riders['Infos']) # D 2021 | Krimi
				year = matchYR.group(1) if matchYR else None
				name = f"{name} - {riders['Infos'].split(' |')[0]}"
				genre_due = riders['Infos'].split('| ')[1] if '|' in riders['Infos'] else None
			if riders.get('Studio') not in ['', None]:
				note_3 = translation(30634).format(riders['Studio']) if riders.get('Story') != "" else translation(30635).format(riders['Studio'])
			full_genre = genre_due if genre_due else riders.get('Genre')
			if full_genre:
				edit_genre = full_genre.replace('Krankenhaus', 'Krankenhauss').replace('Sci-Fi', 'Science~Fiction').replace('Science-Fiction', 'Science~Fiction').replace('TV-', '').replace('Vorschul', 'Vorschule')
				genre = ' / '.join(sorted([re.sub(r'(sserie|serie|sreihe|reihe|nalfilm|naldrama|saga)', '', eg) for eg in edit_genre.split('-')])) # Krankenhausserie = 'serie+reihe' aus Genre entfernen
			name = f"{name}  {riders['Station']}" if canal_linkes and riders.get('Station') not in ['', None] else name
			plot = note_1+note_2+riders.get('Story')+note_3
			medias = 'episode' if str(episode).isdecimal() else 'movie'
			debug_MS(f"(navigator.list_broadcasts[3]) ##### TITLE : {name} || STAFFEL : {season} || EPISODE : {episode} || YEAR : {year} || THUMB : {riders.get('Image')} #####")
			debug_MS(f"(navigator.list_broadcasts[3]) ##### OR-LINK : {riders.get('Link_1')} || VIDEO : {riders.get('TvStream')} || STUDIO : {riders.get('Studio')} || RATING : {riders.get('Imdb')} #####")
			fetch_items = create_entries({'Title': name, 'Tagline': riders.get('Tagline'), 'Plot': plot, 'Duration': riders.get('Duration'), 'Season': season, 'Episode': episode, \
				'Aired': aired, 'Year': year, 'Genre': genre, 'Director': riders.get('Director'), 'Writer': riders.get('Writer'), 'Cast': riders.get('Cast'), 'Rating': riders.get('Imdb'), \
				'Mpaa': riders.get('Mpaa'), 'Studio': riders.get('Studio'), 'Mediatype': medias, 'Image': riders.get('Image'), 'Reference': 'Single'})
			add_views({'mode': 'playCODE', 'IDENTiTY': riders.get('Link_1')}, fetch_items, False)
			combo_send.append({'filtrate': riders.get('Link_1'), 'title': name, 'tvshow': riders.get('Show'), 'station': riders.get('Studio'), 'transfer': riders.get('TvStream')})
		preserve(WORKS_FILE, combo_send)
	else:
		failing(f'(navigator.list_broadcasts) ##### NO BROADCAST-LIST - NO ENTRY FOR: "{phase}" FOUND #####')
		return dialog.notification(translation(30525), translation(30526).format(phase), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def _fetch_pages(pages_table, secondo=[]):
	package = track_several(pages_table, headers={**WEB_HEADER, **{'Referer': f"{BASE_URL}/"}})
	if package:
		for points, chiave, scraps in package:
			if scraps not in ['', None]:
				articles = re.findall(r'''<article class=["']broadcast-detail["'](.*?)</article>''', scraps, re.S)
				for item in articles:
					item = item.replace('\/', '/')
					(descript, sorting), (director, writer, staff), (tag_marker, added, seconds, infos, mpaa) = ("" for _ in range(2)), ([] for _ in range(3)), (None for _ in range(5))
					teaser = re.findall(r'''<section class=["']broadcast-detail__description["'](.*?)</section>''', item, re.S)[0]
					tag_uno = re.compile(r'''<p class=["']headline["']>([^<]+)</p>''', re.S).findall(teaser) # Filme & Serien
					tag_due = re.compile(r'''<h2 class=["']broadcast-info["']>([^<]+)</h2>''', re.S).findall(item) # z.B. Neuanfänge (2)
					tag_tre = re.compile(r'''<ul class=["']headline prelude["']>(.*?)</ul>''', re.S).findall(teaser) # z.B. Küchlein, Kopfstand und Krokan
					if tag_tre and len(tag_tre[0]) > 10:
						tag_special = re.compile(r'<li[^>]*>(.*?)</li>', re.S).findall(tag_tre[0])
						tag_marker = '[CR]'.join(['• '+cleaning(re.sub(' +', ' ', tagpart.replace('\n', ' ').replace('\t', ' '))) for tagpart in tag_special])
					tagline = cleaning(tag_uno[0].replace('\n', ' ').replace('\t', ' ')) if tag_uno else cleaning(tag_due[0].replace('\n', ' ').replace('\t', ' ')) if tag_due and \
						not tag_due[0].startswith('Mehr zu ') else tag_marker if tag_marker else None
					tagline = tagline[:125]+'...' if tagline and len(tagline) > 125 and tag_marker is None else tagline
					agreeDSC = re.compile(r'<p>(.*?)</p>', re.S).findall(teaser)
					if agreeDSC and len(agreeDSC[0]) > 10:
						descript += '[CR][CR]'.join([cleaning(re.sub(' +', ' ', teas.replace('\n', ' ').replace('\t', ' '))) for teas in agreeDSC])
						descript = descript.rstrip()[:-4] if descript.endswith('[CR]') else descript
					agreeGES = re.compile(r'''<div class=["']broadcast-info-guests["']>(.*?)</section>''', re.S).findall(item)
					if agreeGES and '<li' in agreeGES[0]:
						STORY_02 = re.compile(r'<li[^>]*>(.*?)</li>', re.S).findall(agreeGES[0])
						if STORY_02 and len(STORY_02[0]) > 1:
							prefix = '[CR][CR]' if agreeDSC and len(agreeDSC[0]) > 10 else ""
							descript += prefix+'[CR]'.join([cleaning(clean_guest(mods)) for mods in STORY_02])
							descript = descript.rstrip()[:-4] if descript.endswith('[CR]') else descript
					agreeRAT = re.compile(r'''class=["']content-rating__imdb-rating__rating-value["']>([^<]+)</div>''', re.S).findall(item)
					imdb = agreeRAT[0].strip().replace(',', '.') if agreeRAT and str(agreeRAT[0]).strip().replace(',', '').isdecimal() else None # class="content-rating__imdb-rating__rating-value">7,3</div>
					agreeSER = re.compile(r'''<section class=["']serial-info["']>(.*?)</section>''', re.S).findall(item)
					seasepis = cleaning(re.sub(r'\<.*?>', '', agreeSER[0])) if agreeSER else None # Folge 4
					sector_uno = re.compile(r'''<div class=["']text-wrapper["']>(.*?)<section class=["']broadcast-detail__stage''', re.S).findall(item)
					matchONE = cleaning(sector_uno[0]) if sector_uno else None
					if matchONE:
						agreeTME = re.compile(r'Ausstrahlung:\ ([^<]+)</span>', re.S).findall(matchONE)
						datings = agreeTME[0].strip()[:6] if agreeTME else None # TV-Ausstrahlung: 18.01. | 90 Min.
						if datings and str(datings)[:2].isdecimal():
							yearing = datetime.now().strftime('%Y') # Sendung aus diesem Monat = Aktuelles Jahr
							if str(datetime.now().month) == '12' and str(datings[3:5]) == '01': # Sendung aus dem Monat Januar // Aktueller Monat ist Dezember = Aktuelles Datum plus 32 Tage
								yearing = (datetime.now() + timedelta(days=32)).strftime('%Y')
							elif str(datetime.now().month) == '1' and str(datings[3:5]) == '12': # Sendung aus dem Monat Dezember // Aktueller Monat ist Januar = Aktuelles Datum minus 32 Tage
								yearing = (datetime.now() - timedelta(days=32)).strftime('%Y')
							available = datetime(*(time.strptime(f"{datings}{str(yearing)}", '%d.%m.%Y')[0:6])) # 18.01.+JAHR
							added = available.strftime('%a. %d.%m.%Y')
							sorting = available.strftime('%Y.%m.%d')
							for av in (('Mon', translation(32201)), ('Tue', translation(32202)), ('Wed', translation(32203)), ('Thu', translation(32204)),\
								('Fri', translation(32205)), ('Sat', translation(32206)), ('Sun', translation(32207))): added = added.replace(*av)
						minutes = re.search('([0-9]+) Min.', agreeTME[0]) if agreeTME else None # 90 Min.
						seconds = str(int(minutes.group(1)) * 60) if minutes else None
						agreeCYG = re.compile(r'''<span class=["']text-row["']>([^<]+)</span>''', re.S).findall(matchONE)
						infos = cleaning(agreeCYG[0]) if agreeCYG else None # D 2021 | Krimi
					if seconds is None and descript == "": continue # Quelltextleichen ohne weiterführende Verbindung entfernen
					sector_due = re.compile(r'''broadcast-cast-crew-box["'] data-tracking-id=["']castAndCrew["'](.*?)</section>''', re.S).findall(item)
					matchTWO = cleaning(sector_due[0]) if sector_due else None
					if matchTWO:
						area_uno = re.compile(r'''<p class=["']headline(?: headline--spacing)?["']>Infos(.*?)</dl>''', re.S).findall(matchTWO)
						if area_uno:
							agreeAGE = re.compile(r'<dt>FSK</dt>\s*<dd>([^<]+)</dd>', re.S).findall(area_uno[0])
							mpaa = cleaning(agreeAGE[0]) if agreeAGE and not str(cleaning(agreeAGE[0])).startswith('0 ') else None # <dd>ab 10 Jahren</dd>
						area_due = re.compile(r'''<p class=["']headline(?: headline--spacing)?["']>Crew(.*?)</dl>''', re.S).findall(matchTWO)
						if area_due: # <dt>   Drehbuch   </dt> // <dd>Hans G. Raeth</dd>
							agreeDIR = re.compile(r'<dt>\s*Regie\s*</dt>\s*<dd>(.*?)</dd>', re.S).findall(area_due[0]) # <dt>Regie</dt> // <dd>Philipp Osthus, Andreas Menck, Florian Gottschick, Felix Ahrens</dd>
							director = ', '.join([cleaning(re.sub(r'\<.*?>', '', dirs.replace('\n', ' ').replace('\t', ' ').replace('  ', ''))) for dirs in agreeDIR]) if agreeDIR else []
							agreeCRE = re.compile(r'<dt>\s*Drehbuch\s*</dt>\s*<dd>(.*?)</dd>', re.S).findall(area_due[0]) # <dt>Drehbuch</dt> // <dd>Philipp Osthus, Andreas Menck, Florian Gottschick, Felix Ahrens</dd>
							writer = ', '.join([cleaning(re.sub(r'\<.*?>', '', creas.replace('\n', ' ').replace('\t', ' ').replace('  ', ''))) for creas in agreeCRE]) if agreeCRE else []
						area_tre = re.compile(r'''<p class=["']headline(?: headline--spacing)?["']>Cast(.*?)</dl>''', re.S).findall(matchTWO)
						if area_tre: # <dt>Ina Becker</dt> // <dd>Andrea Sawatzki</dd>
							agreeACT = re.compile(r'''<dt>(.*?)</dt>\s*<dd>(.*?)</dd>''', re.S).findall(area_tre[0])
							for index, person in enumerate(agreeACT, 1):
								actor = {'name': cleaning(re.sub(r'\<.*?>', '', person[1])), 'role': cleaning(re.sub(r'\<.*?>', '', person[0])), 'order': index, 'thumb': ''}
								if actor['name'] not in ['' , None]:
									if KODI_BUILD >= 20:
										staff.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
									else: staff.append(actor)
					agreePLR = re.compile(r'''["']event_action["']:["']pageElement.clickExternal["'],["']event_label["']:["'](http[^"']+)["'],["']pageElementId["']:''', re.S).findall(item)
					stream = agreePLR[0] if agreePLR else None
					embrace = {'Count_2': int(points), 'Link_2': chiave, 'Tagline': tagline, 'Story': descript, 'Duration': seconds, 'SeasEpis': seasepis, 'Added': added,
						'Infos': infos, 'Director': director, 'Writer': writer, 'Cast': staff, 'Imdb': imdb, 'Mpaa': mpaa, 'TvStream': stream, 'Sorting': sorting}
					debug_MS("-------------------------------------------------")
					debug_MS(f"(navigator.fetch_pages[2]) ### COUNT-02 : {points} || LINK-02 : {chiave} || ENTRY-02 : {embrace} ###")
					secondo.append(embrace)
	return secondo

def playCODE(ORIGIN):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	FINAL_URL, title_clear, show, onward = (False for _ in range(4))
	for elem in preserve(WORKS_FILE):
		if elem['filtrate'] != '00' and elem['filtrate'] == ORIGIN:
			title_clear = re.sub(r'\[.*?\]', '', elem['title']) if elem.get('title', '') else False
			show, studio, onward = elem['tvshow'], elem['station'], elem['transfer']
			debug_MS(f"(navigator.playCODE) ### WORKS_FILE-Line : {elem} ###")
	onward = onward.replace('http://', 'https://') if onward and onward[:7] == 'http://' else onward
	log("(navigator.playCODE) --- START WIEDERGABE ANFORDERUNG ---")
	log("(navigator.playCODE[1]) frei")
	log(f"(navigator.playCODE[1]) ~~~ AbspielLink-01 (Original) : {onward} ~~~")
	log("(navigator.playCODE[1]) frei")
	if onward and onward.startswith('https://www.ardmediathek.de'):
		return ard_contents(onward)
	elif onward and onward.startswith('https://www.arte.tv'):
		video_code = re.compile('arte.tv/de/videos/([^/]+)/', re.S).findall(onward)[0]
		FINAL_URL = f"plugin://plugin.video.artetv.de/?mode=playVideo&link={video_code}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'ARTE.TV', 'ARTE.TV - Plugin')
	elif onward and onward.startswith('https://www.joyn.de'):
		return joyn_contents(onward)
	elif onward and onward.startswith('https://www.servustv.com'):
		video_code = onward.split('/')[-2].replace('/', '').upper()
		FINAL_URL = f"plugin://plugin.video.servustv_com/?mode=play_video&link={video_code}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'ServusTV.com', 'ServusTV - Plugin')
	elif onward and onward.startswith('https://www.welt.de'):
		return welt_contents(onward)
	elif onward and onward.startswith(('https://www.3sat.de', 'https://www.zdf.de', 'https://www.zdfheute.de')):
		return zdf_contents(onward)
	else:
		failing(f"(navigator.playCODE[2]) AbspielLink-00 : Der Provider *{urlparse(onward).netloc}* konnte nicht aufgelöst werden !!!")
		dialog.notification(translation(30521).format('LINK'), translation(30527).format(urlparse(onward).netloc), icon, 10000)
		log("(navigator.playCODE[2]) --- ENDE WIEDERGABE ANFORDERUNG ---")

def add_views(params, listitem, folder=True):
	uws = build_mass(HOST_AND_PATH, params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
