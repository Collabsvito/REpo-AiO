﻿# -*- coding: utf-8 -*-

from .common import *


def ard_contents(video_origin):
	debug_MS("(resolver.ard_contents) ------------------------------------------------ START = ard_contents -----------------------------------------------")
	(masters, medias), (code_one, stream, final_link) = ([] for _ in range(2)), (False for _ in range(3))
	LANGUAGES = ['deu', 'ov']
	ARD_QUALITIES = ['Auto', 2560, 1920, 1280, 960, 640] # ARD_QUALITIES = ['auto', 5, 4, 3, 2, 1, 0]
	for code_one in video_origin.split('/'):
		try:
			testing = base64.urlsafe_b64decode(code_one + '=' * (len(code_one) % 4)).decode()
			if code_one and len(testing) > 5: break
		except: pass
	# https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL3JhZGlvYnJlbWVuLmRlLzgyYzhkMjE0LTFhM2YtNDU3NC1iOWMwLTdjODlmYWIzNDYyNi9lcGlzb2RlL3VybjphcmQ6c2hvdzo2MjA5YjVhYmQ4ODZhN2Fj?devicetype=pc&embedded=true = Nicht immer Videoeinträge vorhanden !!!
	# https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL3JhZGlvYnJlbWVuLmRlLzgyYzhkMjE0LTFhM2YtNDU3NC1iOWMwLTdjODlmYWIzNDYyNi9lcGlzb2RlL3VybjphcmQ6c2hvdzo2MjA5YjVhYmQ4ODZhN2Fj?embedded=true&mcV6=true = Alle Videoeinträge = Fremdsprachen, Deutsch Standard, Deutsch mit Audiodescription, Deutsch mit Unterttiteln
	debug_MS(f"(resolver.ard_contents[1]) ##### REQUEST_ONE : {API_ARD}ard/item/{code_one}?embedded=true&mcV6=true #####")
	if code_one:
		section_one = track_content(f"{API_ARD}ard/item/{code_one}?embedded=true&mcV6=true", 'GET', 'TRACK', WEB_HEADER)
		if section_one.status_code in [200, 201, 202]:
			data_one = section_one.json()
			debug_MS("++++++++++++++++++++++++")
			debug_MS(f"(resolver.ard_contents[1]) XXXXX CONTENT-01 : {data_one} XXXXX")
			debug_MS("++++++++++++++++++++++++")
			if data_one is not None and data_one.get('widgets', '') and len(data_one['widgets']) > 0:
				full_video = data_one.get('widgets', [])
				if data_one.get('coreAssetType', '') == 'SECTION' and len(data_one['widgets']) > 1 and 'teasers' in str(data_one['widgets'][1]):
					broadcast = data_one['widgets'][0].get('broadcastedOn', 'UNKNOWN')
					code_two = next(filter(lambda cx: cx.get('coreAssetType', '') == 'EPISODE' and broadcast in cx.get('broadcastedOn', ''), data_one['widgets'][1].get('teasers', [])), None)
					debug_MS(f"(resolver.ard_contents[1]) ##### DETECTED CODE FOR REQUEST_TWO : {code_two['id'] if code_two else '!!! ERROR !!! NO RESULTS !!! ERROR !!!'} #####")
					if code_two:
						section_two = track_content(f"{API_ARD}ard/item/{code_two['id']}?embedded=false&mcV6=true", 'GET', 'TRACK', WEB_HEADER)
						if section_two.status_code in [200, 201, 202]:
							data_two = section_two.json()
							debug_MS("++++++++++++++++++++++++")
							debug_MS(f"(resolver.ard_contents[2]) XXXXX CONTENT-02 : {data_two} XXXXX")
							debug_MS("++++++++++++++++++++++++")
							if data_two is not None and data_two.get('widgets', '') and len(data_two['widgets']) > 0:
								full_video = data_two.get('widgets', [])
				for elem in full_video:
					if elem.get('mediaCollection', '') and len(elem['mediaCollection']) > 0:
						for each in elem['mediaCollection']['embedded']['streams']:
							formitaeten = each.get('media')
							if not isinstance(formitaeten, list):
								continue
							for item in formitaeten:
								if item.get('forcedLabel').lower() == 'auto' and item.get('mimeType').lower() in ['application/x-mpegurl', 'application/vnd.apple.mpegurl']:
									for found in LANGUAGES:
										for shorties in item.get('audios', {}):
											if shorties.get('languageCode').lower() == found and shorties.get('kind').lower() == 'standard':
												masters.append({'url': item['url'], 'quality': item['maxHResolutionPx'], 'mimeType': item.get('mimeType').lower(), 'language': shorties['languageCode']})
								if item.get('forcedLabel').lower() != 'auto' and item.get('mimeType').lower() == 'video/mp4':
									for found in LANGUAGES:
										for shorties in item.get('audios', {}):
											if shorties.get('languageCode').lower() == found and shorties.get('kind').lower() == 'standard':
												numbers = 22 if shorties.get('languageCode').lower() == 'deu' else 11
												medias.append({'pos': numbers, 'url': item['url'], 'quality': item['maxHResolutionPx'], 'mimeType': item.get('mimeType').lower(), 'language': shorties['languageCode']})
												medias = sorted(medias, key=lambda px: (int(px['pos']), int(px['quality'])), reverse=True)
						debug_MS(f"(resolver.ard_contents[3]) SORTED_LIST | M3U8 ### MASTER : {masters} ###")
						debug_MS(f"(resolver.ard_contents[3]) SORTED_LIST | MPP4 ### MEDIAS : {medias} ###")
					elif elem.get('blockedByFsk', '') is True:
						log("(resolver.ard_contents[3]) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Alterbeschränkungen geblockt !!!")
						return dialog.notification(translation(30529), translation(30530), icon, 10000)
					elif elem.get('geoblocked', '') is True:
						log("(resolver.ard_contents[3]) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Geo-Sperren geblockt !!!")
						return dialog.notification(translation(30529), translation(30531), icon, 10000)
	if (enable_adaptive or prefer_stream == 0) and masters:
		stream, final_link = 'HLS' if enable_adaptive else 'M3U8', masters[0]['url']
		debug_MS(f"(resolver.ard_contents[4]) ***** TAKE - {'Inputstream (hls)' if stream == 'HLS' else 'Standard (m3u8)'} - FILE (Ard.de+3) *****")
	if not final_link and medias:
		ard_link = f"https:{medias[0]['url']}" if medias[0]['url'][:4] != 'http' else medias[0]['url']
		stream, final_link = 'MP4', improve_video(ard_link, station='DasErste') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
		debug_MS(f"(resolver.ard_contents[4]) ***** TAKE - (mp4) - FILE (Ard.de+3) : {ard_link} *****")
	return play_tracer(final_link, stream, 'ARD+3', 'ARD - Intern')

def joyn_contents(video_origin):
	debug_MS("(resolver.joyn_contents) ------------------------------------------------ START = joyn_contents -----------------------------------------------")
	# ORIGINAL = https://www.joyn.de/play/serien/sweet-easy-on-tour/2-5-schwarzwaelder-himbeertorte-aus-mailand
	# FINAL_URL = plugin://plugin.video.joyn/?mode=play_video&video_id=a_pbbt48zdo6a&client_data=%7B%22genre%22%3A+%5B%5D%2C+%22startTime%22%3A+0%2C+%22videoId%22%3A+%22a_pbbt48zdo6a%22%2C+%22npa%22%3A+false%2C+%22duration%22%3A+1490000%2C+%22brand%22%3A+%22%22%7D&stream_type=VOD&title=Schwarzw%C3%A4lder+Himbeertorte+aus+Mailand&movie_id=None&path=%2Fserien%2Fsweet-easy-on-tour%2F2-5-schwarzwaelder-himbeertorte-aus-mailand
	video_id, movie_id, route, final_link = (None for _ in range(4))
	sweep = urlparse(video_origin)
	section_one = track_content(f"{sweep.path.replace('play/', '')}.json", headers={**WEB_HEADER, **{'Referer': BASE_JOYN}})
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(resolver.joyn_contents[1]) XXXXX CONTENT-01 : {section_one} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if section_one is not None and section_one.get('pageProps', ''):
		if section_one['pageProps'].get('__N_REDIRECT', ''):
			data_video = track_content(f"{section_one['pageProps']['__N_REDIRECT']}.json", headers={**WEB_HEADER, **{'Referer': video_origin}})
		else: data_video = section_one
		if data_video is not None and data_video.get('pageProps', '') and data_video['pageProps'].get('initialData', '') and data_video['pageProps']['initialData'].get('page', ''):
			short = data_video['pageProps']['initialData']['page']
			if short.get('movie', ''):
				video_id = short['movie']['video']['id']
				runtime = short['movie']['video']['duration'] if short['movie']['video'].get('duration', '') else 0
				movie_id = short['movie']['id']
				route = short['movie']['path']
				title = short['movie']['title'] if short['movie'].get('title', '') else 'Unknown'
			elif short.get('episode', ''):
				video_id = short['episode']['video']['id']
				runtime = short['episode']['video']['duration'] if short['episode']['video'].get('duration', '') else 0
				route = short['episode']['path']
				title = short['episode']['title'] if short['episode'].get('title', '') else 'Unknown'
			if video_id and route:
				client = f'{{"genre": [], "startTime": 0, "videoId": "{video_id}", "npa": false, "duration": {int(runtime) * 1000}, "brand": ""}}'
				debug_MS(f"(resolver.joyn_contents[2]) ##### CLIENT_DATA : {quote_plus(client)} #####")
				final_link = build_mass('plugin://plugin.video.joyn/', {'mode': 'play_video', 'movie_id': movie_id, 'video_id': video_id, 'stream_type': 'VOD', 'title': title, 'client_data': client, 'path': route})
				# JOYN-TRANSMIT : plugin://plugin.video.joyn/?mode=play_video&movie_id=&video_id=a_plf6fi6v9wq&stream_type=VOD&title=Young+Monaco&client_data=%7B%22genre%22%3A+%5B%5D%2C+%22startTime%22%3A+0%2C+%22videoId%22%3A+%22a_plf6fi6v9wq%22%2C+%22npa%22%3A+false%2C+%22duration%22%3A+2966000%2C+%22brand%22%3A+%22%22%7D&path=%2Fserien%2Fgalileo-stories%2F2024-32-young-monaco
	return play_tracer(final_link, 'TRANSMIT', 'JOYN - Mediathek', 'Joyn - Plugin')

def welt_contents(video_origin):
	debug_MS("(resolver.welt_contents) ------------------------------------------------ START = welt_contents -----------------------------------------------")
	section_one, (stream, final_link) = track_content(video_origin, 'GET', 'TEXT', {**WEB_HEADER, **{'Referer': video_origin}}), (False for _ in range(2))
	welt_player = re.compile(r'''(?s)<script type=["']application/json["'] data-content=["']VideoPlayer.Config["'] data-qa=["']VideoPlayer.Config["']>\s+(?P<json>{.+?})\s+</script>''', re.S).findall(section_one)
	if welt_player and len(welt_player[0]) > 0:
		debug_MS(f"(resolver.welt_contents[1]) ##### CONTENT-01 : {welt_player[0]} #####")
		data_video = json.loads(welt_player[0])
		if data_video.get('sources', '') and len(data_video['sources']) > 0:
			for elem in data_video.get('sources', []):
				delivery, source = elem.get('extension', None), elem.get('src', None)
				if (enable_adaptive or prefer_stream == 0) and delivery == 'm3u8' and source:
					stream = 'HLS' if enable_adaptive else 'M3U8'
					final_link = f"https://www.welt.de/onward/video/play/{quote_plus(source)}"
					debug_MS(f"(resolver.welt_contents[2]) ***** TAKE - {'Inputstream (hls)' if stream == 'HLS' else 'Standard (m3u8)'} - FILE (Welt.de) *****")
					break
				if not final_link and delivery == 'mp4' and source:
					stream, final_link = 'MP4', f"https://www.welt.de/onward/video/play/{quote_plus(source)}"
					debug_MS("(resolver.welt_contents[2]) ***** TAKE - (mp4) - FILE (Welt.de) *****")
					break
	return play_tracer(final_link, stream, 'WELT', 'WELT - Intern')

def zdf_contents(video_origin):
	debug_MS("(resolver.zdf_contents) ------------------------------------------------ START = zdf_contents -----------------------------------------------")
	data_one, teaser, token, video_found = (False for _ in range(4))
	video_origin = video_origin.replace('https://zdf.de', 'https://www.zdf.de').replace('https://www.zdfheute.de', 'https://www.zdf.de')
	section_one = track_content(video_origin, 'GET', 'TEXT', WEB_HEADER).replace('\\', '')
	zdf_player = re.compile(r'''(?s)data-zdfplayer-jsb=["'](?P<json>{.+?})["']''', re.S).findall(section_one)
	if zdf_player:
		player_uno = json.loads(zdf_player[0])
		teaser, token = player_uno['content'], player_uno['apiToken']
		ready = API_ZDF_OLD+teaser if teaser[:4] != 'http' else teaser
		debug_MS(f"(resolver.zdf_contents[2.1]) API_ZDF_OLD ##### VIDEO_FOUND : {ready} || SECRET : {token} #####")
		data_one = track_content(ready, headers={**WEB_HEADER, **{'Api-Auth': f"Bearer {token}"}})
	elif not zdf_player:
		template = re.compile(r'''["']__typename["']:["']VodMedia["'],["']ptmdTemplate["']:["']([^"']+)["'],["']vodMediaType["']:["']DEFAULT["'],''', re.S).findall(section_one)
		targical = re.compile(r'''["']target_video_id["']:["']([^"']+)["'],["']target_sophora_id["']''', re.S).findall(section_one)
		sophora = re.compile(r'''["']page_sophora_id["']:["']([^"']+)["'],["']page_type["']:["']Video["'],''', re.S).findall(section_one)
		vapitoks = re.compile(r'''["']tokens["']:\{["']videoToken["']:\{["']apiToken["']:["']([^"']+)["'],''', re.S).findall(section_one)
		if template and '/ptmd/' in template[0] and vapitoks:
			start_link = 'https://api.3sat.de' if video_origin.startswith('https://www.3sat.de') else API_ZDF_OLD
			video_found = start_link+template[0].replace('{playerId}', 'ngplayer_2_5').replace('\/', '/')
			debug_MS(f"(resolver.zdf_contents[2.2]) EXTRACTED ##### VIDEO_FOUND : {video_found} || SECRET : {vapitoks[0]} #####")
			return zdf_extractors(video_found, vapitoks[0])
		elif (targical or sophora) and vapitoks:
			video_found = f"{API_ZDF_NEW}/document/{targical[0]}" if targical else f"{API_ZDF_NEW}/document/{sophora[0]}"
			debug_MS(f"(resolver.zdf_contents[2.3]) EXTRACTED ##### VIDEO_FOUND : {video_found} || SECRET : {vapitoks[0]} #####")
			return zdf_extractors(video_found, vapitoks[0])
	if data_one and data_one.get('contentType') in ['clip', 'episode'] and not data_one.get('profile') == 'http://zdf.de/rels/not-found':
		start_link = 'https://api.3sat.de' if teaser and teaser.startswith('https://api.3sat.de') else API_ZDF_OLD if teaser and teaser.startswith(API_ZDF_OLD) else ""
		basis = data_one['mainVideoContent']['http://zdf.de/rels/target']
		default = data_one['mainVideoContent']['http://zdf.de/rels/target']['streams']['default'] if basis.get('streams', '') and basis['streams'].get('default', '') else basis
		video_found = start_link+default['http://zdf.de/rels/streams/ptmd-template'].replace('{playerId}', 'ngplayer_2_5').replace('\/', '/')
		debug_MS(f"(resolver.zdf_contents[3]) EXTRACTED ##### VIDEO_FOUND : {video_found} || SECRET : {token} #####")
		return zdf_extractors(video_found, token) if start_link != "" else zdf_extractors(video_found, None)
	if video_found is False:
		failing("(resolver.zdf_contents) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
		log("(resolver.zdf_contents) --- ENDE WIEDERGABE ANFORDERUNG ---")
		dialog.notification(translation(30521).format('ZDF - Intern'), translation(30528), icon, 10000)

def zdf_extractors(section_three, token):
	debug_MS("(resolver.zdf_extractors) ------------------------------------------------ START = zdf_extractors -----------------------------------------------")
	data_two = track_content(section_three, headers={**WEB_HEADER, **{'Api-Auth': f"Bearer {token}"}}) if token else track_content(section_three, headers=WEB_HEADER)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(resolver.zdf_extractors[1]) XXXXX CONTENT-01 : {data_two} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	(masters, medias), (unikat_uno, unikat_due), (stream, final_link) = ([] for _ in range(2)), (set() for _ in range(2)), (False for _ in range(2))
	M3U8_QUALITIES, MPP4_QUALITIES = ['auto', 'veryhigh', 'high', 'med'], ['uhd', 'fhd', 'hd', 'veryhigh', 'high', 'low']
	if data_two is not None and data_two.get('priorityList', []) and len(data_two['priorityList']) > 0:
		for each in data_two.get('priorityList', []):
			formitaeten = each.get('formitaeten')
			if not isinstance(formitaeten, list):
				continue
			for item in formitaeten:
				if item.get('type') == 'h264_aac_ts_http_m3u8_http' and item.get('mimeType').lower() in ['application/x-mpegurl', 'application/vnd.apple.mpegurl']:
					for found in M3U8_QUALITIES:
						for shorties in item.get('qualities', []):
							if shorties.get('quality') == found and shorties.get('quality') not in unikat_uno:
								unikat_uno.add(shorties['quality'])
								masters.append({'url': shorties['audio']['tracks'][0]['uri'], 'quality': shorties['quality'], 'mimeType': item.get('mimeType').lower(), 'language': shorties['audio']['tracks'][0]['language']})
				if item.get('type') == 'h264_aac_mp4_http_na_na' and 'progressive' in item.get('facets', []) and item.get('mimeType').lower() == 'video/mp4':
					for found in MPP4_QUALITIES:
						for shorties in item.get('qualities', []):
							if shorties.get('quality') == found and shorties.get('quality') not in unikat_due:
								unikat_due.add(shorties['quality'])
								medias.append({'url': shorties['audio']['tracks'][0]['uri'], 'quality': shorties['quality'], 'mimeType': item.get('mimeType').lower(), 'language': shorties['audio']['tracks'][0]['language']})
		debug_MS(f"(resolver.zdf_extractors[2.1]) SORTED_LIST | M3U8 ### MASTER : {masters} ###")
		debug_MS(f"(resolver.zdf_extractors[2.1]) SORTED_LIST | MPP4 ### MEDIAS : {medias} ###")
	elif data_two is not None and data_two.get('document', {}) and data_two['document'].get('formitaeten', []) and len(data_two['document']['formitaeten']) > 0:
		for item in data_two['document'].get('formitaeten', []):
			if item.get('type') == 'h264_aac_ts_http_m3u8_http' and item.get('class') == 'main' and item.get('mimeType').lower() in ['application/x-mpegurl', 'application/vnd.apple.mpegurl']:
				for found in M3U8_QUALITIES:
					if item.get('quality') == found and item.get('quality') not in unikat_uno:
						unikat_uno.add(item['quality'])
						masters.append({'url': item['url'], 'quality': item['quality'], 'mimeType': item.get('mimeType').lower(), 'language': item['language']})
			if item.get('type') == 'h264_aac_mp4_http_na_na' and item.get('class') == 'main' and item.get('mimeType').lower() == 'video/mp4':
				for found in MPP4_QUALITIES:
					if item.get('quality') == found and item.get('quality') not in unikat_due:
						unikat_due.add(item['quality'])
						medias.append({'url': item['url'], 'quality': item['quality'], 'mimeType': item.get('mimeType').lower(), 'language': item['language']})
		debug_MS(f"(resolver.zdf_extractors[2.2]) SORTED_LIST | M3U8 ### MASTER : {masters} ###")
		debug_MS(f"(resolver.zdf_extractors[2.2]) SORTED_LIST | MPP4 ### MEDIAS : {medias} ###")
	if (enable_adaptive or prefer_stream == 0) and masters:
		stream, final_link = 'HLS' if enable_adaptive else 'M3U8', masters[0]['url']
		debug_MS(f"(resolver.zdf_extractors[3]) ***** TAKE - {'Inputstream (hls)' if stream == 'HLS' else 'Standard (m3u8)'} - FILE (Zdf.de+3) *****")
	if not final_link and medias:
		stream, final_link = 'MP4', improve_video(medias[0]['url'], station='DasZweite') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
		debug_MS(f"(resolver.zdf_extractors[3]) ***** TAKE - (mp4) - FILE (Zdf.de+3) : {medias[0]['url']} *****")
	return play_tracer(final_link, stream, 'ZDF+3', 'ZDF - Intern')

def improve_video(highest, station=False):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen // aktualisiert am 23.11.2024
	standards = [highest, '', '', ''] # Seite zur Überprüfung : https://github.com/mediathekview/MServer/blob/master/src/main/java/mServer/crawler/sender/zdf/ZdfVideoUrlOptimizer.java
	if station == 'DasErste':
		route_one = (('/960', '/1280'), ('.l.mp4', '.xl.mp4'), ('_C.mp4', '_X.mp4'))
		route_two = (('/1280', '/1920'), ('_X.mp4', '_HD.mp4'), ('x720-50p-3200kbit.mp4', 'x1080-50p-5000kbit.mp4'), ('.hd.mp4', '.1080.mp4'), ('hd1080-avc720.mp4', 'hd1080-avc1080.mp4'))
		route_tree = (('/1920', '/3840'), ('_P.mp4', '_H.mp4'), ('.xl.mp4', '.xxl.mp4'))
	elif station == 'DasZweite':
		route_one = (('808k_p11v15', '2360k_p35v15'), ('1456k_p13v11', '2328k_p35v11'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'), ('1628k_p13v15', '2360k_p35v15'),
								('1628k_p13v17', '2360k_p35v17'), ('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
		route_two = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'), ('2360k_p35v17', '3360k_p36v17'))
		route_tree = (('3360k_p36v15', '4692k_p72v16'), ('3360k_p36v17', '6660k_p37v17'))
	standards[1] = reduce(lambda m, kv: m.replace(*kv), route_one, standards[0])
	standards[2] = reduce(lambda n, kv: n.replace(*kv), route_two, standards[1])
	standards[3] = reduce(lambda o, kv: o.replace(*kv), route_tree, standards[2])
	if standards[0] not in [standards[1], standards[2], standards[3]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def play_tracer(END_URL, PROTOCOL, OBJECT, NOTE, MIME='application/vnd.apple.mpegurl', DRM_GUARD=False):
	if END_URL and PROTOCOL:
		LPM = xbmcgui.ListItem(path=END_URL, offscreen=True)
		if plugin_operate('inputstream.adaptive') and PROTOCOL in ['HLS', 'MPD']:
			IA_NAME, IA_SYSTEM, DRM_SPECIES = 'inputstream.adaptive', 'com.widevine.alpha', None
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			DRM_HEADERS = {'User-Agent': WEB_AGENT, 'Content-Type': 'application/octet-stream'} if DRM_GUARD else {}
			LPM.setMimeType(MIME); LPM.setContentLookup(False); LPM.setProperty('inputstream', IA_NAME)
			if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", PROTOCOL.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			if KODI_BUILD in [19, 20, 21]:
				LPM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={WEB_AGENT}")
				LPM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={WEB_AGENT}")
			else: LPM.setProperty(f"{IA_NAME}.common_headers", f"User-Agent={WEB_AGENT}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
			if int(IA_VERSION) >= 2150 and PROTOCOL in ['HLS', 'MPD']:
				DRM_SPECIES = {'DRM_System': 'org.w3.clearkey'} if PROTOCOL == 'HLS' else {'DRM_System': IA_SYSTEM}
				if PROTOCOL == 'MPD' and DRM_GUARD:
					DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS)}
				LPM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
			elif int(IA_VERSION) < 2150 and PROTOCOL == 'MPD':
				LPM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
				if DRM_GUARD:
					DRM_SPECIES = {'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS), 'Post_Data': 'R{SSM}|'}
					LPM.setProperty(f"{IA_NAME}.license_key", '|'.join(DRM_SPECIES.values())) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
			if DRM_SPECIES: log(f"(resolver.play_tracer) INPUTSTREAM_VERSION: {IA_VERSION} >>>>> LICENSE : {'|'.join(DRM_SPECIES.values())} <<<<<")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		log(f"(resolver.play_tracer) END-AbspielLink ({OBJECT}) : {PROTOCOL}_stream : {END_URL}")
	else:
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		failing(f"(resolver.play_tracer) AbspielLink-00 ({OBJECT}) : *{NOTE}* Der angeforderte -VideoLink- existiert NICHT !!!")
		dialog.notification(translation(30521).format(NOTE), translation(30528), icon, 10000)
	log("(resolver.play_tracer) --- ENDE WIEDERGABE ANFORDERUNG ---")
