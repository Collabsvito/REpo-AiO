﻿# -*- coding: utf-8 -*-

from .common import *
config = traversing.get_config()
OPERATION = None


def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	number, SCORE_LIVE, SCORE_NEXT, NEXT_PAY = (0 for _ in range(4))
	COMBI_PAGES, COMBI_EVENTS, SENDING= ([] for _ in range(3))
	if nowlive or upcoming:
		LINKS = [config['HOME_LIVENEXT'].format('asc', 200), config['HOME_LIVENEXT'].format('asc', 300)]
		for ELEMENT in LINKS:
			for ii in range(1, 6, 1):
				number += 1
				MURL = f"{ELEMENT}&page={str(ii)}&per_page=40"
				debug_MS(f"(navigator.mainMenu[1]) LIVE+NEXT-PAGES XXX POS = {number} || URL = {MURL} XXX")
				COMBI_PAGES.append([int(number), MURL])
		if COMBI_PAGES:
			COMBI_EVENTS = getMultiData(COMBI_PAGES)
			if COMBI_EVENTS:
				DATA_ONE = json.loads(COMBI_EVENTS)
				for results in sorted(DATA_ONE, key=lambda pn: int(pn.get('Position', 0))):
					if 1 <= int(results['Position']) <= 5 and results is not None and results.get('data', '') and len(results['data']) > 0: # Pages between Number 1 and 5
						for livegame in results.get('data', []):
							if str(livegame.get('endTime'))[:4].isdecimal() and get_CentralTime(livegame['endTime']) + timedelta(minutes=15) > datetime.now() and \
								livegame.get('status', 500) == 200 and livegame.get('free', True) is True:
								debug_MS(f"(navigator.mainMenu[2]) LIVESTREAM ### NAME : {cleaning(livegame.get('name', 'UNKNOWN'))} || COMPETITION : {str(livegame.get('competition', {}).get('name', 'UNKNOWN'))} || IDD : {livegame.get('uuid', '00')} ###")
								SCORE_LIVE += 1
					elif 6 <= int(results['Position']) <= 10 and results is not None and results.get('data', '') and len(results['data']) > 0: # Pages between Number 6 and 10
						NEXT_ALL = results.get('totalCount', 0)
						for nextgame in results.get('data', []):
							if str(nextgame.get('startTime'))[:4].isdecimal() and datetime.now() < get_CentralTime(nextgame['startTime']) - timedelta(minutes=15) and \
								nextgame.get('status', 500) == 300 and nextgame.get('free', True) is True:
								debug_MS(f"(navigator.mainMenu[3]) NEXTSTREAM ### NAME : {cleaning(nextgame.get('name', 'UNKNOWN'))} || COMPETITION : {str(nextgame.get('competition', {}).get('name', 'UNKNOWN'))} || IDD : {nextgame.get('uuid', '00')} ###")
								SCORE_NEXT += 1
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	if nowlive and SCORE_LIVE > 0:
		LIVE_URL = config['HOME_LIVENEXT'].format('desc', 200)+f"&expand[]=teams&expand[]=sport&page=1&per_page=40"
		FETCH_UNO = create_entries({'Title': translation(30701).format(SCORE_LIVE), 'Plot': translation(30702).format(SCORE_LIVE), 'Image': f"{artpic}livestream.png"})
		addDir({'mode': 'listVideos', 'Link': LIVE_URL, 'Category': 'LIVE - Alle Sportarten'}, FETCH_UNO)
	if upcoming and SCORE_NEXT > 0:
		NEXT_URL = config['HOME_LIVENEXT'].format('asc', 300)+f"&expand[]=teams&expand[]=sport&page=1&per_page=40"
		FETCH_DUE = create_entries({'Title': translation(30703).format(SCORE_NEXT), 'Plot': translation(30704).format(SCORE_NEXT), 'Image': f"{artpic}upcoming.png"})
		addDir({'mode': 'listVideos', 'Link': NEXT_URL, 'Category': 'NEXT - Alle Sportarten'}, FETCH_DUE)
	addDir({'mode': 'listFavorites'}, create_entries({'Title': translation(30606), 'Image': f"{artpic}favourites.png"}))
	DATA_TWO = getContent(BASE_URL, queries='TEXT')
	sportcats = json.loads(re.compile(r'({"pageProps":.*?,"__N_SSP":true})', re.S).findall(DATA_TWO)[0])
	if sportcats is not None and sportcats['pageProps'].get('region', '') and sportcats['pageProps']['region'].get('sports', ''):
		for each in sportcats['pageProps']['region'].get('sports', []):
			debug_MS(f"(navigator.mainMenu[5]) xxxxx EACH-05 : {each} xxxxx")
			name, uuid = each['name'].title(), each.get('uuid', '00')
			image = f"{artpic}{name.lower()}.png" if xbmcvfs.exists(f"{artpic}{name.lower()}.png") else None
			published = each.get('published', False)
			name = next((lang.get('new') for lang in GENLANG if lang.get('old') == name.lower()), name)
			if uuid != '00' and published is True:
				addDir({'mode': 'listCategories', 'Link': uuid, 'Category': name, 'Section': name}, create_entries({'Title': name, 'Image': image}))
				debug_MS(f"(navigator.mainMenu[5]) ### NAME : {name} || UUID : {uuid} || GENRE : {name} ###")
	if basedates: addDir({'mode': 'listDates'}, create_entries({'Title': translation(30607), 'Image': f"{artpic}preview.png"}))
	if basesearch: addDir({'mode': 'SearchSPORT'}, create_entries({'Title': translation(30608), 'Image': f"{artpic}basesearch.png"}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30609), 'Image': f"{artpic}settings.png"}), False)
		if enableINPUTSTREAM and plugin_operate('inputstream.adaptive'):
			addDir({'mode': 'iConfigs'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listCategories(url, CAT, SECTOR, PAGE, LIMIT):
	debug_MS("(navigator.listCategories) -------------------------------------------------- START = listCategories --------------------------------------------------")
	debug_MS(f"(navigator.listCategories) ### URL = {url} ### CATEGORY = {CAT} ### GENRE = {SECTOR} ### PAGE = {PAGE} ### LIMIT = {LIMIT} ###")
	COMBI_PAGES, COMBI_FIRST, COMBI_SECOND = ([] for _ in range(3))
	(FOUND, PAYING), UNIKAT, PAGE, LIMIT = (0 for _ in range(2)), set(), int(PAGE), int(LIMIT)
	if '@@' in url:
		CODE, TARGET = url.split('@@')[1], url.split('@@')[0]
		LINKS = [config['LIVE_EVENT'].format(CODE, TARGET, PAGE, LIMIT), config['COMING_EVENT'].format(CODE, TARGET, PAGE, LIMIT), \
						config['LATEST_EVENT'].format(CODE, TARGET, PAGE, LIMIT), config['HIGH_EVENT'].format(CODE, TARGET, PAGE, LIMIT)]
		if TARGET == 'competition':
			LINKS += [config['CONTEST_TEAMS'].format(CODE, PAGE, LIMIT)]
	else:
		CODE, TARGET = url, 'sport'
		LINKS = [config['LIVE_EVENT'].format(CODE, TARGET, PAGE, LIMIT), config['COMING_EVENT'].format(CODE, TARGET, PAGE, LIMIT), \
						config['LATEST_EVENT'].format(CODE, TARGET, PAGE, LIMIT), config['HIGH_EVENT'].format(CODE, TARGET, PAGE, LIMIT), \
						config['SPORT_CONTESTS'].format(CODE, PAGE, LIMIT), config['SPORT_TEAMS'].format(CODE, PAGE, LIMIT)]
	for ii, ELEMENT in enumerate(LINKS, 1):
		debug_MS(f"(navigator.listCategories[1]) CATEGORIES-PAGES XXX POS = {str(ii)} || URL = {ELEMENT} XXX")
		COMBI_PAGES.append([int(ii), ELEMENT])
	if COMBI_PAGES:
		COMBI_FIRST = getMultiData(COMBI_PAGES)
		if COMBI_FIRST:
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
			DATA_ONE = json.loads(COMBI_FIRST)
			for results in sorted(DATA_ONE, key=lambda pn: int(pn.get('Position', 0))):
				if results is not None and results.get('data', '') and len(results['data']) > 0 and results.get('totalCount', ''):
					debug_MS(f"(navigator.listCategories[2]) xxxxx RESULTS-02 : {results} xxxxx")
					POS, DEM = results['Position'], results['Demand']
					TITLE = next((pt.get('title') for pt in config['picks'] if f"event_type={pt.get('member')}" in DEM or f"v3/{pt.get('member')}" in DEM), 'UNKNOWN')
					TOTAL = results.get('totalCount', 0)
					PAYING = get_Number(results, DEM)
					TRIMMED = TOTAL - PAYING
					if TITLE in UNIKAT or TRIMMED <= 0:
						continue
					UNIKAT.add(TITLE)
					FOUND += 1
					NAME_ONE = NAME_TWO = translation(30711).format(TITLE+CAT, TRIMMED)
					IMG = next((f"{artpic}{ps.get('member')}.png" for ps in config['picks'] if f"event_type={ps.get('member')}" in DEM or \
						f"v3/{ps.get('member')}" in DEM and xbmcvfs.exists(f"{artpic}{ps.get('member')}.png")), icon)
					PLOT = translation(30712).format(TITLE, CAT, TRIMMED)
					if 'event_type=live' in DEM:
						NAME_ONE = translation(30713).format(NAME_ONE)
						PLOT = translation(30714).format(TRIMMED)
					elif 'event_type=upcoming' in DEM:
						NAME_ONE = translation(30715).format(NAME_ONE)
						PLOT = translation(30716).format(CAT, TRIMMED)
					debug_MS(f"(navigator.listCategories[3]) NUMBERING ### CATEGORY : {TITLE+CAT} ### TOTAL : {TOTAL} ### FORFREE : {TRIMMED} ###")
					debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
					COMBI_SECOND.append([POS, DEM, SECTOR, CAT, NAME_ONE, NAME_TWO, TITLE, IMG, PLOT])
	if COMBI_SECOND and FOUND == 1:
		debug_MS("(navigator.listCategories[4]) ----- Only one Entry FOUND - goto = listVideos -----")
		for POS, DEM, SECTOR, CAT, NAME_ONE, NAME_TWO, TITLE, IMG, PLOT in COMBI_SECOND:
			FETCH_UNO = create_entries({'Title': translation(30717).format(NAME_TWO), 'Genre': SECTOR, 'Image': IMG})
			addDir({'mode': 'blankFUNC', 'Link': '00'}, FETCH_UNO, False)
			return listVideos(DEM, TITLE+CAT, SECTOR, 1, 40, 0, 0)
	elif COMBI_SECOND and FOUND >= 2:
		for POS, DEM, SECTOR, CAT, NAME_ONE, NAME_TWO, TITLE, IMG, PLOT in sorted(COMBI_SECOND, key=lambda cr: int(cr[0])):
			FETCH_DUE = create_entries({'Title': NAME_ONE, 'Plot': PLOT, 'Genre': SECTOR, 'Image': IMG})
			addDir({'mode': 'listVideos', 'Link': DEM, 'Category': TITLE+CAT, 'Section': SECTOR}, FETCH_DUE)
			debug_MS(f"(navigator.listCategories[4]) ### NAME : {NAME_ONE} || URL : {DEM} || GENRE : {SECTOR} || PHOTO : {IMG} ###")
	else:
		return dialog.notification(translation(30526).format('Einträge'), translation(30527).format(CAT), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listDates():
	debug_MS("(navigator.listDates) ------------------------------------------------ START = listDates -----------------------------------------------")
	DATA_ONE = getContent(config['EVENT_DATES'])
	#log(f"(navigator.listDates[1]) ### DATES-01 : {DATA_ONE} ###")
	for ii in range(-30, 31, 1):
		utc_start = (datetime.utcnow() - timedelta(days=ii + 1)).strftime('%Y-%m-%d') # 2023-07-19
		epoch_start = TGM(time.strptime(utc_start+'T22:00:00', '%Y-%m-%dT%H:%M:%S')) * 1000 # UTC-EPOCH-STARTZEIT einen Tag zurück um 22:00:00 Uhr (Milliseconds=168980400000)
		utc_ends = (datetime.utcnow() - timedelta(days=ii)).strftime('%Y-%m-%d') # 2023-07-20
		epoch_ends = TGM(time.strptime(utc_ends+'T21:59:59', '%Y-%m-%dT%H:%M:%S')) * 1000 # UTC-EPOCH-ENDZEIT aktuell ausgewählter Tag um 21:59:59 Uhr (Milliseconds=1689890399000)
		if not utc_ends in DATA_ONE: continue
		debug_MS(f"(navigator.listDates[1]) ### START_UTC : {utc_start} || START_EPOCH : {str(epoch_start)} ###")
		#log(f"(navigator.listDates[2]) ### UTC_END : {utc_ends} || EPOCH_END : {str(epoch_ends)} ###")
		WD = (datetime.utcnow() - timedelta(days=ii)).strftime('%d.%m.%y | %a') # Datum mit engl. Wochentagskürzel = 16.07.23 | Sun
		for av in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), \
			('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))): WD = WD.replace(*av)
		TIMING = config['EVENT_STARTS'].format(epoch_start, epoch_ends, 1, 40)
		TITLE = translation(30731).format(WD) if ii == 0 else WD
		addDir({'mode': 'listVideos', 'Link': TIMING, 'Category': utc_ends}, create_entries({'Title': TITLE, 'Image': f"{artpic}calendar.png"}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchSPORT():
	debug_MS("(navigator.SearchSPORT) ------------------------------------------------ START = SearchSPORT -----------------------------------------------")
	keyword = preserve(SEARCH_FILE, 'TEXT') if xbmcvfs.exists(SEARCH_FILE) else None
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30741), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword:
		return listVideos(config['SEARCH_ALL'].format(quote_plus(keyword), 1, 50), translation(30742).format(keyword), 'Sport', 1, 50, 0, 0)
	return None

def load_pagination(CONTENT, FEED):
	global OPERATION
	if FEED.startswith(('SEARCH:', 'SUCHE:')): # Alles: 'competitions, teams, events' nur in Suchfunktion vorhanden
		if CONTENT.get('competitions', '') and isinstance(CONTENT['competitions'], list):
			addDir({'mode': 'blankFUNC', 'Link': '00'}, create_entries({'Title': translation(30751).format(cleaning(FEED)), 'Image': f"{artpic}competitions.png"}), False)
			OPERATION = 'COMPS'
			for item in sorted(CONTENT.get('competitions', []), key=lambda nc: cleanUmlaut(nc.get('name', 'unk')).lower()): yield item
			debug_MS("---------------------------------------------")
		if CONTENT.get('teams', '') and isinstance(CONTENT['teams'], list):
			addDir({'mode': 'blankFUNC', 'Link': '00'}, create_entries({'Title': translation(30752).format(cleaning(FEED)), 'Image': f"{artpic}teams.png"}), False)
			OPERATION = 'TEAMS'
			for item in sorted(CONTENT.get('teams', []), key=lambda nt: cleanUmlaut(nt.get('name', 'unk')).lower()): yield item
			debug_MS("---------------------------------------------")
		if CONTENT.get('events', '') and isinstance(CONTENT['events'], list):
			addDir({'mode': 'blankFUNC', 'Link': '00'}, create_entries({'Title': translation(30753).format(cleaning(FEED)), 'Image': f"{artpic}latest.png"}), False)
			OPERATION = 'EVENTS'
			for item in sorted(CONTENT.get('events', []), key=lambda se: se.get('startTime', '2025-01-01T00:00:01.000'), reverse=True): yield item
	elif not FEED.startswith(('SEARCH:', 'SUCHE:')) and CONTENT.get('data', '') and isinstance(CONTENT['data'], list):
		for item in CONTENT.get('data', []): yield item

def listVideos(TARGET, CAT, SECTOR, PAGE, LIMIT, POS, FILTER):
	global OPERATION
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS(f"(navigator.listVideos) ### URL = {TARGET} ### CATEGORY = {CAT} ### GENRE = {SECTOR} ### PAGE = {PAGE} ### LIMIT = {LIMIT} ### POSITION = {POS} ### EXCLUDED = {FILTER} ###")
	# Stream-Status-Codes = 200 : Livestream // 300 : Kommender Stream // 600 : Aufgezeichneter Stream
	DIRECTORY, PLAYOUTS = ['competition', 'team'], ['live', 'upcoming', 'latest', 'all_events']
	(counterONE, excludedONE), SENDING, UNIKAT, PAGE, LIMIT, counterTWO, excludedTWO = (0 for _ in range(2)), [], set(), int(PAGE), int(LIMIT), int(POS), int(FILTER)
	HIGHER = True if int(PAGE) > 1 else False
	if enableBACK and PLACEMENT == 0 and HIGHER is True:
		addDir({'mode': 'callingMain'}, create_entries({'Title': translation(30771), 'Image': f"{artpic}backmain.png"}))
	DATA_ONE = getContent(f"{TARGET.split('page=')[0]}page={str(PAGE)}&per_page={str(LIMIT)}") if int(PAGE) > 1 else getContent(TARGET)
	for each in load_pagination(DATA_ONE, CAT):
		debug_MS(f"(navigator.listVideos[1]) xxxxx FUNCTION : ★{OPERATION}★ || EACH-01 : {each} xxxxx")
		startCOMPLETE, startDATE, startTIME, aired, begins, endDATE, plot, photo = (None for _ in range(8))
		(NEXTCOME, RUNNING), branch, source, gender, MARK, fotoBIG = (False for _ in range(2)), 'sport', each, "", 'team', True
		counterONE, counterTWO = counterONE.__add__(1), counterTWO.__add__(1)
		uuid = each.get('uuid', None)
		if uuid is None or uuid in UNIKAT:
			excludedONE, excludedTWO = excludedONE.__add__(1), excludedTWO.__add__(1)
			continue
		UNIKAT.add(uuid)
		title = cleaning(each['name'])
		desc = cleaning(each['description']) if each.get('description', '') else ""
		each = each['event'] if each.get('event', '') and 'highlights' in TARGET else each
		TYPE = each.get('eventType', 'unknown')
		if OPERATION == 'EVENTS' and TYPE in ['live', 'upcoming']:
			excludedONE, excludedTWO = excludedONE.__add__(1), excludedTWO.__add__(1)
			continue # In der Suchfunktion die live+kommenden Spiele herausfiltern
		FREE = each.get('free', True)
		STAT = each.get('status', 500)
		SEXO = each.get('gender', '')
		if SEXO == 'women': gender = translation(30772).format(SEXO.replace('women', 'F'))
		elif SEXO == 'men': gender = translation(30773).format(SEXO.replace('men', 'M'))
		if str(each.get('startTime'))[:4].isdecimal(): # 2024-05-10T19:15:18.000Z
			LOCALstart = get_CentralTime(each['startTime'])
			startCOMPLETE = LOCALstart.strftime('%a{0} %d{0}%m{0}%y {1} %H{2}%M').format( '.', '•', ':')
			for tt in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), ('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))):
				startCOMPLETE = startCOMPLETE.replace(*tt)
			startDATE = LOCALstart.strftime('%d.%m.%Y')
			startTIME = LOCALstart.strftime('%H:%M')
			if datetime.now() < LOCALstart - timedelta(minutes=15): NEXTCOME, RUNNING = True, False # 19:44 < 20:00-15m = 19:45
			if datetime.now() > LOCALstart - timedelta(minutes=15): NEXTCOME, RUNNING = False, True # 19:46 > 20:00-15m = 19:45
			aired = LOCALstart.strftime('%d.%m.%Y') # FirstAired
			begins = LOCALstart.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else LOCALstart.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
		if str(each.get('endTime'))[:4].isdecimal(): # 2024-05-10T22:00:18.000Z
			LOCALend = get_CentralTime(each['endTime'])
			endDATE = LOCALend.strftime('%d.%m.%YT%H:%M')
			if datetime.now() > LOCALend + timedelta(minutes=15): # 22:30 > 22:00+15m = 22:15
				NEXTCOME, RUNNING = False, False
			if str(STAT).isdecimal() and int(STAT) == 200 and startTIME and datetime.now() > LOCALend + timedelta(hours=4): STAT = 600 # 22:30 > 18:15+4h = 22:15
		else:
			if str(STAT).isdecimal() and int(STAT) in [300, 600] and RUNNING is True:
				RUNNING = False
		if each.get('competition', '') and each['competition'].get('name', ''):
			if (RUNNING is True or NEXTCOME is True) and startCOMPLETE and OPERATION is None:
				plot = translation(30774).format(title, cleaning(each['competition']['name']), startCOMPLETE)
				if len(desc) > 90: plot += desc
			if plot is None and startDATE:
				plot = translation(30775).format(title, cleaning(each['competition']['name']), startDATE)
				if len(desc) > 90: plot += desc
			if plot is None and startDATE is None:
				plot = translation(30776).format(title, cleaning(each['competition']['name']))
				if len(desc) > 90: plot += desc
		if plot is None: plot = f"[B]{desc}[/B]" if 'searches' in TARGET else desc
		if each.get('sport', '') and each['sport'].get('name', ''): # Alle Rubriken ausser: Suche: Events+Teams
			branch = cleaning(each['sport']['name'])
		elif each.get('competition', '') and each['competition'].get('sport', ''): # Rubrik Suche: Events+Teams
			branch = cleaning(each['competition']['sport'])
		branch = SECTOR if branch == 'sport' and branch.lower() != SECTOR.lower() else branch
		genre = next((lang.get('new') for lang in GENLANG if lang.get('old') == branch.lower()), branch.title())
		if startDATE and FREE is False:
			excludedONE, excludedTWO = excludedONE.__add__(1), excludedTWO.__add__(1)
		if photo is None and source.get('images', '') and isinstance(source['images'], list):
			num, resources = uuid, source.get('images', []) # Bei Highlights sind die Bilder manchmal in der StartSource enthalten
			photo = (get_Picture(num, resources, 'cover') or get_Picture(num, resources, 'thumb'))
			if photo is None:
				photo, fotoBIG = get_Picture(num, resources, 'logo'), False
		if photo is None and each.get('images', '') and isinstance(each['images'], list):
			num, resources = uuid, each.get('images', [])
			photo = (get_Picture(num, resources, 'cover') or get_Picture(num, resources, 'thumb'))
			if photo is None:
				photo, fotoBIG = get_Picture(num, resources, 'logo'), False
		if photo is None and each.get('teams', ''):
			if each.get('teams', {})[0].get('images', ''):
				num, resources = uuid, each['teams'][0].get('images', [])
				photo = (get_Picture(num, resources, 'cover') or get_Picture(num, resources, 'thumb'))
				if photo is None:
					photo, fotoBIG = get_Picture(num, resources, 'logo'), False
			if photo is None and each.get('teams', {})[0].get('logoUrl', ''):
				photo, fotoBIG = each['teams'][0]['logoUrl'], False
		if photo is None: photo, fotoBIG = f"{artpic}standard.png", False
		if startDATE is None:
			if OPERATION == 'COMPS': MARK = 'competition'
			elif OPERATION == 'TEAMS': MARK = 'team'
			handling, MARK = 'adding', next((drs for drs in DIRECTORY if f"{drs}s?" in TARGET), MARK) # https://sporttotal.tv/api/v3/competitions?
			if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
				for article in preserve(FAVORIT_FILE):
					if article.get('Link') == f"{MARK}@@{uuid}": handling = 'skipping'
			FETCH_UNO = context = {'Link': f"{MARK}@@{uuid}", 'Category': title, 'Section': genre, \
				'Title': title+gender, 'Plot': plot, 'Genre': genre, 'Image': photo, 'Fanback': fotoBIG}
			addDir({'mode': 'listCategories', 'Link': f"{MARK}@@{uuid}", 'Category': title, 'Section': genre}, create_entries(FETCH_UNO), True, context, handling, HIGHER)
			debug_MS(f"(navigator.listVideos[2]) ### NAME : {title+gender} || LINK : {MARK}@@{uuid} || PHOTO : {photo} ###")
			debug_MS("---------------------------------------------")
		elif startDATE and FREE is True:
			name = f"{startDATE} - {title+gender}" if startDATE else title+gender
			if str(STAT).isdecimal() and int(STAT) == 200 and RUNNING is True and startTIME:
				name = translation(30777).format(startTIME, title+gender)
			media = 'LIVE' if str(STAT).isdecimal() and int(STAT) == 200 else 'VOD'
			table = 'event_playouts' if any(ps in TARGET for ps in PLAYOUTS) or TYPE in ['live', 'latest', 'upcoming'] else 'media_assets' # Event // MediaAsset
			SENDING.append({'Filter': uuid, 'Name': name, 'Photo': photo, 'Plot': plot, 'Coding': config['VIDEO_LINK'].format(table, uuid), 'Muxing': media})
			FETCH_DUE = {'Title': name, 'Plot': plot, 'Date': begins, 'Aired': aired, 'Year': aired, 'Genre': genre, \
				'Mediatype': 'episode', 'Image': photo, 'Fanback': fotoBIG, 'Reference': 'Single'}
			addDir({'mode': 'playCODE', 'IDENTiTY': uuid}, create_entries(FETCH_DUE), False, higher=HIGHER)
			debug_MS(f"(navigator.listVideos[3]) ### NAME : {name} || URL : {config['VIDEO_LINK'].format(table, uuid)} || PHOTO : {photo} || EVENT_TYPE : {TYPE.lower()} || GENRE : {genre} ###")
			debug_MS("---------------------------------------------")
	if counterONE >= 1:
		if SENDING:
			preserve(WORKS_FILE, 'JSON', SENDING)
			debug_MS(f"(navigator.listVideos[4]) NUMBERING ### current_RESULT : {counterONE} // all_RESULT : {counterTWO} ### current_EXCLUDED : {excludedONE} // all_EXCLUDED : {excludedTWO} ###")
		if not 'searches' in TARGET and str(DATA_ONE.get('totalCount')).isdecimal():
			debug_MS(f"(navigator.listVideos[4]) NUMBERING ### totalRESULTS : {DATA_ONE['totalCount']} // thisPAGE ends at : {int(PAGE)*int(LIMIT)} ###")
			if int(DATA_ONE['totalCount']) > int(counterTWO):
				debug_MS(f"(navigator.listVideos[4]) PAGES ### Now show NextPage ... No.{int(PAGE)+1} ... ###")
				FETCH_DUE = create_entries({'Title': translation(30778).format(int(PAGE)+1), 'Image': f"{artpic}nextpage.png"})
				addDir({'mode': 'listVideos', 'Link': TARGET, 'Category': CAT, 'Section': SECTOR, 'Page': int(PAGE)+1, 'Limit': LIMIT, 'Position': counterTWO, 'Excluded': excludedTWO}, FETCH_DUE)
	else:
		MESSAGE = CAT if not 'searches' in TARGET else re.sub('(SEARCH: |SUCHE: )', '', CAT)
		return dialog.notification(translation(30526).format('Einträge'), translation(30527).format(MESSAGE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def playCODE(PLID):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### SOURCE = {PLID} ###")
	EXTRA, Status, MEDIAS, RECORDED = 'LIVE', 'OFFLINE', [], True
	PLAY_URL, PLAY_TYPE, FOUND, PayFree, FINAL_WORKS, STREAM_WORKS, TEST_WORKS = (False for _ in range(7))
	for elem in preserve(WORKS_FILE):
		if elem['Filter'] != '00' and elem['Filter'] == PLID:
			CLEAR_TITLE, PHOTO, PLOT, PLAY_URL, PLAY_TYPE = re.sub('(\[/?B\])', '', elem['Name']), elem['Photo'], elem['Plot'], elem['Coding'], elem['Muxing']
			debug_MS(f"(navigator.playCODE[1]) ### WORKS_FILE-Line : {elem} ###")
	if PLAY_URL and PLAY_TYPE:
		FIRST = getContent(PLAY_URL)
		debug_MS(f"(navigator.playCODE[1]) XXXXX CONTENT-01 : {FIRST} XXXXX")
		debug_MS("---------------------------------------------")
		if FIRST is not None and not FIRST.get('errors', ''):
			if (FIRST.get('event', '') and len(FIRST['event']) > 0) or (FIRST and len(FIRST) > 0):
				DATA_UNO = FIRST['event'] if FIRST.get('event', '') and len(FIRST['event']) > 0 else FIRST
				if str(DATA_UNO.get('endTime'))[:4].isdecimal(): # 2024-05-10T22:00:18.000Z
					LOCALend = get_CentralTime(DATA_UNO['endTime'])
					EXTRA = 'VOD' if datetime.now() > LOCALend else 'LIVE'
					debug_MS(f"(navigator.playCODE[2]) ### NEW_TYPE : {EXTRA} || DAYTIME (local NOW) : {str(datetime.now())[:19]} || official ENDTIME (local GAME) : {LOCALend} ###")
				FOUND = True
				PayFree = True if DATA_UNO.get('free', '') is True else False
				Status = 'ONLINE' if str(DATA_UNO.get('status')).isdecimal() and int(DATA_UNO['status']) != 300 else 'OFFLINE'
			if PayFree is True and Status == 'ONLINE' and (FIRST.get('mediaAssets', '') and len(FIRST['mediaAssets']) > 0) or \
				(FIRST.get('mediaAssetLocators', '') and len(FIRST['mediaAssetLocators']) > 0):
				DATA_DUE = FIRST['mediaAssets'] if FIRST.get('mediaAssets', '') and isinstance(FIRST['mediaAssets'], list) else [FIRST]
				for STEPS in DATA_DUE:
					ASSET = STEPS.get('assetType', 'DEFAULT')
					for item in STEPS.get('mediaAssetLocators', []):
						if 'pano' in ASSET: continue
						MEDIAS.append({'video': item['url'], 'asset': ASSET, 'norm': item['mediaFormat']})
				debug_MS(f"(navigator.playCODE[3]) === STATUS : {Status} === HLS/MP4 === SORTED_LIST : {MEDIAS} ===")
	if FOUND is True and PayFree is False:
		failing(f"(navigator.playCODE) ##### Abspielen des Streams NICHT möglich ##### URL : {PLAY_URL} #####\n ########## Dieser Stream ist nur mit einem Bezahl-ABO-System von *https://sporttotal.tv/* abrufbar !!! ##########")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem(offscreen=True))
		xbmc.PlayList(1).clear()
		return dialog.notification(translation(30528), translation(30529), icon, 10000)
	if MEDIAS:
		attempts_one, attempts_two = (0 for _ in range(2))
		for item in MEDIAS:
			if ((EXTRA.lower() in item['asset']) or (not item['asset'].lower().startswith('broadcast'))) and item['norm'] == 'hls' and 'm3u8' in item['video']:
				STREAM_ONE, FINAL_ONE = 'HLS' if enableINPUTSTREAM and plugin_operate('inputstream.adaptive') else 'M3U8', item['video']
				log(f"(navigator.playCODE[4]) ***** FIRST_TESTING : {'Inputstream (hls)' if STREAM_ONE == 'HLS' else 'Standard (m3u8)'} {EXTRA} - FILE *****")
				while not TEST_WORKS and attempts_one < 2: # 2 x Pingversuche für den STREAM-Request ::: zur Überprüfung der Verfügbarkeit des Streams
					attempts_one += 1
					try:
						queries = Request(FINAL_ONE, None, {**head_WEB, **{'Cache-Control': 'no-cache', 'Accept': '*/*'}})
						scan_one = urlopen(queries, timeout=8)
						debug_MS(f"(navigator.playCODE[4]) === CALL_{STREAM_ONE}_STREAM === RETRIES_no : {attempts_one} === STATUS : {str(scan_one.getcode())} || URL : {FINAL_ONE} ===")
					except (URLError, HTTPError) as exo:
						debug_MS(f"(navigator.playCODE[4]) ERROR - {STREAM_ONE}_STREAM - ERROR ##### RETRIES_no : {attempts_one} === URL : {FINAL_ONE} === FAILURE : {exo} #####")
						time.sleep(2)
					else:
						FINAL_WORKS, STREAM_WORKS, TEST_WORKS = FINAL_ONE, STREAM_ONE, True
						break
		if TEST_WORKS is False:
			for item in MEDIAS:
				if item['norm'] == 'mp4' and ('.mp4' in item['video'] or '.ts' in item['video']):
					STREAM_TWO, FINAL_TWO = 'MP4', item['video']
					log("(navigator.playCODE[5]) !!!!! SECOND_TESTING : KEINEN funktionierenden Stream gefunden === nehme jetzt den Reserve-Stream-MP4 !!!!!")
					while not TEST_WORKS and attempts_two < 2: # 2 x Pingversuche für den STREAM-Request ::: zur Überprüfung der Verfügbarkeit des Streams
						attempts_two += 1
						try:
							queries = Request(FINAL_TWO, None, {**head_WEB, **{'Cache-Control': 'no-cache', 'Accept': '*/*'}})
							scan_two = urlopen(queries, timeout=8)
							debug_MS(f"(navigator.playCODE[5]) === CALL_{STREAM_TWO}_STREAM === RETRIES_no : {attempts_two} === STATUS : {str(scan_two.getcode())} || URL : {FINAL_TWO} ===")
						except (URLError, HTTPError) as exu:
							debug_MS(f"(navigator.playCODE[5]) ERROR - {STREAM_TWO}_STREAM - ERROR ##### RETRIES_no : {attempts_two} === URL : {FINAL_TWO} === FAILURE : {exu} #####")
							time.sleep(2)
						else:
							FINAL_WORKS, STREAM_WORKS, TEST_WORKS = FINAL_TWO, STREAM_TWO, True
							break
		if TEST_WORKS is False:
			failing(f"(navigator.playCODE[6]) ##### Abspielen des Streams NICHT möglich ##### URL : {PLAY_URL} #####\n ########## Die vorhandenen Stream-Einträge auf der Webseite von *https://sporttotal.tv/* sind OFFLINE/DEFEKT !!! ##########")
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem(offscreen=True))
			xbmc.PlayList(1).clear()
			return dialog.notification(translation(30521).format('URL-2'), translation(30530), icon, 10000)
	else:
		failing(f"(navigator.playCODE[2]) ##### Abspielen des Streams NICHT möglich ##### URL : {PLAY_URL} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *https://sporttotal.tv/* gefunden !!! ##########")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem(offscreen=True))
		xbmc.PlayList(1).clear()
		return dialog.notification(translation(30521).format('URL-1'), translation(30531), icon, 10000)
	if FINAL_WORKS and TEST_WORKS:
		LPM = xbmcgui.ListItem(CLEAR_TITLE, path=FINAL_WORKS, offscreen=True)
		if PLOT in ['', 'None', None]: PLOT = ' '
		if KODI_ov20:
			LPM.getVideoInfoTag().setTitle(CLEAR_TITLE), LPM.getVideoInfoTag().setPlot(PLOT), LPM.getVideoInfoTag().setStudios(['Sporttotal.tv'])
		else: LPM.setInfo('Video', {'Title': CLEAR_TITLE, 'Plot': PLOT, 'Studio': 'Sporttotal.tv'})
		LPM.setArt({'icon': icon, 'thumb': PHOTO, 'poster': PHOTO})
		MIME_WORKS = 'video/mp4' if STREAM_WORKS == 'MP4' else 'application/x-mpegurl'
		LPM.setMimeType(MIME_WORKS)
		if enableINPUTSTREAM and plugin_operate('inputstream.adaptive') and STREAM_WORKS in ['HLS', 'M3U8']:
			IA_NAME = 'inputstream.adaptive'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			LPM.setContentLookup(False), LPM.setProperty('inputstream', IA_NAME)
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LPM.setProperty(f"{IA_NAME}.manifest_type", 'hls')
			if KODI_ov20:
				LPM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={agent_WEB}") # On KODI v20 and above
			else: LPM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={agent_WEB}") # On KODI v19 and below
			if int(IA_VERSION) >= 2150 and STREAM_WORKS == 'HLS':
				LPM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey')
			LPM.setProperty(f"{IA_NAME}.play_timeshift_buffer", 'true')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		log(f"(navigator.playCODE) {STREAM_WORKS}_stream : {FINAL_WORKS}")
		xbmc.sleep(15000)
		if not xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)') and not xbmc.Player().isPlayingVideo():
			return dialog.notification(translation(30521).format('URL-PLAY'), translation(30532), icon, 10000)

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0: # Favoriten für Profile/Vereine
		for each in sorted(preserve(FAVORIT_FILE), key=lambda sx: (sx.get('Link', 'zorro').split('@@')[0], cleanUmlaut(sx.get('Title', 'Zorro').lower()))):
			paras_FAV = {'mode': 'listCategories', 'Link': each.get('Link'), 'Category': each.get('Category'), 'Section': each.get('Section', 'Sport'), 'Title': cleaning(each.get('Title')), \
				'Plot': cleaning(each.get('Plot')), 'Genre': each.get('Section', 'Sport'), 'Image': each.get('Image'), 'Fanback': True if each.get('Fanback', 'False') == 'True' else False}
			ACTION = FETCH_UNO = context = paras_FAV
			debug_MS(f"(navigator.listFavorites[1]) ### NAME : {cleaning(each.get('Title'))} || LINK : {each.get('Link')} || IMAGE : {each.get('Image')} || GENRE : {each.get('Section', 'Sport')} ###")
			addDir(ACTION, create_entries(FETCH_UNO), True, context, 'removing')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favorit_construct(**kwargs):
	TOPS = []
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		del kwargs['mode']; del kwargs['action']; del kwargs['Genre']
		TOPS.append({key: value if value != 'None' else None for key, value in kwargs.items()})
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30533), translation(30534).format(kwargs['Title']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Link') != kwargs.get('Link')]
		if len(TOPS) == 0:
			xbmcvfs.delete(FAVORIT_FILE)
		elif len(TOPS) >= 1:
			preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30533), translation(30535).format(kwargs['Title']), icon, 10000)

def addDir(params, listitem, folder=True, context={}, handling='default', higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enableBACK and PLACEMENT == 1 and higher is True:
		entries.append([translation(30650), f"RunPlugin({build_mass({'mode': 'callingMain'})})"])
	if handling == 'adding' and context:
		entries.append([translation(30651), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
