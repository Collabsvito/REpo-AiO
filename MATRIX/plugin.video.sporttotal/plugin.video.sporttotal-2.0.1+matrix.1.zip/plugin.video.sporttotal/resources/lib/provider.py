﻿# -*- coding: utf-8 -*-

import sys
import xbmc
import xbmcaddon


def translation(id):
	return xbmcaddon.Addon().getLocalizedString(id)


class Client(object):
	CONFIG_SPORTTOTAL = {
		'menu': 'https://sporttotal.tv/api/v2/config/menu',
		'dating': 'https://sporttotal.tv/api/v2/event_dates',
		'live': 'https://sporttotal.tv/api/v2/{}/events?event_type=live&resource_type={}&page={}&per_page={}',
		'coming': 'https://sporttotal.tv/api/v2/{}/events?event_type=upcoming&resource_type={}&page={}&per_page={}',
		'latest': 'https://sporttotal.tv/api/v2/{}/events?event_type=latest&resource_type={}&page={}&per_page={}',
		'clips': 'https://sporttotal.tv/api/v2/{}/events?event_type=highlights&resource_type={}&page={}&per_page={}',
		'contests': 'https://sporttotal.tv/api/v2/sports/{}/competitions?page={}&per_page={}',
		'teams': 'https://sporttotal.tv/api/v2/sports/{}/teams?page={}&per_page={}',
		'starting': 'https://sporttotal.tv/api/v2/75a0f3c0-33b9-4b92-b09b-94f2858f729c/events?event_type=all_events&resource_type=region&start_time_gt={}&start_time_lt={}&page={}&per_page={}',
		'searching': 'https://sporttotal.tv/api/v2/searches?query={}&page={}&per_page={}',
		'playing': 'https://sporttotal.tv/api/v2/{}/{}',
		'picks': [
		{
			'title': translation(30621),
			'slug': 'live',
			'id': 11
		},
		{
			'title': translation(30622),
			'slug': 'upcoming',
			'id': 22
		},
		{
			'title': translation(30623),
			'slug': 'latest',
			'id': 33
		},
		{
			'title': translation(30624),
			'slug': 'highlights',
			'id': 44
		},
		{
			'title': translation(30625),
			'slug': 'competitions',
			'id': 55
		},
		{
			'title': translation(30626),
			'slug': 'teams',
			'id': 66
		}],
		'header': {
			'Origin': 'https://sporttotal.tv',
			'Referer': 'https://sporttotal.tv/'
		}
	}

	def __init__(self, config):
		self._config = config

	def get_config(self):
		return self._config
