﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

COMPS_WAY, TEAMS_WAY, EVENTS_WAY = (None for _ in range(3))

def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	config = traversing.get_config()
	COMBI_TYPES = []
	LINGO = [{'old': 'americanfootball', 'new': 'American Football'},{'old': 'fieldhockey', 'new': 'Feldhockey'},{'old': 'icehockey', 'new': 'Eishockey'},{'old': 'indoorhockey', 'new': 'Hallenhockey'},{'old': 'soccer', 'new': 'Fussball'}]
	DATA_ONE = getUrl('/de.json')
	if DATA_ONE is not None and DATA_ONE.get('pageProps', '') and DATA_ONE['pageProps'].get('promoList', '') and DATA_ONE['pageProps']['promoList'].get('data', '') and DATA_ONE['pageProps']['promoList'].get('data', {})[0].get('promoItems', ''):
		for item in DATA_ONE['pageProps']['promoList']['data'][0]['promoItems']:
			debug_MS(f"(navigator.mainMenu[1]) ### ITEM-01 : {str(item)} ###")
			plot, photo = (None for _ in range(2))
			title = cleaning(item['title'])
			table = 'media_assets' if item.get('promotableType', '') == 'MediaAsset' else 'event_playouts' # Event // MediaAsset
			plot = cleaning(item.get('description', ''))
			slug = item['promotable']['uuid'] if item.get('promotable', '') and item['promotable'].get('uuid', '') else '00'
			if item.get('promotable', '') and item['promotable'].get('images', '') and len(item['promotable']['images']) > 0:
				num, resources = slug, item['promotable'].get('images', [])
				photo = (get_Picture(num, resources, 'cover') or get_Picture(num, resources, 'thumb'))
			if photo is None: photo = icon
			if slug != '00': addLink(title, photo, {'mode': 'playVideo', 'url': config['playing'].format(table, slug)}, plot)
	DATA_TWO = getUrl(config['menu'])
	if DATA_TWO is not None and DATA_TWO.get('columns', '') and DATA_TWO.get('columns', {})[0].get('items', ''):
		for each in DATA_TWO['columns'][0]['items']:
			debug_MS(f"(navigator.mainMenu[2]) ### EACH-02 : {str(each)} ###")
			idd = each.get('id', '00')
			name = each['data']['name'].title()
			for lang in LINGO:
				if name.lower() == lang['old']: name = lang['new']
			if idd != '00': addDir(name, icon, {'mode': 'listCategories', 'url': idd, 'category': name})
	addDir(translation(30607), icon, {'mode': 'listDates'})
	addDir(translation(30608), artpic+'basesearch.png', {'mode': 'SearchSPORT'})
	if enableADJUSTMENT:
		addDir(translation(30609), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30610), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listCategories(url, CAT, PHOTO, PAGE, LIMIT):
	debug_MS("(navigator.listCategories) -------------------------------------------------- START = listCategories --------------------------------------------------")
	debug_MS(f"(navigator.listCategories) ##### URL = {url} ##### CATEGORY = {CAT} ##### PAGE = {PAGE} ##### LIMIT = {LIMIT} #####")
	config = traversing.get_config()
	COMBI_PAGES, COMBI_FIRST, COMBI_SECOND = ([] for _ in range(3))
	UNIKAT = set()
	FOUND, PAYING = (0 for _ in range(2))
	if '@@' in url:
		code, target = url.split('@@')[1], url.split('@@')[0]
		LINKS = [config['live'].format(code, target, PAGE, LIMIT), config['coming'].format(code, target, PAGE, LIMIT),
						config['latest'].format(code, target, PAGE, LIMIT), config['clips'].format(code, target, PAGE, LIMIT)]
	else:
		code, target = url, 'sport'
		LINKS = [config['live'].format(code, target, PAGE, LIMIT), config['coming'].format(code, target, PAGE, LIMIT), config['latest'].format(code, target, PAGE, LIMIT),
						config['clips'].format(code, target, PAGE, LIMIT), config['contests'].format(code, PAGE, LIMIT), config['teams'].format(code, PAGE, LIMIT)]
	for ii, ELEMENT in enumerate(LINKS, 1):
		COMBI_PAGES.append([int(ii), ELEMENT])
	COMBI_FIRST = getMultiData(COMBI_PAGES)
	if COMBI_FIRST:
		DATA = json.loads(COMBI_FIRST)
		debug_MS("++++++++++++++++++++++++")
		debug_MS(f"(navigator.listCategories[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
		debug_MS("++++++++++++++++++++++++")
		for item in DATA:
			if item is not None and item.get('data', '') and item.get('totalCount', ''):
				#log("(navigator.listSeries[1]) ### EACH-01 : {} ###".format(str(item)))
				POS, DEM = item['Position'], item['Demand']
				title = [obj.get('title') for obj in config['picks'] if obj.get('slug') in DEM][0]
				tt_count = item.get('totalCount', 0)
				tt_pages = item.get('totalPages', 0)
				PAYING = get_Number(item, DEM)
				TRIMMED = tt_count - PAYING
				if title in UNIKAT or TRIMMED <= 0:
					continue
				UNIKAT.add(title)
				FOUND += 1
				NAME_1 = f"{title}{CAT}  [COLOR yellow]({str(TRIMMED)})[/COLOR]"
				NAME_2 = f"{title}{CAT}  [COLOR yellow]({str(TRIMMED)})[/COLOR]"
				if 'live' in DEM:
					NAME_1 = f"[B][COLOR chartreuse]■  ■  ■  [/COLOR]{NAME_1}[COLOR chartreuse]  ■  ■  ■[/COLOR][/B]"
					plot = f"[B]JETZT IM LIVESTREAM :[CR][COLOR lime]{str(TRIMMED)} - Event(s)[/COLOR][/B]"
				elif 'upcoming' in DEM:
					NAME_1 = f"[B][COLOR orangered]■  ■  ■  [/COLOR]{NAME_1}[COLOR orangered]  ■  ■  ■[/COLOR][/B]"
					plot = f"{title}[CR]{CAT} :[CR][COLOR gold]Einträge • {str(TRIMMED)}[/COLOR]"
				else:
					plot = f"{title}[CR]{CAT} :[CR][COLOR gold]Einträge • {str(TRIMMED)}[/COLOR]"
				debug_MS("(navigator.listCategories[2]) NUMBERING ### COMPLETE : {} ### FORFREE : {} ###".format(str(tt_count), str(TRIMMED)))
				COMBI_SECOND.append([POS, DEM, NAME_1, NAME_2, title, plot])
	if COMBI_SECOND and FOUND == 1:
		debug_MS("(navigator.listSeasons) ----- Only one Season FOUND - goto = listVideos -----")
		addDir(translation(30627).format(NAME_2), PHOTO, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
		for POS, DEM, NAME_1, NAME_2, title, plot in COMBI_SECOND:
			return listVideos(DEM, title+CAT, page, limit)
	elif COMBI_SECOND and FOUND > 1:
		for POS, DEM, NAME_1, NAME_2, title, plot in sorted(COMBI_SECOND, key=lambda d: int(d[0]), reverse=False):
			addDir(NAME_1, PHOTO, {'mode': 'listVideos', 'url': DEM, 'category': title+CAT}, plot)
			debug_MS(f"(navigator.listCategories[2]) ### TITLE : {str(NAME_1)} || URL : {DEM} ###")
	else:
		return dialog.notification(translation(30526).format('Einträge'), translation(30527).format(CAT), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listDates():
	debug_MS("(navigator.listDates) ------------------------------------------------ START = listDates -----------------------------------------------")
	config = traversing.get_config()
	DATA = getUrl(config['dating'])
	#log(f"(navigator.listDates[1]) ### DATES-01 : {str(DATA)} ###")
	for ii in range(-90, 91, 1):
		utc_start = (datetime.utcnow() - timedelta(days=ii + 1)).strftime('%Y-%m-%d') # 2023-07-19
		epoch_start = TGM(time.strptime(utc_start+'T22:00:00', '%Y-%m-%dT%H:%M:%S')) * 1000 # UTC-EPOCH-STARTZEIT einen Tag zurück um 22:00:00 Uhr (Milliseconds=168980400000)
		utc_end = (datetime.utcnow() - timedelta(days=ii)).strftime('%Y-%m-%d') # 2023-07-20
		epoch_end = TGM(time.strptime(utc_end+'T21:59:59', '%Y-%m-%dT%H:%M:%S')) * 1000 # UTC-EPOCH-ENDZEIT aktuell ausgewählter Tag um 21:59:59 Uhr (Milliseconds=1689890399000)
		if not utc_end in DATA: continue
		debug_MS(f"(navigator.listDates[2]) ### START_UTC : {utc_start} || START_EPOCH : {str(epoch_start)} ###")
		#debug_MS(f"(navigator.listDates[2]) ### ENDE_UTC  : {utc_ende} || ENDE_EPOCH  : {str(epoch_ende)} ###")
		WD = (datetime.utcnow() - timedelta(days=ii)).strftime('%d.%m.%y | %a') # Datum mit engl. Wochentagskürzel = 16.07.23 | Sun
		for av in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), ('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))):
			WD = WD.replace(*av)
		TIMING = config['starting'].format(epoch_start, epoch_end, page, limit)
		if ii == 0: addDir(translation(32108).format(WD), icon, {'mode': 'listVideos', 'url': TIMING, 'category': utc_end})
		else: addDir(WD, icon, {'mode': 'listVideos', 'url': TIMING, 'category': utc_end})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchSPORT():
	debug_MS("(navigator.SearchRTLPLUS) ------------------------------------------------ START = SearchRTLPLUS -----------------------------------------------")
	config = traversing.get_config()
	keyword = None
	if xbmcvfs.exists(searchHackFile):
		with open(searchHackFile, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30631), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword:
			keyword = quote_plus(keyword)
			with open(searchHackFile, 'w') as record:
				record.write(keyword)
	if keyword:
		return listVideos(config['searching'].format(keyword, page, 50), 'SEARCH: '+unquote_plus(keyword), page, 50)
	return None

def load_pagination(QUERY):
	global COMPS_WAY, TEAMS_WAY, EVENTS_WAY
	RECORD = False
	if QUERY.get('data', '') and not isinstance(QUERY['data'], list) and QUERY.get('data', {}).get('competitions', ''):
		addDir(translation(30632), icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
		COMPS_WAY = 'COMPS' # Nur in Suchfunktion vorhanden
		for item in QUERY.get('data', {}).get('competitions', ''): yield item
		RECORD = True
	if QUERY.get('data', '') and not isinstance(QUERY['data'], list) and QUERY.get('data', {}).get('teams', ''):
		addDir(translation(30633), icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
		TEAMS_WAY = 'TEAMS' # Nur in Suchfunktion vorhanden
		for item in QUERY.get('data', {}).get('teams', ''): yield item
		RECORD = True
	if 'data' in QUERY and QUERY['data'] and 'events' in QUERY['data'] and QUERY['data']['events']:
		addDir(translation(30634), icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
		EVENTS_WAY = 'EVENTS' # Nur in Suchfunktion vorhanden
		for item in QUERY['data']['events']: yield item
		RECORD = True
	if RECORD is False and QUERY.get('data', '') and isinstance(QUERY['data'], list):
		for item in QUERY.get('data', ''): yield item

def listVideos(TARGET, CAT, PAGE, LIMIT):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS("(navigator.listVideos) ##### URL = {} ##### CATEGORY = {} ##### PAGE = {} ##### LIMIT = {} #####".format(TARGET, CAT, PAGE, LIMIT))
	# Stream-Status-Codes = 200 : Livestream // 300 : Kommender Stream // 600 : Aufgezeichneter Stream
	config = traversing.get_config()
	DIRECTORY = ['competition', 'team']
	PLAYOUTS = ['live', 'latest', 'upcoming', 'all_events']
	FOUND = 0
	RESULTS = TARGET.split('page=')[0]+'page={}&per_page={}'.format(PAGE, LIMIT) if int(PAGE) > 1 else TARGET
	DATA_ONE = getUrl(RESULTS)
	for each in load_pagination(DATA_ONE):
		#log(f"(navigator.listVideos[1]) ### ITEM-01 : {str(each)} ###")
		plot, startCOMPLETE, startDATE, startTIME, endDATE, photo = (None for _ in range(6))
		BACKWARD, FORWARD = (False for _ in range(2))
		source, gender, fotoBIG = each, "", True
		FOUND += 1
		title = cleaning(each['name'])
		idd = each.get('uuid', '00')
		desc = cleaning(each['description']) if each.get('description', '') else None
		each = each['event'] if each.get('event', '') and 'highlights' in TARGET else each
		TYPE = each.get('eventType', '')
		if EVENTS_WAY == 'EVENTS' and TYPE == 'upcoming': continue # In der Suchfunktion die kommenden Spiele herausfiltern
		FREE = each.get('free', '')
		STAT = each.get('status', 500)
		sexo = each.get('gender', '')
		if sexo == 'women': gender = translation(30635).format(sexo.replace('women', 'F'))
		elif sexo == 'men': gender = translation(30636).format(sexo.replace('men', 'M'))
		if str(each.get('startTime'))[:4].isdigit(): # 2023-07-10T19:15:18.000Z
			LOCALstart = get_Local_DT(each['startTime'][:19])
			if each.get('startTime').endswith('+01:00'):
				GIVENstart = datetime(*(time.strptime(each['startTime'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))
				LOCALstart = (GIVENstart + timedelta(hours=1))
			elif each.get('startTime').endswith('+02:00'):
				LOCALstart = datetime(*(time.strptime(each['startTime'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))
			startCOMPLETE = LOCALstart.strftime('%a{0} %d{0}%m{0}%y {1} %H{2}%M').format( '.', '•', ':')
			for tt in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), ('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))):
				startCOMPLETE = startCOMPLETE.replace(*tt)
			startDATE = LOCALstart.strftime('%d{0}%m{0}%Y').format('.')
			startTIME = LOCALstart.strftime('%H{0}%M').format(':')
			if LOCALstart < datetime.now(): BACKWARD = True # 16:00 < 18:00
			elif LOCALstart > datetime.now(): FORWARD = True # 18:00 > 16:00
		if str(each.get('endTime'))[:4].isdigit(): # 2023-07-10T22:00:18.000Z
			LOCALend = get_Local_DT(each['endTime'][:19])
			if each.get('endTime').endswith('+01:00'):
				GIVENend = datetime(*(time.strptime(each['endTime'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))
				LOCALend = (GIVENend + timedelta(hours=1))
			elif each.get('endTime').endswith('+02:00'):
				LOCALend = datetime(*(time.strptime(each['endTime'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))
			endDATE = LOCALend.strftime('%d{0}%m{0}%YT%H{1}%M').format('.', ':')
			if LOCALend > datetime.now(): # 20:00 > 18:00
				BACKWARD, FORWARD = False, True
			if int(STAT) == 200 and startTIME and LOCALend < (datetime.now() - timedelta(hours=4)): STAT = 600
		if each.get('competition', '') and each.get('competition', {}).get('name', ''):
			if (not 'highlights' in TARGET and FORWARD is True) and startCOMPLETE:
				plot = translation(30637).format(title, cleaning(each['competition']['name']), startCOMPLETE)
				if desc and len(desc) > 90: plot += desc
			if plot is None and startDATE:
				plot = translation(30638).format(title, cleaning(each['competition']['name']), startDATE)
				if desc and len(desc) > 90: plot += desc
		elif 'teams' in TARGET:
			if each.get('competitions', '') and each.get('competitions', {})[0].get('name', ''):
				plot = translation(30639).format(title, cleaning(each['competitions'][0]['name']))
			else: continue
		elif EVENTS_WAY == 'EVENTS' and TYPE == 'latest' and startDATE:
			plot = translation(30640).format(title, startDATE)
			if desc and len(desc) > 90: plot += desc
		if plot is None: plot = desc
		photo = each['imageUrl'] if each.get('imageUrl', '') else None
		if photo is None and each.get('images', '') and isinstance(each['images'], list):
			num, resources = idd, each.get('images', [])
			photo = (get_Picture(num, resources, 'cover') or get_Picture(num, resources, 'thumb'))
			if photo is None:
				photo, fotoBIG = get_Picture(num, resources, 'logo'), False
		if photo is None and source.get('images', '') and isinstance(source['images'], list):
			num, resources = idd, source.get('images', []) # Bei Highlights sind die Bilder manchmal in der StartSource enthalten
			photo = (get_Picture(num, resources, 'cover') or get_Picture(num, resources, 'thumb'))
			if photo is None:
				photo, fotoBIG = get_Picture(num, resources, 'logo'), False
		if photo is None and each.get('teams', ''):
			if each.get('teams', {})[0].get('images', ''):
				num, resources = idd, each['teams'][0].get('images', [])
				photo = (get_Picture(num, resources, 'cover') or get_Picture(num, resources, 'thumb'))
				if photo is None:
					photo, fotoBIG = get_Picture(num, resources, 'logo'), False
			if photo is None and each.get('teams', {})[0].get('logoUrl', ''):
				photo, fotoBIG = each['teams'][0]['logoUrl'], False
		if photo is None:
			photo, fotoBIG = icon, False
		name = title+gender
		#if str(each.get('payPerViewPrice')).replace('.', '').replace('-', '').isdigit():
			#if int(str(each.get('payPerViewPrice', '')).replace('.', '').replace('-', '')) > 1: continue
		if idd != '00' and startDATE is None:
			if COMPS_WAY == 'COMPS': DRS = 'competition'
			elif TEAMS_WAY == 'TEAMS': DRS = 'team'
			elif any(ds in TARGET for ds in DIRECTORY):
				DRS = [ds for ds in DIRECTORY if ds in TARGET][0]
			addDir(name, photo, {'mode': 'listCategories', 'url': DRS+'@@'+idd, 'category': title, 'pict': photo}, plot, background=fotoBIG)
			debug_MS(f"(navigator.listVideos[2]) ### TITLE : {name} || URL : {DRS+'@@'+idd} || PHOTO : {photo} ###")
		elif idd != '00' and startDATE and (FREE is True or EVENTS_WAY == 'EVENTS'):
			name = f"{startDATE} - {title+gender}" if startDATE else title+gender
			if int(STAT) == 200 and FORWARD is True and startTIME:
				name = translation(30641).format(startTIME, title+gender)
			media = 'LIVE' if int(STAT) == 200 else 'VOD'
			table = 'event_playouts' if any(ps in TARGET for ps in PLAYOUTS) or TYPE in ['live', 'latest', 'upcoming', 'highlights'] else 'media_assets' # Event // MediaAsset // if each.get('event', '') and 'highlights' in TARGET
			addLink(name, photo, {'mode': 'playVideo', 'url': config['playing'].format(table, idd)}, plot, fotoBIG)
			debug_MS(f"(navigator.listVideos[3]) ### TITLE : {name} || URL : {config['playing'].format(table, idd)} || TYPE : {TYPE.lower()} ###")
	if FOUND == 0:
		return dialog.notification(translation(30526).format('Einträge'), translation(30527).format(CAT), icon, 8000)
	elif DATA_ONE.get('totalCount', '') and isinstance(DATA_ONE['totalCount'], int) and int(DATA_ONE['totalCount']) > int(PAGE)*int(LIMIT) and not 'searches' in TARGET:
		debug_MS(f"(navigator.listVideos[4]) PAGES ### Now show NextPage ... No.{str(int(PAGE)+1)} ... ###")
		addDir(translation(30642).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listVideos', 'url': TARGET, 'category': CAT, 'page': int(PAGE)+1, 'limit': int(LIMIT)})
	xbmcplugin.endOfDirectory(handle=ADDON_HANDLE)

def playVideo(url):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS(f"(navigator.playVideo) ##### URL = {url} #####")
	COMBI, MEDIAS = ([] for _ in range(2))
	EXTRA, FOUND, PayFree, STREAM, FINAL_URL, TEST_URL = (False for _ in range(6))
	result = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.playVideo[1]) XXXXX CONTENT : {str(result)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if result is not None and not result.get('errors', ''):
		if (result.get('event', '') and len(result['event']) > 0) or (result and len(result) > 0):
			DATA_ONE = result['event'] if result.get('event', '') and len(result['event']) > 0 else result
			if str(DATA_ONE.get('endTime'))[:4].isdigit(): # 2023-07-10T19:15:18.000Z
				LOCALend = get_Local_DT(DATA_ONE['endTime'][:19])
				if DATA_ONE.get('endTime').endswith('+01:00'):
					GIVENend = datetime(*(time.strptime(DATA_ONE['endTime'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))
					LOCALend = (GIVENend + timedelta(hours=1))
				elif DATA_ONE.get('endTime').endswith('+02:00'):
					LOCALend = datetime(*(time.strptime(DATA_ONE['endTime'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))
				EXTRA = 'LIVE' if datetime.now() < LOCALend else 'VOD'
				debug_MS(f"(navigator.playVideo[2]) ### NEW_TYPE : {str(EXTRA)} || DAYTIME (local NOW) : {str(datetime.now())[:19]} || official ENDTIME (local GAME) : {str(LOCALend)[:19]} ###")
			FOUND = True
			PayFree = True if DATA_ONE.get('free', '') is True else False
			Status = DATA_ONE.get('status', 500)
		if PayFree is True and (result.get('mediaAssets', '') and len(result['mediaAssets']) > 0) or (result.get('mediaAssetLocators', '') and len(result['mediaAssetLocators']) > 0):
			if result.get('mediaAssets', '') and isinstance(result['mediaAssets'], list):
				for STEPS in result['mediaAssets']:
					ASSET = STEPS.get('assetType', 'DEFAULT')
					if 'pano' in ASSET: continue
					for item in STEPS.get('mediaAssetLocators', []):
						NORM, VIDEO = item['mediaFormat'], item['url']
						MEDIAS.append({'video': VIDEO, 'asset': ASSET, 'norm': NORM})
			else:
				STEPS, ASSET = result, result.get('assetType', 'DEFAULT')
				for item in STEPS.get('mediaAssetLocators', []):
					if 'pano' in ASSET: continue
					NORM, VIDEO = item['mediaFormat'], item['url']
					MEDIAS.append({'video': VIDEO, 'asset': ASSET, 'norm': NORM})
			debug_MS(f"(navigator.playVideo[3]) HLS/MP4 ### SORTED_LIST : {str(MEDIAS)} ###")
	if MEDIAS:
		for item in MEDIAS:
			if ((EXTRA.lower() in item['asset']) or (not item['asset'].lower().startswith('broadcast'))) and item['norm'] == 'hls' and 'm3u8' in item['video']:
				STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
				MIME, FINAL_URL = 'application/x-mpegurl', item['video']
				log("(navigator.playVideo[4]) ***** TAKE - {} {} - FILE *****".format('Inputstream (hls)' if STREAM == 'HLS' else 'Standard (m3u8)', str(EXTRA)))
	if not FINAL_URL and MEDIAS:
		for item in MEDIAS:
			if item['norm'] == 'mp4' and ('.mp4' in item['video'] or '.ts' in item['video']):
				STREAM, MIME, FINAL_URL = 'MP4', 'video/mp4', item['video']
				log("(navigator.playVideo[4]) !!!!! KEINEN passenden Stream gefunden --- nehme jetzt den Reserve-Stream-MP4 !!!!!")
	if FOUND is True and PayFree is False:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {url} #####\n ########## Dieser Stream ist nur mit einem Bezahl-ABO-System von *https://sporttotal.tv/* abrufbar !!! ##########")
		return dialog.notification(translation(30528), translation(30529), icon, 10000)
	elif not STREAM:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {url} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *https://sporttotal.tv/* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('URL-1'), translation(30530), icon, 8000)
	try:
		code = urlopen(FINAL_URL, timeout=8).getcode()
		if code in [200, 201, 202]: TEST_URL = True
	except: pass
	if FINAL_URL and TEST_URL:
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		LSM.setMimeType(MIME)
		if ADDON_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LSM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
				if EXTRA and EXTRA == 'LIVE': # THE "full" BEHAVIOUR PARAM HAS BEEN REMOVED ON Kodi v21 because now enabled by default
					LSM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
			if KODI_ov20:
				LSM.setProperty('inputstream.adaptive.manifest_headers', f"User-Agent={get_userAgent()}")
			else: # DEPRECATED ON Kodi v20, please use 'inputstream.adaptive.manifest_headers' instead.
				LSM.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={get_userAgent()}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}")
	else:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### FINAL_URL : {str(FINAL_URL)} #####\n ########## Die Stream-Url auf der Webseite von *https://sporttotal.tv/* ist OFFLINE !!! ##########")
		return dialog.notification(translation(30521).format('URL-2'), translation(30531), icon, 8000)

def addDir(name, image, params={}, plot=None, folder=True, background=False):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setStudios(['Sporttotal.tv'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'Sporttotal.tv'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, background=False):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setGenres(['Sport']), vinfo.setStudios(['Sporttotal.tv']), vinfo.setMediaType('video')
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': 'Sport', 'Studio': 'Sporttotal.tv', 'Mediatype': 'video'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'Action(Queue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
