﻿# -*- coding: utf-8 -*-

import sys
import xbmc
import xbmcaddon


def translation(id):
	return xbmcaddon.Addon().getLocalizedString(id)

class Client(object):
	CONFIG_SPORTTOTAL = {
		'HOME_MENU': 'https://sporttotal.tv/api/v2/config/menu',
		'HOME_LIVENEXT': 'https://sporttotal.tv/api/v3/events?sport_uuid=all&sort_by=start_time&sort_order={}&status={}&expand[]=competition',
		'EVENT_DATES': 'https://sporttotal.tv/api/v2/event_dates',
		'EVENT_STARTS': 'https://sporttotal.tv/api/v3/75a0f3c0-33b9-4b92-b09b-94f2858f729c/events?event_type=all_events&expand[]=competition&expand[]=teams&expand[]=sport&resource_type=region&sort_field=start_time&sort_order=asc&start_time_gt={}&start_time_lt={}&page={}&per_page={}',
		'SEARCH_ALL': 'https://sporttotal.tv/api/v3/searches?details=true&query={}&page={}&per_page={}',
		'LIVE_EVENT': 'https://sporttotal.tv/api/v3/{}/events?event_type=live&expand[]=competition&expand[]=teams&expand[]=sport&resource_type={}&sort_field=start_time&sort_order=desc&page={}&per_page={}',
		'COMING_EVENT': 'https://sporttotal.tv/api/v3/{}/events?event_type=upcoming&expand[]=competition&expand[]=teams&expand[]=sport&resource_type={}&sort_field=start_time&sort_order=asc&page={}&per_page={}',
		'LATEST_EVENT': 'https://sporttotal.tv/api/v3/{}/events?event_type=latest&expand[]=competition&expand[]=teams&expand[]=sport&resource_type={}&sort_field=start_time&sort_order=desc&page={}&per_page={}',
		'HIGH_EVENT': 'https://sporttotal.tv/api/v3/{}/events?event_type=highlights&expand[]=competition&expand[]=teams&expand[]=event&expand[]=sport&resource_type={}&sort_field=start_time&sort_order=desc&page={}&per_page={}',
		'SPORT_CONTESTS': 'https://sporttotal.tv/api/v3/competitions?sport_uuid={}&sort_by=name&sort_order=asc&page={}&per_page={}',
		'SPORT_TEAMS': 'https://sporttotal.tv/api/v3/teams?active=true&sport_uuid={}&sort_by=name&sort_order=asc&page={}&per_page={}',
		'CONTEST_TEAMS': 'https://sporttotal.tv/api/v3/teams?active=true&competition_uuids[]={}&sort_by=name&sort_order=asc&page={}&per_page={}',
		'VIDEO_LINK': 'https://sporttotal.tv/api/v2/{}/{}',
		'picks': [
		{
			'title': translation(30621),
			'member': 'live',
			'id': 11
		},
		{
			'title': translation(30622),
			'member': 'upcoming',
			'id': 22
		},
		{
			'title': translation(30623),
			'member': 'latest',
			'id': 33
		},
		{
			'title': translation(30624),
			'member': 'highlights',
			'id': 44
		},
		{
			'title': translation(30625),
			'member': 'competitions',
			'id': 55
		},
		{
			'title': translation(30626),
			'member': 'teams',
			'id': 66
		}],
	}

	def __init__(self, config):
		self._config = config

	def get_config(self):
		return self._config
