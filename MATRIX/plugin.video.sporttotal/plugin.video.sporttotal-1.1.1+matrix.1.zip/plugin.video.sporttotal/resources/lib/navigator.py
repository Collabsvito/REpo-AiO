﻿# -*- coding: utf-8 -*-

from .common import *


def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	COMBI_TYPES = []
	DATA = getUrl(BASE_URL+'re938d1ec7.json?lang='+langSHORTCUT)#.replace('window.config={', '{')
	for each in DATA['menu']['content']:
		debug_MS("(navigator.mainMenu) ### ENTRY = {} ###".format(str(each)))
		title = (cleaning(each.get('title', None)) or None)
		idd = (each.get('id', None) or None)
		target = (cleaning(each.get('type', 'unknown')) or 'unknown')
		if (title and idd) and (target and idd not in COMBI_TYPES):
			COMBI_TYPES.append({'title': title, 'idd': str(idd)+'.json?lang='+langSHORTCUT, 'type': target})
	if COMBI_TYPES:
		relayed_1 = json.dumps(COMBI_TYPES)
		for item in sorted(COMBI_TYPES, key=lambda d: d['title'], reverse=False):
			if item['type'].lower() == 'sport' or 'amator ' in item['title'].lower():
				newCAT = item['title'] if not 'amator ' in item['title'].lower() else 'amator'
				debug_MS("(navigator.mainMenu) --- SPORT --- ### TITLE = {} ### URL = {} ### CATEGORY = {} ###".format(str(item['title']), BASE_URL+item['idd'], str(newCAT)))
				addDir(item['title'], icon, {'mode': 'listCategories', 'url': BASE_URL+item['idd'], 'category': newCAT})
		addDir(translation(30606), icon, {'mode': 'listEvents', 'url': relayed_1})
	if enableADJUSTMENT:
		addDir(translation(30607), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30608), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEvents(Xurl):
	debug_MS("(navigator.listEvents) -------------------------------------------------- START = listEvents --------------------------------------------------")
	debug_MS("(navigator.listEvents) ##### JSON-LIST = {} #####".format(str(Xurl)))
	COMBI_LEAGUES, COMBI_REGION, COMBI_EVENT = ([] for _ in range(3))
	RELAYED_1 = json.loads(Xurl)
	for elem in RELAYED_1:
		if elem['type'].lower() == 'competition':
			title_CO = cleaning(elem['title'])
			url_CO = BASE_URL+elem['idd']
			debug_MS("(navigator.listEvents) -- LEAGUES -- ### TITLE = {} ### URL = {} ###".format(str(title_CO), url_CO))
			COMBI_LEAGUES.append([title_CO, url_CO])
		elif elem['type'].lower() == 'region':
			title_RE = translation(30621).format(cleaning(elem['title']))
			url_RE = BASE_URL+elem['idd']
			debug_MS("(navigator.listEvents) --- REGION --- ### TITLE = {} ### URL = {} ###".format(str(cleaning(elem['title'])), url_RE))
			COMBI_REGION.append([title_RE, url_RE])
		elif elem['type'].lower() == 'event':
			title_EV = cleaning(elem['title'])
			url_EV = BASE_URL+elem['idd']
			debug_MS("(navigator.listEvents)  --- EVENT ---  ### TITLE = {} ### URL = {} ###".format(str(title_EV), url_EV))
			COMBI_EVENT.append([title_EV, url_EV])
	if COMBI_LEAGUES:
		for title_CO, url_CO in sorted(COMBI_LEAGUES, key=lambda ls: ls[0], reverse=False):
			addDir(title_CO, icon, {'mode': 'listCategories', 'url': url_CO, 'category': 'Competition'})
		addDir(translation(30622), icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
	if COMBI_REGION:
		for title_RE, url_RE in sorted(COMBI_REGION, key=lambda rn: rn[0].replace('Ö', 'Oe'), reverse=False):
			addDir(title_RE, icon, {'mode': 'listCategories', 'url': url_RE, 'category': 'Region'})
		addDir(translation(30622), icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
	if COMBI_EVENT:
		for title_EV, url_EV in sorted(COMBI_EVENT, key=lambda et: et[0], reverse=False):
			addDir(title_EV, icon, {'mode': 'listCategories', 'url': url_EV, 'category': 'Event'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listCategories(url, CAT, FILTER, THUMB): # https://api.sporttotal.tv/v2/live?sporttypeuuid=6294114c-5400-4978-bc6a-b3fe75d03fdf&channeluuid=00365d04-ad90-4ef7-b9b3-ef1e72890908
	debug_MS("(navigator.listCategories) -------------------------------------------------- START = listCategories --------------------------------------------------")
	debug_MS("(navigator.listCategories) ##### URL = {} ##### CATEGORY = {} ##### FILTER = {} #####".format(url, str(CAT), FILTER))
	langADAPTION = ['nächste', 'kommende', 'upcoming']
	UN_Supported = ['adac', 'amator', 'competition', 'event', 'motorsport', 'region']
	COMBI_CATIS = []
	ISOLATED = set()
	FOUND, position = (0 for _ in range(2))
	DATA = getUrl(url)#.replace('window.config={', '{')
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listCategories) XXXXX CONTENT : {} XXXXX".format(str(DATA)))
	debug_MS("++++++++++++++++++++++++")
	for each in DATA['components']:
		if each.get('component', '').lower() not in ['ads', 'description', 'videoplayer'] and each.get('title', ''): # in ['List', 'Table']:
			debug_MS("(navigator.listCategories) ### ENTRY = {} ###".format(str(each)))
			title = cleaning(each['title'])
			if title in ISOLATED or ('children' in each and len(each['children']) == 0):
				continue
			ISOLATED.add(title)
			FOUND += 1
			name = title
			if 'live' in title.lower():
				disqualified = 0
				COMPLETE = len(each['children'])
				for item in each.get('children', []):
					if str(item.get('payPerViewPrice', '')).replace('.', '').replace('-', '').isdigit():
						if int(str(item.get('payPerViewPrice', '')).replace('.', '').replace('-', '')) > 1: disqualified += 1
				TRIMMED = COMPLETE - disqualified
				debug_MS("(navigator.listCategories) NUMBERING ### COMPLETE = {} ### FORFREE = {} ###".format(str(COMPLETE), str(TRIMMED)))
				position, name = 1, translation(30623).format(str(TRIMMED))
			elif any(lg in title.lower() for lg in langADAPTION):
				position, name = 2, translation(30624)
			else: position = 3
			COMBI_CATIS.append([position, name, title])
	if COMBI_CATIS:
		for position, name, title in sorted(COMBI_CATIS, key=lambda d: d[0], reverse=False):
			newFILTER = 'amator' if CAT == 'amator' else 'standard'
			debug_MS("(navigator.listCategories[1]) no.01 ### TITLE = {} ### URL = {} ### FILTER = {} ###".format(str(name), url, newFILTER))
			addDir(name, THUMB, {'mode': 'listVideos', 'url': url, 'category': title, 'transmit': newFILTER})
	if FOUND == 0:
		return dialog.notification(translation(30524).format('Ergebnisse'), translation(30525), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def listVideos(url, CAT, FILTER):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS("(navigator.listVideos) ##### URL = {} ##### CATEGORY = {} ##### FILTER = {} #####".format(url, str(CAT), FILTER))
	FOUND = 0
	DATA = getUrl(url)#.replace('window.config={', '{')
	for each in DATA['components']:
		if each.get('title', ''):
			RUBRIK = cleaning(each['title'])
			if RUBRIK == CAT and 'children' in each and len(each['children']) > 0:
				for item in each.get('children', []):
					debug_MS("(navigator.listVideos) ### ENTRY = {} ###".format(str(item)))
					gender, plot = ("" for _ in range(2))
					startCOMPLETE, startDATE, startTIME = (None for _ in range(3))
					fotoBIG = True
					FOUND += 1
					title = cleaning(item['title'])
					idd = str(item['id']).strip()+'.json?lang='+langSHORTCUT
					sexo = (cleaning(item.get('gender', '')) or "")
					if sexo == 'WOMEN': gender = translation(30625).format(sexo.replace('WOMEN', 'F'))
					elif sexo == 'MEN': gender = translation(30626).format(sexo.replace('MEN', 'M'))
					if str(item.get('date')).isdigit():
						LOCALstart = get_Local_DT(datetime(1970,1,1) + timedelta(milliseconds=item.get('date')))
						startCOMPLETE = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						startDATE = LOCALstart.strftime('%d{0}%m{0}%Y').format('.')
						startTIME = LOCALstart.strftime('%H{0}%M').format(':')
					plot = (cleaning(item.get('description', '')) or "")
					if plot == "" and item.get('competition', {}).get('title', ''):
						plot = cleaning(item['competition']['title'])+" :[CR]"+title
					photo = (quote(item.get('image', {}).get('cover', ''), safe='/:') or quote(item.get('image', {}).get('thumb', ''), safe='/:') or icon)
					if photo == icon:
						if item.get('teams', '') and item.get('teams', {})[0].get('image', ''):
							photo = (quote(item.get('teams', [])[0].get('image', {}).get('logo', ''), safe='/:') or quote(item.get('teams', [])[0].get('image', {}).get('thumb', ''), safe='/:') or icon)
						elif item.get('image', '') and item.get('image', {}).get('logo', ''):
							photo = quote(item.get('image', {}).get('logo', ''), safe='/:')
						fotoBIG = False
					name = title+gender
					if str(item.get('payPerViewPrice')).replace('.', '').replace('-', '').isdigit():
						if int(str(item.get('payPerViewPrice', '')).replace('.', '').replace('-', '')) > 1: continue
					TYPE = (cleaning(item.get('type', '')) or "")
					if (FILTER == 'amator' or TYPE.lower() in ['match', 'video'] or item.get('video', '')):
						debug_MS("(navigator.listVideos[1]) no.01 ### TITLE = {} ### TYPE = {} ###".format(str(title), TYPE.lower()))
						debug_MS("(navigator.listVideos[1]) no.01 ### URL = {} ###".format(BASE_URL+idd))
						name = startDATE+" - "+title+gender if startDATE and not '1970' in startDATE else title+gender
						if 'live' in RUBRIK.lower() and startTIME:
							name = translation(30627).format(startTIME, title+gender)
						elif not 'live' in RUBRIK.lower() and startCOMPLETE:
							if LOCALstart > datetime.now():
								name = startCOMPLETE+" - "+title+gender
						addLink(name, photo, {'mode': 'playVideo', 'url': BASE_URL+idd, 'category': name}, plot, fotoBIG)
					else:
						xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
						debug_MS("(navigator.listVideos[2]) no.02 ### TITLE = {} ### TYPE = Category-Folder ###".format(str(title)))
						debug_MS("(navigator.listVideos[2]) no.02 ### URL = {} ###".format(BASE_URL+idd))
						if not 'amator' in title.lower():
							addDir(name, photo, {'mode': 'listCategories', 'url': BASE_URL+idd, 'transmit': 'no_Additives', 'picture': photo}, plot, background=fotoBIG)
	if FOUND == 0:
		return dialog.notification(translation(30524).format('Einträge'), translation(30526).format(CAT), icon, 8000)
	xbmcplugin.endOfDirectory(handle=ADDON_HANDLE, cacheToDisc=False)

def playVideo(url, NAME):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS("(navigator.playVideo) ##### URL = {} ##### NAME = {} #####".format(url, str(NAME)))
	m3u8_LIST, mp4_LIST = ([] for _ in range(2))
	stream, FILE_URL, TEST_URL = (False for _ in range(3))
	DATA = getUrl(url)#.replace('window.config={', '{')
	for each in DATA['components']:
		if each.get('component', '').lower() == 'videoplayer' and each.get('video', ''):
			videos = list(browse_All(each['video'], 'value')) # FILTER show only the Values behind constantly changing Key (default, Default, video...)
			for elem in videos:
				if 'm3u8' in elem.lower() and not 'pano' in elem.lower():
					m3u8_LIST.append(elem)
					FILE_URL = True
				if ('mp4' in elem.lower() or '.ts' in elem.lower()) and not 'pano' in elem.lower():
					mp4_LIST.append(elem)
					FILE_URL = True
			debug_MS("(navigator.playVideo[1]) ### VIDEOS_m3u8 = {} ###".format(str(m3u8_LIST)))
			debug_MS("(navigator.playVideo[1]) ### VIDEOS_mp4 = {} ###".format(str(mp4_LIST)))
	if m3u8_LIST:
		stream = m3u8_LIST[0]
	if mp4_LIST and not stream:
		stream = mp4_LIST[1] if len(mp4_LIST) > 1 else mp4_LIST[0]
	if not stream:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *sporttotal.tv* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('URL-1'), translation(30527), icon, 8000)
	finalURL = quote(stream, safe='_/:-.%20')
	debug_MS("(navigator.playVideo[2]) ### standardSTREAM = {} ### correctSTREAM = {} ###".format(stream, finalURL))
	try:
		code = urlopen(finalURL, timeout=8).getcode()
		if code in [200, 201, 202]: TEST_URL = True
	except: pass
	if FILE_URL and TEST_URL: # https://d3j8poz04ftomu.cloudfront.net/RECORD/0_hd_hls.m3u8?hlsid=HTTP_ID_1
		log("(navigator.playVideo) StreamURL : {}".format(finalURL))
		LSM = xbmcgui.ListItem(path=finalURL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'm3u8' in finalURL:
			LSM.setMimeType('application/vnd.apple.mpegurl')
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			LSM.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
	else:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### URL : {} #####\n   ########## Die Stream-Url auf der Webseite von *sporttotal.tv* ist OFFLINE !!! ##########".format(finalURL))
		return dialog.notification(translation(30521).format('URL-2'), translation(30528), icon, 8000)

def addDir(name, image, params={}, plot=None, folder=True, background=False):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot), videoInfoTag.setStudios(['Sporttotal.tv'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'Sporttotal.tv'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, background=False):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot), videoInfoTag.setGenres(['Sport']), videoInfoTag.setStudios(['Sporttotal.tv']), videoInfoTag.setMediaType('video')
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': 'Sport', 'Studio': 'Sporttotal.tv', 'Mediatype': 'video'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'Action(Queue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
