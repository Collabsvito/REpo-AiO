﻿# -*- coding: utf-8 -*-

from .common import *
config = traversing.get_config()


def main_menu():
	for item in config['samples']:
		title = item['title_de'] if GERM else item['title_fr']
		target = item.get('link').format(API_EMAC) if item.get('link') is not None and item['action'] != 'list_categories' else item.get('link', '00')
		fetch_items = create_entries({'Title': title, 'Image': f"{artpic}{item.get('thumb')}"})
		if item['action'] not in ['antuning', 'ietuning']:
			add_views({'mode': item['action'], 'link': target, 'phase': item['phase'], 'name': title}, fetch_items)
		if enable_tune and item['action'] == 'antuning':
				add_views({'mode': item['action']}, fetch_items, False)
		if enable_tune and item['action'] == 'ietuning' and enable_adaptive and plugin_operate('inputstream.adaptive'):
				add_views({'mode': item['action']}, fetch_items, False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_categories(extra):
	debug_MS(f"(navigator.list_{extra.lower()}) --------------------------------------------- START = list_{extra.lower()} ---------------------------------------------")
	supported = ['BAR', 'ADS', 'MUE', 'HIP', 'JAZ', 'CLA', 'MET', 'OPE', 'MUA', 'MUD'] if extra == 'MUSICS' else ['ACT', 'DOR', 'DEC', 'SER', 'HIS', 'CIN', 'CPO', 'EMI', 'SCI']
	data_uno = track_content(config['edges_one'].format(API_EMAC), headers=WEB_HEADER)
	if extra == 'MUSICS':
		fetch_uno = create_entries({'Title': translation(30641) if GERM else translation(30642), 'Image': f"{thepic}ARS.png"})
		add_views({'mode': 'list_broadcasts', 'link': config['edges_two'].format(API_EMAC, 'ARTE_CONCERT'), 'phase': 'ARS', 'name': 'ARTE CONCERT'}, fetch_uno)
	for item in supported:
		for theme in data_uno:
			if theme.get('deeplink', '') and theme['deeplink'].endswith(f"emac/{item}"):
				code, teaser = item, get_plotting(theme)
				if extra == 'MUSICS':
					name = theme['label'].replace('Barock', translation(30643)).replace('Baroque', translation(30644)).replace('Performance', translation(30645)).replace('Electro', translation(30646) if GERM else translation(30647)).replace('Klassische Musik', translation(30648))
					title = translation(30649).format(name)
				else:
					name = theme['label'] if item != 'EMI' else translation(30650) if GERM else translation(30651)
					title = f"[B]{name}[/B]"
				debug_MS(f"(navigator.list{extra.title()}[1]) ### NAME : {name} || CATEGORY : {code} || URL : {config['edges_two'].format(API_EMAC, code)} ###")
				fetch_due = create_entries({'Title': title, 'Tagline': teaser, 'Image': f"{thepic}{code}.png"})
				add_views({'mode': 'list_broadcasts', 'link': config['edges_two'].format(API_EMAC, code), 'phase': code, 'name': name}, fetch_due)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_thoroughs(extra):
	debug_MS(f"(navigator.list_{extra.lower()}) --------------------------------------------- START = list_{extra.lower()} ---------------------------------------------")
	if extra == 'HISTORY':
		supported = [{'name': 'Stimmt es, dass...?', 'zone': 'de609ad5-a957-4109-b7a9-869826256ed1', 'coll': 'RC-026488'},{'name': 'Das 20. Jahrhundert', 'zone': '2b58ae11-edfa-49f3-bab8-134920410e06'},
			{'name': 'Die Zeit vor dem 20. Jahrhundert', 'zone': 'f30c86a4-ed63-41c0-a48d-3cbba123c054'},{'name': 'Die großen Dokureihen', 'zone': '8fbf35e4-324d-4d3e-a194-28f7d288789b', 'coll': 'RC-020554'},
			{'name': 'Biographien', 'zone': '7d91ee35-62fb-4c4f-aec3-057e02196ea3'},{'name': 'Geschichte schreiben', 'zone': 'f9136297-c639-48c7-865c-3f5db07de468', 'coll': 'RC-020782'}] if GERM else \
				[{'name': 'Est-il vrai que...?', 'zone': 'd3bad9c8-b1c0-43db-87fb-fb95cc68766d', 'coll': 'RC-026488'},{'name': 'Civilisations', 'zone': '0fdfa046-a060-4ab3-9498-871a1d15c7e3'},
				{'name': 'XXe siècle', 'zone': '4ed8b40a-ba13-4da4-8574-2a1b73a5878b'},{'name': "Les séries documentaires d'histoire", 'zone': 'e0dfcff6-67bc-4d83-8055-8edf45687aea', 'coll': 'RC-020554'},
				{'name': 'Les grands personnages', 'zone': '8c788ec9-8b2c-455d-b856-7f105ca0dc4e'},{'name': "Faire l'histoire", 'zone': '5c5ab0fc-a32c-493c-bfa1-7d4eddca8834', 'coll': 'RC-020782'}]
		for item in supported:
			link = config['collections_one'].format(API_EMAC, item['coll']) if item.get('coll', None) else config['zones_one'].format(API_EMAC, item['zone'], LOC_LANG)
			debug_MS(f"(navigator.list{extra.title()}[1]) ### NAME : {item['name']} || CATEGORY : Geschichte/Histoire=HIS || URL : {link} ###")
			add_views({'mode': 'list_broadcasts', 'link': link, 'phase': 'HIS', 'name': item['name']}, create_entries({'Title': item['name']}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_videodates(start, extra):
	debug_MS("(navigator.list_videodates) --------------------------------------------- START = list_videodates ---------------------------------------------")
	debug_MS(f"(navigator.list_videodates) ### URL = {start} || EXTRA = {extra} ###")
	if extra == 'display': # URL-Day = https://www.arte.tv/api/rproxy/emac/v4/de/web/pages/TV_GUIDE/?day=2026-02-11
		found, data_uno = 0, track_content(start, headers=WEB_HEADER)
		for movie in data_uno['zones'][-1]['content']['data']:
			if 'FULL_VIDEO' in str(movie.get('stickers')) and str(movie.get('duration')).isdecimal() and int(movie['duration']) > 0 and movie.get('programId', None):
				found += 1
				part_uno = create_substances(movie, movie['title'], 'DATA_ONE', 'TV_GUIDE', '(list_videodates=VIDEOS[1])')
				if part_uno[0] is None: continue
				add_views(part_uno[0], create_entries(part_uno[1]), part_uno[2])
		if found == 0:
			failing(f'(navigator.list_videodates) ##### NO VIDEO-DATE-LIST - NO ENTRY FOR: "{start.split("?day=")[1]}" FOUND #####')
			return dialog.notification(translation(30524), translation(30526).format(start.split('?day=')[1]), icon, 10000)
	else:
		for ii in range(-20, 21, 1):
			ends = (datetime.now() - timedelta(days=ii)).strftime('%Y-%m-%d') # Date for URL // 2025-06-11
			datum = (datetime.now() - timedelta(days=ii)).strftime('%w~%d.%m.') # Date with weekday numbering // 3~11.06.
			tage = [xrs for xrs in config['weekdays'] if xrs.get('route') == datum.split('~')[0]]
			title = translation(30685).format(tage[0]['title_de'] if GERM else tage[0]['title_fr'], datum.split('~')[1]) if ii == 0 else \
				f"{tage[0]['title_de'] if GERM else tage[0]['title_fr']}, {datum.split('~')[1]}"
			add_views({'mode': 'list_videodates', 'link': f"{start}{ends}", 'extra': 'display'}, create_entries({'Title': title, 'Image': f"{artpic}days.png"}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_broadcasts(target, phrase, naming, pages):
	debug_MS("(navigator.list_broadcasts) --------------------------------------------- START = list_broadcasts ---------------------------------------------")
	naming = re.sub(r'\[/?B\]', '', naming)
	debug_MS(f"(navigator.list_broadcasts) ### URL = {target} || PHRASE = {phrase} || NAME = {naming} || PAGE = {pages} ###")
	beam_one, total_beam, next_one, total_one, next_two, total_two = (None for _ in range(6))
	unikat, combo_uno, (course, count_one, count_top, count_exc) = set(), [], (0 for _ in range(4))
	forward, proceed, limitation, scrolling, maximum = False, False, 20, int(pages), int(pages)+1
	include_code = ('collection_videos', 'videos_subcategory', 'collection_subcollection', 'listing_') # Wanted Collections
	exclude_code = ('collection_content', 'collection_upcoming', 'collection_article', 'collection_associated', 'collection_partner') # Unwanted Collections
	exclude_name = ('auch interessant', 'à voir aussi', 'demnächst', 'à venir') # Unwanted Titles = à voir aussi: auch interessant // à venir: demnächst
	if GERM is True: # e3df396a-3d21-4e6e-908b-17f57e99146d...Nach Themen in 1.Dokus(46d) // 76fdf18b-f820-4270-90f2-fa13243e6e21...Hintergründe in 2.Dokus(e21)
		exclude_cids = ['e3df396a-3d21-4e6e-908b-17f57e99146d', '76fdf18b-f820-4270-90f2-fa13243e6e21']
	else: # fb7c69e9-9b71-468d-b4e3-d2c9309cfb74...Nach Themen in 1.Dokus(b74)
		exclude_cids = ['fb7c69e9-9b71-468d-b4e3-d2c9309cfb74']
	switch = True if any(xs in phrase for xs in ['ARS', 'CONCERT', 'BAR', 'ADS', 'MUE', 'HIP', 'JAZ', 'CLA', 'MET', 'OPE', 'MUA', 'MUD']) else False
	collect = True if 'collections/' in target or 'subCollectionId' in target else False # Series name for mixed content = Do not display for folders/videos
	while scrolling > 0:
		course += 1
		data_uno = track_content(target, headers=WEB_HEADER) if scrolling == 1 or course == 1 else track_content(next_page, headers=WEB_HEADER) if next_page else data_uno
		debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++")
		debug_MS(f"(navigator.list_broadcasts[1]) XXXXX CONTENT-01 : {data_uno} XXXXX")
		debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++")
		data_due = data_uno['zones'] if data_uno.get('zones', '') and len(data_uno['zones']) > 0 else \
			data_uno['data'] if data_uno.get('data', '') and len(data_uno['data']) > 0 else []
		coll_names = [cn for cn in data_due if str(cn.get('code')).lower().startswith(include_code) and cn.get('content', '') and cn['content'].get('data', '')]
		for each in data_due:
			if each.get('content', '') and each['content'].get('data', '') and len(each['content']['data']) > 0:
				count_one += 1
				newPHR = data_uno['code'] if data_uno.get('code', '') and phrase == 'HOME' else phrase # TransmissionCode for Most Viewed and Last Chance
				if ((count_one in [1, 2] and 'pages/HOME' in target) or (count_one == 1 and not 'pages/HOME' in target)) and each.get('displayOptions', '') and \
					each['displayOptions'].get('showZoneTitle', True) is False and each['displayOptions'].get('showItemTitle', False) is True:
					count_top += 1
					for video in each['content']['data']: # If videos are available in the first category = show it directly
						series = video.get('subtitle', None) if switch or 'ARTE_CONCERT' in str(video.get('stickers')) or not collect else video['title']
						part_uno = create_substances(video, series, 'DATA_TWO', newPHR, '(list_broadcasts=VIDEOS[1])')
						combo_uno.append([int(count_top), series, part_uno[0], part_uno[1], part_uno[2], newPHR])
				else:
					if each.get('displayOptions', '') and str(each['displayOptions'].get('template')).startswith('event'): continue # Hide trailer preview
					if (len(each['content']['data']) == 1 and str(each['content']['data'][0].get('programId')) in ['', 'None']) or (str(each.get('title')).lower().startswith(exclude_name)) or \
						(str(each.get('id')).split('_')[0] in exclude_cids) or (str(each.get('code')).lower().startswith(exclude_code)): continue # 1. z.b. Newsletter // 2. exclude_name // 3. exclude_cids // 4. exclude_code
					if len(each['content']['data']) == 1 and str(each['content']['data'][0].get('programId'))[:3] == 'RC-': # z.b. Happy Hour under All Films
						short, series, count_top = each['content']['data'][0], each['content']['data'][0]['title'], count_top.__add__(1)
						part_due = create_substances(short, series, 'DATA_TWO', newPHR, '(list_broadcasts=VIDEOS[2])')
						combo_uno.append([int(count_top), series, part_due[0], part_due[1], part_due[2], newPHR])
					elif each.get('code', '') and str(each.get('code')).lower().startswith(include_code):
						if len(coll_names) > 1:
							count_top, count_exc = count_top.__add__(1), count_exc.__add__(1) # This is a folder, so exclude it from the sort function
							part_tre = create_substances(each, naming, 'ZONE_TWO', newPHR, '(list_broadcasts=FOLDER[1])')
							combo_uno.append([int(count_top), naming, part_tre[0], part_tre[1], part_tre[2], newPHR])
						else:
							forward = True
							beam_one = each['content']['pagination']['links']['next'] if each.get('content', '') and each['content'].get('pagination', '') and \
								each['content']['pagination'].get('links', '') and 'api/emac' in str(each['content']['pagination']['links'].get('next')) else None
							total_beam = each['content']['pagination']['totalCount'] if each.get('content', '') and each['content'].get('pagination', '') and \
								str(each['content']['pagination'].get('totalCount')).isdecimal() else None
							for mixed in each['content']['data']:
								if mixed.get('kind', '') and mixed['kind'].get('isCollection', False) is True:
									series, term, mark, count_top, count_exc = naming, 'ZONE_TWO', '(list_broadcasts=FOLDER[2])', count_top.__add__(1), count_exc.__add__(1) # This is a folder, so exclude it from the sort function
								else:
									series = mixed.get('subtitle', None) if switch or 'ARTE_CONCERT' in str(mixed.get('stickers')) or not collect else mixed['title']
									term, mark, count_top = 'DATA_TWO', '(list_broadcasts=VIDEOS[3])', count_top.__add__(1)
								part_quat = create_substances(mixed, series, term, newPHR, mark)
								combo_uno.append([int(count_top), series, part_quat[0], part_quat[1], part_quat[2], newPHR])
					else:
						series, count_top, count_exc = naming, count_top.__add__(1), count_exc.__add__(1) # This is a folder, so exclude it from the sort function
						part_cinq = create_substances(each, series, 'ZONE_TWO', newPHR, '(list_broadcasts=FOLDER[3])')
						combo_uno.append([int(count_top), series, part_cinq[0], part_cinq[1], part_cinq[2], newPHR])
			elif data_uno.get('data', '') and len(data_uno['data']) > 0:
				count_top, count_exc = count_top.__add__(1), count_exc.__add__(1) if 'collectION' in str(each.get('stickers')) else count_exc # This is a folder, so exclude it from the sort function
				series = each.get('subtitle', None) if switch or 'ARTE_CONCERT' in str(each.get('stickers')) else each['title']
				part_sei = create_substances(each, series, 'DATA_TWO', phrase, '(list_broadcasts=VARIABLE[1])')
				combo_uno.append([int(count_top), series, part_sei[0], part_sei[1], part_sei[2], phrase])
		if course == 1 and int(count_top) < 19: # Less than 19 entries
			limitation, maximum, display = int(count_top), int(maximum)+2, int(maximum+2) // 4 + 1
		elif course == 1 and 19 <= int(count_top) <= 42 : # Entries between 19 and 42
			limitation, maximum, display = int(limitation), int(maximum), int(maximum) // 2 + 1
		elif course == 1 and int(count_top) > 42: # More than 42 entries
			limitation, maximum, display = int(count_top), int(maximum)-1, int(maximum)
		next_one, total_one = beam_one if forward is True else None, total_beam if forward is True else None
		forward = False
		next_two = data_uno['pagination']['links']['next'] if data_uno.get('pagination', '') and \
			data_uno['pagination'].get('links', '') and 'api/emac' in str(data_uno['pagination']['links'].get('next')) else None
		total_two = data_uno['pagination']['totalCount'] if data_uno.get('pagination', '') and \
			str(data_uno['pagination'].get('totalCount')).isdecimal() else None
		next_page = API_EMAC+next_one.split('web/')[1] if next_one else API_EMAC+next_two.split('web/')[1] if next_two else None
		numbers = total_one if total_one and next_one else total_two if total_two and next_two else None
		debug_MS(f"(list_broadcasts=PAGES[1]) ### CHANGES : {switch} || COUNT-TOP : {count_top} || TOTAL-COUNT : {numbers} || PAGE*LIMIT : {int(scrolling)*int(limitation)} || MAX-PAGES : {maximum} ###")
		if next_page and numbers and int(numbers) > int(scrolling)*int(limitation) and int(scrolling+1) <= int(maximum):
			debug_MS(f"(list_broadcasts=PAGES[2]) ### NOW GET NEXTPAGE FROM MAXIMUM : {next_page} ###")
			scrolling += 1
		else: # next_page = /api/emac/v4/de/web/zones/af9b8927-0c87-4bc7-8772-e9f889f417d9/content?authorizedCountry=DE&page=2&pageId=FIC&zoneIndexInPage=0
			if next_page and numbers and int(numbers) > int(scrolling)*int(limitation) and int(scrolling) == int(maximum):
				proceed = True
			break
	if combo_uno: # Counter ZERO is always the numbering of the list
		for xev in sorted(combo_uno, key=lambda pn: int(pn[0])): # xev[0]=NUMBER, xev[1]=TITLE, xev[2]=ARGIOS, xev[3]=FETCH_UNO, xev[4]=FOLDER, xev[5]=PHRASE
			if xev[2] is not None and frozenset(xev[2].items()) not in unikat:
				unikat.add(frozenset(xev[2].items())) # Filtering double Entries out in Dictionary and hold sortorder
				add_views(xev[2], create_entries(xev[3]), xev[4], True if int(pages) > 2 else False, xev[5])
	if count_top >= 1:
		if proceed is True:
			fetch_blades = {'Title': translation(30701).format(display) if GERM else translation(30702).format(display), 'Image': f"{artpic}nextpage.png"}
			add_views({'mode': 'list_broadcasts', 'link': next_page, 'phase': phrase, 'name': naming, 'page': int(scrolling)+1}, create_entries(fetch_blades))
			debug_MS(f"(list_broadcasts=PAGES[3]) === NOW SHOW FOLLOWING-PAGE ENTRY ... No.{int(scrolling)+1} || URL : {next_page} ... ===")
		if count_exc == 0:
			for method in get_sorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	elif count_top == 0:
		message = translation(30526).format(naming) if naming != 'Unknown' else translation(30525)
		failing(f'(navigator.list_broadcasts) ##### NO BROADCAST-LIST - NO ENTRY FOR: "{naming}" FOUND #####')
		return dialog.notification(translation(30524), message, icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE) 

def search_arte():
	debug_MS("(navigator.search_arte) --------------------------------------------- START = search_arte ---------------------------------------------")
	keyword = preserve(SEARCH_FILE)
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(translation(30711) if GERM else translation(30712), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, keyword)
	if keyword: return list_broadcasts(config['search_query'].format(API_EMAC, quote(keyword)), 'SEARCH', keyword, 1)
	return None

def calling_infos(target, phrase):
	debug_MS("(navigator.calling_infos) --------------------------------------------- START = calling_infos ---------------------------------------------")
	change = True if any(cs in phrase for cs in ['ARS', 'CONCERT', 'BAR', 'ADS', 'MUE', 'HIP', 'JAZ', 'CLA', 'MET', 'OPE', 'MUA', 'MUD']) else False
	debug_MS(f"(navigator.calling_infos[1]) ### CHANGE = {change} || TARGET = {target} || PHRASE = {phrase}")
	contents = track_content(config['programs_one'].format(API_EMAC, target), headers=WEB_HEADER)
	if contents.get('zones', '') and len(contents['zones']) > 0:
		for articles in contents.get('zones', []):
			if str(articles.get('code')).lower().startswith('program_content') and articles.get('content', '') and articles['content'].get('data', '') and len(articles['content']['data']) > 0:
				for selection in articles['content'].get('data', []):
					entries = create_substances(selection, selection['title'], 'DATA_THREE', 'INFORMATION', '(calling_infos=VIDEOS[1])')
					title = entries[1].get('TvShowTitle') if change and entries[1].get('TvShowTitle') is not None and entries[1].get('Title') is not None else entries[1].get('Title')
					series = entries[1].get('Title') if change and entries[1].get('TvShowTitle') is not None else None if change and entries[1].get('TvShowTitle') is None else entries[1].get('TvShowTitle')
					plot = translation(30721).format(title) # Title
					if series is not None: plot += translation(30722).format(series) if GERM else translation(30723).format(series) # TV-Show
					if entries[1].get('Year') is not None:
						plot += translation(30724).format(entries[1].get('Year')) if GERM else translation(30725).format(entries[1].get('Year')) # Production-Year
					if entries[1].get('Duration') is not None and str(entries[1].get('Duration')).isdecimal():
						plot += translation(30726).format(int(entries[1].get('Duration')) // 60) if GERM else translation(30727).format(int(entries[1].get('Duration')) // 60) # Duration in minutes
					if entries[1].get('Genre') is not None and len(entries[1].get('Genre')) > 0: plot += translation(30728).format(entries[1].get('Genre'))
					if entries[1].get('Country') is not None and len(entries[1].get('Country')) > 0:
						plot += translation(30729).format(entries[1].get('Country')) if GERM else translation(30730).format(entries[1].get('Country')) # Countries
					if entries[1].get('Cast') is not None and len(entries[1].get('Cast')) > 0:
						plot += translation(30731).format(entries[1].get('Cast')) if GERM else translation(30732).format(entries[1].get('Cast')) # Cast-Names small
					if entries[1].get('Director') is not None and len(entries[1].get('Director')) > 0:
						plot += translation(30733).format(entries[1].get('Director')) if GERM else translation(30734).format(entries[1].get('Director')) # Director-Names
					if entries[1].get('Writer') is not None and len(entries[1].get('Writer')) > 0:
						plot += translation(30735).format(entries[1].get('Writer')) if GERM else translation(30736).format(entries[1].get('Writer')) # Writer-Names
					if entries[1].get('Mpaa') is not None:
						plot += translation(30737).format(entries[1].get('Mpaa')) if GERM else translation(30738).format(entries[1].get('Mpaa')) # Mpaa
					if len(entries[1].get('Desc_Small')) > 0: plot += f"[CR]{entries[1].get('Desc_Small')}" # Description
					if len(plot) < 40: plot = translation(30739) if GERM else translation(30740) # Nothing found
					dialog.textviewer(translation(30741) if GERM else translation(30742), plot, usemono=True)

def create_substances(info, naming, category, phrase, capture, FOLDER=True, STOCK=False):
	(note_1, note_2, note_3), fanart = ("" for _ in range(3)), defaultFanart
	season, episode, tagline, start_times, starting, airing, ends_times, mpaa, ARGIOS, duration, thumb, poster = (None for _ in range(12))
	yearings, countries, directors, writers, actoring = (None for _ in range(5))
	objects_code = info['id'].split('_')[0] if info.get('id', '') and '_' in info['id'] else info['id'] if info.get('id', '') else None
	program_code = info.get('programId', None)
	name = info['title'].strip()
	subtitle = info['subtitle'].strip() if info.get('subtitle', '') else None
	marker ='lastOverview' if str(info.get('code')).lower().startswith(('collection_videos', 'collection_subcollection')) else None # Hide Poster-Pictures in Season/Episode-Listing
	matchSEA = re.search(r'(Staffel:? |Saison:? )([0-9]+)', info['title']) # "Staffel 2, Folge 5 // Staffel: 2, Folge: 6 // S2 E10 // (2/2)
	if matchSEA: season = f"{int(matchSEA.group(2)):02}" if str(matchSEA.group(2)).isdecimal() and int(matchSEA.group(2)) != 0 else None
	matchEP = re.search(r'(Episode:? |Épisode:? |Folge:? |E)([0-9]+)', info['title']) # Folge 18 // Staffel: 2, Folge: 6 // S2 E10
	if matchEP: episode = f"{int(matchEP.group(2)):02}" if str(matchEP.group(2)).isdecimal() and int(matchEP.group(2)) != 0 else None
	if episode is None:
		matchSO = re.search(r'\(([0-9]+)/[0-9]+\)', info['title']) # (1/2)
		if matchSO: episode = f"{int(matchSO.group(1)):02}" if str(matchSO.group(1)).isdecimal() and int(matchSO.group(1)) != 0 else None
	if episode is None and subtitle:
		matchDE = re.search(r'(Episode:? |Épisode:? |Folge:? |E)([0-9]+)', subtitle) # Folge 18 // Staffel: 2, Folge: 6 // S2 E10
		if matchDE: episode = f"{int(matchDE.group(2)):02}" if str(matchDE.group(2)).isdecimal() and int(matchDE.group(2)) != 0 else None
	if str(name)[:10].upper() in ['BANNER TEM', 'ZONE EVENT'] and info.get('content', '') and info['content'].get('data', '') and len(info['content']['data']) > 0:
		name = f"{info['content']['data'][0]['title'].strip()}  [COLOR lime](Special)[/COLOR]"
	tagline = info['teaserText'].strip() if info.get('teaserText', '') else None
	if tagline and len(tagline) > 125:
		tagline = f"{tagline[:125]}..."
	if info.get('availability', ''):
		if category == 'DATA_ONE' and str(info['availability'].get('upcomingDate'))[:4] not in ['None', '0', '1970']:
			local_upcom = convert_region(info['availability']['upcomingDate'])
			name = f"[COLOR orange]{local_upcom.strftime('%H:%M')}[/COLOR]  {name}"
		if str(info['availability'].get('start'))[:4] not in ['None', '0', '1970']:
			local_start = convert_region(info['availability']['start'])
			start_times = local_start.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			starting = local_start.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else local_start.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
			airing = local_start.strftime('%d.%m.%Y') # FirstAired
		if str(info['availability'].get('end'))[:4] not in ['None', '0', '1970']:
			local_ends = convert_region(info['availability']['end'])
			ends_times = local_ends.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
	if str(info.get('ageRating')).isdecimal():
		mpaa = translation(30761).format(info['ageRating'])
	genre = info['genre']['label'].strip() if info.get('genre', '') and info['genre'].get('label', '') else None
	if info.get('credits', '') and len(info['credits']) > 2:
		year_sign = next(filter(lambda xv: (xv.get('values', '') and xv.get('code') == 'PRODUCTION_YEAR'), info.get('credits', [])), None)
		yearings = [yea for yea in year_sign.get('values', {})][0] if year_sign else None
		cous_sign = next(filter(lambda xv: (xv.get('values', '') and xv.get('code') == 'COUNTRY'), info.get('credits', [])), None)
		countries = ', '.join(sorted([cou for cou in cous_sign.get('values', {})])) if cous_sign else None
		dirs_sign = next(filter(lambda xv: (xv.get('values', '') and xv.get('code') == 'REA'), info.get('credits', [])), None)
		directors = ', '.join(sorted([dis for dis in dirs_sign.get('values', {})])) if dirs_sign else None
		crea_sign = next(filter(lambda xv: (xv.get('values', '') and xv.get('code') == 'SCE'), info.get('credits', [])), None)
		writers = ', '.join(sorted([cre for cre in crea_sign.get('values', {})])) if crea_sign else None
		star_sign = next(filter(lambda xv: (xv.get('values', '') and xv.get('code') == 'ACT'), info.get('credits', [])), None)
		actoring = ', '.join([sta for sta in star_sign.get('values', {})]) if star_sign else None
	if category =='ZONE_TWO':
		FOLLOW = 'list_broadcasts'
		if info.get('code', '') and str(info['code']).lower().startswith('collection_videos') and info.get('id', '') and info['id'].count('_') == 1:
			gangway = '111'
			ACCESS = config['collections_two'].format(API_EMAC, info['id'].split('_')[0], LOC_LANG, info['id'].split('_')[1])
		elif info.get('code', '') and str(info['code']).lower().startswith('collection_subcollection') and info.get('id', '') and info['id'].count('_') == 2:
			gangway = '222'
			ACCESS = config['collections_three'].format(API_EMAC, info['id'].split('_')[0], LOC_LANG, info['id'].split('_')[1], info['id'].split('_')[2])
		else:
			deeplink = info['link']['deeplink'] if info.get('link', '') and info['link'].get('deeplink', '') else info['deeplink'] if info.get('deeplink', '') else None
			linkpage = info['link']['page'] if info.get('link', '') and info['link'].get('page', '') else info['page'] if info.get('page', '') else None
			if (deeplink or linkpage):
				route_one = deeplink.upper().split('/')[-1] if deeplink and 'emac' in deeplink else \
					linkpage.upper() if linkpage and str(linkpage)[:3] != 'RC-' else None
				route_two = deeplink.split('/')[-1] if deeplink and 'collection' in deeplink else \
					linkpage if linkpage and str(linkpage)[:3] == 'RC-' else None
				if route_one:
					gangway = '333'
					ACCESS = config['edges_two'].format(API_EMAC, route_one)
				elif route_two:
					gangway = '444'
					ACCESS = config['collections_one'].format(API_EMAC, route_two)
			elif objects_code in ['2f19c109-044b-420b-9069-6c2e5daf6a74', '67747aea-5426-4b45-8ef4-f648fd227a69', 'a4245cee-29a8-4ae1-9d6b-df5d1b280002', 'cbde5425-226c-4638-b9f6-6847e509db7f']:
				if objects_code in ['2f19c109-044b-420b-9069-6c2e5daf6a74', 'a4245cee-29a8-4ae1-9d6b-df5d1b280002']:
					gangway = '555' # 1.Musik Genres(a74)+3.Parcourir les genres(002)
					FOLLOW, ACCESS = 'list_categories', 'MUSICS'
				else:
					gangway = '666' # 2.Alle Kategorien(a69)+4.Parcourir toute l'offre(b7f) ???
					FOLLOW, ACCESS = 'list_categories', 'THEMES'
			elif objects_code in ['0f41c5ac-eb59-4a54-8fea-75a1cbfa4c22', 'faab3de5-678c-4a5b-9f56-3c96838beded']:
				gangway = '666' # 1.Geschichte nach Themen(c22)+2.Parcourir toute l'offre Histoire(ded)
				FOLLOW, ACCESS = 'list_thoroughs', 'HISTORY'
			else:
				gangway = '777'
				ACCESS = config['zones_one'].format(API_EMAC, objects_code, LOC_LANG)
		ARGIOS = {'mode': FOLLOW, 'link': ACCESS, 'phase': phrase, 'name': name}
	elif category in ['DATA_ONE', 'DATA_TWO', 'DATA_THREE'] and ((program_code and len(program_code) > 5) or (str(objects_code)[:3] == 'RC-')):
		if 'COLLECTION' in str(info.get('stickers')):
			gangway = 'P-888'
			ACCESS = config['collections_one'].format(API_EMAC, objects_code if str(objects_code)[:3] == 'RC-' else program_code)
			ARGIOS = {'mode': 'list_broadcasts', 'link': ACCESS, 'phase': phrase, 'name': name}
		elif 'FULL_VIDEO' in str(info.get('stickers')) and str(info.get('duration')).isdecimal() and int(info['duration']) > 0:
			gangway = 'P-999'
			ACCESS, FOLDER = program_code, False
			ARGIOS = {'mode': 'playVideo', 'link': ACCESS}
			duration = int(info['duration'])
		else:
			gangway, ACCESS, ARGIOS = 'NULL', 'NO ►COLLECTION◄ OR ►FULL_VIDEO◄ IN STICKERS', None
	else:
		gangway, ACCESS, ARGIOS = 'NULL', 'CATEGORY IS NOTHING, BECAUSE PROGRAMID IS NONE', None
	if info.get('availability', '') and info['availability'].get('type', '') == 'LIVESTREAM_WEB': ACCESS, ARGIOS = 'LIVESTREAM_WEB', None # 1. noch nicht vorh. Videos // 2. z.b. Das Wichtigste in Kürze unter Aktuelles und Gesellschaft
	tvshow = re.sub(r'(\([0-9]+/[0-9]+\)| - Staffel:? [0-9]+| - Saison:? [0-9]+)', '', naming).strip() if duration and naming and (info.get('type', '') == 'teaser' or info.get('standaloneContent', False) is True) else None
	if subtitle and phrase != 'TV_GUIDE' and re.search(r'(Staffel:? [0-9]+|Saison:? [0-9]+)', name) and FOLDER is False:
		name = f"Staffel{name.split('Staffel')[1]} - {subtitle}" if GERM and 'Staffel' in name else f"Saison{name.split('Saison')[1]} - {subtitle}"
	elif subtitle and phrase != 'TV_GUIDE' and tvshow and tvshow.title() in name.title() and FOLDER is False:
		name = f"{subtitle.replace('(', '[').replace(')', ']')}{name.title().replace(tvshow.title(), '')}"
	elif subtitle and phrase == 'TV_GUIDE' and tvshow and FOLDER is False:
		name = f"{name.split('[/COLOR]  ')[0]}[/COLOR]  {subtitle.replace('(', '[').replace(')', ']')}{name.split('[/COLOR]  ')[1].title().replace(tvshow.title(), '')}"
	elif subtitle and (phrase == 'TV_GUIDE' or not re.search(r'(Staffel:? [0-9]+|Saison:? [0-9]+)', name)) and (tvshow is None or tvshow.title() not in subtitle.title()) and FOLDER is False:
		name = f"{name} - {subtitle}"
	elif subtitle and FOLDER is True: tagline = subtitle
	descript = get_plotting(info)
	if tagline and (tagline.replace('.', '') == tvshow or tagline[:-7] in descript): tagline = None
	if tvshow and phrase != 'TV_GUIDE' and tvshow.title() != name.title(): note_1 = translation(30762).format(tvshow)
	if tvshow and phrase == 'TV_GUIDE' and tvshow.title() != name.split('[/COLOR]  ')[1].title(): note_1 = translation(30762).format(tvshow)
	if season and episode:
		note_2 = translation(30763).format(season, episode) if GERM else translation(30764).format(season, episode)
	elif season is None and episode: 
		note_2 = translation(30765).format(episode) if GERM else translation(30766).format(episode)
	if start_times and ends_times:
		note_3 = translation(30767).format(start_times, ends_times) if GERM else translation(30768).format(start_times, ends_times)
	elif start_times and ends_times is None:
		note_3 = translation(30769).format(start_times) if GERM else translation(30770).format(start_times)
	elif tvshow and start_times is None and ends_times is None: note_3 = '[CR]'
	plot_short = note_2+note_3+descript
	plot_longs = note_1+plot_short
	if mpaa and FOLDER is True: mpaa = None # Hide MPAA on Folders
	if info.get('mainImage', '') and info['mainImage'].get('url', ''):
		resources, STOCK = info['mainImage']['url'], True
	if STOCK is False and info.get('content', '') and info['content'].get('data', '') and len(info['content']['data']) > 0 and \
		info['content']['data'][0].get('mainImage', '') and info['content']['data'][0]['mainImage'].get('url', ''):
		resources, STOCK = info['content']['data'][0]['mainImage']['url'], True
	if STOCK: # Square=940x940 or Square=720x720 / Portrait=500x750 / Banner=1024x256 or Banner=768x192 / Landscape=1920x1080
		thumb = resources.split('?type=TEXT')[0].replace('__SIZE__', '1280x720')+'?type=TEXT'
		poster = resources.split('?type=TEXT')[0].replace('__SIZE__', '500x750')+'?type=TEXT'
		fanart = resources.split('?type=TEXT')[0].replace('__SIZE__', '1920x1080')+'?type=TEXT'
	fetch_items = {'Title': name, 'TvShowTitle': tvshow if note_1 != "" else None, 'Tagline': tagline, 'Desc_Small': plot_short, 'Plot': plot_longs, 'Duration': duration, 'Season': season, \
		'Episode': episode, 'Date': starting, 'Aired': airing, 'Year': yearings, 'Genre': genre, 'Country': countries, 'Director': directors, 'Writer': writers, 'Cast': actoring, 'Mpaa': mpaa, \
		'Mediatype': 'episode' if not FOLDER else None, 'Image': thumb, 'Poster': poster, 'Fanback': fanart, 'Reference': 'Single' if not FOLDER else None, 'Marker': marker}
	if capture:
		debug_MS(f"{capture} ### TITLE : {name} || CATEGORY : {category} || PHRASE : {phrase} || CALLno : {gangway} ###")
		debug_MS(f"{capture} ### URL : {ACCESS} || CONNECT_ID : {objects_code} || CODE : {info.get('code', None)} || PROGRAM_ID : {program_code} ###")
		debug_MS(f"{capture} ### is FOLDER : {FOLDER} || DURATION : {duration} || THUMB : {thumb} ###")
		debug_MS("-----------------------------------------------")
	return [ARGIOS, fetch_items, FOLDER]

def playVideo(target):
	debug_MS("(navigator.playVideo) --------------------------------------------- START = playVideo ---------------------------------------------")
	"""
	Übergabe des Abspiellinks von anderem Video-ADDON: plugin://plugin.video.artetv.de/?mode=playVideo&link=048256-000-A oder: plugin://plugin.video.artetv.de/?mode=playVideo&link=https://www.arte.tv/de/videos/048256-000-A/wir-waren-koenige/
	NEWEST_MP4: https://www.arte.tv/hbbtv-mw/api/1/player/101328-000-A?lang=de // FOUND at 07.11.2026
	DEUTSCH::: "VOA" = Original deutsch | "VOA-STMA" = Original mit deutschen Untertiteln | "VAAUD" = Deutsch mit Audiodescription | "OV" = Stumm oder Originalversion | "VOA-STF" = Deutsch/UT-Französisch
	FRANCE::: "VOF" = Original französisch | "VF-STF" = französisch vertont | "VFAUD" = Französisch mit Audiodescription | "VOF-STMF" = Stumm oder Original mit französischen Untertiteln
	"""
	data_uno, (masters, medias), (purpose_uno, purpose_due, final_link, test_link, status, message) = {}, ([] for _ in range(2)), (False for _ in range(6))
	video_code = re.compile(r'/videos/([^/]+)/', re.S).findall(target)[0] if target[:4] == 'http' else target
	debug_MS(f"(navigator.playVideo[1]) ### Original_URL = {target} || Video_Code = {video_code} ###")
	arte_qualities = [2160, 1080, 720, 406, 360, 216] # Height of the Stream
	shortcuts = ['DE', 'UT', 'AD'] if GERM else ['FR', 'UT', 'AD']
	try:
		data_uno = track_content(config['player_mpp4'].format(video_code, LOC_LANG.lower()), 'GET', 'JSON', AGES_HEADER, False) # For mp4- Streams // Currently function without Token 07.11.2026
		if len(data_uno['item']['streams']) >= 1: purpose_uno = True
	except: pass
	if purpose_uno:
		for each in data_uno['item']['streams']:
			stream_one = each.get('url', 'unk')
			name_one    = each['versions'][0]['label'] if each.get('versions', '') and each.get('versions', {})[0].get('label', '') else 'NOT FOUND'
			lang_one      = each['versions'][0]['shortLabel'] if each.get('versions', '') and each.get('versions', {})[0].get('shortLabel', '') else 'NOT FOUND'
			height_one  = each['mainQuality']['label'] if each.get('mainQuality', '') and each['mainQuality'].get('label', '') else 'NOT FOUND'
			quality_one  = height_one.replace('p', '') if height_one != 'NOT FOUND' and not isinstance(height_one, int) else height_one if height_one != 'NOT FOUND' and isinstance(height_one, int) else 0
			version_one  = each['slot'] if str(each.get('slot')).isdecimal() else 0
			mime_one    = 'video/mp4'
			if version_one == 1 and '.mp4' in stream_one and int(quality_one) > 358:
				medias.append({'link': stream_one, 'quality': quality_one, 'mimeType': mime_one, 'name': name_one, 'language': lang_one})
		medias.sort(key=lambda v1: int(v1.get('quality', 0)), reverse=True)
		debug_MS(f"(navigator.playVideo[2]) SORTED_LIST | MPP4 ### sorted_LIST : {medias} ###")
	elif data_uno.get('item', {}) and data_uno['item'].get('error', {}) and data_uno['item']['error'].get('message', ''):
		status, message = data_uno['item']['error'].get('title', 'Der STREAM wurde von ARTE geblockt ...'), data_uno['item']['error'].get('message', 'Momentan nicht verfügbar !')
	try:
		data_due = track_content(config['player_m3u8'].format(LOC_LANG.lower(), video_code), 'GET', 'JSON', AGES_HEADER, False) # For HLS- and m3u8- Streams // Currently function with or without Token 11.02.2026
		if len(data_due['data']['attributes']['streams']) >= 1: purpose_due = True
	except: pass
	if purpose_due:
		for elem in data_due['data']['attributes']['streams']:
			stream_two = elem.get('url', 'unk')
			name_two    = elem['versions'][0]['label'] if elem.get('versions', '') and elem.get('versions', {})[0].get('label', '') else 'NOT FOUND'
			lang_two      = elem['versions'][0]['shortLabel'] if elem.get('versions', '') and elem.get('versions', {})[0].get('shortLabel', '') else 'NOT FOUND'
			height_two  = elem['mainQuality']['label'] if elem.get('mainQuality', '') and elem['mainQuality'].get('label', '') else 'NOT FOUND'
			quality_two  = height_two.replace('p', '') if height_two != 'NOT FOUND' and not isinstance(height_two, int) else height_two if height_two != 'NOT FOUND' and isinstance(height_two, int) else 0
			version_two  = elem['slot'] if str(elem.get('slot')).isdecimal() else 0
			mime_two     = 'application/vnd.apple.mpegurl'
			if version_two == 1 and '.m3u8' in stream_two and int(quality_two) > 404:
				masters.append({'link': stream_two, 'quality': quality_two, 'mimeType': mime_two, 'name': name_two, 'language': lang_two})
		masters.sort(key=lambda v2: int(v2.get('quality', 0)), reverse=True)
		debug_MS(f"(navigator.playVideo[3]) SORTED_LIST | M3U8 ### sorted_LIST : {masters} ###")
		debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
	if ((prefer_stream == 1 and not enable_adaptive) or (not masters)) and medias:
		debug_MS("(navigator.playVideo[4]) ~~~~~ TRY NUMBER ONE TO GET THE FINALURL (mp4) ~~~~~")
		stream, mimes, quality, final_link = 'MP4', medias[0]['mimeType'], medias[0]['quality'], medias[0]['link']
	if not final_link and masters:
		debug_MS("(navigator.playVideo[4]) ~~~~~ TRY NUMBER TWO TO GET THE FINALURL (m3u8/hls) ~~~~~")
		stream = 'HLS' if enable_adaptive else 'M3U8'
		mimes, quality, final_link = masters[0]['mimeType'], masters[0]['quality'], masters[0]['link']
	try: # Test function to see if stream can be played !!!
		signo = urlopen(final_link, timeout=6).getcode()
		if signo in [200, 201, 202]: test_link = True
	except: pass
	if final_link and test_link:
		LSM = xbmcgui.ListItem(path=final_link, offscreen=True)
		LSM.setMimeType(mimes)
		if plugin_operate('inputstream.adaptive') and stream in ['HLS', 'MPD']:
			IA_NAME = 'inputstream.adaptive'
			LSM.setContentLookup(False); LSM.setProperty('inputstream', IA_NAME)
			if KODI_BUILD in [19, 20]: LSM.setProperty(f"{IA_NAME}.manifest_type", stream.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			if KODI_BUILD in [19, 20, 21]:
				LSM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={WEB_AGENT}")
				LSM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={WEB_AGENT}")
			else: LSM.setProperty(f"{IA_NAME}.common_headers", f"User-Agent={WEB_AGENT}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.playVideo) [{quality}p] {stream}_stream : {final_link}")
	elif final_link and not test_link:
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		failing(f"(navigator.playVideo) $$$$$ Playback of the stream is NOT possible; the Stream-URL on the *arte.tv* website is BROKEN or OFFLINE !!! $$$$$\n $$$$$ IDD : {video_code} || FINAL_URL : {final_link} $$$$$")
		return dialog.notification(translation(30521).format('VIDEO'), translation(30527), icon, 10000)
	else:
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		if status and message:
			failing(f"(navigator.play_video[1]) ERROR - PLAYER - ERROR ##### FAILURE : {status} ===\n === {message} #####")
			return dialog.ok(addon_id, translation(30503).format(status, message))
		else:
			failing(f"(navigator.playVideo) $$$$$ Playback of the stream is NOT possible $$$$$ IDD : {video_code} $$$$$\n ########## NO Stream-Entry found on *arte.tv* !!! ##########")
			return dialog.notification(translation(30521).format('VIDEO'), translation(30528), icon, 8000)

def list_livestreams():
	debug_MS("(navigator.list_livestreams) --------------------------------------------- START = list_livestreams ---------------------------------------------")
	for item in config['streams']:
		if GERM and 'France' in item.get('description'): continue
		elif not GERM and 'Germany' in item.get('description'): continue
		title = item['title_de'] if GERM else item['title_fr']
		fetch_items = create_entries({'Title': title, 'Image': f"{evepic}{item.get('thumb')}"})
		add_views({'mode': 'play_lives', 'link': item['link'], 'name': title, 'extra': f"{evepic}{item.get('thumb')}"}, fetch_items, False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_lives(target, name, extra):
	LTM = xbmcgui.ListItem(name, path=target, offscreen=True)
	LTM.setMimeType('application/vnd.apple.mpegurl')
	LTM.setArt({'icon': icon, 'thumb': extra, 'poster': extra})
	if plugin_operate('inputstream.adaptive'):
		LTM.setProperty('inputstream', 'inputstream.adaptive')
		if KODI_BUILD in [19, 20]: LTM.setProperty('inputstream.adaptive.manifest_type', 'hls') # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
	xbmc.Player().play(item=target, listitem=LTM)

def add_views(params, listitem, folder=True, higher=False, sample='standard'):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if params.get('mode') == 'playVideo' and params.get('link'):
		entries.append([translation(32231) if GERM else translation(32232), f"RunPlugin({build_mass({'mode': 'calling_infos', 'link': params.get('link'), 'phase': sample})})"])
	if enable_decrease and higher is True:
		entries.append([translation(32233) if GERM else translation(32234), f"RunPlugin({build_mass({'mode': 'calling_main'})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
