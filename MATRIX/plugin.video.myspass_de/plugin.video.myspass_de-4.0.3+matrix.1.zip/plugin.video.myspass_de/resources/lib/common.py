﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
import io
import gzip
import ssl
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import quote_plus, unquote_plus, urlencode  # Python 2.X
	from urllib2 import build_opener  # Python 2.X
else: 
	from urllib.parse import quote_plus, unquote_plus, urlencode  # Python 2.X
	from urllib.request import build_opener  # Python 3+

try: _create_unverified_https_context = ssl._create_unverified_context
except AttributeError: pass
else: ssl._create_default_https_context = _create_unverified_https_context


global debuging
HOST_AND_PATH        = sys.argv[0]
ADDON_HANDLE          = int(sys.argv[1])
dialog                              = xbmcgui.Dialog()
addon                              = xbmcaddon.Addon()
addon_id                         = addon.getAddonInfo('id')
addon_name                  = addon.getAddonInfo('name')
addon_version               = addon.getAddonInfo('version')
addonPath                      = xbmc.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                         = xbmc.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
WORKFILE                      = os.path.join(dataPath, 'episode_data.txt')
defaultFanart                 = os.path.join(addonPath, 'resources', 'fanart.jpg')
icon                                  = os.path.join(addonPath, 'resources', 'icon.png')
BASE_API                        = 'http://m.myspass.de/api/index.php?'
BASE_URL                       = 'https://www.myspass.de/'

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py2_enc(s, encoding='utf-8'):
	if PY2:
		if not isinstance(s, basestring):
			s = str(s)
		s = s.encode(encoding) if isinstance(s, unicode) else s
	return s

def py2_uni(s, encoding='utf-8'):
	if PY2 and isinstance(s, str):
		s = unicode(s, encoding)
	return s

def py3_dec(d, encoding='utf-8'):
	if not PY2 and isinstance(d, bytes):
		d = d.decode(encoding)
	return d

def translation(id):
	return py2_enc(addon.getLocalizedString(id))

def failing(content):
	log(content, xbmc.LOGERROR)

def debug(content):
	log(content, xbmc.LOGDEBUG)

def log(msg, level=xbmc.LOGNOTICE):
	msg = py2_enc(msg)
	return xbmc.log('[{0} v.{1}]{2}'.format(addon_id, addon_version, msg), level)

def build_url(query):
	return '{0}?{1}'.format(HOST_AND_PATH, urlencode(query))

def getUrl(url, header=None, data=None, agent='Dalvik/2.1.0 (Linux; U; Android 7.1.2;)'):
	opener = build_opener()
	opener.addheaders = [('User-Agent', agent), ('Accept-Encoding', 'gzip, identity')]
	try:
		if header: opener.addheaders = header
		response = opener.open(url, data=data, timeout=30)
		if response.info().get('Content-Encoding') == 'gzip':
			content = py3_dec(gzip.GzipFile(fileobj=io.BytesIO(response.read())).read())
		else:
			content = py3_dec(response.read())
	except Exception as e:
		failure = str(e)
		failing("(getUrl) ERROR - ERROR - ERROR : ########## {0} === {1} ##########".format(url, failure))
		dialog.notification('MySpass : [COLOR red]!!! URL - ERROR !!![/COLOR]', "ERROR = [COLOR red]{0}[/COLOR]".format(failure), icon, 15000)
		return sys.exit(0)
	return py2_enc(content)

def cleaning(text):
	text = py2_enc(text)
	for n in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&apos;', "'"), ("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''),
				('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''), ('\xc2\xb7', '-'),
				('&quot;', '"'), ('&szlig;', 'ß'), ('&ndash;', '-'), ('&Auml;', 'Ä'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&ouml;', 'ö'), ('&uuml;', 'ü'),
				('&agrave;', 'à'), ('&aacute;', 'á'), ('&acirc;', 'â'), ('&egrave;', 'è'), ('&eacute;', 'é'), ('&ecirc;', 'ê'), ('&igrave;', 'ì'), ('&iacute;', 'í'), ('&icirc;', 'î'),
				('&ograve;', 'ò'), ('&oacute;', 'ó'), ('&ocirc;', 'ô'), ('&ugrave;', 'ù'), ('&uacute;', 'ú'), ('&ucirc;', 'û')):
				text = text.replace(*n)
	return text.strip()

def cleanVideo(code):
	for v in (('\/', '/'), ('http://c11021-osu.p.core.cdn.streamfarm.net/', 'https://cldf-od.r53.cdn.tv1.eu/')):
		code = code.replace(*v)
	return code.strip()

def parameters_string_to_dict(parameters):
	paramDict = {}
	if parameters:
		paramPairs = parameters[1:].split('&')
		for paramsPair in paramPairs:
			paramSplits = paramsPair.split('=')
			if (len(paramSplits)) == 2:
				paramDict[paramSplits[0]] = paramSplits[1]
	return paramDict

params = parameters_string_to_dict(sys.argv[2])
url = unquote_plus(params.get('url', ''))
mode = unquote_plus(params.get('mode', 'root'))
IDENTiTY = unquote_plus(params.get('IDENTiTY', ''))
