﻿# -*- coding: utf-8 -*-

from .common import *
config = traversing.get_config()


def mainMenu():
	NUMBER, SEND = 0, {}
	addDir({'mode': 'listFavorites'}, create_entries({'Title': translation(30601), 'Image': f"{artpic}favourites.png"}))
	SEND['playlists'], MERGING = [], [getUrl(config['PAGE_VIEW'].format(API_VANILLA, 'homepage&'), AUTH=VANILLA_TOKEN)]
	MERGING += [getUrl(config['PAGE_VIEW'].format(API_VANILLA, 'detail%20page&'), AUTH=VANILLA_TOKEN)]
	for item in MERGING:
		for each in item.get('data', []):
			debug_MS(f"(navigator.mainMenu[1]) xxxxx THEME-01 : {each} xxxxx")
			THEME_IDD = each['id']
			TITLE = cleaning(each['attributes']['title']).replace('Hero', translation(30602))
			FORMAT = [check.get('video', '') for check in each['attributes']['items'] if each.get('attributes', {}) and \
				each['attributes'].get('items', {}) and check.get('video') and len(check['video']) > 0]
			INSTANCE = 'listEpisodes' if each.get('attributes', {}) and each['attributes'].get('items', {}) and \
				FORMAT and len(FORMAT) == len(each['attributes']['items']) else 'listShows'
			NAME, NUMBER = None if INSTANCE == 'listEpisodes' else TITLE, NUMBER.__add__(1)
			if each['attributes'].get('page', '').upper() == 'HOMEPAGE':
				addDir({'mode': INSTANCE, 'url': 'ENTRIES_HOME', 'name': NAME, 'code': THEME_IDD, 'number': NUMBER}, create_entries({'Title': f"[B]{TITLE}[/B]"}))
			elif each['attributes'].get('page', '').upper() == 'DETAIL PAGE':
				TITLE = cleaning(each['attributes']['title']).replace('Alle Sendungen', translation(30603))
				addDir({'mode': INSTANCE, 'url': 'ENTRIES_HOME', 'name': NAME, 'code': THEME_IDD, 'number': NUMBER}, create_entries({'Title': f"[B]{TITLE}[/B]"}))
			debug_MS(f"(navigator.mainMenu[2]) ### ACTION : {INSTANCE} || NAME : {TITLE} || THEME_IDD : {THEME_IDD} || LIST_IDD : {NUMBER} ###")
			debug_MS("++++++++++++++++++++++++")
			SEND['playlists'].append(each)
	preserve(RECORD_FILE, SEND)
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30609), 'Image': f"{artpic}settings.png"}), folder=False)
		if enableINPUTSTREAM and plugin_operate('inputstream.adaptive'):
			addDir({'mode': 'iConfigs'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"}), folder=False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listShows(TARGET, NAME, CAT_IDD):
	debug_MS("(navigator.listShows) -------------------------------------------------- START = listShows --------------------------------------------------")
	debug_MS(f"(navigator.listShows) ### TARGET = {TARGET} ### NAME = {NAME} ### CAT_IDD = {CAT_IDD} ###")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	DATA_ONE, FOUND, UNIKAT = {}, 0, set()
	if TARGET.startswith('ENTRIES_HOME') and xbmcvfs.exists(RECORD_FILE) and os.stat(RECORD_FILE).st_size > 0:
		DATA_ONE = preserve(RECORD_FILE)
	for item in DATA_ONE.get('playlists', []):
		if int(item.get('id', 0)) == int(CAT_IDD):
			for each in item['attributes'].get('items', []):
				debug_MS(f"(navigator.listShows[1]) xxxxx EACH-01 : {each} xxxxx")
				SHORT = each['format']['data']
				SHOW_IDD = SHORT['id']
				if SHOW_IDD in ['', 0, None] or SHOW_IDD in UNIKAT:
					debug_MS("~~~~~~~~~~~~~~~~~~~~~~~~ THIS SHOW IS DOUBLE - REMOVED ~~~~~~~~~~~~~~~~~~~~~~~~")
					continue
				UNIKAT.add(SHOW_IDD)
				FOUND += 1
				TITLE = cleaning(SHORT['attributes']['name'])
				PLOT = get_Description(SHORT.get('attributes', {}))
				THUMB = SHORT['attributes']['keyvisual_16_9']['data']['attributes']['url'] if SHORT['attributes'].get('keyvisual_16_9', {}) and \
					SHORT['attributes']['keyvisual_16_9'].get('data', {}) and SHORT['attributes']['keyvisual_16_9']['data'].get('attributes', {}) and \
					SHORT['attributes']['keyvisual_16_9']['data']['attributes'].get('url', '') else None
				POSTER = SHORT['attributes']['keyvisual_5_8']['data']['attributes']['url'] if SHORT['attributes'].get('keyvisual_5_8', {}) and \
					SHORT['attributes']['keyvisual_5_8'].get('data', {}) and SHORT['attributes']['keyvisual_5_8']['data'].get('attributes', {}) and \
					SHORT['attributes']['keyvisual_5_8']['data']['attributes'].get('url', '') else None
				debug_MS(f"(navigator.listShows[2]) ### NAME : {TITLE} || SHOW_IDD : {SHOW_IDD} || THUMB : {THUMB} ###")
				debug_MS("++++++++++++++++++++++++")
				operation = 'adding'
				if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
					for article in preserve(FAVORIT_FILE).get('items', []):
						if article.get('url') == str(SHOW_IDD): operation = 'skipping'
				FETCH_UNO = create_entries({'Title': TITLE, 'Plot': PLOT, 'Image': THUMB, 'Poster': POSTER})
				addDir({'mode': 'listSeasons', 'url': SHOW_IDD, 'name': TITLE, 'picture': THUMB, 'portrait': POSTER, 'plot': PLOT}, FETCH_UNO, handling=operation)
	if FOUND == 0:
		failing(f"(navigator.listShows) ##### NO Entries for: {NAME} FOUND #####")
		return dialog.notification(translation(30524), translation(30525).format(NAME), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(TARGET, SERIE, IMG):
	debug_MS(f"(navigator.listSeasons) ### URL = {TARGET} ### SERIE = {SERIE} ### THUMB = {IMG} ###")
	COMBI_SEASON, FOUND, UNIKAT = [], 0, set()
	DATA_ONE = getUrl(config['SEAS_VIEW'].format(API_VANILLA, TARGET), AUTH=VANILLA_TOKEN)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listSeasons[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if DATA_ONE is not None and DATA_ONE.get('data', {}) and DATA_ONE['data'].get('attributes', {}) and \
		DATA_ONE['data']['attributes'].get('seasons', {}) and DATA_ONE['data']['attributes']['seasons'].get('data', ''):
		for item in DATA_ONE['data']['attributes']['seasons'].get('data', []):
			FORM_IDD = DATA_ONE['data']['id']
			SEAS_IDD = item['id']
			if SEAS_IDD in ['', 0, None] or SEAS_IDD in UNIKAT:
				continue
			UNIKAT.add(SEAS_IDD)
			FOUND += 1
			TITLE = cleaning(item['attributes']['name'])
			PLOT = get_Description(item.get('attributes', {}))
			debug_MS(f"(navigator.listSeasons[2]) ### NAME : {TITLE} || FORM_IDD : {FORM_IDD} || SEAS_IDD : {SEAS_IDD} || THUMB : {IMG} ###")
			COMBI_SEASON.append([TITLE, IMG, PLOT, SERIE, FORM_IDD, SEAS_IDD])
	if COMBI_SEASON and FOUND == 1:
		debug_MS("(navigator.listSeasons[3]) ----- Only one Season FOUND - goto = listEpisodes -----")
		for TITLE, IMG, PLOT, SERIE, FORM_IDD, SEAS_IDD in COMBI_SEASON:
			return listEpisodes(FORM_IDD, SERIE, SEAS_IDD, 1, 1)
	elif COMBI_SEASON and FOUND > 1:
		for TITLE, IMG, PLOT, SERIE, FORM_IDD, SEAS_IDD in sorted(COMBI_SEASON, key=lambda ex: ex[0]):
			FETCH_UNO = create_entries({'Title': TITLE, 'Plot': PLOT, 'Image': IMG})
			addDir({'mode': 'listEpisodes', 'url': FORM_IDD, 'name': SERIE, 'code': SEAS_IDD}, FETCH_UNO)
	else:
		failing(f"(navigator.listSeasons) ##### NO Entries for: {SERIE} FOUND #####")
		return dialog.notification(translation(30524), translation(30525).format(SERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(TARGET, SERIE, SEAS_CODE, LIST_CODE, PAGE):
	debug_MS("(navigator.listEpisodes) -------------------------------------------------- START = listEpisodes --------------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL = {TARGET} ### SERIE = {SERIE} ### SEAS_CODE = {SEAS_CODE} ### LIST_CODE = {LIST_CODE} ### PAGE = {PAGE} ###")
	DATA_ONE, FOUND, UNIKAT = {}, 0, set()
	if TARGET != 'ENTRIES_HOME' and str(TARGET).isdecimal():
		DATA_ONE = getUrl(config['EPIS_VIEW'].format(API_VANILLA, TARGET, SEAS_CODE, PAGE), AUTH=VANILLA_TOKEN)
	elif TARGET == 'ENTRIES_HOME' and xbmcvfs.exists(RECORD_FILE) and os.stat(RECORD_FILE).st_size > 0:
		DATA_ONE = preserve(RECORD_FILE)
	ARTICLES = DATA_ONE.get('data', []) if TARGET != 'ENTRIES_HOME' and str(TARGET).isdecimal() else DATA_ONE['playlists'][int(LIST_CODE)-1]['attributes'].get('items', [])
	for item in ARTICLES:
		for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
		(NOTE_1, NOTE_2), (BC_DATE, BC_TIME, STARTS, BEGINS, AIRED) = ("" for _ in range(2)), (None for _ in range(5))
		SHORT = item['video']['data'] if item.get('video', '') else item
		debug_MS(f"(navigator.listEpisodes[1]) xxxxx SHORT-01 : {SHORT} xxxxx")
		EPIS_IDD = SHORT['id']
		TITLE = cleaning(SHORT['attributes']['title'])
		origSERIE = SERIE if SERIE not in ['', 'None', None] else SHORT['attributes']['format']['data']['attributes']['name'] if \
			SHORT['attributes'].get('format', {}) and SHORT['attributes']['format'].get('data', {}) and \
			SHORT['attributes']['format']['data'].get('attributes', {}) and SHORT['attributes']['format']['data']['attributes'].get('name', '') else ""
		if origSERIE != "": NOTE_1 = translation(30620).format(origSERIE)
		SEAS = SHORT['attributes']['season']['data']['attributes']['name'].replace('Staffel ', '') if SHORT['attributes'].get('season', {}) and \
			SHORT['attributes']['season'].get('data', {}) and SHORT['attributes']['season']['data'].get('attributes', {}) and \
			SHORT['attributes']['season']['data']['attributes'].get('name', '') else None
		EPIS = SHORT['attributes']['episode']['data']['attributes']['number'] if SHORT['attributes'].get('episode', {}) and \
			SHORT['attributes']['episode'].get('data', {}) and SHORT['attributes']['episode']['data'].get('attributes', {}) and \
			SHORT['attributes']['episode']['data']['attributes'].get('number', '') else None
		DESC = cleaning(SHORT['attributes'].get('teaser_text', ''))
		RUNS = SHORT['attributes'].get('play_length', None)
		BC_DATE = SHORT['attributes'].get('broadcast_date', None)
		BC_TIME = SHORT['attributes'].get('broadcast_time', None)
		if BC_DATE and not str(BC_DATE).startswith(('0000', '1970')) and BC_TIME:
			CIPHER = datetime(*(time.strptime(f"{BC_DATE[:10]}T{BC_TIME[:8]}", '%Y-%m-%dT%H:%M:%S')[0:6])) # 2019-06-13T22:15:00
			STARTS = CIPHER.strftime('%a. %d.%m.%Y')
			for sd in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), \
				('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))): STARTS = STARTS.replace(*sd)
			BEGINS = CIPHER.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else CIPHER.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
			AIRED = CIPHER.strftime('%d.%m.%Y') # FirstAired
		if str(SEAS).isdecimal() and str(EPIS).isdecimal() and str(EPIS) != '0':
			NAME = translation(30621).format(f"{int(SEAS):02}", f"{int(EPIS):02}", TITLE)
			if STARTS: NOTE_2 = translation(30622).format(f"{int(SEAS):02}", f"{int(EPIS):02}", STARTS)
			else: NOTE_2 = translation(30623).format(f"{int(SEAS):02}", f"{int(EPIS):02}")
		elif str(SEAS).isdecimal() and (not str(EPIS).isdecimal() or str(EPIS) == '0'):
			NAME = translation(30624).format(f"{int(SEAS):02}", TITLE)
			if STARTS: NOTE_2 = translation(30625).format(f"{int(SEAS):02}", STARTS)
			else: NOTE_2 = translation(30626).format(f"{int(SEAS):02}")
		else:
			if STARTS: NAME ,NOTE_2 = TITLE, translation(30627).format(STARTS)
			else: NAME ,NOTE_2 = TITLE, '[CR]'
		THUMB = config['IMAGE_URL'].format(re.sub(r'/[0-9]+.jpg', '', SHORT['attributes'].get('thumbnail_url', '')), SHORT['attributes'].get('thumbnail_url', '').split('/')[-1])
		VIDEO = SHORT['attributes'].get('video_url', None)
		if EPIS_IDD in ['', 0, None] or EPIS_IDD in UNIKAT or VIDEO is None:
			continue
		UNIKAT.add(EPIS_IDD)
		FOUND += 1
		debug_MS(f"(navigator.listEpisodes[2]) ##### NAME : {NAME} || EPIS_IDD : {EPIS_IDD} #####")
		debug_MS(f"(navigator.listEpisodes[2]) ##### SERIE : {SERIE} || BEGINS : {BEGINS} || DURATION : {RUNS} #####")
		debug_MS(f"(navigator.listEpisodes[2]) ##### THUMB : {THUMB} || SEASON : {SEAS} || EPISODE : {EPIS} #####")
		debug_MS("++++++++++++++++++++++++")
		FETCH_UNO = create_entries({'Title': NAME, 'TvShowTitle': origSERIE, 'Plot': NOTE_1+NOTE_2+DESC, 'Season': SEAS,'Episode': EPIS, \
			'Duration': RUNS, 'Date': BEGINS, 'Aired': AIRED, 'Mediatype': 'episode', 'Image': THUMB, 'Reference': 'Single'})
		addDir({'mode': 'playVideo', 'url': VIDEO}, FETCH_UNO, folder=False)
	NUMBERS = DATA_ONE['meta']['pagination']['total'] if DATA_ONE.get('meta', {}) and DATA_ONE['meta'].get('pagination', {}) and \
		DATA_ONE['meta']['pagination'].get('total', '') and str(DATA_ONE['meta']['pagination']['total']).isdecimal() else None
	if FOUND > 0 and NUMBERS and int(NUMBERS) > int(PAGE)*40:
		debug_MS(f"(navigator.listEpisodes[3]) PAGES ### NOW SHOW NEXTPAGE ENTRY ... No.{int(PAGE)+1} || URL : {config['EPIS_VIEW'].format(API_VANILLA, TARGET, SEAS_CODE, str(int(PAGE)+1))} ... ###")
		FETCH_DUE = create_entries({'Title': translation(30628).format(int(PAGE)+1), 'Image': f"{artpic}nextpage.png"})
		addDir({'mode': 'listEpisodes', 'url': TARGET, 'name': SERIE, 'code': SEAS_CODE, 'number': LIST_CODE, 'page': int(PAGE)+1}, FETCH_DUE)
	elif FOUND == 0:
		failing(f"(navigator.listEpisodes) ##### NO Entries for: {SERIE} FOUND #####")
		return dialog.notification(translation(30524), translation(30525).format(SERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(ORIGIN):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### SOURCE = {ORIGIN} ###")
	ORIGIN = re.sub(r'/[0-9]+_720-HLS_.m3u8', '/master.m3u8', ORIGIN.replace('/720-HLS', '')) if '/720-HLS' in ORIGIN else ORIGIN
	STREAM, FINAL_URL = 'M3U8', config['PLAYER_M3U8'].format(ORIGIN) if ORIGIN else False
	if FINAL_URL:
		LPM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		if enableINPUTSTREAM and plugin_operate('inputstream.adaptive') and 'm3u8' in FINAL_URL:
			IA_NAME, STREAM = 'inputstream.adaptive', 'HLS'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			LPM.setMimeType('application/vnd.apple.mpegurl'), LPM.setContentLookup(False), LPM.setProperty('inputstream', f"{IA_NAME}.")
			if KODI_un21:
				LPM.setProperty(f"{IA_NAME}.manifest_type", STREAM.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			if KODI_ov20:
				LPM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={get_userAgent()}") # On KODI v20 and above
			else: LPM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={get_userAgent()}") # On KODI v19 and below
			if int(IA_VERSION) >= 2150 and STREAM == 'HLS':
				LPM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey')
		log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}|User-Agent={get_userAgent()}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
	else:
		failing("(navigator.playVideo) AbspielLink-00 : *MYSPASS* Der angeforderte -VideoLink- wurde NICHT gefunden !!!")
		return dialog.notification(translation(30521).format('VIDEO'), translation(30526), icon, 10000)

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		for each in preserve(FAVORIT_FILE).get('items', []):
			LINK, THUMB, POSTER, TITLE, PLOT = each.get('url'), each.get('picture'), each.get('portrait', ''), cleaning(each.get('name')), cleaning(each.get('plot', ''))
			FETCH_UNO = create_entries({'Title': TITLE, 'Plot': PLOT, 'Image': THUMB, 'Poster': POSTER})
			addDir({'mode': 'listSeasons', 'url': LINK, 'name': TITLE, 'picture': THUMB, 'portrait': POSTER, 'plot': PLOT}, FETCH_UNO, handling='removing')
			debug_MS(f"(navigator.listFavorites[1]) ### NAME : {TITLE} || SHOW_IDD : {LINK} || IMAGE : {THUMB} ###")
		debug_MS("++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favorit_construct(**kwargs):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		del kwargs['mode']; del kwargs['action']
		TOPS['items'].append({key: value if value != 'None' else None for key, value in kwargs.items()})
		preserve(FAVORIT_FILE, TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30527), translation(30528).format(kwargs['name']), icon, 8000)
	elif kwargs['action'] == 'DEL':
		TOPS['items'] = [top for top in TOPS['items'] if top.get('url') != kwargs.get('url')]
		preserve(FAVORIT_FILE, TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30527), translation(30529).format(kwargs['name']), icon, 8000)

def addDir(params, listitem, folder=True, handling='default'):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if handling == 'adding' and params:
		entries.append([translation(30651), f"RunPlugin({build_mass({**params, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and params:
		entries.append([translation(30652), f"RunPlugin({build_mass({**params, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
