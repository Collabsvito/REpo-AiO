﻿# -*- coding: utf-8 -*-


class Client(object):
	CONFIG_MYSPASS = {# Startseite=homepage& // Videoseite=detail%20page&
		'PAGE_VIEW': '{}/carousels?%20%20%20%20%20%20%20%20&sort[0]=order_rank%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][video][populate][format][fields]=name%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][video][populate][format][fields]=short_description%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][video][populate][format][fields]=medium_description%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][video][populate][season][fields]=name%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][video][populate][episode][fields]=number%20%20%20%20%20%20%20%20'
			'&populate[items][populate][format][populate][keyvisual_16_9][fields]=url%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][format][populate][keyvisual_5_8][fields]=url%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][season][populate][format][fields]=name%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][season][populate][format][fields]=short_description%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][season][populate][format][fields]=medium_description%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][season][populate][keyvisual_16_9][fields]=url%20%20%20%20%20%20%20%20'\
			'&populate[items][populate][season][populate][keyvisual_5_8][fields]=url%20%20%20%20%20%20%20%20&filters[page][$eq]={}',
		'SEAS_VIEW': '{}/formats/{}'\
			'?populate[seasons]=seasons&',
		'EPIS_VIEW': '{}/videos?filters[type][$contains]=full_episode&filters[format][id][$eq]={}&filters[season][id][$eq]={}'\
			'&populate[format][fields]=name'\
			'&populate[season][fields]=name'\
			'&populate=episode'\
			'&sort[0]=episode.number:asc&pagination[page]={}&pagination[pageSize]=40',
		'VIDS_VIEW': '{}/videos/{}'\
			'?populate[format][fields]=name'\
			'&populate[season][fields]=name&',
		'PLAYS_VIEW': '{}/next-video/{}?',
		'IMAGE_URL': 'https://1403103913.rsc.cdn77.org{}/1280x720-{}',
		'PLAYER_M3U8': 'https://1020993654.rsc.cdn77.org{}'
		}

	def __init__(self, config):
		self._config = config

	def get_config(self):
		return self._config
