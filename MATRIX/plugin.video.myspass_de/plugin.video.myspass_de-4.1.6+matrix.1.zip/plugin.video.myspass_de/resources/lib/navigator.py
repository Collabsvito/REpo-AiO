﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	for TITLE, PATH in [(30601, {'mode': 'listFavorites'}), (30602, {'mode': 'listEpisodes', 'url': BASE_LONG}), (30603, {'mode': 'listSelections', 'url': 'CHANNELS'}),
		(30604, {'mode': 'listSelections', 'url': 'TV SHOWS'}), (30605, {'mode': 'listSelections', 'url': 'WEB SHOWS'}), (30606, {'mode': 'listSelections', 'url': 'STAND UP'}),
		(30607, {'mode': 'listSelections', 'url': 'SERIEN'}), (30608, {'mode': 'listAlphabet'}), (30609, {'mode': 'listShows', 'url': 'standard'})]:
		FETCH_UNO = create_entries({'Title': translation(TITLE), 'Image': f"{artpic}favourites.png" if TITLE == 30601 else icon})
		addDir('', '', PATH, FETCH_UNO)
	if enableADJUSTMENT:
		FETCH_DUE = create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"})
		addDir('', '', {'mode': 'aConfigs'}, FETCH_DUE, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listAlphabet():
	debug_MS("(navigator.listAlphabet) ------------------------------------------------ START = listAlphabet -----------------------------------------------")
	for letter in ['0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'W', 'Z', '??']:
		FETCH_UNO = create_entries({'Title': letter, 'Image': f"{alppic}{letter.replace('??', 'QM')}.jpg"})
		addDir('', '', {'mode': 'listShows', 'url': letter.replace('0-9', '1').replace('??', 'QM')}, FETCH_UNO)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listShows(TYPE):
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listShows) -------------------------------------------------- START = listShows --------------------------------------------------")
	debug_MS(f"(navigator.listShows) ### URL or LETTER = {TYPE} ###")
	content = getUrl(f"{BASE_URL}/sendungen-a-bis-z/")
	if TYPE == 'QM':
		result = re.compile(r'''<h3 class=["']category__headline["']>(.*?)</div>          </div>\s*</div>''', re.S).findall(content)[-1]
	elif len(TYPE) < 4:
		result = re.findall(fr'''<div class=["']category clearfix["'] id=["']{TYPE}["']>(.*?)(?:<div class=["']category clearfix["']|<footer class=)''', content, re.S)[0]
	else:
		result = re.findall(r'''<div id=["']content["'] class=["']container["']>(.*?)<footer class=''', content, re.S)[0]
	part = result.split('<div class="category__item">')
	for i in range(1, len(part), 1):
		entry = part[i]
		NAME = re.compile(r''' alt=["'](.*?)["']/>''', re.S).findall(entry)
		TITLE = cleaning(NAME[0])
		SURL = re.compile(r'''<link itemprop=["']url["'] href=["']([^"']+?)["']''', re.S).findall(entry)
		LINK = BASE_URL+SURL[0] if SURL and SURL[0][:4] != 'http' else SURL[0] if SURL else None
		if (LINK is None) or (LINK and LINK.endswith('https://www.myspass.de')): continue
		LINK = LINK.replace('UNKNOWN', 'tvshows').replace('das-rtl-turmspringen', 'rtl-turmspringen').replace('besten-comedians', 'besten-comediens')
		PHOTO = re.compile(r'''(?:img["'] src=|data-src=)["'](.*?(?:\.png|\.jpg|\.jpeg))["']''', re.S).findall(entry)[0].replace('-300x169.', '.')
		PHOTO = cleanPhoto(PHOTO)
		debug_MS(f"(navigator.listShows[1]) ##### TITLE : {TITLE} || LINK : {LINK} || IMAGE : {PHOTO} #####")
		addType = 1
		if xbmcvfs.exists(channelFavsFile) and os.stat(channelFavsFile).st_size > 0:
			with open(channelFavsFile, 'r') as misc:
				present = json.load(misc)
				for item in present.get('items', []):
					if item.get('url') == LINK: addType = 2
		FETCH_UNO = create_entries({'Title': TITLE, 'Image': PHOTO})
		addDir(TITLE, PHOTO, {'mode': 'listSeasons', 'url': LINK, 'extras': PHOTO, 'transmit': TITLE}, FETCH_UNO, addType)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSelections(TYPE):
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	debug_MS("(navigator.listSelections) -------------------------------------------------- START = listSelections --------------------------------------------------")
	debug_MS(f"(navigator.listSelections) ### THEMA = {TYPE} ###")
	content = getUrl(f"{BASE_URL}/ganze-folgen/")
	result = re.findall(fr'''<h3 class=["']headline has-arrow["']>{TYPE}</h3>(.*?)(?:<h3 class=["']headline has-arrow["']>|<footer class=)''', content, re.S)[0]
	part = result.split('<div class="bacs-item bacs-item--hover')
	for i in range(1, len(part), 1):
		entry = part[i]
		NAME = re.compile(r'''(?:<meta itemprop=["']name["'] content=| alt=)["']([^"']+?)["']/?>''', re.S).findall(entry)
		TITLE = cleaning(NAME[0])
		SURL = re.compile(r'''<a href=["']([^"']+?)["']''', re.S).findall(entry)
		LINK = BASE_URL+SURL[0] if SURL and SURL[0][:4] != 'http' else SURL[0] if SURL else None
		if (LINK is None) or (LINK and LINK.endswith('https://www.myspass.de')): continue
		LINK = LINK.replace('UNKNOWN', 'tvshows').replace('das-rtl-turmspringen', 'rtl-turmspringen').replace('besten-comedians', 'besten-comediens')
		PHOTO = re.compile(r'''(?:<meta itemprop=["']image["'] content=|data-src=)["']([^"']+?)["']''', re.S).findall(entry)[0].replace('-300x169.', '.')
		PHOTO = cleanPhoto(PHOTO)
		DESC = re.compile(r'''<meta itemprop=["']description["'] content=["']([^"']+?)["']''', re.S).findall(entry)
		PLOT = cleaning(DESC[0]) if DESC else None
		debug_MS(f"(navigator.listSelections) ##### TITLE : {TITLE} || LINK : {LINK} || IMAGE : {PHOTO} #####")
		if TYPE == 'CHANNELS' and not 'trailer' in LINK.lower():
			FETCH_UNO = create_entries({'Title': TITLE, 'Image': PHOTO, 'Plot': PLOT})
			addDir(TITLE, PHOTO, {'mode': 'listEpisodes', 'url': LINK, 'extras': 'compilation', 'transmit': TITLE}, FETCH_UNO)
		elif TYPE != 'CHANNELS' and not 'trailer' in LINK.lower():
			addType = 1
			if xbmcvfs.exists(channelFavsFile) and os.stat(channelFavsFile).st_size > 0:
				with open(channelFavsFile, 'r') as misc:
					present = json.load(misc)
					for item in present.get('items', []):
						if item.get('url') == LINK: addType = 2
			FETCH_DUE = create_entries({'Title': TITLE, 'Image': PHOTO, 'Plot': PLOT})
			addDir(TITLE, PHOTO, {'mode': 'listSeasons', 'url': LINK, 'extras': PHOTO, 'transmit': TITLE}, FETCH_DUE, addType)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(TARGET, IMG, SERIE):
	debug_MS("(navigator.listSeasons) -------------------------------------------------- START = listSeasons --------------------------------------------------")
	debug_MS(f"(navigator.listSeasons) ### URL = {TARGET} ###")
	COMBI_SEASON, FOUND = [], 0
	content = getUrl(TARGET)
	SELECTOR = re.search(r'''<select title=["']Staffel auswählen["'] class=(.*?)</select>''', content, re.S)
	if SELECTOR:
		SEASONS = re.findall(r'''<option data-remote-args=["'](.*?)["'].+?data-remote-target=.+?>(.*?)</option>''', SELECTOR.group(1), re.S)
		for SURL, NAME in SEASONS:
			FOUND += 1
			LINK = f'{BASE_URL}/frontend/php/ajax.php?query=bob&videosOnly=true{SURL}'
			TITLE = cleaning(NAME)
			RATE = re.compile('([0-9]+)', re.S).findall(TITLE)
			if RATE:
				TITLE = translation(30620).format(str(RATE[0])) if 'staffel' in TITLE.lower() else translation(30621) if str(RATE[0]) == '1' else TITLE.split(' -')[0]
			debug_MS(f"(navigator.listSeasons[1]) ##### TITLE : {TITLE} || LINK : {LINK} #####")
			COMBI_SEASON.append([TITLE, IMG, LINK, SERIE])
	if COMBI_SEASON and FOUND == 1:
		debug_MS("(navigator.listSeasons[2]) ----- Only one Season FOUND - goto = listEpisodes -----")
		for TITLE, IMG, LINK, SERIE in COMBI_SEASON:
			return listEpisodes(LINK, SERIE)
	elif COMBI_SEASON and FOUND > 1:
		for TITLE, IMG, LINK, SERIE in COMBI_SEASON:
			FETCH_UNO = create_entries({'Title': TITLE, 'Image': IMG})
			addDir('', '', {'mode': 'listEpisodes', 'url': LINK, 'transmit': SERIE}, FETCH_UNO)
	else:
		debug_MS("(navigator.listSeasons[1]) ##### Keine SEASON-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524), translation(30525).format(SERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(TARGET, SERIE):
	debug_MS("(navigator.listEpisodes) -------------------------------------------------- START = listEpisodes --------------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL = {TARGET} ### SERIE = {SERIE} ###")
	SEND = {}
	(COMBI_EPISODE, SEND['videos']), START_URL, position = ([] for _ in range(2)), TARGET, 0
	content = getUrl(TARGET).replace('\\', '')
	if START_URL == BASE_LONG:
		result = re.findall(r'''<div id=["']content["'] class=["']container["']>(.*?)</article>  </section>''', content, re.S)[0]
		part = result.split('<div class="homeTeaser-overlay Desktop_HomeTeaser')
	elif 'channels/' in START_URL:
		result = re.findall(r'''<ul id=["']playlist_ul["']>(.*?)</ul>''', content, re.S)[0]
		part = result.split('_video_li">')
	else:
		part = content.split('bacs-item--hover bacs-item--lg has-infos-shown bacs-item--monthly')
	for i in range(1, len(part), 1):
		entry = part[i]
		debug_MS("-----------------------------------------")
		debug_MS(f"(navigator.listEpisodes[1]) xxxxx ENTRY-01 : {entry} xxxxx")
		newSHOW, newTITLE, VIDEO, Note_1, Note_2, DESC = ("" for _ in range(6))
		SEAS, EPIS, VIDEO_2, VIDEO_3, PHOTO, bcDATE, bcDATE_2, bcDATE_3, YEAR, BEGINS = (None for _ in range(10))
		RUNS, RUNS_2, RUNS_3 = ('0' for _ in range(3))
		if START_URL == BASE_LONG:
			TITLE = re.compile(r'''<h2 class=["']title ellipsis["']>([^<]+?)</h2>''', re.S).findall(entry)[0]
		elif 'channels/' in START_URL:
			TITLE = re.compile(r'''aria-hidden=["']true["']></i>([^<]+?)</a></li>''', re.S).findall(entry)[0]
			if 'channel erneut von vorne' in TITLE.lower(): continue
		else:
			TITLE_1 = re.compile(r'''class=["']title["'] title=["'](.*?)["']>''', re.S).findall(entry)
			TITLE_2 = re.compile(r''' alt=["'](.*?)["']/>''', re.S).findall(entry)
			TITLE = TITLE_1[0] if TITLE_1 else TITLE_2[0]
		TITLE = cleaning(TITLE)
		if not 'channels/' in START_URL and ('Teil 2' in TITLE or 'Teil 3' in TITLE): continue
		SURL = re.compile(r'''<a href=["']([^"']+?)["']''', re.S).findall(entry)
		LINK = BASE_URL+SURL[0] if SURL and SURL[0][:4] != 'http' else SURL[0] if SURL else None
		try: episID = re.compile(r'https?://(?:www\.)?myspass\.de/([^/]+/)*(?P<id>\d+)', re.S).findall(LINK)[0][1]
		except: continue
		newSHOW, newTITLE, SEAS, EPIS, DESC, RUNS, PHOTO, bcDATE, BEGINS, VIDEO = getVideodata(episID)
		if VIDEO == "": continue
		if not 'channels/' in START_URL and ('Teil 1' in TITLE or 'Teil 1' in newTITLE):
			try:
				HREF_1 = LINK.split('www.myspass.de')[1].split('-Teil-')[0] if 'www.myspass.de' in LINK and '-Teil-' in LINK else LINK
				plus_CONTENT = content[content.find('<table class="listView--table">')+1:]
				plus_CONTENT = plus_CONTENT[:plus_CONTENT.find('</table>')]
				match = re.findall(r'<tr data-month(.+?)</tr>', plus_CONTENT, re.S)
				for chtml in match:
					debug_MS(f"(navigator.listEpisodes[2]) ### more Videos CHTML : {chtml} ###")
					HREF_2 = re.compile(r'''<a href=["']([^"']+?)["']''', re.S).findall(chtml)[0]
					HREF_3 = BASE_URL+HREF_2 if HREF_2[:4] != 'http' else HREF_2
					identical = similar(HREF_2, HREF_1)
					if identical is True and 'Teil-2' in HREF_3:
						newIDD_2 = re.compile(r'https?://(?:www\.)?myspass\.de/([^/]+/)*(?P<id>\d+)', re.S).findall(HREF_3)[0][1]
						newSHOW_2, newTITLE_2, SEAS_2, EPIS_2, DESC_2, RUNS_2, PHOTO_2, bcDATE_2, BEGINS_2, VIDEO_2 = getVideodata(newIDD_2)
						VIDEO_2 = f"@@{VIDEO_2}"
					if identical is True and 'Teil-3' in HREF_3:
						newIDD_3 = re.compile(r'https?://(?:www\.)?myspass\.de/([^/]+/)*(?P<id>\d+)', re.S).findall(HREF_3)[0][1]
						newSHOW_3, newTITLE_3, SEAS_3, EPIS_3, DESC_3, RUNS_3, PHOTO_3, bcDATE_3, BEGINS_2, VIDEO_3 = getVideodata(newIDD_3)
						VIDEO_3 = f"@@{VIDEO_3}"
			except: pass
		position += 1
		if VIDEO_2: VIDEO = VIDEO+VIDEO_2
		if VIDEO_3: VIDEO = VIDEO+VIDEO_3
		RUNS = int(RUNS)+int(RUNS_2)+int(RUNS_3)
		IMAGE = cleanPhoto(PHOTO) if PHOTO else icon
		SERIE = newSHOW if START_URL == BASE_LONG else SERIE
		Note_1 = translation(30622).format(SERIE)
		TITLE = f"{SERIE} - {newTITLE}" if START_URL == BASE_LONG else TITLE.split('- Teil')[0].split(' Teil')[0]
		newTITLE = newTITLE.split(' - Teil')[0].split(' Teil')[0] if 'Teil' in newTITLE else newTITLE
		if str(SEAS).isdecimal() and str(EPIS).isdecimal() and str(EPIS) != '0':
			SEAS, EPIS = f"{int(SEAS):02}", f"{int(EPIS):02}"
			NAME = translation(30623).format(SEAS, EPIS, TITLE)
			if bcDATE and not '1970' in bcDATE:
				YEAR, Note_2 = str(bcDATE)[10:14], translation(30624).format(SEAS, EPIS, bcDATE)
			else: Note_2 = translation(30625).format(SEAS, EPIS)
		else:
			NAME = f"{TITLE}  (Special)" if 'spezial' in str(EPIS).lower() else TITLE
			if bcDATE and not '1970' in bcDATE:
				YEAR, Note_2 = str(bcDATE)[10:14], translation(30626).format(newTITLE, bcDATE)
			else: Note_2 = '[CR]'
		if 'channels/' in START_URL:
			NAME = translation(30627).format(f"{int(position):02}", newTITLE)
		PLOT = Note_1+Note_2+DESC.replace('\n', '[CR]')
		debug_MS(f"(navigator.listEpisodes[3]) ##### NAME : {NAME} || IDD : {episID} #####")
		debug_MS(f"(navigator.listEpisodes[3]) ##### SERIE : {SERIE} || BEGINS : {BEGINS} || YEAR : {YEAR} || DURATION : {RUNS} #####")
		debug_MS(f"(navigator.listEpisodes[3]) ##### THUMB : {IMAGE} || SEASON : {SEAS} || EPISODE : {EPIS} #####")
		COMBI_EPISODE.append([episID, VIDEO, IMAGE, NAME, SERIE, SEAS, EPIS, PLOT, RUNS, YEAR, BEGINS])
	if COMBI_EPISODE:
		for episID, VIDEO, IMAGE, NAME, SERIE, SEAS, EPIS, PLOT, RUNS, YEAR, BEGINS in COMBI_EPISODE:
			for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			cineType = 'episode' if str(EPIS).isdecimal() and str(EPIS) != '0' else 'movie'
			playType = 'Multi' if '@@' in VIDEO else 'Single'
			FETCH_UNO = create_entries({'Title': NAME, 'TvShowTitle': SERIE, 'Plot': PLOT, 'Season': SEAS,'Episode': EPIS, 'Duration': RUNS,\
				'Date': BEGINS, 'Year': YEAR, 'Mediatype': cineType, 'Image': IMAGE, 'Reference': playType})
			addDir('', '', {'mode': 'playCODE', 'IDENTiTY': episID}, FETCH_UNO, folder=False)
			SEND['videos'].append({'filter': episID, 'url': VIDEO, 'photo': IMAGE, 'tvshow': SERIE, 'name': NAME})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	else:
		debug_MS("(navigator.listEpisodes[1]) ##### Keine EPISODE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524), translation(30525).format(SERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def getVideodata(VideoID):
	# https://www.myspass.de/includes/apps/video/getvideometadataxml.php?id=886
	(show, name, plot, stream), duration = ("" for _ in range(4)), 0
	seasonNR, episodeNR, image, starting, begins = (None for _ in range(5))
	DATA_ONE = f'{BASE_URL}/includes/apps/video/getvideometadataxml.php?id={VideoID}'
	debug_MS(f"(common.getVideodata) ### URL = {DATA_ONE} ###")
	content = getUrl(DATA_ONE)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(common.getVideodata[1]) CONTENT-01 : {content}")
	debug_MS("++++++++++++++++++++++++")
	TVS = re.compile(r'<format><!\[CDATA\[(.*?)\]\]></format>', re.S).findall(content)
	if TVS: show = cleaning(TVS[0])
	TTL = re.compile(r'<title><!\[CDATA\[(.*?)\]\]></title>', re.S).findall(content)
	if TTL: name = cleaning(TTL[0])
	SEAS = re.compile(r'<season><!\[CDATA\[(.*?)\]\]></season>', re.S).findall(content)
	if SEAS: seasonNR = SEAS[0]
	EPIS = re.compile(r'<episode><!\[CDATA\[(.*?)\]\]></episode>', re.S).findall(content)
	if EPIS: episodeNR = EPIS[0]
	DESC = re.compile(r'<description><!\[CDATA\[(.*?)\]\]></description>', re.S).findall(content)
	if DESC: plot = cleaning(DESC[0])
	DUR = re.compile(r'<duration><!\[CDATA\[(.*?)\]\]></duration>', re.S).findall(content)
	if DUR: duration = get_RunTime(DUR[0])
	IMG = re.compile(r'<imagePreview><!\[CDATA\[(.*?)\]\]></imagePreview>', re.S).findall(content)
	if IMG: image = IMG[0]
	BC_DATE = re.compile(r'<broadcast_date><!\[CDATA\[(.*?)\]\]></broadcast_date>', re.S).findall(content)
	BC_TIME = re.compile(r'<broadcast_time><!\[CDATA\[(.*?)\]\]></broadcast_time>', re.S).findall(content)
	if BC_DATE and BC_TIME:
		try:
			fullDATE = f"{BC_DATE[0][:10]}T{BC_TIME[0][:8]}"
			available = datetime(*(time.strptime(fullDATE, '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2019-06-13T22:15:00
			starting = available.strftime('%a{0} %d{0}%m{0}%Y').format('.')
			for sd in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), ('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))): starting = starting.replace(*sd)
			begins = available.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
			if KODI_ov20:
				begins = available.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
		except: pass
	VID = re.compile(r'<url_flv><!\[CDATA\[(.*?)\]\]></url_flv>', re.S).findall(content)
	if VID:
		stream = VID[0]
		grps = re.search(r'/myspass2009/\d+/(\d+)/(\d+)/(\d+)/', stream)
		for group in grps.groups() if grps else []:
			videoINT, groupINT = int(VideoID), int(group)
			if groupINT > videoINT:
				try: stream = stream.replace(group, unicode(groupINT // videoINT))
				except NameError: stream = stream.replace(group, str(groupINT // videoINT))
	return (show, name, seasonNR, episodeNR, plot, duration, image, starting, begins, stream)

def playCODE(SOURCE):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### SOURCE = {SOURCE} ###")
	FINAL_URL, position = False, 0
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == SOURCE:
				FINAL_URL, PHOTO, seriesname = elem['url'], elem['photo'], elem['tvshow']
				TITLE = elem['name'].split('[/COLOR]')[1].strip() if '[/COLOR]' in elem['name'] else elem['name']
				debug_MS(f"(navigator.playCODE) ### WORKFILE-Line : {str(elem)} ###")
	if FINAL_URL:
		if '@@' in FINAL_URL:
			PLT, fields = cleanPlaylist(), FINAL_URL.split('@@')
			for track in fields:
				position += 1
				LSM = xbmcgui.ListItem(translation(30628).format(TITLE, str(position), str(len(fields))), path=track)
				LSM.setArt({'icon': icon, 'thumb': PHOTO, 'poster': PHOTO})
				log(f"(navigator.playCODE) no. {str(position)}_playlist : {track}")
				PLT.add(track, LSM)
			xbmc.Player().play(PLT)
		else:
			log(f"(navigator.playCODE) StreamURL : {FINAL_URL}")
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL))
	else:
		failing("(navigator.playCODE[1]) AbspielLink-00 : *MYSPASS* Der angeforderte -VideoLink- wurde NICHT gefunden !!!")
		return dialog.notification(translation(30521).format('Video'), translation(30526), icon, 8000)

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if xbmcvfs.exists(channelFavsFile) and os.stat(channelFavsFile).st_size > 0:
		with open(channelFavsFile, 'r') as hold:
			snippets = json.load(hold)
			for item in snippets.get('items', []):
				TITLE, PHOTO = cleaning(item.get('name')), cleanPhoto(item.get('pict'))
				FETCH_UNO = create_entries({'Title': TITLE, 'Image': PHOTO})
				debug_MS(f"(navigator.listFavorites) ### NAME : {TITLE} || URL : {item.get('url')} || IMAGE : {PHOTO} ###")
				addDir(TITLE, PHOTO, {'mode': 'listSeasons', 'url': item.get('url'), 'extras': PHOTO, 'transmit': TITLE}, FETCH_UNO, FAVclear=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(*args):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(channelFavsFile) and os.stat(channelFavsFile).st_size > 0:
		with open(channelFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'name': name, 'pict': pict, 'url': url})
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30527), translation(30528).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('url') != url]
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30527), translation(30529).format(name), icon, 8000)

def addDir(name, image, params, listitem, addType=0, FAVclear=False, folder=True):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if addType == 1 and FAVclear is False:
		entries.append([translation(30651), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'ADD', 'name': params.get('transmit'), 'pict': image, 'url': params.get('url')}))])
	if addType == 0 and FAVclear is True:
		entries.append([translation(30652), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'DEL', 'name': params.get('transmit'), 'pict': image, 'url': params.get('url')}))])
	if entries: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
