﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
import io
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import quote_plus, urlencode  # Python 2.X
else: 
	from urllib.parse import quote_plus, urlencode  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	addDir('Neue Videos', icon, {'mode': 'listVideos', 'url': BASE_API+'command=latest&length=30'})
	addDir('Beliebte Videos', icon, {'mode': 'listVideos', 'url': BASE_API+'command=favourite&length=30'})
	addDir('Ganze Folgen', icon, {'mode': 'listShows', 'url': BASE_API+'command=formats&length=200'})
	addDir('Sendungen A-Z', icon, {'mode': 'listShows', 'url': BASE_API+'command=azformats&length=200'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listShows(url):
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
	debug("(navigator.listShows) ------------------------------------------------ START = listShows -----------------------------------------------")
	debug("(navigator.listShows) ### URL : {0} ###".format(url))
	content = getUrl(url)
	DATA = json.loads(content) 
	for elem in DATA['data']:
		name = ""
		plot = ""
		if "format" in elem and elem['format'] != "" and elem['format'] != None:
			name = cleaning(elem['format'])
		if "format_description" in elem and elem['format_description'] != "" and elem['format_description'] != None:
			plot = cleaning(elem['format_description'])
		TVS_idd = str(elem['format_id'])
		image = 'http:'+elem['latestVideo']['original_image'].replace('\/', '/') if elem['latestVideo']['original_image'][:4] != "http" else elem['latestVideo']['original_image'].replace('\/', '/')
		debug("(navigator.listShows) ##### TITLE = {0} || IDD = {1} || PHOTO = {2} #####".format(name, TVS_idd, str(image)))
		if 'media/images' in image:
			addDir(name, image, {'mode': 'listSeasons', 'url': BASE_API+'command=seasonslist&id='+TVS_idd}, plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(url):
	debug("(navigator.listSeasons) ------------------------------------------------ START = listSeasons -----------------------------------------------")
	debug("(navigator.listSeasons) ### URL : {0} ###".format(url))
	content = getUrl(url)
	DATA = json.loads(content) 
	for elem in DATA['data']:
		name = ""
		plot = ""
		if "season_name" in elem and elem['season_name'] != "" and elem['season_name'] != None:
			name = cleaning(elem['season_name'])
			if name == '1': name = 'Staffel 1'
		if "season_description" in elem and elem['season_description'] != "" and elem['season_description'] != None:
			plot = cleaning(elem['season_description'])
		SEA_idd = str(elem['season_id'])
		image = 'http:'+elem['latestVideo']['original_image'].replace('\/', '/') if elem['latestVideo']['original_image'][:4] != "http" else elem['latestVideo']['original_image'].replace('\/', '/')
		debug("(navigator.listSeasons) ##### TITLE = {0} || IDD = {1} || PHOTO = {2} #####".format(name, SEA_idd, str(image)))
		if name != 'Trailer':
			addDir(name, image, {'mode': 'listVideos', 'url': BASE_API+'command=seasonepisodes&id='+SEA_idd}, plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(url):
	debug("(navigator.listVideos) ------------------------------------------------ START = listVideos -----------------------------------------------")
	debug("(navigator.listVideos) ### URL : {0} ###".format(url))
	uno_LIST = []
	firstURL = url
	try:
		content = getUrl(url)
		DATA = json.loads(content)
	except: return dialog.notification('[COLOR red]Leider gibt es KEINE Einträge :[/COLOR]', '* [COLOR blue]In dieser Rubrik[/COLOR] * bei MySpass', icon, 8000)
	for item in DATA['data']:
		debug("(navigator.listVideos) xxxxx ELEMENT : {0} xxxxx".format(str(item)))
		seriesname, title, Note_1, Note_2 = ("" for _ in range(4))
		duration2, vidURL2, duration3, vidURL3, startDATES = (None for _ in range(5))
		duration = '0'
		if "format" in item and item['format'] != "" and item['format'] != None:
			seriesname = cleaning(item['format'])
		if "title" in item and item['title'] != "" and item['title'] != None:
			title = cleaning(item['title'])
		if 'Teil 2' in title or 'Teil 3' in title: continue
		episID = str(item['unique_id'])
		if 'command=hometeaser' in firstURL:
			item = item['video']
		image = 'http:'+item['original_image'].replace('\/', '/') if item['original_image'][:4] != "http" else item['original_image'].replace('\/', '/')
		if 'Teil 1' in title:
			try:
				searchURL = item['myspass_url'].replace('\/', '/').replace('/myspass/', '/').replace('http://www.myspass.de/', BASE_URL)
				debug("(navigator.listVideos) no.01 ##### searchURL : {0} #####".format(searchURL))
				header = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0'), ('Accept-Encoding', 'gzip, identity')]
				html = getUrl(searchURL, header=header)
				if 'www.myspass.de' in searchURL and '-Teil-' in searchURL: shortURL = searchURL.split('www.myspass.de')[1].split('-Teil-')[0]
				else: shortURL = searchURL
				plus_CONTENT = html[html.find('<table class="listView--table">')+1:]
				plus_CONTENT = plus_CONTENT[:plus_CONTENT.find('</table>')]
				match = re.findall('data-id="(.+?)".*?<a href="(.+?)">', plus_CONTENT, re.S)
				for newIDD, url2 in match:
					debug("(navigator.listVideos) no.02 ##### newIDD = {0} || URL-2 = {1} #####".format(str(newIDD), url2))
					if shortURL in url2 and 'Teil-2' in url2:
						content_2 = getUrl(BASE_API+'command=video&id='+str(newIDD))
						DATA_2 = json.loads(content_2)
						duration2 = DATA_2['data']['play_length']
						vidURL2 = '@@'+cleanVideo(DATA_2['data']['video_url'])
					if shortURL in url2 and 'Teil-3' in url2:
						content_3 = getUrl(BASE_API+'command=video&id='+str(newIDD))
						DATA_3 = json.loads(content_3)
						duration3 = DATA_3['data']['play_length']
						vidURL3 = '@@'+cleanVideo(DATA_3['data']['video_url'])
			except: pass
		if "broadcast_date" in item and item['broadcast_date'] != "" and item['broadcast_date'] != None:
			try:
				airedtime = datetime(*(time.strptime(item['broadcast_date'], '%Y{0}%m{0}%d'.format('-'))[0:6])) # 2019-06-13
				startDATES =  airedtime.strftime('%d{0}%m{0}%Y').format('.')
			except: pass
		if startDATES and not '1970' in startDATES: Note_1 = "Sendung vom "+str(startDATES)+"[CR][CR]"
		if "teaser_text" in item and item['teaser_text'] != "" and item['teaser_text'] != None:
			Note_2 = cleaning(item['teaser_text'])
		plot = Note_1+Note_2
		season = str(item['season_number']).zfill(2)
		episode = str(item['episode_nr'])
		if episode.startswith('00'): episode = episode.replace('00', '0')
		episode = episode.zfill(2)
		vidURL = cleanVideo(item['video_url'])
		if vidURL2: vidURL = vidURL+vidURL2
		if vidURL3: vidURL = vidURL+vidURL3
		if "play_length" in item and item['play_length'] != "" and item['play_length'] != None:
			duration = item['play_length']
		if duration2: duration = int(duration)+int(duration2)
		if duration3: duration = int(duration)+int(duration3)
		name = "[COLOR chartreuse]S"+season+"E"+episode+":[/COLOR]  "+title.split('- Teil')[0].split(' Teil')[0]
		if 'hometeaser' in firstURL or 'favourite' in firstURL or 'latest&length' in firstURL:
			name = "[COLOR chartreuse]S"+season+"E"+episode+":[/COLOR]  "+seriesname+" - "+title.split('- Teil')[0].split(' Teil')[0]
		EP_entry = episID+'###'+str(vidURL)+'###'+str(seriesname)+'###'+str(name)+'###'+str(image)+'###'+str(plot.replace('\n', '#n#'))+'###'+str(duration)+'###'+str(season)+'###'+str(episode)+'###'
		if EP_entry not in uno_LIST:
			uno_LIST.append(EP_entry)
		listitem = xbmcgui.ListItem(name, path=HOST_AND_PATH+'?IDENTiTY='+episID+'&mode=playCODE')
		info = {}
		info['Season'] = season
		info['Episode'] = episode
		info['Tvshowtitle'] = seriesname
		info['Title'] = name
		info['Tagline'] = None
		info['Plot'] = plot
		info['Duration'] = duration
		info['Year'] = None
		info['Genre'] = 'Unterhaltung'
		info['Studio'] = 'myspass.de'
		info['Mpaa'] = None
		info['Mediatype'] = 'episode'
		listitem.setInfo(type='Video', infoLabels=info)
		listitem.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
		if image != icon:
			listitem.setArt({'fanart': image})
		listitem.addStreamInfo('Video', {'Duration':duration})
		listitem.setProperty('IsPlayable', 'true')
		listitem.addContextMenuItems([('[COLOR yellow]In MySpass-Abspielliste einreihen[/COLOR]', 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
		xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+episID+'&mode=playCODE', listitem=listitem)
	with io.open(WORKFILE, 'w', encoding='utf-8') as input:
		input.write(py2_uni('\n'.join(uno_LIST)))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playCODE(IDD):
	debug("(navigator.playCODE) ------------------------------------------------ START = playCODE -----------------------------------------------")
	debug("(navigator.playCODE) ### IDD : {0} ###".format(str(IDD)))
	pos_LISTE = 0
	Special = False
	PL = xbmc.PlayList(1)
	with io.open(WORKFILE, 'r', encoding='utf-8') as output:
		lines = output.readlines()
		for line in lines:
			field = line.split('###')
			if field[0]==IDD:
				endURL = field[1]
				seriesname = field[2]
				title = field[3]
				try: title = title.split(':[/COLOR]')[1].strip()
				except: pass
				try: title = title.split(seriesname+" -")[1].strip()
				except: pass
				image = field[4]
				plot = field[5].replace('#n#', '\n').strip()
				duration = field[6]
				season = field[7]
				episode = field[8]
				if '@@' in endURL:
					Special = True
					videoURL = endURL.split('@@')
					complete = '/2'
					if len(videoURL) == 3:
						complete = '/3'
					for single in videoURL:
						log("(navigator.playCODE) Playlist : {0} ".format(str(single)))
						pos_LISTE += 1
						NRS_title = title+"[COLOR chartreuse]  TEIL "+str(pos_LISTE)+complete+"[/COLOR]"
						listitem = xbmcgui.ListItem(title)
						listitem.setInfo(type='Video', infoLabels={'Tvshowtitle': seriesname, 'Title': NRS_title, 'Season': season, 'Episode': episode, 'Plot': plot, 'Duration': duration, 'Studio': 'myspass.de', 'Genre': 'Unterhaltung', 'mediatype': 'episode'})
						listitem.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': image})
						xbmc.sleep(50)
						PL.add(url=single, listitem=listitem, index=pos_LISTE)
				else:
					log("(navigator.playCODE) Streamurl : {0} ".format(str(endURL)))
					listitem = xbmcgui.ListItem(path=endURL)
					listitem.setInfo(type='Video', infoLabels={'Tvshowtitle': seriesname, 'Title': title, 'Season': season, 'Episode': episode, 'Plot': plot, 'Duration': duration, 'Studio': 'myspass.de', 'Genre': 'Unterhaltung', 'mediatype': 'episode'})
					listitem.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': image})
	if Special:
		return PL
	else:
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image != icon:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)
