﻿# -*- coding: utf-8 -*-

from .common import *
config = traversing.get_config()


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	SEND = {}
	addDir({'mode': 'listFavorites'}, create_entries({'Title': translation(30601), 'Image': f"{artpic}favourites.png"}))
	SEND['playlists'], MERGING = [], [getUrl(config['PAGE_VIEW'].format('homepage&'), AUTH=VANILLA_TOKEN)]
	MERGING += [getUrl(config['PAGE_VIEW'].format('detail%20page&'), AUTH=VANILLA_TOKEN)]
	for item in MERGING:
		for each in item.get('data', []):
			debug_MS(f"(navigator.mainMenu[1]) xxxxx THEME-01 : {each} xxxxx")
			THEME_IDD = each['id']
			TITLE = cleaning(each['attributes']['title']).replace('Hero', translation(30602))
			INSTANCE = 'listEpisodes' if 'hero' in each['attributes']['title'].lower() else 'listShows'
			if each['attributes'].get('page', '').upper() == 'HOMEPAGE':
				addDir({'mode': INSTANCE, 'url': 'ENTRIES_HOME', 'extras': THEME_IDD, 'name': TITLE}, create_entries({'Title': f"[B]{TITLE}[/B]"}))
			elif each['attributes'].get('page', '').upper() == 'DETAIL PAGE':
				TITLE = cleaning(each['attributes']['title']).replace('Alle Sendungen', translation(30603))
				addDir({'mode': INSTANCE, 'url': 'ENTRIES_HOME', 'extras': THEME_IDD, 'name': TITLE}, create_entries({'Title': f"[B]{TITLE}[/B]"}))
			debug_MS(f"(navigator.mainMenu[2]) ### ACTION : {INSTANCE} || NAME : {TITLE} || THEME_IDD : {THEME_IDD} ###")
			debug_MS("++++++++++++++++++++++++")
			SEND['playlists'].append(each)
	with open(HOMEBASE, 'w') as backup:
		json.dump(SEND, backup, indent=2, sort_keys=True)
	if enableADJUSTMENT:
		FETCH_UNO = create_entries({'Title': translation(30609), 'Image': f"{artpic}settings.png"})
		addDir({'mode': 'aConfigs'}, FETCH_UNO, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			FETCH_DUE = create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"})
			addDir({'mode': 'iConfigs'}, FETCH_DUE, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listShows(TARGET, CAT_IDD, NAME):
	debug_MS("(navigator.listShows) -------------------------------------------------- START = listShows --------------------------------------------------")
	debug_MS(f"(navigator.listShows) ### TARGET = {TARGET} ### CAT_IDD = {CAT_IDD} ### NAME = {NAME} ###")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	DATA_ONE, FOUND, UNIKAT = {}, 0, set()
	if TARGET.startswith('ENTRIES_HOME') and xbmcvfs.exists(HOMEBASE) and os.stat(HOMEBASE).st_size > 0:
		with open(HOMEBASE, 'r') as ground:
			DATA_ONE = json.load(ground)
	for item in DATA_ONE.get('playlists', []):
		if int(item.get('id', 0)) == int(CAT_IDD):
			for each in item['attributes'].get('items', []):
				SHORT, (THUMB, POSTER) = each['format']['data'], (None for _ in range(2))
				debug_MS(f"(navigator.listShows[1]) xxxxx EACH-01 : {each} xxxxx")
				SHOW_IDD = SHORT['id']
				if SHOW_IDD in ['', 0, None] or SHOW_IDD in UNIKAT:
					debug_MS("~~~~~~~~~~~~~~~~~~~~~~~~ THIS SHOW IS DOUBLE - REMOVED ~~~~~~~~~~~~~~~~~~~~~~~~")
					continue
				UNIKAT.add(SHOW_IDD)
				FOUND += 1
				TITLE = cleaning(SHORT['attributes']['name'])
				PLOT = get_Description(SHORT.get('attributes', ''))
				if SHORT['attributes'].get('keyvisual_16_9', '') and SHORT['attributes']['keyvisual_16_9'].get('data', '') and \
					SHORT['attributes']['keyvisual_16_9']['data'].get('attributes', '') and SHORT['attributes']['keyvisual_16_9']['data']['attributes'].get('url', ''):
					THUMB = SHORT['attributes']['keyvisual_16_9']['data']['attributes']['url']
				if SHORT['attributes'].get('keyvisual_5_8', '') and SHORT['attributes']['keyvisual_5_8'].get('data', '') and \
					SHORT['attributes']['keyvisual_5_8']['data'].get('attributes', '') and SHORT['attributes']['keyvisual_5_8']['data']['attributes'].get('url', ''):
					POSTER = SHORT['attributes']['keyvisual_5_8']['data']['attributes']['url']
				debug_MS(f"(navigator.listShows[2]) ### NAME : {TITLE} || SHOW_IDD : {SHOW_IDD} || THUMB : {THUMB} ###")
				debug_MS("++++++++++++++++++++++++")
				addType = 1
				if xbmcvfs.exists(channelFavsFile) and os.stat(channelFavsFile).st_size > 0:
					with open(channelFavsFile, 'r') as misc:
						present = json.load(misc)
						for article in present.get('items', []):
							if article.get('url') == str(SHOW_IDD): addType = 2
				FETCH_UNO = create_entries({'Title': TITLE, 'Plot': PLOT, 'Image': THUMB, 'Poster': POSTER})
				addDir({'mode': 'listSeasons', 'url': SHOW_IDD, 'picture': THUMB, 'portrait': POSTER, 'name': TITLE, 'plot': PLOT}, FETCH_UNO, addType)
	if FOUND == 0:
		failing("(navigator.listShows) ##### Keine TVSHOW-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524), translation(30525).format(NAME), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(TARGET, IMG, SERIE):
	debug_MS(f"(navigator.listSeasons) ### URL = {TARGET} ### THUMB = {IMG} ### SERIE = {SERIE} ###")
	COMBI_SEASON, FOUND, UNIKAT = [], 0, set()
	DATA_ONE = getUrl(config['SEAS_VIEW'].format(TARGET), AUTH=VANILLA_TOKEN)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listSeasons[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if DATA_ONE is not None and DATA_ONE.get('data', '') and DATA_ONE['data'].get('attributes', '') and DATA_ONE['data']['attributes'].get('seasons', '') and DATA_ONE['data']['attributes']['seasons'].get('data', ''):
		for item in DATA_ONE['data']['attributes']['seasons'].get('data', []):
			FORM_IDD = DATA_ONE['data']['id']
			SEAS_IDD = item['id']
			if SEAS_IDD in ['', 0, None] or SEAS_IDD in UNIKAT:
				continue
			UNIKAT.add(SEAS_IDD)
			FOUND += 1
			TITLE = cleaning(item['attributes']['name'])
			PLOT = get_Description(item.get('attributes', ''))
			debug_MS(f"(navigator.listSeasons[2]) ### NAME : {TITLE} || FORM_IDD : {FORM_IDD} || SEAS_IDD : {SEAS_IDD} || THUMB : {IMG} ###")
			COMBI_SEASON.append([TITLE, IMG, PLOT, SERIE, FORM_IDD, SEAS_IDD])
	if COMBI_SEASON and FOUND == 1:
		debug_MS("(navigator.listSeasons[3]) ----- Only one Season FOUND - goto = listEpisodes -----")
		for TITLE, IMG, PLOT, SERIE, FORM_IDD, SEAS_IDD in COMBI_SEASON:
			return listEpisodes(FORM_IDD, SEAS_IDD, SERIE, page)
	elif COMBI_SEASON and FOUND > 1:
		for TITLE, IMG, PLOT, SERIE, FORM_IDD, SEAS_IDD in sorted(COMBI_SEASON, key=lambda ex: ex[0]):
			FETCH_UNO = create_entries({'Title': TITLE, 'Plot': PLOT, 'Image': IMG})
			addDir({'mode': 'listEpisodes', 'url': FORM_IDD, 'extras': SEAS_IDD, 'name': SERIE}, FETCH_UNO)
	else:
		failing("(navigator.listSeasons) ##### Keine SEASON-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524), translation(30525).format(SERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(TARGET, SEAS_CODE, SERIE, PAGE):
	debug_MS("(navigator.listEpisodes) -------------------------------------------------- START = listEpisodes --------------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL = {TARGET} ### SEAS_CODE = {SEAS_CODE} ### SERIE = {SERIE} ### PAGE = {PAGE} ###")
	DATA_ONE, FOUND, UNIKAT = {}, 0, set()
	if TARGET != 'ENTRIES_HOME' and str(TARGET).isdecimal():
		DATA_ONE = getUrl(config['EPIS_VIEW'].format(TARGET, SEAS_CODE, PAGE), AUTH=VANILLA_TOKEN)
	elif TARGET == 'ENTRIES_HOME' and xbmcvfs.exists(HOMEBASE) and os.stat(HOMEBASE).st_size > 0:
		with open(HOMEBASE, 'r') as ground:
			DATA_ONE = json.load(ground)
	ARTICLES = DATA_ONE.get('data', []) if TARGET != 'ENTRIES_HOME' and str(TARGET).isdecimal() else DATA_ONE['playlists'][0]['attributes'].get('items', [])
	for item in ARTICLES:
		for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
		(NOTE_1, NOTE_2), (SEAS, EPIS, BC_DATE, BC_TIME, AIRED, STARTS, BEGINS) = ("" for _ in range(2)), (None for _ in range(7))
		SHORT = item['video']['data'] if item.get('video', '') else item
		debug_MS(f"(navigator.listEpisodes[1]) xxxxx SHORT-01 : {SHORT} xxxxx")
		EPIS_IDD = SHORT['id']
		TITLE = cleaning(SHORT['attributes']['title'])
		NOTE_1 = translation(30620).format(SERIE) if SERIE != "" else translation(30620).format(SHORT['attributes']['format']['data']['attributes']['name']) if \
			SHORT['attributes'].get('format', '') and SHORT['attributes']['format'].get('data', '') and SHORT['attributes']['format']['data'].get('attributes', '') and \
			SHORT['attributes']['format']['data']['attributes'].get('name', '') else ""
		matchSE = re.search(r'(Staffel:? )(\d+)', SHORT['attributes'].get('unique_name', '')) if SHORT['attributes'].get('unique_name', '') else None # "Staffel 2, Folge 5 // Staffel: 2, Folge: 6
		if matchSE: SEAS = matchSE.group(2)
		matchEP_ONE = re.search(r'(Episode:? |Folge:? )(\d+)', SHORT['attributes'].get('unique_name', '')) if SHORT['attributes'].get('unique_name', '') else None # "Staffel 2, Folge 5 // Staffel: 2, Folge: 6
		matchEP_TWO = re.search(r'(Episode:? |Folge:? )(\d+)', SHORT['attributes']['episode']['data']['attributes'].get('title', '')) if SHORT['attributes'].get('episode', '') and \
			SHORT['attributes']['episode'].get('data', '') and SHORT['attributes']['episode']['data'].get('attributes', '') and \
			SHORT['attributes']['episode']['data']['attributes'].get('title', '') else None # "Staffel 2, Folge 5 // Staffel: 2, Folge: 6
		if matchEP_ONE or matchEP_TWO: EPIS = matchEP_ONE.group(2) if matchEP_ONE else matchEP_TWO.group(2)
		DESC = cleaning(SHORT['attributes'].get('teaser_text', ''))
		RUNS = SHORT['attributes'].get('play_length', None)
		BC_DATE = SHORT['attributes'].get('broadcast_date', None)
		BC_TIME = SHORT['attributes'].get('broadcast_time', None)
		if BC_DATE and not str(BC_DATE).startswith('0000') and BC_TIME:
			CIPHER = datetime(*(time.strptime(f"{BC_DATE[:10]}T{BC_TIME[:8]}", '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2019-06-13T22:15:00
			AIRED = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # FirstAired
			STARTS = CIPHER.strftime('%a{0} %d{0}%m{0}%Y').format('.')
			for sd in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), \
				('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))): STARTS = STARTS.replace(*sd)
			BEGINS = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
			if KODI_ov20:
				BEGINS = CIPHER.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
		if str(SEAS).isdecimal() and str(EPIS).isdecimal() and str(EPIS) != '0':
			SEAS, EPIS = f"{int(SEAS):02}", f"{int(EPIS):02}"
			NAME = translation(30621).format(SEAS, EPIS, TITLE)
			if STARTS and not '1970' in STARTS: NOTE_2 = translation(30622).format(SEAS, EPIS, STARTS)
			else: NOTE_2 = translation(30623).format(SEAS, EPIS)
		else:
			if STARTS and not '1970' in STARTS: NAME ,NOTE_2 = TITLE, translation(30624).format(STARTS)
			else: NAME ,NOTE_2 = TITLE, '[CR]'
		THUMB = config['IMAGE_URL'].format(re.sub(r'/[0-9]+.jpg', '', SHORT['attributes'].get('thumbnail_url', '')), SHORT['attributes'].get('thumbnail_url', '').split('/')[-1])
		VIDEO = SHORT['attributes'].get('video_url', None)
		if EPIS_IDD in ['', 0, None] or EPIS_IDD in UNIKAT or VIDEO is None:
			continue
		UNIKAT.add(EPIS_IDD)
		FOUND += 1
		debug_MS(f"(navigator.listEpisodes[2]) ##### NAME : {NAME} || EPIS_IDD : {EPIS_IDD} #####")
		debug_MS(f"(navigator.listEpisodes[2]) ##### SERIE : {SERIE} || BEGINS : {BEGINS} || DURATION : {RUNS} #####")
		debug_MS(f"(navigator.listEpisodes[2]) ##### THUMB : {THUMB} || SEASON : {SEAS} || EPISODE : {EPIS} #####")
		debug_MS("++++++++++++++++++++++++")
		FETCH_UNO = create_entries({'Title': NAME, 'TvShowTitle': SERIE, 'Plot': NOTE_1+NOTE_2+DESC, 'Season': SEAS,'Episode': EPIS, \
			'Duration': RUNS, 'Date': BEGINS, 'Aired': AIRED, 'Mediatype': 'episode', 'Image': THUMB, 'Reference': 'Single'})
		addDir({'mode': 'playVideo', 'url': VIDEO}, FETCH_UNO, folder=False)
	NUMBERS = DATA_ONE['meta']['pagination']['total'] if DATA_ONE.get('meta', '') and DATA_ONE['meta'].get('pagination', '') and \
		DATA_ONE['meta']['pagination'].get('total', '') and str(DATA_ONE['meta']['pagination']['total']).isdecimal() else None
	if FOUND > 0 and NUMBERS and int(NUMBERS) > int(PAGE)*40:
		debug_MS(f"(navigator.listEpisodes[3]) PAGES ### NOW SHOW NEXTPAGE ENTRY ... No.{int(PAGE)+1} || URL : {config['EPIS_VIEW'].format(TARGET, SEAS_CODE, str(int(PAGE)+1))} ... ###")
		FETCH_DUE = create_entries({'Title': translation(30625).format(int(PAGE)+1), 'Image': f"{artpic}nextpage.png"})
		addDir({'mode': 'listEpisodes', 'url': TARGET, 'extras': SEAS_CODE, 'name': SERIE, 'page': int(PAGE)+1}, FETCH_DUE)
	elif FOUND == 0:
		failing("(navigator.listEpisodes) ##### Keine EPISODE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524), translation(30525).format(SERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(SOURCE):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### SOURCE = {SOURCE} ###")
	SOURCE = re.sub(r'/[0-9]+_720-HLS_.m3u8', '/master.m3u8', SOURCE.replace('/720-HLS', '')) if '/720-HLS' in SOURCE else SOURCE
	FINAL_URL = config['PLAYER_M3U8'].format(SOURCE) if SOURCE else False
	if FINAL_URL:
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		STREAM = 'M3U8'
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'm3u8' in FINAL_URL:
			STREAM = 'HLS'
			LSM.setMimeType('application/vnd.apple.mpegurl')
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			if KODI_un21:
				LSM.setProperty('inputstream.adaptive.manifest_type', 'hls') # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LSM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full') # THE "full" BEHAVIOUR PARAM HAS BEEN REMOVED ON Kodi v21 because now enabled by default.
			if KODI_ov20:
				LSM.setProperty('inputstream.adaptive.manifest_headers', f"User-Agent={get_userAgent()}") # On KODI v20 and above
			else:
				LSM.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={get_userAgent()}") # On KODI v19 and below
		log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}|User-Agent={get_userAgent()}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
	else:
		failing("(navigator.playVideo) AbspielLink-00 : *MYSPASS* Der angeforderte -VideoLink- wurde NICHT gefunden !!!")
		return dialog.notification(translation(30521).format('VIDEO'), translation(30526), icon, 10000)

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if xbmcvfs.exists(channelFavsFile) and os.stat(channelFavsFile).st_size > 0:
		with open(channelFavsFile, 'r') as hold:
			snippets = json.load(hold)
			for each in snippets.get('items', []):
				LINK, THUMB, POSTER, TITLE, PLOT = each.get('url'), each.get('picture'), each.get('portrait', ''), cleaning(each.get('name')), cleaning(each.get('plot', ''))
				FETCH_UNO = create_entries({'Title': TITLE, 'Plot': PLOT, 'Image': THUMB, 'Poster': POSTER})
				addDir({'mode': 'listSeasons', 'url': LINK, 'picture': THUMB, 'portrait': POSTER, 'name': TITLE, 'plot': PLOT}, FETCH_UNO, FAVclear=True)
				debug_MS(f"(navigator.listFavorites[1]) ### NAME : {TITLE} || SHOW_IDD : {LINK} || IMAGE : {THUMB} ###")
			debug_MS("++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(*args):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(channelFavsFile) and os.stat(channelFavsFile).st_size > 0:
		with open(channelFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'url': url, 'picture': picture, 'portrait': portrait, 'name': name, 'plot': plot})
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=2, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30527), translation(30528).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('url') != url]
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=2, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30527), translation(30529).format(name), icon, 8000)

def addDir(params, listitem, addType=0, FAVclear=False, folder=True):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if addType == 1 and FAVclear is False:
		entries.append([translation(30651), f"RunPlugin({build_mass({**params, **{'mode': 'favs', 'action': 'ADD'}})})"])
	if addType == 0 and FAVclear is True:
		entries.append([translation(30652), f"RunPlugin({build_mass({**params, **{'mode': 'favs', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
