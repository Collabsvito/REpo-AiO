﻿# -*- coding: utf-8 -*-

from .common import *
from .resolver import *


def main_menu():
	for TITLE, IMG, PATH in [(30601, 'favourites', {'mode': 'list_favorites'}), (30602, 'beliebteste', {'mode': 'list_broadcasts', 'link': '/top.json', 'phase': 'shows'}),
		(30603, 'trends', {'mode': 'list_broadcasts', 'link': '/trends.json', 'phase': 'shows'}), (30604, 'stations', {'mode': 'list_broadcasts', 'link': '/index.json', 'phase': 'stations'}),
		(30605, 'categories', {'mode': 'list_broadcasts', 'link': '/index.json', 'phase': 'categories'}), (30606, 'justfound', {'mode': 'list_broadcasts', 'link': '/index.json', 'phase': 'justFound'}),
		(30607, 'expiring', {'mode': 'list_broadcasts', 'link': '/index.json', 'phase': 'expiring'}), (30608, 'vonabisz', {'mode': 'list_alphabet'}),
		(30609, 'archive', {'mode': 'filtrate_search', 'link': '/search.json', 'phase': 'searchFILTRATE'}), (30610, 'basesearch', {'mode': 'search_sever', 'phase': 'searchWORD'})]:
		add_views(PATH, create_entries({'Title': translation(TITLE), 'Image': f"{artpic}{IMG}.png"}))
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30611), 'Image': f"{artpic}settings.png"}), False)
		if enable_adaptive and plugin_operate('inputstream.adaptive'):
			add_views({'mode': 'ietuning'}, create_entries({'Title': translation(30612), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_tvshows(target, phase, extra):
	debug_MS("(navigator.list_tvshows) ------------------------------------------------ START = list_tvshows -----------------------------------------------")
	debug_MS(f"(navigator.list_tvshows) ### TARGET = {target} ### CATEGORY = {phase} ### WANTED = {extra} ###")
	block_table = track_content(target, headers={**WEB_HEADER, **{'Referer': BASE_URL}})
	for each in block_table.get('pageProps', {}).get(phase, []):
		if each.get('letter') == extra:
			for item in sorted(each.get('items', []), key=lambda vsx: clear_umlaut(vsx.get('name', 'zorro')).lower()):
				if not item.get('name', ''): continue
				(fetch_items, context), (plot, genre, studio), operation = ({} for _ in range(2)), ("" for _ in range(3)), 'adding'
				media_idd, slug = item.get('id', None), item['slug']
				name = tvshow = cleaning(item['name'])
				if item.get('categories', {}) and isinstance(item['categories'], list) and item.get('categories', {})[0].get('name', ''):
					genre = cleaning(item['categories'][0]['name']).replace('/', ' / ').title()
				if item.get('stations', {}) and isinstance(item['stations'], list) and item.get('stations', {})[0].get('name', ''):
					station = item['stations'][0]['name']
					plot = translation(30621).format(genre, station)
					name = f"{name}  ({station.upper()})" if channel_folder else name
					if show_arte is False and station.upper() in ARTEEX: continue
					if show_joyn is False and station.upper() in JOYNEX: continue
					if show_rtlp is False and station.upper() in RTLPEX: continue
				link = f"/sendungen/{quote(slug)}.json"
				fetch_items = context = {'Cid': media_idd, 'Slug': slug, 'Extra': 'shows', 'Serie': tvshow, \
					'Title': name, 'Plot': plot, 'Genre': genre, 'Studio': station, 'Image': f"{alppic}{extra}.jpg"}
				if preserve(FAVORIT_FILE) is not None:
					for article in preserve(FAVORIT_FILE):
						if article.get('Cid') == media_idd: operation = 'skipping'
				add_views({'mode': 'list_broadcasts', 'link': link, 'phase': 'shows', 'origin': tvshow}, create_entries(fetch_items), True, context, operation)
				debug_MS(f"(navigator.list_tvshows[2]) ### NAME : {name} || CID : {media_idd} || SLUG : {slug} || GENRE : {genre} || STUDIO : {station} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_subtopics(target, phase):
	debug_MS("(navigator.list_subtopics) ------------------------------------------------ START = list_subtopics -----------------------------------------------")
	debug_MS(f"(navigator.list_subtopics) ### TARGET = {target} ### CATEGORY = {phase} ###")
	block_table = track_content(target, headers={**WEB_HEADER, **{'Referer': BASE_URL}})
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	debug_MS(f"(navigator.list_subtopics[1]) XXXXX CONTENT-01 : {block_table} XXXXX")
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	for item in block_table.get('pageProps', []):
		combo = [obj for obj in traversing.get_records()['mount'] if obj.get('short') == item]
		if combo and item[:5] not in phase and len(block_table.get('pageProps', {}).get(item, '')) > 0:
			name = combo[0]['name']
			image = f"{genpic}{item.lower()}.png" if xbmcvfs.exists(f"{genpic}{item.lower()}.png") else icon
			add_views({'mode': 'list_broadcasts', 'link': target, 'phase': item, 'origin': name}, create_entries({'Title': name, 'Image': image}))
			debug_MS(f"(navigator.list_subtopics[2]) ### NAME : {name} || SLUG : {item} || IMAGE : {image} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_alphabet():
	debug_MS("(navigator.list_alphabet) ------------------------------------------------ START = list_alphabet -----------------------------------------------")
	for letter in ['0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']:
		add_views({'mode': 'list_tvshows', 'link': '/a-z.json', 'phase': 'series', 'extra': letter}, create_entries({'Title': letter, 'Image': f"{alppic}{letter}.jpg"}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_sever(phase):
	debug_MS("(navigator.search_sever) ------------------------------------------------ START = search_sever -----------------------------------------------")
	# https://www.sendungverpasst.de/_next/data/cl7AR8ToJErdg4wnRFYGT/search.json?q=%22Rote+Rosen%22
	keyword = preserve(SEARCH_FILE, 'TEXT')
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30622), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword: return filtrate_search(f'/search.json?q={quote_plus(keyword)}', phase, keyword)
	return None

def filtrate_search(target, phase, origin):
	debug_MS("(navigator.filtrate_search) -------------------------------------------------- START = filtrate_search --------------------------------------------------")
	debug_MS(f"(navigator.filtrate_search) ### TARGET = {target} ### CATEGORY = {phase} ### EXTRA = {origin} ###")
	if not 'cat=' in target:
		add_views({'mode': 'selection_search', 'link': target, 'phase': 'categories', 'origin': origin}, create_entries({'Title': translation(30623)}))
	if not 'station=' in target:
		add_views({'mode': 'selection_search', 'link': target, 'phase': 'stations', 'origin': origin}, create_entries({'Title': translation(30624)}))
	if not 'date=' in target:
		add_views({'mode': 'selection_search', 'link': target, 'phase': 'dates', 'origin': origin}, create_entries({'Title': translation(30625)}))
	add_views({'mode': 'list_broadcasts', 'link': target+build_rider(target, 'sort=date'), 'phase': 'result', 'origin': origin}, create_entries({'Title': translation(30626)}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selection_search(target, phase, origin):
	debug_MS("(navigator.selection_search) ------------------------------------------------ START = selection_search -----------------------------------------------")
	debug_MS(f"(navigator.selection_search) ### TARGET = {target} ### CATEGORY = {phase} ### EXTRA = {origin} ###")
	block_table = track_content(target, headers={**WEB_HEADER, **{'Referer': BASE_URL}})
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	debug_MS(f"(navigator.selection_search[1]) XXXXX CONTENT-01 : {block_table} XXXXX")
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	if block_table is not None and block_table.get('pageProps', '') and block_table['pageProps'].get(phase, ''):
		elements = sorted(block_table['pageProps'].get(phase, []), key=lambda vsx: clear_umlaut(vsx.get('name', 'zorro')).lower()) if \
			phase in ['categories', 'stations'] else block_table['pageProps'].get(phase, [])
		for item in elements:
			if not item.get('name', ''): continue
			name, slug = cleaning(item['name']), str(item['key'])
			if phase == 'stations' and show_arte is False and name.upper() in ARTEEX: continue
			if phase == 'stations' and show_joyn is False and name.upper() in JOYNEX: continue
			if phase == 'stations' and show_rtlp is False and name.upper() in RTLPEX: continue
			counter = item.get('doc_count', None)
			if counter: name, title = f"{name}   [B][COLOR yellow]({counter})[/COLOR][/B]", f"{name}  [{counter}]"
			changes = phase.replace('categories', 'cat').replace('stations', 'station').replace('dates', 'date')
			add_views({'mode': 'filtrate_search', 'link': target+build_rider(target, f"{changes}={slug}"), 'phase': phase, 'origin': origin}, create_entries({'Title': name}))
			debug_MS(f"(navigator.selection_search[2]) ### NAME : {title} || SLUG : {slug} || CAT : {phase} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_broadcasts(target, page, limit, persist, phase, origin):
	debug_MS("(navigator.list_broadcasts) ------------------------------------------------ START = list_broadcasts -----------------------------------------------")
	debug_MS(f"(navigator.list_broadcasts) ### TARGET = {target} ### PAGE = {page} ### LIMIT = {limit} ### POSITION = {persist} ### PHASE = {phase} ### ORIGIN = {origin} ###")
	scrolling, counter, merging, block_table, (combo_partial, combo_links, combo_uno, combo_due, combo_send) = 1, 0, {}, None, ([] for _ in range(5))
	while scrolling > 0:
		block_table = track_content(target if scrolling == 1 else next_page, headers=WEB_HEADER)
		if block_table and block_table.get('pageProps', ''):
			if phase in block_table.get('pageProps', {}) or 'shows' in block_table.get('pageProps', {}):
				for key, value in block_table.get('pageProps', []).items():
					if (key in ['current', 'shows', 'show', 'moreShows'] or key == phase) and value is not None:
						elements = value if isinstance(value, list) else [value]
						for item in elements:
							persist = int(persist).__add__(1)
							combo_partial.append([persist, key, item])
			if not 'sendungen/' in target and str(block_table['pageProps'].get('total')).isdecimal() and int(block_table['pageProps']['total']) > int(page)*int(limit) and int(scrolling) < 4: # Maximum of total 4 Pages
				debug_MS("---------------------------------------------")
				scrolling, page = int(scrolling).__add__(1), int(page).__add__(1)
				next_ends = build_rider(target, f"page={page}") if int(page) < 6 else f"page={page}"
				next_page = target.split('page=')[0]+next_ends
				debug_MS(f"(navigator.list_broadcasts[1]) PAGES ### NOW GET NEXTPAGE : {next_page} ###")
			else: break
		else: break
	if combo_partial:
		combo_links, combo_uno = _fetch_verpasst(combo_partial)
		if combo_links: combo_due = [mex for mex in _fetch_pages(combo_links)]
		merging = [{**uno, **next(iter([due for due in combo_due if due.get('Slug_2') == uno.get('Slug_1')]), {})} for uno in combo_uno] # Merge List1 and List2 (dictionaries) by specific value if value exists else only List1 !!!
		parts = merging[:]
		analogy = [pax for pax in parts if pax.get('station') == parts[0].get('station')]
		attach_studio = True if len(analogy) != len(merging) else False
		if merging: # https://stackoverflow.com/questions/56658669/combine-two-lists-of-dictionaries-by-value-of-key-in-dictionaries
			merging = sorted(merging, key=lambda sox: clear_umlaut(sox.get('name', 'zorro')).lower()) if \
				phase in ['categories', 'stations'] else sorted(merging, key=lambda sox: int(sox.get('Count_1', 0)))
			for post in merging:
				debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
				debug_MS(f"(navigator.list_broadcasts[3]) ##### Anzahl = {len(post)} || Eintrag : {post} #####")
				(ordner, excluding), (more_collect, more_search) = (True for _ in range(2)), ('DEFAULT' for _ in range(2))
				(season, episode, starting, airing, dating, ending, genre), (note_1, note_2, note_3, note_4) = (None for _ in range(7)), ("" for _ in range(4))
				media_idd, slug = (post.get('id', None) or post.get('_id', None)), post.get('slug', None)
				chiave, persist = post.get('chiave', 'unknown'), int(post.get('Count_1', 1))
				station = post.get('station', None) if phase not in ['categories', 'stations'] else post.get('name', None)
				if station and show_arte is False and station.upper() in ARTEEX: continue
				if station and show_joyn is False and station.upper() in JOYNEX: continue
				if station and show_rtlp is False and station.upper() in RTLPEX: continue
				counter, lenght = int(counter).__add__(1), int(post['duration']) * 60 if str(post.get('duration')).isdecimal() else None
				playable = True if lenght or (slug and str(slug.split('-')[-1]).isdecimal()) else False
				name = extractor = cleaning(post['fullTitle']) if post.get('fullTitle', '') else cleaning(post['title']) if post.get('title', '') else \
					cleaning(post['name']) if post.get('name', '') else 'UNBEKANNT'
				if any(xu in target for xu in ['/trends.', '/top.']) or 'top20' in phase:
					name = translation(30627).format(counter, name)
				tvshow, original = cleaning(post.get('show', None)), cleaning(post['show']) if post.get('show') else origin
				if phase not in ['categories', 'stations'] and playable is True:
					more_collect = f"/content/{quote(slug)}.json" if not 'sendungen/' in target and slug and chiave not in ['show', 'moreShows', 'result'] else 'DEFAULT' # UNWANTED: show, moreShows, result
					more_search = f"/search.json?q=%22{quote_plus(tvshow)}%22" if tvshow and ('sendungen/' in target or chiave in ['show', 'moreShows']) and \
						(block_table.get('pageProps', {}).get('hasMore', '') is True or post.get('hasMore', '') is True) else 'DEFAULT' # WANTED: show, moreShows
					ordner, excluding = False, True if media_idd is None else False
				else: ordner, excluding = True, False
				if excluding is True or name == 'UNBEKANNT': continue
				matchSEAS = [''.join(sn) for sn in re.findall(r'Staffel:? ([0-9]+)|S([0-9]+)', extractor, re.S)]
				season = f"{int(matchSEAS[-1]):02}" if matchSEAS and int(matchSEAS[-1]) != 0 else None # Staffel 13, Folge 05 // Staffel: 6, Folge: 11 // (S01/E03) // (1/3) // Rote Rosen: (1094)
				matchEPIS = [''.join(eo) for eo in re.findall(r'Folge:? ([0-9]+)|Episode:? ([0-9]+)|E([0-9]+)|\(([0-9])+/[0-9]+\)|\(([0-9]+)\)', extractor, re.S)]
				episode = f"{int(matchEPIS[-1]):02}" if matchEPIS and int(matchEPIS[-1]) != 0 else None # Staffel 13, Folge 05 // Staffel: 6, Folge: 11 // (S01/E03) // (1/3) // Rote Rosen: (1094)
				image = f"{BASE_URL[:-1]}{post['logoWhite']}" if phase == 'stations' and post.get('logoWhite', '') else \
					f"{genpic}{slug.lower()}.png" if phase == 'categories' and xbmcvfs.exists(f"{genpic}{slug.lower()}.png") else icon
				if phase not in ['categories', 'stations']: image = DIGITAL_IMG.format(post['image']) if post.get('image', '') else None
				if str(list(post.values())[0]) == 'series' and image is None and slug:
					photo = DIGITAL_IMG.format(f"series/{clear_umlaut(slug)}.jpg")
				if post.get('datetime', '') and str(post.get('datetime')[:10].replace('.', '').replace('-', '').replace('/', '')).isdecimal():
					available = datetime(*(time.strptime(post['datetime'][:16], '%d.%m.%Y %H:%M')[0:6])) # 20.12.2023 20:15
					starting = available.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
					airing = available.strftime('%d.%m.%Y') # FirstAired
					dating = available.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else available.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
					if starting.startswith(('31.12.99', '01.01.00')): starting = airing = dating = None
				if post.get('expiryDate', '') and str(post.get('expiryDate')[:10].replace('.', '').replace('-', '').replace('/', '')).isdecimal():
					expiring = datetime(*(time.strptime(post['expiryDate'][:16], '%d.%m.%Y %H:%M')[0:6])) # 27.12.2023 00:00
					ending = expiring.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
					if ending.startswith(('31.12.99', '01.01.00')): ending = None
				if post.get('genre'): genre = cleaning(post['genre']).replace('/', ' / ').title()
				teaser, transfer = (cleaning(post.get('description', '') or '')), (post.get('link', None) or None)
				title = f"{name}  ({station.upper()})" if channel_linkes and station and attach_studio else name
				if ordner is False and transfer is None: continue # If this is no folder and direct-link is None, skip this entry
				if tvshow and int(post.get('clicks', 0)) > 0: note_1 = translation(30628).format(tvshow, post.get('clicks', 0))
				elif tvshow and int(post.get('clicks', 0)) < 1: note_1 = translation(30629).format(tvshow)
				if ordner is False: # Show these entries only if this is no folder
					if season and episode: note_2 = translation(30630).format(season, episode)
					elif season is None and episode: note_2 = translation(30631).format(episode)
					if starting and ending: note_3 = translation(30632).format(starting, ending)
					elif starting and ending is None: note_3 = translation(30633).format(starting)
					elif starting is None and ending is None and tvshow: note_3 = '[CR]'
				if phase not in ['categories', 'stations'] and station: note_4 = translation(30634).format(station) if teaser != "" else translation(30635).format(station)
				short_name, plot = re.sub(r'\[.*?\]', '', title), note_1+note_2+note_3+teaser+note_4
				debug_MS(f"(navigator.list_broadcasts[3]) ##### TITLE : {short_name} || SEASON : {season} || EPISODE : {episode} || AIRED : {airing} #####")
				debug_MS(f"(navigator.list_broadcasts[3]) ##### SLUG : {post.get('Slug_1')} || CID : {media_idd} || GENRE : {genre} || STUDIO : {station} #####")
				debug_MS(f"(navigator.list_broadcasts[3]) ##### is FOLDER : {ordner} || DURATION : {lenght} || THUMB : {image} #####")
				fetching = {'Slug': post.get('Slug_1'), 'Title': title, 'TvShowTitle': tvshow if extractor != tvshow else None, 'Tagline': post.get('subtitle'), \
					'Plot': plot, 'Season': season, 'Episode': episode, 'Date': dating, 'Aired': airing, 'Genre': genre, 'Studio': station, 'Image': image}
				if ordner is True:
					ACTION = {'mode': 'list_subtopics', 'link': f"/{quote(slug)}.json" if phase == 'stations' else f"/rubriken/{quote(slug)}.json", 'phase': phase}
					fetch_posts = create_entries(fetching)
				else:
					for method in get_sorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
					ACTION = {'mode': 'playCODE', 'IDENTiTY': media_idd}
					fetch_posts = create_entries({**fetching, **{'Duration': lenght, 'Mediatype': 'episode' if episode else 'movie', 'Reference': 'Single'}})
					if tvshow and more_collect != 'DEFAULT': # cyan, magenta, springgreen
						fetch_posts.addContextMenuItems([(translation(30655).format(tvshow), f"Container.Update({build_mass(HOST_AND_PATH, {'mode': 'list_broadcasts', 'link': API_COMP+more_collect, 'phase': 'show', 'origin': tvshow})})")])
					if tvshow and more_search != 'DEFAULT': # cyan, magenta, springgreen
						fetch_posts.addContextMenuItems([(translation(30656), f"Container.Update({build_mass(HOST_AND_PATH, {'mode': 'list_broadcasts', 'link': API_COMP+more_search, 'phase': 'result', 'origin': tvshow})})")])
					combo_send.append({'filtrate': media_idd, 'title': title, 'tvshow': tvshow, 'station': station, 'transfer': transfer})
				add_views(ACTION, fetch_posts, ordner, higher=True if int(page) > 1 else False)
			preserve(WORKS_FILE, 'JSON', combo_send)
			if not 'sendungen/' in target and block_table and block_table.get('pageProps', '') and str(block_table['pageProps'].get('total')).isdecimal() and int(block_table['pageProps']['total']) > int(page)*int(limit):
				debug_MS("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~")
				debug_MS(f"(navigator.list_broadcasts[3]) PAGES ### currentENTRIES : {int(page)*int(limit)} / from totalENTRIES : {block_table['pageProps']['total']} ###")
				suffix = build_rider(target, f"page={int(page)+1}") if int(page) < 6 else f"page={int(page)+1}"
				fetch_items = create_entries({'Title': translation(30636).format(int(page) // 4 + 1), 'Image': f"{artpic}nextpage.png"})
				add_views({'mode': 'list_broadcasts', 'link': target.split('page=')[0]+suffix, 'page': int(page)+1, 'limit': int(limit), 'persist': int(persist), 'phase': phase, 'origin': origin}, fetch_items)
	else:
		failing(f'(navigator.list_broadcasts) ##### NO BROADCAST-LIST - NO ENTRY FOR: "{origin}" FOUND #####')
		return dialog.notification(translation(30526), translation(30527).format(origin), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def _fetch_verpasst(media_table, primodo=[], secondo=[]):
	for persist, chiave, scraps in media_table:
		if scraps.get('_source', {}):
			scraps.update({key: value for key, value in scraps['_source'].items()}) # Kopiere _source-Ordner in 2. Ebene zu item
			scraps.pop('_source', None); scraps.pop('sort', None)
		if scraps.get('categories', {}) and isinstance(scraps['categories'], list) and scraps.get('categories', {})[0].get('name', ''):
			scraps['genre'] = scraps['categories'][0]['name'] # Kopiere _source-Ordner in 2. Ebene zu item
			scraps.pop('categories', None)
		if scraps.get('stations', {}) and isinstance(scraps['stations'], list) and scraps.get('stations', {})[0].get('name', ''):
			scraps['station'] = scraps['stations'][0]['name'] # Kopiere _source-Ordner in 2. Ebene zu item
			scraps.pop('stations', None)
		epis_idd = (scraps.get('id', None) or scraps.get('_id', None))
		transition = API_BASE+addon.getSetting('sever_staticCODE')+f"/content/{quote(scraps.get('slug'))}.json"
		if str(scraps.get('duration')).isdecimal() or (scraps.get('slug') and str(scraps.get('slug').split('-')[-1]).isdecimal()):
			if scraps.get('link') is None and epis_idd and scraps.get('slug'):
				primodo.append({'Count_1': int(persist), 'Slug_1': scraps.get('slug'), 'Link_1': transition})
		scraps = {**scraps, **{'Count_1': int(persist), 'Slug_1': scraps.get('slug'), 'Link_1': transition, 'chiave': chiave}}
		debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
		debug_MS(f"(navigator.fetch_primo[1]) XXX COUNT-01 : {persist} || SLUG-01 : {scraps.get('slug')} || EACH-01 : {scraps} XXX")
		secondo.append({key: value for key, value in scraps.items() if value not in ['', 'None', None]})
	return primodo, secondo

def _fetch_pages(templates):
	package = track_several(templates, 'GET', 'JSON', WEB_HEADER)
	if package:
		for settle in json.loads(package):
			if settle is not None and settle.get('pageProps', {}) and settle['pageProps'].get('show', {}):
				settle.update({key: value for key, value in settle['pageProps']['show'].items()})
				if settle.get('categories', {}) and isinstance(settle['categories'], list) and settle.get('categories', {})[0].get('name', ''):
					settle['genre'] = settle['categories'][0]['name']
					settle.pop('categories', None)
				if settle.get('stations', {}) and isinstance(settle['stations'], list) and settle.get('stations', {})[0].get('name', ''):
					settle['station'] = settle['stations'][0]['name']
					settle.pop('stations', None)
				if settle['pageProps'].get('hasMore', {}):
					settle['hasMore'] = settle['pageProps']['hasMore']
				settle.pop('pageProps', None) # Kopiere alle Ordner in 2. Ebene zu article und lösche diese danach
				embrace = {key: value for key, value in settle.items() if value not in ['', 'None', None]}
				debug_MS("---------------------------------------------")
				debug_MS(f"(navigator.fetch_pages[2]) ### COUNT-02 : {settle.get('Count_2', 0)} || SLUG-02 : {settle.get('Slug_2')} || ENTRY-02 : {embrace} ###")
				yield embrace

def playCODE(PLID):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### SENDUNGVERPASST_CID : {PLID} ###")
	FINAL_URL, title_clear, show, onward = (False for _ in range(4))
	for elem in preserve(WORKS_FILE):
		if elem['filtrate'] != '00' and elem['filtrate'] == PLID:
			title_clear = re.sub('\[.*?\]', '', elem['title']) if elem.get('title', '') else None
			show, studio, onward = elem['tvshow'], elem['station'], elem['transfer']
			debug_MS(f"(navigator.playCODE) ### WORKS_FILE-Line : {elem} ###")
	onward = onward.replace('http://', 'https://') if onward and onward[:7] == 'http://' else onward
	log("(navigator.playCODE) --- START WIEDERGABE ANFORDERUNG ---")
	log("(navigator.playCODE[1]) frei")
	log(f"(navigator.playCODE[1]) ~~~ AbspielLink-01 (Original) : {onward} ~~~")
	log("(navigator.playCODE[1]) frei")
	if onward and onward.startswith('https://www.ardmediathek.de'):
		return ard_contents(onward)
	elif onward and onward.startswith('https://www.arte.tv'):
		video_code = re.compile(r'arte.tv/de/videos/([^/]+)/', re.S).findall(onward)[0]
		FINAL_URL = f"plugin://plugin.video.artetv.de/?mode=playVideo&link={video_code}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'ARTE.TV', 'ARTE.TV - Plugin')
	elif onward and onward.startswith('https://www.dw.com'):
		return dew_contents(onward)
	elif onward and onward.startswith('https://www.joyn.de'):
		return joyn_contents(onward)
	elif onward and onward.startswith('https://www.kika.de'):
		return kika_contents(onward)
	elif onward and onward.startswith('https://plus.rtl.de'):
		squeeze = re.compile(r'''plus.rtl.de/([^/]+)/[A-Za-z0-9]+/([^/]+)''', re.S).findall(onward)
		if squeeze: # https://plus.rtl.de/berlin-tag-nacht-p_4172/video/klare-ansagen-c_1992330
			video_title = re.sub(fr'([0-9]+ •  |{show}:? )', '', title_clear) if title_clear and show and title_clear != show else None
			video_code = re.search(r'c_([0-9]+)', squeeze[0][1])
			FINAL_URL = f"plugin://plugin.video.rtlplus/?mode=play_vod&video_id=clip_{video_code.group(1)}{'&title='+quote_plus(video_title) if video_title else ''}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'RTLplus', 'RTL+ - Plugin')
	elif onward and onward.startswith(('https://www.3sat.de', 'https://zdf.de', 'https://www.zdf.de', 'https://www.zdfheute.de')):
		return zdf_contents(onward)
	else:
		failing(f"(navigator.playCODE[2]) AbspielLink-00 : Der Provider *{urlparse(onward).netloc}* konnte nicht aufgelöst werden !!!")
		dialog.notification(translation(30521).format('LINK'), translation(30528).format(urlparse(onward).netloc), icon, 10000)
		log("(navigator.playCODE[2]) --- ENDE WIEDERGABE ANFORDERUNG ---")

def list_favorites():
	debug_MS("(navigator.list_favorites) ------------------------------------------------ START = list_favorites -----------------------------------------------")
	if preserve(FAVORIT_FILE) is not None:
		for each in sorted(preserve(FAVORIT_FILE), key=lambda vsx: clear_umlaut(vsx.get('Serie', 'zorro')).lower()):
			ACTION = {'mode': 'list_broadcasts', 'link': f"/sendungen/{quote(each.get('Slug'))}.json", 'phase': each.get('Extra'), 'origin': each.get('Serie')}
			fetch_items = context = {'Cid': each.get('Cid'), 'Slug': each.get('Slug'), 'Extra': each.get('Extra'), 'Serie': each.get('Serie'), \
				'Title': each.get('Serie'), 'Plot': each.get('Plot'), 'Genre': each.get('Genre'), 'Studio': each.get('Studio'), 'Image': each.get('Image')}
			debug_MS(f"(navigator.list_favorites[1]) ##### NAME : {each.get('Title')} || CID : {each.get('Cid')} || SLUG : {each.get('Slug')} || THUMB : {each.get('Image')} #####")
			add_views(ACTION, create_entries(fetch_items), True, context, 'removing')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favorit_construct(**kwargs):
	TOPS = []
	if preserve(FAVORIT_FILE) is not None:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		kwargs.pop('mode', None); kwargs.pop('action', None)
		TOPS.append({key: value for key, value in kwargs.items() if value not in ['', 'None', None]})
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30533), translation(30534).format(kwargs['Serie']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Cid') != kwargs.get('Cid')]
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30533), translation(30535).format(kwargs['Serie']), icon, 10000)

def add_views(params, listitem, folder=True, context={}, handling='default', higher=False):
	uws, entries = build_mass(HOST_AND_PATH, params), []
	listitem.setPath(uws)
	if enable_decrease and higher is True:
		entries.append([translation(30651), f"RunPlugin({build_mass(HOST_AND_PATH, {'mode': 'calling_main'})})"])
	if handling == 'adding' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass(HOST_AND_PATH, {**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30653), f"RunPlugin({build_mass(HOST_AND_PATH, {**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
