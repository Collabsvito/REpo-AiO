﻿# -*- coding: utf-8 -*-

from .common import *


def ArdGetVideo(videoURL):
	debug_MS("(resolver.ArdGetVideo) ------------------------------------------------ START = ArdGetVideo -----------------------------------------------")
	MEDIAS = []
	player_PAGE, STREAM, FINAL_URL = (False for _ in range(3))
	All_QUALITIES = ['auto', 5, 4, 3, 2, 1, 0]
	docuID = re.compile('ardmediathek.de/video/([A-Za-z0-9_]+)', re.S).findall(videoURL)# https://www.ardmediathek.de/video/Y3JpZDovL2Rhc2Vyc3RlLmRlL3RhdG9ydC9kYzYwZGU0Zi0zYzRlLTRiNjQtOTgxYi02ZWIwYjYzY2MyOTA
	if docuID:# https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL2Rhc2Vyc3RlLmRlL3RhdG9ydC9kYzYwZGU0Zi0zYzRlLTRiNjQtOTgxYi02ZWIwYjYzY2MyOTA?devicetype=pc&embedded=false
		player_PAGE = '{}ard/item/{}?devicetype=pc&embedded=false'.format(API_ARD, docuID[0])
	else:
		content_one = getUrl(videoURL, method='LOAD')
		docuLINK = re.compile(r'<script id="fetchedContextValue" type="application/json">.+?"href":"(https?://.*?/item/.*?)".+?</script>', re.S).findall(content_one)
		player_PAGE = docuLINK[0] if docuLINK else False
	debug_MS("(resolver.ArdGetVideo[1]) ##### videoPAGE : {} #####".format(str(player_PAGE)))
	if player_PAGE:
		content_two = getUrl(player_PAGE, method='TRACK')
		if content_two.status_code == 200:
			DATA_VIDEO = content_two.json()
			debug_MS("++++++++++++++++++++++++")
			debug_MS("(resolver.ArdGetVideo[2]) XXXXX CONTENT : {} XXXXX".format(str(DATA_VIDEO)))
			debug_MS("++++++++++++++++++++++++")
			if DATA_VIDEO is not None and DATA_VIDEO.get('widgets', '') and len(DATA_VIDEO['widgets']) > 0:
				for elem in DATA_VIDEO.get('widgets', []):
					if elem.get('type', '') == 'player_ondemand' and elem.get('mediaCollection', ''):
						SHORT = elem['mediaCollection']['embedded']['_mediaArray'][1] if len(elem['mediaCollection']['embedded']['_mediaArray']) > 1 else elem['mediaCollection']['embedded']['_mediaArray'][0]
						for found in All_QUALITIES:
							for quality in SHORT.get('_mediaStreamArray', []):
								if quality['_quality'] == found and '_stream' in quality and quality['_stream']:
									if (enableINPUTSTREAM or prefSTREAM == '0') and quality['_quality'] == 'auto' and 'm3u8' in quality['_stream']:
										STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
										FINAL_URL = 'https:'+quality['_stream'] if quality['_stream'][:4] != 'http' else quality['_stream']
										log("(resolver.ArdGetVideo) Auswahl vom *m3u8-Stream* (ARD+3) : {}".format(FINAL_URL))
									if quality['_quality'] != 'auto' and '.mp4' in quality['_stream']:
										MEDIAS.append({'url': quality['_stream'], 'quality': quality['_quality'], 'mimeType': 'mp4', 'height': (quality.get('_height', 'Unknown') or 'Unknown')})
					elif elem.get('blockedByFsk', '') is True:
						log("(resolver.ArdGetVideo[3]) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Alterbeschränkungen geblockt !!!")
						return dialog.notification(translation(30529), translation(30530), icon, 8000)
					elif elem.get('geoblocked', '') is True:
						log("(resolver.ArdGetVideo[3]) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Geo-Sperren geblockt !!!")
						return dialog.notification(translation(30529), translation(30531), icon, 8000)
	if not FINAL_URL and MEDIAS:
		ARD_Url = 'https:'+MEDIAS[0]['url'] if MEDIAS[0]['url'][:4] != 'http' else MEDIAS[0]['url']
		debug_MS("(resolver.ArdGetVideo[4]) SORTED_LIST | MP4 ### MEDIAS : {} ###".format(str(MEDIAS)))
		log("(resolver.ArdGetVideo[5]) Auswahl vom *mp4-Stream* (ARD+3) : {}".format(ARD_Url))
		STREAM, FINAL_URL = 'MP4', VideoBEST(ARD_Url, improve='DasErste') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	return playRESOLVED(FINAL_URL, STREAM, 'ARD+3', 'ARD - Intern')

def DwGetVideo(videoURL):
	debug_MS("(resolver.DwGetVideo) ------------------------------------------------ START = DwGetVideo -----------------------------------------------")
	FINAL_URL, STREAM = (False for _ in range(2))
	req_FIRST = getUrl(videoURL, method='LOAD')
	docuID = re.compile(r'<source src="([^"]+)" type="(?:video/mp4|application/x-mpegURL|audio/mpeg)"', re.S).findall(req_FIRST) # https://radiodownloaddw-a.akamaihd.net/Events/dwelle/dira/mp3/deu/FEE8E841_2.mp3
	FINAL_URL = docuID[0] if docuID else False # https://api.dw.com/api/detail/video/65556146 // Anforderung geht auch
	if FINAL_URL:
		STREAM ='HLS' if enableINPUTSTREAM and 'm3u8' in FINAL_URL else 'M3U8' if not enableINPUTSTREAM and 'm3u8' in FINAL_URL else 'MP3' if 'mp3' in FINAL_URL else 'UNKNOWN'
	return playRESOLVED(FINAL_URL, STREAM, 'DeutscheWelle', 'DW - Intern')

def KikaGetVideo(videoURL):
	debug_MS("(resolver.KikaGetVideo) ------------------------------------------------ START = KikaGetVideo -----------------------------------------------")
	All_QUALITIES = [5, 4, 3, 2, 1, 0, 'hd', 'veryhigh', 'high', 'med', 'low', 3840, 2560, 1920, 1280, 1024, 960, 852, 720, 640, 512, 480, 320]
	video_id, M3U8_Url, FINAL_URL, STREAM = (False for _ in range(4))
	MEDIAS, bestMEDIA = ([] for _ in range(2))
	content_one = getUrl(videoURL, method='LOAD')
	target_KIKA = re.compile(r'</div></div></div><script id="__NEXT_DATA__" type="application/json">(?P<json>{.+?})</script></body></html>', re.S).findall(content_one)
	if target_KIKA:
		DATA_ONE = json.loads(target_KIKA[0])
		if DATA_ONE is not None and DATA_ONE.get('props', '') and DATA_ONE['props'].get('pageProps', '') and DATA_ONE['props']['pageProps'].get('docResponse', ''):
			if DATA_ONE['props']['pageProps']['docResponse'].get('videos', '') and len(DATA_ONE['props']['pageProps']['docResponse']['videos']) > 0:
				video_id = DATA_ONE['props']['pageProps']['docResponse']['videos'][0]['api']['id']
			elif DATA_ONE['props']['pageProps']['docResponse'].get('featuredVideo', '') and len(DATA_ONE['props']['pageProps']['docResponse']['featuredVideo']) > 0:
				video_id = DATA_ONE['props']['pageProps']['docResponse']['featuredVideo']['api']['id']
			debug_MS("(resolver.KikaGetVideo[1]) EXTRACTED ##### videoFOUND : {} #####".format(str(video_id)))
			DATA_TWO = getUrl('https://www.kika.de/_next-api/proxy/v1/videos/{}/assets'.format(video_id))
			for entry in DATA_TWO.get('assets', []):
				AUTO = (entry.get('quality', '') or entry.get('type', '') or 'Unknown')
				if AUTO == 'auto' and 'm3u8' in entry.get('url'):
					M3U8_Url = entry['url']
				MP4 = (entry.get('url', None) or None)
				TYPE = (entry.get('delivery', '') or entry.get('type', '') or 'Unknown')
				QUAL = (entry.get('width', None) or entry.get('frameWidth', None) or None)
				if MP4 and QUAL:
					MEDIAS.append({'url': MP4, 'delivery': TYPE, 'quality': QUAL, 'document': 'API_WEB'})
	if MEDIAS:
		debug_MS("(resolver.KikaGetVideo[1]) ORIGINAL_MP4 ### unsorted_LIST : {0} ###".format(str(MEDIAS)))
		order_dict = {qual: index for index, qual in enumerate(All_QUALITIES)}
		bestMEDIA = sorted(MEDIAS, key=lambda x: order_dict.get(x['quality'], float('inf')))
		debug_MS("(resolver.KikaGetVideo[1]) SORTED_MP4 ###### sorted_LIST : {0} ###".format(str(bestMEDIA)))
	if (enableINPUTSTREAM or prefSTREAM == '0') and M3U8_Url:
		debug_MS("(resolver.KikaGetVideo[2]) ~~~~~ TRY NUMBER ONE TO GET THE FINALURL (m3u8) ~~~~~")
		STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
		FINAL_URL = M3U8_Url
	if not FINAL_URL and bestMEDIA:
		debug_MS("(resolver.KikaGetVideo[2]) ~~~~~ TRY NUMBER TWO TO GET THE FINALURL (mp4) ~~~~~")
		MP4_Url = bestMEDIA[0]['url'] if bestMEDIA[0]['url'].startswith('http') else 'https:'+bestMEDIA[0]['url']
		STREAM, FINAL_URL = 'MP4', VideoBEST(MP4_Url) # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	return playRESOLVED(FINAL_URL, STREAM, 'KiKA', 'KiKA - Intern')

def SevenGetVideo(videoURL):
	debug_MS("(resolver.SevenGetVideo) ------------------------------------------------ START = SevenGetVideo -----------------------------------------------")
	# ORIGINAL = https://video.sat1.de/serien/110-notruf-autobahn/videos/staffel-1-episode-1-achtung-notruf-unterwegs-auf-gefaehrlichem-pflaster
	MIME, video_web, video_id, STREAM, FINAL_URL, WALU = '', False, False, False, False, False
	sweep = urlparse(videoURL)
	domain = sweep.netloc.split('.', 1)[1]
	content_one = getUrl(videoURL, method='LOAD')
	if videoURL.startswith(('https://video.kabeleins.de/', 'https://video.prosieben.de', 'https://video.sat1.de', 'https://video.sixx.de/')):
		route_one = re.compile('"ROOT_QUERY":.*?"videoBySlug\\({"slug":"([^"]+)"}\\).*?"__ref": "Video:([^"]+)"', re.S).findall(content_one.replace('\\', ''))
		debug_MS("(resolver.SevenGetVideo[1]) xxxxx SEGMENT_ONE : {} xxxxx".format(str(route_one)))
		video_web = True if route_one and route_one[0][0] == sweep.path else False
		video_id = route_one[0][1] if video_web else False
		ACCESS_ID = 'x_supernovatvc-de'
		ENCRYPTION_KEY = 'Ahsh3soxiemusijophoophiodeevujup'
	else:
		route_two = re.compile(r'</div></div></div></div><script id="state" type="text/plain">(?P<json>.+?)</script><div id="fb-root"></div><div id="p7s1-ds-portal">', re.S).findall(content_one)
		if route_two:
			debug_MS("(resolver.SevenGetVideo[2]) xxxxx SEGMENT_TWO : {} xxxxx".format(str(route_two[0])))
			DATA = json.loads(route_two[0])
			short_PATH = '/video/'+sweep.path.split('/video/', 1)[1] if '/video/' in sweep.path else sweep.path
			if DATA.get('views', '') and DATA['views'].get('default', '') and DATA['views']['default'].get('page', ''):
				video_web = True if DATA['views']['default']['page'].get('route', '') in [sweep.path, short_PATH] else False
				if DATA['views']['default']['page'].get('contentResource', '') and DATA['views']['default']['page'].get('contentResource', [])[0].get('id', ''):
					video_id = DATA['views']['default']['page']['contentResource'][0]['id']
			ACCESS_ID = 'x_kabeleinsdoku-de' if domain == 'kabeleinsdoku.de' else 'x_prosiebenmaxx-de' if domain == 'prosiebenmaxx.de' else 'x_sat1gold-de'
			ENCRYPTION_KEY = 'eiM1ahfohreebifahjuwitaisooxeiwi' if domain == 'kabeleinsdoku.de' else 'Eeyeey9oquahthainoofashoyoikosag' if domain == 'prosiebenmaxx.de' else 'beiyaiTaluving7aeraephakoyuyafoh'
	debug_MS("(resolver.SevenGetVideo[3]) ### videoWEB : {} || videoID : {} || netloc : {} ###".format(str(video_web), str(video_id), str(sweep.netloc)))
	if video_web and not video_id:
		log("(resolver.SevenGetVideo[4]) AbspielLink-00 ({}) : *ProSiebenSat.1 - Intern* Der angeforderte -VideoLink- wurde auf Grund der Account-Voraussetzung geblockt !!!".format(domain))
		dialog.notification(translation(30529), translation(30532), icon, 8000)
		log("(resolver.SevenGetVideo[4]) --- ENDE WIEDERGABE ANFORDERUNG ---")
	else:
		#urls mit '//video.' = {access_id: 'x_supernovatvc-de', encryption_key: 'Ahsh3soxiemusijophoophiodeevujup', initializing_vector: 'Seeth6rohquuuthaiquiumepaphohrer'}
		#kabeleinsdoku      = {access_id: 'x_kabeleinsdoku-de', encryption_key: 'eiM1ahfohreebifahjuwitaisooxeiwi', initializing_vector: 'Edaicohcehielai9oophaingiethooqu'}
		#prosiebenmaxx     = {access_id: 'x_prosiebenmaxx-de', encryption_key: 'Eeyeey9oquahthainoofashoyoikosag', initializing_vector: 'Aeluchoc6aevechuipiexeeboowedaok'}
		#sat1gold                = {access_id: 'x_sat1gold-de', encryption_key: 'beiyaiTaluving7aeraephakoyuyafoh', initializing_vector: 'Go2taethohmioluupaithiengoopaifo'}
		#voice-of-germany = {access_id: 'x_the_voice_of_germany-de', encryption_key: 'Ahphiesh9aenahghahlaethohchaghae', initializing_vector: 'Teeth1eegaengeigeenethohcooshale'}
		#{"content_ids": {"v_18towp3uw2ir": {}}, "secure_delivery": true, "miratoken": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImEzZDEzMjdiZTA0Y2I2ODAwNGFjOTY2ZWQ4ZDRiNjI3In0.eyJzaWQiOiI4NWIxZjgxODVlZDIyMjNkMzEwOTcyNDNiNGFkZGEzNiIsInNlZyI6WyJBNCIsIkczIl0sImZuIjoia3VydCIsIm5uIjpudWxsLCJlbWFpbCI6ImhhcHBlbmluZzAwN0B5YWhvby5kZSIsImciOiJkaXZlcnNlIiwiYmQiOiIxOTg1LTA4LTI2IiwicGlkIjoic2F0MS1kZSIsImVudCI6W10sInlwIjp7fSwiaWF0IjoxNjgzODY1OTY2LCJleHAiOjE2ODM4ODc1NjYsImF1ZCI6ImU1MWIxZDQ5N2M3YjdjOTZiNTUwOTliMGU5NzM2ZmU0IiwiaXNzIjoiaHR0cHM6Ly9taXJhLnNhdDEuZGUiLCJzdWIiOiI2MTcyODk5ZjM4MmMyMGQ5NzMzN2JkNTkifQ.ehWDKngS4NQMfMzVpvIOGdXQ1HRSmzMD6886KLPumcGDbGL3j-ZTxTKD7UJQzaPxvdwrWu46t8erCYjBdI9YqHc2ejwkLmmnWQD0FqA9ctlJMbE5HT4EUgDVGIg6E2Eh0F5q9XMT5O8laNQGm3N39QZgQCdcEH3qRG4NhL1vgAq1Q4p7qZXWbArD3BXtsxM4uCImjWij1-kl4QmDGA8K75o7oVi3vCmiOcx5oevTc79fd-M2oH6spwbJEmPKkGCdqFFbAF5iv8AtIV8AIb2cH5ooe-fcDtKN6Z0wmz9Gdmy4MoXY_ET1reGQN1va4cYVPuz6qCt1SLnpj3p1OqqYGg", "iat": 1683866663, "nbf": 1683866363, "exp": 1683866963}
		actual = datetime.now()
		rewind = actual - timedelta(minutes=5)
		expire = actual + timedelta(minutes=5)
		payload = {'content_ids': {'{}'.format(video_id): {}}, 'secure_delivery': True, 'iat': int(actual.timestamp()), 'nbf': int(rewind.timestamp()), 'exp': int(expire.timestamp())}
		jwt_token = jwt_enc_hs256(ACCESS_ID, payload, ENCRYPTION_KEY)
		time.sleep(2)
		if video_web and video_id:
			content_two = getUrl(API_SEVEN.format(py3_dec(jwt_token)), method='TRACK', REF=videoURL.split('.de/')[0]+'.de/', AUTH=py3_dec(jwt_token))
			if content_two.status_code == 200:
				DATA_TWO = content_two.json()
				debug_MS("++++++++++++++++++++++++")
				debug_MS("(resolver.SevenGetVideo[4]) XXXXX CONTENT : {} XXXXX".format(str(DATA_TWO)))
				debug_MS("++++++++++++++++++++++++")
				if DATA_TWO is not None and DATA_TWO.get('data', '') and DATA_TWO['data'].get(video_id, '') and DATA_TWO['data'][video_id].get('urls', '') and len(DATA_TWO['data'][video_id]['urls']) > 0:
					SHORT = DATA_TWO['data'][video_id]
					WILIZ = SHORT['urls']['dash']['widevine']['drm']['licenseAcquisitionUrl'] if SHORT.get('urls', '') and SHORT['urls'].get('dash', '') and SHORT['urls']['dash'].get('widevine', '') \
						and SHORT['urls']['dash']['widevine'].get('drm', '') and SHORT['urls']['dash']['widevine']['drm'].get('licenseAcquisitionUrl', '') else None
					if SHORT.get('is_protected', '') is True and WILIZ:
						STREAM, MIME, FINAL_URL, drm_TOKEN = 'MPD', 'application/dash+xml', SHORT['urls']['dash']['widevine']['url'], SHORT['urls']['dash']['widevine']['drm']['token']
						WALU = '{}?token={}|User-Agent={}&Content-Type={}|{}|'.format(WILIZ, drm_TOKEN, get_userAgent(), MIME, 'R{SSM}')
						debug_MS("(resolver.SevenGetVideo[5]) ***** TAKE - Inputstream (mpd) - FILE (Joyn.de) *****")
					if not FINAL_URL and SHORT.get('is_protected', '') is False and not WALU:
						STREAM, MIME, FINAL_URL = 'HLS', 'application/vnd.apple.mpegurl', SHORT['urls']['hls']['clear']['url']
						debug_MS("(resolver.SevenGetVideo[5]) ***** TAKE - {} - FILE (Joyn.de) *****".format('Inputstream (hls)' if STREAM == 'HLS' else 'Standard (m3u8)'))
				#if FINAL_URL and STREAM: dialog.notification('[COLOR lime]Video erfolgreich extrahiert:[/COLOR]', '[COLOR magenta]VIDEO: [/COLOR][B]'+str(video_id)+'[/B] // [COLOR magenta]TYPE: [/COLOR][B]'+str(STREAM)+'[/B]', icon, 8000)
		return playRESOLVED(FINAL_URL, STREAM, domain, 'ProSiebenSat.1 - Intern', MIME, WALU)

def RtlGetVideo(videoURL):
	debug_MS("(resolver.RtlGetVideo) ------------------------------------------------ START = RtlGetVideo -----------------------------------------------")
	FINAL_URL = False # https://bff.apigw.tvnow.de/player/%d" % int(streamID)
	content_one = getUrl(videoURL, method='LOAD').replace('&q;', '"')
	video_id = re.compile(',"moduleUrl":"/player/([0-9_]+)","type":"player"', re.S).findall(content_one) # https://bff.apigw.tvnow.de/player/5230201 // ,"moduleUrl":"/player/5230201","type":"player"
	premium = re.compile(',"statusCode":[0-9]+,"isPremium":([^,]+),"loggedIn"', re.S).findall(content_one) # ,"statusCode":3,"isPremium":false,"loggedIn"
	PayType = premium[0] if premium else 'true'
	if video_id:
		log("(resolver.RtlGetVideo[1]) --- RTL-Daten : ### Request = https://bff.apigw.tvnow.de/player/{0} ### Episode = {0} ### Premium = {1} ### ---".format(video_id[0], str(PayType)))
		FINAL_URL = '{0}?{1}'.format('plugin://plugin.video.rtlgroup.de/', urlencode({'mode': 'playDash', 'xcode': video_id[0]}))
	return playRESOLVED(FINAL_URL, 'TRANSMIT', 'RTLPLUS - V.3', 'RTLPLUS - V.3 - Plugin')

def ZdfGetVideo(videoURL):
	debug_MS("(resolver.ZdfGetVideo) ------------------------------------------------ START = ZdfGetVideo -----------------------------------------------")
	episID, DATA_ONE, teaser, videoFOUND = (False for _ in range(4))
	if videoURL.startswith('https://www.phoenix.de'):
		docuID = re.compile('-a-([0-9]+).', re.S).findall(videoURL)# https://www.phoenix.de/sendungen/dokumentationen/amerikas-legendaere-strassen-55-a-793934.html
		target_PHOE = 'https://www.phoenix.de/response/id/{}/refid/suche'.format(docuID[0]) if docuID else False# https://www.phoenix.de/response/id/793934/refid/suche
		debug_MS("(resolver.ZdfGetVideo[1]) ##### target_PHOE : {} #####".format(str(target_PHOE)))
		if target_PHOE:
			firstURL = getUrl(target_PHOE)
			for elem in firstURL.get('absaetze', []):
				if str(elem.get('content'))[:4].isdigit():
					episID = str(elem.get('content'))# https://www.phoenix.de/php/mediaplayer/data/beitrags_details.php?id=2403864&profile=player2
					debug_MS("(resolver.ZdfGetVideo[2]) ##### TEASER : https://www.phoenix.de/php/mediaplayer/data/beitrags_details.php?id={}&profile=player2 #####".format(episID))
					break
			if episID: DATA_ONE = getUrl('https://www.phoenix.de/php/mediaplayer/data/beitrags_details.php?id={}&profile=player2'.format(episID))
	else:
		content_one = getUrl(videoURL, method='LOAD')
		target_ZDF = re.compile(r'(?s)data-zdfplayer-jsb=["\'](?P<json>{.+?})["\']', re.S).findall(content_one)
		if target_ZDF:
			debug_MS("(resolver.ZdfGetVideo[3]) ##### targetLINKS : {} #####".format(str(target_ZDF[0])))
			firstURL = json.loads(target_ZDF[0])
			teaser = firstURL['content']
			secret = firstURL['apiToken']
			log("(resolver.ZdfGetVideo[4]) SECRET gefunden (ZDF+3) : ***** {} *****".format(str(secret)))
			teaser = API_ZDF+teaser if teaser[:4] != 'http' else teaser
			debug_MS("(resolver.ZdfGetVideo[5]) ##### TEASER : {} #####".format(teaser))
			DATA_ONE = getUrl(teaser, WAY='Api-Auth', AUTH='Bearer '+secret)
	if DATA_ONE and (DATA_ONE.get('profile') == 'http://zdf.de/rels/not-found' or not ('contentType' in DATA_ONE)):
		videoFOUND = False
	else:
		if DATA_ONE and DATA_ONE.get('contentType') in ['clip', 'episode']:
			START_URL = 'https://api.3sat.de' if teaser and teaser.startswith('https://api.3sat.de') else 'https://api.zdf.de' if teaser and teaser.startswith('https://api.zdf.de') else ""
			videoFOUND = START_URL+DATA_ONE['mainVideoContent']['http://zdf.de/rels/target']['http://zdf.de/rels/streams/ptmd-template'].replace('{playerId}', 'ngplayer_2_4').replace('\/', '/')
			debug_MS("(resolver.ZdfGetVideo[6]) ##### videoFOUND : {} #####".format(videoFOUND))
			step_THIRD = ZdfExtractQuality(videoFOUND, 'Api-Auth', 'Bearer '+secret) if START_URL != "" else ZdfExtractQuality(videoFOUND, None, None)
			return step_THIRD
	if not target_ZDF or not videoFOUND:
		failing("(resolver.ZdfGetVideo[7]) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
		log("(resolver.ZdfGetVideo[7]) --- ENDE WIEDERGABE ANFORDERUNG ---")
		dialog.notification(translation(30521).format('ZDF -', 'Intern'), translation(30528), icon, 8000)

def ZdfExtractQuality(content_three, PREFIX, TOKEN):
	debug_MS("(resolver.ZdfExtractQuality) ------------------------------------------------ START = ZdfExtractQuality -----------------------------------------------")
	DATA_TWO = getUrl(content_three) if TOKEN is None else getUrl(content_three, WAY=PREFIX, AUTH=TOKEN)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(resolver.ZdfExtractQuality[1]) XXXXX CONTENT : {} XXXXX".format(str(DATA_TWO)))
	debug_MS("++++++++++++++++++++++++")
	MEDIAS = []
	STREAM, FINAL_URL = (False for _ in range(2))
	m3u8_QUALITIES = ['auto', 'veryhigh', 'high', 'med']
	mp4_QUALITIES = ['fhd', 'hd', 'veryhigh', 'high', 'low']
	if DATA_TWO is not None:
		for each in DATA_TWO.get('priorityList', []):
			formitaeten = each.get('formitaeten')
			if not isinstance(formitaeten, list):
				continue
			for item in formitaeten:
				if (enableINPUTSTREAM or prefSTREAM == '0') and item.get('type') == 'h264_aac_ts_http_m3u8_http' and item.get('mimeType').lower() == 'application/x-mpegurl':
					for found in m3u8_QUALITIES:
						for quality in item.get('qualities', []):
							if quality['quality'] == found and 'mil/master.m3u8' in quality['audio']['tracks'][0]['uri']:
								MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': item.get('mimeType').lower(), 'language': quality['audio']['tracks'][0]['language']})
					debug_MS("(resolver.ZdfExtractQuality[2]) SORTED_LIST | M3U8 ### MEDIAS : {} ###".format(str(MEDIAS)))
					log("(resolver.ZdfExtractQuality[3]) Auswahl vom *m3u8-Stream* (ZDF+3) : {}".format(MEDIAS[0]['url']))
					STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
					FINAL_URL = MEDIAS[0]['url']
				if not FINAL_URL and item.get('type') == 'h264_aac_mp4_http_na_na' and 'progressive' in item.get('facets', []) and item.get('mimeType').lower() == 'video/mp4':
					for found in mp4_QUALITIES:
						for quality in item.get('qualities', []):
							if quality['quality'] == found:
								MEDIAS.append({'url': quality['audio']['tracks'][0]['uri'], 'quality': quality['quality'], 'mimeType': item.get('mimeType').lower(), 'language': quality['audio']['tracks'][0]['language']})
					debug_MS("(resolver.ZdfExtractQuality[4]) SORTED_LIST | MP4 ### MEDIAS : {} ###".format(str(MEDIAS)))
					log("(resolver.ZdfExtractQuality[5]) Auswahl vom *mp4-Stream* (ZDF+3) : {}".format(MEDIAS[0]['url']))
					STREAM, FINAL_URL = 'MP4', VideoBEST(MEDIAS[0]['url'], improve='DasZweite') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	return playRESOLVED(FINAL_URL, STREAM, 'ZDF+3', 'ZDF - Intern')

def VideoBEST(highest, improve=False):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen // aktualisiert am 28.03.2023
	standards = [highest, '', '', ''] # Seite zur Überprüfung : https://github.com/mediathekview/MServer/blob/master/src/main/java/mServer/crawler/sender/zdf/ZdfVideoUrlOptimizer.java
	if improve == 'DasErste':
		route_one = (('/960', '/1280'), ('.hq.mp4', '.hd.mp4'), ('.l.mp4', '.xl.mp4'), ('_C.mp4', '_X.mp4'))
		route_two = (('/1280', '/1920'), ('.xl.mp4', '.xxl.mp4'))
		route_tree = (('/1920', '/3840'), ('.xl.mp4', '.xxl.mp4'))
	elif improve == 'DasZweite':
		route_one = (('808k_p11v15', '2360k_p35v15'), ('1456k_p13v11', '2328k_p35v11'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'), ('1628k_p13v15', '2360k_p35v15'),
								('1628k_p13v17', '2360k_p35v17'), ('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
		route_two = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'), ('2360k_p35v17', '3360k_p36v17'))
		route_tree = (('3360k_p36v15', '4692k_p72v16'), ('3360k_p36v17', '6660k_p37v17'))
	standards[1] = reduce(lambda m, kv: m.replace(*kv), route_one, standards[0])
	standards[2] = reduce(lambda n, kv: n.replace(*kv), route_two, standards[1])
	standards[3] = reduce(lambda o, kv: o.replace(*kv), route_tree, standards[2])
	if standards[0] not in [standards[1], standards[2], standards[3]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def playRESOLVED(END_URL, VERS, MARKING, NOTE, MIME='application/vnd.apple.mpegurl', LICE=None):
	if END_URL and VERS:
		LSM = xbmcgui.ListItem(path=END_URL)
		if ADDON_operate('inputstream.adaptive') and VERS in ['HLS', 'MPD']:
			LSM.setMimeType(MIME)
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			LSM.setProperty('inputstream.adaptive.manifest_type', VERS.lower())
			if KODI_ov20:
				LSM.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent={}'.format(get_userAgent()))
			else:
				LSM.setProperty('inputstream.adaptive.stream_headers', 'User-Agent={}'.format(get_userAgent()))
			if LICE:
				LSM.setProperty('inputstream.adaptive.license_key', LICE)
				debug_MS("(resolver.playRESOLVED) LICENSE : {}".format(str(LICE)))
				LSM.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log("(resolver.playRESOLVED) END-AbspielLink ({}) : {}_stream : {}".format(MARKING, VERS, END_URL))
	else:
		failing("(resolver.playRESOLVED) AbspielLink-00 ({}) : *{}* Der angeforderte -VideoLink- existiert NICHT !!!".format(MARKING, NOTE))
		dialog.notification(translation(30521).format(NOTE, ''), translation(30528), icon, 8000)
	log("(resolver.playRESOLVED) --- ENDE WIEDERGABE ANFORDERUNG ---")
