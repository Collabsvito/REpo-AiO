﻿# -*- coding: utf-8 -*-

from .common import *
from .resolver import *


def mainMenu():
	for TITLE, IMG, PATH in [(30601, 'favourites', {'mode': 'listFavorites'}), (30602, 'beliebteste', {'mode': 'listBroadcasts', 'url': '/top.json', 'extras': 'shows'}),
		(30603, 'trends', {'mode': 'listBroadcasts', 'url': '/trends.json', 'extras': 'shows'}), (30604, 'highlights', {'mode': 'listBroadcasts', 'url': '/index.json', 'extras': 'highlights'}),
		(30605, 'stations', {'mode': 'listTopics', 'url': '/index.json', 'extras': 'stations'}), (30606, 'categories', {'mode': 'listTopics', 'url': '/index.json', 'extras': 'categories'}),
		(30607, 'justfound', {'mode': 'listBroadcasts', 'url': '/index.json', 'extras': 'justFound'}), (30608, 'expiring', {'mode': 'listBroadcasts', 'url': '/index.json', 'extras': 'expiring'}),
		(30609, 'vonabisz', {'mode': 'listAlphabet', 'extras': 'letter_A-Z'}), (30610, 'archive', {'mode': 'filtrateSearch', 'url': '/search.json', 'extras': 'searchFILTRATE'}),
		(30611, 'basesearch', {'mode': 'SearchSEVER', 'extras': 'searchWORD'})]:
		addDir(PATH, create_entries({'Title': translation(TITLE), 'Image': f"{artpic}{IMG}.png"}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30612), 'Image': f"{artpic}settings.png"}), False)
		if enableINPUTSTREAM and plugin_operate('inputstream.adaptive'):
			addDir({'mode': 'iConfigs'}, create_entries({'Title': translation(30613), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTopics(TARGET, CAT, WANTED):
	debug_MS("(navigator.listTopics) ------------------------------------------------ START = listTopics -----------------------------------------------")
	debug_MS(f"(navigator.listTopics) ### TARGET = {TARGET} ### CATEGORY = {CAT} ### WANTED = {WANTED} ###")
	DATA_ONE = getContent(TARGET, REF=BASE_URL)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listTopics[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if 'index.json' in TARGET and DATA_ONE is not None and DATA_ONE.get('pageProps', '') and DATA_ONE['pageProps'].get(CAT, ''):
		for item in sorted(DATA_ONE['pageProps'].get(CAT, []), key=lambda vsx: clear_umlaut(vsx.get('name', 'zorro')).lower()):
			if not item.get('name', ''): continue
			name, slug = cleaning(item['name']), quote_plus(item['slug'])
			if CAT == 'stations' and showARTE is False and name.upper() in ARTEEX: continue
			if CAT == 'stations' and showJOYN is False and name.upper() in JOYNEX: continue
			if CAT == 'stations' and showRTL is False and name.upper() in RTLEX: continue
			image = f"{BASE_URL[:-1]}{item['logoWhite']}" if CAT == 'stations' and item.get('logoWhite', '') else \
				f"{genpic}{slug.lower()}.png" if CAT == 'categories' and xbmcvfs.exists(f"{genpic}{slug.lower()}.png") else icon
			NEW_URL = f"/{slug}.json" if CAT == 'stations' else f"/rubriken/{slug}.json"
			addDir({'mode': 'subTopics', 'url': NEW_URL, 'extras': CAT}, create_entries({'Title': name, 'Image': image}))
			debug_MS(f"(navigator.listTopics[2]) ### NAME : {name} || SLUG : {slug} || IMAGE : {image} ###")
	elif 'a-z.json' in TARGET and DATA_ONE is not None and DATA_ONE.get('pageProps', '') and DATA_ONE['pageProps'].get(CAT, ''):
		for item in DATA_ONE['pageProps'].get(CAT, []):
			if item.get('letter') == WANTED:
				for each in sorted(item.get('items', []), key=lambda vsx: clear_umlaut(vsx.get('name', 'zorro')).lower()):
					if not each.get('name', ''): continue
					(FETCH_UNO, context), (plot, genre, studio), operation = ({} for _ in range(2)), ("" for _ in range(3)), 'adding'
					MEDIAID, slug = each.get('id', '00'), quote_plus(each['slug'])
					name = origSERIE = cleaning(each['name'])
					if each.get('categories', '') and each.get('categories', {})[0].get('name', ''):
						genre = cleaning(each['categories'][0]['name']).replace('/', ' / ').title()
					if each.get('stations', '') and each.get('stations', {})[0].get('name', ''):
						studio = each['stations'][0]['name']
						plot = translation(30621).format(genre, studio)
						name = f"{name}  ({studio.upper()})" if showCHANFOLD else name
						if showARTE is False and studio.upper() in ARTEEX: continue
						if showJOYN is False and studio.upper() in JOYNEX: continue
						if showRTL is False and studio.upper() in RTLEX: continue
					FETCH_UNO = context = {'Cid': MEDIAID, 'Slug': slug, 'Extra': 'shows', 'Serie': origSERIE, \
						'Title': name, 'Plot': plot, 'Genre': genre, 'Studio': studio, 'Image': f"{alppic}{WANTED}.jpg"}
					if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
						for article in preserve(FAVORIT_FILE):
							if article.get('Cid') == MEDIAID: operation = 'skipping'
					addDir({'mode': 'listBroadcasts', 'url': f"/sendungen/{slug}.json", 'extras': 'shows', 'transmit': origSERIE}, create_entries(FETCH_UNO), True, context, operation)
					debug_MS(f"(navigator.listTopics[2]) ### NAME : {name} || CID : {MEDIAID} || SLUG : {slug} || GENRE : {genre} || STUDIO : {studio} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def subTopics(TARGET, CAT):
	debug_MS("(navigator.subTopics) ------------------------------------------------ START = subTopics -----------------------------------------------")
	debug_MS(f"(navigator.subTopics) ### TARGET = {TARGET} ### CATEGORY = {CAT} ###")
	DATA_ONE = getContent(TARGET, REF=BASE_URL)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.subTopics[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	for item in DATA_ONE.get('pageProps', []):
		COMBI = [obj for obj in traversing.get_records()['specifications'] if obj.get('short') == item]
		if COMBI and item[:5] not in CAT and len(DATA_ONE.get('pageProps', {}).get(item, '')) > 0:
			name = COMBI[0]['name']
			image = f"{genpic}{item.lower()}.png" if xbmcvfs.exists(f"{genpic}{item.lower()}.png") else icon
			addDir({'mode': 'listBroadcasts', 'url': TARGET, 'extras': item, 'transmit': name}, create_entries({'Title': name, 'Image': image}))
			debug_MS(f"(navigator.subTopics[2]) ### NAME : {name} || SLUG : {item} || IMAGE : {image} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listAlphabet():
	debug_MS("(navigator.listAlphabet) ------------------------------------------------ START = listAlphabet -----------------------------------------------")
	for letter in ['0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']:
		addDir({'mode': 'listTopics', 'url': '/a-z.json', 'extras': 'series', 'transmit': letter}, create_entries({'Title': letter, 'Image': f"{alppic}{letter}.jpg"}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchSEVER(CAT):
	debug_MS("(navigator.SearchSEVER) ------------------------------------------------ START = SearchSEVER -----------------------------------------------")
	# https://www.sendungverpasst.de/_next/data/cl7AR8ToJErdg4wnRFYGT/search.json?q=%22Rote+Rosen%22
	keyword = preserve(SEARCH_FILE, 'TEXT') if xbmcvfs.exists(SEARCH_FILE) else None
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30622), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword: return filtrateSearch(f'/search.json?q={quote_plus(keyword)}', CAT, keyword)
	return None

def filtrateSearch(TARGET, CAT, SERIE):
	debug_MS("(navigator.filtrateSearch) -------------------------------------------------- START = filtrateSearch --------------------------------------------------")
	debug_MS(f"(navigator.filtrateSearch) ### TARGET = {TARGET} ### CATEGORY = {CAT} ### SERIE : {SERIE} ###")
	if not 'cat=' in TARGET:
		addDir({'mode': 'selectionSearch', 'url': TARGET, 'extras': 'categories', 'transmit': SERIE}, create_entries({'Title': translation(30623)}))
	if not 'station=' in TARGET:
		addDir({'mode': 'selectionSearch', 'url': TARGET, 'extras': 'stations', 'transmit': SERIE}, create_entries({'Title': translation(30624)}))
	if not 'date=' in TARGET:
		addDir({'mode': 'selectionSearch', 'url': TARGET, 'extras': 'dates', 'transmit': SERIE}, create_entries({'Title': translation(30625)}))
	addDir({'mode': 'listBroadcasts', 'url': TARGET+build_rider(TARGET, 'sort=date'), 'extras': 'result', 'transmit': SERIE}, create_entries({'Title': translation(30626)}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def selectionSearch(TARGET, CAT, SERIE):
	debug_MS("(navigator.selectionSearch) ------------------------------------------------ START = selectionSearch -----------------------------------------------")
	debug_MS(f"(navigator.selectionSearch) ### TARGET = {TARGET} ### CATEGORY = {CAT} ### SERIE : {SERIE} ###")
	DATA_ONE = getContent(TARGET, REF=BASE_URL)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.selectionSearch[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if DATA_ONE is not None and DATA_ONE.get('pageProps', '') and DATA_ONE['pageProps'].get(CAT, ''):
		elements = sorted(DATA_ONE['pageProps'].get(CAT, []), key=lambda vsx: clear_umlaut(vsx.get('name', 'zorro')).lower()) if \
			CAT in ['categories', 'stations'] else DATA_ONE['pageProps'].get(CAT, [])
		for item in elements:
			if not item.get('name', ''): continue
			name, slug = cleaning(item['name']), str(item['key'])
			if CAT == 'stations' and showARTE is False and name.upper() in ARTEEX: continue
			if CAT == 'stations' and showJOYN is False and name.upper() in JOYNEX: continue
			if CAT == 'stations' and showRTL is False and name.upper() in RTLEX: continue
			counter = item.get('doc_count', None)
			if counter: name, title = f"{name}   [B][COLOR yellow]({counter})[/COLOR][/B]", f"{name}  [{counter}]"
			changes = CAT.replace('categories', 'cat').replace('stations', 'station').replace('dates', 'date')
			addDir({'mode': 'filtrateSearch', 'url': TARGET+build_rider(TARGET, f"{changes}={slug}"), 'extras': CAT, 'transmit': SERIE}, create_entries({'Title': name}))
			debug_MS(f"(navigator.selectionSearch[2]) ### NAME : {title} || SLUG : {slug} || CAT : {CAT} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(TARGET, PAGE, LIMIT, POS, TYPE, SERIE):
	debug_MS("(navigator.listBroadcasts) ------------------------------------------------ START = listBroadcasts -----------------------------------------------")
	debug_MS(f"(navigator.listBroadcasts) ### TARGET = {TARGET} ### PAGE = {PAGE} ### LIMIT = {LIMIT} ### POSITION = {POS} ### TYPE = {TYPE} ### SERIE = {SERIE} ###")
	counter, POS, (COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, SENDING), DATA_ONE = 0, int(POS), ([] for _ in range(4)), getContent(TARGET, REF=BASE_URL)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listBroadcasts[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if DATA_ONE is not None and DATA_ONE.get('pageProps', '') and (TYPE in DATA_ONE.get('pageProps', {}) or 'shows' in DATA_ONE.get('pageProps', {})):
		for key, value in DATA_ONE.get('pageProps', []).items():
			#debug_MS(f"(navigator.listBroadcasts) ##### KEY : {key} || VALUE : {value} #####")
			if (key in ['current', 'shows', 'show', 'moreShows'] or key == TYPE) and value is not None:
				elements = value if isinstance(value, list) else [value]
				for item in elements:
					(ORDNER, excluding), (MORE_COLLECT, MORE_SEARCH, WANT_DETAILS) = (True for _ in range(2)), ('DEFAULT' for _ in range(3))
					STATION, SEASON, EPISODE, START_1, AIRED_1, DATE_1, ENDS_1, GENRE_1 = (None for _ in range(8))
					seriesENTRY = item
					item = item['_source'] if item.get('_source', '') else item
					debug_MS(f"(navigator.listBroadcasts[2]) ##### ELEMENT-02 : {item} #####")
					MEDIAID = (item.get('id', None) or seriesENTRY.get('_id', None))
					SLUG_1 = quote_plus(item['slug']) if item.get('slug', '') else None
					DIRECT_1 = (item.get('link', None) or None)
					if item.get('stations', '') and item.get('stations', {})[0].get('name', ''):
						STATION = item['stations'][0]['name']
						if showARTE is False and STATION.upper() in ARTEEX: continue
						if showJOYN is False and STATION.upper() in JOYNEX: continue
						if showRTL is False and STATION.upper() in RTLEX: continue
					POS, counter = POS.__add__(1), counter.__add__(1)
					NAME = extractor = cleaning(item['fullTitle']) if item.get('fullTitle', '') else cleaning(item['title']) if item.get('title', '') else \
						cleaning(item['name']) if item.get('name', '') else 'UNBEKANNT'
					if any(xu in TARGET for xu in ['/trends.', '/top.']) or 'top20' in TYPE:
						NAME = translation(30627).format(counter, NAME)
					VIEWS = item.get('clicks', 0)
					SHOWTITLE = cleaning(item['show']) if item.get('show', '') else None # STANDARD=shows - SEARCH=result
					origSERIE = SHOWTITLE if SHOWTITLE else SERIE
					TAGS = cleaning(item.get('subtitle', ''))
					LENGHT = int(item['duration']) * 60 if str(item.get('duration')).isdecimal() else None
					if LENGHT or str(SLUG_1.split('-')[-1]).isdecimal() or TYPE == 'highlights':
						MORE_COLLECT = f"/content/{SLUG_1}.json" if SLUG_1 and key not in ['show', 'moreShows', 'result'] else 'DEFAULT' # ERLAUBT: show, moreShows, result
						MORE_SEARCH = f"/search.json?q={quote_plus(SHOWTITLE)}&sort=date" if SHOWTITLE and key in ['show', 'moreShows'] and \
							DATA_ONE.get('pageProps', {}).get('hasMore', '') is True else 'DEFAULT' # ERLAUBT: show, moreShows
						if DIRECT_1 is None and MEDIAID and SLUG_1: WANT_DETAILS = f"/content/{SLUG_1}.json"
						ORDNER, excluding = False, True if MEDIAID is None else False
					else:
						ORDNER, excluding = True, False
					if excluding is True: continue
					matchSEA = re.search(r'(Staffel:? |S)([0-9]+)', extractor) # Staffel 13, Folge 05 // Staffel: 6, Folge: 11 // (S01/E03) // (1/3) // Rote Rosen: (1094)
					if matchSEA: SEASON = f"{int(matchSEA.group(2)):02}" if str(matchSEA.group(2)).isdecimal() and int(matchSEA.group(2)) != 0 else None
					if SEASON is None:
						matchSON = re.search(r'\(([0-9]+)/[0-9]+\)', extractor) # Staffel 13, Folge 05 // Staffel: 6, Folge: 11 // (S01/E03) // (1/3) // Rote Rosen: (1094)
						if matchSON: SEASON = f"{int(matchSON.group(1)):02}" if str(matchSON.group(1)).isdecimal() and int(matchSON.group(1)) != 0 else None
					matchEPI = re.search(r'(Episode:? |Folge:? |E)([0-9]+)', extractor) # Staffel 13, Folge 05 // Staffel: 6, Folge: 11 // (S01/E03) // (1/3) // Rote Rosen: (1094)
					if matchEPI: EPISODE = f"{int(matchEPI.group(2)):02}" if str(matchEPI.group(2)).isdecimal() and int(matchEPI.group(2)) != 0 else None
					if EPISODE is None:
						matchODE = re.search(r'\([0-9]+/([0-9]+)\)', extractor) # Staffel 13, Folge 05 // Staffel: 6, Folge: 11 // (S01/E03) // (1/3) // Rote Rosen: (1094)
						if matchODE: EPISODE = f"{int(matchODE.group(1)):02}" if str(matchODE.group(1)).isdecimal() and int(matchODE.group(1)) != 0 else None
					if EPISODE is None:
						matchISO = re.search(r' \(([0-9]+)\)', extractor) # Staffel 13, Folge 05 // Staffel: 6, Folge: 11 // (S01/E03) // (1/3) // Rote Rosen: (1094)
						if matchISO: EPISODE = f"{int(matchISO.group(1)):02}" if str(matchISO.group(1)).isdecimal() and int(matchISO.group(1)) != 0 else None
					PHOTO_1 = IMG_cover.format(item['image']) if item.get('image', '') else icon
					if str(list(seriesENTRY.values())[0]) == 'series' and PHOTO_1 == icon and SLUG_1:
						PHOTO_1 = IMG_cover.format(f"series/{clear_umlaut(item['slug'])}.jpg")
					if item.get('datetime', '') and str(item.get('datetime')[:10].replace('.', '').replace('-', '').replace('/', '')).isdecimal():
						available_uno = datetime(*(time.strptime(item['datetime'][:16], '%d.%m.%Y %H:%M')[0:6])) # 20.12.2023 20:15
						START_1 = available_uno.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						AIRED_1 = available_uno.strftime('%d.%m.%Y') # FirstAired
						DATE_1 = available_uno.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else available_uno.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
						if START_1.startswith(('31.12.99', '01.01.00')): START_1 = AIRED_1 = DATE_1 = None
					if item.get('expiryDate', '') and str(item.get('expiryDate')[:10].replace('.', '').replace('-', '').replace('/', '')).isdecimal():
						expiring_uno = datetime(*(time.strptime(item['expiryDate'][:16], '%d.%m.%Y %H:%M')[0:6])) # 27.12.2023 00:00
						ENDS_1 = expiring_uno.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						if ENDS_1.startswith(('31.12.99', '01.01.00')): ENDS_1 = None
					if item.get('categories', '') and item.get('categories', {})[0].get('name', ''):
						GENRE_1 = cleaning(item['categories'][0]['name']).replace('/', ' / ').title()
					DESC_1 = cleaning(item['description']) if item.get('description', '') else ""
					COMBI_FIRST.append([int(POS), SLUG_1, DIRECT_1, MEDIAID, NAME, VIEWS, SHOWTITLE, origSERIE, TAGS, LENGHT, ORDNER, SEASON, \
						EPISODE, PHOTO_1, START_1, AIRED_1, DATE_1, ENDS_1, DESC_1, GENRE_1, STATION, MORE_COLLECT, MORE_SEARCH])
					if WANT_DETAILS != 'DEFAULT':
						COMBI_LINKS.append([int(POS), SLUG_1, API_COMP+WANT_DETAILS])
	if COMBI_LINKS:
		COMBI_SECOND = listCompletion(COMBI_LINKS)
	if COMBI_FIRST:
		parts = COMBI_FIRST[:]
		analogy = [psx for psx in parts if psx[15] == parts[0][15]]
		plus_STUDIO = True if len(analogy) != len(COMBI_FIRST) else False
		RESULTS = [av + bv for av in COMBI_FIRST for bv in COMBI_SECOND if av[0] == bv[0] and av[1] == bv[1]] # Merge List1 and List2 - if the POSITION and SLUG matches !!!
		RESULTS += [cv for cv in COMBI_FIRST if all(dv[0] != cv[0] for dv in COMBI_SECOND)] # The remaining items from List1 – if the POSITION is not in List2 !!!
		for xev in sorted(RESULTS, key=lambda pn: int(pn[0])):
			Note_1, Note_2, Note_3, Note_4 = ("" for _ in range(4))
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listBroadcasts[4]) ### Anzahl = {len(xev)} || Eintrag : {xev} ###")
			if len(xev) > 23: ### List1 + List2 is greater than 23 ###
				Slug1, Link1, MediaID, Name, Views, Tvshow, Origin, Tagline, Duration, Folder, Season = xev[1], xev[2], xev[3], xev[4], xev[5], xev[6], xev[7], xev[8], xev[9], xev[10], xev[11]
				Episode, Thumb1, Start1, Aired1, Date1, Ends1, Desc1, Genre1, Studio, MUCH_COLLECT, MUCH_SEARCH = xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18], xev[19], xev[20], xev[21], xev[22]
				Slug2, Link2, Thumb2, Start2, Aired2, Date2, Ends2, Desc2, Genre2 = xev[24], xev[25], xev[26], xev[27], xev[28], xev[29], xev[30], xev[31], xev[32]
			elif len(xev) == 23:
				Slug1, Link1, MediaID, Name, Views, Tvshow, Origin, Tagline, Duration, Folder, Season = xev[1], xev[2], xev[3], xev[4], xev[5], xev[6], xev[7], xev[8], xev[9], xev[10], xev[11]
				Episode, Thumb1, Start1, Aired1, Date1, Ends1, Desc1, Genre1, Studio, MUCH_COLLECT, MUCH_SEARCH = xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18], xev[19], xev[20], xev[21], xev[22]
				Slug2, Link2, Thumb2, Start2, Aired2, Date2, Ends2, Desc2, Genre2 = None, None, icon, None, None, None, None, "", None
			else: continue
			Image = Thumb2 if Thumb2 != icon else Thumb1
			if TYPE == 'highlights': # If TYPE is 'highlights', convert entries (no folder) to entries (folder) with a new SLUG
				Folder, Title, Slug1 = True, Name.split(':')[0], quote_plus(Name.split(':')[0].replace('/', '').replace(' - ', ' ').replace(' ', '-').lower())
			else: Title = f"{Name}  ({Studio.upper()})" if showCHANLINK and plus_STUDIO else Name
			Direct = Link2 if Link2 else Link1
			if Folder is False and Direct is None: continue # If this is no folder and direct-link is None, skip this entry
			if Tvshow and int(Views) > 0: Note_1 = translation(30628).format(Tvshow, Views)
			elif Tvshow and int(Views) < 1: Note_1 = translation(30629).format(Tvshow)
			if Folder is False: # Show these entries only if this is no folder
				if Season and Episode: Note_2 = translation(30630).format(Season, Episode)
				elif Season is None and Episode: Note_2 = translation(30631).format(Episode)
				startTIMES, endTIMES = Start2 if Start2 else Start1, Ends2 if Ends2 else Ends1
				Datum, Airing = Date2 if Date2 else Date1, Aired2 if Aired2 else Aired1
				if startTIMES and endTIMES: Note_3 = translation(30632).format(startTIMES, endTIMES)
				elif startTIMES and endTIMES is None: Note_3 = translation(30633).format(startTIMES)
				elif startTIMES is None and endTIMES is None and Tvshow: Note_3 = '[CR]'
			else:
				Season, Episode, Datum, Airing = (None for _ in range(4))
			Teaser = Desc2 if len(Desc2) > len(Desc1) else Desc1
			if Studio: Note_4 = translation(30634).format(Studio) if Teaser != "" else translation(30635).format(Studio)
			Description = Note_1+Note_2+Note_3+Teaser+Note_4
			Category = Genre2 if Genre2 else Genre1
			debug_MS(f"(navigator.listBroadcasts[4]) ##### TITLE : {Title} || SEASON : {Season} || EPISODE : {Episode} || AIRED : {Airing} #####")
			debug_MS(f"(navigator.listBroadcasts[4]) ##### SLUG : {Slug1} || CID : {MediaID} || GENRE : {Category} || STUDIO : {Studio} #####")
			debug_MS(f"(navigator.listBroadcasts[4]) ##### is FOLDER : {Folder} || DURATION : {Duration} || THUMB : {Image} #####")
			FETCHING = {'Slug': Slug1, 'Title': Title, 'TvShowTitle': Tvshow, 'Tagline': Tagline, 'Plot': Description, 'Season': Season, 'Episode': Episode, \
				'Date': Datum, 'Aired': Airing, 'Genre': Category, 'Studio': Studio, 'Image': Image}
			if Folder is True:
				ACTION = {'mode': 'listBroadcasts', 'url': f"/sendungen/{Slug1}.json", 'extras': 'shows', 'transmit': Title}
				FETCH_UNO = create_entries(FETCHING)
			else:
				for method in get_sorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
				ACTION = {'mode': 'playCODE', 'IDENTiTY': MediaID}
				FETCH_UNO = create_entries({**FETCHING, **{'Duration': Duration, 'Mediatype': 'episode' if str(Episode).isdecimal() else 'movie', 'Reference': 'Single'}})
				if Tvshow and MUCH_COLLECT != 'DEFAULT': # cyan, magenta, springgreen
					FETCH_UNO.addContextMenuItems([(translation(30655).format(Tvshow), f"Container.Update({build_mass(HOST_AND_PATH, {'mode': 'listBroadcasts', 'url': API_COMP+MUCH_COLLECT, 'extras': 'show', 'transmit': Tvshow})})")])
				if Tvshow and MUCH_SEARCH != 'DEFAULT': # cyan, magenta, springgreen
					FETCH_UNO.addContextMenuItems([(translation(30656), f"Container.Update({build_mass(HOST_AND_PATH, {'mode': 'listBroadcasts', 'url': API_COMP+MUCH_SEARCH, 'extras': 'result', 'transmit': Tvshow})})")])
				SENDING.append({'filtrate': MediaID, 'name': Title, 'tvshow': Tvshow, 'station': Studio, 'direct': Direct})
			addDir(ACTION, FETCH_UNO, Folder)
		preserve(WORKS_FILE, 'JSON', SENDING)
		if DATA_ONE is not None and DATA_ONE.get('pageProps', '') and str(DATA_ONE['pageProps'].get('total')).isdecimal() and int(DATA_ONE['pageProps']['total']) > int(PAGE)*int(LIMIT):
			debug_MS(f"(navigator.listBroadcasts[4]) PAGES ### currentENTRIES : {int(PAGE)*int(LIMIT)} from totalENTRIES : {DATA_ONE['pageProps']['total']} ###")
			SUFFIX = build_rider(TARGET, f"page={int(PAGE)+1}") if int(PAGE) == 1 else f"page={int(PAGE)+1}"
			FETCH_DUE = create_entries({'Title': translation(30636).format(int(PAGE)+1), 'Image': f"{artpic}nextpage.png"})
			addDir({'mode': 'listBroadcasts', 'url': TARGET.split('page=')[0]+SUFFIX, 'page': int(PAGE)+1, 'limit': int(LIMIT), 'position': int(POS), 'extras': TYPE, 'transmit': Origin}, FETCH_DUE)
	else:
		failing(f'(navigator.listBroadcasts) ##### NO BROADCAST-LIST - NO ENTRY FOR: "{SERIE}" FOUND #####')
		return dialog.notification(translation(30526), translation(30527).format(SERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listCompletion(MURLS):
	debug_MS("(navigator.listCompletion) -------------------------------------------------- START = listCompletion --------------------------------------------------")
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		DATA_RIDER = json.loads(COMBI_DETAILS)
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.llistCompletion[3]) XXXXX CONTENT-03 : {DATA_RIDER} XXXXX")
		debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
		for articles in DATA_RIDER:
			if articles is not None and articles.get('pageProps', '') and articles['pageProps'].get('show', ''):
				NUMBER_2, SLUG_2, WLINK_2 = articles.get('Position', 0), articles.get('NaviForm', 'unknown'), articles.get('Demand', 'unknown')
				(START_2, AIRED_2, DATE_2, ENDS_2, GENRE_2), SHORT = (None for _ in range(5)), articles['pageProps']['show']
				debug_MS(f"(navigator.listCompletion[3]) xxxxx POSITION-03 : {NUMBER_2} || SLUG-03 : {SLUG_2} || ELEMENT-03 : {SHORT} xxxxx")
				DIRECT_2 = (SHORT.get('link', None) or None)
				PHOTO_2 = IMG_cover.format(SHORT['image']) if SHORT.get('image', '') else icon
				if SHORT.get('datetime', '') and str(SHORT.get('datetime')[:10].replace('.', '').replace('-', '').replace('/', '')).isdecimal():
					available_due = datetime(*(time.strptime(SHORT['datetime'][:16], '%d.%m.%Y %H:%M')[0:6])) # 20.12.2023 20:15
					START_2 = available_due.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
					AIRED_2 = available_due.strftime('%d.%m.%Y') # FirstAired
					DATE_2 = available_due.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else available_due.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
					if START_2.startswith(('31.12.99', '01.01.00')): START_2 = AIRED_2 = DATE_2 = None
				if SHORT.get('expiryDate', '') and str(SHORT.get('expiryDate')[:10].replace('.', '').replace('-', '').replace('/', '')).isdecimal():
					expiring_due = datetime(*(time.strptime(SHORT['expiryDate'][:16], '%d.%m.%Y %H:%M')[0:6])) # 27.12.2023 00:00
					ENDS_2 = expiring_due.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
					if ENDS_2.startswith(('31.12.99', '01.01.00')): ENDS_2 = None
				if SHORT.get('categories', '') and SHORT.get('categories', {})[0].get('name', ''):
					GENRE_2 = cleaning(SHORT['categories'][0]['name']).replace('/', ' / ').title()
				DESC_2 = cleaning(SHORT['description']) if SHORT.get('description', '') else ""
				COMBI_THIRD.append([int(NUMBER_2), SLUG_2, DIRECT_2, PHOTO_2, START_2, AIRED_2, DATE_2, ENDS_2, DESC_2, GENRE_2])
	return COMBI_THIRD

def playCODE(PLID):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### SENDUNGVERPASST_CID : {PLID} ###")
	FINAL_URL, CLEAR_TITLE, TVSHOW, LINK = (False for _ in range(4))
	for elem in preserve(WORKS_FILE):
		if elem['filtrate'] != '00' and elem['filtrate'] == PLID:
			CLEAR_TITLE = re.sub('\[.*?\]', '', elem['name']) if elem.get('name', '') else False
			TVSHOW, STATION, LINK = elem['tvshow'], elem['station'], elem['direct']
			debug_MS(f"(navigator.playCODE) ### WORKS_FILE-Line : {elem} ###")
	LINK = LINK.replace('http://', 'https://') if LINK and LINK[:7] == 'http://' else LINK
	log("(navigator.playCODE) --- START WIEDERGABE ANFORDERUNG ---")
	log("(navigator.playCODE[1]) frei")
	log(f"(navigator.playCODE[1]) ~~~ AbspielLink-01 (Original) : {LINK} ~~~")
	log("(navigator.playCODE[1]) frei")
	if LINK and LINK.startswith('https://www.ardmediathek.de'):
		return ArdGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.arte.tv'):
		submitCode = re.compile(r'arte.tv/de/videos/([^/]+)/', re.S).findall(LINK)[0]
		FINAL_URL = f"plugin://plugin.video.artetv.de/?mode=playVideo&link={submitCode}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'ARTE.TV', 'ARTE.TV - Plugin')
	elif LINK and LINK.startswith('https://www.dw.com'):
		return DwGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.joyn.de'):
		return JoynGetVideo(LINK)
	elif LINK and LINK.startswith('https://www.kika.de'):
		return KikaGetVideo(LINK)
	elif LINK and LINK.startswith('https://plus.rtl.de'):
		videoHUB = re.search(r'(\d+)', LINK.split('-')[-1])
		if videoHUB: # https://plus.rtl.de/video-tv/serien/alles-was-zaehlt-146430/2023-12-984414/episode-4351-niemand-ahnt-welch-waghalsigen-plan-justus-schmiedet-927644
			PREDICATE = 'movie' if 'filme/' in LINK else 'episode' # shows + serien
			FINAL_URL = f"plugin://plugin.video.tvnow.de/?action=playVod&id=rrn:watch:videohub:{PREDICATE}:{videoHUB.group(1)}"
		return playRESOLVED(FINAL_URL, 'TRANSMIT', 'RTL+ - Webversion', 'RTL+ - Plugin')
	elif LINK and LINK.startswith(('https://www.3sat.de', 'https://www.phoenix.de', 'https://zdf.de', 'https://www.zdf.de', 'https://www.zdfheute.de')):
		return ZdfGetVideo(LINK)
	else:
		failing(f"(navigator.playCODE[2]) AbspielLink-00 : Der Provider *{urlparse(LINK).netloc}* konnte nicht aufgelöst werden !!!")
		dialog.notification(translation(30521).format('LINK'), translation(30528).format(urlparse(LINK).netloc), icon, 10000)
		log("(navigator.playCODE[2]) --- ENDE WIEDERGABE ANFORDERUNG ---")

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		for each in sorted(preserve(FAVORIT_FILE), key=lambda vsx: clear_umlaut(vsx.get('Serie', 'zorro')).lower()):
			FETCH_UNO, context = ({} for _ in range(2))
			ACTION = {'mode': 'listBroadcasts', 'url': f"/sendungen/{each.get('Slug')}.json", 'extras': each.get('Extra'), 'transmit': each.get('Serie')}
			FETCH_UNO = context = {'Cid': each.get('Cid'), 'Slug': each.get('Slug'), 'Extra': each.get('Extra'), 'Serie': each.get('Serie'), \
				'Title': each.get('Serie'), 'Plot': each.get('Plot'), 'Genre': each.get('Genre'), 'Studio': each.get('Studio'), 'Image': each.get('Image')}
			debug_MS(f"(navigator.listFavorites[1]) ##### NAME : {each.get('Title')} || CID : {each.get('Cid')} || SLUG : {each.get('Slug')} || THUMB : {each.get('Image')} #####")
			addDir(ACTION, create_entries(FETCH_UNO), True, context, 'removing')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favorit_construct(**kwargs):
	TOPS = []
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		del kwargs['mode']; del kwargs['action']
		TOPS.append({key: value for key, value in kwargs.items() if value not in ['', 'None', None]})
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30533), translation(30534).format(kwargs['Serie']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Cid') != kwargs.get('Cid')]
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30533), translation(30535).format(kwargs['Serie']), icon, 10000)

def addDir(params, listitem, folder=True, context={}, handling='default'):
	uws, entries = build_mass(HOST_AND_PATH, params), []
	listitem.setPath(uws)
	if handling == 'adding' and context:
		entries.append([translation(30651), f"RunPlugin({build_mass(HOST_AND_PATH, {**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass(HOST_AND_PATH, {**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
