﻿# -*- coding: utf-8 -*-

from .common import *


def ard_contents(video_origin):
	debug_MS("(resolver.ard_contents) ------------------------------------------------ START = ard_contents -----------------------------------------------")
	(MASTERS, MEDIAS), (code_one, STREAM, FINAL_URL) = ([] for _ in range(2)), (False for _ in range(3))
	LANGUAGES = ['deu', 'ov']
	ARD_QUALITIES = ['Auto', 2560, 1920, 1280, 960, 640] # ARD_QUALITIES = ['auto', 5, 4, 3, 2, 1, 0]
	for code_one in video_origin.split('/'):
		try:
			testing = base64.urlsafe_b64decode(code_one + '=' * (len(code_one) % 4)).decode()
			if code_one and len(testing) > 5: break
		except: pass
	# https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL3JhZGlvYnJlbWVuLmRlLzgyYzhkMjE0LTFhM2YtNDU3NC1iOWMwLTdjODlmYWIzNDYyNi9lcGlzb2RlL3VybjphcmQ6c2hvdzo2MjA5YjVhYmQ4ODZhN2Fj?devicetype=pc&embedded=true = Nicht immer Videoeinträge vorhanden !!!
	# https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL3JhZGlvYnJlbWVuLmRlLzgyYzhkMjE0LTFhM2YtNDU3NC1iOWMwLTdjODlmYWIzNDYyNi9lcGlzb2RlL3VybjphcmQ6c2hvdzo2MjA5YjVhYmQ4ODZhN2Fj?embedded=true&mcV6=true = Alle Videoeinträge = Fremdsprachen, Deutsch Standard, Deutsch mit Audiodescription, Deutsch mit Unterttiteln
	debug_MS(f"(resolver.ard_contents[1]) ##### REQUEST_ONE : {API_ARD}ard/item/{code_one}?embedded=true&mcV6=true #####")
	if code_one:
		section_one = track_content(f"{API_ARD}ard/item/{code_one}?embedded=true&mcV6=true", 'GET', 'TRACK', WEB_HEADER)
		if section_one.status_code in [200, 201, 202]:
			DATA_ONE = section_one.json()
			debug_MS("++++++++++++++++++++++++")
			debug_MS(f"(resolver.ard_contents[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
			debug_MS("++++++++++++++++++++++++")
			if DATA_ONE is not None and DATA_ONE.get('widgets', '') and len(DATA_ONE['widgets']) > 0:
				if DATA_ONE.get('coreAssetType', '') == 'SECTION' and len(DATA_ONE['widgets']) > 1 and 'teasers' in str(DATA_ONE['widgets'][1]):
					broadcast = DATA_ONE['widgets'][0].get('broadcastedOn', 'UNKNOWN')
					code_two = next(filter(lambda cx: cx.get('coreAssetType', '') == 'EPISODE' and broadcast in cx.get('broadcastedOn', ''), DATA_ONE['widgets'][1].get('teasers', [])), None)
					debug_MS(f"(resolver.ard_contents[1]) ##### DETECTED CODE FOR REQUEST_TWO : {code_two['id'] if code_two else '!!! ERROR !!! NO RESULTS !!! ERROR !!!'} #####")
					if code_two:
						section_two = track_content(f"{API_ARD}ard/item/{code_two['id']}?embedded=false&mcV6=true", 'GET', 'TRACK', WEB_HEADER)
						if section_two.status_code in [200, 201, 202]:
							DATA_TWO = section_two.json()
							debug_MS("++++++++++++++++++++++++")
							debug_MS(f"(resolver.ard_contents[2]) XXXXX CONTENT-02 : {DATA_TWO} XXXXX")
							debug_MS("++++++++++++++++++++++++")
							if DATA_TWO is not None and DATA_TWO.get('widgets', '') and len(DATA_TWO['widgets']) > 0:
								full_video = DATA_TWO.get('widgets', [])
							else: full_video = DATA_ONE.get('widgets', [])
						else: full_video = DATA_ONE.get('widgets', [])
					else: full_video = DATA_ONE.get('widgets', [])
				else: full_video = DATA_ONE.get('widgets', [])
				for elem in full_video:
					if elem.get('mediaCollection', '') and len(elem['mediaCollection']) > 0:
						for each in elem['mediaCollection']['embedded']['streams']:
							formitaeten = each.get('media')
							if not isinstance(formitaeten, list):
								continue
							for item in formitaeten:
								if item.get('forcedLabel').lower() == 'auto' and item.get('mimeType').lower() in ['application/x-mpegurl', 'application/vnd.apple.mpegurl']:
									for found in LANGUAGES:
										for shorties in item.get('audios', {}):
											if shorties.get('languageCode').lower() == found and shorties.get('kind').lower() == 'standard':
												MASTERS.append({'url': item['url'], 'quality': item['maxHResolutionPx'], 'mimeType': item.get('mimeType').lower(), 'language': shorties['languageCode']})
								if item.get('forcedLabel').lower() != 'auto' and item.get('mimeType').lower() == 'video/mp4':
									for found in LANGUAGES:
										for shorties in item.get('audios', {}):
											if shorties.get('languageCode').lower() == found and shorties.get('kind').lower() == 'standard':
												numbers = 22 if shorties.get('languageCode').lower() == 'deu' else 11
												MEDIAS.append({'pos': numbers, 'url': item['url'], 'quality': item['maxHResolutionPx'], 'mimeType': item.get('mimeType').lower(), 'language': shorties['languageCode']})
												MEDIAS = sorted(MEDIAS, key=lambda px: (int(px['pos']), int(px['quality'])), reverse=True)
						debug_MS(f"(resolver.ard_contents[3]) SORTED_LIST | M3U8 ### MASTER : {MASTERS} ###")
						debug_MS(f"(resolver.ard_contents[3]) SORTED_LIST | MPP4 ### MEDIAS : {MEDIAS} ###")
					elif elem.get('blockedByFsk', '') is True:
						log("(resolver.ard_contents[3]) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Alterbeschränkungen geblockt !!!")
						return dialog.notification(translation(30530), translation(30531), icon, 10000)
					elif elem.get('geoblocked', '') is True:
						log("(resolver.ard_contents[3]) AbspielLink-00 (ARD+3) : *ARD-Intern* Der angeforderte -VideoLink- wurde auf Grund von Geo-Sperren geblockt !!!")
						return dialog.notification(translation(30530), translation(30532), icon, 10000)
	if (enable_adaptive or prefer_stream == 0) and MASTERS:
		STREAM, FINAL_URL = 'HLS' if enable_adaptive else 'M3U8', MASTERS[0]['url']
		debug_MS(f"(resolver.ard_contents[4]) ***** TAKE - {'Inputstream (hls)' if STREAM == 'HLS' else 'Standard (m3u8)'} - FILE (Ard.de+3) *****")
	if not FINAL_URL and MEDIAS:
		ard_link = f"https:{MEDIAS[0]['url']}" if MEDIAS[0]['url'][:4] != 'http' else MEDIAS[0]['url']
		STREAM, FINAL_URL = 'MP4', improve_video(ard_link, station='DasErste') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
		debug_MS(f"(resolver.ard_contents[4]) ***** TAKE - (mp4) - FILE (Ard.de+3) : {ard_link} *****")
	return playRESOLVED(FINAL_URL, STREAM, 'ARD+3', 'ARD - Intern')

def dew_contents(video_origin):
	debug_MS("(resolver.dew_contents) ------------------------------------------------ START = dew_contents -----------------------------------------------")
	FINAL_URL, STREAM = (False for _ in range(2))
	section_one = track_content(video_origin, 'GET', 'TEXT', WEB_HEADER)
	dew_player = re.compile(r'<source src="([^"]+)" type="(?:video/mp4|application/x-mpegURL|audio/mpeg)"', re.S).findall(section_one) # https://radiodownloaddw-a.akamaihd.net/Events/dwelle/dira/mp3/deu/FEE8E841_2.mp3
	if dew_player and len(dew_player[0]) > 0: # https://api.dw.com/api/detail/video/65556146 // Anforderung geht auch
		FINAL_URL, STREAM = dew_player[0], 'HLS' if enable_adaptive and 'm3u8' in dew_player[0] else 'M3U8' if not enable_adaptive and 'm3u8' in dew_player[0] else 'MP3' if 'mp3' in dew_player[0] else 'UNKNOWN'
	return playRESOLVED(FINAL_URL, STREAM, 'DeutscheWelle', 'DW - Intern')

def joyn_contents(video_origin):
	debug_MS("(resolver.joyn_contents) ------------------------------------------------ START = joyn_contents -----------------------------------------------")
	# ORIGINAL = https://www.joyn.de/play/serien/sweet-easy-on-tour/2-5-schwarzwaelder-himbeertorte-aus-mailand
	# FINAL_URL = plugin://plugin.video.joyn/?mode=play_video&video_id=a_pbbt48zdo6a&client_data=%7B%22genre%22%3A+%5B%5D%2C+%22startTime%22%3A+0%2C+%22videoId%22%3A+%22a_pbbt48zdo6a%22%2C+%22npa%22%3A+false%2C+%22duration%22%3A+1490000%2C+%22brand%22%3A+%22%22%7D&stream_type=VOD&title=Schwarzw%C3%A4lder+Himbeertorte+aus+Mailand&movie_id=None&path=%2Fserien%2Fsweet-easy-on-tour%2F2-5-schwarzwaelder-himbeertorte-aus-mailand
	video_id, movie_id, route, FINAL_URL = (None for _ in range(4))
	sweep = urlparse(video_origin)
	DATA_ONE = track_content(f"JOYN_REDIRECT@@{sweep.path.replace('play/', '')}.json", headers={**WEB_HEADER, **{'Referer': BASE_JOYN}})
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(resolver.joyn_contents[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if DATA_ONE is not None and DATA_ONE.get('pageProps', ''):
		if DATA_ONE['pageProps'].get('__N_REDIRECT', ''):
			DATA_VIDEO = track_content(f"JOYN_REDIRECT@@{DATA_ONE['pageProps']['__N_REDIRECT']}.json", headers={**WEB_HEADER, **{'Referer': video_origin}})
		else: DATA_VIDEO = DATA_ONE
		if DATA_VIDEO is not None and DATA_VIDEO.get('pageProps', '') and DATA_VIDEO['pageProps'].get('initialData', '') and DATA_VIDEO['pageProps']['initialData'].get('page', ''):
			short = DATA_VIDEO['pageProps']['initialData']['page']
			if short.get('movie', ''):
				video_id = short['movie']['video']['id']
				runtime = short['movie']['video']['duration'] if short['movie']['video'].get('duration', '') else 0
				movie_id = short['movie']['id']
				route = short['movie']['path']
				title = short['movie']['title'] if short['movie'].get('title', '') else 'Unknown'
			elif short.get('episode', ''):
				video_id = short['episode']['video']['id']
				runtime = short['episode']['video']['duration'] if short['episode']['video'].get('duration', '') else 0
				route = short['episode']['path']
				title = short['episode']['title'] if short['episode'].get('title', '') else 'Unknown'
			if video_id and route:
				client = f'{{"genre": [], "startTime": 0, "videoId": "{video_id}", "npa": false, "duration": {int(runtime) * 1000}, "brand": ""}}'
				debug_MS(f"(resolver.joyn_contents[2]) ##### CLIENT_DATA : {quote_plus(client)} #####")
				FINAL_URL = build_mass('plugin://plugin.video.joyn/', {'mode': 'play_video', 'movie_id': movie_id, 'video_id': video_id, 'stream_type': 'VOD', 'title': title, 'client_data': client, 'path': route})
				# JOYN-TRANSMIT : plugin://plugin.video.joyn/?mode=play_video&movie_id=&video_id=a_plf6fi6v9wq&stream_type=VOD&title=Young+Monaco&client_data=%7B%22genre%22%3A+%5B%5D%2C+%22startTime%22%3A+0%2C+%22videoId%22%3A+%22a_plf6fi6v9wq%22%2C+%22npa%22%3A+false%2C+%22duration%22%3A+2966000%2C+%22brand%22%3A+%22%22%7D&path=%2Fserien%2Fgalileo-stories%2F2024-32-young-monaco
	return playRESOLVED(FINAL_URL, 'TRANSMIT', 'JOYN - Mediathek', 'Joyn - Plugin')

def kika_contents(video_origin):
	debug_MS("(resolver.kika_contents) ------------------------------------------------ START = kika_contents -----------------------------------------------")
	KiKA_QUALITIES = [5, 4, 3, 2, 1, 0, 'uhd', 'fhd', 'hd', 'veryhigh', 'high', 'med', 'low', 3840, 2560, 1920, 1280, 1024, 960, 852, 720, 640, 512, 480, 320]
	(default, STREAM, FINAL_URL), (MEDIAS, SELECTION) = (False for _ in range(3)), ([] for _ in range(2))
	section_one = track_content(video_origin, 'GET', 'TEXT', {**WEB_HEADER, **{'Referer': 'https://www.kika.de/'}}).replace('\\', '')
	kika_player = re.compile(r'''["']featuredVideo["']:\{["']docType["']:["'](?:video|externalVideo)["'],["']id["']:["']([^"']+)["'],["']uuid["']''', re.S).findall(section_one)
	if kika_player and len(kika_player[0]) > 0:
		debug_MS(f"(resolver.kika_contents[1]) EXTRACTED ##### video_found : {kika_player[0]} #####")
		DATA_ONE = track_content(f"https://www.kika.de/_next-api/proxy/v1/videos/{kika_player[0]}/assets", headers={**WEB_HEADER, **{'Referer': video_origin}})
		for entry in DATA_ONE.get('assets', []):
			automatic = (entry.get('quality', '') or entry.get('type', '') or 'Unknown')
			if automatic == 'auto' and 'm3u8' in entry.get('url'):
				default = entry['url']
			variable = (entry.get('url', None) or None)
			delivery = (entry.get('delivery', '') or entry.get('bodies', '') or 'Unknown')
			quality = (entry.get('width', None) or entry.get('frameWidth', None))
			if variable and quality:
				MEDIAS.append({'url': variable, 'delivery': delivery, 'quality': quality, 'document': 'WEB_VERSION'})
	if MEDIAS:
		debug_MS(f"(resolver.kika_contents[2]) ORIGINAL_MP4 ### unsorted_LIST : {MEDIAS} ###")
		order_dict = {qual: index for index, qual in enumerate(KiKA_QUALITIES)}
		SELECTION = sorted(MEDIAS, key=lambda xs: order_dict.get(xs['quality'], float('inf')))
		debug_MS(f"(resolver.kika_contents[2]) SORTED_MP4 ###### sorted_LIST : {SELECTION} ###")
	if (enable_adaptive or prefer_stream == 0) and default:
		STREAM, FINAL_URL = 'HLS' if enable_adaptive else 'M3U8', default
		debug_MS(f"(resolver.kika_contents[3]) ***** TAKE - {'Inputstream (hls)' if STREAM == 'HLS' else 'Standard (m3u8)'} - FILE (Kika.de) *****")
	if not FINAL_URL and SELECTION:
		kika_link = f"https:{SELECTION[0]['url']}" if SELECTION[0]['url'][:4] != 'http' else SELECTION[0]['url']
		STREAM, FINAL_URL = 'MP4', kika_link
		debug_MS(f"(resolver.kika_contents[3]) ***** TAKE - (mp4) - FILE (Kika.de) : {kika_link} *****")
	return playRESOLVED(FINAL_URL, STREAM, 'KiKA', 'KiKA - Intern')

def zdf_contents(video_origin):
	debug_MS("(resolver.zdf_contents) ------------------------------------------------ START = zdf_contents -----------------------------------------------")
	DATA_ONE, teaser, token, video_found = (False for _ in range(4))
	video_origin = video_origin.replace('https://zdf.de', 'https://www.zdf.de').replace('https://www.zdfheute.de', 'https://www.zdf.de')
	section_one = track_content(video_origin, 'GET', 'TEXT', WEB_HEADER).replace('\\', '')
	zdf_player = re.compile(r'''(?s)data-zdfplayer-jsb=["'](?P<json>{.+?})["']''', re.S).findall(section_one)
	if zdf_player:
		player_uno = json.loads(zdf_player[0])
		teaser, token = player_uno['content'], player_uno['apiToken']
		ready = API_ZDF_OLD+teaser if teaser[:4] != 'http' else teaser
		debug_MS(f"(resolver.zdf_contents[2.1]) API_ZDF_OLD ##### VIDEO_FOUND : {ready} || SECRET : {token} #####")
		DATA_ONE = track_content(ready, headers={**WEB_HEADER, **{'Api-Auth': f"Bearer {token}"}})
	elif not zdf_player:
		template = re.compile(r'''["']__typename["']:["']VodMedia["'],["']ptmdTemplate["']:["']([^"']+)["'],["']vodMediaType["']:["']DEFAULT["'],''', re.S).findall(section_one)
		targical = re.compile(r'''["']target_video_id["']:["']([^"']+)["'],["']target_sophora_id["']''', re.S).findall(section_one)
		sophora = re.compile(r'''["']page_sophora_id["']:["']([^"']+)["'],["']page_type["']:["']Video["'],''', re.S).findall(section_one)
		vapitoks = re.compile(r'''["']tokens["']:\{["']videoToken["']:\{["']apiToken["']:["']([^"']+)["'],''', re.S).findall(section_one)
		if template and '/ptmd/' in template[0] and vapitoks:
			start_link = 'https://api.3sat.de' if video_origin.startswith('https://www.3sat.de') else API_ZDF_OLD
			video_found = start_link+template[0].replace('{playerId}', 'ngplayer_2_5').replace('\/', '/')
			debug_MS(f"(resolver.zdf_contents[2.2]) EXTRACTED ##### VIDEO_FOUND : {video_found} || SECRET : {vapitoks[0]} #####")
			return zdf_extractors(video_found, vapitoks[0])
		elif (targical or sophora) and vapitoks:
			video_found = f"{API_ZDF_NEW}/document/{targical[0]}" if targical else f"{API_ZDF_NEW}/document/{sophora[0]}"
			debug_MS(f"(resolver.zdf_contents[2.3]) EXTRACTED ##### VIDEO_FOUND : {video_found} || SECRET : {vapitoks[0]} #####")
			return zdf_extractors(video_found, vapitoks[0])
	if DATA_ONE and DATA_ONE.get('contentType') in ['clip', 'episode'] and not DATA_ONE.get('profile') == 'http://zdf.de/rels/not-found':
		start_link = 'https://api.3sat.de' if teaser and teaser.startswith('https://api.3sat.de') else API_ZDF_OLD if teaser and teaser.startswith(API_ZDF_OLD) else ""
		basis = DATA_ONE['mainVideoContent']['http://zdf.de/rels/target']
		default = DATA_ONE['mainVideoContent']['http://zdf.de/rels/target']['streams']['default'] if basis.get('streams', '') and basis['streams'].get('default', '') else basis
		video_found = start_link+default['http://zdf.de/rels/streams/ptmd-template'].replace('{playerId}', 'ngplayer_2_5').replace('\/', '/')
		debug_MS(f"(resolver.zdf_contents[3]) EXTRACTED ##### VIDEO_FOUND : {video_found} || SECRET : {token} #####")
		return zdf_extractors(video_found, token) if start_link != "" else zdf_extractors(video_found, None)
	if video_found is False:
		failing("(resolver.zdf_contents) AbspielLink-00 (ZDF+3) : *ZDF-Intern* Der angeforderte -VideoLink- existiert NICHT !!!")
		log("(resolver.zdf_contents) --- ENDE WIEDERGABE ANFORDERUNG ---")
		dialog.notification(translation(30521).format('ZDF - Intern'), translation(30529), icon, 10000)

def zdf_extractors(section_three, token):
	debug_MS("(resolver.zdf_extractors) ------------------------------------------------ START = zdf_extractors -----------------------------------------------")
	DATA_TWO = track_content(section_three, headers={**WEB_HEADER, **{'Api-Auth': f"Bearer {token}"}}) if token else track_content(section_three, headers=WEB_HEADER)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(resolver.zdf_extractors[1]) XXXXX CONTENT-01 : {DATA_TWO} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	(MASTERS, MEDIAS), (UNIKAT_UNO, UNIKAT_DUE), (STREAM, FINAL_URL) = ([] for _ in range(2)), (set() for _ in range(2)), (False for _ in range(2))
	M3U8_QUALITIES, MPP4_QUALITIES = ['auto', 'veryhigh', 'high', 'med'], ['uhd', 'fhd', 'hd', 'veryhigh', 'high', 'low']
	if DATA_TWO is not None and DATA_TWO.get('priorityList', []) and len(DATA_TWO['priorityList']) > 0:
		for each in DATA_TWO.get('priorityList', []):
			formitaeten = each.get('formitaeten')
			if not isinstance(formitaeten, list):
				continue
			for item in formitaeten:
				if item.get('type') == 'h264_aac_ts_http_m3u8_http' and item.get('mimeType').lower() in ['application/x-mpegurl', 'application/vnd.apple.mpegurl']:
					for found in M3U8_QUALITIES:
						for shorties in item.get('qualities', []):
							if shorties.get('quality') == found and shorties.get('quality') not in UNIKAT_UNO:
								UNIKAT_UNO.add(shorties['quality'])
								MASTERS.append({'url': shorties['audio']['tracks'][0]['uri'], 'quality': shorties['quality'], 'mimeType': item.get('mimeType').lower(), 'language': shorties['audio']['tracks'][0]['language']})
				if item.get('type') == 'h264_aac_mp4_http_na_na' and 'progressive' in item.get('facets', []) and item.get('mimeType').lower() == 'video/mp4':
					for found in MPP4_QUALITIES:
						for shorties in item.get('qualities', []):
							if shorties.get('quality') == found and shorties.get('quality') not in UNIKAT_DUE:
								UNIKAT_DUE.add(shorties['quality'])
								MEDIAS.append({'url': shorties['audio']['tracks'][0]['uri'], 'quality': shorties['quality'], 'mimeType': item.get('mimeType').lower(), 'language': shorties['audio']['tracks'][0]['language']})
		debug_MS(f"(resolver.zdf_extractors[2.1]) SORTED_LIST | M3U8 ### MASTER : {MASTERS} ###")
		debug_MS(f"(resolver.zdf_extractors[2.1]) SORTED_LIST | MPP4 ### MEDIAS : {MEDIAS} ###")
	elif DATA_TWO is not None and DATA_TWO.get('document', {}) and DATA_TWO['document'].get('formitaeten', []) and len(DATA_TWO['document']['formitaeten']) > 0:
		for item in DATA_TWO['document'].get('formitaeten', []):
			if item.get('type') == 'h264_aac_ts_http_m3u8_http' and item.get('class') == 'main' and item.get('mimeType').lower() in ['application/x-mpegurl', 'application/vnd.apple.mpegurl']:
				for found in M3U8_QUALITIES:
					if item.get('quality') == found and item.get('quality') not in UNIKAT_UNO:
						UNIKAT_UNO.add(item['quality'])
						MASTERS.append({'url': item['url'], 'quality': item['quality'], 'mimeType': item.get('mimeType').lower(), 'language': item['language']})
			if item.get('type') == 'h264_aac_mp4_http_na_na' and item.get('class') == 'main' and item.get('mimeType').lower() == 'video/mp4':
				for found in MPP4_QUALITIES:
					if item.get('quality') == found and item.get('quality') not in UNIKAT_DUE:
						UNIKAT_DUE.add(item['quality'])
						MEDIAS.append({'url': item['url'], 'quality': item['quality'], 'mimeType': item.get('mimeType').lower(), 'language': item['language']})
		debug_MS(f"(resolver.zdf_extractors[2.2]) SORTED_LIST | M3U8 ### MASTER : {MASTERS} ###")
		debug_MS(f"(resolver.zdf_extractors[2.2]) SORTED_LIST | MPP4 ### MEDIAS : {MEDIAS} ###")
	if (enable_adaptive or prefer_stream == 0) and MASTERS:
		STREAM, FINAL_URL = 'HLS' if enable_adaptive else 'M3U8', MASTERS[0]['url']
		debug_MS(f"(resolver.zdf_extractors[3]) ***** TAKE - {'Inputstream (hls)' if STREAM == 'HLS' else 'Standard (m3u8)'} - FILE (Zdf.de+3) *****")
	if not FINAL_URL and MEDIAS:
		STREAM, FINAL_URL = 'MP4', improve_video(MEDIAS[0]['url'], station='DasZweite') # *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
		debug_MS(f"(resolver.zdf_extractors[3]) ***** TAKE - (mp4) - FILE (Zdf.de+3) : {MEDIAS[0]['url']} *****")
	return playRESOLVED(FINAL_URL, STREAM, 'ZDF+3', 'ZDF - Intern')

def improve_video(highest, station=False):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen // aktualisiert am 23.11.2024
	standards = [highest, '', '', ''] # Seite zur Überprüfung : https://github.com/mediathekview/MServer/blob/master/src/main/java/mServer/crawler/sender/zdf/ZdfVideoUrlOptimizer.java
	if station == 'DasErste':
		route_one = (('/960', '/1280'), ('.l.mp4', '.xl.mp4'), ('_C.mp4', '_X.mp4'))
		route_two = (('/1280', '/1920'), ('_X.mp4', '_HD.mp4'), ('x720-50p-3200kbit.mp4', 'x1080-50p-5000kbit.mp4'), ('.hd.mp4', '.1080.mp4'), ('hd1080-avc720.mp4', 'hd1080-avc1080.mp4'))
		route_tree = (('/1920', '/3840'), ('_P.mp4', '_H.mp4'), ('.xl.mp4', '.xxl.mp4'))
	elif station == 'DasZweite':
		route_one = (('808k_p11v15', '2360k_p35v15'), ('1456k_p13v11', '2328k_p35v11'), ('1456k_p13v12', '2328k_p35v12'), ('1496k_p13v13', '2328k_p35v13'), ('1496k_p13v14', '2328k_p35v14'), ('1628k_p13v15', '2360k_p35v15'),
								('1628k_p13v17', '2360k_p35v17'), ('2256k_p14v11', '2328k_p35v11'), ('2256k_p14v12', '2328k_p35v12'), ('2296k_p14v13', '2328k_p35v13'), ('2296k_p14v14', '2328k_p35v14'))
		route_two = (('2328k_p35v12', '3328k_p36v12'), ('2328k_p35v13', '3328k_p36v13'), ('2328k_p35v14', '3328k_p36v14'), ('2360k_p35v15', '3360k_p36v15'), ('2360k_p35v17', '3360k_p36v17'))
		route_tree = (('3360k_p36v15', '4692k_p72v16'), ('3360k_p36v17', '6660k_p37v17'))
	standards[1] = reduce(lambda m, kv: m.replace(*kv), route_one, standards[0])
	standards[2] = reduce(lambda n, kv: n.replace(*kv), route_two, standards[1])
	standards[3] = reduce(lambda o, kv: o.replace(*kv), route_tree, standards[2])
	if standards[0] not in [standards[1], standards[2], standards[3]]:
		for xy, element in enumerate(reversed(standards), 1):
			try:
				code = urlopen(element, timeout=6).getcode()
				if code in [200, 201, 202]:
					return element
			except: pass
	return highest

def playRESOLVED(END_URL, PROTOCOL, MARKING, NOTE, MIME='application/vnd.apple.mpegurl', DRM_GUARD=False):
	if END_URL and PROTOCOL:
		LPM = xbmcgui.ListItem(path=END_URL, offscreen=True)
		if plugin_operate('inputstream.adaptive') and PROTOCOL in ['HLS', 'MPD']:
			IA_NAME, IA_SYSTEM, DRM_SPECIES = 'inputstream.adaptive', 'com.widevine.alpha', None
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			DRM_HEADERS = {'User-Agent': WEB_AGENT, 'Content-Type': 'application/octet-stream'} if DRM_GUARD else {}
			LPM.setMimeType(MIME); LPM.setContentLookup(False); LPM.setProperty('inputstream', IA_NAME)
			if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", PROTOCOL.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
			LPM.setProperty(f"{IA_NAME}.{PHRASE}_headers", f"User-Agent={WEB_AGENT}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
			if int(IA_VERSION) >= 2150 and PROTOCOL in ['HLS', 'MPD']:
				DRM_SPECIES = {'DRM_System': 'org.w3.clearkey'} if PROTOCOL == 'HLS' else {'DRM_System': IA_SYSTEM}
				if PROTOCOL == 'MPD' and DRM_GUARD:
					DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS)}
				LPM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
			elif int(IA_VERSION) < 2150 and PROTOCOL == 'MPD':
				LPM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
				if DRM_GUARD:
					DRM_SPECIES = {'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS), 'Post_Data': 'R{SSM}|'}
					LPM.setProperty(f"{IA_NAME}.license_key", '|'.join(DRM_SPECIES.values())) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
			if DRM_SPECIES: log(f"(resolver.playRESOLVED) INPUTSTREAM_VERSION: {IA_VERSION} >>>>> LICENSE : {'|'.join(DRM_SPECIES.values())} <<<<<")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		log(f"(resolver.playRESOLVED) END-AbspielLink ({MARKING}) : {PROTOCOL}_stream : {END_URL}")
	else:
		failing(f"(resolver.playRESOLVED) AbspielLink-00 ({MARKING}) : *{NOTE}* Der angeforderte -VideoLink- existiert NICHT !!!")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		xbmc.PlayList(1).clear()
		dialog.notification(translation(30521).format(NOTE), translation(30529), icon, 10000)
	log("(resolver.playRESOLVED) --- ENDE WIEDERGABE ANFORDERUNG ---")
