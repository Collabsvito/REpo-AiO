﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2020 realvito

    Anime on Demand

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os
import xbmc
import xbmcaddon
import xbmcvfs
import shutil
from datetime import datetime
from resources.lib.common import *
from resources.lib import navigator


def run():
	SEP = os.sep
	if mode == 'root':
		DONE = False
		firstSCRIPT = xbmc.translatePath(os.path.join('special://home'+SEP+'addons'+SEP+'plugin.video.aod'+SEP+'lib'+SEP)).encode('utf-8').decode('utf-8')
		UNO = os.path.join(firstSCRIPT, 'only_at_FIRSTSTART')
		if xbmcvfs.exists(UNO):
			addon.setSetting('select_start', '0')
			sourceUSER = xbmc.translatePath(os.path.join('special://home'+SEP+'userdata'+SEP+'addon_data'+SEP+'plugin.video.aod'+SEP)).encode('utf-8').decode('utf-8')
			if xbmcvfs.exists(sourceUSER):
				try:
					xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid":"'+addon_id+'", "enabled":false}, "id":1}')
					shutil.rmtree(sourceUSER, ignore_errors=True)
					debug_MS("(default.run=onlyFISRTTIME) ### xbmcvfs.delete(UNO) - ADDON AUSSCHALTEN + USERDATA-Path entfernen ###")
				except: pass
				xbmcvfs.delete(UNO)
				xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid":"'+addon_id+'", "enabled":true}, "id":1}')
				debug_MS("(default.run=onlyFISRTTIME) ### xbmc.executebuiltin('Container.Refresh') - ADDON WIEDER EINSCHALTEN ###")
				xbmc.sleep(500)
				DONE = True
			else:
				xbmcvfs.delete(UNO)
				xbmc.sleep(500)
				DONE = True
		else:
			DONE = True
		if addon.getSetting('service_startWINDOW') == 'true' and DONE is True:
			lastHM = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
			addon.setSetting('last_starttime', lastHM+' / 01')
			SOLVED = navigator.Callonce().call_registration(lastHM)
			if SOLVED is True:
				addon.setSetting('service_startWINDOW', 'false')
			debug_MS("(default.run) ### settings_service_startWINDOW is now = {0} ###".format(str(addon.getSetting('service_startWINDOW'))))
		if DONE is True: navigator.mainMenu()
	elif mode == 'logout':
		navigator.want_Logout()
	elif mode == 'newsCategory':
		navigator.newsCategory()
	elif mode == 'listAnimeNews':
		navigator.listAnimeNews(url)
	elif mode == 'listArticle':
		navigator.listArticle(url)
	elif mode == 'newOverview':
		navigator.newOverview(url)
	elif mode == 'listAlphabet':
		navigator.listAlphabet()
	elif mode == 'listGenres':
		navigator.listGenres(url)
	elif mode == 'listLanguages':
		navigator.listLanguages()
	elif mode == 'listSeries':
		navigator.listSeries(url)
	elif mode == 'listSimilar':
		navigator.listSimilar(url)
	elif mode == 'listEpisodes':
		navigator.listEpisodes(url, cineType, origSERIE)
	elif mode == 'playCODE':
		navigator.playCODE(IDENTiTY)
	elif mode == 'listShowsFavs':
		navigator.listShowsFavs()
	elif mode == 'favs':
		navigator.favs(url)
	elif mode == 'aSettings':
		navigator.addon.openSettings()
	elif mode == 'iSettings':
		navigator.xbmcaddon.Addon('inputstream.adaptive').openSettings()

run()
