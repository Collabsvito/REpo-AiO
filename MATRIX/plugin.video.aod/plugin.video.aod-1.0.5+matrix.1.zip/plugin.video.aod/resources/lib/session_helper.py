﻿# -*- coding: utf-8 -*-

import sys
from os import path
import re
import xbmc
import xbmcaddon
import xbmcvfs
import shutil
from datetime import datetime
from requests import session, utils, exceptions
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
else: 
	from urllib.parse import urlencode  # Python 3.X
try: import cPickle as pickle
except: import pickle
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from .common import *
from .config import Registration


class Transmission(object):

	def __init__(self):
		self.config = Registration
		self.maxSessionTime = 360 * 60 # max. Session-Time (Seconds) before clear the Session and delete Session-File [60*60 = 1 hour | 360*60 = 6 hours | 720*60 = 12 hours]
		self.tempSE_folder = tempCE
		self.session_file = cookieFile
		self.verify_ssl = (True if addon.getSetting('verify_ssl') == 'true' else False)
		self.crsf_TOKEN = addon.getSetting('csrftoken')
		self.session = session()
		self.load_session()

	def clear_session(self):
		debug_MS("(session_helper.clear_session) ### START clear_session ###")
		if self.session_file is not None and path.isfile(self.session_file):
			if xbmcvfs.exists(self.tempSE_folder) and path.isdir(self.tempSE_folder):
				shutil.rmtree(self.tempSE_folder, ignore_errors=True)
				xbmc.sleep(500)
			self.session.cookies.clear_session_cookies()

	def save_session(self):
		debug_MS("(session_helper.save_session) ### START save_session ###")
		if not xbmcvfs.exists(self.tempSE_folder) and not path.isdir(self.tempSE_folder):
			xbmcvfs.mkdirs(self.tempSE_folder)
		with open(self.session_file, 'wb') as input:
			pickle.dump(utils.dict_from_cookiejar(self.session.cookies), input)

	def load_session(self):
		debug_MS("(session_helper.load_session) ### START load_session ###")
		if addon.getSetting('without_Account') == 'false':
			if self.session_file is not None and path.isfile(self.session_file):
				debug_MS("(session_helper.load_session) ##### addon.getSetting - without_Account = FALSE || Fortsetzung jetzt mit SESSION-COOKIES #####")
				try:
					with open(self.session_file, 'rb') as output:
						_cookies = utils.cookiejar_from_dict(pickle.load(output))
				except:
					debug_MS("(session_helper.load_session) ##### ERROR = load_session (Pickle-ERROR) #####")
					self.renewal_login()
				if hasattr(self, 'retrieveContent'):
					self.session.cookies = _cookies
			else:
				debug_MS("(session_helper.load_session) ##### ERROR = load_session (KEIN Session-File-ERROR) #####")
				self.renewal_login()
		else:
			debug_MS("(session_helper.load_session) ##### addon.getSetting - without_Account = TRUE || Fortsetzung jetzt ohne Anmeldung #####")

	def modification_date(self, filename):
		last = path.getmtime(filename)
		return datetime.fromtimestamp(last)

	def renewal_login(self):
		lastHM = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
		addon.setSetting('last_starttime', lastHM+' / 02')
		if self.config().has_credentials():
			USER, PWD = self.config().get_credentials()
		else:
			USER, PWD = self.config().save_credentials()
		return self.login(USER, PWD, forceLogin=True)

	def login(self, username, password, forceLogin=False):
		debug_MS("(session_helper.login) ##### START ...login-PROCESS - forceLogin = {0} #####".format(str(forceLogin)))
		if forceLogin is False and self.session_file is not None and path.isfile(self.session_file):
			mod_time = self.modification_date(self.session_file)
			lastModification = (datetime.now() - mod_time).seconds
			if lastModification < self.maxSessionTime:
				return True
			else:
				self.clear_session()
		payload = {}
		headers = self.load_header(REF=BASE_URL, CALL_PRO='Standard')
		standard_res = self.session.get(LOGIN_LINK, verify=self.verify_ssl, headers=headers)
		auth_token = re.findall(r'name="authenticity_token" value="([^"]+)"', standard_res.text, re.S)[0]
		payload['utf8'] = '&#x2713;'
		payload['user[login]'] = username
		payload['user[password]'] = password
		payload['user[remember_me]'] = 1
		payload['commit'] = 'Einloggen'
		payload['authenticity_token'] = auth_token
		login_res = self.session.post(LOGIN_LINK, verify=self.verify_ssl, headers=headers, data=payload)
		index_logged_IN = re.search(r'<a href="/users/edit">Benutzerkonto</a>', login_res.text)
		if index_logged_IN:
			debug_MS("(session_helper.login) ##### !!! DU BIST ERFOLGREICH EINGELOGGT !!! #####")
			addon.setSetting('login_successfully', 'true')
			self.save_session()
			return True
		else:
			debug_MS("(session_helper.login) ##### ERROR = DU BIST NICHT EINGELOGGT = ERROR #####")
			addon.setSetting('login_successfully', 'false')
			addon.setSetting('show_teaser', 'true')
			self.clear_session()
		return False

	def logout(self):
		debug_MS("(session_helper.logout) ### START logout the Session... ###")
		self.clear_session()
		headers = self.load_header(REF=BASE_URL, CALL_PRO='Standard')
		logout_res = self.session.get(BASE_URL, verify=self.verify_ssl, headers=headers)
		index_logged_OUT = re.search(r'<a href="/users/edit">Benutzerkonto</a>', logout_res.text)
		if not index_logged_OUT:
			debug_MS("(session_helper.logout) ##### !!! DIE SESSION WURDE ERFOLGREICH BEENDET !!! #####")
			addon.setSetting('login_successfully', 'false')
			return True
		return False

	def load_header(self, REF, CALL_PRO):
		if REF is 'Unknown':
			HEADERS = self.session.headers.update({'User-Agent': get_userAgent()})
		else:
			HEADERS = self.session.headers.update({'User-Agent': get_userAgent(), 'Referer': REF})
		if CALL_PRO == 'playCODE' :
			HEADERS = self.session.headers.update({'X-CSRF-Token': self.crsf_TOKEN, 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json, text/javascript, */*; q=0.01'})
		return HEADERS

	def retrieveContent(self, url, method='GET', direct=False, CALL_PRO='Standard', REF='Unknown', headers=None, cookies=None, allow_redirects=True, stream=None, data=None):
		if headers is None:
			headers = self.load_header(REF, CALL_PRO)
		try:
			if method == 'GET':
				response = self.session.get(url, headers=headers, allow_redirects=allow_redirects, verify=self.verify_ssl, stream=stream, timeout=30).text
				response = py2_enc(response)
			elif method == 'POST':
				response = self.session.post(url, headers=headers, allow_redirects=allow_redirects, verify=self.verify_ssl, data=data, timeout=30)
		except exceptions.RequestException as e:
			failure = str(e)
			failing("(retrieveContent) ERROR - ERROR - ERROR : ##### {0} === {1} #####".format(url, failure))
			dialog.notification(translation(30521).format('URL'), "ERROR = [COLOR red]{0}[/COLOR]".format(failure), icon, 12000)
			response = ""
			return sys.exit(0)
		return response
