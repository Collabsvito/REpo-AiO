﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2020 realvito

    Anime on Demand

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from __future__ import unicode_literals
from datetime import datetime
from resources.lib.common import *
from resources.lib import navigator


def run():
	if mode == 'root':
		if addon.getSetting('service_startUP') == 'true':
			lastHM = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
			addon.setSetting('last_starttime', lastHM+' / 01')
			SOLVED = navigator.Callonce().call_registration(lastHM)
			if SOLVED is True:
				debug_MS("(default.run) ### settings_service_startUP = FALSE ###")
				addon.setSetting('service_startUP', 'false')
		navigator.mainMenu()
	elif mode == 'logout':
		navigator.want_Logout()
	elif mode == 'newsCategory':
		navigator.newsCategory()
	elif mode == 'listAnimeNews':
		navigator.listAnimeNews(url)
	elif mode == 'listArticle':
		navigator.listArticle(url)
	elif mode == 'newOverview':
		navigator.newOverview(url)
	elif mode == 'listAlphabet':
		navigator.listAlphabet()
	elif mode == 'listGenres':
		navigator.listGenres(url)
	elif mode == 'listLanguages':
		navigator.listLanguages()
	elif mode == 'listSeries':
		navigator.listSeries(url)
	elif mode == 'listSimilar':
		navigator.listSimilar(url)
	elif mode == 'listEpisodes':
		navigator.listEpisodes(url, cineType, origSERIE)
	elif mode == 'playCODE':
		navigator.playCODE(IDENTiTY)
	elif mode == 'listShowsFavs':
		navigator.listShowsFavs()
	elif mode == 'favs':
		navigator.favs(url)
	elif mode == 'aSettings':
		navigator.addon.openSettings()
	elif mode == 'iSettings':
		navigator.xbmcaddon.Addon('inputstream.adaptive').openSettings()

run()
