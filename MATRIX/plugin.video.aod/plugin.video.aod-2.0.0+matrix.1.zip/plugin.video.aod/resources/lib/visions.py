﻿# -*- coding: utf-8 -*-

import re
import xbmc
import xbmcgui
import pyxbmct

from .common import *

SIZE_WIDTH_pyxbmct = 1080 # 16:9 # maximum (pyxbmct)= 1280
SIZE_HEIGHT_pyxbmct = 608 # 16:9 # maximum (pyxbmct) = 720
FROM_TOP = 30 # 30
FROM_SIDE = 11 # 11


class Infowindow(pyxbmct.AddonDialogWindow):
	def __init__(self, content=''):
		self.image = ""
		self.starttext = ""
		self.plottext = ""
		self.trailer = ""
		SIZESCREEN_HEIGHT = xbmcgui.getScreenHeight()  # example  # 1080
		SIZESCREEN_WIDTH = xbmcgui.getScreenWidth()  # 1920
		# window of axes X and Y
		self.screenx = SIZESCREEN_WIDTH
		self.screeny = SIZESCREEN_HEIGHT
		# set to don't over the max pyxbmct
		if self.screenx > SIZE_WIDTH_pyxbmct:
			self.screenx = SIZE_WIDTH_pyxbmct
			self.screeny = SIZE_HEIGHT_pyxbmct
		HEADLINE = re.compile('<h1 style="margin: 0;">(.+?)</h1>', re.S).findall(content)[0]
		self.topline = '[B]'+cleaning(HEADLINE)+'[/B]'
		PHOTO = re.compile('class="newspic" src="(.+?)"', re.S).findall(content)
		if PHOTO: 
			self.image = PHOTO[0]
			self.image = BASE_URL+self.image if self.image[:4] != "http" else self.image
		DESCRIPTION = re.findall('<div class="article-text">(.+?)</div>', content, re.S)[0]
		if '<table ' in DESCRIPTION: 
			self.starttext = content
			DESCRIPTION = DESCRIPTION[:DESCRIPTION.find('<table ')]
		DESCRIPTION = cleaning(DESCRIPTION).replace('</p>', '\n')
		part = DESCRIPTION.split('\n')
		for i in range(1,len(part),1):
			entry = part[i]
			if not 'img alt=' in entry and not 'iframe ' in entry and not '<p>Vom ' in entry:
				entry = entry.replace('<br />', '\n').replace('</li>', '\n')
				entry = re.sub(r'\<.*?\>', '', entry)
				self.plottext = self.plottext+entry
		TRAILER = re.compile('src="https://www.youtube.com/embed/([^"]+?)"', re.S).findall(content)
		if TRAILER:
			self.trailer = TRAILER[0].split('?')[0]
		# pyxbmct :
		super(Infowindow, self).__init__('[B]NEWS[/B]')
		self.setGeometry(self.screenx , self.screeny , FROM_TOP, FROM_SIDE)
		debug_MS("(visions.__init__) ### Size of Screen fix to (pyxbmct.AddonDialogWindow) : {0} x {1} ###".format(str(self.screenx),str(self.screeny)))
		self.set_info_controls()
		# Connect a key action (Backspace) to close the window
		self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

	def set_info_controls(self):
		self.headline = pyxbmct.Label(self.topline, alignment=pyxbmct.ALIGN_CENTER)
		self.placeControl(self.headline, 0, 0, rowspan=1, columnspan=11)
		if not '<tbody>' in self.starttext:
			if self.image == "" and self.trailer != "":
				self.image = 'https://img.youtube.com/vi/'+self.trailer+'/hqdefault.jpg'
			self.image = pyxbmct.Image(self.image, aspectRatio=4)
			self.placeControl(self.image, 1, 4, rowspan=6, columnspan=3)
			self.description = pyxbmct.TextBox()
			self.placeControl(self.description, 7, 0, rowspan=20, columnspan=11)
			self.description.setText(self.plottext)
			self.description.autoScroll(7000, 4000, 7000)
			################################################################################
			# Funktion zum Abspielen von Trailern ist wegen eines Defektes des Addons : script.module.pyxbmct - entfernt (Absturz von KODI) #
			################################################################################
			#if self.trailer !="":
				#self.play_button = pyxbmct.Button('[B]Trailer[/B]', font='font14')
				#self.placeControl(self.play_button, 28, 0, rowspan=3, columnspan=3)
				#self.connect(self.play_button, self.playTrailer)
			self.close_button = pyxbmct.Button('[B]Close[/B]', font='font14')
			self.placeControl(self.close_button, 28, 8, rowspan=3, columnspan=3)
			self.connect(self.close_button, self.close)
			self.setFocus(self.close_button)
		else:
			self.description = pyxbmct.FadeLabel()
			self.placeControl(self.description, 1, 0, rowspan=2, columnspan=11)
			self.description.addLabel(self.plottext)
			ADDITIONAL = re.findall('<tbody>(.+?)</tbody>', self.starttext, re.S)[0].replace('\n', '')
			topx = 3
			lefty = 0
			counter1 = 0
			counter2 = 0
			sp1 = ADDITIONAL.split('</tr>')
			for i1 in range(0,len(sp1),1):
				item = sp1[i1]
				item = item.replace('<br />', '###')
				match = re.compile('>(.+?)</td>', re.S).findall(item)
				for field in match:
					field = cleaning(field)
					field = re.sub(r'\<.*?\>', '', field)
					stretch = 5 if len(field) > 19 else 0
					if '###' in field:
						sp2 = field.split('###')
						for i2 in range(0,len(sp2),1):
							entry = sp2[i2]
							self.additional = pyxbmct.Label(entry, font='font10')
							self.placeControl(self.additional, topx, lefty, rowspan=2, columnspan=2+stretch)
							topx += 1
							counter1 += 1
						topx = topx-counter1
						if counter2 < counter1:
							counter2 = counter1-1
						counter1 = 0
						lefty = lefty+2+stretch
					else:
						self.additional = pyxbmct.Label(field, font='font10', textColor='0xFF00FF00') # COLOR = green1 ~ 00FF00 (Hex=0xFF00FF00)
						self.placeControl(self.additional, topx, lefty, rowspan=8, columnspan=2+stretch)
						lefty = lefty+2+stretch
				topx = topx+1+counter2
				counter2 = 0
				lefty = 0
				self.close_button = pyxbmct.Button('[B]Close[/B]', font='font14')
				self.placeControl(self.close_button, 28, 8, rowspan=3, columnspan=3)
				self.connect(self.close_button, self.close)
				self.setFocus(self.close_button)
		self.connectEventList([pyxbmct.ACTION_MOVE_LEFT,
			pyxbmct.ACTION_MOVE_RIGHT,
			pyxbmct.ACTION_MOUSE_DRAG,
			pyxbmct.ACTION_MOUSE_LEFT_CLICK],
			self.leftright)

	def playTrailer(self):
		self.close()
		finalURL = 'plugin://plugin.video.youtube/play/?video_id='+self.trailer
		log("(visions.playTrailer) ### THIS IS THE TRAILER-URL = {0} ###".format(str(finalURL)))
		listitem = xbmcgui.ListItem(path=finalURL)
		listitem.setProperty('IsPlayable', 'true')
		xbmc.Player().play(item=finalURL, listitem=listitem)

	def leftright(self):
		if self.trailer != "":
			if self.getFocus() == self.close_button:
				self.setFocus(self.play_button)
			elif self.getFocus() == self.play_button:
				self.setFocus(self.close_button)
		else:
			self.setFocus(self.close_button)
