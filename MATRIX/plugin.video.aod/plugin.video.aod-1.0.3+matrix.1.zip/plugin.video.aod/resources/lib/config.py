﻿# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import base64
import uuid
from platform import node
from Cryptodome.Cipher import DES3
from Cryptodome.Util.Padding import pad, unpad

from .common import *


class Registration(object):

	def __init__(self):
		self.username = addon.getSetting('username')
		self.password = addon.getSetting('password')
		self.WantEncrypt = addon.getSetting('encrypt_credentials')

	def get_mac_key(self):
		debug_MS("(config.get_mac_key) ### START get_mac_key ###")
		mac = uuid.getnode()
		if (mac >> 40) % 2:
			mac = node()
		return uuid.uuid5(uuid.NAMESPACE_DNS, str(mac)).bytes

	def vers_encrypt(self, data):
		k = DES3.new(self.get_mac_key(), DES3.MODE_CBC, iv=b'\0\0\0\0\0\0\0\0')
		d = k.encrypt(pad(data.encode('utf-8'), DES3.block_size))
		return base64.b64encode(d)

	def vers_decrypt(self, data):
		if not data:
			return ""
		data += "=" * ((4 - len(data) % 4) % 4) # FIX for = TypeError: Incorrect padding
		k = DES3.new(self.get_mac_key(), DES3.MODE_CBC, iv=b'\0\0\0\0\0\0\0\0')
		try:
			d = unpad(k.decrypt(base64.b64decode(data)), DES3.block_size)
			return d.decode('utf-8')
		except:
			dialog.notification(translation(30521).format('Login'), translation(30529), icon, 12000)
			self.clear_credentials()
			return ""

	def has_credentials(self):
		debug_MS("(config.has_credentials) ### START has_credentials ###")
		return self.username != "" or self.password != ""

	def get_credentials(self):
		debug_MS("(config.get_credentials) ### START get_credentials ###")
		if self.WantEncrypt == 'true':
			return (self.vers_decrypt(self.username), self.vers_decrypt(self.password))
			#return (bytes.decode(self.vers_decrypt(self.username)), bytes.decode(self.vers_decrypt(self.password)))
		return (self.username, self.password)

	def save_credentials(self):
		debug_MS("(config.save_credentials) ### START save_credentials ###")
		USER = dialog.input(translation(30641), type=xbmcgui.INPUT_ALPHANUM)
		PASSWORD = dialog.input(translation(30642), type=xbmcgui.INPUT_ALPHANUM)
		if self.WantEncrypt == 'true':
			_user = self.vers_encrypt(USER) if USER != '' else USER
			_code = self.vers_encrypt(PASSWORD) if PASSWORD != '' else PASSWORD
			debug_MS("(config.save_credentials) XXX encrypt-USER : {0} || encrypt-PASSWORD : {1} XXX".format(_user, _code))
		else:
			_user = USER
			_code = PASSWORD
			debug_MS("(config.save_credentials) XXX standard-USER : {0} || standard-PASSWORD : {1} XXX".format(_user, _code))
		addon.setSetting('username', _user)
		addon.setSetting('password', _code)
		return (USER, PASSWORD)

	def clear_credentials(self):
		debug_MS("(config.clear_credentials) ### START clear_credentials ###")
		USER, PASSWORD = '', ''
		addon.setSetting('username', USER)
		addon.setSetting('password', PASSWORD)
		return (USER, PASSWORD)
