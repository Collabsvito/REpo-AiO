﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcaddon
import xbmcvfs
import shutil
import time
import _strptime
from datetime import datetime, timedelta
import requests
try: import cPickle as pickle
except: import pickle
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from .common import *
from .config import Registration


class Transmission(object):

	def __init__(self):
		self.config = Registration
		self.maxSessionTime = 480 * 60 # max. Session-Time (Seconds) before clear the Session and delete Session-File [60*60 = 1 hour | 360*60 = 6 hours | 720*60 = 12 hours]
		self.tempSE_folder = tempCE
		self.session_file = cookieFile
		self.MEST = time.time() - (self.maxSessionTime) # Date and time now minus 'maxSessionTime'
		self.verify_ssl = (True if addon.getSetting('verify_ssl') == 'true' else False)
		self.crsf_TOKEN = addon.getSetting('csrftoken')
		self.session = requests.Session()
		self.load_session()

	def clear_session(self):
		debug_MS("(utilities.clear_session) ### START clear_session ###")
		if self.session_file is not None and os.path.isfile(self.session_file):
			if xbmcvfs.exists(self.tempSE_folder) and os.path.isdir(self.tempSE_folder):
				shutil.rmtree(self.tempSE_folder, ignore_errors=True)
				xbmc.sleep(500)
			self.session.cookies.clear_session_cookies()

	def save_session(self):
		debug_MS("(utilities.save_session) ### START save_session ###")
		if not xbmcvfs.exists(self.tempSE_folder) and not os.path.isdir(self.tempSE_folder):
			xbmcvfs.mkdirs(self.tempSE_folder)
		with open(self.session_file, 'wb') as input:
			pickle.dump(utils.dict_from_cookiejar(self.session.cookies), input)

	def load_session(self):
		debug_MS("(utilities.load_session) ### START load_session ###")
		if addon.getSetting('without_Account') == 'false':
			if self.session_file is not None and os.path.isfile(self.session_file):
				self.EPFT = os.path.getmtime(self.session_file)
				debug_MS("(utilities.load_session) ##### addon.getSetting - without_Account = FALSE || Fortsetzung jetzt mit SESSION-COOKIES #####")
				debug_MS("(utilities.load_session) ##### SESSION-File-Time (UTC grösser) = {0} || max-Time (UTC kleiner) = {1} #####".format(str(self.convert_epoch(self.EPFT)), str(self.convert_epoch(self.MEST))))
				if self.EPFT > self.MEST:
					try:
						with open(self.session_file, 'rb') as output:
							_cookies = utils.cookiejar_from_dict(pickle.load(output))
					except:
						debug_MS("(utilities.load_session) ##### !!! ERROR = SESSIONFILE (Pickle-ERROR) = ERROR !!! #####")
						self.clear_session()
						self.renewal_login()
					if hasattr(self, 'retrieveContent'):
						self.session.cookies = _cookies
				else:
					debug_MS("(utilities.load_session) ##### ERROR = load_session (KEIN Session-File-ERROR) #####")
					self.clear_session()
					self.renewal_login()
			else:
				debug_MS("(utilities.load_session) ##### NOTHING FOUND - CREATE SESSIONFILE #####")
				self.renewal_login()
		else:
			debug_MS("(utilities.load_session) ##### addon.getSetting - without_Account = TRUE || Fortsetzung jetzt ohne Account #####")

	def renewal_login(self):
		lastHM = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
		addon.setSetting('last_starttime', lastHM+' / 02')
		if self.config().has_credentials() is True:
			USER, PWD = self.config().get_credentials()
		else:
			USER, PWD = self.config().save_credentials()
		return self.login(USER, PWD, forceLogin=True)

	def convert_epoch(self, epoch):
		epochCipher = datetime(1970, 1, 1) + timedelta(seconds=int(epoch))
		return epochCipher.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')

	def login(self, username, password, forceLogin=False):
		debug_MS("(utilities.login) ##### START ...login-PROCESS - forceLogin = {0} #####".format(str(forceLogin)))
		if forceLogin is False and self.session_file is not None and os.path.isfile(self.session_file):
			self.EPFT = os.path.getmtime(self.session_file)
			debug_MS("(utilities.login) ##### SESSION-File-Time (UTC grösser) = {0} || max-Time (UTC kleiner) = {1} #####".format(str(self.convert_epoch(self.EPFT)), str(self.convert_epoch(self.MEST))))
			if self.EPFT > self.MEST:
				return True
		standard_res = self.retrieveContent(LOGIN_LINK, 'GET', REF=BASE_URL)
		auth_token = re.findall(r'name="authenticity_token" value="([^"]+)"', standard_res, re.S)[0]
		payload = {'utf8': '&#x2713;', 'user[login]': username, 'user[password]': password, 'user[remember_me]': 1, 'commit': 'Einloggen', 'authenticity_token': auth_token}
		login_res = self.retrieveContent(LOGIN_LINK, 'POST', data=payload)
		index_logged_IN = re.search(r'<a href="/users/edit">Benutzerkonto</a>', login_res.text)
		if index_logged_IN:
			debug_MS("(utilities.login) ##### !!! DU BIST ERFOLGREICH EINGELOGGT !!! #####")
			addon.setSetting('login_successfully', 'true')
			self.save_session()
			return True
		else:
			debug_MS("(utilities.login) ##### !!! ERROR = DU BIST NICHT EINGELOGGT = ERROR !!! #####")
			addon.setSetting('login_successfully', 'false')
			addon.setSetting('show_teaser', 'true')
			self.clear_session()
		return False

	def logout(self):
		debug_MS("(utilities.logout) ### START logout the Session... ###")
		self.clear_session()
		xbmc.sleep(1000)
		logout_res = self.retrieveContent(BASE_URL, 'GET', REF=BASE_URL)
		index_logged_OUT = re.search(r'<a href="/users/edit">Benutzerkonto</a>', logout_res)
		if not index_logged_OUT:
			debug_MS("(utilities.logout) ##### !!! DIE SESSION WURDE ERFOLGREICH BEENDET !!! #####")
			addon.setSetting('login_successfully', 'false')
			return True
		return False

	def load_header(self, REF, CALL_PRO):
		if REF == 'Unknown':
			HEADERS = self.session.headers.update({'User-Agent': get_userAgent()})
		else:
			HEADERS = self.session.headers.update({'User-Agent': get_userAgent(), 'Referer': REF})
		if CALL_PRO == 'playCODE' :
			HEADERS = self.session.headers.update({'X-CSRF-Token': self.crsf_TOKEN, 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json, text/javascript, */*; q=0.01'})
		return HEADERS

	def retrieveContent(self, url, method='GET', CALL_PRO='Standard', REF='Unknown', headers=None, cookies=None, allow_redirects=True, stream=None, data=None, json=None):
		if headers is None:
			headers = self.load_header(REF, CALL_PRO)
		try:
			if method == 'GET':
				response = self.session.get(url, headers=headers, allow_redirects=allow_redirects, verify=self.verify_ssl, stream=stream, timeout=30).text
				response = py2_enc(response)
			elif method == 'POST':
				response = self.session.post(url, headers=headers, allow_redirects=allow_redirects, verify=self.verify_ssl, data=data, json=json, timeout=30)
		except requests.exceptions.RequestException as e:
			failure = str(e)
			failing("(utilities.retrieveContent) ERROR - ERROR - ERROR : ##### {0} === {1} #####".format(url, failure))
			dialog.notification(translation(30521).format('URL'), "ERROR = [COLOR red]{0}[/COLOR]".format(failure), icon, 12000)
			return sys.exit(0)
		return response
