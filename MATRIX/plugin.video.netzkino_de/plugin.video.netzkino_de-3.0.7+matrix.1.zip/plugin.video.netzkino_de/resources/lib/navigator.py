﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	addDir(translation(30601), f"{artpic}watchlist.png", {'mode': 'listFavorites'})
	config = traversing.get_config()
	for pick in config['picks']:
		TITLE = pick['title']
		IDD = str(pick['id'])
		CAT_URL = config['CAT_ENTRIES'].format(IDD)
		addDir(TITLE, f"{artpic}{IDD}.png", {'mode': 'listVideos', 'url': CAT_URL, 'extras': TITLE, 'target': IDD})
	addDir(translation(30621), f"{artpic}genres.png", {'mode': 'listGenres'})
	addDir(translation(30622), f"{artpic}search.png", {'mode': 'SearchNETZKINO'})
	if enableADJUSTMENT:
		addDir(translation(30623), f"{artpic}settings.png", {'mode': 'aConfigs'}, folder=False)
		#if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			#addDir(translation(30624), f"{artpic}settings.png", {'mode': 'iConfigs'}, folder=False)
	#if not ADDON_operate('inputstream.adaptive'):
		#addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGenres():
	debug_MS("(navigator.listThemes) ------------------------------------------------ START = listThemes -----------------------------------------------")
	config = traversing.get_config()
	for genre in config['genres']:
		TITLE = genre['title']
		IDD = genre.get('id', None)
		PHOTO = config['CAT_THUMB'].format(IDD) if IDD else icon
		CAT_URL = config['CAT_ENTRIES'].format(IDD) if IDD else None
		if (approvedAGE is False and IDD and str(IDD) == '71') or (CAT_URL is None): continue
		addDir(TITLE, PHOTO, {'mode': 'listVideos', 'url': CAT_URL, 'extras': TITLE, 'target': IDD})
		debug_MS(f"(navigator.listGenres[1]) ### NAME : {TITLE} || GENRE-ID : {IDD} || IMAGE : { PHOTO} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(url, CAT, TARGET):
	debug_MS("(navigator.listVideos) ------------------------------------------------ START = listVideos -----------------------------------------------")
	counter, CAT, config = 0, re.sub('(\[B\]|\[/B\])', '', CAT), traversing.get_config()
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND = ([] for _ in range(3))
	STADIVISION = ['SEARCHING', '8', '81', '6611', '6621', '6801', '9431', '9441', '9471', '10633', '10643']
	GENDIVISION = ['1', '3', '4', '5', '6', '10', '18', '32', '35', '51', '71', '8951', '10333']
	debug_MS(f"(navigator.listVideos) ### URL = {url} ### CATEGORY = {CAT} ###")
	DATA_ONE = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listVideos[1]) XXXXX DATA_ONE-01 : {str(DATA_ONE)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	for post in DATA_ONE.get('posts', []):
		AIRED_1, BEGINS_1, STREAM_1, age, MPAA_1, IMDBLINK_1, YEAR_1, score, RATING_1, casting, quality, DURATION_1 = (None for _ in range(12))
		STAFF_1, DIRECTOR_1, GENRE_1 = ([] for _ in range(3))
		if 'Streaming' in post.get('custom_fields', {}) and not 'plus-exclusive' in post.get('properties', {}):
			def get_fields(_post, field_name):
				custom_fields = post.get('custom_fields', {})
				field = custom_fields.get(field_name, [])
				if len(field) >= 1 and len(field[0]) != 0:
					return cleaning(field[0])
				return None
			counter += 1
			SLUG_1 = post.get('slug', '')
			MOVIEIDD_1 = str(post['id'])
			TITLE_1 = cleaning(post['title'])
			try:
				DATE_1 = datetime(*(time.strptime(post['date'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2021-09-15T17:03:22.050874+00:00
				AIRED_1 = DATE_1.strftime('%d{0}%m{0}%Y').format('.') # Normally 'FirstAired' but here is added Date to List
				BEGINS_1 = DATE_1.strftime('%d{0}%m{0}%Y').format('.') # 23.02.2024 / OLDFORMAT until MATRIX
				if KODI_ov20:
					BEGINS_1 = DATE_1.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2024-02-23T04:17:00.00 / NEWFORMAT NEXUS and UP
			except: pass
			DESC_1 = cleaning(post['content']).replace('\n', '[CR]') if post.get('content', '') and len(post['content']) > 10 else ""
			image = (get_Picture(MOVIEIDD_1, post, 'thumbnail') or get_Picture(MOVIEIDD_1, post.get('custom_fields', []), 'Artikelbild'))
			THUMB_1 = image.split('.jpg')[0].rstrip()+'.jpg' if image and '.jpg' in image else image
			banner = get_Picture(MOVIEIDD_1, post.get('custom_fields', []), 'featured_img_seven')
			BANNER_1 = banner.split('.jpg')[0].rstrip()+'.jpg' if banner and '.jpg' in banner else banner
			backdrop = (get_Picture(MOVIEIDD_1, post.get('custom_fields', []), 'featured_img_all') or defaultFanart)
			FANART_1 = backdrop.split('.jpg')[0].rstrip().replace('_slider', '_img_all')+'.jpg' if backdrop and '.jpg' in backdrop else backdrop
			STREAM_1 = get_fields(post, 'Streaming')
			atelier = STREAM_1.replace('plus/', '').split('/')[0].strip().replace('_', ' ') if STREAM_1 else 'Netzkino'
			STUDIO_1 = re.sub(r' flat| SVOD| NKS| NK EV| NK(\d+)?| SG| MG', '', atelier)
			age = get_fields(post, 'FSK')
			if age and str(age).isdigit():
				MPAA_1 = str(age)
				if approvedAGE is False and str(age) == '18': continue
			imdb = get_fields(post, 'IMDb-Link')
			IMDBLINK_1 = f"{imdb.replace('http://', 'https://').replace('http:/', 'https://')}/" if imdb and not imdb.endswith('/') else imdb.replace('http://', 'https://').replace('http:/', 'https://') if imdb and imdb.endswith('/') else None
			YEAR_1 = get_fields(post, 'Jahr')
			score = get_fields(post, 'IMDb-Bewertung')
			if score and score != '0': RATING_1 = score.replace(',', '.')
			casting = get_fields(post, 'Stars')
			if casting and len(casting) > 0: # Fred Willard,Jennifer Coolidge,Kal Penn
				for index, person in enumerate(casting.split(','), 1):
					actor = {'name': person, 'role': '', 'order': index, 'thumb': ''}
					if actor['name'] not in ['' , None]:
						if KODI_ov20:
							STAFF_1.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
						else: STAFF_1.append(actor)
			DIRECTOR_1 = ', '.join([dirseq for dirseq in get_fields(post, 'Regisseur').split(',')]) if get_fields(post, 'Regisseur') else [] # Steven Seagal
			GENRE_1 = get_fields(post, 'TV_Movie_Genre') if get_fields(post, 'TV_Movie_Genre') else []
			quality = get_fields(post, 'Adaptives_Streaming')
			if quality and quality == 'HD': TITLE_1 += translation(30644)
			DURATION_1 = get_fields(post, 'Duration')
			ADDTYPE_1 = 1
			if xbmcvfs.exists(videoFavsFile) and os.stat(videoFavsFile).st_size > 0:
				with open(videoFavsFile, 'r') as fp:
					watch = json.load(fp)
					for item in watch.get('items', []):
						if item.get('url') == STREAM_1: ADDTYPE_1 = 2
			COMBI_FIRST.append([int(counter), MOVIEIDD_1, TITLE_1, AIRED_1, BEGINS_1, THUMB_1, BANNER_1, FANART_1, STREAM_1, STUDIO_1, MPAA_1, IMDBLINK_1, YEAR_1, RATING_1, STAFF_1, \
				DIRECTOR_1, GENRE_1, DURATION_1, DESC_1, ADDTYPE_1])
			if IMDBLINK_1:
				COMBI_LINKS.append([int(counter), IMDBLINK_1])
	if COMBI_FIRST and (META_SMALL or META_LARGE):
		if (META_SMALL and any(oy in TARGET for oy in STADIVISION)) or (META_LARGE and any(qz in TARGET for qz in GENDIVISION)):
			COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_FIRST or COMBI_SECOND:
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_SECOND if a[0] == b[0] and a[11] == b[1]] # Zusammenführung von Liste-1 und Liste-2 - wenn die Nummer an erster Stelle(0) und der LINK an zehnter/erster Stelle(10/1) überein stimmt !!!
		RESULT += [c for c in COMBI_FIRST if all(d[0] != c[0] and d[1] != c[11] for d in COMBI_SECOND)] # Der übriggebliebene Rest von Liste-1 - wenn die Nummer an erster Stelle(0) und der LINK an erster Stelle(1) nicht in der Liste-2 vorkommt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listVideos[3]) XXXXX RESULT-03 : {str(RESULT)} XXXXX")
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda k: int(k[0]), reverse=False): # Liste-1 = 0-19|| Liste-2 = 20-29 oder 0 #
			for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listVideos[3]) ### Anzahl = {str(len(da))} || Eintrag : {str(da)} ###")
			Note_1, (Rated2, Voted2, Mpaa2, Genre2, Added2, Begins2, Director2, Creator2, mpaa) = "", (None for _ in range(9))
			if len(da) > 29: ### COMBI_FIRST+COMBI_SECOND ist grösser als Nummer:29 ###
				'''
				Liste-1 = Num1, MovieIdd, title, Begins1, image, banner, background, stream, studio, Mpaa1, ImdbLink1, Year1, Rated1, STAFF, Director1, Genre1, duration, plot, addType = da[0], da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19]
				Liste-2 = Num2, ImdbLink2, Rated2, Voted2, Mpaa2, Genre2, Aired2, Begins2, Director2, Creator2 = da[20], da[21], da[22], da[23], da[24], da[25], da[26], da[27],da[28], da[29]
				'''
				Num1, MovieIdd, title, Added1, Begins1, image, banner, background, stream, studio, Mpaa1, ImdbLink1, Year1, Rated1, STAFF, Director1, Genre1, duration, description, addType = da[0], da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19]
				Num2, ImdbLink2, Rated2, Voted2, Mpaa2, Genre2, Added2, Begins2, Director2, Creator2 = da[20], da[21], da[22], da[23], da[24], da[25], da[26], da[27], da[28], da[29]
			elif len(da) == 20: ### COMBI_FIRST ist gleich Nummer:20 und COMBI_SECOND ist AUS ###
				Num1, MovieIdd, title, Added1, Begins1, image, banner, background, stream, studio, Mpaa1, ImdbLink1, Year1, Rated1, STAFF, Director1, Genre1, duration, description, addType = da[0], da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19]
				Num2, ImdbLink2, Rated2, Voted2, Mpaa2, Genre2, Added2, Begins2, Director2, Creator2 = (None for _ in range(10))
			else: continue
			if Added1 or Added2:
				Note_1 = translation(30645).format(Added2) if Added2 else translation(30646).format(Added1)
			else: Note_1 = '[CR]'
			plot = f"{title}[CR]{Note_1}{description}"
			begins = Begins2 if Begins2 else Begins1 if Begins1 else None
			year = Added2[6:10] if Added2 else Year1 if Year1 else None
			genre = Genre2 if Genre2 else Genre1 if Genre1 else None
			director = Director2 if Director2 else Director1 if Director1 else None
			writer = Creator2 if Creator2 else None
			rating = Rated2 if Rated2 else Rated1 if Rated1 else None
			voting = Voted2 if Voted2 else None
			if Mpaa1 or Mpaa2:
				FSK = Mpaa2 if Mpaa2 else Mpaa1
				mpaa = translation(30647) if '0' in FSK else translation(30648).format(FSK)
			debug_MS(f"(navigator.listVideos[3]) ##### NAME : {title} || IMDB-LINK : {str(ImdbLink1)} || DATE : {str(begins)} #####")
			debug_MS(f"(navigator.listVideos[3]) ##### GENRE : {str(genre)} || DIRECTOR : {str(director)} || WRITER : {str(writer)} || RATING : {str(rating)} #####")
			debug_MS(f"(navigator.listVideos[3]) ##### VIDEO : {str(config['PLAY_PMD'].format(stream))} || DURATION : {str(duration)} || THUMB : {str(image)} #####")
			addLink(title, image, {'mode': 'playVideo', 'url': stream}, plot, duration, begins, year, genre, director, writer, STAFF, rating, voting, studio, mpaa, banner, background, addType)
	else:
		failing(f"(navigator.listVideos[3]) ##### Keine VIDEOS-List - Kein Eintrag *** {str(CAT)} *** gefunden #####")
		return dialog.notification(translation(30525).format('Einträge'), translation(30526).format(CAT), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSubstances(MURLS):
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		DATA_TWO = json.loads(COMBI_DETAILS)
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listSubstances[2]) XXXXX DATA_TWO-02 : {str(DATA_TWO)} XXXXX")
		#log("++++++++++++++++++++++++")
		for elem in DATA_TWO:
			if elem is not None and elem.get('@context', '') == 'https://schema.org':
				RATING_2, VOTING_2, MPAA_2, AIRED_2, BEGINS_2 = (None for _ in range(5))
				GENRE_2, DIRECTOR_2, CREATOR_2 = ([] for _ in range(3))
				POS_2, DEM_2= elem['Position'], elem['Demand']
				debug_MS(f"(navigator.listSubstances[2]) xxxxx ELEMENT-02 : {str(elem)} xxxxx")
				if elem.get('aggregateRating', '') and str(elem['aggregateRating'].get('ratingValue', '')).replace('.', '').isdigit():
					RATING_2 = elem['aggregateRating']['ratingValue']
				if elem.get('aggregateRating', '') and str(elem['aggregateRating'].get('ratingCount', '')).isdigit():
					VOTING_2 = elem['aggregateRating']['ratingCount']
				MPAA_2 = str(elem['contentRating']) if str(elem.get('contentRating')).isdigit() else None
				GENRE_2 = ' / '.join(sorted([cleaning(genpart) for genpart in elem.get('genre', {})])) if elem.get('genre', {}) else [] # Drama, Familie, Komödie
				try:
					DATE_2 = datetime(*(time.strptime(elem['datePublished'][:10], '%Y{0}%m{0}%d'.format('-', ':'))[0:6])) # 2021-09-15
					AIRED_2 = DATE_2.strftime('%d{0}%m{0}%Y').format('.') # Normally 'FirstAired' but here is added Date to List
					BEGINS_2 = DATE_2.strftime('%d{0}%m{0}%Y').format('.') # 23.02.2024 / OLDFORMAT until MATRIX
					if KODI_ov20:
						BEGINS_2 = DATE_2.strftime('%Y{0}%m{0}%dT00{1}00').format('-', ':') # 2024-02-23T00:00 / NEWFORMAT NEXUS and UP
				except: pass
				DIRECTOR_2 = ', '.join([cleaning(dirpart.get('name', '')) for dirpart in elem.get('director', {}) if dirpart.get('@type') == 'Person']) if elem.get('director', {}) else [] # Steven Seagal
				CREATOR_2 = ', '.join([cleaning(creapart.get('name', '')) for creapart in elem.get('creator', {}) if creapart.get('@type') == 'Person']) if elem.get('creator', {}) else [] # Ed Horowitz, Robin U. Russin
				COMBI_THIRD.append([int(POS_2), DEM_2, RATING_2, VOTING_2, MPAA_2, GENRE_2, AIRED_2, BEGINS_2, DIRECTOR_2, CREATOR_2])
	return COMBI_THIRD

def SearchNETZKINO():
	debug_MS("(navigator.SearchNETZKINO) ------------------------------------------------ START = SearchNETZKINO -----------------------------------------------")
	config = traversing.get_config()
	keyword = None
	if xbmcvfs.exists(SEARCHFILE):
		with open(SEARCHFILE, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30625), type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
		if keyword:
			keyword = quote(keyword)
			with open(SEARCHFILE, 'w') as record:
				record.write(keyword)
	if keyword: return listVideos(config['API_SEARCH'].format(keyword), unquote(keyword), 'SEARCHING')
	return None

def playVideo(SLUG):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### VIDEO_SLUG = {SLUG} ###")
	FINAL_URL, STREAM = (False for _ in range(2))
	config = traversing.get_config()
	if xbmc.Player().isPlaying():
		xbmc.Player().stop()
	#if (prefSTREAM == '0' or enableINPUTSTREAM):
		#STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
		#MIME, FINAL_URL = 'application/vnd.apple.mpegurl', config['PLAY_HLS'].format(SLUG)
	if not FINAL_URL:
		STREAM, MIME, FINAL_URL = 'MP4', 'video/mp4', config['PLAY_PMD'].format(SLUG)
	if FINAL_URL and STREAM:
		LPM = xbmcgui.ListItem(path=FINAL_URL)
		if ADDON_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			LPM.setMimeType(MIME)
			LPM.setProperty('inputstream', 'inputstream.adaptive')
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LPM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}")
	else: 
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### VIDEO_URL : {config['PLAY_PMD'].format(SLUG)} #####\n ########## KEINEN passenden Stream-Eintrag gefunden !!! ##########")
		return dialog.notification(translation(30521).format('PLAY'), translation(30527), icon, 8000)

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	def corr(sg):
		return sg if sg not in ['None', None] else None
	if xbmcvfs.exists(videoFavsFile):
		for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
		with open(videoFavsFile, 'r') as fp:
			watch = json.load(fp)
			for item in watch.get('items', []):
				image = icon if corr(item.get('thumb', 'None')) is None else item.get('thumb')
				debug_MS(f"(navigator.listFavorites[1]) ### NAME : {item.get('name')} || LINK : {item.get('url')} || IMAGE : {image} ###")
				addLink(item.get('name'), image, {'mode': 'playVideo', 'url': item.get('url')}, corr(item.get('plot')), corr(item.get('duration')), corr(item.get('begins', 'None')), corr(item.get('year', 'None')), \
					corr(item.get('genre')), corr(item.get('director')), corr(item.get('writer')), item.get('STAFF', []), corr(item.get('rating')), corr(item.get('voting')), item.get('studio', 'Netzkino'), \
					corr(item.get('mpaa', 'None')), corr(item.get('banner', 'None')), corr(item.get('background', 'None')), FAVclear=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(*args):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(videoFavsFile) and os.stat(videoFavsFile).st_size > 0:
		with open(videoFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'name': name, 'thumb': thumb, 'url': url, 'plot': plot, 'duration': duration, 'begins': begins, 'year': year, 'genre': genre, 'director': director, 'writer': writer, 'STAFF': STAFF, 'rating': rating, \
			'voting': voting, 'studio': studio, 'mpaa': mpaa, 'banner': banner, 'background': background})
		with open(videoFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30528), translation(30529).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('url') != url]
		with open(videoFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30528), translation(30530).format(name), icon, 8000)

def addDir(name, image, params={}, plot=None, background=None, folder=True):
	uws = build_mass(params)
	LDM = xbmcgui.ListItem(name, offscreen=True)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = LDM.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setStudios(['Netzkino'])
	else:
		LDM.setInfo('Video', {'Title': name, 'Plot': plot, 'Studio': 'Netzkino'})
	LDM.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if background and useThumbAsFanart and background != icon:
		LDM.setArt({'fanart': background})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uws, listitem=LDM, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None, begins=None, year=None, genre=None, director=None, writer=None, STAFF=[], rating=None, voting=None, studio=None, mpaa=None, \
	banner=None, background=None, addType=0, FAVclear=False):
	uvz = build_mass(params)
	LEM = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = LEM.getVideoInfoTag()
		vinfo.setTitle(name)
		vinfo.setPlot(plot)
		if str(duration).isdigit(): vinfo.setDuration(int(duration))
		if begins not in ['None', None]: LEM.setDateTime(begins)
		if str(year).isdigit(): vinfo.setYear(int(year))
		if genre and len(genre) > 4: vinfo.setGenres([genre])
		if director and len(director) > 4: vinfo.setDirectors([director])
		if writer and len(writer) > 4: vinfo.setWriters([writer])
		if isinstance(STAFF, (list, tuple)): vinfo.setCast(STAFF)
		if rating and str(rating).replace('.', '').isdigit() and voting and str(voting).isdigit():
			vinfo.setRating(float(rating), int(voting), 'imdb', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		elif rating and str(rating).replace('.', '').isdigit() and voting is None:
			vinfo.setRating(float(rating), 0, 'imdb', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		if studio not in ['None', None]: vinfo.setStudios([studio])
		if mpaa not in ['None', None]: vinfo.setMpaa(mpaa)
		vinfo.setMediaType('movie')
	else:
		vinfo = {}
		if isinstance(STAFF, (list, tuple)): LEM.setCast(STAFF)
		vinfo['Title'] = name
		vinfo['Plot'] = plot
		if str(duration).isdigit(): vinfo['Duration'] = duration
		if begins not in ['None', None]: vinfo['Date'] = begins
		if str(year).isdigit(): vinfo['Year'] = year
		if genre and len(genre) > 4: vinfo['Genre'] = genre
		if director and len(director) > 4: vinfo['Director'] = director
		if writer and len(writer) > 4: vinfo['Writer'] = writer
		if rating and str(rating).replace('.', '').isdigit() and voting and str(voting).isdigit():
			LEM.setRating('imdb', float(rating), int(voting), True) # LEM.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
		elif rating and str(rating).replace('.', '').isdigit() and voting is None:
			LEM.setRating('imdb', float(rating), 0, True) # LEM.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
		if studio not in ['None', None]: vinfo['Studio'] = studio
		if mpaa not in ['None', None]: vinfo['Mpaa'] = mpaa
		vinfo['Mediatype'] = 'movie'
		LEM.setInfo('Video', vinfo)
	LEM.setArt({'icon': icon, 'thumb': image, 'poster': image, 'banner': banner, 'fanart': defaultFanart})
	if background not in ['None', None] and useThumbAsFanart:
		LEM.setArt({'fanart': background})
	LEM.setProperty('IsPlayable', 'true')
	LEM.setContentLookup(False)
	entries = []
	if addType == 1 and FAVclear is False:
		entries.append([translation(30651), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'ADD', 'name': name, 'thumb': None if image == icon else image, 'url': params.get('url'), 'plot': plot, 'duration': duration,
			'begins': begins, 'year': year, 'genre': genre, 'director': director, 'writer': writer, 'STAFF': STAFF, 'rating': rating, 'voting': voting, 'studio': studio, 'mpaa': mpaa, 'banner': banner, 'background': background}))])
	if addType == 0 and FAVclear is True:
		entries.append([translation(30652), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'DEL', 'name': name, 'thumb': image, 'url': params.get('url'), 'plot': plot, 'duration': duration,
			'begins': begins, 'year': year, 'genre': genre, 'director': director, 'writer': writer, 'STAFF': STAFF, 'rating': rating, 'voting': voting, 'studio': studio, 'mpaa': mpaa, 'banner': banner, 'background': background}))])
	entries.append([translation(30654), 'Action(Queue)'])
	LEM.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LEM)
