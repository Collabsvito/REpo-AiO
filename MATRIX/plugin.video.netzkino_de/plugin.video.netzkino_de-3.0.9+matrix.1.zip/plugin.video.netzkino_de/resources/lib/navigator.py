﻿# -*- coding: utf-8 -*-

from .common import *
config = traversing.get_config()


def mainMenu(combo={}):
	debug_MS("(navigator.mainMenu) ------------------------------------------------ START = mainMenu -----------------------------------------------")
	combo['Res_Link'], complete = ([] for _ in range(2))
	addDir({'mode': 'listFavorites'}, create_entries({'Title': translation(30601), 'Image': f"{artpic}watchlist.png"}))
	for ii, each in enumerate(config['picks'], 1):
		combo['Res_Link'].append({'Count_1': int(ii), 'Link_1': config['CAT_ENTRIES'].format(each['id']), 'Code_1': each['id'], 'Specs_1': each['title']})
	complete = trackSeveral(combo['Res_Link'], 'GET', 'JSON', HEAD_NETZ, 2)
	if complete: debug_MS("---------------------------------------------")
	for item in sorted(complete, key=lambda evs: int(evs.get('Position', 0))):
		debug_MS(f"(navigator.mainMenu[1]) === CALLBACK === POS : {item['Position']} || STATUS : {item['Status']} || CODE : {item['Code']} || TITLE : {item['Name']} || RTIME : {item['Time']}s ===")
		if item.get('Status', 'ERROR') == 'OOKAY':
			addDir({'mode': 'listMovies', 'url': config['CAT_ENTRIES'].format(item.get('Code')), 'category': item.get('Name'), 'section': str(item.get('Code'))}, \
				create_entries({'Title': f"[B]{item.get('Name')}[/B]", 'Image': f"{artpic}{item.get('Code')}.png"}))
	addDir({'mode': 'listGenres'}, create_entries({'Title': translation(30621), 'Image': f"{artpic}genres.png"}))
	addDir({'mode': 'SearchNETZKINO'}, create_entries({'Title': translation(30622), 'Image': f"{artpic}search.png"}))
	if enable_tune:
		addDir({'mode': 'antuning'}, create_entries({'Title': translation(30623), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGenres():
	debug_MS("(navigator.listThemes) ------------------------------------------------ START = listThemes -----------------------------------------------")
	for genre in config['genres']:
		title, code, cat_link = genre['title'], genre['id'], config['CAT_ENTRIES'].format(genre['id'])
		if approvedAGE is False and int(code) == 71: continue
		addDir({'mode': 'listMovies', 'url': cat_link, 'category': title, 'section': str(code)}, create_entries({'Title': f"[B]{title}[/B]", 'Image': 'DefaultGenre.png'}))
		debug_MS(f"(navigator.listGenres[1]) ### NAME : {title} || GENRE-ID : {code} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchNETZKINO():
	debug_MS("(navigator.SearchNETZKINO) ------------------------------------------------ START = SearchNETZKINO -----------------------------------------------")
	keyword = preserve(SEARCH_FILE, 'TEXT')
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30625), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword: return listMovies(config['API_SEARCH'].format(keyword), keyword, 'SEARCHING')
	return None

def listMovies(TARGET, CAT, SECTION):
	debug_MS("(navigator.listMovies) ------------------------------------------------ START = listMovies -----------------------------------------------")
	debug_MS(f"(navigator.listMovies) ### URL = {TARGET} ### CATEGORY = {CAT} ### SECTION = {SECTION} ###")
	counter, (combo, merging) = 0, ({} for _ in range(2))
	combo['Res_Link'], combo['Res_Uno'], combo['Res_Due'] = ([] for _ in range(3))
	STADIVISION = ['SEARCHING', '8', '81', '161', '6611', '6621', '6801', '9431', '9441', '9471', '10633', '10643']
	GENDIVISION = ['1', '3', '4', '5', '6', '10', '18', '32', '35', '51', '71', '8951', '10333']
	DATA_ONE = trackContent(TARGET)
	for post in DATA_ONE.get('posts', []):
		starting_uno, airing_uno, stream, mpaa_uno, year, rating_uno, duration_uno = (None for _ in range(7))
		if 'Streaming' in post.get('custom_fields', {}) and not 'plus-exclusive' in post.get('properties', {}):
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
			debug_MS(f"(navigator.listMovies[1]) xxxxx ARTICLE-01 : {post} xxxxx")
			def get_fields(_post, field_name):
				custom_fields = post.get('custom_fields', {})
				field = custom_fields.get(field_name, [])
				if len(field) >= 1 and len(field[0]) != 0:
					return cleaning(field[0])
				return None
			counter += 1
			slug = post.get('slug', '')
			moveid = str(post['id'])
			title = cleaning(post['title'])
			try:
				local_start = datetime(*(time.strptime(post['date'][:19], '%Y-%m-%dT%H:%M:%S')[0:6])) # 2021-09-15T17:03:22.050874+00:00
				starting_uno = local_start.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else local_start.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
				airing_uno = local_start.strftime('%d.%m.%Y') # FirstAired
			except: pass
			descript = cleaning(post['content']).replace('\n', '[CR]') if post.get('content', '') and len(post['content']) > 10 else ""
			country = cleaning(post['custom_fields']['productionCountry']) if post.get('custom_fields', '') and post['custom_fields'].get('productionCountry', '') else None
			image = (get_Picture(moveid, post, 'thumbnail') or get_Picture(moveid, post.get('custom_fields', []), 'Artikelbild'))
			thumb_uno = image.split('.jpg')[0].rstrip()+'.jpg' if image and '.jpg' in image else image
			banner = get_Picture(moveid, post.get('custom_fields', []), 'featured_img_seven')
			banner = banner.split('.jpg')[0].rstrip()+'.jpg' if banner and '.jpg' in banner else banner
			backdrop = (get_Picture(moveid, post.get('custom_fields', []), 'featured_img_all') or defaultFanart)
			fanart = backdrop.split('.jpg')[0].rstrip().replace('_slider', '_img_all')+'.jpg' if backdrop and '.jpg' in backdrop else backdrop
			stream = get_fields(post, 'Streaming')
			atelier = stream.replace('plus/', '').split('/')[0].strip().replace('_', ' ') if stream else 'Netzkino'
			studio = re.sub(r' flat| SVOD| NKS| NK EV| NK(\d+)?| SG| MG', '', atelier)
			ages = get_fields(post, 'FSK')
			if str(ages).isdecimal():
				mpaa_uno = str(ages)
				if approvedAGE is False and str(ages) == '18': continue
			imdb = get_fields(post, 'IMDb-Link').split('imdb.com/title/')[1].replace('/', '') if get_fields(post, 'IMDb-Link') else None # https://www.imdb.com/de/title/tt1772288/
			year = get_fields(post, 'Jahr')
			score = get_fields(post, 'IMDb-Bewertung')
			if score and score != '0': rating_uno = score.replace(',', '.')
			duration_uno = get_fields(post, 'Duration')
			genre_uno = get_fields(post, 'TV_Movie_Genre') if get_fields(post, 'TV_Movie_Genre') else []
			director_uno = ', '.join([cleaning(seur) for seur in get_fields(post, 'Regisseur').split(',')]) if get_fields(post, 'Regisseur') else [] # Steven Seagal
			actors = ','.join([cleaning(star) for star in get_fields(post, 'Stars').split(',')]) if get_fields(post, 'Stars') else [] # Fred Willard,Jennifer Coolidge,Kal Penn
			quality = get_fields(post, 'Adaptives_Streaming')
			if quality and quality == 'HD': title += translation(30644)
			combo['Res_Uno'].append({'Count_1': int(counter), 'Code': imdb, 'Moveid': moveid, 'Title': title, 'Story': descript, 'Duration_1': duration_uno,
				'Date_1': starting_uno, 'Aired_1': airing_uno, 'Year': year, 'Genre_1': genre_uno, 'Country': country, 'Director_1': director_uno, 'Staff': actors,
				'Rating_1': rating_uno, 'Studio': studio, 'Mpaa_1': mpaa_uno, 'Thumb_1': thumb_uno, 'Banner': banner, 'Fanback': fanart, 'Stream': stream})
			if imdb:
				combo['Res_Link'].append({'Count_1': int(counter), 'Link_1': GRAPH_IMDB, 'Code_1': imdb, 'Specs_1': _parse_various(imdb)})
	if combo['Res_Uno'] and (META_SMALL or META_LARGE):
		if (META_SMALL and SECTION in STADIVISION) or (META_LARGE and SECTION in GENDIVISION):
			combo['Res_Due'] = _parse_due(combo['Res_Link'])
	merging = [{**uno, **next(iter([due for due in combo['Res_Due'] if due.get('Count_2') == uno.get('Count_1')]), {})} for uno in combo['Res_Uno']] # Merge two Lists of Dictionaries by specific value !!!
	if merging: # https://stackoverflow.com/questions/56658669/combine-two-lists-of-dictionaries-by-value-of-key-in-dictionaries
		for result in sorted(merging, key=lambda sox: int(sox.get('Count_1', 0))): # 0-19 = List1 || 20-32 = List2 (sorted by date in descending order)
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listMovies[3]) ##### Anzahl : {len(result)} || Eintrag : {result} #####")
			if len(result) < 19: continue ### combo['Res_Uno'] ist gleich Nummer:20 wenn combo['Res_Due'] ausgeschaltet ist ###
			if result.get('Aired_2') or result.get('Aired_1'):
				Notes = translation(30645).format(result.get('Aired_2')) if result.get('Aired_2') else translation(30646).format(result.get('Aired_1'))
			else: Notes = '[CR]'
			plot, operation= f"{result.get('Title')}[CR]{Notes}{result.get('Story')}", 'adding'
			duration = result.get('Duration_1') if str(result.get('Duration_1')).isdecimal() else result.get('Duration_2')
			starting = (result.get('Date_2', None) or result.get('Date_1', None))
			year = result.get('Aired_2')[6:10] if result.get('Aired_2') else result.get('Year')
			genre = (result.get('Genre_2', []) or result.get('Genre_1', []))
			director = (result.get('Director_2', []) or result.get('Director_1', []))
			rating = (result.get('Rating_2', None) or result.get('Rating_1', None))
			agerate = (result.get('Mpaa_2', None) or result.get('Mpaa_1', None))
			mpaa = translation(30647) if agerate and '0' in agerate else translation(30648).format(agerate) if agerate else None
			image = (result.get('Thumb_2', None) or result.get('Thumb_1', None))
			debug_MS(f"(navigator.listMovies[3]) ##### NAME : {result.get('Title')} || IMDB-CODE : {result.get('Code')} || DATE : {(result.get('Aired_2', None) or result.get('Aired_1', None))} #####")
			debug_MS(f"(navigator.listMovies[3]) ##### DIRECTOR : {director} || WRITER : {result.get('Writer', [])} || GENRE : {genre} || RATING : {rating} #####")
			debug_MS(f"(navigator.listMovies[3]) ##### VIDEO : {config['PLAY_PMD'].format(result.get('Stream'))} || DURATION : {duration} || THUMB : {image} #####")
			for method in get_sorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			FETCH_UNO = context = {'Streaming': result.get('Stream'), 'Title': result.get('Title'), 'Plot': plot, 'Duration': duration, 'Date': starting, 'Year': year, 'Genre': genre, 'Country': result.get('Country', None), \
				'Director': director, 'Writer': result.get('Writer', []), 'Stars_Small': result.get('Staff', []), 'Cast': result.get('Cast', []), 'Rating': rating, 'Voting': result.get('Voting', None), \
				'Studio': result.get('Studio'), 'Mpaa': mpaa, 'Mediatype': 'movie', 'Image': image, 'Banner': result.get('Banner'), 'Fanback': result.get('Fanback'), 'Reference': 'Single'}
			if preserve(FAVORIT_FILE) is not None:
				for article in preserve(FAVORIT_FILE):
					if article.get('Streaming') == result.get('Stream'): operation = 'skipping'
			addDir({'mode': 'playVideo', 'url': result.get('Stream')}, create_entries(FETCH_UNO), False, context, operation)
	else:
		failing(f'(navigator.listMovies) ##### NO MOVIE-LIST - NO ENTRY FOR: "{CAT}" FOUND #####')
		return dialog.notification(translation(30525), translation(30526).format(CAT), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def _parse_various(ident):
	query = """
	query Title_Summary_Prompt_From_Base($id: ID!) { title(id: $id) { ...BaseTitleCard } }
	fragment BaseTitleCard on Title {
		id
		titleText { text }
		titleType { id text canHaveEpisodes }
		originalTitleText { text }
		plot { plotText { plainText } }
		primaryImage { id width height url }
		releaseDate { year month day }
		ratingsSummary { aggregateRating voteCount }
		certificate { rating }
		runtime { seconds }
		titleGenres { genres(limit: 3) { genre { text } } }
		directors: credits(first: 3, filter: { categories: ["director"] }) { edges { node { name { nameText { text } } } } }
		writers: credits(first: 3, filter: { categories: ["writer"] }) { edges { node { name { nameText { text } } } } }
		cast: credits(first: 10, filter: { categories: ["actor", "actress"] }) { edges { node { ... on Cast { name { nameText { text } primaryImage { url } } characters { name } } } } } }
	"""
	return {"query": query.replace('\t', ''), "variables": {"id": ident}}

def _parse_due(news, embrace=[], secondo=[]):
	debug_MS("(navigator._parse_due) -------------------------------------------------- START = _parse_due --------------------------------------------------")
	embrace = trackSeveral(news, 'POST', 'JSON', HEAD_GRAPH, 5)
	if embrace:
		DATA_RIDER = json.loads(embrace)
		for item in DATA_RIDER:
			if item is not None and item.get('data', {}) and item.get('data', {}).get('title', {}):
				(starting_due, airing_due, rating_due, voting), (director_due, writer, staff) = (None for _ in range(4)), ([] for _ in range(3))
				number, code, packs = item['Position'], item['NaviCode'], item['data']['title']
				debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
				debug_MS(f"(navigator._parse_due[2]) xxxxx POSITION-02 : {number} || IMDB-02 : {code} || ELEMENT-02 : {packs} xxxxx")
				thumb_due = packs['primaryImage']['url'] if packs.get('primaryImage', {}) and packs.get('primaryImage', {}).get('url', {}) else None
				try:
					local_start = datetime(*(time.strptime(f"{packs['releaseDate']['year']}-{packs['releaseDate']['month']}-{packs['releaseDate']['day']}", '%Y-%m-%d')[0:6])) # 2021-09-15
					starting_due = local_start.strftime('%Y-%m-%dT00:00') if KODI_BUILD >= 20 else local_start.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
					airing_due = local_start.strftime('%d.%m.%Y') # FirstAired
				except: pass
				if packs.get('ratingsSummary', {}) and str(packs.get('ratingsSummary', {}).get('aggregateRating')).replace('.', '').isdecimal():
					rating_due = packs['ratingsSummary']['aggregateRating']
				if packs.get('ratingsSummary', {}) and str(packs.get('ratingsSummary', {}).get('voteCount')).isdecimal():
					voting = packs['ratingsSummary']['voteCount']
				mpaa_due = str(packs['certificate']['rating']) if packs.get('certificate', {}) and str(packs['certificate'].get('rating')).isdecimal() else None
				duration_due = packs['runtime']['seconds'] if packs.get('runtime', {}) and str(packs['runtime'].get('seconds')).isdecimal() else None
				genre_due = ' / '.join(sorted([cleaning(gen.get('genre', {}).get('text', '')) for gen in packs['titleGenres']['genres']])) if packs.get('titleGenres', {}) and packs.get('titleGenres', {}).get('genres', {}) else [] # Drama, Familie, Komödie
				try: director_due = ', '.join([cleaning(rec.get('node').get('name').get('nameText').get('text')) for rec in packs.get('directors').get('edges')]) # Steven Seagal
				except: pass
				try: writer = ', '.join([cleaning(cre.get('node').get('name').get('nameText').get('text')) for cre in packs.get('writers').get('edges')]) # Ed Horowitz, Robin U. Russin
				except: pass
				try: casting = [{'name': xc.get('node').get('name').get('nameText').get('text'), 'role': xc.get('node').get('characters', {})[0].get('name', '') if xc.get('node').get('characters', '') else '', \
					'thumb': xc.get('node').get('name').get('primaryImage', {}).get('url', '') if xc.get('node').get('name').get('primaryImage', '') else ''} for xc in packs.get('cast').get('edges')] # Tom Cruise, Hayley Atwell, Ving Rhames
				except: pass
				secondo.append({'Count_2': int(number), 'Code': code, 'Duration_2': duration_due, 'Date_2': starting_due, 'Aired_2': airing_due, 'Genre_2': genre_due,
					'Director_2': director_due, 'Writer': writer, 'Cast': casting, 'Rating_2': rating_due, 'Voting': voting, 'Mpaa_2': mpaa_due, 'Thumb_2': thumb_due})
	return secondo

def playVideo(SLUG):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### VIDEO_SLUG = {SLUG} ###")
	STREAM, MIME, FINAL_URL, TEST_URL = 'MP4', 'video/mp4', config['PLAY_PMD'].format(SLUG), False
	try: # Test function to see if stream can be played !!!
		code = urlopen(FINAL_URL, timeout=6).getcode()
		if code in [200, 201, 202]: TEST_URL = True
	except: pass
	if FINAL_URL and TEST_URL:
		LSM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}")
	else:
		failing(f"(navigator.playVideo) $$$$$ Playback of the stream is NOT possible $$$$$ FINAL_URL : {FINAL_URL} $$$$$\n ########## NO Stream-Entry found on *netzkino.de* !!! ##########")
		return dialog.notification(translation(30521).format('VIDEO'), translation(30527), icon, 12000)

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	if preserve(FAVORIT_FILE) is not None:
		for each in sorted(preserve(FAVORIT_FILE), key=lambda vsx: clear_umlaut(vsx.get('Title', 'zorro')).lower()):
			for method in get_sorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			FETCH_UNO = context = {'Streaming': each.get('Streaming'), 'Title': each.get('Title'), 'Plot': each.get('Plot'), 'Duration': each.get('Duration'), \
				'Date': each.get('Date'), 'Year': each.get('Year'), 'Genre': each.get('Genre'), 'Country': each.get('Country'), 'Director': each.get('Director'), \
				'Writer': each.get('Writer'), 'Stars_Small': each.get('Stars_Small'), 'Rating': each.get('Rating'), 'Voting': each.get('Voting'), 'Studio': each.get('Studio'), \
				'Mpaa': each.get('Mpaa'), 'Mediatype': 'movie', 'Image': each.get('Image'), 'Banner': each.get('Banner'), 'Fanback': each.get('Fanback'), 'Reference': 'Single'}
			debug_MS(f"(navigator.listFavorites[1]) ##### NAME : {each.get('Title')} || DIRECTOR : {each.get('Director')} || WRITER : {each.get('Writer')}" \
				f"|| DATE : {each.get('Date')} #####")
			debug_MS(f"(navigator.listFavorites[1]) ##### VIDEO : {config['PLAY_PMD'].format(each.get('Streaming'))} || DURATION : {each.get('Duration')}" \
				f"|| RATING : {each.get('Rating')} || THUMB : {each.get('Image')} #####")
			addDir({'mode': 'playVideo', 'url': each.get('Streaming')}, create_entries(FETCH_UNO), False, context, 'removing')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favorit_construct(**kwargs):
	TOPS = []
	if preserve(FAVORIT_FILE) is not None:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		kwargs.pop('mode', None); kwargs.pop('action', None); kwargs.pop('Cast', None)
		TOPS.append({key: value for key, value in kwargs.items() if value not in ['', 'None', None]})
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30528), translation(30529).format(kwargs['Title']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Streaming') != kwargs.get('Streaming')]
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30528), translation(30530).format(kwargs['Title']), icon, 10000)

def addDir(params, listitem, folder=True, context={}, handling='default'):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if handling == 'adding' and context:
		entries.append([translation(30651), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
