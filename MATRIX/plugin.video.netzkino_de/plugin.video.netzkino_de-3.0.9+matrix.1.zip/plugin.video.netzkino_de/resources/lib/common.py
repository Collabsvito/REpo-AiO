﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import time
from datetime import datetime, timedelta
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import parse_qsl, urlencode, quote, quote_plus, unquote, unquote_plus
from urllib.request import urlopen
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from .provider import Client


HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_desc						= addon.getAddonInfo('description')
addon_folder						= xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
addon_profile					= xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
FAVORIT_FILE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'watchlist_NETZKINO.json'))
SEARCH_FILE						= xbmcvfs.translatePath(os.path.join(addon_profile, 'search_string'))
defaultFanart						= os.path.join(addon_folder, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addon_folder, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addon_folder, 'resources', 'media', '').encode('utf-8').decode('utf-8')
enable_adaptive				= addon.getSetting('use_adaptive') == 'true'
prefSTREAM						= addon.getSetting('prefer_stream')
approvedAGE						= (True if addon.getSetting('no_age_restriction') == 'true' else False)
META_SMALL						= (True if addon.getSetting('meta_small') == 'true' else False)
META_LARGE						= (True if addon.getSetting('meta_large') == 'true' else False)
useThumbAsFanart			= addon.getSetting('use_fanart') == 'true'
enable_tune						= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_BUILD						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2])
IMDB_POINT						= 'https://www.imdb.com/'
NETZ_POINT						= 'https://www.netzkino.de/'
GRAPH_IMDB					= 'https://graphql.prod.api.imdb.a2z.com/'
AGENT_WEB						= 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:150.0) Gecko/20100101 Firefox/150.0'
HEAD_GRAPH					= {'User-Agent': AGENT_WEB, 'Origin': IMDB_POINT[:-1], 'Referer': IMDB_POINT, 'Cache-Control': 'public, max-age=300', 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json; charset=utf-8', 'x-imdb-client-name': 'imdb-web-next', 'x-imdb-user-language': 'de-DE', 'x-imdb-user-country': 'DE', 'DNT': '1', 'Upgrade-Insecure-Requests': '1', 'Accept-Encoding': 'gzip', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8'}
HEAD_NETZ						= {'User-Agent': AGENT_WEB, 'Origin': NETZ_POINT[:-1], 'Referer': NETZ_POINT, 'Cache-Control': 'public, max-age=300', 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json; charset=utf-8', 'documentLifecycle': 'active', 'DNT': '1', 'Upgrade-Insecure-Requests': '1', 'Accept-Encoding': 'gzip', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8'}
traversing							= Client(Client.CONFIG_NETZKINO)

xbmcplugin.setContent(ADDON_HANDLE, 'movies')

def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def trackSeveral(stacks, method='GET', queries='JSON', headers={}, timeout=5, workers=20):
	COMBI_NEW, number, counter, fixation = [], len(stacks), 0, requests.Session()
	fixation.mount('https://', HTTPAdapter(pool_connections=int(number), pool_maxsize=int(number), pool_block=True)) # Pool-Verbindungen und -Grösse auf tatsächlichen Inhalt festlegen, um Fehlermeldungen zu vermeiden
	def download(pos, link, code, specs):
		transfer, starting = None if method == 'GET' else specs, time.time()
		try:
			response = fixation.request(method, link, headers=headers, allow_redirects=True, json=transfer, timeout=timeout)
			response.raise_for_status()
			debug_MS(f"(common.trackSeveral[1]) === POS : {pos} || STATUS : {response.status_code} || IDENT : {link if method == 'GET' else code} || HEADER : {response.request.headers} ===")
			if transfer is None: return {'Position': pos, 'Status': 'OOKAY', 'Code': code, 'Name': specs, 'Time': round(time.time() - starting, 3)}
			else: return f'{{"Position":{pos},"NaviCode":"{code}",{response.text[1:-2]}}}'
		except Exception as exc_uno:
			if transfer is None: return {'Position': pos, 'Status': 'ERROR', 'Code': code, 'Name': specs, 'Time': round(time.time() - starting, 3)}
			else:
				failing(f"(common.trackSeveral[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === IDENT : {code} === FAILURE : {exc_uno} #####")
				return f'{{"Position":{pos},"Status":"ERROR"}}'
	with ThreadPoolExecutor(max_workers=workers) as executor:
		picker = [executor.submit(download, single['Count_1'], single['Link_1'], single['Code_1'], single['Specs_1']) for single in stacks]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for future, section in zip(as_completed(picker), stacks):
			counter += 1
			try:
				COMBI_NEW.append(future.result()) if method == 'GET' else COMBI_NEW.append(json.loads(future.result()))
			except Exception as exc_due:
				if counter == 1:
					debug_MS("x x x x x x x x x x x x x x x x x x x x x x x")
					dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(exc_due), icon, 12000)
				failing(f"(common.trackSeveral[2]) ERROR - EXEPTION - ERROR ##### POS : {section['Count_1']} === IDENT : {section['Link_1'] if method == 'GET' else section['Code_1']} === FAILURE : {exc_due} #####")
				executor.shutdown()
		if COMBI_NEW:
			matching = [flop for flop in COMBI_NEW[:] if flop.get('Status', 'OOKAY') == 'ERROR']
			if len(matching) == number or (method == 'GET' and len(matching) > 7) or (method == 'POST' and len(matching) > 5):
				dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 12000)
	return COMBI_NEW if method == 'GET' else json.dumps(COMBI_NEW, indent=2)

def trackContent(url, method='GET', queries='JSON', headers={}, redirects=True, verify=False, data=None, json=None, timeout=30):
	ANSWER = None
	try:
		response = requests.request(method, url, headers=HEAD_NETZ, allow_redirects=redirects, verify=verify, data=data, json=json, timeout=timeout)
		response.raise_for_status()
		ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
		debug_MS(f"(common.trackContent) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
	except Exception as exc: # No JSON object could be decoded
		failing(f"(common.trackContent) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {exc} #####")
		dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 12000)
		return sys.exit(0)
	return ANSWER

def get_Picture(elem_id, resources, elem_type):
	if elem_type == 'thumbnail' and resources[elem_type] is not None and len(resources[elem_type]) != 0:
		return quote(resources[elem_type], safe='/:?=')
	elif elem_type in resources and resources[elem_type] is not None and isinstance(resources[elem_type], list) and len(resources[elem_type][0]) != 0:
		return quote(resources[elem_type][0], safe='/:?=')
	return None

def get_sorting():
	return [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, xbmcplugin.SORT_METHOD_VIDEO_YEAR, xbmcplugin.SORT_METHOD_DURATION, xbmcplugin.SORT_METHOD_DATE]

def preserve(store, action='JSON', facts=None, arrive=None):
	if facts is not None:
		with open(store, 'w') as topics:
			json.dump(facts, topics, indent=2, sort_keys=True) if action == 'JSON' else topics.write(facts)
	else:
		if xbmcvfs.exists(store) and os.path.exists(store) and os.stat(store).st_size > 0:
			with open(store, 'r') as topics:
				arrive = json.load(topics) if action == 'JSON' else topics.read()
		return arrive

def clear_umlaut(changes):
	if changes is not None:
		for cm in (('Ä', 'Ae'), ('ä', 'ae'), ('Ö', 'Oe'), ('ö', 'oe'), ('Ü', 'Ue'), ('ü', 'ue'), ('ß', 'ss')):
			changes = changes.replace(*cm)
		changes = changes.strip()
	return changes

def cleaning(text):
	if text is not None:
		for tx in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\xc2\xb7', '-'),
			("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''),
			('&#xC4;', 'Ä'), ('&#xE4;', 'ä'), ('&#xD6;', 'Ö'), ('&#xF6;', 'ö'), ('&#xDC;', 'Ü'), ('&#xFC;', 'ü'), ('&#xDF;', 'ß'), ('&#x201E;', '„'), ('&#xB4;', '´'), ('&#x2013;', '-'), ('&#xA0;', ' '),
			('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
			('&agrave;', 'à'), ('&Agrave;', 'À'), ('&aacute;', 'á'), ('&Aacute;', 'Á'), ('&acirc;', 'â'), ('&Acirc;', 'Â'), ('&egrave;', 'è'), ('&Egrave;', 'È'), ('&eacute;', 'é'), ('&Eacute;', 'É'), ('&ecirc;', 'ê'), ('&Ecirc;', 'Ê'),
			('&igrave;', 'ì'), ('&Igrave;', 'Ì'), ('&iacute;', 'í'), ('&Iacute;', 'Í'), ('&icirc;', 'î'), ('&Icirc;', 'Î'), ('&ograve;', 'ò'), ('&Ograve;', 'Ò'), ('&oacute;', 'ó'), ('&Oacute;', 'Ó'), ('&ocirc;', 'ô'), ('&Ocirc;', 'Ô'),
			('&ugrave;', 'ù'), ('&Ugrave;', 'Ù'), ('&uacute;', 'ú'), ('&Uacute;', 'Ú'), ('&ucirc;', 'û'), ('&Ucirc;', 'Û'), ('&yacute;', 'ý'), ('&Yacute;', 'Ý'),
			('&atilde;', 'ã'), ('&Atilde;', 'Ã'), ('&ntilde;', 'ñ'), ('&Ntilde;', 'Ñ'), ('&otilde;', 'õ'), ('&Otilde;', 'Õ'), ('&Scaron;', 'Š'), ('&scaron;', 'š'), ('&ccedil;', 'ç'), ('&Ccedil;', 'Ç'),
			('&alpha;', 'a'), ('&Alpha;', 'A'), ('&aring;', 'å'), ('&Aring;', 'Å'), ('&aelig;', 'æ'), ('&AElig;', 'Æ'), ('&epsilon;', 'e'), ('&Epsilon;', 'Ε'), ('&eth;', 'ð'), ('&ETH;', 'Ð'), ('&gamma;', 'g'), ('&Gamma;', 'G'),
			('&oslash;', 'ø'), ('&Oslash;', 'Ø'), ('&theta;', 'θ'), ('&thorn;', 'þ'), ('&THORN;', 'Þ'), ('&bull;', '•'), ('&iexcl;', '¡'), ('&iquest;', '¿'), ('&copy;', '(c)'), ('\t', '    '), ('<br />', ' - '),
			("&rsquo;", "’"), ("&lsquo;", "‘"), ("&sbquo;", "’"), ('&rdquo;', '”'), ('&ldquo;', '“'), ('&bdquo;', '”'), ('&rsaquo;', '›'), ('lsaquo;', '‹'), ('&raquo;', '»'), ('&laquo;', '«'),
			('\\xC4', 'Ä'), ('\\xE4', 'ä'), ('\\xD6', 'Ö'), ('\\xF6', 'ö'), ('\\xDC', 'Ü'), ('\\xFC', 'ü'), ('\\xDF', 'ß'), ('\\x201E', '„'), ('\\x28', '('), ('\\x29', ')'), ('\\x2F', '/'), ('\\x2D', '-'), ('\\x20', ' '), ('\\x3A', ':'), ('\\"', '"')):
			text = text.replace(*tx)
		text = text.strip()
	return text

def create_entries(metadata, SIGNS=None):
	listitem, CASTING = xbmcgui.ListItem(metadata['Title']), []
	vinfo = listitem.getVideoInfoTag() if KODI_BUILD >= 20 else {}
	if KODI_BUILD >= 20: vinfo.setTitle(metadata['Title'])
	else: vinfo['Title'] = metadata['Title']
	description = metadata['Plot'] if metadata.get('Plot') not in ['', 'None', None] else ' '
	if KODI_BUILD >= 20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if str(metadata.get('Duration')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setDuration(int(metadata['Duration']))
		else: vinfo['Duration'] = metadata['Duration']
	if metadata.get('Date', ''):
		if KODI_BUILD >= 20: listitem.setDateTime(metadata['Date'])
		else: vinfo['Date'] = metadata['Date']
	if str(metadata.get('Year')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setYear(int(metadata['Year']))
		else: vinfo['Year'] = metadata['Year']
	if metadata.get('Genre', ''):
		if KODI_BUILD >= 20: vinfo.setGenres([metadata['Genre']])
		else: vinfo['Genre'] = metadata['Genre']
	if metadata.get('Country', ''):
		if KODI_BUILD >= 20: vinfo.setCountries([metadata['Country']])
		else: vinfo['Country'] = metadata['Country']
	if metadata.get('Director', ''):
		if KODI_BUILD >= 20: vinfo.setDirectors([metadata['Director']])
		else: vinfo['Director'] = metadata['Director']
	if metadata.get('Writer', ''):
		if KODI_BUILD >= 20: vinfo.setWriters([metadata['Writer']])
		else: vinfo['Writer'] = metadata['Writer']
	if metadata.get('Cast', '') and len(metadata['Cast']) > 1:
		for index, person in enumerate(metadata['Cast'], 1):
			actor = {'name': person.get('name'), 'role': person.get('role'), 'order': index, 'thumb': person.get('thumb')}
			if actor['name'] not in ['' , None]:
				CASTING.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb'])) if KODI_BUILD >= 20 else CASTING.append(actor)
	if len(CASTING) < 1 and metadata.get('Stars_Small', '') and len(metadata['Stars_Small']) > 10:
		for index, person in enumerate(metadata['Stars_Small'].split(','), 1):
			actor = {'name': person, 'role': '', 'order': index, 'thumb': ''}
			if actor['name'] not in ['' , None]:
				CASTING.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb'])) if KODI_BUILD >= 20 else CASTING.append(actor)
	if CASTING and len(CASTING) > 0 and KODI_BUILD >= 20: vinfo.setCast(CASTING)
	elif CASTING and len(CASTING) > 0 and KODI_BUILD < 20: listitem.setCast(CASTING)
	if str(metadata.get('Rating')).replace('.', '').isdecimal() and str(metadata.get('Voting')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setRating(float(metadata['Rating']), int(metadata['Voting']), 'imdb', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		else: listitem.setRating('imdb', float(metadata['Rating']), int(metadata['Voting']), True) # listitem.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
	elif str(metadata.get('Rating')).replace('.', '').isdecimal() and not str(metadata.get('Voting')).isdecimal():
		if KODI_BUILD >= 20: vinfo.setRating(float(metadata['Rating']), 0, 'imdb', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		else: listitem.setRating('imdb', float(metadata['Rating']), 0, True) # listitem.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
	if metadata.get('Studio', ''):
		if KODI_BUILD >= 20: vinfo.setStudios([metadata['Studio']])
		else: vinfo['Studio'] = metadata['Studio']
	if metadata.get('Mpaa', ''):
		if KODI_BUILD >= 20: vinfo.setMpaa(str(metadata['Mpaa']))
		else: vinfo['Mpaa'] = str(metadata['Mpaa'])
	if metadata.get('Mediatype', ''):
		if KODI_BUILD >= 20: vinfo.setMediaType(metadata['Mediatype'])
		else: vinfo['Mediatype'] = metadata['Mediatype']
	picture, picbann = metadata.get('Image', icon), metadata.get('Banner', None)
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'banner': picbann, 'fanart': defaultFanart})
	if useThumbAsFanart and metadata.get('Fanback', '') and not artpic in metadata['Fanback']:
		listitem.setArt({'fanart': metadata['Fanback']})
	if metadata.get('Reference') == 'Single': listitem.setProperty('IsPlayable', 'true')
	if KODI_BUILD < 20: listitem.setInfo('Video', vinfo)
	return listitem
