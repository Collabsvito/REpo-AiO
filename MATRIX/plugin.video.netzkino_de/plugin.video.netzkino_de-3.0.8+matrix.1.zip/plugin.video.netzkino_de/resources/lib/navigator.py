﻿# -*- coding: utf-8 -*-

from .common import *
config = traversing.get_config()


def mainMenu():
	addDir({'mode': 'listFavorites'}, create_entries({'Title': translation(30601), 'Image': f"{artpic}watchlist.png"}))
	for pick in config['picks']:
		TITLE, CID, CAT_URL = pick['title'], pick['id'], config['CAT_ENTRIES'].format(pick['id'])
		addDir({'mode': 'listMovies', 'url': CAT_URL, 'category': TITLE, 'section': str(CID)}, create_entries({'Title': TITLE, 'Image': f"{artpic}{CID}.png"}))
	addDir({'mode': 'listGenres'}, create_entries({'Title': translation(30621), 'Image': f"{artpic}genres.png"}))
	addDir({'mode': 'SearchNETZKINO'}, create_entries({'Title': translation(30622), 'Image': f"{artpic}search.png"}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30623), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGenres():
	debug_MS("(navigator.listThemes) ------------------------------------------------ START = listThemes -----------------------------------------------")
	for genre in config['genres']:
		TITLE, CID, PHOTO = genre['title'], genre['id'], config['CAT_THUMB'].format(genre['id'])
		CAT_URL = config['CAT_ENTRIES'].format(CID)
		if approvedAGE is False and int(CID) == 71: continue
		addDir({'mode': 'listMovies', 'url': CAT_URL, 'category': TITLE, 'section': str(CID)}, create_entries({'Title': TITLE, 'Image': PHOTO}))
		debug_MS(f"(navigator.listGenres[1]) ### NAME : {TITLE} || GENRE-ID : {CID} || IMAGE : { PHOTO} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchNETZKINO():
	debug_MS("(navigator.SearchNETZKINO) ------------------------------------------------ START = SearchNETZKINO -----------------------------------------------")
	keyword = preserve(SEARCH_FILE, 'TEXT') if xbmcvfs.exists(SEARCH_FILE) else None
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30625), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword: return listMovies(config['API_SEARCH'].format(keyword), keyword, 'SEARCHING')
	return None

def listMovies(TARGET, CAT, SECTION):
	debug_MS("(navigator.listMovies) ------------------------------------------------ START = listMovies -----------------------------------------------")
	counter, CAT = 0, re.sub('(\[/?B\])', '', CAT)
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND = ([] for _ in range(3))
	STADIVISION = ['SEARCHING', '8', '81', '161', '6611', '6621', '9431', '9441', '10633', '10643']
	GENDIVISION = ['1', '3', '4', '5', '6', '10', '18', '32', '35', '51', '71', '8951', '10333']
	debug_MS(f"(navigator.listMovies) ### URL = {TARGET} ### CATEGORY = {CAT} ###")
	DATA_ONE = getContent(TARGET)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listMovies[1]) XXXXX DATA_ONE-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	for post in DATA_ONE.get('posts', []):
		AIRED_1, BEGINS_1, STREAM_1, ages, MPAA_1, YEAR_1, score, RATING_1, quality, SECONDS_1 = (None for _ in range(10))
		STAFF_1, DIRECTOR_1, GENRE_1 = ([] for _ in range(3))
		if 'Streaming' in post.get('custom_fields', {}) and not 'plus-exclusive' in post.get('properties', {}):
			def get_fields(_post, field_name):
				custom_fields = post.get('custom_fields', {})
				field = custom_fields.get(field_name, [])
				if len(field) >= 1 and len(field[0]) != 0:
					return cleaning(field[0])
				return None
			counter += 1
			SLUG_1 = post.get('slug', '')
			MOVIEIDD_1 = str(post['id'])
			TITLE_1 = cleaning(post['title'])
			try:
				DATE_1 = datetime(*(time.strptime(post['date'][:19], '%Y-%m-%dT%H:%M:%S')[0:6])) # 2021-09-15T17:03:22.050874+00:00
				AIRED_1 = DATE_1.strftime('%d.%m.%Y') # FirstAired
				BEGINS_1 = DATE_1.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else DATE_1.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
			except: pass
			DESC_1 = cleaning(post['content']).replace('\n', '[CR]') if post.get('content', '') and len(post['content']) > 10 else ""
			COUNTRY_1 = cleaning(post['custom_fields']['productionCountry']) if post.get('custom_fields', '') and post['custom_fields'].get('productionCountry', '') else None
			image = (get_Picture(MOVIEIDD_1, post, 'thumbnail') or get_Picture(MOVIEIDD_1, post.get('custom_fields', []), 'Artikelbild'))
			THUMB_1 = image.split('.jpg')[0].rstrip()+'.jpg' if image and '.jpg' in image else image
			banner = get_Picture(MOVIEIDD_1, post.get('custom_fields', []), 'featured_img_seven')
			BANNER_1 = banner.split('.jpg')[0].rstrip()+'.jpg' if banner and '.jpg' in banner else banner
			backdrop = (get_Picture(MOVIEIDD_1, post.get('custom_fields', []), 'featured_img_all') or defaultFanart)
			FANART_1 = backdrop.split('.jpg')[0].rstrip().replace('_slider', '_img_all')+'.jpg' if backdrop and '.jpg' in backdrop else backdrop
			STREAM_1 = get_fields(post, 'Streaming')
			atelier = STREAM_1.replace('plus/', '').split('/')[0].strip().replace('_', ' ') if STREAM_1 else 'Netzkino'
			STUDIO_1 = re.sub(r' flat| SVOD| NKS| NK EV| NK(\d+)?| SG| MG', '', atelier)
			ages = get_fields(post, 'FSK')
			if str(ages).isdecimal():
				MPAA_1 = str(ages)
				if approvedAGE is False and str(ages) == '18': continue
			imdb = get_fields(post, 'IMDb-Link') # https://www.imdb.com/title/tt1772288/ = https://www.imdb.com/de/title/tt1772288/
			IMDBLINK_1 = f"{imdb.replace('http://', 'https://').replace('http:/', 'https://').replace('imdb.com/title', 'imdb.com/de/title')}/" if imdb and not imdb.endswith('/') else \
				imdb.replace('http://', 'https://').replace('http:/', 'https://').replace('imdb.com/title', 'imdb.com/de/title') if imdb and imdb.endswith('/') else None
			YEAR_1 = get_fields(post, 'Jahr')
			score = get_fields(post, 'IMDb-Bewertung')
			if score and score != '0': RATING_1 = score.replace(',', '.')
			STAFF_1 = ','.join([cleaning(star) for star in get_fields(post, 'Stars').split(',')]) if get_fields(post, 'Stars') else [] # Fred Willard,Jennifer Coolidge,Kal Penn
			DIRECTOR_1 = ', '.join([cleaning(seur) for seur in get_fields(post, 'Regisseur').split(',')]) if get_fields(post, 'Regisseur') else [] # Steven Seagal
			GENRE_1 = get_fields(post, 'TV_Movie_Genre') if get_fields(post, 'TV_Movie_Genre') else []
			quality = get_fields(post, 'Adaptives_Streaming')
			if quality and quality == 'HD': TITLE_1 += translation(30644)
			SECONDS_1 = get_fields(post, 'Duration')
			COMBI_FIRST.append([int(counter), MOVIEIDD_1, TITLE_1, AIRED_1, BEGINS_1, THUMB_1, BANNER_1, FANART_1, STREAM_1, STUDIO_1, \
				MPAA_1, IMDBLINK_1, YEAR_1, RATING_1, STAFF_1, DIRECTOR_1, GENRE_1, SECONDS_1, COUNTRY_1, DESC_1])
			if IMDBLINK_1:
				COMBI_LINKS.append([int(counter), IMDBLINK_1])
	if COMBI_FIRST and (META_SMALL or META_LARGE):
		if (META_SMALL and SECTION in STADIVISION) or (META_LARGE and SECTION in GENDIVISION):
			COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_FIRST or COMBI_SECOND:
		RESULT = [av + bv for av in COMBI_FIRST for bv in COMBI_SECOND if av[0] == bv[0] and av[11] == bv[1]] # Zusammenführung von Liste-1 und Liste-2 - wenn die Nummer an erster Stelle(0) und der LINK an zehnter/erster Stelle(10/1) überein stimmt !!!
		RESULT += [cv for cv in COMBI_FIRST if all(dv[0] != cv[0] and dv[1] != cv[11] for dv in COMBI_SECOND)] # Der übriggebliebene Rest von Liste-1 - wenn die Nummer an erster Stelle(0) und der LINK an erster Stelle(1) nicht in der Liste-2 vorkommt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listMovies[3]) XXXXX RESULT-03 : {RESULT} XXXXX")
		for xev in sorted(RESULT, key=lambda evs: int(evs[0])): # Liste-1 = 0-19|| Liste-2 = 20-32 oder 0 #
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listMovies[3]) ### Anzahl : {len(xev)} || Eintrag : {xev} ###")
			operation = 'adding'
			if len(xev) > 32: ### COMBI_FIRST+COMBI_SECOND ist grösser als Nummer:31 ###
				'''
				Liste-1 = Num1, MovieIdd, title, Added1, Begins1, Photo1, banner, background, stream, studio, Mpaa1, ImdbLink1, Year1, Rated1, staff, Director1, Genre1, Seconds1, country, description = xev[0], xev[1], xev[2], xev[3], xev[4], xev[5], xev[6], xev[7], xev[8], xev[9], xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18], xev[19]
				Liste-2 = Num2, ImdbLink2, Photo2, Rated2, voting, Mpaa2, Genre2, Added2, Begins2, Staff2, Director2, writer, Seconds2 = xev[20], xev[21], xev[22], xev[23], xev[24], xev[25], xev[26], xev[27],xev[28], xev[29], xev[30], xev[31], xev[32]
				'''
				Num1, MovieIdd, title, Added1, Begins1, Photo1, banner, background, stream, studio, Mpaa1, ImdbLink1, Year1, Rated1, Staff1, Director1, Genre1, Seconds1, country, description = xev[0], xev[1], xev[2], xev[3], xev[4], xev[5], xev[6], xev[7], xev[8], xev[9], xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18], xev[19]
				Num2, ImdbLink2, Photo2, Rated2, voting, Mpaa2, Genre2, Added2, Begins2, Staff2, Director2, writer, Seconds2 = xev[20], xev[21], xev[22], xev[23], xev[24], xev[25], xev[26], xev[27], xev[28], xev[29], xev[30], xev[31], xev[32]
			elif len(xev) == 20: ### COMBI_FIRST ist gleich Nummer:20 und COMBI_SECOND ist AUS ###
				Num1, MovieIdd, title, Added1, Begins1, Photo1, banner, background, stream, studio, Mpaa1, ImdbLink1, Year1, Rated1, Staff1, Director1, Genre1, Seconds1, country, description = xev[0], xev[1], xev[2], xev[3], xev[4], xev[5], xev[6], xev[7], xev[8], xev[9], xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18], xev[19]
				Num2, ImdbLink2, Photo2, Rated2, voting, Mpaa2, Genre2, Added2, Begins2, Staff2, Director2, writer, Seconds2 = (None for _ in range(13))
			else: continue
			if Added1 or Added2:
				Note_1 = translation(30645).format(Added2) if Added2 else translation(30646).format(Added1)
			else: Note_1 = '[CR]'
			plot = f"{title}[CR]{Note_1}{description}"
			duration = Seconds1 if str(Seconds1).isdecimal() else Seconds2 if str(Seconds2).isdecimal() else None
			begins = Begins2 if Begins2 else Begins1 if Begins1 else None
			year = Added2[6:10] if Added2 else Year1 if Year1 else None
			genre = Genre2 if Genre2 else Genre1 if Genre1 else None
			actors = Staff2 if Staff2 else Staff1 if Staff1 else None
			director = Director2 if Director2 else Director1 if Director1 else None
			rating = Rated2 if Rated2 else Rated1 if Rated1 else None
			agerate = Mpaa2 if Mpaa2 else Mpaa1 if Mpaa1 else None
			mpaa = translation(30647) if agerate and '0' in agerate else translation(30648).format(agerate) if agerate else None
			image = Photo2 if Photo2 else Photo1
			debug_MS(f"(navigator.listMovies[3]) ##### NAME : {title} || IMDB-LINK : {ImdbLink1} || DATE : {begins} #####")
			debug_MS(f"(navigator.listMovies[3]) ##### DIRECTOR : {director} || WRITER : {writer} || GENRE : {genre} || RATING : {rating} #####")
			debug_MS(f"(navigator.listMovies[3]) ##### VIDEO : {config['PLAY_PMD'].format(stream)} || DURATION : {duration} || THUMB : {image} #####")
			for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			FETCH_UNO = context = {'Streaming': stream, 'Title': title, 'Plot': plot, 'Duration': duration, 'Date': begins, 'Year': year, 'Genre': genre, \
				'Country': country, 'Director': director, 'Writer': writer, 'Cast': actors, 'Rating': rating, 'Voting': voting, 'Studio': studio, 'Mpaa': mpaa, \
				'Mediatype': 'movie', 'Image': image, 'Banner': banner, 'Fanback': background, 'Reference': 'Single'}
			if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
				for article in preserve(FAVORIT_FILE):
					if article.get('Streaming') == stream: operation = 'skipping'
			addDir({'mode': 'playVideo', 'url': stream}, create_entries(FETCH_UNO), False, context, operation)
	else:
		failing(f'(navigator.listMovies) ##### NO MOVIE-LIST - NO ENTRY FOR: "{CAT}" FOUND #####')
		return dialog.notification(translation(30525), translation(30526).format(CAT), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSubstances(MURLS):
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		DATA_TWO = json.loads(COMBI_DETAILS)
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listSubstances[2]) XXXXX CONTENT-02  : {DATA_TWO} XXXXX")
		debug_MS("*****************************************")
		for elem in DATA_TWO:
			if elem is not None and elem.get('@context', '') == 'https://schema.org':
				RATING_2, VOTING_2, AIRED_2, BEGINS_2, TIMECODE, SECONDS_2 = (None for _ in range(6))
				GENRE_2, STAFF_2, DIRECTOR_2, CREATOR_2 = ([] for _ in range(4))
				POS_2, DEM_2= elem['Position'], elem['Demand']
				debug_MS(f"(navigator.listSubstances[2]) xxxxx ELEMENT-02 : {elem} xxxxx")
				THUMB_2 = elem['image'] if elem.get('image', '') else None
				if elem.get('aggregateRating', '') and str(elem['aggregateRating'].get('ratingValue')).replace('.', '').isdecimal():
					RATING_2 = elem['aggregateRating']['ratingValue']
				if elem.get('aggregateRating', '') and str(elem['aggregateRating'].get('ratingCount')).isdecimal():
					VOTING_2 = elem['aggregateRating']['ratingCount']
				MPAA_2 = str(elem['contentRating']) if str(elem.get('contentRating')).isdecimal() else None
				GENRE_2 = ' / '.join(sorted([cleaning(gen) for gen in elem.get('genre', {})])) if elem.get('genre', {}) else [] # Drama, Familie, Komödie
				try:
					DATE_2 = datetime(*(time.strptime(elem['datePublished'][:10], '%Y-%m-%d')[0:6])) # 2021-09-15
					AIRED_2 = DATE_2.strftime('%d.%m.%Y') # FirstAired
					BEGINS_2 = DATE_2.strftime('%Y-%m-%dT00:00') if KODI_ov20 else DATE_2.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
				except: pass
				STAFF_2 = ','.join([cleaning(aco.get('name', '')) for aco in elem.get('actor', {}) if aco.get('@type') == 'Person']) if elem.get('actor', {}) else [] # Tom Cruise, Hayley Atwell, Ving Rhames
				DIRECTOR_2 = ', '.join([cleaning(rec.get('name', '')) for rec in elem.get('director', {}) if rec.get('@type') == 'Person']) if elem.get('director', {}) else [] # Steven Seagal
				CREATOR_2 = ', '.join([cleaning(cre.get('name', '')) for cre in elem.get('creator', {}) if cre.get('@type') == 'Person']) if elem.get('creator', {}) else [] # Ed Horowitz, Robin U. Russin
				if elem.get('duration', '') and elem['duration'].startswith('PT') and elem['duration'].endswith('M'):
					try: TIMECODE = datetime(*(time.strptime(elem['duration'], 'PT%HH%MM')[0:6]))
					except ValueError: TIMECODE = datetime(*(time.strptime(elem['duration'], 'PT%MM')[0:6]))
					if TIMECODE: SECONDS_2 = round(timedelta(hours=TIMECODE.hour, minutes=TIMECODE.minute).total_seconds())
				COMBI_THIRD.append([int(POS_2), DEM_2, THUMB_2, RATING_2, VOTING_2, MPAA_2, GENRE_2, AIRED_2, BEGINS_2, STAFF_2, DIRECTOR_2, CREATOR_2, SECONDS_2])
	return COMBI_THIRD

def playVideo(SLUG):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### VIDEO_SLUG = {SLUG} ###")
	if xbmc.Player().isPlaying():
		xbmc.Player().stop()
	STREAM, MIME, FINAL_URL = 'MP4', 'video/mp4', config['PLAY_PMD'].format(SLUG)
	LPM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
	xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
	log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}")

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		for each in sorted(preserve(FAVORIT_FILE), key=lambda vsx: cleanUmlaut(vsx.get('Title', 'zorro')).lower()):
			for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			FETCH_UNO = context = {'Streaming': each.get('Streaming'), 'Title': each.get('Title'), 'Plot': each.get('Plot'), 'Duration': each.get('Duration'), \
				'Date': each.get('Date'), 'Year': each.get('Year'), 'Genre': each.get('Genre'), 'Country': each.get('Country'), 'Director': each.get('Director'), \
				'Writer': each.get('Writer'), 'Cast': each.get('Cast'), 'Rating': each.get('Rating'), 'Voting': each.get('Voting'), 'Studio': each.get('Studio'), \
				'Mpaa': each.get('Mpaa'), 'Mediatype': 'movie', 'Image': each.get('Image'), 'Banner': each.get('Banner'), 'Fanback': each.get('Fanback'), 'Reference': 'Single'}
			debug_MS(f"(navigator.listFavorites[1]) ##### NAME : {each.get('Title')} || DIRECTOR : {each.get('Director')} || WRITER : {each.get('Writer')}" \
				f"|| DATE : {each.get('Date')} #####")
			debug_MS(f"(navigator.listFavorites[1]) ##### VIDEO : {config['PLAY_PMD'].format(each.get('Streaming'))} || DURATION : {each.get('Duration')}" \
				f"|| RATING : {each.get('Rating')} || THUMB : {each.get('Image')} #####")
			addDir({'mode': 'playVideo', 'url': each.get('Streaming')}, create_entries(FETCH_UNO), False, context, 'removing')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favorit_construct(**kwargs):
	TOPS = []
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		del kwargs['mode']; del kwargs['action']
		TOPS.append({key: value if value != 'None' else None for key, value in kwargs.items()})
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30528), translation(30529).format(kwargs['Title']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Streaming') != kwargs.get('Streaming')]
		if len(TOPS) == 0:
			xbmcvfs.delete(FAVORIT_FILE)
		elif len(TOPS) >= 1:
			preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30528), translation(30530).format(kwargs['Title']), icon, 10000)

def addDir(params, listitem, folder=True, context={}, handling='default'):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if handling == 'adding' and context:
		entries.append([translation(30651), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
