﻿# -*- coding: utf-8 -*-

from .common import *


def _header(REFERRER=None, REALM=None, USERTOKEN=None):
	header = {} # !!! Accept-Language only set if browser should offer these languages !!!
	header['Accept'] = 'multipart/mixed; deferSpec=20220824, application/json'
	header['Host'] = 'videohub.bibeltv.de'
	header['Content-Type'] = 'application/json; charset=utf-8' # application/json; charset=utf-8
	if REALM == 'ANDROID':
		header['Host'] = 'authentication.bibeltv.de'
		header['Content-Type'] = 'application/x-www-form-urlencoded; charset=utf-8' # application/x-www-form-urlencoded; charset=utf-8
	elif REALM == 'QUERIES':
		header['Host'] = 'searchcluster.bibeltv.de'
	elif REALM == 'CHURCH':
		header['Host'] = 'service.meingottesdienst.com'
	elif REALM == 'PREVIEW':
		header['Host'] = 'api.bibeltv.de'
	if REALM in ['ANDROID', 'QUERIES', 'CHURCH', 'PREVIEW']:
		header['Accept'] = '*/*'
	header['Cache-Control'] = 'public, max-age=300'
	header['User-Agent'] = 'okhttp/4.11.0'
	header['Accept-Encoding'] = 'gzip'
	if REFERRER:
		header['Referer'] = REFERRER
	if USERTOKEN:
		header['Authorization'] = USERTOKEN[::-1] if REALM in ['QUERIES', 'PREVIEW'] else USERTOKEN
	return header

class Transmission(object):

	def __init__(self):
		self.maxTokenTime = 595 # max. Token-Time (Seconds) before clear the Token and delete Token-File [595 = 10 Minutes]
		self.now_utc = datetime.utcnow()
		self.tempSTORE_folder = tempSTORE
		self.bibeltv_file = storeSECRET

	def clear_content(self, title, filename=None, foldername=None):
		debug_MS(f"(utilities.clear_content) ### DELETE OLD-FILE : * {title} * ###")
		if filename is not None and xbmcvfs.exists(filename):
			if foldername is not None and xbmcvfs.exists(foldername) and os.path.exists(foldername):
				shutil.rmtree(foldername, ignore_errors=True)

	def save_content(self, title, filename=None, foldername=None, text=""):
		debug_MS(f"(utilities.save_content) ### SAVE NEW-FILE : * {title} * ###")
		if foldername is not None:
			os.makedirs(foldername, exist_ok=True)
		if filename is not None and text != "":
			with open(filename, 'w') as save:
				json.dump(text, save, indent=2, sort_keys=True)

	def convert_epoch(self, epoch):
		CIPHER = datetime(1970,1,1) + timedelta(seconds=int(epoch))
		return CIPHER.strftime('%d.%m.%Y - %H:%M:%S')

	def check_FreeToken(self):
		debug_MS("(utilities.check_FreeToken) ##### START check_FreeToken #####")
		CODING, forceRenew, AUTH_TOKEN = False, False, None
		if xbmcvfs.exists(self.bibeltv_file) and os.path.isfile(self.bibeltv_file):
			self.NOW_UTC, self.FILE_UTC = time.time(), (os.path.getmtime(self.bibeltv_file) + self.maxTokenTime)
			debug_MS(f"(utilities.check_FreeToken) ##### SESSION-Time (utc NOW) = {str(self.convert_epoch(self.NOW_UTC))} || VALID until (utc SESSION) = {str(self.convert_epoch(self.FILE_UTC))} #####")
			if self.NOW_UTC < self.FILE_UTC:
				try:
					with open(self.bibeltv_file, 'r') as publish:
						ACC_DATA = json.load(publish)
					AUTH_TOKEN = f"Bearer {ACC_DATA['access_token']}"
					debug_MS("(utilities.check_FreeToken) ##### NOTHING CHANGED - TOKENFILE IS OKAY #####")
				except:
					failing("(utilities.check_FreeToken) XXXXX !!! ERROR = TOKENFILE [TOKENFORMAT IS INVALID] = ERROR !!! XXXXX")
					forceRenew = True
			else:
				debug_MS("(utilities.check_FreeToken) ##### TIMEOUT FOR TOKEN - DELETE TOKENFILE #####")
				forceRenew = True
		else:
			debug_MS("(utilities.check_FreeToken) ##### NOTHING FOUND - CREATE TOKENFILE FOR BIBELTV #####")
			forceRenew = True
		if forceRenew:
			self.clear_content('FREE_SECRET', self.bibeltv_file, self.tempSTORE_folder)
			PAYLOAD = 'client_id=video-hub-app&grant_type=client_credentials&client_secret=e908b2ed-42bc-44ab-bb61-e675d5fba330'
			CODING = self.retrieveContent(ACCESS_URL, method='POST', PRO='ANDROID', forcing=False, data=PAYLOAD)
			if CODING:
				debug_MS(f"(utilities.check_FreeToken) ***** NEW TOKENFILE CREATED : {CODING} *****")
				self.save_content('FREE_SECRET', self.bibeltv_file, self.tempSTORE_folder, CODING)
				AUTH_TOKEN = f"Bearer {CODING['access_token']}"
		return AUTH_TOKEN

	def retrieveContent(self, url, method='GET', REF=None, PRO=None, forcing=True, headers=None, cookies=None, allow_redirects=True, verify=False, stream=None, data=None, json=None, timeout=30):
		ANSWER = None
		ACTUCODE = self.check_FreeToken() if forcing is True else PROGRAM_AUTH if url.startswith('https://api.bibeltv') else SEARCH_AUTH if url.startswith('https://searchcluster') else None
		try:
			if method in ['GET', 'LOAD', 'TRACK']:
				response = requests.get(url, headers=_header(REF, PRO, ACTUCODE), allow_redirects=allow_redirects, verify=verify, stream=stream, timeout=timeout)
			elif method in ['POST', 'PUSH']:
				response = requests.post(url, headers=_header(REF, PRO, ACTUCODE), allow_redirects=allow_redirects, verify=verify, data=data, json=json, timeout=timeout)
			response.raise_for_status()
			ANSWER = response.json() if method in ['GET', 'POST'] else response.text if method == 'LOAD' else response
			debug_MS(f"(utilities.retrieveContent) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {_header(REF, PRO, ACTUCODE)} || DATA : {data} ===")
			debug_MS("---------------------------------------------")
			if method in ['POST', 'PUSH'] and response.json().get('errors', ''):
				message = (response.json().get('errors', {})[0].get('message', '') or 'NO DETAILS FOUND')
				failing(f"(utilities.retrieveContent) ERROR - RESPONSE - ERROR ##### URL : {url} === DETAIL : {message} #####")
				dialog.notification(translation(30521).format('URL'), translation(30523).format(message), icon, 10000)
				return sys.exit(0)
		except Exception as e: # No JSON object could be decoded
			failing(f"(utilities.retrieveContent) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {str(e)} ===DATA : {data} #####")
			dialog.notification(translation(30521).format('URL'), translation(30523).format(str(e)), icon, 10000)
			return sys.exit(0)
		return ANSWER
