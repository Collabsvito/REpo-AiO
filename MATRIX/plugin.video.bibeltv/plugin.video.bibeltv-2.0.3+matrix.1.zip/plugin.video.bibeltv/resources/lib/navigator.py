﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listEpisodes', 'url': '/neue-sendungen.json', 'first': 'neueSendungen', 'last': 'videos'})
	addDir(translation(30602), icon, {'mode': 'listEpisodes', 'url': '/letzte-chance.json', 'first': 'letzteChance', 'last': 'videos'})
	addDir(translation(30603), icon, {'mode': 'listEpisodes', 'url': '/meistgesehen.json', 'first': 'meistgesehen', 'last': 'videos'})
	addDir(translation(30604), icon, {'mode': 'listEpisodes', 'url': '/playlists/16.json', 'first': 'playlist', 'last': 'playlists', 'transmit': 'Exklusiv: Nur in der Mediathek'})
	addDir(translation(30605), icon, {'mode': 'listTopics', 'url': '/index.json', 'first': 'page', 'last': 'playlists'})
	addDir(translation(30606), icon, {'mode': 'listEpisodes', 'url': '/sendereihen.json', 'first': 'sendereihen', 'last': 'series'})
	addDir(translation(30607), icon, {'mode': 'listTopics', 'url': '/genres.json', 'first': 'genres', 'last': 'genres'})
	addDir(translation(30608), icon, {'mode': 'listEpisodes', 'url': '/genres/spielfilm.json', 'first': 'genre', 'last': 'genres', 'transmit': 'Spielfilme'})
	addDir(translation(30609), icon, {'mode': 'listEpisodes', 'url': '/serien.json', 'first': 'serien', 'last': 'series', 'transmit': 'Serien'})
	addDir(translation(30610), icon, {'mode': 'listEpisodes', 'url': '/genres/dokumentation.json', 'first': 'genre', 'last': 'genres', 'transmit': 'Dokumentationen'})
	addDir(translation(30611), icon, {'mode': 'listEpisodes', 'url': '/genres/kinder.json', 'first': 'genre', 'last': 'genres', 'transmit': 'Kinder'})
	addDir(translation(30612), artpic+'livestream.png', {'mode': 'liveTV'})
	if enableADJUSTMENT:
		addDir(translation(30613), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if prefSTREAM in ['0', '1'] and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30614), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('prefer_stream', '2')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTopics(url, FIRST, LAST):
	debug_MS("(navigator.listTopics) ------------------------------------------------ START = listTopics -----------------------------------------------")
	debug_MS(f"(navigator.listTopics) ### URL : {url} ### FIRST : {FIRST} ### LAST : {LAST} ###")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
	DATA = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listTopics[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if 'index.json' in url and DATA is not None and DATA.get('pageProps', '') and  DATA['pageProps'].get('playlists', '') and LAST in DATA['pageProps']['playlists'].get(FIRST+'Collection', []):
		for item in DATA['pageProps']['playlists'].get(FIRST+'Collection', {}).get(LAST, ''):
			image = icon
			playlistID = str(item['id'])
			name = cleaning(item['webName'])
			if item.get('videos', '') and len(item['videos']) > 0:
				if item.get('videos', {})[0].get('images', '') and item.get('videos', [])[0].get('images', {})[0].get('url', ''):
					image = item['videos'][0]['images'][0]['url']
			elif item.get('series', '') and len(item['series']) > 0:
				if item.get('series', {})[0].get('images', '') and item.get('series', [])[0].get('images', {})[0].get('url', ''):
					image = item['series'][0]['images'][0]['url']
			else: continue
			NEW_URL = f"/playlists/{playlistID}.json"
			addDir(name, image, {'mode': 'listEpisodes', 'url': NEW_URL, 'first': 'playlist', 'last': 'playlists', 'transmit': name}, background=False)
			debug_MS(f"(navigator.listTopics[2]) no.02 ### NAME : {name} || IDD : {playlistID} || IMAGE : {image} ###")
	elif 'genres.json' in url and DATA is not None and DATA.get('pageProps', '') and LAST in DATA['pageProps'].get(FIRST+'PageData', []):
		for item in DATA['pageProps'].get(FIRST+'PageData', {}).get(LAST, ''):
			genreID = str(item['id'])
			name = cleaning(item['name'])
			NEW_URL, FIRST, LAST = f"/genres/{genreID}.json", 'genre', 'genres'
			addDir(name, icon, {'mode': 'listEpisodes', 'url': NEW_URL, 'first': FIRST, 'last': LAST, 'transmit': name})
			debug_MS(f"(navigator.listGenres[2]) ### NAME : {name} || genreID : {genreID} || NEW_URL : {NEW_URL} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, FIRST, LAST, SERIE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL : {url} ### FIRST : {FIRST} ### LAST : {LAST} ### SERIE : {SERIE} ###")
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_THIRD = ([] for _ in range(4))
	counter = 0
	DATA_ONE = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listEpisodes[1]) XXXXX CONTENT-01 : {str(DATA_ONE)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if DATA_ONE is not None and DATA_ONE.get('pageProps', '') and LAST in DATA_ONE['pageProps'].get(FIRST+'PageData', {}):
		special = DATA_ONE['pageProps'].get(FIRST+'PageData', []) if LAST in ['series', 'videos'] else DATA_ONE['pageProps'].get(FIRST+'PageData', {}).get(LAST, [])[0]
		for key, value in special.items():
			#log(f"(navigator.listEpisodes[1]) ##### KEY : {key} || VALUE : {value} #####")
			if key in ['series', 'videos', LAST] and value is not None:
				elements = value if isinstance(value, list) else [value]
				for item in elements:
					NOTE_1, NOTE_2, NOTE_3, NOTE_4, DESC_1 = ("" for _ in range(5))
					ORIGSERIE_1, DURATION_1, startTIMES, AIRED_1, BEGINS_1, endTIMES, POSTER_1, THUMB_1, BANNER_1, GENRE_1 = (None for _ in range(10))
					genreLIST_1 = []
					FANART_1 = defaultFanart
					debug_MS(f"(navigator.listEpisodes[2]) xxxxx ELEM-02 : {str(item)} xxxxx")
					episID_1 = item.get('id', '00')
					SLUG_1 = item['slug'] if item.get('slug', '') else None
					DURATION_1 = int(item['duration']) // 1000 if str(item.get('duration')).isdigit() else None
					CRN_1 = (item.get('crn', None) or None)
					VIDEOCOUNT_1 = (item.get('videoCount', None) or None)
					TITLE_1 = cleaning(item['title'])
					if item.get('subtitle', ''):
						ORIGSERIE_1 = cleaning(item['subtitle'])
						NOTE_1 = translation(30621).format(ORIGSERIE_1)
						TITLE_1 = TITLE_1+' - '+ORIGSERIE_1
					SEASON_1 = str(item['seasonNumber']).zfill(2) if item.get('seasonNumber', '') else None
					EPISODE_1 = str(item['episodeNumber']).zfill(2) if item.get('episodeNumber', '') else None
					if str(EPISODE_1).isdigit() and str(EPISODE_1) != '0':
						NOTE_2 = translation(30622).format(SEASON_1, EPISODE_1) if SEASON_1 else translation(30623).format(EPISODE_1)
						if showEPIS:
							NOTE_4 = translation(30624).format(SEASON_1, EPISODE_1) if SEASON_1 else translation(30625).format(EPISODE_1)
					if str(item.get('schedulingStart'))[:4].isdigit() and str(item.get('schedulingStart'))[:4] not in ['0', '1970']: # 2022-03-04T19:15:18.000Z
						LOCALstart = get_Local_DT(item['schedulingStart'][:19])
						if (datetime.now() + timedelta(days=3)) < LOCALstart:
							continue
						if datetime.now() < LOCALstart:
							TITLE_1 = translation(30626).format(str(COL_MARKING), TITLE_1) # Plum = FFDDA0DD // FFFFDEAD = NavajoWhite1 // FFFFF68F = khaki1 // FFFFC125 = goldenrod1
						startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						AIRED_1 = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # FirstAired
						BEGINS_1 = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
						if KODI_ov20:
							BEGINS_1 = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
					if str(item.get('schedulingEnd'))[:4].isdigit() and str(item.get('schedulingEnd'))[:4] not in ['0', '1970']: # 2022-03-11T19:15:18.000Z
						LOCALend = get_Local_DT(item['schedulingEnd'][:19])
						endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
					if startTIMES and endTIMES: NOTE_3 = translation(30627).format(str(startTIMES), str(endTIMES))
					elif startTIMES and endTIMES is None: NOTE_3 = translation(30628).format(str(startTIMES))
					else: NOTE_3 = '[CR]'
					if item.get('genres', '') and isinstance(item['genres'], list):
						genreLIST_1 = [gen.get('name', '') for gen in item['genres']]
						if genreLIST_1: GENRE_1 = ' / '.join(sorted(genreLIST_1))
					DESC_1 = get_Description(item)
					if item.get('images', '') and isinstance(item['images'], list):
						num, resources = item.get('id', ''), item.get('images', [])
						POSTER_1 = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
						THUMB_1 = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
						BANNER_1 = get_Picture(num, resources, 'cover')
						FANART_1 = (get_Picture(num, resources, 'basic') or get_Picture(num, resources, 'thumbnail') or defaultFanart)
					counter += 1
					if enableLIMIT and LIMIT_NUMBER == counter: break
					COMBI_FIRST.append([int(counter), episID_1, SLUG_1, CRN_1, VIDEOCOUNT_1, TITLE_1, ORIGSERIE_1, SEASON_1, EPISODE_1, DURATION_1, BEGINS_1, AIRED_1, POSTER_1, THUMB_1, BANNER_1, FANART_1, GENRE_1, NOTE_1, NOTE_2, NOTE_3, NOTE_4, DESC_1])
					if (FOLDER_METAS is True and key == 'series') or (VIDEO_METAS is True and key == 'videos'):
						URL_TWO = f"{API_BASE}{addon.getSetting('new_staticCODE')}/videos/{SLUG_1}.json" if key == 'videos' else f"{API_BASE}{addon.getSetting('new_staticCODE')}/serien/{SLUG_1}.json"
						COMBI_LINKS.append([int(counter), URL_TWO])
	if COMBI_FIRST:
		COMBI_SECOND = getMultiData(COMBI_LINKS)
		if COMBI_SECOND:
			DATA_TWO = json.loads(COMBI_SECOND)
			#log("++++++++++++++++++++++++")
			#log(f"(navigator.listEpisodes[3]) XXXXX CONTENT-03 : {str(DATA_TWO)} XXXXX")
			#log("++++++++++++++++++++++++")
			for elem in DATA_TWO:
				if elem is not None and elem.get('pageProps', '') and (elem['pageProps'].get('seriePageData', []) or elem['pageProps'].get('videoPageData', [])):
					COUNTRY_2, DIRECTOR_2, CAST_2, DESC_2 = ("" for _ in range(4))
					POSTER_2, THUMB_2, BANNER_2, MPAA_2, YEAR_2, GENRE_2 = (None for _ in range(6))
					countryLIST_2, directorLIST_2, castLIST_2, genreLIST_2 = ([] for _ in range(4))
					POS, DEM = elem['Position'], elem['Demand']
					FANART_2 = defaultFanart
					debug_MS(f"(navigator.listEpisodes[3]) xxxxx ELEM-03 : {str(elem)} xxxxx")
					SHORT = elem['pageProps']['seriePageData'] if elem['pageProps'].get('seriePageData', []) else elem['pageProps']['videoPageData']['videos'][0]
					markID_2 = SHORT.get('id', '00')
					if SHORT.get('videos', '') and len(SHORT.get('videos')) > 0:
						num, resources = SHORT.get('id', ''), SHORT.get('videos', [])[0].get('images', {})
						POSTER_2 = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
						THUMB_2 = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
						BANNER_2 = get_Picture(num, resources, 'cover')
						FANART_2 = (get_Picture(num, resources, 'basic') or get_Picture(num, resources, 'thumbnail') or defaultFanart)
					if str(SHORT.get('fsk')) not in ['None', '0', 'nicht definiert']:
						MPAA_2 = str(SHORT['fsk']).replace('ab 0 Jahre -', '').replace('freigegeben', '').strip()
					if SHORT.get('productionYear', '') and str(SHORT.get('productionYear', {}).get('from', '')).isdigit():
						YEAR_2 = SHORT['productionYear']['from']
					if SHORT.get('productionCountry', '') and isinstance(SHORT['productionCountry'], list):
						countryLIST_2 = [one for one in SHORT['productionCountry']]
						if countryLIST_2: COUNTRY_2 = ', '.join(sorted(countryLIST_2))
					if SHORT.get('personsShown', '') and isinstance(SHORT['personsShown'], list):
						directorLIST_2 = [cleaning(psDIRK['person'].get('name', '')) for psDIRK in SHORT['personsShown'] if psDIRK.get('person', '') and psDIRK.get('function', '') == 'director']
						if directorLIST_2: DIRECTOR_2 = ', '.join(sorted(directorLIST_2))
						for index, psCAST in enumerate(SHORT['personsShown'], 1):
							if psCAST.get('person', '') and psCAST['person'].get('name', '') and psCAST.get('function', '') == 'cast':
								actor = {'name': cleaning(psCAST['person']['name']), 'role': cleaning(psCAST.get('role', '')), 'order': index, 'thumb': ''}
								if actor['name'] not in ['' , None]:
									if KODI_ov20:
										castLIST_2.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
									else: castLIST_2.append(actor)
					if SHORT.get('genres', '') and isinstance(SHORT['genres'], list):
						genreLIST_2 = [two.get('name', '') for two in SHORT['genres']]
						if genreLIST_2: GENRE_2 = ' / '.join(sorted(genreLIST_2))
					VOTES_2 = (SHORT.get('likeCount', None) or None)
					DESC_2 = get_Description(SHORT)
					COMBI_THIRD.append([markID_2, POSTER_2, THUMB_2, BANNER_2, FANART_2, GENRE_2, MPAA_2, YEAR_2, COUNTRY_2, DIRECTOR_2, castLIST_2, VOTES_2, DESC_2])
	if COMBI_THIRD or (not COMBI_THIRD and COMBI_FIRST):
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_THIRD if a[1] == b[0]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		RESULT += [c for c in COMBI_FIRST if all(d[0] != c[1] for d in COMBI_THIRD)] # Der übriggebliebene Rest von Liste1 - wenn die ID nicht in der Liste2 vorkommt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listEpisodes[4]) XXXXX RESULT-04 : {str(RESULT)} XXXXX")
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda k: int(k[0]), reverse=False):
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listEpisodes[4]) ### Anzahl = {str(len(da))} || Eintrag : {str(da)} ###")
			Genre2, Poster2, Thumb2 = (None for _ in range(3))
			if len(da) > 22: ### Liste2 beginnt mit Nummer:22 ###
				episID, slug, crn, videoCount, title, seriesname, season, episode, duration, begins, aired = da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10], da[11]
				Poster1, Thumb1, Banner1, Fanart1, Genre1, Note_1, Note_2, Note_3, Note_4, Desc1 = da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19], da[20], da[21]
				Poster2, Thumb2, Banner2, Fanart2, Genre2, mpaa, year, country, director, cast, votes, Desc2 = da[23], da[24], da[25], da[26], da[27], da[28], da[29], da[30], da[31], da[32], da[33], da[34]
			else:
				episID, slug, crn, videoCount, title, seriesname, season, episode, duration, begins, aired = da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10], da[11]
				Poster1, Thumb1, Banner1, Fanart1, Genre1, Note_1, Note_2, Note_3, Note_4, Desc1 = da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19], da[20], da[21]
				mpaa, year, country, director, cast, votes = None, None, "", "", "", None
			if crn and duration:
				uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playVideo', 'url': episID, 'extras': slug}))
				folder = False
			elif (crn is None or videoCount) and duration is None and slug:
				NEW_URL = f"/serien/{slug}.json"
				uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'listEpisodes', 'url': NEW_URL, 'first': 'serie', 'last': 'videos', 'transmit': title}))
				folder = True
			genre = Genre2 if Genre2 and Genre1 is None else Genre1 # genre = GENRE_2 if GENRE_2 and GENRE_1 is None else GENRE_1
			FULL_DESC = Desc2 if len(da) > 22 and len(Desc2) > len(Desc1) else Desc1 # FULL_DESC = DESC_2 if len(DESC_2) > len(DESC_1) else DESC_1
			plot = Note_1+Note_2+Note_3+FULL_DESC
			name = title+Note_4
			poster, thumb, banner, fanart = Poster1, Thumb1, Banner1, Fanart1
			if Poster1 is None and Thumb1 is None and (Poster2 is not None or Thumb2 is not None):
				poster, thumb, banner, fanart = Poster2, Thumb2, Banner2, Fanart2
			debug_MS(f"(navigator.listEpisodes[5]) ##### NAME : {name} || IDD : {episID} || GENRE : {str(genre)} #####")
			debug_MS(f"(navigator.listEpisodes[5]) ##### SERIE : {str(seriesname)} || SEASON : {str(season)} || EPISODE : {str(episode)} #####")
			debug_MS(f"(navigator.listEpisodes[5]) ##### FSK : {str(mpaa)} || THUMB : {str(thumb)} || POSTER : {str(poster)} #####")
			if not folder:
				for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			cineType = 'episode' if str(episode).isdigit() else 'movie'
			LEM = xbmcgui.ListItem(name)
			if plot in ['', 'None', None]: plot = "..."
			if KODI_ov20:
				vinfo = LEM.getVideoInfoTag()
				if str(season).isdigit(): vinfo.setSeason(int(season))
				if str(episode).isdigit(): vinfo.setEpisode(int(episode))
				vinfo.setTvShowTitle(seriesname)
				vinfo.setTitle(name)
				vinfo.setPlot(plot)
				if str(duration).isdigit(): vinfo.setDuration(int(duration))
				if begins: LEM.setDateTime(begins)
				if aired: vinfo.setFirstAired(aired)
				if year: vinfo.setYear(int(year))
				vinfo.setCountries([country])
				if genre and len(genre) > 4: vinfo.setGenres([genre])
				vinfo.setDirectors([director])
				if isinstance(cast, (list, tuple)): vinfo.setCast(cast)
				if votes: vinfo.setVotes(int(votes))
				vinfo.setStudios(['bibel.TV'])
				vinfo.setMpaa(mpaa)
				if not folder: vinfo.setMediaType(cineType)
			else:
				vinfo = {}
				if isinstance(cast, (list, tuple)): LEM.setCast(cast)
				if str(season).isdigit(): vinfo['Season'] = season
				if str(episode).isdigit(): vinfo['Episode'] = episode
				vinfo['Tvshowtitle'] = seriesname
				vinfo['Title'] = name
				vinfo['Plot'] = plot
				if str(duration).isdigit(): vinfo['Duration'] = duration
				if begins: vinfo['Date'] = begins
				if aired: vinfo['Aired'] = aired
				if year: vinfo['Year'] = year
				vinfo['Country'] = country
				if genre and len(genre) > 4: vinfo['Genre'] = genre
				vinfo['Director'] = director
				if votes: vinfo['Votes'] = votes
				vinfo['Studio'] = 'bibel.TV'
				vinfo['Mpaa'] = mpaa
				if not folder: vinfo['Mediatype'] = cineType
				LEM.setInfo(type='Video', infoLabels=vinfo)
			LEM.setArt({'icon': icon, 'thumb': thumb, 'poster': poster, 'banner': banner, 'fanart': fanart})
			if not folder:
				LEM.setProperty('IsPlayable', 'true')
				LEM.setContentLookup(False)
				LEM.addContextMenuItems([(translation(30654), 'Action(Queue)')])
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LEM, isFolder=folder)
	else:
		debug_MS("(navigator.listEpisodes[2]) ##### Keine COMBI_EPISODE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30526), translation(30527).format(SERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(PLID, EXTRA):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### PLID : {PLID} ### SLUG : {EXTRA} ###")
	STREAM, FINAL_URL, DEVINE, LICE = (False for _ in range(4))
	MEDIAS = [] # https://www.bibeltv.de/mediathek/api/video/17165
	DATA = getUrl(API_PLAYER+PLID, REF='https://www.bibeltv.de/mediathek/videos/'+EXTRA.replace('…', ''), AUTH=BTV_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.playVideo[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if DATA is not None and DATA.get('status', '') == 'success':
		for elem in DATA['video']['videoUrls']:
			TYPE, VIDEO = elem['type'], elem['src']
			DEVINE = elem['keySystem']['widevine']['url'] if TYPE == 'application/dash+xml' and elem.get('keySystem', '') and elem['keySystem'].get('widevine', '') and elem['keySystem']['widevine'].get('url', '') else None
			MEDIAS.append({'video': VIDEO, 'mime': TYPE, 'licenseUrl': DEVINE})
			if (prefSTREAM == '0' or DEVINE) and '.mpd' in VIDEO and TYPE == 'application/dash+xml':
				STREAM, MIME, FINAL_URL, LICE = 'MPD', TYPE, VIDEO, DEVINE
				debug_MS("(navigator.playVideo[2]) ***** TAKE - Inputstream (mpd) - FILE *****")
		if not FINAL_URL and MEDIAS:
			for item in MEDIAS:
				if '.m3u8' in item['video'] and item['mime'] in ['application/vnd.apple.mpegurl', 'application/x-mpegURL'] and not LICE:
					STREAM = 'M3U8' if prefSTREAM == '2' else 'HLS'
					MIME, FINAL_URL = item['mime'], item['video']
					debug_MS("(navigator.playVideo[2]) ***** TAKE - Inputstream (hls) - FILE *****")
		if not FINAL_URL and MEDIAS:
			for item in MEDIAS:
				if '.mp4' in item['video'] and item['mime'] == 'video/mp4' and not LICE:
					STREAM, MIME, FINAL_URL = 'MP4', item['mime'], item['video']
					debug_MS("(navigator.playVideo[2]) ***** TAKE - mp4 (last Chance) -  FILE *****")
	if FINAL_URL and STREAM:
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		if ADDON_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			LSM.setMimeType(MIME)
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LSM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
			if KODI_ov20:
				LSM.setProperty('inputstream.adaptive.manifest_headers', f"User-Agent={get_userAgent()}")
			else: # DEPRECATED ON Kodi v20, please use 'inputstream.adaptive.manifest_headers' instead.
				LSM.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={get_userAgent()}")
			if LICE:
				LSM.setProperty('inputstream.adaptive.license_key', LICENSE_URL.format(LICE, get_userAgent(), 'R{SSM}'))
				debug_MS("(navigator.playVideo) LICENSE : "+LICENSE_URL.format(LICE, get_userAgent(), 'R{SSM}'))
				LSM.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}|User-Agent={get_userAgent()}")
	else:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### PLID : {PLID} || SLUG : {EXTRA} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *bibeltv.de* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('STREAM'), translation(30528), icon, 8000)

def liveTV():
	debug_MS("(navigator.liveTV) ------------------------------------------------ START = liveTV -----------------------------------------------")
	CHANNELS = [
		{'name': translation(30641), 'url': 'https://bibeltv01.iptv-playoutcenter.de/bibeltv01/bibeltv01.stream_all/playlist.m3u8', 'idd': 'bibeltv', 'tag': 'Das Hauptprogramm von Bibel TV im Livestream.[CR]'},
		{'name': translation(30642), 'url': 'https://bibeltv02.iptv-playoutcenter.de/bibeltv02/bibeltv02.stream_all/playlist.m3u8', 'idd': 'impuls', 'tag': 'Livestream des Kanals "Bibel TV - Impuls", der Predigt-Kanal.[CR]'},
		{'name': translation(30643), 'url': 'https://bibeltv03.iptv-playoutcenter.de/bibeltv03/bibeltv03.stream_all/playlist.m3u8', 'idd': 'echtjetzt', 'tag': 'Livestream des Kanals "EchtJetzt", EchtJetzt zeigt den ganzen Tag echte Geschichten aus dem Alltag echter Menschen.[CR]'}]
	title_1, desc_1, genre_1, title_2, desc_2, genre_2 = ("" for _ in range(6))
	link_1, start_1, start_2 = (None for _ in range(3))
	getUrl(HOME_URL, method='LOAD')
	xbmc.sleep(2000)
	content = getUrl(HOME_URL, method='LOAD')
	results = re.findall(r'<div class="live-programm-list channel (?:active)?" data-channel=(.+?)title="Zur Programmübersicht"', content, re.S)
	for chtml in results:
		debug_MS(f"(navigator.liveTV[1]) no.01 xxxxx ELEM : {str(chtml)} xxxxx")
		DATA_TWO = re.search('next" class="list-group-item list-group-item-action', chtml)
		PTL = re.compile(r'class="live-programm-title track-link" href="([^"]+)"', re.S).findall(chtml)
		if PTL: link_1 = cleaning(PTL[0])
		CPT = re.compile(r'class="programm-title">(.*?)</', re.S).findall(chtml)
		if CPT: title_1 = cleaning(CPT[0])
		if DATA_TWO and CPT and len(CPT) == 2: title_2 = cleaning(CPT[1])
		CET = re.compile(r'class="episode-title">(.*?)</', re.S).findall(chtml)
		if CET: desc_1 = cleaning(CET[0])
		if DATA_TWO and CET and len(CET) == 2: desc_2 = cleaning(CET[1])
		CGS = re.compile(r'class="genre"><small>(.*?)</', re.S).findall(chtml)
		if CGS: genre_1 = cleaning(CGS[0])
		if DATA_TWO and CGS and len(CGS) == 2: genre_2 = cleaning(CGS[1])
		TDT = re.compile(r'class="time" data-time="([^"]+)Z">', re.S).findall(chtml)
		if TDT:
			LSTA = get_Local_DT(TDT[0][:19])
			start_1 = LSTA.strftime('%H:%M')
		if DATA_TWO and TDT and len(TDT) == 2:
			LSTB = get_Local_DT(TDT[1][:19])
			start_2 = LSTB.strftime('%H:%M')
		if start_1: plot = translation(30644).format(start_1, title_1, genre_1, desc_1)
		if start_2: plot += translation(30645).format(start_2, title_2, genre_2, desc_2)
		for elem in CHANNELS:
			if link_1 and elem['idd'] in link_1:
				addDir(elem['name'], f"{artpic}{elem['idd']}.jpg", {'mode': 'playLIVE', 'url': elem['url'], 'extras': elem['name']}, elem['tag'], plot, background=False, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playLIVE(url, NAME):
	log(f"(navigator.playLIVE) LiveURL : {url}")
	LTM = xbmcgui.ListItem(path=url, label=translation(30646).format(NAME))
	LTM.setMimeType('application/vnd.apple.mpegurl')
	if ADDON_operate('inputstream.adaptive'):
		LTM.setProperty('inputstream', 'inputstream.adaptive')
		if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			LTM.setProperty('inputstream.adaptive.manifest_type', 'hls')
			# THE "full" BEHAVIOUR PARAM HAS BEEN REMOVED ON Kodi v21 because now enabled by default
			LTM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
	xbmc.Player().play(item=url, listitem=LTM)

def addDir(name, image, params={}, tag=None, plot=None, background=True, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setTagLine(tag), vinfo.setPlot(plot), vinfo.setStudios(['bibel.TV'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Tagline': tag, 'Plot': plot, 'Studio': 'bibel.TV'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
