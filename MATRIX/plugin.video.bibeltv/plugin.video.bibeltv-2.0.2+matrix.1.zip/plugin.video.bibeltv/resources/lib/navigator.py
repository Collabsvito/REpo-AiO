﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
from urllib.parse import urlencode

from .common import *


def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listEpisodes', 'url': '/neue-sendungen.json', 'first': 'neueSendungen', 'last': 'videos'})
	addDir(translation(30602), icon, {'mode': 'listEpisodes', 'url': '/letzte-chance.json', 'first': 'letzteChance', 'last': 'videos'})
	addDir(translation(30603), icon, {'mode': 'listEpisodes', 'url': '/meistgesehen.json', 'first': 'meistgesehen', 'last': 'videos'})
	addDir(translation(30604), icon, {'mode': 'listTopics', 'url': '/index.json', 'first': 'page', 'last': 'playlists'})
	addDir(translation(30605), icon, {'mode': 'listEpisodes', 'url': '/sendereihen.json', 'first': 'sendereihen', 'last': 'series'})
	addDir(translation(30606), icon, {'mode': 'listTopics', 'url': '/genres.json', 'first': 'genres', 'last': 'genres'})
	addDir(translation(30607), icon, {'mode': 'listEpisodes', 'url': '/genres/spielfilm.json', 'first': 'genre', 'last': 'genres', 'transmit': 'Spielfilm'})
	addDir(translation(30608), icon, {'mode': 'listEpisodes', 'url': '/playlists/51.json', 'first': 'playlist', 'last': 'playlists', 'transmit': 'Serien'})
	addDir(translation(30609), icon, {'mode': 'listEpisodes', 'url': '/genres/dokumentation.json', 'first': 'genre', 'last': 'genres', 'transmit': 'Dokumentation'})
	addDir(translation(30610), icon, {'mode': 'listEpisodes', 'url': '/genres/kinder.json', 'first': 'genre', 'last': 'genres', 'transmit': 'Kinder'})
	addDir(translation(30611), artpic+'livestream.png', {'mode': 'liveTV'})
	if enableADJUSTMENT:
		addDir(translation(30612), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if prefSTREAM in ['0', '1'] and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30613), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('prefer_stream', '2')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTopics(url, FIRST, LAST):
	debug_MS("(navigator.listTopics) ------------------------------------------------ START = listTopics -----------------------------------------------")
	debug_MS("(navigator.listTopics) ### URL : {0} ### FIRST : {1} ### LAST : {2} ###".format(url, FIRST, LAST))
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
	DATA = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listTopics) XXXXX CONTENT : {0} XXXXX".format(str(DATA)))
	debug_MS("++++++++++++++++++++++++")
	if 'index.json' in url and DATA is not None and 'pageProps' in DATA and  DATA['pageProps'].get('playlists', '') and LAST in DATA['pageProps']['playlists'].get(FIRST+'Collection', []):
		for item in DATA['pageProps']['playlists'].get(FIRST+'Collection', {}).get(LAST, ''):
			image = icon
			playlistID = str(item['id'])
			name = cleaning(item['webName'])
			if item.get('videos', '') and len(item.get('videos')) > 0:
				if item.get('videos', {})[0].get('images', '') and item.get('videos', [])[0].get('images', {})[0].get('url', ''):
					image = item['videos'][0]['images'][0]['url']
			elif item.get('series', '') and len(item.get('series')) > 0:
				if item.get('series', {})[0].get('images', '') and item.get('series', [])[0].get('images', {})[0].get('url', ''):
					image = item['series'][0]['images'][0]['url']
			else: continue
			newURL = '/playlists/'+playlistID+'.json'
			addDir(name, image, {'mode': 'listEpisodes', 'url': newURL, 'first': 'playlist', 'last': 'playlists', 'transmit': name}, background=False)
			debug_MS("(navigator.listTopics) ### NAME : {0} || IDD : {1} || IMAGE : {2} ###".format(str(name), playlistID, image))
	elif 'genres.json' in url and DATA is not None and 'pageProps' in DATA and LAST in DATA['pageProps'].get(FIRST+'PageData', []):
		for item in DATA['pageProps'].get(FIRST+'PageData', {}).get(LAST, ''):
			genreID = str(item['id'])
			name = translation(30621).format(cleaning(item['name'])) if showSUBGENRE else cleaning(item['name'])
			if genreID == '15':
				newURL, FIRST, LAST = '/playlists/'+genreID.replace('15', '51')+'.json', 'playlist', 'playlists'
			else:
				newURL, FIRST, LAST = '/genres/'+genreID+'.json', 'genre', 'genres'
			addDir(name, icon, {'mode': 'listEpisodes', 'url': newURL, 'first': FIRST, 'last': LAST, 'transmit': name})
			debug_MS("(navigator.listGenres) ### NAME : {0} || genreID : {1} || newURL : {2} ###".format(str(name), genreID, newURL))
			if showSUBGENRE and item.get('subGenres', '') and len(item.get('subGenres')) > 0:
				for each in item.get('subGenres', []):
					subID = str(each['id'])
					subNAME = cleaning(each['name'])
					subURL = '/genres/'+subID+'.json'
					addDir('..... '+subNAME, icon, {'mode': 'listEpisodes', 'url': subURL, 'first': 'genre', 'last': 'genres', 'transmit': subNAME})
					debug_MS("(navigator.listGenres) ### subNAME : {0} || subID : {1} || subURL : {2} ###".format(str(subNAME), subID, subURL))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, FIRST, LAST, SERIE):
	debug_MS("(navigator.listEpisodes) ------------------------------------------------ START = listEpisodes -----------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### URL : {0} ### FIRST : {1} ### LAST : {2} ### SERIE : {3} ###".format(url, FIRST, LAST, SERIE))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_THIRD = ([] for _ in range(4))
	counter = 0
	DATA_ONE = getUrl(url)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listEpisodes) no.01 XXXXX CONTENT-01 : {0} XXXXX".format(str(DATA_ONE)))
	debug_MS("++++++++++++++++++++++++")
	if DATA_ONE is not None and 'pageProps' in DATA_ONE and LAST in DATA_ONE['pageProps'].get(FIRST+'PageData', {}):
		special = DATA_ONE['pageProps'].get(FIRST+'PageData', []) if LAST in ['series', 'videos'] else DATA_ONE['pageProps'].get(FIRST+'PageData', {}).get(LAST, [])[0]
		for key, value in special.items():
			#log("(navigator.listEpisodes) no.01 ##### KEY : {0} || VALUE : {1} #####".format(key,value))
			if (key in ['series', 'videos'] or key == LAST) and value is not None:
				elements = value if isinstance(value, list) else [value]
				for item in elements:
					NOTE_1, NOTE_2, NOTE_3, GENRE_1, DESC_1 = ("" for _ in range(5))
					ORIGSERIE_1, DURATION_1, startTIMES, BEGINS_1, endTIMES, POSTER_1, THUMB_1, BANNER_1 = (None for _ in range(8))
					genreLIST_1 = []
					FANART_1 = defaultFanart
					debug_MS("(navigator.listEpisodes) no.01 xxxxx ELEM-01 : {0} xxxxx".format(str(item)))
					episID_1 = (item.get('id', '') or '00')
					SLUG_1 = (item.get('slug', None) or None)
					DURATION_1 = int(item['duration']) // 1000 if str(item.get('duration', '')).isdigit() else None
					CRN_1 = (item.get('crn', None) or None)
					VIDEOCOUNT_1 = (item.get('videoCount', None) or None)
					TITLE_1 = cleaning(item['title'])
					if item.get('subtitle', ''):
						ORIGSERIE_1 = cleaning(item['subtitle'])
						TITLE_1 = TITLE_1+' - '+cleaning(item['subtitle'])
					if str(item.get('schedulingStart'))[:4].isdigit() and str(item.get('schedulingStart'))[:4] not in ['0', '1970']: # 2022-03-04T19:15:18.000Z
						LOCALstart = get_Local_DT(item['schedulingStart'][:19])
						if (datetime.now() + timedelta(days=3)) < LOCALstart:
							continue
						if datetime.now() < LOCALstart:
							TITLE_1 = translation(30622).format(str(COL_MARKING), TITLE_1) # Plum = FFDDA0DD // FFFFDEAD = NavajoWhite1 // FFFFF68F = khaki1 // FFFFC125 = goldenrod1
						startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
						BEGINS_1 = LOCALstart.strftime('%d{0}%m{0}%Y').format('.')
					if str(item.get('schedulingEnd'))[:4].isdigit() and str(item.get('schedulingEnd'))[:4] not in ['0', '1970']: # 2022-03-11T19:15:18.000Z
						LOCALend = get_Local_DT(item['schedulingEnd'][:19])
						endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
					if startTIMES and endTIMES: NOTE_2 = translation(30623).format(str(startTIMES), str(endTIMES))
					elif startTIMES and endTIMES is None: NOTE_2 = translation(30624).format(str(startTIMES))
					if item.get('images', '') and isinstance(item['images'], list):
						num, resources = item.get('id', ''), item.get('images', [])
						POSTER_1 = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
						THUMB_1 = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
						BANNER_1 = get_Picture(num, resources, 'cover')
						FANART_1 = (get_Picture(num, resources, 'basic') or get_Picture(num, resources, 'thumbnail') or defaultFanart)
					SEASON_1 = str(item['seasonNumber']) if item.get('seasonNumber', '') else '0'
					EPISODE_1 = str(item['episodeNumber']) if item.get('episodeNumber', '') else '0'
					if ORIGSERIE_1 and EPISODE_1 != '0':
						suffix = 'S.'+SEASON_1.zfill(2)+' - E.'+EPISODE_1.zfill(2) if SEASON_1 != '0' else 'E.'+EPISODE_1.zfill(2)
						NOTE_1 = ORIGSERIE_1+translation(30625).format(suffix)+'[CR]'
						NOTE_3 = translation(30625).format(suffix)
					elif ORIGSERIE_1 and EPISODE_1 == '0':
						NOTE_1 = ORIGSERIE_1+'[CR]'
					if item.get('genres', '') and isinstance(item['genres'], list):
						genreLIST_1 = [one.get('name', '') for one in item['genres']]
						if genreLIST_1: GENRE_1 = ' / '.join(sorted(genreLIST_1))
					DESC_1 = get_Description(item)
					counter += 1
					if enableLIMIT and LIMIT_NUMBER == counter: break
					COMBI_FIRST.append([int(counter), episID_1, SLUG_1, CRN_1, VIDEOCOUNT_1, TITLE_1, ORIGSERIE_1, SEASON_1, EPISODE_1, DURATION_1, BEGINS_1, POSTER_1, THUMB_1, BANNER_1, FANART_1, GENRE_1, NOTE_1, NOTE_2, NOTE_3, DESC_1])
					if (BINDER_LONG and key == 'series') or (VIDEO_LONG and key == 'videos' and len(DESC_1) < infoLENGHT):
						URL_TWO = API_BASE+addon.getSetting('new_staticCODE')+'/videos/'+SLUG_1+'.json' if key == 'videos' else API_BASE+addon.getSetting('new_staticCODE')+'/serien/'+SLUG_1+'.json'
						COMBI_LINKS.append([int(counter), URL_TWO])
	if COMBI_FIRST:
		COMBI_SECOND = getMultiData(COMBI_LINKS)
		if COMBI_SECOND:
			DATA_TWO = json.loads(COMBI_SECOND)
			#log("++++++++++++++++++++++++")
			#log("(navigator.listEpisodes) no.02 XXXXX CONTENT-02 : {0} XXXXX".format(str(DATA_TWO)))
			#log("++++++++++++++++++++++++")
			for elem in DATA_TWO:
				if elem is not None and 'pageProps' in elem and (elem['pageProps'].get('seriePageData', []) or elem['pageProps'].get('videoPageData', [])):
					COUNTRY_2, DIRECTOR_2, CAST_2, GENRE_2, DESC_2 = ("" for _ in range(5))
					POSTER_2, THUMB_2, BANNER_2, MPAA_2, YEAR_2 = (None for _ in range(5))
					countryLIST_2, directorLIST_2, castLIST_2, genreLIST_2 = ([] for _ in range(4))
					FANART_2 = defaultFanart
					debug_MS("(navigator.listEpisodes) no.02 xxxxx ELEM-02 : {0} xxxxx".format(str(elem)))
					SHORT = elem['pageProps']['seriePageData'] if elem['pageProps'].get('seriePageData', []) else elem['pageProps']['videoPageData']['videos'][0]
					markID_2 = (SHORT.get('id', '') or '00')
					if SHORT.get('videos', '') and len(SHORT.get('videos')) > 0:
						num, resources = SHORT.get('id', ''), SHORT.get('videos', [])[0].get('images', {})
						POSTER_2 = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
						THUMB_2 = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
						BANNER_2 = get_Picture(num, resources, 'cover')
						FANART_2 = (get_Picture(num, resources, 'basic') or get_Picture(num, resources, 'thumbnail') or defaultFanart)
					if str(SHORT.get('fsk')) not in ['None', '0', 'nicht definiert']:
						MPAA_2 = str(SHORT.get('fsk')).replace('ab 0 Jahre -', '').replace('freigegeben', '').strip()
					if SHORT.get('productionYear', '') and str(SHORT.get('productionYear', {}).get('from', '')).isdigit():
						YEAR_2 = SHORT['productionYear']['from']
					if SHORT.get('productionCountry', '') and isinstance(SHORT['productionCountry'], list):
						countryLIST_2 = [one for one in SHORT['productionCountry']]
						if countryLIST_2: COUNTRY_2 = ', '.join(sorted(countryLIST_2))
					if SHORT.get('personsShown', '') and isinstance(SHORT['personsShown'], list):
						directorLIST_2 = [cleaning(psDIRK['person'].get('name', '')) for psDIRK in SHORT['personsShown'] if psDIRK.get('person', '') and psDIRK.get('function', '') == 'director']
						if directorLIST_2: DIRECTOR_2 = ', '.join(sorted(directorLIST_2))
						for index, psCAST in enumerate(SHORT['personsShown'], 1):
							if psCAST.get('person', '') and psCAST['person'].get('name', '') and psCAST.get('function', '') == 'cast':
								actor = {'name': cleaning(psCAST['person']['name']), 'role': cleaning(psCAST.get('role', '')), 'order': index, 'thumb': ''}
								if KODI_ov20:
									castLIST_2.append(xbmc.Actor(actor['name'], actor['role'], actor['order'], actor['thumb']))
								else: castLIST_2.append(actor)
					if SHORT.get('genres', '') and isinstance(SHORT['genres'], list):
						genreLIST_2 = [two.get('name', '') for two in SHORT['genres']]
						if genreLIST_2: GENRE_2 = ' / '.join(sorted(genreLIST_2))
					VOTES_2 = (SHORT.get('likeCount', None) or None)
					DESC_2 = get_Description(SHORT)
					COMBI_THIRD.append([markID_2, POSTER_2, THUMB_2, BANNER_2, FANART_2, MPAA_2, YEAR_2, COUNTRY_2, DIRECTOR_2, castLIST_2, GENRE_2, VOTES_2, DESC_2])
	if COMBI_THIRD or (not COMBI_THIRD and COMBI_FIRST):
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_THIRD if a[1] == b[0]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		RESULT += [c for c in COMBI_FIRST if all(d[0] != c[1] for d in COMBI_THIRD)] # Der übriggebliebene Rest von Liste1 - wenn die ID nicht in der Liste2 vorkommt !!!
		#log("++++++++++++++++++++++++")
		#log("(navigator.listEpisodes) no.03 XXXXX RESULT-03 : {0} XXXXX".format(str(RESULT)))
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda k: int(k[0]), reverse=False):
			debug_MS("---------------------------------------------")
			debug_MS("(navigator.listEpisodes) no.03 ### Anzahl = {0} || Eintrag : {1} ###".format(str(len(da)), str(da)))
			if len(da) > 20: ### Liste2 beginnt mit Nummer:20 ###
				episID, slug, crn, videoCount, title, origSERIE, season, episode, duration, begins = da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10]
				poster, thumb, banner, fanart, Note_1, Note_2, Note_3 = da[11], da[12], da[13], da[14], da[16], da[17], da[18]
				if da[11] is None and da[12] is None and (da[21] is not None or da[22] is not None):
					poster, thumb, banner, fanart = da[21], da[22], da[23], da[24]
				genre = da[30] if da[15] == "" and da[30] != "" else da[15] # genre = GENRE_2 if GENRE_1 == "" and GENRE_2 != "" else GENRE_1
				COMP_DESC = da[32] if len(da[32]) > len(da[19]) else da[19] # COMP_DESC = DESC_2 if len(DESC_2) > len(DESC_1) else DESC_1
				mpaa, year, country, director, cast, votes = da[25], da[26], da[27], da[28], da[29], da[31]
			else:
				episID, slug, crn, videoCount, title, origSERIE, season, episode, duration, begins = da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9], da[10]
				poster, thumb, banner, fanart, genre, Note_1, Note_2, Note_3, COMP_DESC = da[11], da[12], da[13], da[14], da[15], da[16], da[17], da[18], da[19]
				mpaa, year, country, director, cast, votes = None, None, "", "", "", None
			if crn and duration:
				uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playVideo', 'url': episID, 'extras': slug}))
				folder = False
			elif (crn is None or videoCount) and duration is None and slug:
				newURL = '/serien/'+slug+'.json'
				uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'listEpisodes', 'url': newURL, 'first': 'serie', 'last': 'videos', 'transmit': title}))
				folder = True
			plot = Note_1+Note_2+COMP_DESC
			name = title+Note_3
			if not folder:
				for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			cineType = 'episode' if episode != '0' else 'movie'
			debug_MS("(navigator.listEpisodes) no.04 ##### NAME : {0} || IDD : {1} || GENRE : {2} #####".format(name, episID, genre))
			debug_MS("(navigator.listEpisodes) no.04 ##### SERIE : {0} || SEASON : {1} || EPISODE : {2} #####".format(origSERIE, str(season), str(episode)))
			debug_MS("(navigator.listEpisodes) no.04 ##### FSK : {0} || THUMB : {1} || POSTER : {2} #####".format(mpaa, thumb, poster))
			liz = xbmcgui.ListItem(name)
			if plot in ['', 'None', None]: plot = "..."
			if KODI_ov20:
				videoInfoTag = liz.getVideoInfoTag()
				if season not in ['0', 'None', None]: videoInfoTag.setSeason(int(season))
				if episode not in ['0', 'None', None]: videoInfoTag.setEpisode(int(episode))
				videoInfoTag.setTvShowTitle(origSERIE)
				videoInfoTag.setTitle(name)
				videoInfoTag.setTagLine(None)
				videoInfoTag.setPlot(plot)
				if duration not in ['0', 'None', None]: videoInfoTag.setDuration(int(duration))
				if begins: videoInfoTag.setDateAdded(begins)
				if begins: videoInfoTag.setFirstAired(begins)
				if year: videoInfoTag.setYear(int(year))
				videoInfoTag.setCountries([country])
				videoInfoTag.setGenres([genre])
				videoInfoTag.setDirectors([director])
				if isinstance(cast, (list, tuple)): videoInfoTag.setCast(cast)
				if votes: videoInfoTag.setVotes(int(votes))
				videoInfoTag.setStudios(['bibel.TV'])
				videoInfoTag.setMpaa(mpaa)
				if not folder: videoInfoTag.setMediaType(cineType)
			else:
				info = {}
				if isinstance(cast, (list, tuple)): liz.setCast(cast)
				if season not in ['0', 'None', None]: info['Season'] = season
				if episode not in ['0', 'None', None]: info['Episode'] = episode
				info['Tvshowtitle'] = origSERIE
				info['Title'] = name
				info['Tagline'] = None
				info['Plot'] = plot
				if duration not in ['0', 'None', None]: info['Duration'] = duration
				if begins: info['Date'] = begins
				if begins: info['Aired'] = begins
				if year: info['Year'] = year
				info['Country'] = [country]
				info['Genre'] = [genre]
				info['Director'] = [director]
				if votes: info['Votes'] = votes
				info['Studio'] = 'bibel.TV'
				info['Mpaa'] = mpaa
				if not folder: info['Mediatype'] = cineType
				liz.setInfo(type='Video', infoLabels=info)
			liz.setArt({'icon': icon, 'thumb': thumb, 'poster': poster, 'banner': banner, 'fanart': fanart})
			if not folder:
				liz.setProperty('IsPlayable', 'true')
				liz.setContentLookup(False)
				liz.addContextMenuItems([(translation(30654), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, 'mode=AddToQueue'))])
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=liz, isFolder=folder)
	else:
		debug_MS("(navigator.listEpisodes) ##### Keine COMBI_EPISODE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30526), translation(30527).format(SERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(IDD, EXTRA):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS("(navigator.playVideo) ### IDD : {0} ### SLUG : {1} ###".format(IDD, EXTRA))
	finalURL, STREAM, WALU = (False for _ in range(3))
	MEDIAS = [] # https://www.bibeltv.de/mediathek/api/video/17165
	DATA = getUrl(API_PLAYER+IDD, REF='https://www.bibeltv.de/mediathek/videos/'+EXTRA.replace('…', ''), AUTH=BTV_token)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.playVideo) XXXXX CONTENT : {0} XXXXX".format(str(DATA)))
	debug_MS("++++++++++++++++++++++++")
	if DATA is not None and 'status' in DATA and DATA['status'] == 'success':
		for elem in DATA['video']['videoUrls']:
			TYPE = elem['type']
			VIDEO = elem['src']
			WILIZ = elem['keySystem']['widevine']['url'] if TYPE == 'application/dash+xml' and elem.get('keySystem', '') and elem.get('keySystem', {}).get('widevine', '') and elem.get('keySystem', {}).get('widevine', {}).get('url', '') else None
			MEDIAS.append({'video': VIDEO, 'mime': TYPE, 'wiliz': WILIZ})
		if MEDIAS:
			for item in MEDIAS:
				if '.mpd' in item['video'] and item['mime'] == 'application/dash+xml' and (prefSTREAM == '0' or item['wiliz']):
					STREAM, MIME, finalURL, WALU = 'MPD', item['mime'], item['video'], item['wiliz']
					debug_MS("(navigator.playVideo) XXX TAKE - Inputstream (mpd) - FILE XXX")
				if not finalURL and '.m3u8' in item['video'] and item['mime'] in ['application/vnd.apple.mpegurl', 'application/x-mpegURL'] and not WALU:
					STREAM = 'HLS' if prefSTREAM in ['0', '1'] else 'M3U8'
					MIME, finalURL = item['mime'], item['video']
					debug_MS("(navigator.playVideo) XXX TAKE - Inputstream (hls) and Standard (m3u8) - FILE XXX")
			if not finalURL:
				for item in MEDIAS:
					if '.mp4' in item['video'] and item['mime'] == 'video/mp4':
						STREAM, MIME, finalURL = 'MP4', item['mime'], item['video']
						debug_MS("(navigator.playVideo) XXX TAKE - mp4 (last Chance) -  FILE XXX")
	if finalURL and STREAM:
		LSM = xbmcgui.ListItem(path=finalURL)
		if ADDON_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			LSM.setMimeType(MIME)
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			LSM.setProperty('inputstream.adaptive.manifest_type', STREAM.lower())
			if WALU:
				WAKEY = u'{0}|User-Agent={1}&Content-Type=application/octet-stream|{2}|'.format(WALU, get_userAgent(), 'R{SSM}')
				LSM.setProperty('inputstream.adaptive.license_key', WAKEY)
				debug_MS("(navigator.playVideo) LICENSE : {0}".format(str(WAKEY)))
				LSM.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
		log("(navigator.playVideo) {0}_stream : {1}|User-Agent={2}".format(STREAM, finalURL, get_userAgent()))
	else:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### IDD : {0} || SLUG : {1} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *bibeltv.de* gefunden !!! ##########".format(IDD, EXTRA))
		return dialog.notification(translation(30521).format('STREAM'), translation(30528), icon, 8000)

def liveTV():
	debug_MS("(navigator.liveTV) ------------------------------------------------ START = liveTV -----------------------------------------------")
	CHANNELS = [
		{'name': translation(30641), 'url': 'https://bibeltv01.iptv-playoutcenter.de/bibeltv01/bibeltv01.stream_all/playlist.m3u8', 'pict': artpic+'bibeltv.jpg', 'desc': 'Das Hauptprogramm von Bibel TV im Livestream.'},
		{'name': translation(30642), 'url': 'https://bibeltv02.iptv-playoutcenter.de/bibeltv02/bibeltv02.stream_all/playlist.m3u8', 'pict': artpic+'impuls.jpg', 'desc': 'Livestream "Bibel TV Impuls", der Predigt-Kanal.'},
		{'name': translation(30643), 'url': 'https://bibeltv03.iptv-playoutcenter.de/bibeltv03/bibeltv03.stream_all/playlist.m3u8', 'pict': artpic+'musik.jpg', 'desc': 'Livestream des Kanals "Bibel TV Musik" - Inspirierende christliche Musik.'}]
	for elem in CHANNELS:
		addDir(elem['name'], elem['pict'], {'mode': 'playLIVE', 'url': elem['url'], 'transmit': elem['name']}, elem['desc'], folder=False, background=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playLIVE(url, NAME):
	LTM = xbmcgui.ListItem(path=url, label=translation(30644).format(NAME))
	LTM.setMimeType('application/vnd.apple.mpegurl')
	if ADDON_operate('inputstream.adaptive'):
		LTM.setProperty('inputstream', 'inputstream.adaptive')
		LTM.setProperty('inputstream.adaptive.manifest_type', 'hls')
		LTM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
	xbmc.Player().play(item=url, listitem=LTM)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, folder=True, background=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot), videoInfoTag.setStudios(['bibel.TV'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'bibel.TV'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image and background is True:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
