﻿# -*- coding: utf-8 -*-

from .common import *
from .utilities import Transmission
config = traversing.get_config()


def mainMenu():
	for TITLE, PATH in [(30601, {'mode': 'listTopics', 'url': GRAPH_BASE, 'first': 'COLLECTION', 'last': 'videos', 'extras': 3}),
		(30602, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'BROADCASTS', 'last': 'series', 'transmit': 'Broadcasts'}),
		(30603, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'GENRES', 'last': 'genres', 'transmit': 'Genres'}),
		(30604, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'PLAYLIST_BY_ID', 'last': 'videos', 'extras': 16, 'transmit': 'Exklusiv'}),
		(30605, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'PLAYLIST_BY_ID', 'last': 'videos', 'extras': 53, 'transmit': 'Spielfilme'}),
		(30606, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'SERIES', 'last': 'series', 'extras': 51, 'transmit': 'Serien'}),
		(30607, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'NEWEST', 'last': 'videos', 'transmit': 'Newest'}),
		(30608, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'LAST_CHANCE', 'last': 'videos', 'transmit': 'Last Chance'}),
		(30609, {'mode': 'SearchBIBELTV'}), (30610, {'mode': 'listChurches'}), (30611, {'mode': 'listChannels'})]:
		addDir(PATH, create_entries({'Title': translation(TITLE), 'Image': f"{artpic}basesearch.png" if TITLE == 30609 else f"{artpic}livestream.png" if TITLE in [30610, 30611] else icon}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30612), 'Image': f"{artpic}settings.png"}), False)
		if prefSTREAM in [0, 1] and plugin_operate('inputstream.adaptive'):
			addDir({'mode': 'iConfigs'}, create_entries({'Title': translation(30613), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('prefer_stream', '2')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTopics(TARGET, FIRST, LAST, CAT_IDD):
	debug_MS("(navigator.listTopics) ------------------------------------------------ START = listTopics -----------------------------------------------")
	debug_MS(f"(navigator.listTopics) ### URL = {TARGET} ### FIRST = {FIRST} ### LAST = {LAST} ### CAT_IDD = {CAT_IDD} ###")
	FOUND, SEND = 0, {}
	SEND['playlists'] = []
	if TARGET.startswith(GRAPH_BASE):
		NOW_UTC = f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
		ENTRIES = json.loads(json.dumps(config[FIRST]))
		ENTRIES['variables']['id'], ENTRIES['variables']['take'], ENTRIES['variables']['skip'], ENTRIES['variables']['now'] = int(CAT_IDD), 20, 0, NOW_UTC
		DATA_ONE = Transmission().retrieveContent(TARGET, 'POST', data=json.dumps(ENTRIES, indent=2))
		FETCH_UNO = create_entries({'Title': translation(30620), 'Image': f"{artpic}regards.png"})
		addDir({'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'PLAYLIST_BY_ID', 'last': 'videos', 'extras': 1, 'transmit': 'Empfehlungen'}, FETCH_UNO)
		if DATA_ONE not in ['', None] and DATA_ONE.get('data', '') and DATA_ONE['data'].get('playlistCollection', ''):
			for item in DATA_ONE['data']['playlistCollection'].get('playlists', []):
				CID, DESC = item.get('id', None), None
				debug_MS(f"(navigator.listTopics[1]) xxxxx ITEM-01 : {item} xxxxx")
				NAME = cleaning(item['webName'])
				if item.get('videos', '') and len(item['videos']) > 0:
					START, FINAL = 'PLAYLIST_BY_ID', 'videos'
					if item.get('videos', {})[0].get('images', '') and len(item['videos'][0]['images']) > 0:
						num, resources = item.get('id', ''), item.get('videos', {})[0].get('images', [])
						THUMB = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
						POSTER = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
						if item.get('videos', {})[0].get('genres', '') and item.get('videos', [])[0].get('genres', {})[0].get('seoDescription', ''):
							DESC = item['videos'][0]['genres'][0]['seoDescription']
				elif item.get('series', '') and len(item['series']) > 0:
					START, FINAL = 'GENRE_BY_ID', 'series'
					if item.get('series', {})[0].get('images', '') and len(item['series'][0]['images']) > 0:
						num, resources = item.get('id', ''), item.get('series', {})[0].get('images', [])
						THUMB = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
						POSTER = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
				else: continue
				FOUND += 1
				debug_MS(f"(navigator.listTopics[2]) ### NAME : {NAME} || IDD : {CID} || THUMB : {THUMB} ###")
				debug_MS("++++++++++++++++++++++++")
				FETCH_DUE = create_entries({'Title': NAME, 'Plot': DESC, 'Image': THUMB, 'Poster': POSTER})
				addDir({'mode': 'listTopics', 'url': 'Recomendations', 'first': START, 'last': FINAL, 'extras': CID}, FETCH_DUE)
				SEND['playlists'].append(item)
			preserve(HOME_BASE, 'JSON', SEND)
	elif xbmcvfs.exists(HOME_BASE) and os.stat(HOME_BASE).st_size > 0:
		for item in preserve(HOME_BASE).get('playlists', []):
			if int(item.get('id', 0)) == int(CAT_IDD) and item.get(LAST, ''):
				for elem in item.get(LAST, []):
					debug_MS(f"(navigator.listTopics[3]) xxxxx ELEM-03 : {elem} xxxxx")
					each, folder = create_substances(elem), True
					# [cid=0, crn=1, slug=2, norm=3, videocount=4, title=5, origserie=6, desc=7, duration=8, season=9, episode=10, aired=11, begins=12]
					# [note_1=13, note_2=14, note_3=15, note_4=16, votes=17, mpaa=18, country=19, year=20, genre=21, thumb=22, poster=23, banner=24, fanart=25]
					if each[1] is not None and each[8] is not None:
						folder, ACTION = False, {'mode': 'playVideo', 'url': each[1]}
					elif each[1] is None and each[8] is None and str(each[0]).isdecimal():
						xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
						folder, ACTION = True, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'SERIE_BY_ID', 'last': 'videos', 'extras': int(each[0]), 'transmit': each[5]}
					FOUND += 1
					PLOT = each[13]+each[14]+each[15]+each[7]
					NAME = f"{each[5]+each[16]}  [COLOR gold][{str(each[4])}][/COLOR]" if each[4] is not None and folder else each[5]+each[16]
					debug_MS(f"(navigator.listTopics[4]) ### ACTION : {ACTION} || NAME : {NAME} ###")
					debug_MS(f"(navigator.listTopics[4]) ### SEASON : {each[9]} || EPISODE : {each[10]} || THUMB : {each[22]} ###")
					debug_MS("++++++++++++++++++++++++")
					FETCH_UNO = {'Title': NAME, 'Plot': PLOT, 'Season': each[9],'Episode': each[10], 'Duration': each[8], 'Date': each[12], 'Aired': each[11], \
						'Year': each[20], 'Genre': each[21], 'Country': each[19], 'Votes': each[17], 'Mpaa': each[18], 'Mediatype': 'episode' if not folder else None, \
						'Image': each[22], 'Poster': each[23], 'Banner': each[24], 'Fanback': each[25], 'Reference': 'Single' if not folder else 'Standard'}
					addDir(ACTION, create_entries(FETCH_UNO), folder)
	if FOUND == 0:
		failing("(navigator.listTopics) ##### Keine COMBI_TOPICS-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30521).format('TOPICS'), translation(30522), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVarious(TARGET, FIRST, LAST, CAT_IDD, PAGE, SERIE):
	debug_MS("(navigator.listVarious) ------------------------------------------------ START = listVarious -----------------------------------------------")
	debug_MS(f"(navigator.listVarious) ### URL = {TARGET} ### FIRST = {FIRST} ### LAST = {LAST} ### CAT_IDD = {CAT_IDD} ### PAGE = {PAGE} ### SERIE = {SERIE} ###")
	INSTANCE, PLAYLIST, RESULT = 0, False, None
	SKIPPING = int(PAGE)-1 if int(PAGE) > 1 else 0
	NOW_UTC = f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
	UTC_MINUS = f"{(datetime.utcnow() - timedelta(days=5)).isoformat(timespec='milliseconds')}Z" # Neue Videos - Videos beginnend vor 5 Tagen ab heute
	UTC_PLUS = f"{(datetime.utcnow() + timedelta(days=5)).isoformat(timespec='milliseconds')}Z" # Last Chance - Videos enden in den nächsten 5 Tagen
	ENTRIES = json.loads(json.dumps(config[FIRST]))
	HIGHER = True if int(PAGE) > 1 else False
	if enableBACK and PLACEMENT == 0 and HIGHER is True:
		addDir({'mode': 'callingMain'}, create_entries({'Title': translation(30621), 'Image': f"{artpic}backmain.png"}))
	if int(CAT_IDD) == 0 and FIRST in ['BROADCASTS','GENRES']:
		ENTRIES = {**ENTRIES, **{'variables': {'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0}}}
	elif int(CAT_IDD) == 0 and FIRST == 'NEWEST':
		ENTRIES = {**ENTRIES, **{'variables': {'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0, 'now': NOW_UTC, 'dayAfterTomorrow': UTC_MINUS}}}
	elif int(CAT_IDD) == 0 and FIRST == 'LAST_CHANCE':
		ENTRIES = {**ENTRIES, **{'variables': {'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0, 'now': NOW_UTC, 'dayAfterTomorrow': UTC_PLUS}}}
	elif int(CAT_IDD) != 0 and FIRST == 'GENRE_BY_ID':
		ENTRIES = {**ENTRIES, **{'variables': {'id': int(CAT_IDD), 'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0}}}
	else:
		ENTRIES = {**ENTRIES, **{'variables': {'id': int(CAT_IDD), 'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0, 'now': NOW_UTC}}}
	DATA_ONE = Transmission().retrieveContent(TARGET, 'POST', data=json.dumps(ENTRIES, indent=2))
	if DATA_ONE not in ['', None] and DATA_ONE.get('data', '') and DATA_ONE['data'].get('playlist', '') and DATA_ONE['data']['playlist'].get(LAST, ''):
		INSTANCE, PLAYLIST = 1, DATA_ONE['data']['playlist'].get(LAST, [])
	elif DATA_ONE not in ['', None] and DATA_ONE['data'].get('genre', '') and DATA_ONE['data']['genre'].get(LAST, ''):
		INSTANCE, PLAYLIST = 2, DATA_ONE['data']['genre'].get(LAST, [])
	elif DATA_ONE not in ['', None] and DATA_ONE['data'].get('serie', '') and DATA_ONE['data']['serie'].get(LAST, ''):
		INSTANCE, PLAYLIST = 3, DATA_ONE['data']['serie'].get(LAST, [])
	elif DATA_ONE not in ['', None] and DATA_ONE.get('data', '') and DATA_ONE['data'].get(LAST, ''):
		INSTANCE, PLAYLIST = 4, DATA_ONE['data'].get(LAST, [])
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listVarious[1]) XXXXX INSTANCE-01 : {INSTANCE} XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if PLAYLIST:
		for item in PLAYLIST:
			debug_MS(f"(navigator.listVarious[2]) xxxxx ELEM-02 : {item} xxxxx")
			each, folder = create_substances(item), True
			# [cid=0, crn=1, slug=2, norm=3, videocount=4, title=5, origserie=6, desc=7, duration=8, season=9, episode=10, aired=11, begins=12]
			# [note_1=13, note_2=14, note_3=15, note_4=16, votes=17, mpaa=18, country=19, year=20, genre=21, thumb=22, poster=23, banner=24, fanart=25]
			if each[1] is not None and each[8] is not None:
				folder, ACTION = False, {'mode': 'playVideo', 'url': each[1]}
			elif each[1] is None and each[8] is None and str(each[0]).isdecimal():
				START = 'GENRE_BY_ID' if FIRST == 'GENRES'and int(each[0]) not in [642, 695] else 'GENRE_VIDEOS' if int(each[0]) in [642, 695] else 'SERIE_BY_ID'
				FINAL = 'series' if FIRST == 'GENRES'and int(each[0]) not in [642, 695] else 'videos'
				folder, ACTION = True, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': START, 'last': FINAL, 'extras': int(each[0]), 'transmit': each[5]}
			PLOT = each[13]+each[14]+each[15]+each[7]
			NAME = f"{each[5]+each[16]}  [COLOR gold][{str(each[4])}][/COLOR]" if each[4] is not None and folder else each[5]+each[16]
			debug_MS(f"(navigator.listVarious[3]) ##### ACTION : {ACTION} || NAME : {NAME} || IDD : {each[0]} || GENRE : {each[21]} #####")
			debug_MS(f"(navigator.listVarious[3]) ##### SERIE : {each[6]} || SEASON : {each[9]} || EPISODE : {each[10]} #####")
			debug_MS(f"(navigator.listVarious[3]) ##### FSK : {each[18]} || THUMB : {each[22]} || POSTER : {each[23]} #####")
			debug_MS("---------------------------------------------")
			if not folder:
				for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			FETCH_UNO = {'Title': NAME, 'Plot': PLOT, 'Season': each[9],'Episode': each[10], 'Duration': each[8], 'Date': each[12], 'Aired': each[11], \
				'Year': each[20], 'Genre': each[21], 'Country': each[19], 'Votes': each[17], 'Mpaa': each[18], 'Mediatype': 'episode' if not folder else None, \
				'Image': each[22], 'Poster': each[23], 'Banner': each[24], 'Fanback': each[25], 'Reference': 'Single' if not folder else 'Standard'}
			addDir(ACTION, create_entries(FETCH_UNO), folder, HIGHER)
		NEXTLINK = json.loads(json.dumps(config[FIRST]))
		if int(CAT_IDD) == 0 and FIRST in ['BROADCASTS','GENRES']:
			NEXTLINK = {**NEXTLINK, **{'variables': {'take': 40, 'skip': int(PAGE)*40}}}
		elif int(CAT_IDD) == 0 and FIRST == 'NEWEST':
			NEXTLINK = {**NEXTLINK, **{'variables': {'take': 40, 'skip': int(PAGE)*40, 'now': NOW_UTC, 'dayAfterTomorrow': UTC_MINUS}}}
		elif int(CAT_IDD) == 0 and FIRST == 'LAST_CHANCE':
			NEXTLINK = {**NEXTLINK, **{'variables': {'take': 40, 'skip': int(PAGE)*40, 'now': NOW_UTC, 'dayAfterTomorrow': UTC_PLUS}}}
		elif int(CAT_IDD) != 0 and FIRST == 'GENRE_BY_ID':
			NEXTLINK = {**NEXTLINK, **{'variables': {'id': int(CAT_IDD), 'take': 40, 'skip': int(PAGE)*40}}}
		else:
			NEXTLINK = {**NEXTLINK, **{'variables': {'id': int(CAT_IDD), 'take': 40, 'skip': int(PAGE)*40, 'now': NOW_UTC}}}
		DATA_TWO = Transmission().retrieveContent(TARGET, 'POST', data=json.dumps(NEXTLINK, indent=2))
		debug_MS("++++++++++++++++++++++++")
		debug_MS(f"(navigator.listVarious[4]) XXXXX CONTENT-02 : {DATA_TWO} XXXXX")
		debug_MS("++++++++++++++++++++++++")
		if INSTANCE == 1 and DATA_TWO not in ['', None]: RESULT = DATA_TWO['data']['playlist'].get(LAST, [])
		elif INSTANCE == 2 and DATA_TWO not in ['', None]: RESULT = DATA_TWO['data']['genre'].get(LAST, [])
		elif INSTANCE == 3 and DATA_TWO not in ['', None]: RESULT = DATA_TWO['data']['serie'].get(LAST, [])
		elif INSTANCE == 4 and DATA_TWO not in ['', None]: RESULT = DATA_TWO['data'].get(LAST, [])
		if RESULT is not None and len(RESULT) > 0:
			debug_MS(f"(navigator.listVarious[5]) PAGES ### NOW SHOW NEXTPAGE ENTRY ... No.{int(PAGE)+1} ... ###")
			debug_MS("---------------------------------------------")
			FETCH_DUE = create_entries({'Title': translation(30622).format(int(PAGE)+1), 'Image': f"{artpic}nextpage.png"})
			addDir({'mode': 'listVarious', 'url': GRAPH_BASE, 'first': FIRST, 'last': LAST, 'extras': CAT_IDD, 'page': int(PAGE)+1, 'transmit': each[6] if each[6] is not None else SERIE}, FETCH_DUE)
	else:
		failing("(navigator.listVarious) ##### Keine COMBI_VARIOUS-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524), translation(30525).format(SERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def create_substances(rsx, SECTOR=True):
	(note_1, note_2, note_3, note_4, desc), fanart = ("" for _ in range(5)), defaultFanart
	origserie, start_date, aired, begins, ends_date, thumb, poster, banner = (None for _ in range(8))
	if SECTOR:
		st_code, st_crn, st_slug, st_type, st_year, st_vocal, st_subs, st_dur, st_seas = 'id', 'crn', 'slug', 'type', 'productionYear', 'from', 'subtitle', 'duration', 'seasonNumber'
		st_epis, st_start, st_ends, st_land, st_likes, st_cats, st_foto = 'episodeNumber', 'schedulingStart', 'schedulingEnd', 'productionCountry', 'likeCount', 'genres', 'images'
		title = cleaning(rsx['name']) if rsx.get('name', '') else cleaning(rsx['title'])
		sub_title = rsx[st_subs] if rsx.get(st_subs, '') else rsx['serie']['title'] if rsx.get('serie', '') and rsx['serie'].get('title', '') else None
		duration = int(rsx[st_dur]) // 1000 if str(rsx.get(st_dur)).isdecimal() and int(rsx[st_dur]) != 0 else None
		season = f"{int(rsx[st_seas]):02}" if str(rsx.get(st_seas)).isdecimal() and int(rsx[st_seas]) != 0 else None
		episode = f"{int(rsx[st_epis]):02}" if str(rsx.get(st_epis)).isdecimal() and int(rsx[st_epis]) != 0 else None
		startting = rsx[st_start] if str(rsx.get(st_start))[:4].isdecimal() and str(rsx[st_start])[:4] not in ['0', '1970'] else None
		stopping = rsx[st_ends] if str(rsx.get(st_ends))[:4].isdecimal() and str(rsx[st_ends])[:4] not in ['0', '1970'] else None
		regions = rsx[st_land] if rsx.get(st_land, '') and isinstance(rsx[st_land], list) else None
		votes = int(rsx[st_likes]) if str(rsx.get(st_likes)).isdecimal() and int(rsx[st_likes]) != 0 else None
		species = rsx[st_cats] if rsx.get(st_cats, '') and isinstance(rsx[st_cats], list) else None
	else:
		st_code, st_crn, st_slug, st_type, st_year, st_vocal, st_subs, st_dur, st_seas = 'origin_id', 'crn', 'slug', 'type', 'production_year', 'raw', 'subtitle', 'duration', 'season_number'
		st_epis, st_start, st_stop, st_land, st_likes, st_cats, st_foto = 'episode_number', 'scheduling_start', 'scheduling_end', 'production_country', 'like_count', 'genres', 'images'
		title = cleaning(rsx['title'][st_vocal])
		sub_title = rsx[st_subs][st_vocal] if rsx.get(st_subs, '') and rsx[st_subs].get(st_vocal, '') else rsx['serie'][st_vocal] if rsx.get('serie', '') and rsx['serie'].get(st_vocal, '') else None
		duration = int(rsx[st_dur][st_vocal]) // 1000 if rsx.get(st_dur, '') and str(rsx[st_dur].get(st_vocal))[:4].isdecimal() and int(rsx[st_dur][st_vocal]) != 0 else None
		season = f"{int(rsx[st_seas][st_vocal]):02}" if rsx.get(st_seas, '') and str(rsx[st_seas].get(st_vocal))[:1].isdecimal() and int(rsx[st_seas][st_vocal]) != 0 else None
		episode = f"{int(rsx[st_epis][st_vocal]):02}" if rsx.get(st_epis, '') and str(rsx[st_epis].get(st_vocal))[:1].isdecimal() and int(rsx[st_epis][st_vocal]) != 0 else None
		startting = rsx[st_start][st_vocal] if rsx.get(st_start, '') and str(rsx[st_start].get(st_vocal))[:4].isdecimal() and str(rsx[st_start][st_vocal])[:4] not in ['0', '1970'] else None
		stopping = rsx[st_stop][st_vocal] if rsx.get(st_stop, '') and str(rsx[st_stop].get(st_vocal))[:4].isdecimal() and str(rsx[st_stop][st_vocal])[:4] not in ['0', '1970'] else None
		regions = rsx[st_land][st_vocal] if rsx.get(st_land, '') and rsx[st_land].get(st_vocal, '') and isinstance(rsx[st_land][st_vocal], list) else None
		votes = int(rsx[st_likes][st_vocal]) if rsx.get(st_likes, '') and str(rsx[st_likes].get(st_vocal))[:1].isdecimal() and int(rsx[st_likes][st_vocal]) != 0 else None
		species = rsx[st_cats][st_vocal] if rsx.get(st_cats, '') and rsx[st_cats].get(st_vocal, '') and isinstance(rsx[st_cats][st_vocal], list) else None
		thumb = rsx[st_foto][st_vocal][0].replace(' ', '%20') if rsx.get(st_foto, '') and rsx[st_foto].get(st_vocal, '') and len(rsx[st_foto][st_vocal]) > 0 else None
	cid = rsx.get(st_code, None) if SECTOR else rsx[st_code][st_vocal] if rsx.get(st_code, '') and rsx[st_code].get(st_vocal, '') else None
	crn = rsx.get(st_crn, None) if SECTOR else rsx[st_crn][st_vocal] if rsx.get(st_crn, '') and rsx[st_crn].get(st_vocal, '') else None
	slug = rsx.get(st_slug, None) if SECTOR else rsx[st_slug][st_vocal] if rsx.get(st_slug, '') and rsx[st_slug].get(st_vocal, '') else None
	norm = rsx[st_type][st_vocal] if rsx.get(st_type, '') and rsx[st_type].get(st_vocal, '') else 'unknown'
	videocount = rsx.get('currentScheduledVideoCount', None)
	if sub_title:
		if title.startswith(('am ', 'vom ')): title = title[:1].upper()+title[1:]
		origserie, note_1 = cleaning(sub_title), translation(30623).format(cleaning(sub_title))
		title = f"{title} - {origserie}"
	desc = cleaning(rsx['seoDescription']) if rsx.get('seoDescription', None) else get_Description(rsx, suffix=None if SECTOR else st_vocal)
	if episode:
		note_2 = translation(30624).format(season, episode) if season else translation(30625).format(episode)
		if showEPIS: note_4 = translation(30626).format(season, episode) if season else translation(30627).format(episode)
	if startting: # 2022-03-04T19:15:18.000Z
		local_start = get_CentralTime(startting)
		start_date = local_start.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
		aired = local_start.strftime('%d.%m.%Y') # FirstAired
		begins = local_start.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else local_start.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
	if stopping: # 2022-03-11T19:15:18.000Z
		local_ends = get_CentralTime(stopping)
		ends_date = local_ends.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
	if start_date and ends_date: note_3 = translation(30628).format(start_date, ends_date)
	elif start_date and ends_date is None: note_3 = translation(30629).format(start_date)
	elif note_1 != "" or note_2 != "": note_3 = '[CR]'
	ages = rsx.get('fsk', None) if SECTOR else rsx['fsk'][st_vocal] if rsx.get('fsk', '') and rsx['fsk'].get(st_vocal, '') else None
	mpaa = str(ages).replace('ab 0 Jahre -', '').replace('freigegeben', '').strip() if str(ages) not in ['None', '0', 'nicht definiert'] else None
	country = ', '.join(sorted([cou for cou in regions])) if regions else None
	year = int(rsx[st_year][st_vocal]) if rsx.get(st_year, '') and str(rsx[st_year].get(st_vocal))[:4].isdecimal() and int(rsx[st_year][st_vocal]) != 0 else None
	genre = ' / '.join(sorted([gen.get('name', '') for gen in species][:2])) if SECTOR and species else ' / '.join(sorted([gen for gen in species][:2])) if species else None
	if SECTOR and rsx.get(st_foto, '') and isinstance(rsx[st_foto], list):
		num, resources = rsx.get(st_code, ''), rsx.get(st_foto, [])
		thumb = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
		poster = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
		banner = get_Picture(num, resources, 'cover')
		fanart = (get_Picture(num, resources, 'basic') or get_Picture(num, resources, 'thumbnail') or defaultFanart)
	elif SECTOR and rsx.get('image', '') and len(rsx['image']) > 0:
		if rsx['image'].get('category') in ['thumbnail', 'basic'] and rsx['image'].get('url'):
			thumb = rsx['image']['url'].replace(' ', '%20')
	return [cid, crn, slug, norm, videocount, title, origserie, desc, duration, season, episode, aired, begins, note_1, note_2, note_3, note_4, votes, mpaa, country, year, genre, thumb, poster, banner, fanart]

def SearchBIBELTV():
	debug_MS("(navigator.SearchBIBELTV) ------------------------------------------------ START = SearchBIBELTV -----------------------------------------------")
	keyword = preserve(SEARCH_FILE, 'TEXT') if xbmcvfs.exists(SEARCH_FILE) else None
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(translation(30630), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword:
		return listSearches(keyword, 'SEARCH_QUERY')
	return None

def listSearches(TARGET, FIRST):
	debug_MS("(navigator.listSearches) ------------------------------------------------ START = listSearches -----------------------------------------------")
	debug_MS(f"(navigator.listSearches) ### KEYWORD = {TARGET} ### FIRST = {FIRST} ###")
	NOW_UTC = f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
	ENTRIES = json.loads(json.dumps(config[FIRST]))
	ENTRIES['query'], ENTRIES['filters']['any'][0]['all'][3]['scheduling_end']['from'] = TARGET, NOW_UTC
	ENTRIES['filters']['any'][1]['all'][2]['scheduling_start']['to'], ENTRIES['filters']['any'][1]['all'][3]['scheduling_end']['from'] = NOW_UTC, NOW_UTC
	FOUND, DATA_ONE = 0, Transmission().retrieveContent(config['ENGINES'], 'POST', PRO='QUERIES', forcing=False, data=json.dumps(ENTRIES, indent=2))
	if DATA_ONE not in ['', None] and DATA_ONE.get('results', '') and len(DATA_ONE['results']) > 0:
		for item in DATA_ONE.get('results', []):
			if item.get('page_category', '') and item['page_category'].get('raw', '') and item['page_category']['raw'] != 'mediathek': continue # Alles was nicht Mediathek ist herausfiltern
			debug_MS(f"(navigator.listSearches[1]) xxxxx ITEM-01 : {item} xxxxx")
			each, folder = create_substances(item, False), True
			# [cid=0, crn=1, slug=2, norm=3, videocount=4, title=5, origserie=6, desc=7, duration=8, season=9, episode=10, aired=11, begins=12]
			# [note_1=13, note_2=14, note_3=15, note_4=16, votes=17, mpaa=18, country=19, year=20, genre=21, thumb=22, poster=23, banner=24, fanart=25]
			if each[22] is None: continue # Wenn kein Thumb vorhanden - ausblenden
			if each[3].lower() == 'video' and each[1] is not None and each[8] is not None:
				folder, ACTION = False, {'mode': 'playVideo', 'url': each[1]}
			elif each[3].lower() == 'page' and each[8] is None and str(each[0]).isdecimal():
				folder, ACTION = True, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'SERIE_BY_ID', 'last': 'videos', 'extras': int(each[0]), 'transmit': each[5]}
			else: continue
			FOUND += 1
			PLOT = each[13]+each[14]+each[15]+each[7]
			NAME = each[5] if folder else each[5]+each[16]
			debug_MS(f"(navigator.listSearches[2]) ### ACTION : {ACTION} || NAME : {NAME} || TYPE : {each[3].title()} #####")
			debug_MS(f"(navigator.listSearches[2]) ##### SERIE : {each[6]} || GENRE : {each[21]} || SEASON : {each[9]} || EPISODE : {each[10]} #####")
			debug_MS(f"(navigator.listSearches[2]) ##### AIRED : {each[11]} || DURATION : {each[8]} || THUMB : {each[22]} #####")
			debug_MS("++++++++++++++++++++++++")
			FETCH_UNO = {'Title': NAME, 'Plot': PLOT, 'Season': each[9],'Episode': each[10], 'Duration': each[8], 'Date': each[12], 'Aired': each[11], \
				'Year': each[20], 'Genre': each[21], 'Country': each[19], 'Votes': each[17], 'Mpaa': each[18], 'Mediatype': 'episode' if not folder else None, \
				'Image': each[22], 'Fanback': each[22], 'Reference': 'Single' if not folder else 'Standard'}
			addDir(ACTION, create_entries(FETCH_UNO), folder)
	if FOUND == 0:
		failing("(navigator.listSearches) ##### Keine COMBI_SEARCH-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524), translation(30525).format(TARGET), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listChurches():
	debug_MS("(navigator.listChurches) ------------------------------------------------ START = listChurches -----------------------------------------------")
	UNIKAT, FOUND, DATA_ONE = set(), 0, Transmission().retrieveContent(config['SERVICES'], PRO='CHURCH', forcing=False)
	if DATA_ONE not in ['', None] and len(DATA_ONE) > 0:
		for item in DATA_ONE:
			(start_date, ends_date), (note_1, note_2, note_3, desc) = (None for _ in range(2)), ("" for _ in range(4))
			debug_MS(f"(navigator.listChurches[1]) xxxxx ITEM-01 : {item} xxxxx")
			code = item.get('id', '00')
			if str(item.get('start_timestamp')).isdecimal():
				local_start = get_CentralTime(datetime(1970,1,1) + timedelta(seconds=item['start_timestamp']), 'EPOCHTIME')
				start_date = local_start.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			if str(item.get('stop_timestamp')).isdecimal():
				local_ends = get_CentralTime(datetime(1970,1,1) + timedelta(seconds=item['stop_timestamp']), 'EPOCHTIME')
				ends_date = local_ends.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			if start_date and ends_date: note_1 = translation(30628).format(start_date, ends_date)
			elif start_date and ends_date is None: note_1 = translation(30629).format(start_date)
			if item.get('prediger', ''): note_2 = translation(30631).format(cleaning(item['prediger']))
			title = cleaning(item['name'])
			testing = f"{start_date} ~ {ends_date} ~ {title}" if start_date and ends_date else None
			if testing and testing in UNIKAT:
				continue
			UNIKAT.add(testing)
			thumb, poster = item.get('thumbnail_url', None), item.get('vertical_img_url', None)
			fanart, desc = item.get('thumbnail_url', defaultFanart), get_Description(item)
			connect, status = item.get('is_connected', False), item.get('scheduling_state', 'today')
			if (connect is True or status == 'running') and item.get('stream', '') and item['stream'].get('viewing_url', ''):
				note_3 = f"[CR][CR]{translation(30632)}" if desc != "" else f"[CR]{translation(30632)}" if note_2 != "" else translation(30632)
				PLOT = note_1+note_2+desc+note_3
				ACTION = {'mode': 'playVideo', 'url': item['stream']['viewing_url'], 'transmit': f"LIVE_PLAY@@{title}@@{code}@@{thumb}@@{PLOT}@@"}
			else:
				note_3 = f"[CR][CR]{translation(30633)}" if desc != "" else f"[CR]{translation(30633)}" if note_2 != "" else translation(30633)
				PLOT = note_1+note_2+desc+note_3
				ACTION = {'mode': 'blankFUNC', 'url': code}
			if start_date and ends_date:
				FOUND += 1
				debug_MS(f"(navigator.listChurches[2]) ##### NAME : {title} || IDD : {code} || STREAM : {ACTION.get('url')} #####")
				debug_MS(f"(navigator.listChurches[2]) ##### STATUS : {status} || START : {start_date} || THUMB : {thumb} #####")
				debug_MS("++++++++++++++++++++++++")
				FETCH_UNO = {'Title': title, 'Plot': PLOT, 'Image': thumb, 'Poster': poster, 'Fanback': fanart, 'Mediatype': 'episode'}
				addDir(ACTION, create_entries(FETCH_UNO), False)
	if FOUND == 0:
		failing("(navigator.listChurches) ##### Keine COMBI_CHURCHES-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30521).format('LIVE-GOD'), translation(30527), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listChannels():
	debug_MS("(navigator.listChannels) ------------------------------------------------ START = listChannels -----------------------------------------------")
	for LABEL, IMG, STORY, VIDEO, CODE in [(30641, 'bibel', 32101, config['BIBELTV'], 13), (30642, 'impuls', 32102, config['IMPULS'], 14), (30643, 'echt', 32103, config['ECHTTV'], 15),
		(30644, 'ewtn', 32104, config['EWTNTV'], 16), (30645, 'hope', 32105, config['HOPETV'], 17), (30646, 'ktv', 32106, config['KATOTV'], 18)]:
		st_name, st_code, st_desc, st_video, st_frame = translation(LABEL), CODE, translation(STORY), VIDEO, f"{artpic}{IMG}.png"
		debug_MS(f"(navigator.listChannels[1]) ##### TITLE : {st_name} || CODE : {st_code} || STREAM : {st_video} #####")
		if st_code in [16, 17, 18]: st_guide, part_uno, st_photo = st_desc, st_desc, st_frame
		else: 
			guide_data, guide_thumb = getSchedules(st_name, st_code)
			if guide_data == "": st_guide = part_uno = st_desc
			else: st_guide, part_uno = guide_data.replace('@@', ''), guide_data.split('@@')[0]
			st_photo = guide_thumb if guide_thumb else st_frame
		FETCH_UNO = create_entries({'Title': f"[B]{st_name}[/B]", 'Plot': st_guide, 'Image': st_photo, 'Mediatype': 'episode'})
		addDir({'mode': 'playVideo', 'url': st_video, 'transmit': f"LIVE_PLAY@@{st_name}@@{st_code}@@{st_photo}@@{part_uno}@@"}, FETCH_UNO, False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def getSchedules(station, code, guide_info="", guide_thumb=None):
	counter_one, counter_two, NOW_UTC = 0, 0, f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
	PROGRAM = Transmission().retrieveContent(config['PROGRAMS'].format(NOW_UTC, code), PRO='PREVIEW', forcing=False)
	if PROGRAM not in ['', None] and PROGRAM.get('items', '') and len(PROGRAM['items']) > 0:
		for elem in PROGRAM.get('items', [])[:5]:
			(local_start, local_ends, published), teaser = (None for _ in range(3)), '[CR]'
			title = cleaning(elem.get('termin_titel', ''))
			phrase = (elem.get('titel_zusatz', '') or None)
			if title in ['', None]: continue
			counter_one += 1
			if str(elem.get('start'))[:4].isdecimal():
				local_start = get_CentralTime(elem['start'])
				start_date = local_start.strftime('%d{0}%m {1} %H{2}%M').format('/', '•', ':')
			if str(elem.get('ende'))[:4].isdecimal():
				local_ends = get_CentralTime(elem['ende'])
				ends_date = local_ends.strftime('%d{0}%m {1} %H{2}%M').format('/', '•', ':')
			if str(elem.get('verfuegbar_von'))[:4].isdecimal():
				local_aired = get_CentralTime(elem['verfuegbar_von'])
				published = None if str(local_aired).startswith(('1970', '2100')) else f" (Premiere: {local_aired.strftime('%d.%m.%Y')})"
			season = f"{int(elem['staffel']):02}" if str(elem.get('staffel')).isdecimal() and int(elem['staffel']) != 0 else None
			episode = f"{int(elem['folgennummer']):02}" if str(elem.get('folgennummer')).isdecimal() and int(elem['folgennummer']) != 0 else None
			if episode:
				if phrase: sub_title = translation(30661).format(season, episode, cleaning(phrase)) if season else translation(30662).format(episode, cleaning(phrase))
				else: sub_title = translation(30663).format(season, episode) if season else translation(30664).format(episode)
			else: sub_title = cleaning(phrase) if phrase else None
			substance = next(filter(lambda ta: ta.get('textart', '') == 'Beschreibung' and ta.get('inhalt', {}), elem.get('texte', [])), None)
			if substance and substance.get('inhalt', '') and len(substance['inhalt']) > 10:
				teaser = f"{cleaning(substance['inhalt'])[:300]}..." if len(substance['inhalt']) > 300 else cleaning(substance['inhalt'])
			if teaser == '[CR]' and elem.get('episoden_text', '') and len(elem['episoden_text']) > 10:
				teaser = f"{cleaning(elem['episoden_text'])[:300]}..." if len(elem['episoden_text']) > 300 else cleaning(elem['episoden_text'])
			description = f"{teaser}{published}@@[CR][CR]" if len(teaser) > 10 and published else f"{teaser}@@[CR][CR]" if len(teaser) > 10 else teaser
			debug_MS(f"(navigator.getSchedules[2]) ##### COUNTER : {counter_one} || SERIE : {title} || EPISODE : {sub_title} #####")
			debug_MS(f"(navigator.getSchedules[2]) ##### STATION : {station} || START : {local_start} || ENDED : {local_ends} #####")
			debug_MS("---------------------------------------------")
			if local_start and local_ends and not str(local_ends).startswith(('1970', '2100')) and local_ends > datetime.now():
				counter_two += 1
				if sub_title is None: guide_info += translation(30665).format(start_date, ends_date, title, description)
				else: guide_info += translation(30666).format(start_date, ends_date, title, sub_title, description)
				scene = next(filter(lambda bg: bg.get('beschreibung', '') == 'Serien-Bild' and bg.get('url', {}), elem.get('bilder', [])), None)
				if scene and scene.get('url', '') and len(scene['url']) > 10 and counter_two == 1: guide_thumb = scene['url'].replace(' ', '%20')
	return (guide_info, guide_thumb)

def playVideo(PLID, RIDERS):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	MEDIAS, (CHIAVE, DRM_GUARD, DRM_SPECIES), (OTHER, STREAM, FINAL_URL) = [], (None for _ in range(3)), (False for _ in range(3))
	if RIDERS.startswith('LIVE_PLAY'):
		SECTION = RIDERS.split('@@')
		debug_MS(f"(navigator.playVideo[1]) ### PLID : {PLID} ### NAME : {SECTION[1]} ### THUMB : {SECTION[3]} ###")
		NAME, IMAGE = re.sub(r'\[/?B\]', '', SECTION[1]), SECTION[3]
		STREAM, MIME, FINAL_URL = 'HLS', 'application/vnd.apple.mpegurl', PLID
		DESC = SECTION[4] if len(SECTION[4]) > 8 else ' '
	else:
		NOW_UTC = f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
		ENTRIES = json.loads(json.dumps(config['VIDEOS']))
		ENTRIES = {**ENTRIES, **{'variables': {'crn': PLID, 'now': NOW_UTC, 'targetTechnology': 'mobile_app_android'}}}
		DATA_ONE = Transmission().retrieveContent(GRAPH_BASE, 'POST', data=json.dumps(ENTRIES, indent=2))
		debug_MS("++++++++++++++++++++++++")
		debug_MS(f"(navigator.playVideo[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
		debug_MS("++++++++++++++++++++++++")
		if DATA_ONE not in ['', None] and DATA_ONE.get('data', '') and DATA_ONE['data'].get('videos', '') and len(DATA_ONE['data']['videos']) > 0:
			for elem in DATA_ONE['data']['videos']:
				for each in elem.get('editions', {})[0].get('videoUrls', []):
					FORMAT, SOURCE = each.get('type', None), each.get('src', None)
					if 'fairplay/' in SOURCE: continue # Apple-Fairplay aussortieren - nicht kompatibel
					KEY_URL = each['keySystem']['widevine']['url'] if FORMAT == 'application/dash+xml' and each.get('keySystem', '') and \
						each['keySystem'].get('widevine', '') and each['keySystem']['widevine'].get('url', '') else None
					if FORMAT == 'application/dash+xml' and '.mpd' in SOURCE:
						VIDEO, TYPE, CHIAVE = SOURCE, FORMAT, KEY_URL
					if FORMAT in['application/vnd.apple.mpegurl', 'application/x-mpegURL'] and '.m3u8' in SOURCE and 'aes128/' in SOURCE:
						OTHER, VIDEO, TYPE, CHIAVE = True, SOURCE, FORMAT, None
					if FORMAT == 'video/mp4' and '.mp4' in SOURCE:
						VIDEO, TYPE, CHIAVE = SOURCE, FORMAT, None
					MEDIAS.append({'video': VIDEO, 'mime': TYPE, 'keyUrl': CHIAVE})
			debug_MS(f"(navigator.playVideo[2]) ORIGINAL_SOURCES ### MEDIAS_LIST : {MEDIAS} ###")
		if not FINAL_URL and MEDIAS:
			for item_uno in MEDIAS:
				if (prefSTREAM == 0 or OTHER is False) and item_uno['mime'] == 'application/dash+xml' and item_uno['video'] is not None:
					log("(navigator.playVideo[3]) ***** TAKE - Inputstream (mpd) - FILE *****")
					STREAM, MIME, FINAL_URL, DRM_GUARD = 'MPD', item_uno['mime'], item_uno['video'], item_uno['keyUrl']
		if not FINAL_URL and MEDIAS:
			for item_due in MEDIAS:
				if '.m3u8' in item_due['video'] and item_due['mime'] in ['application/vnd.apple.mpegurl', 'application/x-mpegURL']:
					STREAM = 'M3U8' if prefSTREAM == 2 else 'HLS'
					MIME, FINAL_URL = item_due['mime'], item_due['video']
					log(f"(navigator.playVideo[3]) ***** TAKE - Standard/Inputstream ({STREAM.lower()}) - FILE *****")
		if not FINAL_URL and MEDIAS:
			for item_tre in MEDIAS:
				if '.mp4' in item_tre['video'] and item_tre['mime'] == 'video/mp4':
					STREAM, MIME, FINAL_URL = 'MP4', item_tre['mime'], item_tre['video']
					log("(navigator.playVideo[3]) ***** TAKE - mp4 (last Chance) -  FILE *****")
	if FINAL_URL and STREAM:
		if RIDERS.startswith('LIVE_PLAY'):
			LPM = xbmcgui.ListItem(NAME, path=FINAL_URL, offscreen=True)
			if KODI_ov20:
				LPM.getVideoInfoTag().setTitle(NAME), LPM.getVideoInfoTag().setPlot(DESC)
			else: LPM.setInfo('Video', {'Title' : NAME, 'Plot' : DESC})
			LPM.setArt({'icon': icon, 'thumb': IMAGE, 'poster': IMAGE, 'fanart': defaultFanart})
		else:
			LPM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		if plugin_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			IA_NAME, IA_SYSTEM = 'inputstream.adaptive', 'com.widevine.alpha'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			DRM_HEADERS = {'User-Agent': agent_WEB, 'Content-Type': 'application/octet-stream'}
			LPM.setMimeType(MIME), LPM.setContentLookup(False), LPM.setProperty('inputstream', IA_NAME)
			if KODI_un21:
				LPM.setProperty(f"{IA_NAME}.manifest_type", STREAM.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			if KODI_ov20:
				LPM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={agent_WEB}") # On KODI v20 and above
			else: LPM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={agent_WEB}") # On KODI v19 and below
			if int(IA_VERSION) >= 2150 and STREAM in ['HLS', 'MPD']:
				DRM_SPECIES = {'DRM_System': 'org.w3.clearkey'} if STREAM == 'HLS' else {'DRM_System': IA_SYSTEM}
				if STREAM == 'MPD' and DRM_GUARD:
					DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS)}
				LPM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
			elif int(IA_VERSION) < 2150 and STREAM == 'MPD':
				LPM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
				if DRM_GUARD:
					DRM_SPECIES = {'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS), 'Post_Data': 'R{SSM}|'}
					LPM.setProperty(f"{IA_NAME}.license_key", '|'.join(DRM_SPECIES.values())) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
			if DRM_SPECIES: log(f"(navigator.playVideo[4]) INPUTSTREAM_VERSION: {IA_VERSION} >>>>> LICENSE : {'|'.join(DRM_SPECIES.values())} <<<<<")
		if RIDERS.startswith('LIVE_PLAY'):
			xbmc.Player().play(item=FINAL_URL, listitem=LPM)
		else:
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}|User-Agent={agent_WEB}")
	else:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### PLID : {PLID} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *bibeltv.de* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('STREAM'), translation(30526), icon, 10000)

def addDir(params, listitem, folder=True, higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enableBACK and PLACEMENT == 1 and higher is True:
		entries.append([translation(30680), f"RunPlugin({build_mass({'mode': 'callingMain'})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
