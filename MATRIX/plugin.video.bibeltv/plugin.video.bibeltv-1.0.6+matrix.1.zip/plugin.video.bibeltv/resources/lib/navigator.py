﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
import io
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote  # Python 2.X
else: 
	from urllib.parse import urlencode, quote  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listEpisodes', 'url': BASE_API+'videos?limit=50&offset=0&sort=startDate:-1'})
	addDir(translation(30602), icon, {'mode': 'listEpisodes', 'url': BASE_API+'videos?limit=50&offset=0&sort=endDate:1&q=ge(endDate,isodate:2000-05-05T22:00:00.000Z)'})
	addDir(translation(30603), icon, {'mode': 'listEpisodes', 'url': BASE_API+'videos?limit=50&offset=0&sort=playCount:-1'})
	addDir(translation(30604), icon, {'mode': 'listEpisodes', 'url': BASE_API+'videos?q=contains(sourcePlaylistIds,%225992190916001%22)&limit=100&offset=0&sort=startDate:-1'})
	addDir(translation(30605), icon, {'mode': 'listBroadcasts', 'url': BASE_API+'genres?q=gt(entriesCount,0)&limit=100&offset=0&sort=name:1&fields=name,kalturaId,entriesCount,api_id'})
	addDir(translation(30606), icon, {'mode': 'listBroadcasts', 'url': BASE_API+'series?q=gt(entriesCount,0)&limit=200&offset=0&sort=name:1&fields=name,crn,api_id,description,thumbnail,images,kalturaId,entriesCount'})
	addDir(translation(30607), artpic+'livestream.png', {'mode': 'liveTV'})
	if enableADJUSTMENT:
		addDir(translation(30608), artpic+'settings.png', {'mode': 'aSettings'})
		if ADDON_operate('inputstream.adaptive'):
			addDir(translation(30609), artpic+'settings.png', {'mode': 'iSettings'})
		else:
			addon.setSetting('streamSelection', '2')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(url): # Auflistung von Genres, Sendereihen
	debug_MS("(navigator.listBroadcasts) -------------------------------------------------- START = listBroadcasts --------------------------------------------------")
	debug_MS("(navigator.listBroadcasts) ### URL = {0} ###".format(url))
	response = getUrl(url)
	DATA = json.loads(response)
	for item in DATA['items']:
		debug_MS("(navigator.listBroadcasts) ### ENTRY : {0} ###".format(str(item)))
		title = cleaning(item['name'])
		apiId = (item.get('api_id', '0') or '0')
		plot = get_Description(item)
		photo = (item.get('thumbnail', '') or icon)
		kalturaId = (str(item.get('kalturaId', '0')) or '0')
		if item.get('entriesCount') and 'series' in url:
			title += '  ('+str(item['entriesCount'])+')'
		if item.get('href', None):
			debug_MS("(navigator.listBroadcasts) ##### TITLE : {0} || newURL : {1} || EXTRAS : {2} || FOTO : {3} #####".format(str(title), item['href'], str(apiId), photo))
			addDir(title, photo, {'mode': 'listEpisodes', 'url': item['href'], 'extras': str(apiId)}, plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, page, limit, offset, extras):
	debug_MS("(navigator.listEpisodes) -------------------------------------------------- START = listEpisodes --------------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### orig_URL = {0} ### PAGE = {1} ### LIMIT = {2} ### OFFSET = {3} ### EXTRAS = {4} ###".format(url, str(page), str(limit), str(offset), str(extras)))
	COMBI_EPISODE, uno_LIST = ([] for _ in range(2))
	UNIKAT = set()
	if int(page) == 1 and ('genres' in url or 'series' in url):
		special = 'genres' if 'genres' in url else 'series'
		url = BASE_API+'videos?q=contains({0},{1})&limit=50&offset=0&sort=startDate:-1'.format(special, str(extras))
	elif int(page) > 1:
		url = url.split('limit=')[0]+'limit='+str(limit)+'&offset='+str(offset)+'&sort'+url.split('&sort')[1]
	startURL = url
	url += '&fields=name,urls,kalturaId,descriptionLong,description,descriptionShort,subtitle,seasonNumber,episodeNumber,startDate,endDate,FSK,duration,yearOfProduction,countryOfProduction,crn,thumbnailUrl,director,cast,api_id,genres,likeCount,drm&expand=director,cast'
	debug_MS("(navigator.listEpisodes) ### ready_URL : {0} ###".format(url))
	response = getUrl(url)
	DATA = json.loads(response)
	if 'items' in DATA and len(DATA['items']) > 0:
		for item in DATA['items']:
			photo, Note_1, Note_2, Note_3, Note_4, country, director, cast, genre = ("" for _ in range(9))
			season, episode, duration, kalturaId = ('0' for _ in range(4))
			origSERIE, startTIMES, endTIMES, mpaa, year, text, votes = (None for _ in range(7))
			directorLIST, castLIST = ([] for _ in range(2))
			debug_MS("(navigator.listEpisodes) ### ENTRY : {0} ###".format(str(item)))
			title = cleaning(item['name'])
			if item.get('subtitle', ''):
				origSERIE = cleaning(item['subtitle'])
				title = title+' - '+cleaning(item['subtitle']) if not 'series' in startURL else title
			if item.get('seasonNumber', ''):
				season = str(item['seasonNumber'])
			if item.get('episodeNumber', ''):
				episode = str(item['episodeNumber'])
			cineType = 'episode' if episode != '0' else 'movie'
			if origSERIE and episode != '0':
				suffix = 'S.'+season.zfill(2)+' - E.'+episode.zfill(2) if season != '0' else 'E.'+episode.zfill(2)
				Note_1 = origSERIE+translation(30631).format(suffix)+'[CR]'
				Note_4 = translation(30631).format(suffix)
			elif origSERIE and episode is '0':
				Note_1 = origSERIE+'[CR]'
			if item.get('duration', ''):
				converted_DN = round(int(item['duration']))
				duration = "{0:.0f}".format(converted_DN)
			kalturaId = (str(item.get('kalturaId', '0')) or '0')
			MULTI_urls = item.get('urls', None)
			if not MULTI_urls or (kalturaId is not '0' and kalturaId in UNIKAT):
				continue
			UNIKAT.add(kalturaId)
			photo = (item.get('thumbnailUrl', '').replace('160x90/', '1280x720/').replace('320x180/', '1280x720/').replace('640x360/', '1280x720/') or "")
			if str(item.get('startDate'))[:4].isdigit() and str(item.get('startDate'))[:4] not in ['0', '1970']: # 2020-10-20T16:00:18.000Z
				startDATES = datetime(*(time.strptime(item['startDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2020-10-24T23:30:18.000Z
				LOCALstart = utc_to_local(startDATES)
				startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			if startTIMES: Note_2 = translation(30632).format(str(startTIMES))
			if str(item.get('endDate'))[:4].isdigit() and str(item.get('endDate'))[:4] not in ['0', '1970']: # 2020-11-19T16:00:18.000Z
				endDATES = datetime(*(time.strptime(item['endDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6])) # 2020-11-19T16:00:18.000Z
				LOCALend = utc_to_local(endDATES)
				endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			if endTIMES: Note_3 = translation(30633).format(str(endTIMES))
			if str(py2_enc(item.get('FSK'))) not in ['None', '0', 'nicht definiert']:
				mpaa = str(py2_enc(item.get('FSK'))).replace('ab 0 Jahre -', '').replace('freigegeben', '').replace('ohne Altersbeschränkung', '').strip()
			if item.get('yearOfProduction') != None and len(item.get('yearOfProduction')) > 0:
				year = item['yearOfProduction'][0]
			if item.get('countryOfProduction') != None and len(item.get('countryOfProduction')) > 0:
				country = cleaning(item['countryOfProduction'][0])
			if item.get('director', ''):
				directorLIST = [cleaning(dirNAME.get('name', [])) for dirNAME in item.get('director', '')]
				if directorLIST: director = ', '.join(sorted(directorLIST))
			if item.get('cast', ''):
				castLIST = [cleaning(caNAME.get('name', [])) for caNAME in item.get('cast', '')]
				if castLIST: cast = ', '.join(sorted(castLIST))
			if os.path.exists(GENREFILE):
				with io.open(GENREFILE, 'rb') as data_infile:
					text = data_infile.read()
			genrefields = item.get('genres', None)
			if genrefields and text:
				genrelist = json.loads(text.decode('utf-8', 'ignore'))
				for elem in genrefields:
					for entry in genrelist['species']:
						if not str(elem).isdigit() and 'href' in elem and elem['href'] == entry['href']:
							genre = cleaning(entry['name'])
			votes = (str(item.get('likeCount', '')) or "")
			protect = (item.get('drm', None) or False)
			desc = get_Description(item)
			plot = Note_1+Note_2+Note_3+'[CR]'+desc
			name = title+Note_4
			debug_MS("(navigator.listEpisodes) ##### TITLE : {0} || kalturaId : {1} || FOTO : {2} || DURATION : {3} #####".format(str(name), kalturaId, photo, str(duration)))
			debug_MS("(navigator.listEpisodes) ##### origSERIE : {0} || SE : {1} || EP : {2} || GENRE : {3} || YEAR : {4} #####".format(str(origSERIE), str(season), str(episode), genre, str(year)))
			COMBI_EPISODE.append([name, origSERIE, season, episode, cineType, duration, kalturaId, MULTI_urls, photo, mpaa, year, country, director, cast, votes, protect, genre, plot])
	if COMBI_EPISODE:
		for name, origSERIE, season, episode, cineType, duration, kalturaId, MULTI_urls, photo, mpaa, year, country, director, cast, votes, protect, genre, plot in COMBI_EPISODE:
			EP_entry = kalturaId+'@@'+str(MULTI_urls)+'@@'+str(origSERIE)+'@@'+str(name)+'@@'+str(photo)+'@@'+str(duration)+'@@'+str(season)+'@@'+str(episode)+'@@'+str(protect)+'@@'
			if EP_entry not in uno_LIST:
				uno_LIST.append(EP_entry)
			listitem = xbmcgui.ListItem(name, path=HOST_AND_PATH+'?IDENTiTY='+kalturaId+'&mode=playCODE')
			info = {}
			if season != '0':
				info['Season'] = season
			info['Episode'] = episode
			info['Tvshowtitle'] = origSERIE
			info['Title'] = name
			info['Tagline'] = None
			info['Plot'] = plot
			info['Duration'] = duration
			info['Year'] = year
			info['Country'] = [country]
			info['Genre'] = [genre]
			info['Director'] = [director]
			info['Cast'] = [cast]
			info['Votes'] = votes
			info['Studio'] = 'bibel.TV'
			info['Mpaa'] = mpaa
			info['Mediatype'] = cineType
			listitem.setInfo(type='Video', infoLabels=info)
			listitem.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
			if useThumbAsFanart and photo != icon and not artpic in photo:
				listitem.setArt({'fanart': photo})
			listitem.addStreamInfo('Video', {'Duration': duration})
			listitem.setProperty('IsPlayable', 'true')
			listitem.setContentLookup(False)
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+kalturaId+'&mode=playCODE', listitem=listitem)
		with io.open(WORKFILE, 'w', encoding='utf-8', errors='ignore') as input:
			input.write(py2_uni('\n'.join(uno_LIST)))
	try:
		nextPG = DATA['next']
		if nextPG.startswith('https://api.bibeltv.de/v1'):
			limit, offset = re.compile('limit=([0-9]+?)&offset=([0-9]+?)&', re.DOTALL).findall(nextPG)[0]
			debug_MS("(navigator.listEpisodes) found nextPAGE... XXX LIMIT : {0} || OFFSET : {1} XXX".format(str(limit), str(offset)))
			if int(offset) >= int(limit)*int(page):
				debug_MS("(navigator.listEpisodes) XXX HOLD nextPAGE... XXX")
				addDir(translation(30634), artpic+'nextpage.png', {'mode': 'listEpisodes', 'url': startURL, 'page': int(page)+1, 'limit': int(limit), 'offset': int(offset)})
	except: pass
	if not COMBI_EPISODE:
		return dialog.notification(translation(30522).format('Einträge'), translation(30524), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS("(navigator.playCODE) ### IDD = {0} ###".format(IDD))
	MEDIAS = []
	FOUND = False
	finalURL = False
	manifest_type = False
	licenseURL = False
	with io.open(WORKFILE, 'r', encoding='utf-8', errors='ignore') as output:
		lines = output.readlines()
		for line in lines:
			field = line.split('@@')
			if field[0]==IDD:
				FOUND = True
				entryId = field[0]
				ALL_URLS = field[1].replace("u'","'").replace('\'', '"')
				seriesname = field[2]
				name = field[3]
				photo = field[4]
				duration = field[5]
				season = field[6]
				episode = field[7]
				DRM = (True if field[8].lower() == 'true' else False)
				debug_MS("(navigator.playCODE) ### WORKFILE-Line : {0} ###".format(str(py2_enc(line))))
	if FOUND:
		for subITEM in json.loads(ALL_URLS):
			subUrl = subITEM['url']
			subType = subITEM['type']
			subLic = subITEM['widevine_license_url'] if 'widevine_license_url' in subITEM else None
			subWith = subITEM['width'] if 'width' in subITEM and subITEM['width'] != -1 else None
			MEDIAS.append({'url': subUrl, 'mimeType': subType, 'licenseUrl': subLic, 'width': subWith})
		debug_MS("(navigator.playCODE) ### MEDIAS_list : {0} ###".format(str(MEDIAS)))
		if MEDIAS:
			for item in MEDIAS:
				if ADDON_operate('inputstream.adaptive'):
					if 'dash/' in item['url'] and '.mpd' in item['url'] and item['mimeType'] == 'application/dash+xml' and (prefSTREAM == "0" or DRM is True):
						manifest_type = 'mpd'
						mime_type = item['mimeType']
						finalURL = item['url']
						licenseURL = item['licenseUrl']
						debug_MS("(navigator.playCODE) XXX TAKE - Inputstream (mpd) - FILE XXX")
					elif 'hls/' in item['url'] and '.m3u8' in item['url'] and item['mimeType'] == 'application/x-mpegURL' and prefSTREAM == "1" and DRM is False:
						manifest_type = 'hls'
						mime_type = item['mimeType']
						finalURL = item['url']
						debug_MS("(navigator.playCODE) XXX TAKE - Inputstream (hls) - FILE XXX")
		if not finalURL and MEDIAS:
			for item in MEDIAS:
				if 'hls/' in item['url'] and '.m3u8' in item['url'] and item['mimeType'] == 'application/x-mpegURL' and prefSTREAM == "2":
					mime_type = item['mimeType']
					finalURL = item['url']
					debug_MS("(navigator.playCODE) XXX TAKE - m3u8 - FILE XXX")
				if not finalURL and '.mp4' in item['url'] and item['mimeType'] == 'video/mp4':
					if len(item['url']) > 1 and 'width' in item and item['width'] is not None:
						max_res = max(MEDIAS, key=lambda a: a['width'])
						mime_type = max_res['mimeType']
						finalURL = max_res['url']
					else:
						mime_type = item['mimeType']
						finalURL = item['url']
					debug_MS("(navigator.playCODE) XXX TAKE - mp4 (Breite: {0}px) -  FILE XXX".format(str(item['width'])))
	if finalURL:
		userAgent = '|User-Agent='+get_userAgent()
		log("(navigator.playCODE) StreamURL : {0}".format(finalURL+userAgent))
		listitem=xbmcgui.ListItem(path=finalURL)
		listitem.setMimeType(mime_type)
		if ADDON_operate('inputstream.adaptive') and manifest_type:
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.stream_headers', 'user-agent={0}'.format(get_userAgent()))
			listitem.setProperty('inputstream.adaptive.manifest_type', manifest_type)
			if licenseURL and DRM is True:
				lic_KEY = u'{0}{1}&Content-Type=application/octet-stream|{2}|'.format(licenseURL, userAgent, 'R{SSM}')
				listitem.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
				listitem.setProperty('inputstream.adaptive.license_key', lic_KEY)
				debug_MS("(navigator.playCODE) LICENSE : {0}".format(str(lic_KEY)))
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playCODE) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *bibeltv.de* gefunden !!! ##########".format(str(url)))
		return dialog.notification(translation(30521).format('STREAM'), translation(30526), icon, 8000)

def liveTV():
	debug_MS("(navigator.liveTV) ------------------------------------------------ START = liveTV -----------------------------------------------")
	items = []
	items.append([translation(30641), "https://bibeltv01.iptv-playoutcenter.de/bibeltv01/bibeltv01.stream_all/playlist.m3u8", artpic+'bibeltv.png'])
	items.append([translation(30642), "https://bibeltv02.iptv-playoutcenter.de/bibeltv02/bibeltv02.stream_all/playlist.m3u8", artpic+'impuls.png'])
	items.append([translation(30643), "https://bibeltv03.iptv-playoutcenter.de/bibeltv03/bibeltv03.stream_all/playlist.m3u8", artpic+'musik.png'])
	for item in items:
		listitem = xbmcgui.ListItem(path=item[1], label=item[0])
		listitem.setArt({'icon': icon, 'thumb': item[2], 'poster': item[2], 'fanart': defaultFanart})
		xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+"?mode=playLIVE&url="+quote(item[1])+"&extras="+item[0], listitem=listitem)  
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playLIVE(url, extras):
	listitem = xbmcgui.ListItem(path=url, label='[COLOR lime]* Livestream - '+extras+' *[/COLOR]')
	listitem.setMimeType('application/x-mpegurl')
	xbmc.Player().play(item=url, listitem=listitem)

def addDir(name, image, params={}, plot=None, genre=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': genre})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)
