﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
import io
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import quote_plus, urlencode  # Python 2.X
else: 
	from urllib.parse import quote_plus, urlencode  # Python 3.X

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listEpisodes', 'url': BASE_API+'videos?limit=50&offset=0&sort=startDate:-1'})
	addDir(translation(30602), icon, {'mode': 'listEpisodes', 'url': BASE_API+'videos?limit=50&offset=0&sort=playCount:-1'})
	addDir(translation(30603), icon, {'mode': 'listEpisodes', 'url': BASE_API+'videos?limit=50&offset=0&sort=endDate:1&q=ge(endDate,isodate:2000-05-05T22:00:00.000Z)'})
	addDir(translation(30604), icon, {'mode': 'listEpisodes', 'url': BASE_API+'videos?q=contains(sourcePlaylistIds,%225992190916001%22)&limit=100&offset=0&sort=startDate:-1'})
	addDir(translation(30605), icon, {'mode': 'listBroadcasts', 'url': BASE_API+'genres?q=gt(entriesCount,0)&limit=100&offset=0&sort=name:1&fields=name,api_id,kalturaId,entriesCount'})
	addDir(translation(30606), icon, {'mode': 'listBroadcasts', 'url': BASE_API+'series?q=gt(entriesCount,0)&limit=200&offset=0&sort=name:1&fields=name,api_id,images,thumbnail,kalturaId,entriesCount,description,categories&expand=categories'})
	addDir(translation(30607), icon, {'mode': 'listEpisodes', 'url': BASE_API+'videos?q=contains(categories,8984)&limit=50&offset=0&sort=startDate:-1'})
	addDir(translation(30608), artpic+'livestream.png', {'mode': 'list_LIVE', 'url': BASE_URL+'/livestreams'})
	if enableAdjustment:
		addDir(translation(30609), artpic+'settings.png', {'mode': 'aSettings'})
		if ADDON_operate('inputstream.adaptive'):
			addDir(translation(30610), artpic+'settings.png', {'mode': 'iSettings'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(url): # Auflistung von Genres, Sendereihen
	debug_MS("(navigator.listBroadcasts) -------------------------------------------------- START = listBroadcasts --------------------------------------------------")
	debug_MS("(navigator.listBroadcasts) ### URL = {0} ###".format(url))
	response = getUrl(url)
	DATA = json.loads(response)
	for item in DATA['items']:
		debug_MS("(navigator.listBroadcasts) ### ENTRY : {0} ###".format(str(item)))
		title = cleaning(item['name'])
		apiId = str(item['api_id'])
		entriesCount = item.get('entriesCount', None)
		if entriesCount and 'series' in url:
			title += '  ('+str(item['entriesCount'])+')'
		try: photo = item['thumbnail']
		except: photo = icon
		plot = get_Description(item)
		genre = ""
		categories = item.get('categories', None)
		if categories:
			genre = cleaning(categories[0]['name'])
		href = item.get('href', None)
		if href:
			newURL = item['href']
			debug_MS("(navigator.listBroadcasts) ##### TITLE : {0} || newURL : {1} || EXTRAS : {2} || FOTO : {3} #####".format(str(title), newURL, apiId, photo))
			addDir(title, photo, {'mode': 'listEpisodes', 'url': newURL, 'extras': apiId}, plot, genre)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listEpisodes(url, page, limit, offset, extras):
	debug_MS("(navigator.listEpisodes) -------------------------------------------------- START = listEpisodes --------------------------------------------------")
	debug_MS("(navigator.listEpisodes) ### orig_URL = {0} ### PAGE = {1} ### LIMIT = {2} ### OFFSET = {3} ### EXTRAS = {4} ###".format(url, str(page), str(limit), str(offset), str(extras)))
	COMBI_EPISODE = []
	uno_LIST = []
	Isolated = set()
	if int(page) == 1 and ('genres' in url or 'series' in url):
		if 'genres' in url: special = 'genres'
		elif 'series' in url: special = 'series'
		url = BASE_API+'videos?q=contains({0},{1})&limit=50&offset=0&sort=startDate:-1'.format(special, str(extras))
	elif int(page) > 1:
		url = url.split('limit=')[0]+'limit='+str(limit)+'&offset='+str(offset)+'&sort'+url.split('&sort')[1]
	debug_MS("(navigator.listEpisodes) ### ready_URL : {0} ###".format(url))
	response = getUrl(url)
	DATA = json.loads(response)
	if 'items' in DATA and len(DATA['items']) > 0:
		for item in DATA['items']:
			Note_1, Note_2, Note_3, Note_4, videoId = ("" for _ in range(5))
			season, episode, duration, kalturaId = ('0' for _ in range(4))
			origSERIE, startTIMES, endTIMES, mpaa, year, country, text, genre, votes = (None for _ in range(9))
			debug_MS("(navigator.listEpisodes) ### ENTRY : {0} ###".format(str(item)))
			title = cleaning(item['name'])
			if 'subtitle' in item and item['subtitle'] != "" and item['subtitle'] is not None:
				title = title+' - '+cleaning(item['subtitle'])
				origSERIE = cleaning(item['subtitle'])
			if 'seasonNumber' in item and item['seasonNumber'] != "" and item['seasonNumber'] is not None:
				season = str(item['seasonNumber'])
			cineType = 'movie'
			if 'episodeNumber' in item and item['episodeNumber'] != "" and item['episodeNumber'] is not None:
				episode = str(item['episodeNumber'])
				cineType = 'episode'
			if origSERIE and episode != '0':
				suffix = 'S.'+season.zfill(2)+' - E.'+episode.zfill(2) if season != '0' else 'E.'+episode.zfill(2)
				Note_1 = origSERIE+translation(30630).format(suffix)+'[CR]'
				Note_4 = translation(30630).format(suffix)
			elif origSERIE and episode is '0':
				Note_1 = origSERIE+'[CR]'
			if 'duration' in item and item['duration'] !="" and item['duration'] is not None:
				converted_DN = int(item['duration'])
				duration = "{0:.0f}".format(converted_DN)
			if 'kalturaId' in item and item['kalturaId'] != "" and item['kalturaId'] is not None:
				kalturaId = str(item['kalturaId'])
			MULTI_urls = item.get('urls', None)
			if not MULTI_urls or (kalturaId is not '0' and kalturaId in Isolated):
				continue
			Isolated.add(kalturaId)
			try: photo = item['thumbnailUrl'].replace('160x90/', '1280x720/').replace('320x180/', '1280x720/').replace('640x360/', '1280x720/')
			except: photo = ""
			if 'api_id' in item and item['api_id'] !="" and item['api_id'] is not None:
				videoID = str(item['api_id'])
			started = item.get('startDate', None)
			if started: # 2020-12-31T00:00:00.000Z
				startDates = datetime(*(time.strptime(item['startDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))
				startTIMES = startDates.strftime('%d.%m.%Y')
			if startTIMES and not '1970' in startTIMES: Note_2 = translation(30631).format(str(startTIMES))
			ended = item.get('endDate', None)
			if ended: # 2020-12-31T00:00:00.000Z
				endDates = datetime(*(time.strptime(item['endDate'][:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))
				endTIMES = endDates.strftime('%d.%m.%Y')
			if endTIMES and not '1970' in endTIMES: Note_3 = translation(30632).format(str(endTIMES))
			plot = get_Description(item)
			if 'FSK' in item and item['FSK'] != "0" and item['FSK'] != 'nicht definiert' and item['FSK'] is not None:
				mpaa = str(item['FSK']).replace('ab 0 Jahre -', '').replace('freigegeben', '').strip()
			if 'yearOfProduction' in item and item['yearOfProduction'] != "0" and item['yearOfProduction'] is not None and not '1970' in item['yearOfProduction']:
				try: year = item['yearOfProduction'][0]
				except: pass
			if 'countryOfProduction' in item and item['countryOfProduction'] != "0" and item['countryOfProduction'] is not None:
				try: country = cleaning(item['countryOfProduction'][0])
				except: pass
			if os.path.exists(filename):
				with io.open(filename, 'rb') as data_infile:
					text = data_infile.read()
			genrefields = item.get('genres', None)
			if genrefields and text:
				genrelist = json.loads(text.decode('utf-8', 'ignore'))
				for elem in genrefields:
					for entry in genrelist['species']:
						if 'href' in elem and elem['href'] !="" and elem['href'] is not None:
							if elem['href'] == entry['href']:
								genre = cleaning(entry['name'])
			if 'likeCount' in item and item['likeCount'] != "0" and item['likeCount'] is not None:
				votes = str(item['likeCount'])
			plot = Note_1+Note_2+Note_3+'[CR]'+plot
			name = title+Note_4
			debug_MS("(navigator.listEpisodes) ##### TITLE : {0} || kalturaId : {1} || FOTO : {2} || DURATION : {3} #####".format(str(name), kalturaId, photo, str(duration)))
			debug_MS("(navigator.listEpisodes) ##### origSERIE : {0} || SE : {1} || EP : {2} || GENRE : {3} || YEAR : {4} #####".format(str(origSERIE), str(season), str(episode), genre, str(year)))
			COMBI_EPISODE.append([episode, kalturaId, MULTI_urls, photo, cineType, name, plot, duration, season, episode, genre, year, country, votes, mpaa, origSERIE])
	if COMBI_EPISODE:
		for episode, kalturaId, MULTI_urls, photo, cineType, name, plot, duration, season, episode, genre, year, country, votes, mpaa, origSERIE in COMBI_EPISODE:
			EP_entry = kalturaId+'@@'+str(MULTI_urls)+'@@'+str(origSERIE)+'@@'+str(name)+'@@'+str(photo)+'@@'+str(duration)+'@@'+str(season)+'@@'+str(episode)+'@@'
			if EP_entry not in uno_LIST:
				uno_LIST.append(EP_entry)
			listitem = xbmcgui.ListItem(name, path=HOST_AND_PATH+'?IDENTiTY='+kalturaId+'&mode=playCODE')
			info = {}
			if season != '0':
				info['Season'] = season
			info['Episode'] = episode
			info['Tvshowtitle'] = origSERIE
			info['Title'] = name
			info['Tagline'] = None
			info['Plot'] = plot
			info['Duration'] = duration
			info['Year'] = year
			info['Country'] = country
			info['Genre'] = genre
			info['Votes'] = votes
			info['Studio'] = 'Bibeltv'
			info['Mpaa'] = mpaa
			info['Mediatype'] = cineType
			listitem.setInfo(type='Video', infoLabels=info)
			listitem.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
			if useThumbAsFanart and photo != icon and not artpic in photo:
				listitem.setArt({'fanart': photo})
			listitem.addStreamInfo('Video', {'Duration': duration})
			listitem.setProperty('IsPlayable', 'true')
			listitem.setContentLookup(False)
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+kalturaId+'&mode=playCODE', listitem=listitem, isFolder=False)
		with io.open(WORKFILE, 'w', encoding='utf-8') as input:
			input.write(py2_uni('\n'.join(uno_LIST)))
	try:
		nextPG = DATA['next']
		if nextPG.startswith('https://api.bibeltv.de/v1'):
			limit, offset = re.compile('limit=([0-9]+?)&offset=([0-9]+?)&', re.DOTALL).findall(nextPG)[0]
			debug_MS("(navigator.listEpisodes) FOUND nextPAGE... XXX LIMIT : {0} || OFFSET : {1} XXX".format(str(limit), str(offset)))
			if int(offset) >= int(limit)*int(page):
				debug_MS("(navigator.listEpisodes) XXX HOLD nextPAGE... XXX")
				addDir(translation(30611), artpic+'nextpage.png', {'mode': 'listEpisodes', 'url': url, 'page': int(page)+1, 'limit': int(limit), 'offset': int(offset)})
	except: pass
	if not COMBI_EPISODE:
		return dialog.notification(translation(30522).format('Einträge'), translation(30524), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS("(navigator.playCODE) ### IDD = {0} ###".format(IDD))
	MEDIAS = []
	FOUND = False
	finalURL = False
	manifest_type = False
	with io.open(WORKFILE, 'r', encoding='utf-8') as output:
		lines = output.readlines()
		for line in lines:
			field = line.split('@@')
			if field[0]==IDD:
				FOUND = True
				entryId = field[0]
				ALL_URLS = field[1].replace("u'","'").replace('\'', '"')
				seriesname = field[2]
				name = field[3]
				photo = field[4]
				duration = field[5]
				season = field[6]
				episode = field[7]
				debug_MS("(navigator.playCODE) ### WORKFILE-Line : {0} ###".format(str(line)))
	if FOUND:
		for subITEM in json.loads(ALL_URLS):
			subUrl = subITEM['url']
			subType = subITEM['type']
			subWith = subITEM['width'] if 'width' in subITEM and subITEM['width'] != -1 else None
			MEDIAS.append({'url': subUrl, 'mimeType': subType, 'width': subWith})
		debug_MS("(navigator.playCODE) ### MEDIAS_list : {0} ###".format(str(MEDIAS)))
		if MEDIAS:
			for item in MEDIAS:
				if ADDON_operate('inputstream.adaptive'):
					if 'dash/' and '.mpd' in item['url'] and item['mimeType'] == 'application/dash+xml' and prefSTREAM == "0":
						manifest_type = 'mpd'
						mime_type = item['mimeType']
						finalURL = item['url']
						debug_MS("(navigator.playCODE) XXX TAKE - Inputstream (mpd) - FILE XXX")
					elif 'hls/' and '.m3u8' in item['url'] and item['mimeType'] == 'application/x-mpegURL' and prefSTREAM == "1":
						manifest_type = 'hls'
						mime_type = item['mimeType']
						finalURL = item['url']
						debug_MS("(navigator.playCODE) XXX TAKE - Inputstream (hls) - FILE XXX")
		if not finalURL and MEDIAS:
			for item in MEDIAS:
				if 'hls/' and '.m3u8' in item['url'] and item['mimeType'] == 'application/x-mpegURL' and prefSTREAM == "2":
					mime_type = item['mimeType']
					finalURL = item['url']
					debug_MS("(navigator.playCODE) XXX TAKE - m3u8 - FILE XXX")
				if not finalURL and '.mp4' in item['url'] and item['mimeType'] == 'video/mp4':
					if len(item['url']) > 1 and 'width' in item and item['width'] is not None:
						max_res = max(MEDIAS, key=lambda a: a['width'])
						mime_type = max_res['mimeType']
						finalURL = max_res['url']
					else:
						mime_type = item['mimeType']
						finalURL = item['url']
					debug_MS("(navigator.playCODE) XXX TAKE - mp4 (Breite: {0}px) -  FILE XXX".format(str(item['width'])))
	if finalURL:
		userAgent = '|User-Agent='+get_userAgent()
		log("(navigator.playCODE) StreamURL : {0}".format(finalURL+userAgent))
		listitem=xbmcgui.ListItem(path=finalURL)
		listitem.setMimeType(mime_type)
		if ADDON_operate('inputstream.adaptive') and manifest_type:
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.stream_headers', 'user-agent={0}'.format(get_userAgent()))
			listitem.setProperty('inputstream.adaptive.manifest_type', manifest_type)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playCODE) ##### Abspielen des Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Stream-Eintrag auf der Webseite von *bibeltv.de* gefunden !!! ##########".format(str(url)))
		return dialog.notification(translation(30521).format('STREAM'), translation(30526), icon, 8000)

def list_LIVE(url): # Auflistung der Bibeltv-Sender
	debug_MS("(navigator.list_LIVE) -------------------------------------------------- START = list_LIVE --------------------------------------------------")
	debug_MS("(navigator.list_LIVE) ### URL = {0} ###".format(url))
	content = getUrl(url)
	results = re.findall('<div class="teasermenu"><ul>(.+?)</ul></div>', content, re.S)
	for chtml in results:
		stations = re.findall('<li><a href="([^"]+)" class="bildlink"><img title="([^"]+)" alt=.*?src="([^"]+)" width=', chtml, re.S)
		for newURL, CAT, IMG in stations:
			if newURL[:4] != "http":
				newURL = BASE_URL+newURL
			if IMG[:4] != "http":
				IMG = BASE_URL+IMG
			debug_MS("(navigator.list_LIVE) ##### TITLE : {0} || URL : {1} || IMAGE : {2} #####".format(str(CAT), newURL, IMG))
			listitem = xbmcgui.ListItem(label='[COLOR lime]* '+CAT+' *[/COLOR]')
			listitem.setArt({'icon': icon, 'thumb': IMG, 'poster': IMG, 'fanart': defaultFanart})
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?url='+str(newURL)+'&extras='+str(CAT)+'&mode=playLIVE', listitem=listitem, isFolder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playLIVE(url, extras):
	debug_MS("(navigator.playLIVE) -------------------------------------------------- START = playLIVE --------------------------------------------------")
	debug_MS("(navigator.playLIVE) ### URL = {0} ### EXTRAS = {1} ###".format(url, str(extras)))
	live_url = False
	try:
		content = getUrl(url)
		live_url = re.findall(r" src: '([^']+)'", content, re.S)[0]
	except: pass
	if live_url:
		log("(navigator.playLIVE) liveURL : {0}".format(live_url))
		listitem = xbmcgui.ListItem(label='[COLOR lime]* Livestream - '+extras+' *[/COLOR]')
		listitem.setPath(live_url)
		listitem.setMimeType('application/vnd.apple.mpegurl')
		xbmc.Player().play(item=live_url, listitem=listitem)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Live-Stream-Eintrag auf der Webseite von *bibeltv.de* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('LIVE'), translation(30526), icon, 8000)

def addDir(name, image, params={}, plot=None, genre=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': genre})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)
