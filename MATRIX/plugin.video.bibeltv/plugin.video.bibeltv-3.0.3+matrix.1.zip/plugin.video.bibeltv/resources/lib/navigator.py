﻿# -*- coding: utf-8 -*-

from .common import *
from .utilities import Transmission
config = traversing.get_config()


def mainMenu():
	for TITLE, PATH in [(30601, {'mode': 'listTopics', 'url': GRAPH_BASE, 'first': 'COLLECTION', 'last': 'videos', 'extras': 3}),
		(30602, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'BROADCASTS', 'last': 'series', 'transmit': 'Broadcasts'}),
		(30603, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'GENRES', 'last': 'genres', 'transmit': 'Genres'}),
		(30604, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'PLAYLIST_BY_ID', 'last': 'videos', 'extras': 16, 'transmit': 'Exklusiv'}),
		(30605, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'PLAYLIST_BY_ID', 'last': 'videos', 'extras': 53, 'transmit': 'Spielfilme'}),
		(30606, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'SERIES', 'last': 'series', 'extras': 51, 'transmit': 'Serien'}),
		(30607, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'NEWEST', 'last': 'videos', 'transmit': 'Newest'}),
		(30608, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'LAST_CHANCE', 'last': 'videos', 'transmit': 'Last Chance'}),
		(30609, {'mode': 'SearchBIBELTV'}), (30610, {'mode': 'listChurches'}), (30611, {'mode': 'listChannels'})]:
		addDir(PATH, create_entries({'Title': translation(TITLE), 'Image': f"{artpic}basesearch.png" if TITLE == 30609 else f"{artpic}livestream.png" if TITLE in [30610, 30611] else icon}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30612), 'Image': f"{artpic}settings.png"}), folder=False)
		if prefSTREAM in [0, 1] and plugin_operate('inputstream.adaptive'):
			addDir({'mode': 'iConfigs'}, create_entries({'Title': translation(30613), 'Image': f"{artpic}settings.png"}), folder=False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('prefer_stream', '2')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTopics(TARGET, FIRST, LAST, CAT_IDD):
	debug_MS("(navigator.listTopics) ------------------------------------------------ START = listTopics -----------------------------------------------")
	debug_MS(f"(navigator.listTopics) ### URL = {TARGET} ### FIRST = {FIRST} ### LAST = {LAST} ### CAT_IDD = {CAT_IDD} ###")
	FOUND, SEND = 0, {}
	SEND['playlists'] = []
	if TARGET.startswith(GRAPH_BASE):
		NOW_UTC = f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
		ENTRIES = json.loads(json.dumps(config[FIRST]))
		ENTRIES['variables']['id'], ENTRIES['variables']['take'], ENTRIES['variables']['skip'], ENTRIES['variables']['now'] = int(CAT_IDD), 20, 0, NOW_UTC
		DATA_ONE = Transmission().retrieveContent(TARGET, 'POST', data=json.dumps(ENTRIES, indent=2))
		FETCH_UNO = create_entries({'Title': translation(30620), 'Image': f"{artpic}regards.png"})
		addDir({'mode': 'listVarious', 'url': GRAPH_BASE, 'first': 'PLAYLIST_BY_ID', 'last': 'videos', 'extras': 1, 'transmit': 'Empfehlungen'}, FETCH_UNO)
		if DATA_ONE not in ['', None] and DATA_ONE.get('data', '') and DATA_ONE['data'].get('playlistCollection', ''):
			for item in DATA_ONE['data']['playlistCollection'].get('playlists', []):
				CID, DESC = item.get('id', None), None
				debug_MS(f"(navigator.listTopics[1]) xxxxx ITEM-01 : {item} xxxxx")
				NAME = cleaning(item['webName'])
				if item.get('videos', '') and len(item['videos']) > 0:
					START, FINAL = 'PLAYLIST_BY_ID', 'videos'
					if item.get('videos', {})[0].get('images', '') and len(item['videos'][0]['images']) > 0:
						num, resources = item.get('id', ''), item.get('videos', {})[0].get('images', [])
						THUMB = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
						POSTER = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
						if item.get('videos', {})[0].get('genres', '') and item.get('videos', [])[0].get('genres', {})[0].get('seoDescription', ''):
							DESC = item['videos'][0]['genres'][0]['seoDescription']
				elif item.get('series', '') and len(item['series']) > 0:
					START, FINAL = 'GENRE_BY_ID', 'series'
					if item.get('series', {})[0].get('images', '') and len(item['series'][0]['images']) > 0:
						num, resources = item.get('id', ''), item.get('series', {})[0].get('images', [])
						THUMB = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
						POSTER = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
				else: continue
				FOUND += 1
				debug_MS(f"(navigator.listTopics[2]) ### NAME : {NAME} || IDD : {CID} || THUMB : {THUMB} ###")
				debug_MS("++++++++++++++++++++++++")
				FETCH_DUE = create_entries({'Title': NAME, 'Plot': DESC, 'Image': THUMB, 'Poster': POSTER})
				addDir({'mode': 'listTopics', 'url': 'Recomendations', 'first': START, 'last': FINAL, 'extras': CID}, FETCH_DUE)
				SEND['playlists'].append(item)
			preserve(HOME_BASE, 'JSON', SEND)
	elif xbmcvfs.exists(HOME_BASE) and os.stat(HOME_BASE).st_size > 0:
		for item in preserve(HOME_BASE).get('playlists', []):
			if int(item.get('id', 0)) == int(CAT_IDD) and item.get(LAST, ''):
				for elem in item.get(LAST, []):
					debug_MS(f"(navigator.listTopics[3]) xxxxx ELEM-03 : {elem} xxxxx")
					each, folder = create_substances(elem), True
					# [cid=0, crn=1, slug=2, videocount=3, title=4, origserie=5, desc=6, duration=7, season=8, episode=9, aired=10, begins=11, note_1=12]
					# [note_2=13, note_3=14, note_4=15, votes=16, mpaa=17, country=18, year=19, genre=20, thumb=21, poster=22, banner=23, fanart=24]
					if each[1] is not None and each[7] is not None:
						folder, ACTION = False, {'mode': 'playVideo', 'url': each[1]}
					elif each[1] is None and each[7] is None and str(each[0]).isdecimal():
						xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
						START, FINAL, folder = 'SERIE_BY_ID', 'videos', True
						ACTION = {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': START, 'last': FINAL, 'extras': int(each[0]), 'transmit': each[4]}
					FOUND += 1
					PLOT = each[12]+each[13]+each[14]+each[6]
					NAME = f"{each[4]+each[15]}  [COLOR gold][{str(each[3])}][/COLOR]" if each[3] is not None and folder else each[4]+each[15]
					debug_MS(f"(navigator.listTopics[4]) ### ACTION : {ACTION} || NAME : {NAME} ###")
					debug_MS(f"(navigator.listTopics[4]) ### SEASON : {each[8]} || EPISODE : {each[9]} || THUMB : {each[21]} ###")
					debug_MS("++++++++++++++++++++++++")
					FETCH_UNO = create_entries({'Title': NAME, 'TvShowTitle': each[5], 'Plot': PLOT, 'Season': each[8],'Episode': each[9], 'Duration': each[7], 'Date': each[11], \
						'Aired': each[10], 'Year': each[19], 'Genre': each[20], 'Country': each[18], 'Votes': each[16], 'Mpaa': each[17], 'Mediatype': 'episode' if not folder else None, \
						'Image': each[21], 'Poster': each[22], 'Banner': each[23], 'Fanback': each[24], 'Reference': 'Single' if not folder else 'Standard'})
					addDir(ACTION, FETCH_UNO, folder)
	if FOUND == 0:
		failing("(navigator.listTopics) ##### Keine COMBI_TOPICS-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30521).format('TOPICS'), translation(30522), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVarious(TARGET, FIRST, LAST, CAT_IDD, PAGE, SERIE):
	debug_MS("(navigator.listVarious) ------------------------------------------------ START = listVarious -----------------------------------------------")
	debug_MS(f"(navigator.listVarious) ### URL = {TARGET} ### FIRST = {FIRST} ### LAST = {LAST} ### CAT_IDD = {CAT_IDD} ### PAGE = {PAGE} ### SERIE = {SERIE} ###")
	INSTANCE, PLAYLIST, RESULT = 0, False, None
	SKIPPING = int(PAGE)-1 if int(PAGE) > 1 else 0
	NOW_UTC = f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
	UTC_MINUS = f"{(datetime.utcnow() - timedelta(days=5)).isoformat(timespec='milliseconds')}Z" # Neue Videos - Videos beginnend vor 5 Tagen ab heute
	UTC_PLUS = f"{(datetime.utcnow() + timedelta(days=5)).isoformat(timespec='milliseconds')}Z" # Last Chance - Videos enden in den nächsten 5 Tagen
	ENTRIES = json.loads(json.dumps(config[FIRST]))
	HIGHER = True if int(PAGE) > 1 else False
	if enableBACK and PLACEMENT == 0 and HIGHER is True:
		addDir({'mode': 'callingMain'}, create_entries({'Title': translation(30621), 'Image': f"{artpic}backmain.png"}))
	if int(CAT_IDD) == 0 and FIRST in ['BROADCASTS','GENRES']:
		ENTRIES = {**ENTRIES, **{'variables': {'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0}}}
	elif int(CAT_IDD) == 0 and FIRST == 'NEWEST':
		ENTRIES = {**ENTRIES, **{'variables': {'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0, 'now': NOW_UTC, 'dayAfterTomorrow': UTC_MINUS}}}
	elif int(CAT_IDD) == 0 and FIRST == 'LAST_CHANCE':
		ENTRIES = {**ENTRIES, **{'variables': {'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0, 'now': NOW_UTC, 'dayAfterTomorrow': UTC_PLUS}}}
	elif int(CAT_IDD) != 0 and FIRST == 'GENRE_BY_ID':
		ENTRIES = {**ENTRIES, **{'variables': {'id': int(CAT_IDD), 'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0}}}
	else:
		ENTRIES = {**ENTRIES, **{'variables': {'id': int(CAT_IDD), 'take': 40, 'skip': int(SKIPPING)*40 if int(PAGE) > 1 else 0, 'now': NOW_UTC}}}
	DATA_ONE = Transmission().retrieveContent(TARGET, 'POST', data=json.dumps(ENTRIES, indent=2))
	if DATA_ONE not in ['', None] and DATA_ONE.get('data', '') and DATA_ONE['data'].get('playlist', '') and DATA_ONE['data']['playlist'].get(LAST, ''):
		INSTANCE, PLAYLIST = 1, DATA_ONE['data']['playlist'].get(LAST, [])
	elif DATA_ONE not in ['', None] and DATA_ONE['data'].get('genre', '') and DATA_ONE['data']['genre'].get(LAST, ''):
		INSTANCE, PLAYLIST = 2, DATA_ONE['data']['genre'].get(LAST, [])
	elif DATA_ONE not in ['', None] and DATA_ONE['data'].get('serie', '') and DATA_ONE['data']['serie'].get(LAST, ''):
		INSTANCE, PLAYLIST = 3, DATA_ONE['data']['serie'].get(LAST, [])
	elif DATA_ONE not in ['', None] and DATA_ONE.get('data', '') and DATA_ONE['data'].get(LAST, ''):
		INSTANCE, PLAYLIST = 4, DATA_ONE['data'].get(LAST, [])
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listVarious[1]) XXXXX INSTANCE-01 : {INSTANCE} XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	if PLAYLIST:
		for item in PLAYLIST:
			debug_MS(f"(navigator.listVarious[2]) xxxxx ELEM-02 : {item} xxxxx")
			each, folder = create_substances(item), True
			# [cid=0, crn=1, slug=2, videocount=3, title=4, origserie=5, desc=6, duration=7, season=8, episode=9, aired=10, begins=11, note_1=12]
			# [note_2=13, note_3=14, note_4=15, votes=16, mpaa=17, country=18, year=19, genre=20, thumb=21, poster=22, banner=23, fanart=24]
			if each[1] is not None and each[7] is not None:
				folder, ACTION = False, {'mode': 'playVideo', 'url': each[1]}
			elif each[1] is None and each[7] is None and str(each[0]).isdecimal():
				START = 'GENRE_BY_ID' if FIRST == 'GENRES'and int(each[0]) not in [642, 695] else 'GENRE_VIDEOS' if int(each[0]) in [642, 695] else 'SERIE_BY_ID'
				FINAL = 'series' if FIRST == 'GENRES'and int(each[0]) not in [642, 695] else 'videos'
				folder, ACTION = True, {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': START, 'last': FINAL, 'extras': int(each[0]), 'transmit': each[4]}
			PLOT = each[12]+each[13]+each[14]+each[6]
			NAME = f"{each[4]+each[15]}  [COLOR gold][{str(each[3])}][/COLOR]" if each[3] is not None and folder else each[4]+each[15]
			debug_MS(f"(navigator.listVarious[3]) ##### ACTION : {ACTION} || NAME : {NAME} || IDD : {each[0]} || GENRE : {each[20]} #####")
			debug_MS(f"(navigator.listVarious[3]) ##### SERIE : {each[5]} || SEASON : {each[8]} || EPISODE : {each[9]} #####")
			debug_MS(f"(navigator.listVarious[3]) ##### FSK : {each[17]} || THUMB : {each[21]} || POSTER : {each[22]} #####")
			debug_MS("---------------------------------------------")
			if not folder:
				for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
			FETCH_UNO = create_entries({'Title': NAME, 'TvShowTitle': each[5], 'Plot': PLOT, 'Season': each[8],'Episode': each[9], 'Duration': each[7], 'Date': each[11], \
				'Aired': each[10], 'Year': each[19], 'Genre': each[20], 'Country': each[18], 'Votes': each[16], 'Mpaa': each[17], 'Mediatype': 'episode' if not folder else None, \
				'Image': each[21], 'Poster': each[22], 'Banner': each[23], 'Fanback': each[24], 'Reference': 'Single' if not folder else 'Standard'})
			addDir(ACTION, FETCH_UNO, folder, HIGHER)
		NEXTLINK = json.loads(json.dumps(config[FIRST]))
		if int(CAT_IDD) == 0 and FIRST in ['BROADCASTS','GENRES']:
			NEXTLINK = {**NEXTLINK, **{'variables': {'take': 40, 'skip': int(PAGE)*40}}}
		elif int(CAT_IDD) == 0 and FIRST == 'NEWEST':
			NEXTLINK = {**NEXTLINK, **{'variables': {'take': 40, 'skip': int(PAGE)*40, 'now': NOW_UTC, 'dayAfterTomorrow': UTC_MINUS}}}
		elif int(CAT_IDD) == 0 and FIRST == 'LAST_CHANCE':
			NEXTLINK = {**NEXTLINK, **{'variables': {'take': 40, 'skip': int(PAGE)*40, 'now': NOW_UTC, 'dayAfterTomorrow': UTC_PLUS}}}
		elif int(CAT_IDD) != 0 and FIRST == 'GENRE_BY_ID':
			NEXTLINK = {**NEXTLINK, **{'variables': {'id': int(CAT_IDD), 'take': 40, 'skip': int(PAGE)*40}}}
		else:
			NEXTLINK = {**NEXTLINK, **{'variables': {'id': int(CAT_IDD), 'take': 40, 'skip': int(PAGE)*40, 'now': NOW_UTC}}}
		DATA_TWO = Transmission().retrieveContent(TARGET, 'POST', data=json.dumps(NEXTLINK, indent=2))
		debug_MS("++++++++++++++++++++++++")
		debug_MS(f"(navigator.listVarious[4]) XXXXX CONTENT-02 : {DATA_TWO} XXXXX")
		debug_MS("++++++++++++++++++++++++")
		if INSTANCE == 1 and DATA_TWO not in ['', None]: RESULT = DATA_TWO['data']['playlist'].get(LAST, [])
		elif INSTANCE == 2 and DATA_TWO not in ['', None]: RESULT = DATA_TWO['data']['genre'].get(LAST, [])
		elif INSTANCE == 3 and DATA_TWO not in ['', None]: RESULT = DATA_TWO['data']['serie'].get(LAST, [])
		elif INSTANCE == 4 and DATA_TWO not in ['', None]: RESULT = DATA_TWO['data'].get(LAST, [])
		if RESULT is not None and len(RESULT) > 0:
			debug_MS(f"(navigator.listVarious[5]) PAGES ### NOW SHOW NEXTPAGE ENTRY ... No.{int(PAGE)+1} ... ###")
			debug_MS("---------------------------------------------")
			FETCH_DUE = create_entries({'Title': translation(30622).format(int(PAGE)+1), 'Image': f"{artpic}nextpage.png"})
			addDir({'mode': 'listVarious', 'url': GRAPH_BASE, 'first': FIRST, 'last': LAST, 'extras': CAT_IDD, 'page': int(PAGE)+1, 'transmit': each[5] if each[5] is not None else SERIE}, FETCH_DUE)
	else:
		failing("(navigator.listVarious) ##### Keine COMBI_VARIOUS-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524), translation(30525).format(SERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def create_substances(content):
	(note_1, note_2, note_3, note_4, desc), fanart = ("" for _ in range(5)), defaultFanart
	origserie, startTIMES, aired, begins, endTIMES, mpaa, country, year, genre, thumb, poster, banner = (None for _ in range(12))
	cid = content.get('id', None)
	crn = content.get('crn', None)
	slug = content.get('slug', None)
	videocount = content.get('currentScheduledVideoCount', None)
	title = cleaning(content['name']) if content.get('name', None) else cleaning(content['title'])
	if content.get('subtitle', ''):
		origserie = cleaning(content['subtitle'])
		note_1 = translation(30623).format(origserie)
		title = f"{title} - {origserie}"
	desc = cleaning(content['seoDescription']) if content.get('seoDescription', None) else get_Description(content)
	duration = int(content['duration']) // 1000 if str(content.get('duration')).isdecimal() else None
	season = f"{int(content['seasonNumber']):02}" if str(content.get('seasonNumber')).isdecimal() and int(content.get('seasonNumber')) != 0 else None
	episode = f"{int(content['episodeNumber']):02}" if str(content.get('episodeNumber')).isdecimal() and int(content.get('episodeNumber')) != 0 else None
	if episode:
		note_2 = translation(30624).format(season, episode) if season else translation(30625).format(episode)
		if showEPIS:
			note_4 = translation(30626).format(season, episode) if season else translation(30627).format(episode)
	if str(content.get('schedulingStart'))[:4].isdecimal() and str(content.get('schedulingStart'))[:4] not in ['0', '1970']: # 2022-03-04T19:15:18.000Z
		LOCALstart = get_CentralTime(content['schedulingStart'])
		startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
		aired = LOCALstart.strftime('%d.%m.%Y') # FirstAired
		begins = LOCALstart.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else LOCALstart.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
	if str(content.get('schedulingEnd'))[:4].isdecimal() and str(content.get('schedulingEnd'))[:4] not in ['0', '1970']: # 2022-03-11T19:15:18.000Z
		LOCALend = get_CentralTime(content['schedulingEnd'])
		endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
	if startTIMES and endTIMES: note_3 = translation(30628).format(startTIMES, endTIMES)
	elif startTIMES and endTIMES is None: note_3 = translation(30629).format(startTIMES)
	elif note_1 != "" or note_2 != "": note_3 = '[CR]'
	votes = content.get('likeCount', None)
	if str(content.get('fsk')) not in ['None', '0', 'nicht definiert']:
		mpaa = str(content['fsk']).replace('ab 0 Jahre -', '').replace('freigegeben', '').strip()
	if content.get('productionCountry', '') and isinstance(content['productionCountry'], list):
		country = ', '.join(sorted([cou for cou in content['productionCountry']]))
	if content.get('productionYear', '') and str(content['productionYear'].get('from')).isdecimal():
		year = content['productionYear']['from']
	if content.get('genres', '') and isinstance(content['genres'], list):
		genre = ' / '.join(sorted([gen.get('name', '') for gen in content['genres']]))
	if content.get('images', '') and isinstance(content['images'], list):
		num, resources = content.get('id', ''), content.get('images', [])
		thumb = (get_Picture(num, resources, 'thumbnail') or get_Picture(num, resources, 'basic'))
		poster = (get_Picture(num, resources, 'poster') or get_Picture(num, resources, 'thumbnail'))
		banner = get_Picture(num, resources, 'cover')
		fanart = (get_Picture(num, resources, 'basic') or get_Picture(num, resources, 'thumbnail') or defaultFanart)
	elif content.get('image', '') and len(content['image']) > 0:
		if content['image'].get('category') in ['thumbnail', 'basic'] and content['image'].get('url'):
			thumb = content['image']['url']
	return [cid, crn, slug, videocount, title, origserie, desc, duration, season, episode, aired, begins, note_1, note_2, note_3, note_4, votes, mpaa, country, year, genre, thumb, poster, banner, fanart]

def SearchBIBELTV():
	debug_MS("(navigator.SearchBIBELTV) ------------------------------------------------ START = SearchBIBELTV -----------------------------------------------")
	keyword = preserve(SEARCH_FILE, 'TEXT') if xbmcvfs.exists(SEARCH_FILE) else None
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(translation(30630), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword:
		return listSearches(keyword, 'SEARCH_QUERY')
	return None

def listSearches(TARGET, FIRST):
	debug_MS("(navigator.listSearches) ------------------------------------------------ START = listSearches -----------------------------------------------")
	debug_MS(f"(navigator.listSearches) ### KEYWORD = {TARGET} ### FIRST = {FIRST} ###")
	NOW_UTC = f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
	ENTRIES = json.loads(json.dumps(config[FIRST]))
	ENTRIES['query'],ENTRIES['filters']['any'][0]['all'][2]['scheduling_start']['to'] = TARGET, NOW_UTC
	ENTRIES['filters']['any'][0]['all'][3]['scheduling_end']['from'], ENTRIES['filters']['any'][1]['all'][2]['scheduling_end']['from'] = NOW_UTC, NOW_UTC
	FOUND, DATA_ONE = 0, Transmission().retrieveContent(config['ENGINES'], 'POST', PRO='QUERIES', forcing=False, data=json.dumps(ENTRIES, indent=2))
	if DATA_ONE not in ['', None] and DATA_ONE.get('results', '') and len(DATA_ONE['results']) > 0:
		for item in DATA_ONE.get('results', []):
			folder, (NOTE_1, NOTE_2, NOTE_3, NOTE_4, DESC) = True, ("" for _ in range(5))
			ORIGSERIE, startTIMES, BEGINS, AIRED, endTIMES, MPAA, COUNTRY, GENRE = (None for _ in range(8))
			if item.get('page_category', '') and item['page_category'].get('raw', '') and item['page_category']['raw'] != 'mediathek': # Alles was nicht Mediathek ist herausfiltern
				continue
			debug_MS(f"(navigator.listSearches[1]) xxxxx ITEM-01 : {item} xxxxx")
			CID = item['origin_id']['raw'] if item.get('origin_id', '') and item['origin_id'].get('raw', '') else None
			CRN = item['crn']['raw'] if item.get('crn', '') and item['crn'].get('raw', '') else None
			SLUG = item['slug']['raw'] if item.get('slug', '') and item['slug'].get('raw', '') else None
			TYPE = item['type']['raw'] if item.get('type', '') and item['type'].get('raw', '') else 'unknown'
			TITLE = cleaning(item['title']['raw'])
			if item.get('subtitle', '') and item['subtitle'].get('raw', ''):
				ORIGSERIE = cleaning(item['subtitle']['raw'])
				NOTE_1 = translation(30623).format(ORIGSERIE)
				TITLE = f"{TITLE} - {ORIGSERIE}"
			DESC = cleaning(item['description']['raw']) if item.get('description', '') and item['description'].get('raw', '') and len(item['description']['raw']) > 10 else ""
			DURATION = int(item['duration']['raw']) // 1000 if item.get('duration', '') and item['duration'].get('raw', '') and item['duration']['raw'].is_integer() else None
			SEASON = f"{int(item['season_number']['raw']):02}" if item.get('season_number', '') and item['season_number'].get('raw', '') and item['season_number']['raw'].is_integer() and int(item['season_number']['raw']) != 0 else None
			EPISODE = f"{int(item['episode_number']['raw']):02}" if item.get('episode_number', '') and item['episode_number'].get('raw', '') and item['episode_number']['raw'].is_integer() and int(item['episode_number']['raw']) != 0 else None
			if str(EPISODE).isdecimal() and str(EPISODE) != '0':
				NOTE_2 = translation(30624).format(SEASON, EPISODE) if SEASON else translation(30625).format(EPISODE)
				if showEPIS:
					NOTE_4 = translation(30626).format(SEASON, EPISODE) if SEASON else translation(30627).format(EPISODE)
			if item.get('scheduling_start', '') and str(item['scheduling_start'].get('raw'))[:4].isdecimal() and str(item['scheduling_start']['raw'])[:4] not in ['0', '1970']: # 2022-03-04T19:15:18.000Z
				LOCALstart = get_CentralTime(item['scheduling_start']['raw'])
				startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				BEGINS = LOCALstart.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else LOCALstart.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
				AIRED = LOCALstart.strftime('%d.%m.%Y') # FirstAired
			if item.get('scheduling_end', '') and str(item['scheduling_end'].get('raw'))[:4].isdecimal() and str(item['scheduling_end']['raw'])[:4] not in ['0', '1970']: # 2022-03-04T19:15:18.000Z
				LOCALend = get_CentralTime(item['scheduling_end']['raw'])
				endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			if startTIMES and endTIMES: NOTE_3 = translation(30628).format(startTIMES, endTIMES)
			elif startTIMES and endTIMES is None: NOTE_3 = translation(30629).format(startTIMES)
			elif NOTE_1 != "" or NOTE_2 != "": NOTE_3 = '[CR]'
			VOTES = int(item['like_count']['raw']) if item.get('like_count', '') and item['like_count'].get('raw', '') and item['like_count']['raw'].is_integer() and int(item['like_count']['raw']) != 0 else None
			if item.get('fsk', '') and str(item['fsk'].get('raw')) not in ['None', '0', 'nicht definiert']:
				MPAA = str(item['fsk']['raw']).replace('ab 0 Jahre -', '').replace('freigegeben', '').strip()
			if item.get('production_country', '') and item['production_country'].get('raw', '') and isinstance(item['production_country']['raw'], list):
				COUNTRY = ', '.join(sorted([cou for cou in item['production_country']['raw']]))
			YEAR = int(item['production_year']['raw']) if item.get('production_year', '') and item['production_year'].get('raw', '') and item['production_year']['raw'].is_integer() and int(item['production_year']['raw']) != 0 else None
			if item.get('genres', '') and item['genres'].get('raw', '') and isinstance(item['genres']['raw'], list):
				GENRE = ' / '.join(sorted([gen for gen in item['genres']['raw']]))
			THUMB = item['images']['raw'][0] if item.get('images', '') and item['images'].get('raw', '') and len(item['images']['raw']) > 0 else None
			if TYPE.lower() == 'video' and CRN is not None and DURATION is not None:
				folder, ACTION = False, {'mode': 'playVideo', 'url': CRN}
			elif TYPE.lower() == 'page' and DURATION is None and str(CID).isdecimal():
				START, FINAL, folder = 'SERIE_BY_ID', 'videos', True
				ACTION = {'mode': 'listVarious', 'url': GRAPH_BASE, 'first': START, 'last': FINAL, 'extras': int(CID), 'transmit': TITLE}
			FOUND += 1
			NAME, PLOT = TITLE if folder else TITLE+NOTE_4, NOTE_1+NOTE_2+NOTE_3+DESC
			debug_MS(f"(navigator.listSearches[2]) ### ACTION : {ACTION} || NAME : {NAME} || TYPE : {TYPE.title()} #####")
			debug_MS(f"(navigator.listSearches[2]) ##### SERIE : {ORIGSERIE} || GENRE : {GENRE} || SEASON : {SEASON} || EPISODE : {EPISODE} #####")
			debug_MS(f"(navigator.listSearches[2]) ##### AIRED : {AIRED} || DURATION : {DURATION} || THUMB : {THUMB} #####")
			debug_MS("++++++++++++++++++++++++")
			FETCH_UNO = create_entries({'Title': NAME, 'TvShowTitle': ORIGSERIE, 'Plot': PLOT, 'Season': SEASON,'Episode': EPISODE, \
				'Duration': DURATION, 'Date': BEGINS, 'Aired': AIRED, 'Year': YEAR, 'Genre': GENRE, 'Country': COUNTRY, 'Votes': VOTES, 'Mpaa': MPAA,
				'Mediatype': 'episode' if not folder else None, 'Image': THUMB, 'Fanback': THUMB, 'Reference': 'Single' if not folder else 'Standard'})
			addDir(ACTION, FETCH_UNO, folder)
	if FOUND == 0:
		failing("(navigator.listSearches) ##### Keine COMBI_SEARCH-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30524), translation(30525).format(TARGET), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listChurches():
	debug_MS("(navigator.listChurches) ------------------------------------------------ START = listChurches -----------------------------------------------")
	UNIKAT, FOUND, DATA_ONE = set(), 0, Transmission().retrieveContent(config['SERVICES'], PRO='CHURCH', forcing=False)
	if DATA_ONE not in ['', None] and len(DATA_ONE) > 0:
		for item in DATA_ONE:
			(startTIMES, endTIMES), (NOTE_1, NOTE_2, NOTE_3, DESC) = (None for _ in range(2)), ("" for _ in range(4))
			debug_MS(f"(navigator.listChurches[1]) xxxxx ITEM-01 : {item} xxxxx")
			PID = item.get('id', '00')
			if item.get('start_timestamp', '') and str(item['start_timestamp']).isdecimal():
				LOCALstart = get_CentralTime(datetime(1970,1,1) + timedelta(seconds=item['start_timestamp']), 'EPOCHTIME')
				startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			if item.get('stop_timestamp', '') and str(item['stop_timestamp']).isdecimal():
				LOCALend = get_CentralTime(datetime(1970,1,1) + timedelta(seconds=item['stop_timestamp']), 'EPOCHTIME')
				endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
			if startTIMES and endTIMES: NOTE_1 = translation(30628).format(startTIMES, endTIMES)
			elif startTIMES and endTIMES is None: NOTE_1 = translation(30629).format(startTIMES)
			if item.get('prediger', ''): NOTE_2 = translation(30631).format(cleaning(item['prediger']))
			TITLE = cleaning(item['name'])
			TESTING = f"{startTIMES} ~ {endTIMES} ~ {TITLE}" if startTIMES and endTIMES else None
			if TESTING and TESTING in UNIKAT:
				continue
			UNIKAT.add(TESTING)
			THUMB, POSTER = item.get('thumbnail_url', None), item.get('vertical_img_url', None)
			FANART = item.get('thumbnail_url', defaultFanart)
			DESC = cleaning(item['description']) if item.get('description', '') and len(item['description']) > 10 else ""
			CONNECT, STATE = item.get('is_connected', False), item.get('scheduling_state', 'today')
			if (CONNECT is True or STATE == 'running') and item.get('stream', '') and item['stream'].get('viewing_url', ''):
				NOTE_3 = f"[CR][CR]{translation(30632)}" if DESC != "" else f"[CR]{translation(30632)}" if NOTE_2 != "" else translation(30632)
				PLOT = NOTE_1+NOTE_2+DESC+NOTE_3
				ACTION = {'mode': 'playVideo', 'url': item['stream']['viewing_url'], 'transmit': f"LIVE_PLAY@@{TITLE}@@{PID}@@{THUMB}@@{PLOT}@@"}
			else:
				NOTE_3 = f"[CR][CR]{translation(30633)}" if DESC != "" else f"[CR]{translation(30633)}" if NOTE_2 != "" else translation(30633)
				PLOT = NOTE_1+NOTE_2+DESC+NOTE_3
				ACTION = {'mode': 'blankFUNC', 'url': PID}
			if startTIMES and endTIMES:
				FOUND += 1
				debug_MS(f"(navigator.listChurches[2]) ##### NAME : {TITLE} || IDD : {PID} || STREAM : {ACTION.get('url')} #####")
				debug_MS(f"(navigator.listChurches[2]) ##### STATUS : {STATE} || startTIMES : {startTIMES} || THUMB : {THUMB} #####")
				debug_MS("++++++++++++++++++++++++")
				FETCH_UNO = create_entries({'Title': TITLE, 'Plot': PLOT, 'Image': THUMB, 'Poster': POSTER, 'Fanback': FANART, 'Mediatype': 'episode'})
				addDir(ACTION, FETCH_UNO, folder=False)
	if FOUND == 0:
		failing("(navigator.listChurches) ##### Keine COMBI_CHURCHES-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30521).format('LIVE-GOD'), translation(30527), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listChannels():
	debug_MS("(navigator.listChannels) ------------------------------------------------ START = listChannels -----------------------------------------------")
	CHANNELS = [{'sub': translation(30641),'kid': 13, 'm3u': config['BIBELTV']},{'sub': translation(30642),'kid': 14, 'm3u': config['IMPULS']},{'sub': translation(30643),'kid': 15, 'm3u': config['ECHTTV']}]
	COMBI_FIRST, FOUND, NOW_UTC = [], 0, f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
	for CHAN in CHANNELS:
		DATA_ONE = Transmission().retrieveContent(config['PROGRAMS'].format(NOW_UTC, CHAN['kid']), PRO='PREVIEW', forcing=False)
		if DATA_ONE not in ['', None] and DATA_ONE.get('items', '') and len(DATA_ONE['items']) > 0:
			for item in DATA_ONE.get('items', []):
				startTIMES, THUMB, PLOT = (None for _ in range(3))
				debug_MS(f"(navigator.listChannels[1]) xxxxx ITEM-01 : {item} xxxxx")
				PID = item.get('sender_ID', '00')
				if item.get('start', '') and str(item['start'])[:4].isdigit():
					LOCALstart = get_CentralTime(item['start'])
					startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				TITLE = cleaning(item['termin_titel'])
				TITLE = f"{TITLE} - {cleaning(item['titel_zusatz'])}" if item.get('titel_zusatz', '') else TITLE
				SEASON = str(item['staffel']).zfill(2) if item.get('staffel', '') else None
				EPISODE = str(item['folgennummer']).zfill(2) if item.get('folgennummer', '') else None
				if item.get('bilder', '') and item.get('bilder', {})[0].get('url', ''):
					THUMB = item['bilder'][0]['url'].replace('https:', 'http:')
				if item.get('text', '') and item['text'].get('inhalt', '') and len(item['text']['inhalt']) > 10:
					PLOT = f"[CR][CR]{cleaning(item['text']['inhalt'])[:300]}..." if len(item['text']['inhalt']) > 300 else f"[CR][CR]{cleaning(item['text']['inhalt'])}"
				if PLOT is None: PLOT = translation(32101) if int(PID) == 13 else translation(32102) if int(PID) == 14 else translation(32103)
				if startTIMES and EPISODE:
					debug_MS(f"(navigator.listChannels[2]) ##### NAME : {TITLE} || IDD : {PID} || THUMB : {THUMB} #####")
					debug_MS("++++++++++++++++++++++++")
					FOUND += 1
					COMBI_FIRST.append([CHAN['kid'], PID, startTIMES, TITLE, EPISODE, PLOT, THUMB])
				else: debug_MS("~~~~~~~~~~~~~~~~~~~~~~~~ THIS SHOW HAS NO STARTTIMES AND NO EPISODE - REMOVED ~~~~~~~~~~~~~~~~~~~~~~~~")
			STORIES = '[CR][CR]'.join([translation(30644).format(str(ax[2]), ax[3], str(ax[4]), ax[5]) for ax in COMBI_FIRST if int(ax[1]) == int(CHAN['kid'])])
			PICTURE = [px[6] for px in COMBI_FIRST if int(px[1]) == int(CHAN['kid'])][0]
			FETCH_UNO = create_entries({'Title': CHAN['sub'], 'Plot': STORIES, 'Image': PICTURE, 'Poster': PICTURE, 'Mediatype': 'episode'})
			addDir({'mode': 'playVideo', 'url': CHAN['m3u'], 'transmit': f"LIVE_PLAY@@{CHAN['sub']}@@{CHAN['kid']}@@{PICTURE}@@Start: {STORIES.split('Start: ')[1].split('Start: ')[0]}@@"}, FETCH_UNO, folder=False)
	for LABEL, PATH, STORY, IMG in [(30645, {'mode': 'playVideo', 'url': config['HOPETV'], 'transmit': f"LIVE_PLAY@@{translation(30645)}@@16@@{artpic}hope.png@@{translation(32105)}@@"}, 32105, f"{artpic}hope.png"),
		(30646, {'mode': 'playVideo', 'url': config['EWTNTV'], 'transmit': f"LIVE_PLAY@@{translation(30646)}@@17@@{artpic}ewtn.png@@{translation(32106)}@@"}, 32106, f"{artpic}ewtn.png"),
		(30647, {'mode': 'playVideo', 'url': config['KATOTV'], 'transmit': f"LIVE_PLAY@@{translation(30647)}@@18@@{artpic}ktv.png@@{translation(32107)}@@"}, 32107, f"{artpic}ktv.png")]:
		addDir(PATH, create_entries({'Title': translation(LABEL), 'Plot': translation(STORY), 'Image': IMG}), folder=False)
	if FOUND == 0:
		failing("(navigator.listChannels) ##### Keine COMBI_CHANNELS-List - Kein Eintrag gefunden #####")
		dialog.notification(translation(30521).format('LIVE-TV'), translation(30527), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def playVideo(PLID, RIDERS):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	MEDIAS, (CHIAVE, DRM_GUARD, DRM_SPECIES), (OTHER, STREAM, FINAL_URL) = [], (None for _ in range(3)), (False for _ in range(3))
	if RIDERS.startswith('LIVE_PLAY'):
		SECTION = RIDERS.split('@@')
		debug_MS(f"(navigator.playVideo[1]) ### PLID : {PLID} ### NAME : {SECTION[1]} ### THUMB : {SECTION[3]} ###")
		NAME, IMAGE = re.sub(r'\[/?B\]', '', SECTION[1]), SECTION[3]
		STREAM, MIME, FINAL_URL = 'HLS', 'application/vnd.apple.mpegurl', PLID
		DESC = SECTION[4] if len(SECTION[4]) > 8 else ' '
	else:
		NOW_UTC = f"{datetime.utcnow().isoformat(timespec='milliseconds')}Z"
		ENTRIES = json.loads(json.dumps(config['VIDEOS']))
		ENTRIES = {**ENTRIES, **{'variables': {'crn': PLID, 'now': NOW_UTC, 'targetTechnology': 'mobile_app_android'}}}
		DATA_ONE = Transmission().retrieveContent(GRAPH_BASE, 'POST', data=json.dumps(ENTRIES, indent=2))
		debug_MS("++++++++++++++++++++++++")
		debug_MS(f"(navigator.playVideo[1]) XXXXX CONTENT-01 : {DATA_ONE} XXXXX")
		debug_MS("++++++++++++++++++++++++")
		if DATA_ONE not in ['', None] and DATA_ONE.get('data', '') and DATA_ONE['data'].get('videos', '') and len(DATA_ONE['data']['videos']) > 0:
			for elem in DATA_ONE['data']['videos']:
				for each in elem.get('editions', {})[0].get('videoUrls', []):
					FORMAT, SOURCE = each.get('type', None), each.get('src', None)
					if 'fairplay/' in SOURCE: continue # Apple-Fairplay aussortieren - nicht kompatibel
					KEY_URL = each['keySystem']['widevine']['url'] if FORMAT == 'application/dash+xml' and each.get('keySystem', '') and \
						each['keySystem'].get('widevine', '') and each['keySystem']['widevine'].get('url', '') else None
					if FORMAT == 'application/dash+xml' and '.mpd' in SOURCE:
						VIDEO, TYPE, CHIAVE = SOURCE, FORMAT, KEY_URL
					if FORMAT in['application/vnd.apple.mpegurl', 'application/x-mpegURL'] and '.m3u8' in SOURCE and 'aes128/' in SOURCE:
						OTHER, VIDEO, TYPE, CHIAVE = True, SOURCE, FORMAT, None
					if FORMAT == 'video/mp4' and '.mp4' in SOURCE:
						VIDEO, TYPE, CHIAVE = SOURCE, FORMAT, None
					MEDIAS.append({'video': VIDEO, 'mime': TYPE, 'keyUrl': CHIAVE})
			debug_MS(f"(navigator.playVideo[2]) ORIGINAL_SOURCES ### MEDIAS_LIST : {MEDIAS} ###")
		if not FINAL_URL and MEDIAS:
			for item_uno in MEDIAS:
				if (prefSTREAM == 0 or OTHER is False) and item_uno['mime'] == 'application/dash+xml' and item_uno['video'] is not None:
					log("(navigator.playVideo[3]) ***** TAKE - Inputstream (mpd) - FILE *****")
					STREAM, MIME, FINAL_URL, DRM_GUARD = 'MPD', item_uno['mime'], item_uno['video'], item_uno['keyUrl']
		if not FINAL_URL and MEDIAS:
			for item_due in MEDIAS:
				if '.m3u8' in item_due['video'] and item_due['mime'] in ['application/vnd.apple.mpegurl', 'application/x-mpegURL']:
					STREAM = 'M3U8' if prefSTREAM == 2 else 'HLS'
					MIME, FINAL_URL = item_due['mime'], item_due['video']
					log(f"(navigator.playVideo[3]) ***** TAKE - Standard/Inputstream ({STREAM.lower()}) - FILE *****")
		if not FINAL_URL and MEDIAS:
			for item_tre in MEDIAS:
				if '.mp4' in item_tre['video'] and item_tre['mime'] == 'video/mp4':
					STREAM, MIME, FINAL_URL = 'MP4', item_tre['mime'], item_tre['video']
					log("(navigator.playVideo[3]) ***** TAKE - mp4 (last Chance) -  FILE *****")
	if FINAL_URL and STREAM:
		if RIDERS.startswith('LIVE_PLAY'):
			LPM = xbmcgui.ListItem(NAME, path=FINAL_URL, offscreen=True)
			if KODI_ov20:
				LPM.getVideoInfoTag().setTitle(NAME), LPM.getVideoInfoTag().setPlot(DESC)
			else: LPM.setInfo('Video', {'Title' : NAME, 'Plot' : DESC})
			LPM.setArt({'icon': icon, 'thumb': IMAGE, 'poster': IMAGE, 'fanart': defaultFanart})
		else:
			LPM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		if plugin_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD']:
			IA_NAME, IA_SYSTEM = 'inputstream.adaptive', 'com.widevine.alpha'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			DRM_HEADERS = {'User-Agent': agent_WEB, 'Content-Type': 'application/octet-stream'}
			LPM.setMimeType(MIME), LPM.setContentLookup(False), LPM.setProperty('inputstream', IA_NAME)
			if KODI_un21:
				LPM.setProperty(f"{IA_NAME}.manifest_type", STREAM.lower()) # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			if KODI_ov20:
				LPM.setProperty(f"{IA_NAME}.manifest_headers", f"User-Agent={agent_WEB}") # On KODI v20 and above
			else: LPM.setProperty(f"{IA_NAME}.stream_headers", f"User-Agent={agent_WEB}") # On KODI v19 and below
			if int(IA_VERSION) >= 2150 and STREAM in ['HLS', 'MPD']:
				DRM_SPECIES = {'DRM_System': 'org.w3.clearkey'} if STREAM == 'HLS' else {'DRM_System': IA_SYSTEM}
				if STREAM == 'MPD' and DRM_GUARD:
					DRM_SPECIES = {'DRM_System': IA_SYSTEM, 'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS)}
				LPM.setProperty(f"{IA_NAME}.drm_legacy", '|'.join(DRM_SPECIES.values())) # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
			elif int(IA_VERSION) < 2150 and STREAM == 'MPD':
				LPM.setProperty(f"{IA_NAME}.license_type", IA_SYSTEM)
				if DRM_GUARD:
					DRM_SPECIES = {'License_Link': DRM_GUARD, 'License_Headers': urlencode(DRM_HEADERS), 'Post_Data': 'R{SSM}|'}
					LPM.setProperty(f"{IA_NAME}.license_key", '|'.join(DRM_SPECIES.values())) # Below v.21.5.0 / Kodi 19+20 - OLD method to configure a single DRM
			if DRM_SPECIES: log(f"(navigator.playVideo[4]) INPUTSTREAM_VERSION: {IA_VERSION} >>>>> LICENSE : {'|'.join(DRM_SPECIES.values())} <<<<<")
		if RIDERS.startswith('LIVE_PLAY'):
			xbmc.Player().play(item=FINAL_URL, listitem=LPM)
		else:
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		log(f"(navigator.playVideo) {STREAM}_stream : {FINAL_URL}|User-Agent={agent_WEB}")
	else:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich ##### PLID : {PLID} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *bibeltv.de* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('STREAM'), translation(30526), icon, 10000)

def addDir(params, listitem, folder=True, higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enableBACK and PLACEMENT == 1 and higher is True:
		entries.append([translation(30650), f"RunPlugin({build_mass({'mode': 'callingMain'})})"])
	if params.get('mode') == 'playVideo':
		entries.append([translation(30654), 'Action(Queue)'])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
