﻿# -*- coding: utf-8 -*-

from .common import *
from .utilities import clientHelper


def mainMenu():
	for title, img, action in [(30601, 'deepsearch', {'mode': 'searchingDeezer'}), (30602, 'apple', {'mode': 'appleMain'}),
		(30603, 'beatport', {'mode': 'beatportMain'}), (30604, 'billboard', {'mode': 'billboardMain'}), (30605, 'ddp_home', {'mode': 'ddpMain'}),
		(30606, 'hypem', {'mode': 'hypemMain'}), (30607, 'official', {'mode': 'occMain'})]:
		add_views(action, create_entries({'Title': translation(title), 'Image': f"{artpic}{img}.gif" if img == 'deepsearch' else f"{artpic}{img}.png"}))
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30608), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def searchingDeezer():
	keyword, received = None, False
	keyword = dialog.input(translation(30621), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
	if keyword: keyword = quote_plus(keyword, safe='')
	else: return
	for item in [{'conv': 'strukturARTIST', 'name': 30622, 'turn': 'listDeezerSelection', 'slug': 'artist'},
		{'conv': 'strukturTRACK', 'name': 30623, 'turn': 'listDeezerVideos', 'slug': 'track'}, {'conv': 'strukturALBUM', 'name': 30624, 'turn': 'listDeezerSelection', 'slug': 'album'},
		{'conv': 'strukturPLAYLIST', 'name': 30625, 'turn': 'listDeezerSelection', 'slug': 'playlist'}, {'conv': 'strukturUSERLIST', 'name': 30626, 'turn': 'listDeezerSelection', 'slug': 'user'}]:
		item['conv'] = clientHelper().track_content(f"{BASE_URL_DZ}/{item['slug']}?q={keyword}&limit={deezer_folders}&strict=on&output=json&index=0", service='DEEZER')
		if item['slug'] == 'track' and item['conv']['total'] != 0:
			add_views({'mode': item['turn'], 'link': keyword, 'extra': item['slug'], 'transmit': icon}, create_entries({'Title': translation(item['name']), 'Image': f"{artpic}{item['slug']}.png"}), automatic=True)
			received = True
		elif item['slug'] in ['artist', 'album', 'playlist', 'user'] and item['conv']['total'] != 0:
			add_views({'mode': item['turn'], 'link': keyword, 'extra': item['slug']}, create_entries({'Title': translation(item['name']), 'Image': f"{artpic}{item['slug']}.png"}))
			received = True
	if not received:
		add_views({'mode': 'rootMain', 'link': keyword}, create_entries({'Title': translation(30627), 'Image': f"{artpic}noresults.png"}))
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listDeezerSelection(target, extra):
	musicondo, unikat = [], set()
	if target.startswith(BASE_URL_DZ):
		package = clientHelper().track_content(quote_plus(target, safe='/:?=&'), service='DEEZER')
	else:
		package = clientHelper().track_content(f"{BASE_URL_DZ}/{extra}?q={quote_plus(target)}&limit={deezer_folders}&strict=on&output=json&index=0", service='DEEZER')
	for item in package.get('data', []):
		artist = cleaning(item['artist']['name']) if extra == 'album' else cleaning(item['name']) if extra == 'artist' else title_case(cleaning(item['title'])) if extra == 'playlist' else None
		album = cleaning(item['title']) if extra == 'album' else None
		user = title_case(cleaning(item['user']['name'])) if extra == 'playlist' else title_case(cleaning(item['name'])) if extra == 'user' else None
		numbers = str(item['nb_tracks']) if extra in ['album', 'playlist'] else str(item['nb_fan']) if extra == 'artist' else None
		version = cleaning(item['record_type']).title() if extra == 'album' else None
		try:
			thumb = item['picture_big'] if extra in ['artist', 'playlist', 'user'] else item['cover_big']
			if extra in ['artist', 'user'] and thumb.endswith(extra+'//500x500-000000-80-0-0.jpg'):
				thumb = f"{artpic}noavatar.gif"
		except:
			thumb = f"{artpic}noavatar.gif" if extra in ['artist', 'user'] else f"{artpic}noimage.png"
		if item.get('tracklist', '') and item['tracklist'].startswith('https://api.deezer.com/'):
			tracks_link = f"{item['tracklist'].split('top?limit=')[0]}top?limit={deezer_videos}&index=0" if extra == 'artist' else f"{item['tracklist']}?limit={deezer_videos}&index=0"
		else: tracks_link = None
		special = f"{artist} - {album}" if extra == 'album' else artist.strip().lower() if extra == 'artist' else f"{artist} - {user}" if extra == 'playlist' else user
		if tracks_link is None or special in unikat:
			continue
		unikat.add(special)
		musicondo.append([numbers, artist, album, user, version, tracks_link, special, thumb])
	musicondo = sorted(musicondo, key=lambda mv: int(mv[0]), reverse=True) if extra == 'artist' else musicondo
	for numbers, artist, album, user, version, tracks_link, special, thumb in musicondo:
		if extra == 'artist':
			name = translation(30628).format(artist, numbers) if show_details else artist
			plot = f"Artist: [B]{artist}[/B][CR]Fans: [B][COLOR chartreuse]{numbers}[/COLOR][/B]"
		elif extra == 'album':
			name = translation(30629).format(special, version, numbers) if show_details else special
			plot = f"Artist: [B]{artist}[/B][CR]Album: [B][COLOR FFFFA500]{album}[/COLOR][/B][CR]Version: [B][COLOR deepskyblue]{version}[/COLOR][/B][CR]Tracks: [B][COLOR yellow]{numbers}[/COLOR][/B]"
		elif extra == 'playlist':
			name = translation(30630).format(artist, user, numbers) if show_details else artist
			plot = f"Artist: [B]{artist}[/B][CR]User: [B][COLOR chartreuse]{user}[/COLOR][/B][CR]Tracks: [B][COLOR yellow]{numbers}[/COLOR][/B]"
		elif extra == 'user':
			name = user
			plot = f"User: [B][COLOR chartreuse]{user}[/COLOR][/B]"
		add_views({'mode': 'listDeezerVideos', 'link': tracks_link, 'extra': extra, 'photo': thumb}, create_entries({'Title': name, 'Image': thumb, 'Plot': plot}), automatic=True)
	if musicondo and package.get('next', '') and package['next'].startswith(BASE_URL_DZ):
		add_views({'mode': 'listDeezerSelection', 'link': package['next'], 'extra': extra}, create_entries({'Title': translation(30802), 'Image': f"{artpic}nextpage.png"}))
	xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_playlists})")

def listDeezerVideos(target, phase, limit, number, extra, photo):
	musicondo, unikat, number = [], set(), int(number)
	PLT = clear_playlist() if phase == 'playing' else None
	if extra == 'track' and not 'index=' in target:
		package = clientHelper().track_content(f"{BASE_URL_DZ}/{extra}?q={quote_plus(target)}&limit={deezer_videos}&strict=on&output=json&index=0", service='DEEZER')
	else:
		package = clientHelper().track_content(quote_plus(target, safe='/:?=&'), service='DEEZER')
	for item in package.get('data', []):
		artist = cleaning(item['artist']['name'])
		song = cleaning(item['title'])
		if song.isupper() or song.islower():
			song = title_case(song)
		plot = f"Artist: [B]{artist}[/B][CR]Song: [B]{song}[/B]"
		firstTitle = f"{artist} - {song}"
		if firstTitle in unikat or artist == "":
			continue
		unikat.add(firstTitle)
		album = cleaning(item['album']['title']) if extra == 'track' and item.get('album', '') and item['album'].get('title', '') else ""
		if album != "": plot += f"[CR]Album: [B][COLOR FFFFA500]{album}[/COLOR][/B]"
		if extra == 'track':
			photo = item['album']['cover_big'] if item.get('album', '') and item['album'].get('cover_big', '') else f"{artpic}noimage.png"
		for snippet in BLACK_LISTING:
			if len(snippet.strip()) > 2 and snippet.strip().lower() in firstTitle.lower():
				continue
		musicondo.append([firstTitle, album, photo, plot])
	if phase == 'browse':
		for firstTitle, album, photo, plot in musicondo:
			number += 1
			name = translation(30631).format(firstTitle, album) if extra == 'track' and show_details else translation(30801).format(number, firstTitle)
			add_views({'mode': 'playTITLE', 'link': customise(firstTitle)}, create_entries({'Title': name, 'Image': photo, 'Plot': plot, 'Mediatype': 'musicvideo', 'Reference': 'Single'}), False)
		if musicondo and package.get('next', '') and package['next'].startswith('https://api.deezer.com/'):
			add_views({'mode': 'listDeezerVideos', 'link': package['next'], 'number': number, 'extra': extra, 'photo': photo}, create_entries({'Title': translation(30802), 'Image': f"{artpic}nextpage.png"}), automatic=True)
		xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if force_viewing:
			xbmc.executebuiltin(f"Container.SetViewMode({viewer_videos})")
	else:
		musicondo = musicondo[:int(limit)] if int(limit) > 0 else musicondo
		random.shuffle(musicondo)
		for firstTitle, album, photo, plot in musicondo:
			action = build_mass({'mode': 'playTITLE', 'link': customise(firstTitle)})
			fetching = create_entries({'Title': firstTitle, 'Image': photo, 'Mediatype': 'musicvideo', 'Reference': 'Single'})
			PLT.add(action, fetching)
		xbmc.Player().play(PLT)

def appleMain(): # https://amp-api-music.apple.com/v1/editorial/us/groupings?genre=34&l=en-US&platform=web
	# https://amp-api-music.apple.com/v1/editorial/us/rooms/6456176470/contents?l=en-US&platform=web
	for item in [{'name': 30641, 'turn': 'listAppleGroups', 'slug': '/groupings?genre=34'},{'name': 30642, 'turn': 'listAppleCharts', 'slug': '/new/top-charts'},
		{'name': 30643, 'turn': 'listAppleRooms', 'slug': '/rooms/6456176473'},{'name': 30644, 'turn': 'listAppleRooms', 'slug': '/rooms/6456176472'},
		{'name': 30645, 'turn': 'listAppleRooms', 'slug': '/rooms/6456176470'},{'name': 30646, 'turn': 'listAppleRooms', 'slug': '/rooms/6456176471'}]:
		follow = f"{BASE_URL_MA}/editorial/{appleRegion}{item['slug']}/contents?l={appleLocale}&platform=web&limit=150" if item['turn'] == 'listAppleRooms' else \
			f"{BASE_URL_MA}/editorial/{appleRegion}{item['slug']}&l={appleLocale}&platform=web&limit=100"
		add_views({'mode': item['turn'], 'link': follow}, create_entries({'Title': translation(item['name']), 'Image': f"{artpic}apple.png"}))
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_genres})")

def listAppleCharts(): # https://amp-api.music.apple.com/v1/catalog/us/charts?genre=34&chartId=135&limit=150&l=en-US&platform=web
	# https://amp-api.music.apple.com/v1/catalog/us/charts?genre=34&chart=most-played&types=playlists&limit=100&l=en-US&platform=web
	for item in [{'name': 30647, 'turn': 'listAppleRooms', 'slug': 'chartId=135&limit=150', 'plate': 'cityCharts'},
		{'name': 30648, 'turn': 'listAppleRooms', 'slug': 'chartId=119&limit=150', 'plate': 'dailyGlobalTopCharts'},
		{'name': 30649, 'turn': 'listAppleRooms', 'slug': 'chart=most-played&types=playlists&limit=200', 'plate': 'playlists'},
		{'name': 30650, 'turn': 'listAppleVideos', 'slug': 'chart=most-played&types=songs&limit=100', 'plate': 'songs'},
		{'name': 30651, 'turn': 'listAppleVideos', 'slug': 'chart=most-played&types=music-videos&limit=100', 'plate': 'music-videos'}]:
		add_views({'mode': item['turn'], 'link': f"{BASE_URL_MA}/catalog/{appleRegion}/charts?genre=34&{item['slug']}&l={appleLocale}&platform=web", 'extra': item['plate']}, \
			create_entries({'Title': translation(item['name']), 'Image': f"{artpic}apple.png"}), automatic=True if item['turn'] == 'listAppleVideos' else False)
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_genres})")

def listAppleRooms(target, extra): # https://amp-api.music.apple.com/v1/editorial/de/rooms/6456176473/contents?l=de-DE&platform=web
	primodo, package = [], clientHelper().track_content(target, service='APPLEMUSIC')
	results = package.get('data', []) if extra in ['DEFAULT', 'TRACKS'] else package['results'][extra][0].get('data', [])
	for item in results:
		shorts, style, cata_id = item['attributes'], item['type'], item['id']
		name = (cleaning(shorts.get('shortName', '')) or cleaning(shorts.get('name', '')))
		desc = shorts['description']['short'] if shorts.get('description', '') and shorts['description'].get('short', '') else None # shorts['description']['standard']
		if shorts.get('artwork', '') and shorts['artwork'].get('url', ''):
			thumb = re.sub(r'/{w}x{h}', '/1080x1080', shorts['artwork']['url']) # /1080x1080SC.DN01.jpg?l=de-DE
		else: thumb = f"{artpic}apple.png"
		primodo.append([name, style, cata_id, desc, thumb])
	primodo = sorted(primodo, key=lambda vsx: clear_umlaut(vsx[0]).lower()) if extra.endswith('Charts') or any(xe in target for xe in ['/6503417678', '/6503417844']) else primodo
	for name, style, cata_id, desc, thumb in primodo: # dailyGlobalTopCharts=6503417678 // cityCharts=6503417844
		if style == 'playlists':# https://amp-api.music.apple.com/v1/catalog/de/playlists/pl.a2bebcf1035e456aba4109a414c4c2d5/tracks?platform=web
			follow = f"{BASE_URL_MA}/catalog/{appleRegion}/{style}/{cata_id}/tracks?l={appleLocale}&platform=web&limit=100"
			add_views({'mode': 'listAppleVideos', 'link': follow}, create_entries({'Title': name, 'Image': thumb, 'Plot': desc}), automatic=True)
		else: # https://amp-api.music.apple.com/v1/catalog/de/apple-curators/988574300/grouping?l=de-DE&platform=web
			follow = f"{BASE_URL_MA}/catalog/{appleRegion}/{style}/{cata_id}/grouping?l={appleLocale}&platform=web&limit=100"
			add_views({'mode': 'listAppleGroups', 'link': follow, 'photo': thumb}, create_entries({'Title': name, 'Image': thumb, 'Plot': desc}))
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_playlists})")

def listAppleGroups(target, photo): # https://amp-api.music.apple.com/v1/catalog/de/apple-curators/988574300/grouping?l=de-DE&platform=web
	counter, supported, undesired = 0, ['music-videos', 'playlists', 'songs'], ['albums', 'uploaded-videos', 'stations']
	package = clientHelper().track_content(target, service='APPLEMUSIC')
	for item in package['data'][0]['relationships']['tabs']['data'][0]['relationships']['children'].get('data', {}):
		counter += 1
		if counter == 1: continue # Hide first category
		if item.get('attributes', '') and item['attributes'].get('resourceTypes', '') and any(xs in item['attributes']['resourceTypes'] for xs in supported) and \
			not any(xu in item['attributes']['resourceTypes'] for xu in undesired) and item.get('relationships', '') and item['relationships'].get('room', '') and \
			item['relationships']['room'].get('data', {}) and item['relationships']['room'].get('data', {})[0].get('href', ''): # Hide anything thats not supported
			room_id = item['relationships']['room']['data'][0]['id']
			name = cleaning(item['attributes']['name'])
			if 'interview' in name.lower(): continue # Hide interviews
			if any(xw in item['attributes']['resourceTypes'] for xw in ['music-videos', 'songs']): # https://amp-api-edge.music.apple.com/v1/editorial/us/rooms/6746612880/contents?l=en-US&platform=web&limit=100
				follow = f"{BASE_URL_MA}/editorial/{appleRegion}/rooms/{room_id}/contents?l={appleLocale}&platform=web&limit=100"
				add_views({'mode': 'listAppleVideos', 'link': follow}, create_entries({'Title': name, 'Image': photo}), automatic=True)
			else: # https://amp-api-edge.music.apple.com/v1/editorial/de/rooms/6737138481/contents?l=de-DE&platform=web
				follow = f"{BASE_URL_MA}/editorial/{appleRegion}/rooms/{room_id}/contents?l={appleLocale}&platform=web&limit=150"
				add_views({'mode': 'listAppleRooms', 'link': follow, 'extra': 'TRACKS'}, create_entries({'Title': name, 'Image': photo}))
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_playlists})")

def listAppleVideos(target, phase, limit, extra):
	musicondo, unikat, counter = [], set(), 0
	PLT = clear_playlist() if phase == 'playing' else None
	package = clientHelper().track_content(target, service='APPLEMUSIC')
	results = package.get('data', []) if extra == 'DEFAULT' else package['results'][extra][0].get('data', [])
	for item in results:
		shorts = item['attributes']
		composers = [cleaning(at) for at in shorts['artistName'].split(', ')]
		artists = ', '.join(composers[:3]) # maximum three artists
		song = cleaning(shorts['name'])
		plot = f"Artist: [B]{artists}[/B][CR]Song: [B]{song}[/B]"
		firstTitle = f"{artists} - {song}"
		if firstTitle in unikat:
			continue
		unikat.add(firstTitle)
		longTitle = firstTitle
		if shorts.get('releaseDate', ''):
			released = time.strptime(shorts['releaseDate'][:10], '%Y-%m-%d')
			selection = time.strftime('%d.%m.%Y', released)
			plot += f"[CR]Date: [B][COLOR deepskyblue]{selection}[/COLOR][/B]"
			longTitle = f"{firstTitle}   [COLOR deepskyblue][{selection}][/COLOR]"
		if shorts.get('albumName', ''):
			plot += f"[CR]Album: [B][COLOR FFFFA500]{shorts['albumName']}[/COLOR][/B]"
		if shorts.get('artwork', '') and shorts['artwork'].get('url', ''):
			thumb = re.sub(r'/{w}x{h}', '/1080x1080', shorts['artwork']['url']) # /1400x1400bb.jpg or /3000x3000bb.jpg
		else: thumb = f"{artpic}noimage.png"
		for snippet in BLACK_LISTING:
			if len(snippet.strip()) > 2 and snippet.strip().lower() in firstTitle.lower():
				continue
		musicondo.append([firstTitle, longTitle, thumb, plot])
	if phase == 'browse':
		for firstTitle, longTitle, thumb, plot in musicondo:
			counter, suffix = counter.__add__(1), longTitle if show_details else firstTitle
			name = translation(30801).format(counter, suffix)
			add_views({'mode': 'playTITLE', 'link': customise(firstTitle)}, create_entries({'Title': name, 'Image': thumb, 'Plot': plot, 'Mediatype': 'musicvideo', 'Reference': 'Single'}), False)
		xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if force_viewing:
			xbmc.executebuiltin(f"Container.SetViewMode({viewer_videos})")
	else:
		musicondo = musicondo[:int(limit)] if int(limit) > 0 else musicondo
		random.shuffle(musicondo)
		for firstTitle, longTitle, thumb, plot in musicondo:
			action = build_mass({'mode': 'playTITLE', 'link': customise(firstTitle)})
			fetching = create_entries({'Title': firstTitle, 'Image': thumb, 'Mediatype': 'musicvideo', 'Reference': 'Single'})
			PLT.add(action, fetching)
		xbmc.Player().play(PLT)

def beatportMain():
	add_views({'mode': 'listBeatportVideos', 'link': '/en/top-100.json'}, create_entries({'Title': translation(30661), 'Image': f"{artpic}beatport.png"}), automatic=True)
	for pick in clientHelper().genres_strong():
		follow = f"/en/genre/{pick['slug']}/{pick['id']}/top-100.json" # /en/genre/140-deep-dubstep-grime/95/top-100.json
		add_views({'mode': 'listBeatportVideos', 'link': follow}, create_entries({'Title': pick['ne'], 'Image': f"{artpic}beatport.png"}), automatic=True)
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_genres})")

def listBeatportVideos(target, phase, limit):
	musicondo, together, unikat, counter = [], {}, set(), 0
	PLT = clear_playlist() if phase == 'playing' else None
	package = clientHelper().track_content(target, service='BEATPORT')
	if package and len(package) > 0:
		together = json.loads(package)['pageProps']['dehydratedState']['queries'][0]['state']['data']
	for item in together.get('results', []):
		composers = [cleaning(at.get('name', '')) for at in item.get('artists', [])]
		artists = ', '.join(composers[:3]) # maximum three artists
		song = cleaning(item['name'])
		if item.get('mix_name', '') and not 'original' in item.get('mix_name').lower():
			song += f" [{cleaning(item['mix_name'])}]"
		plot = f"Artist: [B]{artists}[/B][CR]Song: [B]{song}[/B]"
		firstTitle = f"{artists} - {song}"
		if firstTitle in unikat:
			continue
		unikat.add(firstTitle)
		longTitle = firstTitle
		if item.get('publish_date', ''):
			released = time.strptime(item['publish_date'], '%Y-%m-%d')
			selection = time.strftime('%d.%m.%Y', released)
			plot += f"[CR]Date: [B][COLOR deepskyblue]{selection}[/COLOR][/B]"
			longTitle = f"{firstTitle}   [COLOR deepskyblue][{selection}][/COLOR]"
		if item.get('release', '') and item['release'].get('label', '') and item['release']['label'].get('name', ''):
			plot += f"[CR]Label: [B][COLOR FFFFA500]{item['release']['label']['name']}[/COLOR][/B]"
		if item.get('release', '') and item['release'].get('image', '') and item['release']['image'].get('dynamic_uri', ''):
			thumb = re.sub(r'/{w}x{h}', '/500x500', item['release']['image']['dynamic_uri']) # https://geo-media.beatport.com/image_size/{w}x{h}/ab2d1d04-233d-4b08-8234-9782b34dcab8.jpg
		else: thumb = f"{artpic}noimage.png"
		for snippet in BLACK_LISTING:
			if len(snippet.strip()) > 2 and snippet.strip().lower() in firstTitle.lower():
				continue
		musicondo.append([firstTitle, longTitle, thumb, plot])
	if phase == 'browse':
		for firstTitle, longTitle, thumb, plot in musicondo:
			counter, suffix = counter.__add__(1), longTitle if show_details else firstTitle
			name = translation(30801).format(counter, suffix)
			add_views({'mode': 'playTITLE', 'link': customise(firstTitle)}, create_entries({'Title': name, 'Image': thumb, 'Plot': plot, 'Mediatype': 'musicvideo', 'Reference': 'Single'}), False)
		xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if force_viewing:
			xbmc.executebuiltin(f"Container.SetViewMode({viewer_videos})")
	else:
		musicondo = musicondo[:int(limit)] if int(limit) > 0 else musicondo
		random.shuffle(musicondo)
		for firstTitle, longTitle, thumb, plot in musicondo:
			action = build_mass({'mode': 'playTITLE', 'link': customise(firstTitle)})
			fetching = create_entries({'Title': firstTitle, 'Image': thumb, 'Mediatype': 'musicvideo', 'Reference': 'Single'})
			PLT.add(action, fetching)
		xbmc.Player().play(PLT)

def billboardMain():
	for title, action in [(30671, {'mode': 'listBillboardVideos', 'link': f"{BASE_URL_BB}/charts/hot-100/"}), (30672, {'mode': 'listBillboardVideos', 'link': f"{BASE_URL_BB}/charts/billboard-200/"}),
		(30673, {'mode': 'listBillboardVideos', 'link': f"{BASE_URL_BB}/charts/billboard-global-200/"}), (30674, {'mode': 'listBillboardCharts', 'link': 'genre'}),
		(30675, {'mode': 'listBillboardCharts', 'link': 'country'}), (30676, {'mode': 'listBillboardCharts', 'link': 'other'}), (30677, {'mode': 'listBillboardCharts', 'link': 'archive'})]:
		add_views(action, create_entries({'Title': translation(title), 'Image': f"{artpic}billboard.png"}), automatic=True if title in [30671, 30672, 30673] else False)
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_genres})")

def listBillboardCharts(select):
	if select == 'genre':
		for gen_item in [
			{'name': 'Alternative', 'slug': 'alternative-airplay/'},{'name': 'Country', 'slug': 'country-songs/'},{'name': 'Dance/Club', 'slug': 'dance-club-play-songs/'},
			{'name': 'Dance/Electronic', 'slug': 'dance-electronic-songs/'},{'name': 'Gospel', 'slug': 'gospel-songs/'},{'name': 'Latin', 'slug': 'latin-songs/'},{'name': 'Pop', 'slug': 'pop-songs/'},
			{'name': 'Rap', 'slug': 'rap-song/'},{'name': 'R&B', 'slug': 'r-and-b-songs/'},{'name': 'R&B/Hip-Hop', 'slug': 'r-b-hip-hop-songs/'},{'name': 'Rhythmic', 'slug': 'rhythmic-40/'},
			{'name': 'Rock', 'slug': 'rock-songs/'},{'name': 'Smooth Jazz', 'slug': 'jazz-songs/'},{'name': 'Soundtracks', 'slug': 'soundtracks/'},{'name': 'Tropical', 'slug': 'latin-tropical-airplay/'}]:
			add_views({'mode': 'listBillboardVideos', 'link': f"{BASE_URL_BB}/charts/{gen_item['slug']}"}, create_entries({'Title': gen_item['name'], 'Image': f"{artpic}billboard.png"}), automatic=True)
	elif select == 'country':
		for cou_item in [
			{'name': 'Argentina Hot-100', 'slug': 'billboard-argentina-hot-100/'},{'name': 'Canada Hot-100', 'slug': 'canadian-hot-100/'},{'name': 'Italy Hot-100', 'slug': 'billboard-italy-hot-100/'},
			{'name': 'U.K. - Singles Chart', 'slug': 'official-uk-songs/'},{'name': 'Australia Songs', 'slug': 'australia-songs-hotw/'},{'name': 'Belgium Songs', 'slug': 'belgium-songs-hotw/'},
			{'name': 'Brazil Songs', 'slug': 'brazil-songs-hotw/'},{'name': 'Croatia Songs', 'slug': 'croatia-songs-hotw/'},{'name': 'Denmark Songs', 'slug': 'denmark-songs-hotw/'},
			{'name': 'Finland Songs', 'slug': 'finland-songs-hotw/'},{'name': 'France Songs', 'slug': 'france-songs-hotw/'},{'name': 'Germany Songs', 'slug': 'germany-songs-hotw/'},
			{'name': 'Greece Songs', 'slug': 'greece-songs-hotw/'},{'name': 'Hungary Songs', 'slug': 'hungary-songs-hotw/'},{'name': 'Ireland Songs', 'slug': 'ireland-songs-hotw/'},
			{'name': 'Netherlands Songs', 'slug': 'netherlands-songs-hotw/'},{'name': 'Norway Songs', 'slug': 'norway-songs-hotw/'},{'name': 'Poland Songs', 'slug': 'poland-songs-hotw/'},
			{'name': 'Portugal Songs', 'slug': 'portugal-songs-hotw/'},{'name': 'Spain Songs', 'slug': 'spain-songs-hotw/'},{'name': 'Sweden Songs', 'slug': 'sweden-songs-hotw/'},
			{'name': 'Turkey Songs', 'slug': 'turkey-songs-hotw/'}]:
			add_views({'mode': 'listBillboardVideos', 'link': f"{BASE_URL_BB}/charts/{cou_item['slug']}"}, create_entries({'Title': cou_item['name'], 'Image': f"{artpic}billboard.png"}), automatic=True)
	elif select == 'other':
		for oth_item in [
			{'name': 'Digital Song Sales', 'slug': 'digital-song-sales/'},{'name': 'Streaming Songs', 'slug': 'streaming-songs/'},{'name': 'Radio Songs', 'slug': 'radio-songs/'},
			{'name': 'TOP Songs of the ’90s', 'slug': 'greatest-billboards-top-songs-90s/'},{'name': 'TOP Songs of the ’80s', 'slug': 'greatest-billboards-top-songs-80s/'},
			{'name': 'All Time Hot 100 Singles', 'slug': 'greatest-hot-100-singles/'},{'name': 'All Time Greatest Alternative Songs', 'slug': 'greatest-alternative-songs/'},
			{'name': 'All Time Greatest Country Songs', 'slug': 'greatest-country-songs/'},{'name': 'All Time Greatest Latin Songs', 'slug': 'greatest-hot-latin-songs/'},
			{'name': 'All Time Greatest Pop Songs', 'slug': 'greatest-of-all-time-pop-songs/'}]:
			add_views({'mode': 'listBillboardVideos', 'link': f"{BASE_URL_BB}/charts/{oth_item['slug']}"}, create_entries({'Title': oth_item['name'], 'Image': f"{artpic}billboard.png"}), automatic=True)
	elif select == 'archive':
		for arc_item in [
			{'name': 'Hot 100 Songs', 'slug': 'hot-100-songs/'},{'name': 'Global 200 Songs', 'slug': 'billboard-global-200/'},{'name': 'Streaming Songs', 'slug': 'streaming-songs/'},
			{'name': 'Radio Songs', 'slug': 'radio-songs/'},{'name': 'Digital Song Sales', 'slug': 'digital-songs/'},{'name': 'Alternative Songs', 'slug': 'hot-alternative-songs/'},
			{'name': 'Country Songs', 'slug': 'hot-country-songs/'},{'name': 'Dance/Electronic Songs', 'slug': 'hot-dance-electronic-songs/'},
			{'name': 'Gospel Songs', 'slug': 'hot-gospel-songs/'},{'name': 'Latin Songs', 'slug': 'hot-latin-songs/'},{'name': 'Pop Airplay Songs', 'slug': 'pop-songs/'},
			{'name': 'Rap Songs', 'slug': 'hot-rap-songs/'},{'name': 'R&B Songs', 'slug': 'hot-r-and-and-b-songs/'},{'name': 'R&B/Hip-Hop Songs', 'slug': 'hot-r-and-and-b-hip-hop-songs/'},
			{'name': 'Rhytmic Airplay Songs', 'slug': 'rhythmic-songs/'},{'name': 'Rock Songs', 'slug': 'hot-rock-songs/'},{'name': 'Hard Rock Songs', 'slug': 'hot-hard-rock-songs/'},
			{'name': 'Holiday Songs', 'slug': 'hot-holiday-songs/'},{'name': 'Smooth Jazz Airplay Songs', 'slug': 'smooth-jazz-songs/'}]:
			add_views({'mode': 'listBillboardVideos', 'link': f"{BASE_URL_BB}/charts/year-end/{arc_item['slug']}"}, create_entries({'Title': arc_item['name'], 'Image': f"{artpic}billboard.png"}))
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_playlists})")

def listBillboardVideos(target, phase, limit):
	musicondo, counter = [], 0
	PLT = clear_playlist() if phase == 'playing' else None
	package = clientHelper().track_content(target, 'GET', 'TEXT', 'BILLBOARD')
	posts = package.split('class="o-chart-results-list-row-container">')
	for i in range(1, len(posts), 1):
		entry = posts[i]
		AT = re.compile(r'''id=["']title-of-a-story["'] class=["']c-title.+?<span class=["']\s*c-label(?: a|  a)-no-trucate.+?>(.*?)</span>''', re.S).findall(entry)[0]
		SG = re.compile(r'''id=["']title-of-a-story["'] class=["']c-title.+?>([^<]+)</''', re.S).findall(entry)[0]
		artist = cleaning(re.sub(r'\<.*?>', '', AT))
		song = cleaning(re.sub(r'\<.*?>', '', SG))
		plot = f"Artist: [B]{artist}[/B][CR]Song: [B]{song}[/B]"
		firstTitle = f"{artist} - {song}"
		longTitle = firstTitle
		if not 'charts/greatest' in target and not 'charts/year-end' in target:
			results = re.findall(r'''<div class=["']a-chart-plus-minus-icon["']>(.*?)<div class=["']charts-result-detail''', entry, re.S)
			for item in results:
				match = re.compile(r'''<span class=["']\s*c-label.+?>([^<]+)</span>''', re.S).findall(item)
				if match and len(match) > 2:
					plot += f"[CR]Rank: [B][COLOR chartreuse]LW = {str(match[0]).strip().replace('-', '~')}[/COLOR][/B][CR]Week: [B][COLOR violet]{str(match[2]).strip().replace('-', '~')}[/COLOR][/B]"
					longTitle = f"{firstTitle}   [COLOR deepskyblue][LW: {str(match[0]).strip().replace('-', '~')}|WK: {str(match[2]).strip().replace('-', '~')}][/COLOR]"
		img = re.compile(r'''data-lazy-src=["'](https?://charts-static.billboard.com.+?(?:\.jpg|\.jpeg|\.png))''', re.S).findall(entry)
		thumb = re.sub(r'-[0-9]+x[0-9]+', '-480x480', img[0]).strip() if img else f"{artpic}noimage.png" # -53x53.jpg || -87x87.jpg || -106x106.jpg || -180x180.jpg || -224x224.jpg || -344x344.jpg
		for snippet in BLACK_LISTING:
			if len(snippet.strip()) > 2 and snippet.strip().lower() in firstTitle.lower():
				continue
		musicondo.append([firstTitle, longTitle, thumb, plot])
	if phase == 'browse':
		for firstTitle, longTitle, thumb, plot in musicondo:
			counter, suffix = counter.__add__(1), longTitle if show_details else firstTitle
			name = translation(30801).format(counter, suffix)
			add_views({'mode': 'playTITLE', 'link': customise(firstTitle)}, create_entries({'Title': name, 'Image': thumb, 'Plot': plot, 'Mediatype': 'musicvideo', 'Reference': 'Single'}), False)
		xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if force_viewing:
			xbmc.executebuiltin(f"Container.SetViewMode({viewer_videos})")
	else:
		musicondo = musicondo[:int(limit)] if int(limit) > 0 else musicondo
		random.shuffle(musicondo)
		for firstTitle, longTitle, thumb, plot in musicondo:
			action = build_mass({'mode': 'playTITLE', 'link': customise(firstTitle)})
			fetching = create_entries({'Title': firstTitle, 'Image': thumb, 'Mediatype': 'musicvideo', 'Reference': 'Single'})
			PLT.add(action, fetching)
		xbmc.Player().play(PLT)

def ddpMain():
	package = clientHelper().track_content(BASE_URL_DP, 'GET', 'TEXT')
	result = re.compile(r'''<nav id=["']menu["']>(.*?)</nav>''', re.S).findall(package)[0]
	add_views({'mode': 'blankFUNC', 'link': '00'}, create_entries({'Title': translation(30691), 'Image': f"{artpic}ddp_dance.png"}), False)
	add_views({'mode': 'listDdpVideos', 'link': f"{BASE_URL_DP}/top-30/video"}, create_entries({'Title': translation(30692), 'Image': f"{artpic}ddp_dance.png"}), automatic=True)
	match = re.findall(r'''<a href=["']([^"']+)["']>(.*?)</a>''', result, re.S)
	for link, title in match:
		title = cleaning(title)
		if not title.lower().startswith(('ddp', 'top 30')) and not 'schlager' in link.lower():
			if title.lower() in ['top 100','hot 50', 'neueinsteiger']:
				add_views({'mode': 'listDdpVideos', 'link': f"{BASE_URL_DP}{link}"}, create_entries({'Title': f"..... {title}", 'Image': f"{artpic}ddp_dance.png"}), automatic=True)
			elif title.lower() in ['highscores', 'jahrescharts']:
				add_views({'mode': 'listDdpYearCharts', 'link': f"{BASE_URL_DP}{link}"}, create_entries({'Title': f"..... {title}", 'Image': f"{artpic}ddp_dance.png"}))
	add_views({'mode': 'blankFUNC', 'link': '00'}, create_entries({'Title': translation(30693), 'Image': f"{artpic}ddp_schlager.png"}), False)
	for link, title in match:
		title = cleaning(title)
		if not title.lower().startswith(('ddp', 'top 30')) and 'schlager' in link.lower():
			if title.lower() in ['top 100','hot 50', 'neueinsteiger']:
				add_views({'mode': 'listDdpVideos', 'link': f"{BASE_URL_DP}{link}"}, create_entries({'Title': f"..... {title}", 'Image': f"{artpic}ddp_schlager.png"}), automatic=True)
			elif title.lower() in ['highscores', 'jahrescharts']:
				add_views({'mode': 'listDdpYearCharts', 'link': f"{BASE_URL_DP}{link}"}, create_entries({'Title': f"..... {title}", 'Image': f"{artpic}ddp_schlager.png"}))
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_genres})")

def listDdpYearCharts(target, musicondo=[]):
	package = clientHelper().track_content(target, 'GET', 'TEXT', 'DJPLAYLIST')
	result = re.compile(r'''<div class=["']year-selection["']>(.*?)</div>''', re.S).findall(package)[0]
	musicondo = re.findall(r'''<a href=["']([^"']+).*?>([^<]+)</a>''', result, re.S)
	for link, title in sorted(musicondo, key=lambda xs: xs[1], reverse=True):
		thumb = f"{artpic}ddp_dance.png" if 'dance' in target.lower() else f"{artpic}ddp_schlager.png"
		add_views({'mode': 'listDdpVideos', 'link': f"{BASE_URL_DP}{link}"}, create_entries({'Title': cleaning(title), 'Image': thumb}), automatic=True)
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_playlists})")

def listDdpVideos(target, phase, limit):
	musicondo, unikat = [], set()
	PLT = clear_playlist() if phase == 'playing' else None
	package = clientHelper().track_content(target, 'GET', 'TEXT', 'DJPLAYLIST')
	if 'highscores' in target or 'jahrescharts' in target:
		result = re.compile(r'''<div class=["']charts big["'] style(.*?)<div class=["']charts big mobile["'] style''', re.S).findall(package)[0]
	else:
		result = re.compile(r'''<div class=["']charts big mobile["'] style(.*?)<div class=["']footer["']>''', re.S).findall(package)[-1]
	posts = result.split('<div class="entry">')
	for i in range(1, len(posts), 1):
		entry = posts[i]
		rank = re.compile(r'''<div class=["']rank["']>(.*?)</div>''', re.S).findall(entry)
		AT = re.compile(r'''<div class=["']artist["']>(.*?)</div>''', re.S).findall(entry)
		SG = re.compile(r'''<div class=["']title["']>(.*?)</div>''', re.S).findall(entry)
		if not AT or not SG:
			continue
		artist = title_case(cleaning(AT[0]))
		song = title_case(cleaning(SG[0]))
		plot = f"Artist: [B]{artist}[/B][CR]Song: [B]{song}[/B]"
		firstTitle = f"{artist} - {song}"
		if firstTitle in unikat:
			continue
		unikat.add(firstTitle)
		longTitle = firstTitle
		if 'highscores' in target or 'jahrescharts' in target:
			point = re.compile(r'''<div class=["']s-pkt["']><div>(.*?)</div>''', re.S).findall(entry)
			week = re.compile(r'''<div class=["']s-wk["']><div>(.*?)</div>''', re.S).findall(entry)
			if week and not point:
				plot += f"[CR]Week: [B][COLOR violet]{str(week[0].strip())}[/COLOR][/B]"
				longTitle = f"{firstTitle}   [COLOR deepskyblue][WK: {str(week[0].strip())}][/COLOR]"
			elif week and point:
				plot += f"[CR]Point: [B][COLOR FFFFA500]{str(point[0]).strip()}[/COLOR][/B][CR]Week: [B][COLOR violet]{str(week[0]).strip()}[/COLOR][/B]"
				longTitle = f"{firstTitle}   [COLOR deepskyblue][PT: {str(point[0]).strip()}|WK: {str(week[0]).strip()}][/COLOR]"
		else:
			match = re.compile(r'''<div class=["']name["']>(.*?)</div>\s*<div class=["']value["']>(.*?)</div>''', re.S).findall(entry)
			change = match[0][1].strip().replace('<img src="img/icons/charts/dance/re.svg" width="16px" alt="">', 'RE') if match and len(match) > 0 and \
				cleaning(match[0][0]) == 'TW' else None
			NEW = change if change and change in ['NEU', 'RE'] else None
			UNO = str(match[1][1]).strip() if match and len(match) > 1 and cleaning(match[1][0]) == 'LW' else None
			DUE = str(match[2][1]).strip() if match and len(match) > 2 and cleaning(match[2][0]) == '2W' else None
			TRE = str(match[3][1]).strip() if match and len(match) > 3 and cleaning(match[3][0]) == '3W' else None
			if NEW:
				plot += f"[CR]Rank: [B][COLOR chartreuse]{NEW}[/COLOR][/B]"
				longTitle = f"{firstTitle}   [COLOR deepskyblue][{NEW}][/COLOR]"
			elif NEW is None and UNO and DUE and TRE:
				plot += f"[CR]Rank: [B][COLOR chartreuse]LW = {UNO.replace('-', '~')}|2W = {DUE.replace('-', '~')}|3W = {TRE.replace('-', '~')}[/COLOR][/B]"
				longTitle = f"{firstTitle}   [COLOR deepskyblue][LW: {UNO.replace('-', '~')}|2W: {DUE.replace('-', '~')}|3W: {TRE.replace('-', '~')}][/COLOR]"
		img = re.compile(r'''<div class=["']cover["'].+?//poolposition.mp3([^"']+)["']''', re.S).findall(entry)
		thumb = 'https://poolposition.mp3'+img[0].split('&width')[0] if img else f"{artpic}noimage.png"
		for snippet in BLACK_LISTING:
			if len(snippet.strip()) > 2 and snippet.strip().lower() in firstTitle.lower():
				continue
		musicondo.append([rank[0].strip(), firstTitle, longTitle, thumb, plot])
	musicondo = sorted(musicondo, key=lambda cn: int(cn[0]))
	if phase == 'browse':
		for rank, firstTitle, longTitle, thumb, plot in musicondo:
			suffix = longTitle if show_details else firstTitle
			name = translation(30801).format(rank, suffix)
			add_views({'mode': 'playTITLE', 'link': customise(firstTitle)}, create_entries({'Title': name, 'Image': thumb, 'Plot': plot, 'Mediatype': 'musicvideo', 'Reference': 'Single'}), False)
		xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if force_viewing:
			xbmc.executebuiltin(f"Container.SetViewMode({viewer_videos})")
	else:
		musicondo = musicondo[:int(limit)] if int(limit) > 0 else musicondo
		random.shuffle(musicondo)
		for rank, firstTitle, longTitle, thumb, plot in musicondo:
			action = build_mass({'mode': 'playTITLE', 'link': customise(firstTitle)})
			fetching = create_entries({'Title': firstTitle, 'Image': thumb, 'Mediatype': 'musicvideo', 'Reference': 'Single'})
			PLT.add(action, fetching)
		xbmc.Player().play(PLT)

def hypemMain():
	for title, action in [(30701, {'mode': 'listHypemVideos', 'link': f"{BASE_URL_HM}/popular?ax=1&sortby=shuffle"}),
		(30702, {'mode': 'listHypemVideos', 'link': f"{BASE_URL_HM}/popular/lastweek?ax=1&sortby=shuffle"}), (30703, {'mode': 'listHypemMachine'})]:
		add_views(action, create_entries({'Title': translation(title), 'Image': f"{artpic}hypem.png"}), automatic=True if title in [30701, 30702] else False)
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_genres})")

def listHypemMachine():
	for i in range(1, 201, 1):
		dt = date.today()
		while dt.weekday() != 0:
			dt -= timedelta(days=1)
		dt -= timedelta(weeks=i)
		months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
		month = months[int(dt.strftime('%m')) - 1]
		name = dt.strftime('%d. %b - %Y').replace('Mar', translation(30704)).replace('May', translation(30705)).replace('Oct', translation(30706)).replace('Dec', translation(30707))
		add_views({'mode': 'listHypemVideos', 'link': f"{BASE_URL_HM}/popular/week:{month}-{dt.strftime('%d-%Y')}?ax=1&sortby=shuffle"}, create_entries({'Title': name, 'Image': f"{artpic}hypem.png"}), automatic=True)
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_playlists})")

def listHypemVideos(target, phase, limit):
	musicondo, unikat, counter = [], set(), 0
	PLT = clear_playlist() if phase == 'playing' else None
	package = clientHelper().track_content(target, 'GET', 'TEXT')
	result = re.compile(r'''(?s)<script\s+type=["']application/json["']\s+id=["']displayList-data["']>(.*?)</script>''', re.S).findall(package)[0]
	for item in json.loads(result).get('tracks', []):
		artist = cleaning(item['artist'])
		song = cleaning(item['song'])
		plot = f"Artist: [B]{artist}[/B][CR]Song: [B]{song}[/B]"
		firstTitle = f"{artist} - {song}"
		if firstTitle in unikat or artist == "":
			continue
		unikat.add(firstTitle)
		img = re.compile(r'href="/track/'+item['id']+'/.+?background:url\((.*?)\)', re.S).findall(package)
		thumb = img[0] if img else f"{artpic}noimage.png"
		for snippet in BLACK_LISTING:
			if len(snippet.strip()) > 2 and snippet.strip().lower() in firstTitle.lower():
				continue
		musicondo.append([firstTitle, thumb, plot])
	if phase == 'browse':
		for firstTitle, thumb, plot in musicondo:
			counter += 1
			name = translation(30801).format(counter, firstTitle)
			add_views({'mode': 'playTITLE', 'link': customise(firstTitle)}, create_entries({'Title': name, 'Image': thumb, 'Plot': plot, 'Mediatype': 'musicvideo', 'Reference': 'Single'}), False)
		xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if force_viewing:
			xbmc.executebuiltin(f"Container.SetViewMode({viewer_videos})")
	else:
		musicondo = musicondo[:int(limit)] if int(limit) > 0 else musicondo
		random.shuffle(musicondo)
		for firstTitle, thumb, plot in musicondo:
			action = build_mass({'mode': 'playTITLE', 'link': customise(firstTitle)})
			fetching = create_entries({'Title': firstTitle, 'Image': thumb, 'Mediatype': 'musicvideo', 'Reference': 'Single'})
			PLT.add(action, fetching)
		xbmc.Player().play(PLT)

def occMain():
	for title, slug in [(30721, 'singles-chart/'), (30722, 'uk-top-40-singles-chart/'), (30723, 'singles-chart-update/'), (30724, 'singles-downloads-chart/'),
		(30725, 'singles-sales-chart/'), (30726, 'video-streaming-chart/'), (30727, 'audio-streaming-chart/'), (30728, 'vinyl-singles-chart/'),
		(30729, 'independent-singles-chart/'), (30730, 'dance-singles-chart/'), (30731, 'official-hip-hop-and-r-and-b-singles-chart/'), (30732, 'rock-and-metal-singles-chart/'),
		(30733, 'french-singles-chart/'), (30734, 'irish-singles-chart/'), (30735, 'end-of-year-singles-chart/'), (30736, 'physical-singles-chart/')]:
		add_views({'mode': 'listOccVideos', 'link': f"{BASE_URL_OC}/charts/{slug}"}, create_entries({'Title': translation(title), 'Image': f"{artpic}official.png"}), automatic=True)
	xbmcplugin.setContent(ADDON_HANDLE, 'files')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)
	if force_viewing:
		xbmc.executebuiltin(f"Container.SetViewMode({viewer_playlists})")

def listOccVideos(target, phase, limit):
	musicondo, unikat, counter = [], set(), 0
	PLT = clear_playlist() if phase == 'playing' else None
	package = clientHelper().track_content(target, 'GET', 'TEXT', 'OFFICIAL')
	result = re.compile(r'''<section class=["']chart-list(.*?)</section>''', re.S).findall(package)[0]
	posts = result.split('<div class="chart-item-content')
	for i in range(1, len(posts), 1):
		entry = posts[i]
		AT = re.compile(r'''class=["']chart-artist.+?><span>(.*?)</span></(?:a|span)></p>''', re.S).findall(entry)[0]
		SG = re.compile(r'''class=["']chart-name.+?</span>(?:<!---->)?<span>(.*?)</span></a>''', re.S).findall(entry)[0]
		artist = title_case(cleaning(AT.replace('/', ', ')))
		song = title_case(cleaning(SG))
		plot = f"Artist: [B]{artist}[/B][CR]Song: [B]{song}[/B]"
		firstTitle = f"{artist} - {song}"
		longTitle = firstTitle
		move = re.compile(r'''<li class=["']movement.+?<span class=["']text-brand.+?["']>(.*?)</span>''', re.S).findall(entry)
		peak = re.compile(r'''<li class=["']peak.+?<span class=["']text-brand.+?["']>(.*?)</span>''', re.S).findall(entry)
		week = re.compile(r'''<li class=["']weeks.+?<span class=["']text-brand.+?["']>(.*?)</span>''', re.S).findall(entry)
		if move and peak and week:
			plot += f"[CR]Rank: [B][COLOR chartreuse]LW = {str(move[0]).strip().replace('-', '~')}[/COLOR][/B][CR]Peak: [B][COLOR FFFFA500]{str(peak[0]).strip().replace('-', '~')}[/COLOR][/B]"\
				f"[CR]Week: [B][COLOR violet]{str(week[0]).strip().replace('-', '~')}[/COLOR][/B]"
			longTitle = f"{firstTitle}   [COLOR deepskyblue][LW: {str(move[0]).strip().replace('-', '~')}|PK: {str(peak[0]).strip().replace('-', '~')}|WK: {str(week[0]).strip().replace('-', '~')}][/COLOR]"
		img = re.compile(r'''<div class=["']chart-image["'].+?src=["'](https?://[^"']+)["'] width=''', re.S).findall(entry)
		thumb = re.sub(r'/[0-9]+x[0-9]+bb', '/512x512bb', img[0]).replace('item_artwork_small', 'item_artwork_large').strip() if img else f"{artpic}noimage.png"
		for snippet in BLACK_LISTING: # backstage.officialcharts.com = item_artwork_small > item_artwork_large // ssl.mzstatic.com = /80x80bb.jpg > /512x512bb.jpg
			if len(snippet.strip()) > 2 and snippet.strip().lower() in firstTitle.lower():
				continue
		musicondo.append([firstTitle, longTitle, thumb, plot])
	if phase == 'browse':
		for firstTitle, longTitle, thumb, plot in musicondo:
			counter, suffix = counter.__add__(1), longTitle if show_details else firstTitle
			name = translation(30801).format(counter, suffix)
			add_views({'mode': 'playTITLE', 'link': customise(firstTitle)}, create_entries({'Title': name, 'Image': thumb, 'Plot': plot, 'Mediatype': 'musicvideo', 'Reference': 'Single'}), False)
		xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
		xbmcplugin.endOfDirectory(ADDON_HANDLE)
		if force_viewing:
			xbmc.executebuiltin(f"Container.SetViewMode({viewer_videos})")
	else:
		musicondo = musicondo[:int(limit)] if int(limit) > 0 else musicondo
		random.shuffle(musicondo)
		for firstTitle, longTitle, thumb, plot in musicondo:
			action = build_mass({'mode': 'playTITLE', 'link': customise(firstTitle)})
			fetching = create_entries({'Title': firstTitle, 'Image': thumb, 'Mediatype': 'musicvideo', 'Reference': 'Single'})
			PLT.add(action, fetching)
		xbmc.Player().play(PLT)

def playTITLE(riders, primodo=[]):
	enquiry = 'official+'+quote_plus(riders).replace('%5B', '').replace('%5D', '').replace('%27', '').replace('%28', '').replace('%29', '').replace('%2F', '').lower()
	package = clientHelper().track_content(f"https://www.googleapis.com/youtube/v3/search?part=snippet&phase=video&maxResults=5&order=relevance&q={enquiry}&key={PERS_TOKEN}", service='YOUTUBE')
	for item in package.get('items', []):
		if item.get('id', {}).get('kind', '') == 'youtube#video':
			snip_title, yout_video = cleaning(item['snippet']['title']), item['id']['videoId']
			primodo.append([snip_title, yout_video])
	if primodo:
		parts = primodo[:]
		matching = [s for s in parts if not 'audio' in s[0].lower() and not 'hörprobe' in s[0].lower()]
		yout_sign = matching[0][1] if matching else parts[0][1]
		FINAL_URL = f"plugin://plugin.video.youtube/play/?video_id={yout_sign}"
		log(f"(navigator.playTITLE) StreamURL : {FINAL_URL}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL, offscreen=True))
		xbmc.sleep(1000)
		if show_infos: infoMessage()
	else:
		return dialog.notification(translation(30521).format('VIDEO'), translation(30525).format(suffix), icon, 10000)

def infoMessage():
	counter = 0
	while not xbmc.Player().isPlaying():
		xbmc.sleep(200)
		if counter == 50:
			break
		counter += 1
	xbmc.sleep(int(info_delay)*1000 - 2000)
	if xbmc.Player().isPlaying() and info_styles == '0':
		xbmc.sleep(1500)
		xbmc.executebuiltin('ActivateWindow(12901)')
		xbmc.sleep(info_duration*1000)
		xbmc.executebuiltin('ActivateWindow(12005)')
		xbmc.sleep(500)
		xbmc.executebuiltin('Action(Back)')
	elif xbmc.Player().isPlaying() and info_styles == '1':
		xbmc.getInfoLabel('Player.Title')
		xbmc.getInfoLabel('Player.Duration')
		xbmc.getInfoLabel('Player.Art(thumb)')
		xbmc.sleep(500)
		TITLE = xbmc.getInfoLabel('Player.Title')
		if TITLE.isupper() or TITLE.islower():
			TITLE = title_case(TITLE)
		RUNTIME = xbmc.getInfoLabel('Player.Duration')
		PHOTO = xbmc.getInfoLabel('Player.Art(thumb)')
		xbmc.sleep(1000)
		dialog.notification(translation(30803), translation(30804).format(TITLE, RUNTIME), PHOTO, int(info_duration)*1000)

def add_views(params, listitem, folder=True, automatic=False):
	uws, entries = build_mass(params), []
	debug_MS(f"(navigator.{params.get('mode', '')}) ### PARAM : {urlencode(params, safe='/:?=&')} || FOLDER : {folder} ###")
	listitem.setPath(uws)
	if automatic is True:
		for label, volume in [(30831, 0), (30832, 10), (30833, 20), (30834, 30), (30835, 40), (30836, 50)]:
			entries.append([translation(label), f"RunPlugin({build_mass({**params, **{'phase': 'playing', 'limit': volume}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
