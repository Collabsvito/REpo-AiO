﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import time
from bs4 import BeautifulSoup
import YDStreamExtractor
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote, quote_plus  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else: 
	from urllib.parse import urlencode, quote, quote_plus  # Python 3.X
	from urllib.request import urlopen  # Python 3.X

from .common import *


def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listBroadcasts', 'url': BASE_URL+'/programs'})
	content = getUrl(BASE_URL+'/videos')
	soup = BeautifulSoup(content, 'html.parser')
	start = soup.find_all('h2', class_='section-global-h2')
	for theme in start:
		title = cleaning(theme.span.text)
		link = BASE_URL+theme.a['href']
		debug_MS("(navigator.mainMenu) ### NAME : {0} || LINK : {1} ###".format(title, link))
		addDir(title, icon, {'mode': 'listVideos', 'url': link, 'origSERIE': title, 'extras': 'themevids'})
	addDir(translation(30602), artpic+'basesearch.png', {'mode': 'SearchWDW'})
	if enableYOUTUBE:
		addDir(translation(30621), icon, {'mode': 'listYTcategories'})
	addDir(translation(30622), artpic+'livestream.png', {'mode': 'playLIVE', 'url': BASE_URL+'/videos/live'}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30623), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(url):
	debug_MS("(navigator.listBroadcasts) ------------------------------------------------ START = listBroadcasts -----------------------------------------------")
	content = getUrl(url)
	soup = BeautifulSoup(content, 'html.parser')
	start = soup.find('div', class_='row item-list-video').find_all('a')
	for series in start:
		photo = quote(py2_enc(series.img['src']), safe='/:')
		link = BASE_URL+series['href']
		title = cleaning(re.compile('.+/([^/]+)$', re.DOTALL).findall(link)[0].replace('-', ' '))
		debug_MS("(navigator.listBroadcasts) ### NAME : {0} || LINK : {1} || IMAGE : {2} ###".format(title.title(), link, photo))
		if title != 'life goes on':
			addDir(title.title(), photo, {'mode': 'listSeasons', 'url': link, 'origSERIE': title.title(), 'extras': photo})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(url, origSERIE, THUMB):
	debug_MS("(navigator.listSeasons) ------------------------------------------------ START = listSeasons -----------------------------------------------")
	content = getUrl(url)
	soup = BeautifulSoup(content, 'html.parser')
	desc = soup.find('div', class_='modal-body')
	plot = cleaning(desc.text) if desc is not None else ""
	select = soup.find('select', class_='form-control')
	if select is not None:
		for elem in select.find_all('option'):
			debug_MS("(navigator.listSeasons) ### NAME : {0} || LINK : {1} || IMAGE : {2} ###".format(cleaning(elem.text), url+'?staffel='+str(elem['value']), THUMB))
			addDir(cleaning(elem.text), THUMB, {'mode': 'listVideos', 'url': url+'?staffel='+str(elem['value']), 'origSERIE': origSERIE}, plot)
	else:
		debug_MS("(navigator.listSeasons) ##### !!! Keinen Listeneintrag für '{0}' gefunden !!! #####".format(origSERIE))
		return dialog.notification(translation(30522).format('Einträge'), translation(30525).format(origSERIE), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(url, origSERIE, PAGE, TYPE):
	debug_MS("(navigator.listVideos) ------------------------------------------------ START = listVideos -----------------------------------------------")
	PGurl = url+"_load?page="+str(PAGE) if TYPE == 'themevids' else url
	debug_MS("(navigator.listVideos) ### URL = {0} ### PAGE = {1} ### TYPE = {2} ###".format(PGurl, PAGE, TYPE))
	content = getUrl(PGurl)
	FOUND = 0
	duration = '0'
	soup = BeautifulSoup(content, 'html.parser')
	desc = soup.find('div', class_='modal-body')
	lead = cleaning(desc.text) if desc is not None else ""
	videos = soup.find_all('div', class_='col-md-3 col-sm-6 item-video item-video-global')
	for vid in videos:
		photo, link, title, duration, plot = ("" for _ in range(5))
		photo = quote(py2_enc(vid.img['src']), safe='/:')
		link = BASE_URL+vid.a['href']
		title = cleaning(vid.find('h4').text)
		FOUND += 1
		if TYPE == 'themevids':
			desc = vid.p
			lead = cleaning(desc.text) if desc is not None else ""
			runtime = vid.span.previous_sibling
			running = re.compile('([0-9]+):([0-9]+)', re.DOTALL).findall(runtime)
			duration = int(running[0][0])*60+int(running[0][1]) if running else '0'
		plot = origSERIE+'[CR][CR]'+lead.strip()
		debug_MS("(navigator.listVideos) ### NAME : {0} || LINK : {1} ###".format(title, link))
		debug_MS("(navigator.listVideos) ### DURATION : {0} || IMAGE : {1} ###".format(duration, photo))
		addLink(title, photo, {'mode': 'playVideo', 'url': link, 'origSERIE': origSERIE, 'cineType': 'episode'}, plot, duration)
	if TYPE == 'themevids' and FOUND > 31:
		addDir(translation(30624), artpic+'nextpage.png', {'mode': 'listVideos', 'url': url, 'origSERIE': origSERIE, 'page': int(PAGE)+1, 'extras': TYPE})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchWDW():
	debug_MS("(navigator.SearchWDW) ------------------------------------------------ START = SearchWDW -----------------------------------------------")
	keyword = None
	if xbmcvfs.exists(searchHackFile):
		with open(searchHackFile, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30625), type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
		if keyword:
			keyword = quote(keyword)
			with open(searchHackFile, 'w') as record:
				record.write(keyword)
	if keyword: return listSearch(BASE_URL+'/search?query='+keyword)
	return None

def listSearch(url):
	debug_MS("(navigator.listSearch) ------------------------------------------------ START = listSearch -----------------------------------------------")
	debug_MS("(navigator.listSearch) ### URL = {0} ###".format(url))
	content = getUrl(url)
	soup = BeautifulSoup(content, 'html.parser')
	videos = soup.find_all('div', class_='col-md-12 col-sm-12')
	for vid in videos:
		photo, title, plot = ("" for _ in range(3))
		try: idd = vid.div['id']
		except: idd = '00'
		photo = quote(py2_enc(vid.img['src']), safe='/:')
		title = cleaning(vid.find('h2').text)
		desc = vid.p
		plot = cleaning(desc.text) if desc is not None else ""
		if idd == '00':
			debug_MS("(navigator.listSearch) ### NAME : {0} || IDD : [No Video] ###".format(title))
			addDir(translation(30626).format(title), photo, {'mode': 'blankFUNC', 'url': '00', 'origSERIE': title}, plot, folder=False)
		else:
			result = getUrl('{0}/videos/{1}/embed_code'.format(BASE_URL, str(idd)))
			matching = re.search(r'(?:\/|%3D|v=|vi=)([0-9A-z-_]{11})(?:[%#?&]|$)', result)
			YOUT_ID = matching.group(1) if matching else 'NKF'
			debug_MS("(navigator.listSearch) ### NAME : {0} || IDD : {1} || YOUTUBE : {2} ###".format(title, str(idd), YOUT_ID))
			if YOUT_ID != 'NKF':
				addLink(title, photo, {'mode': 'playVideo', 'url': YOUT_ID, 'origSERIE': title, 'extras': 'YTstream', 'cineType': 'movie'}, plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listYTcategories():
	debug_MS("(navigator.listYTcategories) -------------------------------------------------- START = listYTcategories --------------------------------------------------")
	addDir(translation(30631), icon, {'url': BASE_YT+'UUBk6ZmyoyX1kLl-w17B0V1A/', 'extras': 'YT_FOLDER'}, tag='Welt der Wunder')
	addDir(translation(30632), icon, {'url': BASE_YT+'PLYdG_9RWfsrXCehAv5GqyhI0QerT873Hk/', 'extras': 'YT_FOLDER'}, tag='Lifestyle-Magazin')
	addDir(translation(30633), icon, {'url': BASE_YT+'PLYdG_9RWfsrVtOFH-Pn17Fv1jAqMI8cdy/', 'extras': 'YT_FOLDER'}, tag='Magazin rund um Start-ups')
	addDir(translation(30634), icon, {'url': BASE_YT+'PLYdG_9RWfsrVQoW9I2lQtLI7bl14inzht/', 'extras': 'YT_FOLDER'}, tag='Musik-Magazin für Nachwuchskünstler')
	addDir(translation(30635), icon, {'url': BASE_YT+'PLYdG_9RWfsrXkIeFj3GNq-pb2aZdsz4tq/', 'extras': 'YT_FOLDER'}, tag='Gaming-Magazin')
	addDir(translation(30636), icon, {'url': BASE_YT+'PLYdG_9RWfsrWmnIIGxb2JkKAFRJELRbWr/', 'extras': 'YT_FOLDER'}, tag='Magazin rund um Mobilität')
	addDir(translation(30637), icon, {'url': BASE_YT+'PLYdG_9RWfsrVrswxMNOcN0tD9u2NfqN9s/', 'extras': 'YT_FOLDER'}, tag='Automagazin')
	addDir(translation(30638), icon, {'url': BASE_YT+'PLYdG_9RWfsrXGndfGfTLDfdoQ2jWiARu_/', 'extras': 'YT_FOLDER'}, tag='Magazin rund um Nachhaltigkeit')
	addDir(translation(30639), icon, {'url': BASE_YT+'PLYdG_9RWfsrX205xRZvwSDOLVFmjYnGIM/', 'extras': 'YT_FOLDER'}, tag='Gesundheitsmagazin')
	addDir(translation(30640), icon, {'url': BASE_YT+'PLYdG_9RWfsrWIYZJZtcveo7Qo0TeNOJQg/', 'extras': 'YT_FOLDER'}, tag='Magazin rund um Reise & Genuss')
	addDir(translation(30641), icon, {'url': BASE_YT+'PLYdG_9RWfsrVR1chw4BZe33tlbTx0QZUh/', 'extras': 'YT_FOLDER'}, tag='Talkshow')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url, TYPE):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL = {0} ### TYPE = {1} ###".format(url, TYPE))
	if TYPE == 'YTstream':
		stream_url = 'plugin://plugin.video.youtube/play/?video_id='+url
	else:
		vid = YDStreamExtractor.getVideoInfo(url, quality=prefQUALITY) # Quality is 0=SD, 1=720p, 2=1080p, 3=Highest Available
		stream_url = vid.streamURL() # This is what Kodi (XBMC) will play
		stream_url = stream_url.split('|')[0]
	log("(navigator.playVideo) StreamURL : "+stream_url)
	xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=stream_url))

def playLIVE(url):
	debug_MS("(navigator.playLIVE) ------------------------------------------------ START = playLIVE -----------------------------------------------")
	live_url = False
	try:
		content = getUrl(url)
		stream = re.compile('<video id="live-video".*?<source src="([^"]+?)" type="application/x-mpeg', re.DOTALL).findall(content)[0]
		code = urlopen(stream).getcode()
		if str(code) == '200': live_url = stream
	except: pass
	if live_url:
		log("(navigator.playLIVE) ### LiveURL : {0} ###".format(live_url))
		listitem = xbmcgui.ListItem(path=live_url, label=translation(30642))
		listitem.setMimeType('application/x-mpegURL')
		if ADDON_operate('inputstream.adaptive') and 'm3u8' in live_url:
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
			listitem.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
		xbmc.Player().play(item=live_url, listitem=listitem)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Live-Stream-Eintrag auf der Webseite von *weltderwunder.de* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('LIVE'), translation(30527), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, tag=None, folder=True):
	if params.get('extras') == 'YT_FOLDER': u = params.get('url')
	else: u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Tagline': tag, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	info = {}
	info['Tvshowtitle'] = params.get('origSERIE')
	info['Title'] = name
	info['Tagline'] = None
	info['Plot'] = plot
	info['Duration'] = duration
	info['Year'] = None
	info['Genre'] = 'Facts, Wissen'
	info['Studio'] = 'WDW'
	info['Mediatype'] = params.get('cineType')
	liz.setInfo(type='Video', infoLabels=info)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
