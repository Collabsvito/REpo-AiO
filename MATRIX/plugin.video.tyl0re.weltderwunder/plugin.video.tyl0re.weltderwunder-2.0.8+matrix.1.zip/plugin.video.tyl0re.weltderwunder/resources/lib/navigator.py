﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
from bs4 import BeautifulSoup
import YDStreamExtractor
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else: 
	from urllib.parse import urlencode, quote_plus  # Python 2.X
	from urllib.request import urlopen  # Python 3+

from .common import *


def mainMenu():
	addDir(translation(30601), icon, {'mode': 'listBroadcasts', 'url': BASE_URL+'/programs'})
	addDir(translation(30602), icon, {'mode': 'listThemes', 'url': BASE_URL+'/videos'})
	addDir(translation(30603), artpic+'basesearch.png', {'mode': 'Searching'})
	addDir(translation(30604), artpic+'livestream.png', {'mode': 'playLIVE', 'url': BASE_URL+'/videos/live'}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30605), artpic+'settings.png', {'mode': 'aSettings'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE) 

def listThemes(url):
	debug("(navigator.listThemes) ------------------------------------------------ START = listThemes -----------------------------------------------")
	content = getUrl(url)
	htmlPage = BeautifulSoup(content, 'html.parser')
	starting = htmlPage.find_all('h2',attrs={'class':'section-global-h2'})
	for theme in starting:
		title = theme.text.replace('» Alle Anzeigen', '')
		link = BASE_URL+theme.find('a')['href']
		addDir(title, icon, {'mode': 'listVideos', 'url': link, 'origSERIE': title, 'extras': 'themevids'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(url):
	debug("(navigator.listBroadcasts) ------------------------------------------------ START = listBroadcasts -----------------------------------------------")
	content = getUrl(url)
	htmlPage = BeautifulSoup(content, 'html.parser')
	starting = htmlPage.find_all('div',attrs={'class':'col-md-3 col-sm-3 col-xs-6 program-thumbnail'})
	for serie in starting:
		img = cleanPhoto(serie.find('img')['src'])
		link = BASE_URL+serie.find('a')['href']
		title = re.compile('.+/([^/]+)$', re.DOTALL).findall(link)[0].replace('-', ' ')
		if title != 'life goes on':
			addDir(title.title(), img, {'mode': 'listSeasons', 'url': link, 'origSERIE': title.title(), 'extras': img})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSeasons(url, origSERIE, THUMB):
	debug("(navigator.listSeasons) ------------------------------------------------ START = listSeasons -----------------------------------------------")
	content = getUrl(url)
	htmlPage = BeautifulSoup(content, 'html.parser')
	try: plot = htmlPage.find('div',attrs={'class':'modal-body'}).text
	except: plot = ""
	selection = htmlPage.find('select',attrs={'class':'form-control'})
	entries = selection.find_all('option')
	for elem in entries:
		addDir(elem.text, cleanPhoto(THUMB), {'mode': 'listVideos', 'url': url+'?staffel='+str(elem['value']), 'origSERIE': origSERIE}, plot)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(url, origSERIE, PAGE, TYPE):
	debug("(navigator.listVideos) ------------------------------------------------ START = listVideos -----------------------------------------------")
	PGurl = url+"_load?page="+str(PAGE) if TYPE=='themevids' else url
	content = getUrl(PGurl)
	FOUND = 0
	htmlPage = BeautifulSoup(content, 'html.parser')
	try: Note_1 = htmlPage.find('div',attrs={'class':'modal-body'}).text.strip()
	except: Note_1 = ""
	videos = htmlPage.find_all('div',attrs={'class':'col-md-3 col-sm-6 item-video item-video-global'})
	for vid in videos:
		img = cleanPhoto(vid.find('img')['src'])
		link = BASE_URL+vid.find('a')['href']
		title = vid.find('h4').text
		FOUND += 1
		if TYPE == 'themevids':
			try: Note_1 = vid.find('p').text
			except: Note_1 = ""
			runtime = vid.find('div',attrs={'class':'item-video-duration-global'}).text
			running = re.compile('([0-9]+):([0-9]+)', re.DOTALL).findall(runtime)
			duration = int(running[0][0])*60+int(running[0][1])
		else:
			duration = '0'
		plot = origSERIE+'[CR][CR]'+Note_1
		addLink(title, img, {'mode': 'playVideo', 'url': link, 'origSERIE': origSERIE}, plot, duration)
	if TYPE == 'themevids' and FOUND > 31:
		addDir(translation(30610), artpic+'nextpage.png', {'mode': 'listVideos', 'url': url, 'origSERIE': origSERIE, 'page': int(PAGE)+1, 'extras': TYPE})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def Searching():
	debug("(navigator.Searching) ------------------------------------------------ START = Searching -----------------------------------------------")
	word = dialog.input('Suche', type=xbmcgui.INPUT_ALPHANUM)
	word = quote_plus(word, safe='')
	if word == "": return
	content = getUrl(BASE_URL+"/search?query="+word)
	htmlPage = BeautifulSoup(content, 'html.parser')
	videos = htmlPage.find_all('div',attrs={'class':'col-md-12 col-sm-12'})
	for vid in videos:
		try:
			img = cleanPhoto(vid.find('img')['src'])
			link = BASE_URL+vid.find('a')['href']
			title = vid.find('h2').text
			plot = vid.find('p').text
			if "VIDEO" in title:
				name = title.replace('VIDEO', '')
				addLink(name, img, {'mode': 'playVideo', 'url': link, 'origSERIE': title}, plot)
			else:
				addDir(title+translation(30611), img, {'mode': '00', 'url': link, 'origSERIE': title}, plot)
		except: pass
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url):
	debug("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	vid = YDStreamExtractor.getVideoInfo(url, quality=prefQUALITY) # Quality is 0=SD, 1=720p, 2=1080p, 3=Highest Available
	stream_url = vid.streamURL() # This is what Kodi (XBMC) will play
	stream_url = stream_url.split('|')[0]
	xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=stream_url))

def playLIVE(url):
	debug("(navigator.playLIVE) ------------------------------------------------ START = playLIVE -----------------------------------------------")
	live_url = False
	try:
		content = getUrl(url)
		stream = re.compile('<video id="live-video".*?<source src="([^"]+?)" type="application/x-mpeg', re.DOTALL).findall(content)[0]
		code = urlopen(stream).getcode()
		if str(code) == '200': live_url = stream
	except: pass
	if live_url:
		debug("(navigator.playLIVE) ### LIVEurl : {0} ###".format(live_url))
		listitem = xbmcgui.ListItem(path=live_url, label=translation(30612))
		listitem.setMimeType('application/vnd.apple.mpegurl')
		xbmc.Player().play(item=live_url, listitem=listitem)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Live-Stream-Eintrag auf der Webseite von *weltderwunder.de* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('LIVE'), translation(30524), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def addDir(name, image, params={}, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Tvshowtitle': params.get('origSERIE'), 'Plot': plot, 'Duration': duration, 'Studio': 'WDW', 'Genre': 'Facts, Wissen', 'Mediatype': 'episode'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
