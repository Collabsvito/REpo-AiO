﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import io
import gzip
from bs4 import BeautifulSoup
import YDStreamExtractor
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus, unquote_plus  # Python 2.X
	from urllib2 import urlopen, build_opener  # Python 2.X
else: 
	from urllib.parse import urlencode, quote_plus, unquote_plus  # Python 2.X
	from urllib.request import urlopen, build_opener  # Python 3+


global debuging
HOST_AND_PATH          = sys.argv[0]
ADDON_HANDLE            = int(sys.argv[1])
dialog                                = xbmcgui.Dialog()
addon                                = xbmcaddon.Addon()
addon_id                           = addon.getAddonInfo('id')
addon_name                    = addon.getAddonInfo('name')
addon_version                 = addon.getAddonInfo('version')
TRANS_PATH                   = (xbmcvfs.translatePath if int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 19 else xbmc.translatePath)
addonPath                        = TRANS_PATH(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath                           = TRANS_PATH(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
defaultFanart                   = (os.path.join(addonPath, 'fanart.jpg') or os.path.join(addonPath, 'resources', 'fanart.jpg') or os.path.join(addonPath, 'resources', 'media', 'fanart.jpg'))
icon                                    = (os.path.join(addonPath, 'icon.png') or os.path.join(addonPath, 'resources', 'icon.png') or os.path.join(addonPath, 'resources', 'media', 'icon.png'))
artpic                                 = os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
prefQUALITY                    = int(addon.getSetting('prefVideoQuality'))
useThumbAsFanart         = addon.getSetting('useThumbAsFanart') == 'true'
enableADJUSTMENT       = addon.getSetting('show_settings') == 'true'
LOG_MESSAGE                 = (xbmc.LOGINFO if int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 19 else xbmc.LOGNOTICE)
BASE_URL                         = 'https://www.weltderwunder.de/'

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py2_enc(s, nom='utf-8', ign='ignore'):
	if PY2:
		if not isinstance(s, basestring):
			s = str(s)
		s = s.encode(nom, ign) if isinstance(s, unicode) else s
	return s

def py2_uni(s, nom='utf-8', ign='ignore'):
	if PY2 and isinstance(s, str):
		s = unicode(s, nom, ign)
	return s

def py3_dec(d, nom='utf-8', ign='ignore'):
	if not PY2 and isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return py2_enc(addon.getLocalizedString(id))

def failing(content):
	log(content, xbmc.LOGERROR)

def debug(content):
	log(content, xbmc.LOGDEBUG)

def log(msg, level=LOG_MESSAGE):
	msg = py2_enc(msg)
	return xbmc.log('[{0} v.{1}]{2}'.format(addon_id, addon_version, msg), level)

def build_url(query):
	return '{0}?{1}'.format(HOST_AND_PATH, urlencode(query))

def getUrl(url, header=None, data=None, agent='Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0'):
	opener = build_opener()
	opener.addheaders = [('User-Agent', agent), ('Accept-Encoding', 'gzip, identity')]
	try:
		if header: opener.addheaders = header
		response = opener.open(url, data=data, timeout=30)
		if response.info().get('Content-Encoding') == 'gzip':
			link = py3_dec(gzip.GzipFile(fileobj=io.BytesIO(response.read())).read())
		else:
			link = py3_dec(response.read())
	except Exception as e:
		failure = str(e)
		failing("(common.getHTML) ERROR - ERROR - ERROR : ########## {0} === {1} ##########".format(url, failure))
		dialog.notification(translation(30521).format('URL'), "ERROR = [COLOR red]{0}[/COLOR]".format(failure), icon, 15000)
		return sys.exit(0)
	return py2_enc(link)

def utc_to_local(dt):
	if time.localtime().tm_isdst and time.daylight: return dt - timedelta(seconds=time.altzone)
	else: return dt - timedelta(seconds=time.timezone)

def cleanPhoto(img):
	img = py2_enc(img)
	for p in ((' ', '%20'), ('ß', '%C3%9F'), ('ä', '%C3%A4'), ('ö', '%C3%B6'), ('ü', '%C3%BC'),
				('à', '%C3%A0'), ('á', '%C3%A1'), ('â', '%C3%A2'), ('è', '%C3%A8'), ('é', '%C3%A9'), ('ê', '%C3%AA'), ('ì', '%C3%AC'), ('í', '%C3%AD'), ('î', '%C3%AE'),
				('ò', '%C3%B2'), ('ó', '%C3%B3'), ('ô', '%C3%B4'), ('ù', '%C3%B9'), ('ú', '%C3%BA'), ('û', '%C3%BB'), ('width/500', 'width/1280')):
				img = img.replace(*p)
	return img.strip()

def parameters_string_to_dict(parameters):
	paramDict = {}
	if parameters:
		paramPairs = parameters[1:].split('&')
		for paramsPair in paramPairs:
			paramSplits = paramsPair.split('=')
			if (len(paramSplits)) == 2:
				paramDict[paramSplits[0]] = paramSplits[1]
	return paramDict

params = parameters_string_to_dict(sys.argv[2])
url = unquote_plus(params.get('url', ''))
mode = unquote_plus(params.get('mode', 'root'))
image = unquote_plus(params.get('image', ''))
page = unquote_plus(params.get('page', '1'))
origSERIE = unquote_plus(params.get('origSERIE', ''))
extras = unquote_plus(params.get('extras', 'standard'))
