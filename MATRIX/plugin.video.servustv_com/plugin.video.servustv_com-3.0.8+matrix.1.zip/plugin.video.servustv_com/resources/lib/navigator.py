﻿# -*- coding: utf-8 -*-

from .common import *
from .records import get_ListItem
from .utilities import Transmission


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	addDir(translation(30601), f"{artpic}favourites.png", {'mode': 'listFavorites'})
	addDir(translation(30602), f"{artpic}overviews.png", {'mode': 'listGenerals', 'url': 'calendar', 'phrase': 'products'})
	addDir(translation(30603), f"{artpic}overviews.png", {'mode': 'listGenerals', 'url': 'discover', 'phrase': 'products'})
	addDir(translation(30604), f"{artpic}overviews.png", {'mode': 'listGenerals', 'url': 'latest-videos', 'phrase': 'collections'})
	addDir(translation(30605), f"{artpic}overviews.png", {'mode': 'listGenerals', 'url': 'e2fda2e1-58ff-4474-a49a-a2df01309998', 'phrase': 'collections'})
	addDir(translation(30606), f"{artpic}overviews.png", {'mode': 'listGenerals', 'url': 'discover-featured', 'phrase': 'collections'})
	addDir(translation(30607), f"{artpic}overviews.png", {'mode': 'listGenerals', 'url': 'latest-films', 'phrase': 'collections'})
	addDir(translation(30608), f"{artpic}overviews.png", {'mode': 'listGenerals', 'url': 'subchannels', 'phrase': 'collections'})
	addDir(translation(30609), f"{artpic}overviews.png", {'mode': 'listGenerals', 'url': 'shows', 'phrase': 'products'})
	addDir(translation(30610), f"{artpic}basesearch.png", {'mode': 'SearchSERVUSTV'})
	addDir(translation(30611), f"{artpic}channels.png", {'mode': 'listChannels'})
	addDir(translation(30612), f"{artpic}livestream.png", {'mode': 'playVideo', 'action': 'LIVE_PLAY'}, folder=False)
	ACCESS, CANTON = Transmission().check_FreeToken()
	if CANTON:
		NATION = CANTON.replace('ch', 'suisse').replace('at', translation(30623)).replace('de', translation(30624)).replace('suisse', translation(30625)).replace(CANTON, CANTON.upper())
		TEXTBOX = translation(30621).format(NATION)
	else: TEXTBOX = translation(30622)
	if textSelection == 0: LAYOUT = translation(30613)+TEXTBOX
	elif textSelection == 1: LAYOUT = TEXTBOX+translation(30613)
	elif textSelection == 2: LAYOUT = TEXTBOX
	else: LAYOUT = translation(30613)
	if enableADJUSTMENT:
		addDir(LAYOUT,f"{artpic}settings.png", {'mode': 'aConfigs'}, folder=False)
		if ADDON_operate('inputstream.adaptive'):
			addDir(translation(30614), f"{artpic}settings.png", {'mode': 'iConfigs'}, folder=False)
	else:
		addDir(TEXTBOX, icon, {'mode': 'blankFUNC', 'url': '00'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def unsubscribe():
	debug_MS("(navigator.unsubscribe) -------------------------------------------------- START = unsubscribe --------------------------------------------------")
	if xbmcvfs.exists(servFile) and os.path.isdir(tempSERV):
		debug_MS("(navigator.unsubscribe[1]) XXXXX USER FORCE REMOVING TOKEN - DELETE TOKENFILE XXXXX")
		shutil.rmtree(tempSERV, ignore_errors=True)
		return dialog.notification(translation(30529), translation(30530), icon, 8000)
	return dialog.ok(addon_id, translation(30503))

def message(NOTE):
	debug_MS("(navigator.message) -------------------------------------------------- START = message --------------------------------------------------")
	return dialog.ok(addon_name, translation(30504).format(NOTE))

def listGenerals(TARGET, PHRASE, QUERY, PAGE, LIMIT):
	debug_MS("(navigator.listGenerals) -------------------------------------------------- START = listGenerals --------------------------------------------------")
	debug_MS(f"(navigator.listGenerals) ### URL = {TARGET} || PHRASE = {PHRASE} || QUERY = {QUERY} || PAGE = {PAGE} || LIMIT = {LIMIT} ###")
	FOUND = 0
	# https://api.redbull.tv/collections/v4/subchannels?namespace=stv&offset=0&limit=20
	# https://api.redbull.tv/collections/v4/shows?namespace=stv&offset=0&limit=20
	# https://api.redbull.tv/playlists/v4/a4111699-89f7-48aa-954f-cca1116fec70?namespace=stv&offset=0&limit=20
	# https://api.redbull.tv/v3/search?q=nachrichten&collection_type=top_results&namespace=stv&offset=0&limit=20
	NEW_URL = f"{SERTV_AP4.format(PHRASE, TARGET)}?namespace=stv&offset={str((int(PAGE) - 1) * int(LIMIT))}&limit={LIMIT}"
	if QUERY != 'NOTHING':
		NEW_URL = f"{SERTV_AV3}{PHRASE}?q={QUERY}&namespace=stv&offset={str((int(PAGE) - 1) * int(LIMIT))}&limit={LIMIT}"
	DATA = Transmission().retrieveContent(NEW_URL)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listGenerals[1]) XXXXX CONTENT-01 : {str(DATA)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	aback, GAP = DATA, DATA
	if DATA.get('links', ''):
		for link in DATA.get('links', []):
			FOUND += 1
			LINKING(link, 'PRODUCT', PHRASE, '(list[LINKS], no.1)', aback)
	if DATA.get('collections', ''):
		if DATA.get('collections', [])[0].get('collection_type', '') == 'top_results' and QUERY != 'NOTHING':
			GAP = DATA['collections'][0] # Set Searchresults to next Level
		else:
			for collection in DATA.get('collections', []): ### AUSSCHLIESSEN: a1ee3b51-f893-46c9-a578-f55594e899f3 = Beliebte Themen / 6ce91711-d1a7-4491-b65c-7ce50e806bcf = Weiter ansehen / 73cb1c8b-5d44-4652-985b-34f13ee42661 = Favoriten / 73053000-1088-4462-8ce1-aa7e86c7227f = On-Kanäle ###
				if collection.get('list_type', '') == 'reference': continue
				FOUND += 1
				LINKING(collection, 'COLLECTION', PHRASE, '(list[COLLECTIONS], no.1)', aback)
	if GAP.get('items', ''):
		CAT = 'THEME' if 'subchannels' in TARGET else 'PRODUCT'
		for item in GAP.get('items', []):
			if item.get('type', '') == 'video' and item.get('content_type', '') != 'live_program' and (item.get('playable', '') is False or not item.get('duration', '')):
				continue
			FOUND += 1
			LINKING(item, CAT, PHRASE, '(list[ITEMS], no.1)', aback)
	if FOUND == 0:
		return dialog.notification(translation(30524).format('Ergebnisse'), translation(30525), icon, 8000)
	if GAP.get('meta', '') and GAP['meta'].get('total', '') and isinstance(GAP['meta']['total'], int) and int(GAP['meta']['total']) > int(PAGE)*int(LIMIT):
		debug_MS(f"(navigator.listGenerals[2]) NEXTPAGES ### Now show NextPage ... No.{str(int(PAGE)+1)} ... ###")
		addDir(translation(30631).format(int(PAGE)+1), f"{artpic}nextpage.png", {'mode': 'listGenerals', 'url': TARGET, 'phrase': PHRASE, 'searching': QUERY,  'page': int(PAGE)+1})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listThemes(TARGET, PHRASE, PAGE, LIMIT):
	debug_MS("(navigator.listThemes) -------------------------------------------------- START = listThemes --------------------------------------------------")
	debug_MS(f"(navigator.listThemes) ### URL = {TARGET} || PHRASE = {PHRASE} || PAGE = {PAGE} || LIMIT = {LIMIT} ###")
	COMBINATION, FOUND = [], 0
	# https://api.redbull.tv/products/v4/sports?namespace=stv&&offset=0limit=20
	SPECIAL = ['/culture', '/entertainment', '/folk-culture', '/nature', '/science', '/sports']
	FIRST_URL = f"{SERTV_AP4.format('products', TARGET)}?namespace=stv&offset={str((int(PAGE) - 1) * int(LIMIT))}&limit={LIMIT}"
	DATA_ONE = Transmission().retrieveContent(FIRST_URL)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listThemes[1]) XXXXX DATA_ONE-01 : {str(DATA_ONE)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	aback, GAP = DATA_ONE, DATA_ONE
	if DATA_ONE.get('collections', ''):
		for collection in DATA_ONE.get('collections', []):
			firsttitle = collection['label'] if collection.get('label', '') else ""
			if collection.get('list_type', '') == 'reference' or 'Mehr zu: ' in firsttitle:
				continue
			COMBINATION.append(firsttitle.lower())
			FOUND += 1
			LINKING(collection, 'COLLECTION', PHRASE, '(list[THEMES], no.1)', aback)
	if any(x in FIRST_URL.strip().lower() for x in SPECIAL):
		# https://api.redbull.tv/collections/v4/nature-latest-shows?namespace=stv&offset=0&limit=20
		SUFFIX_URL = f"{SERTV_AP4.format('collections', TARGET)}-latest-shows?namespace=stv&offset={str((int(PAGE) - 1) * int(LIMIT))}&limit={LIMIT}"
		DATA_TWO = Transmission().retrieveContent(SUFFIX_URL)
		debug_MS("++++++++++++++++++++++++")
		debug_MS(f"(navigator.listThemes[2]) XXXXX DATA_TWO-02 : {str(DATA_TWO)} XXXXX")
		debug_MS("++++++++++++++++++++++++")
		if DATA_TWO.get('items', ''):
			for item in DATA_TWO.get('items', []):
				if str(item.get('title')).lower() not in COMBINATION:
					FOUND += 1
					LINKING(item, 'PRODUCT', PHRASE, '(list[THEMES], no.2)', aback)
	if FOUND == 0:
		return dialog.notification(translation(30524).format('Ergebnisse'), translation(30525), icon, 8000)
	if GAP.get('meta', '') and GAP['meta'].get('total', '') and isinstance(GAP['meta']['total'], int) and int(GAP['meta']['total']) > int(PAGE)*int(LIMIT):
		debug_MS(f"(navigator.listThemes[3]) NEXTPAGES ### Now show NextPage ... No.{str(int(PAGE)+1)} ... ###")
		addDir(translation(30631).format(int(PAGE)+1), f"{artpic}nextpage.png", {'mode': 'listThemes', 'url': TARGET, 'phrase': PHRASE, 'page': int(PAGE)+1})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchSERVUSTV():
	debug_MS("(navigator.SearchSERVUSTV) ------------------------------------------------ START = SearchSERVUSTV -----------------------------------------------")
	keyword = None # https://api.redbull.tv/v3/search?q=nachrichten&collection_type=top_results&namespace=stv&offset=0&limit=20
	if xbmcvfs.exists(SEARCHFILE):
		with open(SEARCHFILE, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30632), type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
		if keyword:
			keyword = quote(keyword)
			with open(SEARCHFILE, 'w') as record:
				record.write(keyword)
	if keyword: return listGenerals('enquiries', 'search', f"{keyword}&collection_type=top_results", page, limit)
	return None

def listChannels():
	debug_MS("(navigator.listChannels) ------------------------------------------------ START = listChannels -----------------------------------------------")
	CHANNELS = [{'ne': 'Bergwelten ON','cid': 'nature'},{'ne': 'Sport ON','cid': 'sports'},{'ne': 'Wetterpanorama ON','cid': 'wetterpanorama'},
		{'ne': 'Wissen ON','cid': 'science'},{'ne': 'World of Redbull','cid': 'linear-rb-worb'},{'ne': 'Wintersport ON','cid': 'wintersport'}]
	COMBINATION, FOUND , (ACCESS, CANTON) = [], 0, Transmission().check_FreeToken()
	if ACCESS: # https://dms.redbull.tv/v5/destination/stv/wetterpanorama/personal_computer/http/at/de/playlist.m3u8
		for CHAN in CHANNELS: # https://api.redbull.tv/v3/guides/science?namespace=stv&offset=0&limit=20 / EPG for ON Channels
			DATA_ONE = Transmission().retrieveContent(f"{SERTV_AV3}guides/{CHAN['cid']}?namespace=stv&offset=0&limit=20")
			if CHAN['cid'] == 'wintersport' and CANTON.lower() not in ['at', 'de']: continue # 'Category wintersport' is only available in CANTON ['at', 'de'] therefore here it is excluded
			STREAM = f"{SERTV_HLS[:-3]}playlists/{ACCESS}/{CHAN['cid']}_{CANTON.lower()}/hls6/playlist.m3u8" # Only 'sports' and 'wintersport' with CANTON, if CANTON in ['at', 'de']
			if (CHAN['cid'] in ['nature', 'science']) or (CHAN['cid'] == 'sports' and CANTON.lower() not in ['at', 'de']): # Only 'nature' and 'science' for all CANTONS or 'sports' if CANTON not in ['at', 'de'] = here without CANTON definition
				STREAM = f"{SERTV_HLS[:-3]}playlists/{ACCESS}/{CHAN['cid']}/hls6/playlist.m3u8"
			elif CHAN['cid'] in ['wetterpanorama', 'linear-rb-worb']: # Only 'wetterpanorama' and 'linear-rb-worb' as normal 'm3u8' request
				STREAM = f"{SERTV_HLS}destination/stv/{CHAN['cid']}/personal_computer/http/{CANTON.lower()}/de/playlist.m3u8"
			debug_MS(f"(navigator.listChannels[1]) ##### TITLE : {CHAN['ne']} || CHANNEL_URL : {STREAM} #####")
			for item in DATA_ONE.get('items', [])[:6]:
				debug_MS(f"(navigator.listChannels[2]) xxxxx ITEM-02 : {str(item)} xxxxx")
				startTIMES, description, exsin = None, ' ', '\r\n'
				FOUND += 1
				if item.get('start_time', '') and str(item['start_time'])[:4].isdigit():
					LOCALstart = get_CentralTime(item['start_time'])
					startTIMES = LOCALstart.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('.', '•', ':')
				name = item['label'].strip()
				epis_one = item['chapter'].split(' -')[0].replace('01 Servus Wintersport: ', '').strip() if item.get('chapter', '') else None
				epis_two = f" - {item['title'].strip()}" if item.get('title', '') and item['title'].strip().lower() != name.lower() else '   FAST - STREAM' if item.get('title', '') and item['title'].strip().lower() == name.lower() else None
				episode = epis_one+epis_two if epis_one and epis_two and epis_one not in epis_two else epis_two[3:] if epis_two else None
				if item.get('short_description', '') and len(item['short_description']) > 10:
					description = f"[CR][CR]{item['short_description'][:300].replace(exsin, '').strip()}..." if len(item['short_description']) > 300 else f"[CR][CR]{item['short_description'].replace(exsin, '').strip()}"
				if description == ' ' and item.get('long_description', '') and len(item['long_description']) > 10:
					description = f"[CR][CR]{item['long_description'][:300].replace(exsin, '').strip()}..." if len(item['long_description']) > 300 else f"[CR][CR]{item['long_description'].replace(exsin, '').strip()}"
				episode = 'FAST - STREAM' if CHAN['cid'] == 'linear-rb-worb' else 'LIVE - STREAM' if CHAN['cid'] == 'wetterpanorama' else episode
				description = description if CHAN['cid'] != 'wetterpanorama' else "[CR][CR]ServusTV On liefert Ihnen täglich die schönsten Blickwinkel aus dem Alpenraum direkt in Ihr Wohnzimmer. Wir versorgen Sie mit einer aktuellen Wettervorhersage zu jedem Standort."
				if startTIMES and episode:
					COMBINATION.append([CHAN['ne'], CHAN['cid'], startTIMES, name, episode, description])
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
			stories = '[CR][CR]'.join([translation(30641).format(each[2], str(each[3]), str(each[4]), each[5]) for each in COMBINATION if each[1] == CHAN['cid']])
			addDir(f"[B]{CHAN['ne']}[/B]", f"{artpic}{CHAN['cid']}.png", {'mode': 'playVideo', 'url': STREAM, 'action': f"LIVE_PLAY@@{CHAN['ne']}@@{CHAN['cid']}@@Start: {stories.split('Start: ')[1].split('Start: ')[0]}@@"}, stories, folder=False)
	if FOUND == 0:
		return dialog.notification(translation(30524).format('Einträge'), translation(30526).format('ON - Kanäle'), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def playVideo(UUID, RIDERS):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	(FINAL_URL, TEST_URL), (ACCESS, CANTON) = (False for _ in range(2)), Transmission().check_FreeToken()
	if ACCESS:
		if RIDERS.startswith(('LIVE_PLAY', 'EVENT_PLAY')):
			SECTION = RIDERS.split('@@')
			if RIDERS.startswith('LIVE_PLAY'):
				TITLE = translation(30642).format(CANTON.upper())
				THUMB, ASSET, FINAL_URL = f"{artpic}livestream.png", 'LIVE', f"{SERTV_HLS}stv-linear/{ACCESS}/playlist.m3u8?namespace=stv"
				if UUID.startswith('https'):
					TITLE = translation(30643).format(re.sub(r'(\[B\]|\[/B\])', '', SECTION[1]), CANTON.upper())
					THUMB, ASSET, FINAL_URL = f"{artpic}{SECTION[2]}.png", 'FAST', UUID
				PLOT = SECTION[3] if len(SECTION) > 4 else ' '
			elif RIDERS.startswith('EVENT_PLAY'):
				TITLE, THUMB, ASSET, PLOT = re.sub(r'(\[B\]|\[/B\])', '', SECTION[1]), SECTION[2], 'EVENT', SECTION[3]
				FINAL_URL = f"{SERTV_HLS}{UUID}/{ACCESS}/playlist.m3u8?namespace=stv"
		else:
			ASSET, FINAL_URL = 'HLS', f"{SERTV_HLS}{UUID}/{ACCESS}/playlist.m3u8?namespace=stv"
		VERIFY = Transmission().retrieveContent(FINAL_URL, 'TRACK', timeout=15)
		if VERIFY and VERIFY.status_code in [200, 201, 202, 300, 301, 302]: TEST_URL = True
	if FINAL_URL and TEST_URL:
		if RIDERS.startswith(('LIVE_PLAY', 'EVENT_PLAY')):
			LPM = xbmcgui.ListItem(TITLE, path=FINAL_URL)
			if KODI_ov20:
				tracts = LPM.getVideoInfoTag()
				tracts.setTitle(TITLE), tracts.setPlot(PLOT), tracts.setStudios(['ServusTV'])
			else:
				LPM.setInfo('Video', {'Title' : TITLE, 'Plot' : PLOT, 'Studio' : 'ServusTV'})
			LPM.setArt({'icon': icon, 'thumb': THUMB, 'poster': THUMB, 'fanart': defaultFanart})
		else:
			LPM = xbmcgui.ListItem(path=FINAL_URL)
		LPM.setMimeType('application/vnd.apple.mpegurl')
		if ADDON_operate('inputstream.adaptive'):
			LPM.setProperty('inputstream', 'inputstream.adaptive')
			if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				LPM.setProperty('inputstream.adaptive.manifest_type', 'hls')
				LPM.setProperty('inputstream.adaptive.manifest_update_parameter', 'full') # THE "full" BEHAVIOUR PARAM HAS BEEN REMOVED ON Kodi v21 because now enabled by default.
			if KODI_ov20:
				LPM.setProperty('inputstream.adaptive.manifest_headers', f"User-Agent={defaultAgent}") # On KODI v20 and above
			else:
				LPM.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={defaultAgent}") # On KODI v19 and below
			if RIDERS.startswith(('LIVE_PLAY', 'EVENT_PLAY')):
				LPM.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true') # If possible allow to start playing a LIVE stream from the beginning of the buffer instead of its end.
		if RIDERS.startswith(('LIVE_PLAY', 'EVENT_PLAY')):
			xbmc.Player().play(item=FINAL_URL, listitem=LPM)
		else:
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		log(f"(navigator.playVideo) {ASSET}_stream : {FINAL_URL}")
	elif FINAL_URL and not TEST_URL:
		failing(f"(navigator.playVideo[1]) ##### Abspielen des Streams NICHT möglich #####\n ##### ERROR_CODE : {str(VERIFY.status_code)} || FINAL_URL : {FINAL_URL} #####\n ########## Die Wiedergabe wurde geblockt !!! ##########")
		return dialog.notification(translation(30521).format('PLAY'), translation(30523).format(f"[B]Code: {str(VERIFY.status_code)}|Text: Zugriff verweigert[/B]"), icon, 10000)
	else:
		failing("(navigator.playVideo[1]) ##### Abspielen des Streams NICHT möglich #####\n ########## Der erforderliche Token wurde leider NICHT gefunden !!! ##########")
		return dialog.notification(translation(30521).format('TOKEN'), translation(30528), icon, 10000)

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as fp:
			watch = json.load(fp)
			for item in watch.get('items', []):
				name = item.get('name')
				logo = icon if item.get('pict', 'None') == 'None' else item.get('pict')
				debug_MS(f"(navigator.listFavorites[1]) ### NAME : {name} || URL : {item.get('url')} || IMAGE : {logo} || cineType : {item.get('cineType')} ###")
				addDir(name, logo, {'mode': 'listGenerals', 'url': item.get('url'), 'wallpaper': item.get('wallpaper'), 'cineType': item.get('cineType')}, item.get('plot'), FAVclear=True)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favs(*args):
	TOPS = {}
	TOPS['items'] = []
	if xbmcvfs.exists(channelFavsFile):
		with open(channelFavsFile, 'r') as output:
			TOPS = json.load(output)
	if action == 'ADD':
		TOPS['items'].append({'name': name, 'pict': pict, 'url': url, 'plot': plot, 'wallpaper': wallpaper, 'cineType': cineType})
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.sleep(500)
		dialog.notification(translation(30531), translation(30532).format(name), icon, 8000)
	elif action == 'DEL':
		TOPS['items'] = [obj for obj in TOPS['items'] if obj.get('url') != url]
		with open(channelFavsFile, 'w') as input:
			json.dump(TOPS, input, indent=4, sort_keys=True)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30531), translation(30533).format(name), icon, 8000)

def LINKING(info, category=None, phrase=None, extras=None, aback=None):
	uvz, LEM, folder = get_ListItem(info, category, phrase, extras, aback)
	if uvz is None: return
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uvz, LEM, folder)

def addDir(name, image, params={}, plot=None, FAVclear=False, folder=True):
	uws = build_mass(params)
	LDM = xbmcgui.ListItem(name, offscreen=True)
	if plot in ['', 'None', None]: plot = ' '
	if KODI_ov20:
		vinfo = LDM.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setStudios(['ServusTV'])
	else:
		LDM.setInfo('Video', {'Title': name, 'Plot': plot, 'Studio': 'ServusTV'})
	LDM.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if 'wallpaper' in params and params.get('wallpaper') != 'DEFAULT' and not artpic in params.get('wallpaper'):
		LDM.setArt({'fanart': params.get('wallpaper')})
	if FAVclear is True:
		LDM.addContextMenuItems([(translation(30652), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'DEL', 'name': name, 'pict': image, 'url': params.get('url'),
			'plot': plot, 'wallpaper': params.get('wallpaper'), 'cineType': params.get('cineType')})))])
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, LDM, folder)
