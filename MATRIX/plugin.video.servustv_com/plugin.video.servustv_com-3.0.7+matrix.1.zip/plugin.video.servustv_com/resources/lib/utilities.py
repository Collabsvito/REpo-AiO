﻿# -*- coding: utf-8 -*-

from .common import *


def _header(REFERRER=None, USERTOKEN=None):
	header = {}
	header['Connection'] = 'keep-alive'
	header['Pragma'] = 'no-cache'
	header['Cache-Control'] = 'no-cache'
	header['User-Agent'] = get_userAgent()
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	header['Accept-Language'] = 'en-US,en;q=0.8,de;q=0.7'
	header['Origin'] = 'https://www.servustv.com'
	if REFERRER:
		header['Referer'] = REFERRER
	if USERTOKEN:
		header['Authorization'] = USERTOKEN
	return header

class Transmission(object):

	def __init__(self):
		self.maxTokenTime = tokenDelay * 60 * 60 # max. Token-Time (Seconds) before clear the Token and delete Token-File [4*60*60 = 4 hours | 8*60*60 = 8 hours | 12*60*60 = 12 hours]
		self.tempTO_folder = tempTN
		self.token_file = tokenFile
		self.NOW_UTC = time.time() # UTC Datetime now
		self.verify_ssl = (True if addon.getSetting('verify_ssl') == 'true' else False)
		self.session = requests.Session()

	def clear_special(self, filename, foldername):
		debug_MS("(utilities.clear_special) ##### START clear_special #####")
		if filename is not None and os.path.isfile(filename):
			if xbmcvfs.exists(foldername) and os.path.isdir(foldername):
				shutil.rmtree(foldername, ignore_errors=True)

	def save_special(self, filename, foldername, text=""):
		debug_MS("(utilities.save_special) ##### START save_special #####")
		if not xbmcvfs.exists(foldername) and not os.path.isdir(foldername):
			xbmcvfs.mkdirs(foldername)
		with open(filename, 'w') as save:
			json.dump(text, save, indent=4, sort_keys=True)

	def convert_epoch(self, epoch):
		eCipher = datetime(1970,1,1) + timedelta(seconds=int(epoch))
		return eCipher.strftime('%d{0}%m{0}%y {1} %H{2}%M{2}%S').format('.', '•', ':')

	def check_FreeToken(self):
		debug_MS("(utilities.check_FreeToken) ##### START check_FreeToken #####")
		forceRenew, USERTOKEN, USERCOUNTRY = (False for _ in range(3))
		if self.maxTokenTime > 1 and self.token_file is not None and os.path.isfile(self.token_file):
			self.FILE_UTC = (os.path.getmtime(self.token_file) + self.maxTokenTime)
			debug_MS("(utilities.check_FreeToken) ##### SESSION-Time (utc NOW) = {} || VALID until (utc SESSION) = {} #####".format(str(self.convert_epoch(self.NOW_UTC)), str(self.convert_epoch(self.FILE_UTC))))
			if self.NOW_UTC < self.FILE_UTC:
				try:
					with open(self.token_file, 'r') as output:
						DATA = json.load(output)
					USERTOKEN = DATA['token']
					USERCOUNTRY = DATA['country_code']
					debug_MS("(utilities.check_FreeToken) ##### NOTHING CHANGED - TOKENFILE OKAY #####")
				except:
					failing("(utilities.check_FreeToken) XXXXX !!! ERROR = TOKENFILE [TOKENFORMAT IS INVALID] = ERROR !!! XXXXX")
					forceRenew = True
			else:
				debug_MS("(utilities.check_FreeToken) ##### TIMEOUT FOR TOKEN - DELETE TOKENFILE #####")
				forceRenew = True
		else:
			debug_MS("(utilities.check_FreeToken) ##### NOTHING FOUND - SEARCH FOR NEW TOKEN #####")
			forceRenew = True
		if forceRenew:
			if self.token_file is not None and os.path.isfile(self.token_file):
				self.clear_special(self.token_file, self.tempTO_folder)
			CODING = self.retrieveContent(SERVUSTV_API+'session?namespace=stv&category=personal_computer&os_family=http')
			if CODING:
				if self.maxTokenTime > 1:
					debug_MS("(utilities.check_FreeToken) ***** NEW TOKENFILE CREATED : {} *****".format(CODING))
					self.save_special(self.token_file, self.tempTO_folder, CODING)
				else:
					debug_MS("(utilities.check_FreeToken) XXXXX YOU ARE IN LIVE-SESSION WITHOUT SAVING TOKEN - EVERTHING OKAY XXXXX")
				USERTOKEN = CODING['token']
				USERCOUNTRY = CODING['country_code']
		return (USERTOKEN, USERCOUNTRY)

	def retrieveContent(self, url, method='GET', REF=None, forcing=False, headers=None, cookies=None, allow_redirects=True, stream=None, data=None, json=None):
		ACCESS, CANTON, ANSWER = (None for _ in range(3))
		if forcing is True:
			ACCESS, CANTON = self.check_FreeToken()
		try:
			response = self.session.get(url, headers=_header(REF, ACCESS), allow_redirects=allow_redirects, verify=self.verify_ssl, stream=stream, timeout=30)
			ANSWER = response.json() if method in ['GET', 'POST'] else response.text if method == 'LOAD' else response
			debug_MS("(common.getUrl) === CALLBACK === status : {} || url : {} || header : {} ===".format(response.status_code, response.url, _header(REF, ACCESS)))
		except requests.exceptions.RequestException as e:
			failing("(common.getUrl) ERROR - ERROR - ERROR ##### url: {} === error: {} #####".format(url, str(e)))
			dialog.notification(translation(30521).format('URL'), translation(30523).format(str(e)), icon, 12000)
			return sys.exit(0)
		return ANSWER
