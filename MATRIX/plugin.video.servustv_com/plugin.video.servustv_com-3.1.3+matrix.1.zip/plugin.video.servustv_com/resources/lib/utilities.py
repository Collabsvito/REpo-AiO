﻿# -*- coding: utf-8 -*-

from .common import *


class clientHelper():
	def __init__(self, *args, **kwargs):
		super(clientHelper, self).__init__()
		self.expire_public = token_delay*60*60 # max. Token-Time (Seconds) before clear the Token and delete Token-File
		self.tempSTORE = tempSTORE
		self.savePUBLIC = publicSECRET
		self.signMARKET = MARKETS

	def convert_epoch(self, epoch):
		CIPHER = datetime(1970,1,1) + timedelta(seconds=int(epoch))
		return CIPHER.strftime('%d.%m.%Y - %H:%M:%S')

	def check_authtoken(self):
		CODING, forceRenew, TOKEN, COUNTRY = False, False, None, None
		GUARDIA, SECURITY, PLACED, TIME_UTC = self.tempSTORE, self.savePUBLIC, self.signMARKET, time.time()
		if self.expire_public > 1 and preserve(SECURITY) is not None:
			try:
				TOKEN_UTC = (os.path.getmtime(SECURITY) + self.expire_public)
				debug_MS(f"(utilities.check_authtoken) ### SESSION-Time (utc NOW) = {self.convert_epoch(TIME_UTC)} || VALID until (utc SESSION) = {self.convert_epoch(TOKEN_UTC)} ###")
				if TIME_UTC < TOKEN_UTC:
					ACC_DATA = preserve(SECURITY)
					TOKEN, COUNTRY = ACC_DATA['token'], ACC_DATA['country_code']
					if PLACED != COUNTRY:
						failing(f"(utilities.check_authtoken) ERROR - ACCORDANCE - ERROR ##### USER-COUNTRY : {PLACED.upper()} vs. TOKEN-COUNTRY : {COUNTRY.upper()} #####")
						forceRenew = True
					else: debug_MS("(utilities.check_authtoken) ### NOTHING CHANGED - TOKENFILE IS OKAY ###")
				else:
					debug_MS("(utilities.check_authtoken) ### TIMEOUT FOR TOKEN - DELETE TOKENFILE ###")
					forceRenew = True
			except:
				failing("(utilities.check_authtoken) XXXXX !!! ERROR = TOKENFILE [TOKENFORMAT IS INVALID] = ERROR !!! XXXXX")
				forceRenew = True
		else:
			debug_MS("(utilities.check_authtoken) ### NOTHING FOUND - CREATE TOKENFILE FOR SERVUSTV ###")
			forceRenew = True
		if forceRenew:
			if preserve(SECURITY) is not None:
				shutil.rmtree(GUARDIA, ignore_errors=True)
			CODING = self.track_content(BULL_ACCESS, headers=WEB_HEADER)
			if CODING:
				if self.expire_public > 1:
					debug_MS(f"(utilities.check_FreeToken) ***** NEW TOKENFILE CREATED : {CODING} *****")
					if not xbmcvfs.exists(GUARDIA) and not os.path.isdir(GUARDIA):
						xbmcvfs.mkdirs(GUARDIA)
					preserve(SECURITY, 'JSON', CODING)
				else:
					debug_MS("(utilities.check_FreeToken) XXXXX YOU ARE IN LIVE-SESSION WITHOUT SAVING TOKEN - EVERTHING OKAY XXXXX")
				TOKEN, COUNTRY = CODING['token'], CODING['country_code']
		return (TOKEN, COUNTRY)

	def track_several(self, stacks, method='GET', queries='JSON', headers={}, timeout=5, redirects=True, workers=20):
		COMBI_NEW, number, counter, fixation, = [], len(stacks), 0, requests.Session()
		fixation.mount('https://', HTTPAdapter(pool_connections=int(number), pool_maxsize=int(number), pool_block=True)) # Pool-Verbindungen und -Grösse auf tatsächlichen Inhalt festlegen, um Fehlermeldungen zu vermeiden
		def download(pos, code, link):
			try:
				response = fixation.request(method, link, headers=headers, allow_redirects=redirects, timeout=timeout)
				response.raise_for_status()
				debug_MS(f"(utilities.track_several[1]) === POS : {pos} || STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
				return f'{{"Count_2":{pos},"Code":"{code}","Link_2":"{link}",{response.text[1:-1]}}}'
			except Exception as exc_uno:
				failing(f"(utilities.track_several[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === URL : {link} === FAILURE : {exc_uno} #####")
				return f'{{"Position":{pos},"Status":"ERROR"}}'
		with ThreadPoolExecutor(max_workers=workers) as executor:
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++++")
			picker = [executor.submit(download, single['Count_1'], single['Code'], single['Link_1']) for single in stacks]
			wait(picker, timeout=30, return_when=ALL_COMPLETED)
			for future, section in zip(as_completed(picker), stacks):
				counter += 1
				try:
					COMBI_NEW.append(json.loads(future.result()))
				except Exception as exc_due:
					if counter == 1:
						dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(exc_due), f"{artpic}icon.png", 12000)
					failing(f"(utilities.track_several[2]) ERROR - EXEPTION - ERROR ##### POS : {section['Count_1']} === URL : {section['Link_1']} === FAILURE : {exc_due} #####")
					executor.shutdown()
			if COMBI_NEW:
				matching = [flop for flop in COMBI_NEW[:] if flop.get('Status', 'OOKAY') == 'ERROR']
				if len(matching) == number or len(matching) > 6:
					dialog.notification(translation(30521).format('DETAILS'), translation(30524), f"{artpic}icon.png", 12000)
		return json.dumps(COMBI_NEW, indent=2)

	def track_content(self, url, method='GET', queries='JSON', headers={}, raising=True, redirects=True, data=None, json=None, timeout=30):
		attempts, ANSWER = 0, None
		while not ANSWER and attempts < 2: # 2 x Pingversuche für den Request ::: zur Überprüfung der Verfügbarkeit der URL
			attempts += 1
			try:
				response = requests.request(method, url, headers=headers, allow_redirects=redirects, data=data, json=json, timeout=timeout)
				ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
				debug_MS(f"(utilities.track_content) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
				if raising is True: response.raise_for_status()
			except Exception as exc: # No JSON object could be decoded
				failing(f"(utilities.track_content) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {exc} #####")
				dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 12000)
				time.sleep(2)
				if attempts >= 2: return sys.exit(0)
		return ANSWER
