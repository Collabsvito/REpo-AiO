﻿# -*- coding: utf-8 -*-

from .common import *
from .utilities import clientHelper


def main_menu():
	(ACCESS, CANTON), (NATION, SHORT, FLAG) = clientHelper().check_authtoken(), country_check()
	if CANTON:
		allow = True if datetime.now() < datetime(*(time.strptime('2026-07-26T00:01', '%Y-%m-%dT%H:%M')[0:6])) else False # Rubrik: WM ab 26.07.26 ausblenden !!!
		for title, thumb, action in[(30601, 'favourites', {'mode': 'list_favorites'}),
			(30602 if allow else None, 'overviews', {'mode': 'list_overview', 'link': BULL_PRODUCT.format(CANTON, 'PNYL8SLYESOX3I8'), 'phase': 'products', 'extra': 'FIFA WM 2026'}),
			(30603, 'overviews', {'mode': 'list_overview', 'link': BULL_PRODUCT.format(CANTON, 'discover'), 'phase': 'products', 'extra': 'Startseite'}),
			(30604, 'overviews', {'mode': 'list_overview', 'link': BULL_PRODUCT.format(CANTON, 'calendar'), 'phase': 'products', 'extra': 'Events'}),
			(30605, 'overviews', {'mode': 'list_overview', 'link': BULL_PRODUCT.format(CANTON, 'PN7TCNATC1Q2LSY'), 'phase': 'products', 'extra': 'Sport'}),
			(30606, 'overviews', {'mode': 'list_overview', 'link': BULL_PRODUCT.format(CANTON, 'sendungen'), 'phase': 'products', 'extra': 'Sendungen'}),
			(30607, 'overviews', {'mode': 'list_overview', 'link': BULL_COLLECT.format(CANTON, 'subchannels', 0), 'phase': 'collections', 'extra': 'Themen'}),
			(30608, 'overviews', {'mode': 'list_overview', 'link': BULL_COLLECT.format(CANTON, 'c688c1d4-62f5-49e1-bd19-8e33242088cf', 0), 'phase': 'collections', 'extra': 'Spielfilme'}),
			(30609, 'overviews', {'mode': 'list_overview', 'link': BULL_PRODUCT.format(CANTON, 'shows'), 'phase': 'products', 'extra': 'Beliebte Shows'}),
			(30610, 'overviews', {'mode': 'list_overview', 'link': BULL_COLLECT.format(CANTON, 'latest-videos', 0), 'phase': 'collections', 'extra': 'Neue Videos'}),
			(30611, 'basesearch', {'mode': 'search_servus'}),
			(30612, 'channels', {'mode': 'list_channels', 'link': BULL_COLLECT.format(CANTON, '6e6475bc-d2f2-4593-b95f-ed0a74206c62', 0)})]:
			if str(title).isdecimal(): add_views(action, create_entries({'Title': translation(title), 'Image': f"{artpic}{thumb}.png"}))
		textbox = translation(30623).format(NATION, MARKETS.upper(), CANTON.upper())
	else: textbox = translation(30624)
	layout = translation(30621)+textbox if text_selection == 0 else textbox+translation(30621) if text_selection == 1 else textbox if text_selection == 2 else translation(30621)
	photo = f"{artpic}settings.png" if FLAG == 'unk' else FLAG
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': layout, 'Image': photo}), False)
		if plugin_operate('inputstream.adaptive'):
			add_views({'mode': 'ietuning'}, create_entries({'Title': translation(30622), 'Image': f"{artpic}settings.png"}), False)
	else: add_views({'mode': 'blankFUNC'}, create_entries({'Title': textbox, 'Image': photo}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def unsubscribe():
	debug_MS("(navigator.unsubscribe) -------------------------------------------------- START = unsubscribe --------------------------------------------------")
	if xbmcvfs.exists(tempSTORE) and os.path.isdir(tempSTORE):
		debug_MS("(navigator.unsubscribe[1]) XXXXX USER FORCE REMOVING TOKEN - DELETE TOKENFILE XXXXX")
		shutil.rmtree(tempSTORE, ignore_errors=True)
		return dialog.notification(translation(30530), translation(30531), icon, 10000)
	return dialog.ok(addon_id, translation(30503))

def message(notes):
	return dialog.ok(addon_name, translation(30504).format(re.sub(r'(\[.*?\]|  \(demnächst\)|  \(next\))', '', notes)))

def list_overview(target, phase, page, extra):
	debug_MS("(navigator.list_overview) -------------------------------------------------- START = list_overview --------------------------------------------------")
	debug_MS(f"(navigator.list_overview) ### URL = {target} || PHASE = {phase} || PAGE = {page} || EXTRA = {extra} ###")
	(merging, fetch_posts, fetch_items), (ACCESS, CANTON) = ({} for _ in range(3)), clientHelper().check_authtoken()
	counter, (transfer, thumb, poster, fanart), (combo_uno, combo_due) = 0, (None for _ in range(4)), ([] for _ in range(2))
	DATAS = extra if isinstance(extra, (dict, list)) else clientHelper().track_content(target, headers=WEB_HEADER)
	if '/products' in target:
		for each in DATAS.get('collections', {}): # type = page // cotent_type = event, system, stop
			if each.get('list_type') == 'reference' or each.get('id', None) is None or 'placeholder' in each.get('id'): continue # Hide Newsletter and other Scratch
			counter, transfer = counter.__add__(1), BULL_COLLECT.format(CANTON, each['id'], 0)
			combo_uno.append({'Count_1': int(counter), 'Code': each.get('id'), 'Link_1': transfer})
		if combo_uno:
			combo_due = _fetch_pages(combo_uno, 'cards')
			for item in sorted(combo_due, key=lambda sox: int(sox.get('Count_2', 0))):
				if item.get('Title_2').upper().startswith(('LIVE-KANÄLE', 'TV-KANÄLE')): continue # Hide Category 'Live/TV-Kanäle'
				debug_MS("-------------------------------------------------")
				debug_MS(f"(navigator.list_overview[1]) [PRODUCTS] ### COUNT-01 : {item.get('Count_2')} || EACH-01 : {item} ###")
				if len(combo_due) == 1: return list_overview(item.get('Link_2'), 'collections', 1, extra) # Open folder direct if only one folder exists
				fetch_items = {'Title': item.get('Title_2'), 'Image': f"{artpic}overviews.png"}
				add_views({'mode': 'list_overview', 'link': item.get('Link_2'), 'phase': 'collections', 'extra': f"ProductPages: {item.get('Title_2')}"}, create_entries(fetch_items))
	elif '/collections' in target:
		for num, item in enumerate(DATAS.get('cards', {}), 1):
			if item.get('type') == 'page' and item.get('content_type') != 'film': # type = page // cotent_type = event, film, show, system, subchannel, stop
				transfer, operation = BULL_PRODUCT.format(CANTON, item.get('id')), 'adding'
				side = create_substances(item, 'pages', 2, num)
				# [ident=0, condition=1, type=2, playable=3, name=4, clean_name=5, showtitle=6, tagline=7, desc=8, duration=9, season=10, episode=11, collate=12, date=13, aired=14, genre=15, thumb=16, poster=17, fanart=18]
				fetch_items = context = {'Code': side[0], 'Condition': side[1], 'Type': side[2], 'Title': side[4], 'TvShowTitle': side[6], 'Tagline': side[7], 'Plot': side[8], \
					'Season': side[10], 'Episode': side[11], 'Date': side[13], 'Aired': side[14], 'Genre': side[15], 'Image': side[16], 'Cover': side[17], 'Fanback': side[18]}
				if extra.startswith('ProductPages') and preserve(FAVORIT_FILE) is not None:
					for snippet in preserve(FAVORIT_FILE):
						if snippet.get('Code') == side[0]: operation = 'skipping'
				elif not extra.startswith('ProductPages'): operation = 'skipping'
				add_views({'mode': 'list_overview', 'link': transfer, 'phase': 'products', 'extra': f"CollectionPages: {side[5]}"}, create_entries(fetch_items), True, context, operation)
			elif item.get('type') == 'video' or item.get('content_type') == 'film': # type = video // cotent_type = clip, episode, live_program
				combo_uno.append({**item, **{'Count_1': num, 'Code': item.get('id'), 'Link_1': BULL_PRODUCT.format(CANTON, item.get('id'))}})
		if combo_uno:
			combo_due = _fetch_pages(combo_uno, 'dates') # https://stackoverflow.com/questions/56658669/combine-two-lists-of-dictionaries-by-value-of-key-in-dictionaries
			merging = [{**uno, **next(iter([due for due in combo_due if due.get('Code') == uno.get('Code')]), {})} for uno in combo_uno] # Merge two Lists of Dictionaries by specific value !!!
			for post in sorted(merging, key=lambda sox: sox.get('Count_2', 0)):
				movs = create_substances(post, 'videos', 3, post.get('Count_2'))
				# [ident=0, condition=1, type=2, playable=3, name=4, clean_name=5, showtitle=6, tagline=7, desc=8, duration=9, season=10, episode=11, collate=12, date=13, aired=14, genre=15, thumb=16, poster=17, fanart=18]
				fetching = {'Code': movs[0], 'Condition': movs[1], 'Type': movs[2], 'Title': movs[4], 'TvShowTitle': movs[6], 'Tagline': movs[7], 'Plot': movs[8], \
					'Season': movs[10], 'Episode': movs[11], 'Date': movs[13], 'Aired': movs[14], 'Genre': movs[15], 'Image': movs[16], 'Cover': movs[17], 'Fanback': movs[18]}
				if (movs[3] is True and movs[9] is not None) or movs[2] == 'movie': # Normal-Play if 'playable' and Duration is found:
					folder, ACTION = False, {'mode': 'play_video', 'link': movs[0]}
					fetch_posts = {**fetching, **{'Duration': movs[9], 'Mediatype': 'movie', 'Reference': 'Single'}}
				elif movs[3] is True and movs[1] in ['LIVE', 'POST']: # Special-Play if 'playable' and Event in ['LIVE', 'POST']
					ACTION = {'mode': 'play_video', 'link': movs[0], 'action': f"EVENT_PLAY@@{movs[4]}@@{movs[17]}@@{movs[8]}@@"}
					fetch_posts = {**fetching, **{'Mediatype': 'episode'}}
				elif movs[3] is False and movs[1] in ['TRIM', 'NEXT'] and movs[9] is None: # Message if not 'playable' and Duration not found
					ACTION, fetch_posts = {'mode': 'newsFUNC', 'extra': movs[5]}, fetching
				else: continue
				if transfer is None:
					for method in get_sorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
				add_views(ACTION, create_entries(fetch_posts), False, higher=True if int(page) > 1 else False)
			if DATAS.get('meta', '') and DATAS.get('meta', {}).get('next', ''):
				debug_MS("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~")
				debug_MS(f"(navigator.list_overview[2]) PAGES ### NEXTCOUNT : {int(page)+1} || NEXTPAGE : {RED_START+DATAS['meta']['next']} ###")
				fetch_blades = create_entries({'Title': translation(30631).format(int(page)+1), 'Image': f"{artpic}nextpage.png"})
				add_views({'mode': 'list_overview', 'link': RED_START+DATAS['meta']['next'], 'phase': phase, 'page': int(page)+1, 'extra': 'NextPage'}, fetch_blades)
	if not fetch_posts and not fetch_items:
		notices = re.sub(r'(CollectionPages: |ProductPages: )', '', extra) if not isinstance(extra, (dict, list)) else f"SUCHE : {target.split('_Searching: ')[1]}"
		failing(f'(navigator.list_channels) ##### NO OVERVIEW-LIST - NO ENTRY FOR: "{notices}" FOUND #####')
		return dialog.notification(translation(30525), translation(30527).format(notices), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_servus(merging={}):
	debug_MS("(navigator.search_servus) ------------------------------------------------ START = search_servus -----------------------------------------------")
	keyword, templates, merging['cards'], (ACCESS, CANTON) = preserve(SEARCH_FILE, 'TEXT'), [], [], clientHelper().check_authtoken()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(translation(30632), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword:
		for ii in range(0, 8, 1): # https://tv-api.redbull.com/search/v5.1/stv/de/at/top_results?q=%C3%B6sterreich&offset=15
			page_link = BULL_SEARCH.format(CANTON, quote(keyword), int(ii)*15)
			debug_MS(f"(navigator.search_servus[1]) SEARCH-PAGES XXX COUNT : {str(ii)} || LINK : {page_link} XXX")
			templates.append({'Count_1': int(ii), 'Code': 'searching', 'Link_1': page_link})
		package = clientHelper().track_several(templates, 'GET', 'JSON', WEB_HEADER, 4)
		if package:
			for article in json.loads(package):
				for item in article.get('cards', {}):
					merging['cards'].append(item)
			return list_overview(f"/collections_Searching: {keyword}", 'collections', 1, merging)
	return None

def _fetch_pages(templates, mark, secondo=[]):
	package = clientHelper().track_several(templates, 'GET', 'JSON', WEB_HEADER, 4)
	if package:
		for article in json.loads(package):
			if article is not None and (mark == 'dates' and article.get('type') == 'video') or (mark == 'cards' and article.get('cards', {}) and article.get('list_type') != 'playnet'):
				if mark == 'dates':
					title_due, genre_due = (article.get('title', '') or article.get('label', '')), article.get('tags', {})
					start_date, ends_date = article.get('sunrise_timestamp', None), article.get('sunset_timestamp', None)
					secondo.append({'Count_2': article['Count_2'], 'Code': article['Code'], 'Link_2': article['Link_2'], 'Title_2': title_due, 'EpisTaxo': genre_due, 'EpisStart': start_date, 'EpisEndes': ends_date})
				elif mark == 'cards':
					title_due, bodies, show_ident = article.get('label', None), article.get('list_type', None), article.get('id', None)
					secondo.append({'Count_2': article['Count_2'], 'Code': article['Code'], 'Link_2': article['Link_2'], 'Title_2': title_due, 'Listing': bodies, 'ShowCID': show_ident})
	return secondo

def create_substances(rsx, others='pages', cabin=1, counter=1):
	debug_MS("-------------------------------------------------")
	debug_MS(f"(navigator.create_substances[{cabin}]) [{others.upper()}] ### COUNT-0{cabin} : {counter} || EACH-0{cabin} : {rsx} ###")
	playable, collate, (name, duration, season, episode, condition) = False, '2026-01-01T00:01', (None for _ in range(5))
	tvshow, tagline, local_start, start_times, starting, airing, local_ends, ends_times, startlive, endslive, poster = (None for _ in range(11))
	thumb, fanart, (note_1, note_2, note_3, note_4, note_5, suffix) = icon, defaultFanart, ("" for _ in range(6))
	title = (cleaning(rsx.get('title', '')) or cleaning(rsx.get('Title_1', '')))
	subtitle = (rsx.get('show_name', None) or rsx.get('subheading', None))
	ident, tables = (rsx.get('id', None) or rsx.get('Code', None)), 'episode'
	if rsx.get('content_type', ''):
		tables = rsx['content_type'].replace('show', 'tvshow').replace('clip', 'tvshow').replace('event', 'tvshow').replace('live_program', 'tvshow').replace('film', 'movie')
		if rsx['content_type'] in ['live_program', 'stop']: condition = get_states(str(rsx.get('badges')))
	if subtitle and tables != 'movie':
		tvshow, note_1 = subtitle, translation(32101).format(subtitle)
	elif subtitle and tables == 'movie': tagline = subtitle
	if str(rsx.get('EpisStart'))[:4].isdecimal():
		local_start = convert_region(rsx['EpisStart'], 'DATETIME')
		start_times = local_start.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
		collate = local_start.strftime('%Y-%m-%dT%H:%M')
		starting = local_start.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else LOCALstart.strftime('%d.%m.%Y') # 2026-05-16T19:10:00 = NEWFORMAT // 16.05.2026 = OLDFORMAT
		airing = local_start.strftime('%d.%m.%Y') # FirstAired
	if str(rsx.get('EpisEndes'))[:4].isdecimal():
		local_ends = convert_region(rsx['EpisEndes'], 'DATETIME')
		ends_times = local_ends.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
	if start_times and ends_times: note_3 = translation(32102).format(start_times, ends_times)
	elif start_times and ends_times is None: note_3 = translation(32103).format(start_times)
	elif start_times is None and ends_times is None: note_3 = '[CR]'
	if str(rsx.get('start_time'))[:4].isdecimal():
		event_start = convert_region(rsx['start_time'], 'DATETIME')
		startlive = event_start.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
	if str(rsx.get('end_time'))[:4].isdecimal():
		event_ends = convert_region(rsx['end_time'], 'DATETIME')
		endslive = event_ends.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
	if startlive and endslive: note_4 = translation(32104).format(startlive, endslive)
	elif startlive and endslive is None: note_4 = translation(32105).format(startlive)
	if others == 'videos':
		duration = int(rsx['duration']) // 1000 if str(rsx.get('duration')).isdecimal() else None
		season = f"{int(rsx['season_number']):02}" if str(rsx.get('season_number')).isdecimal() and int(rsx['season_number']) != 0 else None
		episode = f"{int(rsx['episode_number']):02}" if str(rsx.get('episode_number')).isdecimal() and int(rsx['episode_number']) != 0 else None
		if season and episode: note_2 = translation(32106).format(season, episode)
		elif season is None and episode: note_2 = translation(32107).format(episode)
		playable = rsx.get('playable', False)
		if condition == 'LIVE': name, playable = translation(32108).format(title), True
		elif condition == 'POST': name, playable = translation(32109).format(title), True
		elif condition == 'TRIM': name, playable = translation(32110).format(title), False
		elif condition == 'NEXT' and local_start and datetime.now() < local_start < (datetime.now() + timedelta(days=5)):
			name, playable = translation(32111).format(title), False
	if condition in ['NEXT', 'TRIM'] and local_start and local_ends and datetime.now() > local_start and datetime.now() < local_ends and playable is False:
		published, access = play_check(ident)
		if published and access == 'live': name, playable, condition = translation(32108).format(title), True, 'LIVE'
		elif published and access == 'post': name, playable, condition = translation(32109).format(title), True, 'POST'
		elif not published and access in ['pre', 'trim']: name, playable, condition = translation(32110).format(title), False, 'TRIM'
	if rsx.get('media_resources', '') and len(rsx['media_resources']) > 0:
		num, mars = ident, rsx.get('media_resources', [])
		thumb, poster, fanart = get_picture(num, mars, 'square'), get_picture(num, mars, 'portrait'), get_picture(num, mars, 'landscape')
	note_5 = cleaning(rsx['long_description']) if rsx.get('long_description', '') and len(rsx['long_description']) > 20 else \
		cleaning(rsx['short_description']) if rsx.get('short_description', '') and len(rsx['short_description']) > 20 else ""
	genre = ' / '.join(sorted([tax for tax in rsx.get('EpisTaxo', {})][:2]))
	if condition is None and others == 'videos': suffix = translation(32112) if local_start and local_start > (datetime.now() - timedelta(days=3)) and local_start < datetime.now() else \
		translation(32113) if local_ends and local_ends < (datetime.now() + timedelta(days=5)) and local_ends > datetime.now() else ""
	if condition == 'LIVE' and others == 'pages': suffix = translation(32114)
	elif condition == 'NEXT' and others == 'pages' and startlive and datetime.now() < event_start < (datetime.now() + timedelta(days=5)): suffix = translation(32115)
	name, clean_name = title if name is None else name, title if name is None else re.sub(r'\[.*?\]', '', name)
	teaser = f"{note_1}{note_2}{note_3}{note_4}{note_5}"
	return [ident, condition, tables, playable, name+suffix, clean_name+suffix, tvshow, tagline, teaser, duration, season, episode, collate, starting, airing, genre, thumb, poster, fanart]

def play_check(code): # Sometimes 'Live' not shown as playable, so make a special-request // https://api-player.redbull.com/stv/live-status?videoId=AA61K887L5PIUBIUQELJ
	debug_MS("(navigator.play_check) ------------------------------------------------ START = play_check -----------------------------------------------")
	LOOK, active, status = clientHelper().track_content(BULL_STATUS.format(code), headers=WEB_HEADER, timeout= 6), False, 'unknown'
	if LOOK not in ['', None] and LOOK.get('confirmed', False) is True:
		active = True if LOOK.get('code') in ['live', 'post'] else False
		status = LOOK['code'] if LOOK.get('code') in ['live', 'post', 'pre', 'trim'] else 'unknown'
	debug_MS(f"(navigator.play_check[1]) ~~~~~~~~ ACTIVE : {active} || STATUS : {status.upper()} ~~~~~~~~")
	return (active, status)

def list_channels(): # https://dms.redbull.tv/v5/destination/stv/PNEZ060SSZGUI2L/personal_computer/http/at/de_AT/playlist.m3u8
	debug_MS("(navigator.list_channels) ------------------------------------------------ START = list_channels -----------------------------------------------")
	counter, merging, (combo_uno, combo_due), (ACCESS, CANTON) = 0, {}, ([] for _ in range(2)), clientHelper().check_authtoken()
	if ACCESS:
		DATAS = clientHelper().track_content(BULL_COLLECT.format(CANTON, '6e6475bc-d2f2-4593-b95f-ed0a74206c62', 0), headers=WEB_HEADER)
		if DATAS is not None and DATAS.get('cards', {}):
			for item in DATAS.get('cards', {}):
				stv_name, stv_code, stv_desc = cleaning(item['title']), item['id'], cleaning(item.get('short_description', ''))
				stv_short = stv_name.replace('ServusTV Sport', 'Sport On').replace(' ', '_').lower()
				stv_video = f"{RED_PDMS}destination/stv/{stv_code}/personal_computer/http/de/{CANTON}/playlist.m3u8"
				stv_photo = f"{artpic}{stv_short}.png" if xbmcvfs.exists(f"{artpic}{stv_short}.png") else f"{artpic}channels.png"
				stv_link = BULL_GUIDES.format(CANTON, stv_code)
				debug_MS(f"(navigator.list_channels[1]) ##### TITLE : {stv_name} || CODE : {stv_code} || STREAM : {stv_video} #####")
				counter += 1
				combo_uno.append({'Count_1': int(counter), 'Code': stv_code, 'Link_1': stv_link, 'Channel': stv_name, 'Thumb': stv_photo, 'Teaser': stv_desc, 'Video': stv_video})
		if combo_uno: combo_due = _fetch_guides(combo_uno) # https://stackoverflow.com/questions/56658669/combine-two-lists-of-dictionaries-by-value-of-key-in-dictionaries
		merging = [{**uno, **next(iter([due for due in combo_due if due.get('Code') == uno.get('Code')]), {})} for uno in combo_uno] # Merge two Lists of Dictionaries by specific value !!!
		for post in sorted(merging, key=lambda sox: sox.get('Count_1', 0)):
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
			debug_MS(f"(navigator.list_channels[3]) ##### Anzahl = {len(post)} || Eintrag : {post} #####")
			if post.get('Guides') == "": stv_guide = part_uno = post.get('Teaser')
			else: stv_guide, part_uno = post.get('Guides').replace('@@', ''), post.get('Guides').split('@@')[0]
			fetch_items = create_entries({'Title': f"[B]{post.get('Channel')}[/B]", 'Plot': stv_guide, 'Image': post.get('Thumb')})
			add_views({'mode': 'play_video', 'link': post.get('Video'), 'action': f"LIVE_PLAY@@{post.get('Channel')}@@{post.get('Thumb')}@@{part_uno}@@"}, fetch_items, False)
	if counter == 0:
		failing(f'(navigator.list_channels) ##### NO CHANNEL-LIST - NO ENTRY FOR: "TV-Kanäle" FOUND #####')
		return dialog.notification(translation(30525), translation(30527).format('TV-Kanäle'), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def _fetch_guides(templates, secondo=[]):
	def _parse_guides(program, ident, counter=0, guides_infos=""):
		for scraps in program:
			(local_start, local_ends, episode), teaser = (None for _ in range(3)), '[CR]' # Redbull, Berwelten, Wintersport, Sport, Wissen
			valids = ['PN16D371F0EA864', 'PN5265D2299446D', 'PND8C207D5BC33B', 'PN08A1EAD94C342', 'PN03C63D1068B57']
			name = scraps.get('title', '')
			serie = scraps.get('subheading', None)
			if name in ['', None]: continue
			if str(scraps.get('start_time'))[:4].isdecimal():
				local_start = convert_region(scraps['start_time'], 'DATETIME')
				start_date = local_start.strftime('%d{0}%m {1} %H{2}%M').format('/', '•', ':')
			if str(scraps.get('end_time'))[:4].isdecimal():
				local_ends = convert_region(scraps['end_time'], 'DATETIME')
				ends_date = local_ends.strftime('%d{0}%m {1} %H{2}%M').format('/', '•', ':')
			title = cleaning(serie) if serie and ident in valids else cleaning(name)
			if serie and cleaning(serie).lower() != cleaning(name).lower():
				episode = cleaning(name) if serie and ident in valids else cleaning(serie)
			if scraps.get('long_description', '') and len(scraps['long_description']) > 10:
				teaser = f"{cleaning(scraps['long_description'][:300])}..." if len(scraps['long_description']) > 300 else cleaning(scraps['long_description'])
			if teaser == '[CR]' and scraps.get('short_description', '') and len(scraps['short_description']) > 10:
				teaser = f"{cleaning(scraps['short_description'][:300])}..." if len(scraps['short_description']) > 300 else cleaning(scraps['short_description'])
			description = f"{teaser}@@[CR][CR]" if len(teaser) > 10 else teaser
			if counter < 6 and local_start and local_ends and not str(local_ends).startswith(('2000', '2100')) and local_ends > datetime.now():
				counter += 1
				debug_MS("-------------------------------------------------")
				debug_MS(f"(navigator.fetch_guides[2]) ### COUNTER : {counter} || SERIE : {title} || EPISODE : {episode} ###")
				debug_MS(f"(navigator.fetch_guides[2]) ### CHANNEL : {ident} || START : {local_start} || ENDED : {local_ends} ###")
				if episode is None: guides_infos += translation(30641).format(start_date, ends_date, title, description)
				else: guides_infos += translation(30642).format(start_date, ends_date, title, episode, description)
		return guides_infos
	package = clientHelper().track_several(templates, 'GET', 'JSON', WEB_HEADER, 4)
	if package:
		for article in json.loads(package):
			if article is not None and article.get('cards', {}) and len(article['cards']) > 0 and any(sonic.get('type') == 'video' for sonic in article.get('cards', {})):
				schedule = _parse_guides(article.get('cards', {}), article.get('Code'))
				secondo.append({'Count_2': article.get('Count_2'), 'Code': article.get('Code'), 'Link_2': article.get('Link_2'), 'Guides': schedule})
	return secondo

def play_video(code, riders): # https://dms.redbull.tv/v5/destination/stv/AAVZ5A09DFS3E6DBDSZE/personal_computer/http/at/de_AT/playlist.m3u8
	debug_MS("(navigator.play_video) ------------------------------------------------ START = play_video -----------------------------------------------")
	(FINAL_URL, TEST_URL, title), (ACCESS, CANTON) = (False for _ in range(3)), clientHelper().check_authtoken()
	if ACCESS:
		if riders.startswith(('LIVE_PLAY', 'EVENT_PLAY')):
			section = riders.split('@@')
			if riders.startswith('LIVE_PLAY'):
				title = translation(30643).format(re.sub(r'(\[/?B\]|ServusTV )', '', section[1]), CANTON.upper())
				photo, asset, teaser = section[2], 'CHANNEL', section[3] if len(section) > 4 and len(section[3]) > 0 else ' '
				FINAL_URL = f"{RED_PDMS}stv-linear/{ACCESS}/playlist.m3u8?namespace=stv" if section[1].lower() == 'servustv live' else code
			elif riders.startswith('EVENT_PLAY'):
				title, photo, asset, teaser = re.sub(r'\[/?B\]', '', section[1]), section[2], 'EVENT', section[3]
				FINAL_URL = f"{RED_PDMS}{code}/{ACCESS}/playlist.m3u8?namespace=stv"
		else: asset, FINAL_URL = 'HLS', f"{RED_PDMS}{code}/{ACCESS}/playlist.m3u8?namespace=stv"
		verify = clientHelper().track_content(FINAL_URL, 'GET', 'TRACK', WEB_HEADER, False, timeout=10)
		if verify and verify.status_code in [200, 201, 202, 300, 301, 302]: TEST_URL = True
		else: # https://tv-api.redbull.com/products/dynamic/v5.3/stv/de/de/AA-289YG9AWW1W11 // if the Playcode doesn't work, check it with this Link
			relays = clientHelper().track_content(BULL_RELAYS.format(CANTON, code), headers=WEB_HEADER, timeout=10)
			if relays and relays.get('links', {}) and len(relays['links']) > 0 and relays.get('links', {})[0].get('action', '') == 'play':
				FINAL_URL = f"{RED_PDMS}{relays.get('links', {})[0].get('id', 'test')}/{ACCESS}/playlist.m3u8?namespace=stv"
				verify = clientHelper().track_content(FINAL_URL, 'GET', 'TRACK', WEB_HEADER, False, timeout=10)
				if verify and verify.status_code in [200, 201, 202, 300, 301, 302]: TEST_URL = True
	if FINAL_URL and TEST_URL:
		if riders.startswith(('LIVE_PLAY', 'EVENT_PLAY')):
			LPM = xbmcgui.ListItem(title, path=FINAL_URL, offscreen=True)
			if KODI_BUILD >= 20:
				LPM.getVideoInfoTag().setTitle(title), LPM.getVideoInfoTag().setPlot(teaser), LPM.getVideoInfoTag().setStudios(['ServusTV'])
			else: LPM.setInfo('Video', {'Title' : title, 'Plot' : teaser, 'Studio' : 'ServusTV'})
			LPM.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
		else:
			LPM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		if plugin_operate('inputstream.adaptive'):
			IA_NAME = 'inputstream.adaptive'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			LPM.setMimeType('application/vnd.apple.mpegurl'); LPM.setProperty('inputstream', IA_NAME)
			if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", 'hls') # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
			LPM.setProperty(f"{IA_NAME}.{PHRASE}_headers", f"User-Agent={WEB_AGENT}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
			if int(IA_VERSION) >= 2150:
				LPM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey')
			if enable_shifter and riders.startswith(('LIVE_PLAY', 'EVENT_PLAY')):
				LPM.setProperty(f"{IA_NAME}.play_timeshift_buffer", 'true') # If possible allow to start playing a LIVE stream from the beginning of the buffer instead of its end.
		if riders.startswith(('LIVE_PLAY', 'EVENT_PLAY')):
			xbmc.Player().play(item=FINAL_URL, listitem=LPM)
		else: xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		naming = " || TITLE : "+re.sub(r'\[.*?\]', '', title) if title else ""
		log(f"(navigator.play_video) {asset}_stream : {FINAL_URL}{naming}")
		xbmc.sleep(15000)
		if not xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)') and not xbmc.Player().isPlayingVideo():
			return dialog.notification(translation(30521).format('PLAY'), translation(30523).format("Code: 403|Text: Dieses Video ist leider nicht verfügbar"), icon, 15000)
	elif FINAL_URL and not TEST_URL:
		failing(f"(navigator.play_video[1]) ##### Abspielen des Streams NICHT möglich #####\n ##### ERROR_CODE : {verify.status_code} || FINAL_URL : {FINAL_URL} #####\n ########## Die Wiedergabe wurde geblockt !!! ##########")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		return dialog.notification(translation(30521).format('PLAY'), translation(30523).format(f"Code: {verify.status_code}|Text: Dieses Video ist leider nicht verfügbar"), icon, 15000)
	else:
		failing("(navigator.play_video[1]) ##### Abspielen des Streams NICHT möglich #####\n ########## Der erforderliche Token wurde NICHT gefunden !!! ##########")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		return dialog.notification(translation(30521).format('TOKEN'), translation(30529), icon, 15000)

def list_favorites():
	debug_MS("(navigator.list_favorites) ------------------------------------------------ START = list_favorites -----------------------------------------------")
	if preserve(FAVORIT_FILE) is not None:
		ACCESS, CANTON = clientHelper().check_authtoken()
		for item in sorted(preserve(FAVORIT_FILE), key=lambda vsx: clear_umlaut(vsx.get('Title', 'zorro')).lower()):
			ident, name, transfer = item.get('Code'), item.get('Title'), BULL_PRODUCT.format(CANTON, item.get('Code'))
			fetch_items = context = {'Code': ident, 'Title': name, 'Plot': item.get('Plot'), 'Type': item.get('Type'), \
				'Image': item.get('Image'), 'Cover': item.get('Cover'), 'Fanback': item.get('Fanback')}
			debug_MS(f"(navigator.list_favorites[1]) ### NAME : {name} || LINK : {transfer} || THUMB : {item.get('Image')} ###")
			add_views({'mode': 'list_overview', 'link': transfer, 'phase': 'products', 'extra': 'Favoriten'}, create_entries(fetch_items), True, context, 'removing')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favorit_construct(**kwargs):
	TOPS = []
	if preserve(FAVORIT_FILE) is not None:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		kwargs.pop('mode', None); kwargs.pop('action', None)
		TOPS.append({key: value for key, value in kwargs.items() if value not in ['', 'None', None]})
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30532), translation(30533).format(kwargs['Title']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Code') != kwargs.get('Code')]
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30532), translation(30534).format(kwargs['Title']), icon, 10000)

def add_views(params, listitem, folder=True, context={}, handling='default', higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enable_decrease and higher is True:
		entries.append([translation(30651), f"RunPlugin({build_mass({'mode': 'calling_main'})})"])
	if handling == 'adding' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30653), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
