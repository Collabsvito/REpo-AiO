﻿# -*- coding: utf-8 -*-

from .common import *


def get_ListItem(info, category, phrase, extras, aback, addType=1, folder=True, STOCK=False):
	cineType, description, Note_1, Note_2, Note_3 = ("" for _ in range(5))
	seriesname, tagline, DIGS, epis_one, epis_two, epis_three, start_clock, startTIMES, aired, begins, ending_clock, endTIMES, genre, duration, uvz = (None for _ in range(15))
	entries, VOD_STREAM = [], False
	### Codeübersetzungen = e2fda2e1-58ff-4474-a49a-a2df01309998 = Neues aus Österreich / 9878c650-06dc-403e-9389-3ad738eca2ae = Talks & Meinungen / e440011b-c6f6-447f-97e3-3f7d2853689d = Ab in die Natur ###
	acronym = ['discover-featured', 'episode-topic', 'latest-videos', 'e2fda2e1-58ff-4474-a49a-a2df01309998', '9878c650-06dc-403e-9389-3ad738eca2ae', 'e440011b-c6f6-447f-97e3-3f7d2853689d']
	unwanted = ['mehr zu', 'top-themen', 'live', 'tagesaktuelle', 'wissen & natur', ' entdecken', 'beliebt', ' & mehr', ' ...']
	uuid = info.get('id', '')
	if info.get('content_type', ''):
		cineType = info['content_type'].replace('show', 'tvshow').replace('clip', 'tvshow').replace('event', 'tvshow').replace('live_program', 'tvshow').replace('film', 'movie')
	elif aback.get('content_type', ''):
		cineType = aback['content_type'].replace('show', 'tvshow').replace('clip', 'tvshow').replace('event', 'tvshow').replace('live_program', 'tvshow').replace('film', 'movie')
	name = info.get('label', '') if (cineType == 'movie' and info.get('label', '')) or (info.get('title', None) is None) else info.get('title', '')
	WATCHING = aback['title'] if aback.get('title', '') else 'ANSEHEN'
	if name.startswith('Watch Live'):
		name = f"[B][COLOR chartreuse]■  ■  ■  [/COLOR]JETZT LIVE - {WATCHING}[COLOR chartreuse]  ■  ■  ■[/COLOR][/B]"
	elif name.startswith('Watch Replay'):
		name = f"[COLOR yellow]■  ■  ■  [/COLOR]IM REPLAY - {WATCHING}[COLOR yellow]  ■  ■  ■[/COLOR]"
	if info.get('subheading', ''):
		if cineType == 'movie': tagline = info['subheading']
		else: seriesname = info['subheading'].split(' live bei ServusTV')[0]
	cineType = cineType if cineType in ['episode', 'tvshow', 'video'] else 'movie'
	if seriesname: Note_1 = translation(32101).format(str(seriesname))
	if info.get('long_description', '') or aback.get('long_description', ''):
		if info.get('long_description', '') and len(info['long_description']) > 10:
			DIGS = info['long_description']
		if DIGS is None and aback.get('long_description', '') and len(aback['long_description']) > 10:
			DIGS = aback['long_description']
	if DIGS is None and (info.get('short_description', '') or aback.get('short_description', '')):
		if info.get('short_description', '') and len(info['short_description']) > 10:
			DIGS = info['short_description']
		if DIGS is None and aback.get('short_description', '') and len(aback['short_description']) > 10:
			DIGS = aback['short_description']
	if DIGS: description = DIGS
	seas_one = re.compile('([0-9]+)', re.S).findall(info['season']) if info.get('season', '') else None # Staffel 1
	seas_two = re.search('(Staffel:? |S)(\d+)', name) # S05/E01
	seas_number = seas_one[0].zfill(2) if seas_one else seas_two.group(2).zfill(2) if seas_two else None
	if info.get('chapter', ''):
		epis_one = re.compile('([0-9]+)', re.S).findall(info['chapter']) # Episode 6 - Infrastruktur
		epis_two = info['chapter'] # Wien
	else: epis_three = re.search('(Episode:? |Folge:? |E)(\d+)', name) # S05/E01
	epis_number = epis_one[0].zfill(2) if epis_one else epis_three.group(2).zfill(2) if epis_three else None
	epis_text = f"Folge {str(epis_one[0].zfill(2))}" if epis_one else epis_two.split(' -')[0] if epis_two else f"Folge {str(epis_three.group(2).zfill(2))}" if epis_three else None
	if cineType == 'episode' and seas_number and epis_text: Note_2 = translation(32102).format(str(seas_number), epis_text)
	elif cineType == 'episode' and seas_number is None and epis_text: Note_2 = translation(32103).format(epis_text)
	if info.get('status', '') and info['status'].get('start_time', '') and str(info['status']['start_time'])[:4].isdigit():
		start_clock = info['status']['start_time'] # Datumseinträge gibt es sowohl unter diesem Level als auch unter einem Level eine Stufe höher
	if start_clock is None and info.get('start_time', '') and str(info['start_time'])[:4].isdigit():
		start_clock = info['start_time']
	if start_clock is None and aback.get('status', '') and aback['status'].get('play', '') == uuid and str(aback['status'].get('start_time'))[:4].isdigit():
		start_clock = aback['status']['start_time']
	if start_clock:
		LOCALstart = get_CentralTime(start_clock)
		startTIMES = LOCALstart.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('.', '•', ':')
		aired = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # FirstAired
		begins = LOCALstart.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
		if KODI_ov20:
			begins = LOCALstart.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
		if startTIMES.startswith(('01.01.2000', '01.01.2100')): startTIMES = None
	if info.get('status', '') and info['status'].get('end_time', '') and str(info['status']['end_time'])[:4].isdigit():
		ending_clock = info['status']['end_time']
	if ending_clock is None and info.get('end_time', '') and str(info['end_time'])[:4].isdigit():
		start_clock = info['end_time']
	if ending_clock is None and aback.get('status', '') and aback['status'].get('play', '') == uuid and str(aback['status'].get('end_time'))[:4].isdigit():
		ending_clock = aback['status']['end_time']
	if ending_clock:
		LOCALend = get_CentralTime(ending_clock)
		endTIMES = LOCALend.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('.', '•', ':')
		if endTIMES.startswith(('01.01.2000', '01.01.2100')): endTIMES = None
	if startTIMES and endTIMES: Note_3 = translation(32104).format(str(startTIMES), str(endTIMES))
	elif startTIMES and endTIMES is None: Note_3 = translation(32105).format(str(startTIMES))
	elif seriesname and startTIMES is None and endTIMES is None: Note_3 = '[CR]' #  in ['show', 'system']
	if info.get('tags', '') and len(info['tags']) > 0:
		genre = info['tags'][-1]
	duration = int(info['duration']) // 1000 if str(info.get('duration')).isdigit() else None
	if info.get('playable', '') is True or info.get('action', '') == 'play':
		folder = False
	title_short = name if (not any(x in aback.get('id', '') for x in acronym) and aback.get('item_type', '') in ['mixed', 'video']) or seriesname is None else name+' - '+seriesname
	FULL_PLOT = f"{Note_1}{Note_2}{Note_3}{description}" if f"{Note_1}{Note_2}{Note_3}{description}" != "" else ' '
	if folder is False:
		for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	else:
		xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
		xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	LEM = xbmcgui.ListItem(name)
	if KODI_ov20:
		vinfo = LEM.getVideoInfoTag()
		if str(seas_number).isdigit() and int(seas_number) != 0: vinfo.setSeason(int(seas_number))
		if str(epis_number).isdigit() and int(epis_number) != 0: vinfo.setEpisode(int(epis_number))
		if seriesname: vinfo.setTvShowTitle(seriesname)
		vinfo.setTitle(name)
		if tagline: vinfo.setTagLine(tagline)
		vinfo.setPlot(FULL_PLOT)
		if str(duration).isdigit(): vinfo.setDuration(int(duration))
		if begins: LEM.setDateTime(begins)
		if aired: vinfo.setFirstAired(aired)
		if genre and len(genre) > 3: vinfo.setGenres([genre])
		vinfo.setStudios(['ServusTV'])
		if folder is False: vinfo.setMediaType(cineType)
	else:
		vinfo = {}
		if str(seas_number).isdigit() and int(seas_number) != 0: vinfo['Season'] = seas_number
		if str(epis_number).isdigit() and int(epis_number) != 0: vinfo['Episode'] = epis_number
		if seriesname: vinfo['TvShowTitle'] = seriesname
		vinfo['Title'] = name
		if tagline: vinfo['Tagline'] = tagline
		vinfo['Plot'] = FULL_PLOT
		if str(duration).isdigit(): vinfo['Duration'] = duration
		if begins: vinfo['Date'] = begins
		if aired: vinfo['Aired'] = aired
		if genre and len(genre) > 3: vinfo['Genre'] = genre
		vinfo['Studio'] = 'ServusTV'
		if folder is False: vinfo['Mediatype'] = cineType # mediatype  = "video", "movie", "tvshow", "season", "episode" , "musicvideo"
		LEM.setInfo('Video', vinfo)
	PHOTO, WALL = icon, defaultFanart
	LEM.setArt({'icon': PHOTO, 'thumb': PHOTO, 'fanart': WALL})
	if info.get('resources', '') or aback.get('resources', '') and aback.get('id', '') not in ['discover', 'calendar']:
		if info.get('resources', ''):
			num, resources, STOCK = info.get('id', ''), info.get('resources', []), True
		if STOCK is False and aback.get('resources', ''):
			num, resources, STOCK = aback.get('id', ''), aback.get('resources', []), True
		if STOCK is True:
			LEM.setArt({'fanart': get_Picture(num, resources, 'landscape')})
			LEM.setArt({'landscape': get_Picture(num, resources, 'landscape')})
			LEM.setArt({'banner': get_Picture(num, resources, 'banner')})
			LEM.setArt({'poster': get_Picture(num, resources, 'portrait')})
			LEM.setArt({'thumb': get_Picture(num, resources, 'square')})
			PHOTO = str(get_Picture(num, resources, 'square'))
			WALL = str(get_Picture(num, resources, 'landscape'))
	if info.get('playable', '') is True or info.get('action', '') == 'play':
		if (info.get('playable', '') is True) or (info.get('action', '') == 'play' and aback.get('status', '') and aback['status'].get('play', '') == uuid and aback['status'].get('code', '') == 'post'):
			uvz, VOD_STREAM = build_mass({'mode': 'playVideo', 'url': uuid}), True
		elif info.get('action', '') == 'play' and aback.get('status', '') and aback['status'].get('play', '') == uuid and aback['status'].get('code', '') == 'live':
			uvz, VOD_STREAM = build_mass({'mode': 'playVideo', 'url': uuid, 'action': f"EVENT_PLAY@@{name}@@{PHOTO}@@{FULL_PLOT}@@"}), False
	elif category == 'COLLECTION':
		uvz = build_mass({'mode': 'listGenerals', 'url': uuid, 'phrase': 'collections'})
	elif category in ['PRODUCT', 'THEME']:
		ROUTES = 'listGenerals' if category == 'PRODUCT' else 'listThemes'
		uvz = build_mass({'mode': ROUTES, 'url': uuid, 'phrase': 'products'})
		if ROUTES == 'listGenerals' and info.get('content_type', '') == 'live_program' and info.get('playable', '') is False:
			uvz, folder = build_mass({'mode': 'newsFUNC', 'url': '00', 'action': name}), False
	elif category == 'PLAYLIST':
		uvz = build_mass({'mode': 'listGenerals', 'url': uuid, 'phrase': 'playlists'})
	if ('all_episodes' in uuid or uuid.count('-') > 2) and aback.get('content_type', '') in ['event', 'show', 'system', 'subchannel'] and not any(w in str(name).lower() for w in unwanted):
		if xbmcvfs.exists(channelFavsFile):
			with open(channelFavsFile, 'r') as fp:
				watch = json.load(fp)
				for item in watch.get('items', []):
					if item.get('url') == uuid: addType = 2
		if addType == 1:
			FAVOR_TITLE = name if not any(n in str(name).lower() for n in ['verfügbar', 'ganze ']) else aback.get('title', 'DEFAULT')
			FAVOR_PLOT = f"{aback.get('title', '...')}[CR][CR]{description.replace(chr(10), '[CR]')}" if DIGS else ' '
			entries.append([translation(30651), 'RunPlugin({})'.format(build_mass({'mode': 'favs', 'action': 'ADD', 'name': FAVOR_TITLE,
				'pict': PHOTO, 'url': uuid, 'plot': FAVOR_PLOT, 'wallpaper': WALL, 'cineType': cineType}))])
	if folder is False and VOD_STREAM is True:
		LEM.setProperty('IsPlayable', 'true')
		LEM.setContentLookup(False)
		entries.append([translation(30654), 'Action(Queue)'])
	LEM.addContextMenuItems(entries)
	if extras:
		debug_MS(f"{extras} ### TITLE = {name} || CINETYPE = {cineType} ###")
		debug_MS(f"{extras} ### EID = {uuid} || is FOLDER = {str(folder)} || DURATION = {str(duration)} ###")
		debug_MS(f"{extras} ### THUMB = {PHOTO} ###") if STOCK else debug_MS(f"{extras} ### THUMB = !!! NO PHOTO FOUND IN ENTRIES !!! ###")
	return (uvz, LEM, folder)
