﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import time
from datetime import datetime, timedelta
from calendar import timegm as TGM
import requests
from urllib.parse import parse_qsl, urlencode, quote, unquote_plus
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addonPath							= xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath								= xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
tempSERV							= xbmcvfs.translatePath(os.path.join(dataPath, 'tempSERV', '')).encode('utf-8').decode('utf-8')
servFile								= xbmcvfs.translatePath(os.path.join(tempSERV, 'FREE_SECRET'))
SEARCHFILE						= xbmcvfs.translatePath(os.path.join(dataPath, 'search_string'))
channelFavsFile					= xbmcvfs.translatePath(os.path.join(dataPath, 'favorites_SERVUS.json'))
defaultFanart						= os.path.join(addonPath, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addonPath, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
tokenDelay							= {0: 0, 1: 5, 2: 10, 3: 30, 4: 60, 5: 180, 6: 360, 7: 720, 8: 1080, 9: 1440}[int(addon.getSetting('token_rhythm'))]
#   Zeitrahmen(servustv) = 0: auto|1: 5min.|2: 10min.|3: 30min.|4: 1hrs.|5: 3hrs.|6: 6hrs.|7: 12hrs.|8: 18hrs.|9: 24hrs.
verify_ssl_connect			= (True if addon.getSetting('verify_ssl') == 'true' else False)
enableADJUSTMENT			= addon.getSetting('show_settings') == 'true'
textSelection						= int(addon.getSetting('field_spread'))
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_ov20						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
KODI_un21						= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) <= 20
BASE_URL							= 'https://www.servustv.com/'
SERTV_HLS						= 'https://dms.redbull.tv/v5/'
SERTV_AP4						= 'https://api.redbull.tv/{}/v4/{}'
SERTV_AV3						= 'https://api.redbull.tv/v3/'
SERTV_ART						= 'https://resources.redbull.tv/'
defaultAgent						= 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:122.0) Gecko/20100101 Firefox/122.0'

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def ADDON_operate(IDD):
	check_1 = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.GetAddonDetails", "params":{{"addonid":"{IDD}", "properties":["enabled"]}}}}')
	check_2 = 'undone'
	if '"enabled":false' in check_1:
		try:
			xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.SetAddonEnabled", "params":{{"addonid":"{IDD}", "enabled":true}}}}')
			failing(f"(common.ADDON_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{IDD}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####")
		except: pass
		check_2 = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.GetAddonDetails", "params":{{"addonid":"{IDD}", "properties":["enabled"]}}}}')
	if '"error":' in check_1 or '"error":' in check_2:
		dialog.ok(addon_id, translation(30501).format(IDD))
		failing(f"(common.ADDON_operate) ERROR - INSTALLED - ERROR :\n##### Das benötigte Addon : *{IDD}* ist NICHT installiert !!! #####")
		return False
	if '"enabled":true' in check_1 or '"enabled":true' in check_2:
		return True
	if '"enabled":false' in check_2:
		dialog.ok(addon_id, translation(30502).format(IDD))
		failing(f"(common.ADDON_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{IDD}* ist NICHT aktiviert !!! #####\n##### Eine automatische Aktivierung ist leider NICHT möglich !!! #####")
	return False

def getSorting():
	return [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, xbmcplugin.SORT_METHOD_DURATION, xbmcplugin.SORT_METHOD_EPISODE, xbmcplugin.SORT_METHOD_DATE]

def get_CentralTime(info): # 2024-05-05T19:10:00Z
	UTC_DATE = datetime(*(time.strptime(info[:19], '%Y{0}%m{0}%dT%H{1}%M{1}%S'.format('-', ':'))[0:6]))
	try:
		LOCAL_DATE = datetime.fromtimestamp(TGM(UTC_DATE.timetuple()))
		assert UTC_DATE.resolution >= timedelta(microseconds=1)
		LOCAL_DATE = LOCAL_DATE.replace(microsecond=UTC_DATE.microsecond)
	except (ValueError, OverflowError): # ERROR on Android 32bit Systems = cannot convert unix timestamp over year 2038
		LOCAL_DATE = datetime.fromtimestamp(0) + timedelta(seconds=TGM(UTC_DATE.timetuple()))
		LOCAL_DATE = LOCAL_DATE - timedelta(hours=datetime.timetuple(LOCAL_DATE).tm_isdst)
	return LOCAL_DATE

def get_Picture(elem_id, resources, elem_type, width=960, quality=65):
	img_type = next(filter(lambda xz: elem_type in xz, resources), None)
	if img_type: # https://resources.redbull.tv/AA6IEBWQVZWJNY8WZ41B/rbtv_display_art_landscape/im:i:w_400,c_fill,q_65?namespace=stv
		return f"{SERTV_ART}{elem_id}/{img_type}/im:i:w_{width},q_{quality}?namespace=stv"
	return None

params = dict(parse_qsl(sys.argv[2][1:]))
name = unquote_plus(params.get('name', ''))
url = unquote_plus(params.get('url', ''))
pict = unquote_plus(params.get('pict', ''))
plot = unquote_plus(params.get('plot', ''))
mode = unquote_plus(params.get('mode', 'root'))
action = unquote_plus(params.get('action', 'DEFAULT'))
page = unquote_plus(params.get('page', '1'))
limit = unquote_plus(params.get('limit', '20'))
phrase = unquote_plus(params.get('phrase', 'collections'))
searching = unquote_plus(params.get('searching', 'NOTHING'))
wallpaper = unquote_plus(params.get('wallpaper', 'DEFAULT'))
cineType = unquote_plus(params.get('cineType', 'movie'))
