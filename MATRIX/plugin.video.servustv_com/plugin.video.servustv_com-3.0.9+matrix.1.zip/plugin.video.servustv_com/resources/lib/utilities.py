﻿# -*- coding: utf-8 -*-

from .common import *


def _header(REFERRER=None, USERTOKEN=None):
	header = {}
	header['Pragma'] = 'no-cache'
	header['Accept'] = 'application/json, application/x-www-form-urlencoded, text/plain, */*'
	header['User-Agent'] = defaultAgent
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	header['Accept-Language'] = 'de-DE,de;q=0.9,en;q=0.8'
	header['Origin'] = BASE_URL[:-1]
	if REFERRER:
		header['Referer'] = REFERRER
	if USERTOKEN:
		header['Authorization'] = USERTOKEN
	return header

class Transmission(object):

	def __init__(self):
		self.maxTokenTime = tokenDelay * 60 # max. Token-Time (Seconds) before clear the Token and delete Token-File [30*60 = 30 Mins | 60*60 = 1 Hour | 180*60 = 3 Hours | 720*60 = 12 Hours]
		self.tempSERV_folder = tempSERV
		self.servus_file = servFile
		self.NOW_UTC = time.time() # Actual UTC-Time as Epochtime
		self.verify_ssl = (True if addon.getSetting('verify_ssl') == 'true' else False)

	def clear_content(self, title, filename=None, foldername=None):
		debug_MS(f"(utilities.clear_content) ### DELETE OLD-FILE : * {title} * ###")
		if filename is not None and xbmcvfs.exists(filename):
			if foldername is not None and xbmcvfs.exists(foldername) and os.path.exists(foldername):
				shutil.rmtree(foldername, ignore_errors=True)

	def save_content(self, title, filename=None, foldername=None, text=""):
		debug_MS(f"(utilities.save_content) ### SAVE NEW-FILE : * {title} * ###")
		if foldername is not None and not xbmcvfs.exists(foldername) and not os.path.exists(foldername):
			xbmcvfs.mkdirs(foldername)
		if filename is not None and text != "":
			with open(filename, 'w') as save:
				json.dump(text, save, indent=4, sort_keys=True)

	def convert_epoch(self, epoch):
		CIPHER = datetime(1970,1,1) + timedelta(seconds=int(epoch))
		return CIPHER.strftime('%d.%m.%Y - %H:%M:%S')

	def check_FreeToken(self):
		debug_MS("(utilities.check_FreeToken) ##### START check_FreeToken #####")
		forceRenew, USERTOKEN, USERCOUNTRY = (False for _ in range(3))
		if self.maxTokenTime > 1 and xbmcvfs.exists(self.servus_file) and os.path.exists(self.servus_file):
			self.FILE_UTC = (os.path.getmtime(self.servus_file) + self.maxTokenTime)
			debug_MS(f"(utilities.check_FreeToken) ##### SESSION-Time (utc NOW) = {str(self.convert_epoch(self.NOW_UTC))} || VALID until (utc SESSION) = {str(self.convert_epoch(self.FILE_UTC))} #####")
			if self.NOW_UTC < self.FILE_UTC:
				try:
					with open(self.servus_file, 'r') as publish:
						ACC_DATA = json.load(publish)
					USERTOKEN = ACC_DATA['token']
					USERCOUNTRY = ACC_DATA['country_code']
					debug_MS("(utilities.check_FreeToken) ##### NOTHING CHANGED - TOKENFILE IS OKAY #####")
				except:
					failing("(utilities.check_FreeToken) XXXXX !!! ERROR = TOKENFILE [TOKENFORMAT IS INVALID] = ERROR !!! XXXXX")
					forceRenew = True
			else:
				debug_MS("(utilities.check_FreeToken) ##### TIMEOUT FOR TOKEN - DELETE TOKENFILE #####")
				forceRenew = True
		else:
			debug_MS("(utilities.check_FreeToken) ##### NOTHING FOUND - CREATE TOKENFILE FOR SERVUSTV #####")
			forceRenew = True
		if forceRenew:
			if xbmcvfs.exists(self.servus_file) and os.path.exists(self.servus_file):
				self.clear_content('FREE_SECRET', self.servus_file, self.tempSERV_folder)
			CODING = self.retrieveContent(f"{SERTV_AV3}session?namespace=stv&category=personal_computer&os_family=http", forcing=False)
			if CODING:
				if self.maxTokenTime > 1:
					debug_MS(f"(utilities.check_FreeToken) ***** NEW TOKENFILE CREATED : {CODING} *****")
					self.save_content('FREE_SECRET', self.servus_file, self.tempSERV_folder, CODING)
				else:
					debug_MS("(utilities.check_FreeToken) XXXXX YOU ARE IN LIVE-SESSION WITHOUT SAVING TOKEN - EVERTHING OKAY XXXXX")
				USERTOKEN = CODING['token']
				USERCOUNTRY = CODING['country_code']
		return (USERTOKEN, USERCOUNTRY)

	def retrieveContent(self, url, method='GET', REF=None, forcing=True, headers=None, cookies=None, allow_redirects=True, stream=None, data=None, json=None, timeout=30):
		ACCESS, CANTON, ANSWER = (None for _ in range(3))
		if forcing is True:
			ACCESS, CANTON = self.check_FreeToken()
		try:
			response = requests.get(url, headers=_header(REF, ACCESS), allow_redirects=allow_redirects, verify=self.verify_ssl, stream=stream, timeout=timeout)
			response.raise_for_status()
			ANSWER = response.json() if method in ['GET', 'POST'] else response.text if method == 'LOAD' else response
			debug_MS(f"(utilities.getUrl) === CALLBACK === STATUS : {str(response.status_code)} || URL : {response.url} || HEADER : {response.request.headers} ===")
			debug_MS("---------------------------------------------")
		except requests.exceptions.RequestException as e:
			failing(f"(utilities.getUrl) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {str(e)} #####")
			dialog.notification(translation(30521).format('URL'), translation(30523).format(str(e)), icon, 12000)
			return sys.exit(0)
		return ANSWER
