﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
import _strptime
from datetime import datetime, timedelta
import threading
import traceback
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode, quote_plus  # Python 2.X
else:
	from urllib.parse import urlencode, quote_plus  # Python 3.X

from .common import *


def mainMenu():
	if os.path.exists(radioFILE):
		addDir(translation(30601), artpic+'radio.jpg', {'mode': 'listRadio', 'type': 'audio'})
	addDir(translation(30602), artpic+'ytcom.jpg', {'mode': 'listFeedsRSS', 'url': 'YTuploads', 'type': 'video'})
	addDir(translation(30603), artpic+'video.jpg', {'mode': 'listVideos', 'url': BASE_URL+'/mediathek/videos.html', 'type': 'video'})
	addDir(translation(30604), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/hammer-geschichten-1548.rss', 'type': 'audio'})
	addDir(translation(30605), artpic+'podcast.jpg', {'mode': 'listPodcasts', 'url': BASE_URL+'/programm/traumberufe.html', 'type': 'audio'})
	addDir(translation(30606), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/corona-und-jetzt-4017.rss', 'type': 'audio'})
	addDir(translation(30607), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/sommer-bei-uns-4393.rss', 'type': 'audio'})
	addDir(translation(30608), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/addon-der-gaming-news-podcast-4610.rss', 'type': 'audio'})
	addDir(translation(30609), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': 'https://guterstoff.podigee.io/feed/mp3', 'type': 'audio'})
	addDir(translation(30610), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/comedy-1593.rss', 'type': 'audio'})
	addDir(translation(30611), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/buehne-frei-1747.rss', 'type': 'audio'})
	addDir(translation(30612), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': 'https://bestegaeste.podigee.io/feed/mp3', 'type': 'audio'})
	addDir(translation(30613), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/interviews-und-serien-1762.rss', 'type': 'audio'})
	addDir(translation(30614), artpic+'podcast.jpg', {'mode': 'listFeedsRSS', 'url': BASE_URL+'/thema/unter-der-haube-1748.rss', 'type': 'audio'})
	addDir(translation(30615), artpic+'podcast.jpg', {'mode': 'listPodcasts', 'url': BASE_URL+'/artikel/serie-schuetzenfest-abc-105422.html', 'type': 'audio'})
	if enableADJUSTMENT:
		addDir(translation(30620), artpic+'settings.png', {'mode': 'aSettings'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listRadio():
	debug_MS("(navigator.listRadio) -------------------------------------------------- START = listRadio --------------------------------------------------")
	with io.open(radioFILE, 'rb') as data_infile:
		text = data_infile.read()
		DATA = json.loads(text.decode('utf-8', 'ignore'))
		for item in DATA['mp3_list']:
			ID = str(item['rpID'])
			name = cleaning(item['label'])
			plot = cleaning(item['description'])
			audio_url = item['audio_url']
			thumb = item['thumb']
			addition = 'DIRECTstream@@'+name+'@@'+artpic+thumb+'@@'
			debug_MS("(navigator.listRadio) ### TITLE = {0} || IDD = {1} || AUDIO-URL = {2} ###".format(name, ID, str(audio_url)))
			addLink(name, artpic+thumb, {'mode': 'playVideo', 'url': audio_url, 'extras': addition}, plot)
		xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listFeedsRSS(url):
	debug_MS("(navigator.listFeedsRSS) -------------------------------------------------- START = listFeedsRSS --------------------------------------------------")
	debug_MS("(navigator.listFeedsRSS) ### URL = {0} ###".format(url))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_READY = ([] for _ in range(4))
	counter = 0
	startURL = url
	if url == 'YTuploads':
		response = getUrl('https://www.youtube.com/list_ajax?style=json&action_get_list=1&list=UUNeRy6vfb2XBIsPZ5nxmHYg')
		DATA = json.loads(response)
		for item in DATA['video']:
			debug_MS("(navigator.listFeedsRSS) no.01 ##### FOLGE : {0} #####".format(str(item)))
			Note_1, Note_2 = ("" for _ in range(2))
			title = cleaning(item['title'])
			if item.get('added', ''):
				Note_1 = '[COLOR yellow]'+str(item['added'])+'[/COLOR][CR]'
			if item.get('description', ''):
				Note_2 = cleaning(item['description'])
			plot = Note_1+Note_2
			try: photo = item['thumbnail'].replace('/default.jpg', '/maxresdefault.jpg')
			except: photo = ""
			videoId = (str(item.get('encrypted_id', '')) or "")
			duration = (item.get('length_seconds', '0') or '0')
			rating = (str(item.get('rating', '')) or "")
			votes = (str(item.get('likes', '')) or "")
			addLink(title, photo, {'mode': 'playVideo', 'url': videoId, 'extras': 'YTstream'}, plot, duration, rating, votes)
	else:
		html = getUrl(url)
		articles = re.findall('<item>(.*?)</item>', html, re.S)
		for item in articles:
			debug_MS("(navigator.listFeedsRSS) no.02 ##### FOLGE : {0} #####".format(str(item)))
			title, photo, Note_1, Note_2 = ("" for _ in range(4))
			startTIMES, mp3 = (None for _ in range(2))
			duration = '0'
			counter += 1
			link = re.compile('<link>([^<]+)</link>', re.DOTALL).findall(item)[0]
			link = BASE_URL+link if link[:4] != 'http' else link
			title = re.compile('<title>([^<]+)</title>', re.DOTALL).findall(item)[0]
			title = cleaning(title)
			published = re.compile('<pubDate>([^<]+)</pubDate>', re.DOTALL).findall(item)[0]
			try:
				startDATES = datetime(*(time.strptime(published[5:25], '%d{0}%b{0}%Y{0}%H{1}%M{1}%S'.format(' ', ':'))[0:6])) # Mon, 04 Nov 2019 02:00:00 GMT
				startTIMES = startDATES.strftime('%d{0}%m{0}%Y').format('.')
			except: pass
			if startTIMES: Note_1 = '[COLOR yellow]'+str(startTIMES)+'[/COLOR][CR]'
			desc = re.compile('<descriptio[^>]+>([^<]+)</description>', re.DOTALL).findall(item)
			Note_2 = cleaning(desc[0]) if desc else ""
			plot = Note_1+Note_2
			audio_url = re.compile('<enclosure url="([^"]+)" type=', re.DOTALL).findall(item)
			COMBI_FIRST.append([int(counter), title, plot, startURL, link])
			COMBI_LINKS.append(str(counter)+'@@'+link+'@@'+title+'@@'+startURL+'@@')
			if audio_url:
				mp3 = audio_url[0]
				if 'podcast_19600' in mp3:
					photo = 'https://cdn.podigee.com/uploads/u6682/f0513f65-3de9-4fab-99c9-85615bbe6a8e.jpg'
				elif 'podcast_18516' in mp3:
					photo = 'https://cdn.podigee.com/uploads/u6682/ac2fb912-bfa3-4102-bdb3-d08cee66677e.jpg'
				running = re.compile('<itunes:duration>([^<]+)</itunes:duration>', re.DOTALL).findall(item)
				duration = running[0] if running else '0'
				COMBI_READY.append([int(counter), title, photo, mp3, duration, plot, startURL, link])
		if COMBI_READY:
			for counter, title, photo, mp3, duration, plot, startURL, link in COMBI_READY:
				if (mp3 and not 'serien-1762' in startURL) or (mp3 and 'serien-1762' in startURL and 'heusener-hoheneder' in link):
					debug_MS("(navigator.listFeedsRSS) no.03 ### TITLE = {0} || audioURL = {1} || PHOTO = {2} ###".format(title, mp3, photo))
					addLink(title, photo, {'mode': 'playVideo', 'url': mp3, 'extras': 'standard'}, plot, duration)
		else:
			debug_MS("(navigator.listFeedsRSS) no.04 ### COMBI_FIRST = {0} ###".format(str(COMBI_FIRST)))
			COMBI_SECOND = getMultiData(COMBI_LINKS)
			if COMBI_FIRST and COMBI_SECOND:
				debug_MS("~~~~~~~~~~~~~~~~~~~~~~~~~")
				RESULT = [a + [b[0]] + [b[1]] + [b[2]] + [b[3]] + [b[4]] for a in COMBI_FIRST for b in COMBI_SECOND if a[0] == b[0]]
				RESULT = sorted(RESULT, key=lambda k: (k[0], k[5]), reverse=False)
				for da in RESULT:
					NUM1, TITLE1, DESC1, START1, LINK1, NUM2, TITLE2, PIC2, AUD2, DUR2 = da[0], da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8], da[9]
					if (AUD2 and not 'serien-1762' in START1) or (AUD2 and 'serien-1762' in START1 and 'heusener-hoheneder' in LINK1):
						name = TITLE2 if TITLE2 else TITLE1
						debug_MS("(navigator.listFeedsRSS) no.05 ### TITLE = {0} || audioURL = {1} || PHOTO = {2} ###".format(name, AUD2, PIC2))
						addLink(name, PIC2, {'mode': 'playVideo', 'url': AUD2, 'extras': 'standard'}, cleaning(DESC1), DUR2)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPodcasts(url):
	debug_MS("(navigator.listPodcasts) -------------------------------------------------- START = listPodcasts --------------------------------------------------")
	debug_MS("(navigator.listPodcasts) ### URL = {0} ###".format(url))
	morePLOT = []
	startURL = url
	html = getUrl(url)
	if 'programm' in url:
		spl = html.split('<div id="podlovePlayer')
		for i in range(1, len(spl), 1):
			entry = spl[i]
			title = re.compile('title: "([^"]+?)"', re.DOTALL).findall(entry)[-2]
			title = cleaning(title)
			link = re.compile('url: "(http.*?.mp3)"', re.DOTALL).findall(entry)[0]
			debug_MS("(navigator.listPodcasts) no.01 ### TITLE = {0} || LINK = {1} ###".format(title, link))
			addLink(title, artpic+'podcast.jpg', {'mode': 'playVideo', 'url': link, 'extras': 'standard'})
	else:
		podcast = re.findall('<article class="article__details">(.*?)</div></article></div>', html, re.S)[0]
		spl = podcast.split('<div class="podlovePlayer') if 'gaming-news' in url else podcast.split('<h2')
		for i in range(1, len(spl), 1):
			entry = spl[i]
			debug_MS("(navigator.listPodcasts) no.02 ##### FOLGE : {0} #####".format(str(entry)))
			title, plot, subtitle = ("" for _ in range(3))
			mp3 = None
			duration = '0'
			if not 'gaming-news' in url:
				if not 'serie' in url:
					title = re.compile('<h1 class=["\']article__title["\']>([^<]+?)</h1>', re.DOTALL).findall(entry)[0]
				else:
					title = re.compile('>([^<]+?)</h2>', re.DOTALL).findall(entry)[0]
				title = cleaning(title)
			desc = re.compile('<p>(.*?)</p>').findall(entry)
			if desc: plot = cleaning(re.sub('\<.*?\>', '', desc[0]))
			DATA = re.compile('data-audio=["\']{([^<]+)}["\']></div>', re.DOTALL).findall(entry)
			for element in DATA:
				element = element.replace('&quot;', '"').replace('&amp;', '&').replace('[{', '')
				debug_MS("(navigator.listPodcasts) no.03 ##### ELEMENT : {0} #####".format(str(element)))
				img = re.compile('"poster":"(.+?(?:\.png|\.jpg|\.jpeg))"', re.DOTALL).findall(element)
				photo = BASE_URL+img[0] if img else artpic+'podcast.jpg'
				audio_url = re.compile('"url":"(https?://.*?.mp3)"', re.DOTALL).findall(element)
				mp3 = audio_url[0] if audio_url else None
				if not 'serie' in startURL:
					try: 
						subtitle = re.compile('],"title":"(.*?)","summary', re.DOTALL).findall(element)[0]
						subtitle = cleaning(subtitle)
						if title !="" and title not in subtitle: title = title+' - '+subtitle
						else: title = subtitle
					except: pass
				running = re.compile('"duration":"([0-9]+):([0-9]+)"', re.DOTALL).findall(element)
				duration = int(running[0][0])*60+int(running[0][1]) if running else '0'
				if mp3: addLink(title, photo, {'mode': 'playVideo', 'url': mp3, 'extras': 'standard'}, plot, duration)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(url):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS("(navigator.listVideos) ### URL = {0} ###".format(url))
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND = ([] for _ in range(3))
	counter = 0
	firstRE = getUrl(url)
	spl = firstRE.split('__image card-image">')
	for i in range(1, len(spl), 1):
		entry = spl[i]
		counter += 1
		title = re.compile('<h3 class=["\']news-teaser__title["\']>([^<]+?)</h3>', re.DOTALL).findall(entry)[0]
		title = cleaning(title)
		link = re.compile('class=["\']cover-link["\'] href=["\']([^"]+?)["\']>', re.DOTALL).findall(entry)[0].replace('../', '/')
		link = BASE_URL+link if link[:4] != 'http' else link
		COMBI_FIRST.append([int(counter), title, link])
		COMBI_LINKS.append(str(counter)+'@@'+link)
	if COMBI_FIRST:
		debug_MS("(navigator.listVideos) no.01 ### COMBI_FIRST = {0} ###".format(str(COMBI_FIRST)))
		COMBI_SECOND = getMultiData(COMBI_LINKS, 'VIDEOS')
		if COMBI_SECOND:
			debug_MS("~~~~~~~~~~~~~~~~~~~~~~~~~")
			RESULT = [a + [b[0]] + [b[1]] + [b[2]] + [b[3]] + [b[4]] + [b[5]] for a in COMBI_FIRST for b in COMBI_SECOND if a[0] == b[0]]
			for sign in RESULT:
				if sign[4][:10].replace('.', '').replace('-', '').isdigit():
					RESULT = sorted(RESULT, key=lambda sign: time.mktime(time.strptime(sign[4], '%d.%m.%Y')), reverse=True)
			for da in RESULT:
				NUM1, TITLE1, LINK1, NUM2, DATE2, VID2, PIC2, DESC2, TYPE2 = da[0], da[1], da[2], da[3], da[4], da[5], da[6], da[7], da[8]
				if VID2:
					debug_MS("(navigator.listVideos) no.02 ### TITLE = {0} || vidURL = {1} || PHOTO = {2} ###".format(TITLE1, VID2, PIC2))
					addLink(TITLE1, PIC2, {'mode': 'playVideo', 'url': VID2, 'extras': TYPE2}, DESC2)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

COMBI_OUTPUT = []
pill2kill = threading.Event()
def listSubstances(parts, pill2kill, course):
	num = parts.split('@@')[0]
	elem = parts.split('@@')[1]
	firstTI = parts.split('@@')[2] if course=='FEEDS' else ""
	firstUL = parts.split('@@')[3] if course=='FEEDS' else ""
	if not pill2kill.is_set():
		try:
			UN_Supported = ['1548.rss', '4263.rss', '4393.rss']
			photo, subtitle, plot = ("" for _ in range(3))
			title, mp3 = (None for _ in range(2))
			duration = '0'
			if course == 'FEEDS':
				content = getUrl(elem)
				podcast = re.findall('<article class="article__details">(.*?)</div></article></div>', content, re.S)[0]
				DATA = re.compile('class=["\']podlovePlayer["\'] data-audio=["\']{([^<]+)}["\']></div>', re.DOTALL).findall(podcast)
				for element in DATA:
					element = element.replace('&quot;', '"').replace('&amp;', '&').replace('[{', '')
					try: photo = BASE_URL+'/files/'+re.compile('<div class=["\']card-image["\']><img.*?src=["\']([^"]+?)["\'] data', re.DOTALL).findall(podcast)[0].split('source=')[1].split('&amp;')[0]
					except: pass
					if photo == "":
						img2 = re.compile('"poster":"(https?://.+?(?:\.png|\.jpg|\.jpeg))"', re.DOTALL).findall(element)
						photo = img2[0] if img2 else ""
					audio_url = re.compile('"url":"(https?://.*?.mp3)"', re.DOTALL).findall(element)
					mp3 = audio_url[0] if audio_url else None
					if not 'comedy' in firstUL:
						try: 
							subtitle = re.compile('],"title":"(.*?)","summary', re.DOTALL).findall(element)[0]
							subtitle = cleaning(subtitle)
							if firstTI !="" and subtitle != "" and subtitle not in firstTI and not any(x in firstUL for x in UN_Supported):
								title = firstTI+' - '+subtitle
							else: title = subtitle
						except: pass
					running = re.compile('"duration":"([0-9]+):([0-9]+)"', re.DOTALL).findall(element)
					duration = int(running[0][0])*60+int(running[0][1]) if running else '0'
					COMBI_OUTPUT.append([int(num), title, photo, mp3, duration])
			elif course == 'VIDEOS':
				content = getUrl(elem)
				spl = content.split('<article class="article__details">')
				for i in range(1, len(spl), 1):
					item = spl[i]
					desc1 = re.compile('<p[^>]*>(.*?)</p>', re.DOTALL).findall(item)[0][:-6]
					desc1 = re.sub('\<.*?\>', '', desc1)
					desc2 = re.compile('<p[^>]*>(.*?)</p>', re.DOTALL).findall(item)[2]
					desc2 = re.sub('\<.*?\>', '', desc2)
					matching = re.search(r'\b(\d{2})\.(\d{2})\.(\d{4})\b', desc1)
					dt = matching.group() if matching else 'NDF'
					plot = '[COLOR yellow]'+cleaning(desc1)+'[/COLOR][CR][CR]'+cleaning(desc2)
					video = re.compile(r'<iframe.+?src=["\']([^"]+?)["\'] (?:width|frameborder)', re.DOTALL).findall(item)[0].replace('&amp;', '&').replace('%3A', ':').replace('%2F', '/')
					if not 'youtube' in video.lower():
						thirdRE = getUrl(video)
						photo = re.compile('<img class=["\']_1p6f _3fnw img["\'] src=["\']([^"]+?)["\']', re.DOTALL).findall(thirdRE)[0].replace('&amp;', '&')
						try: vidURL = re.compile('"hd_src":"([^"]+)",', re.DOTALL).findall(thirdRE)[0].replace('\/', '/').replace('\u00253F', '%3F').replace('\u00253D', '%3D').replace('\u00257E', '%7E').replace('\u00252A', '%2A')
						except:
							try: vidURL = re.compile('"sd_src":([^"]+)",', re.DOTALL).findall(thirdRE)[0].replace('\/', '/').replace('\u00253F', '%3F').replace('\u00253D', '%3D').replace('\u00257E', '%7E').replace('\u00252A', '%2A')
							except: vidURL = None
						TYPE = 'standard'
					else:
						photo = re.compile('<div class=["\']card-image["\']><img alt=.*?src=["\']([^"]+?)["\']', re.DOTALL).findall(item)[0]
						photo = BASE_URL+'/files/'+photo.split('source=')[1].split('&amp;')[0]
						vidURL = video.split('/')[-1]
						TYPE = 'YTstream'
					COMBI_OUTPUT.append([int(num), dt, vidURL, photo, plot, TYPE])
		except:
			stop()
			formatted_lines = traceback.format_exc().splitlines()
			failing("(navigator.listSubstances) ERROR - ERROR - ERROR :\n{0} \n{1} \n{2}".format(formatted_lines[1], formatted_lines[2], formatted_lines[3]))

def stop():
	pill2kill.set()

def getMultiData(simultan, event='FEEDS'):
	debug_MS("(navigator.getMultiData) ------------------------------------------------ START = getMultiData -----------------------------------------------")
	threads = []
	debug_MS("(navigator.getMultiData) ganze LISTE XXXXX {0} XXXXX".format(' || '.join(simultan)))
	for article in simultan:
		th = threading.Thread(target=listSubstances, args=[article, pill2kill, event])
		if hasattr(th, 'daemon'): th.daemon = True
		else: th.setDaemon()
		threads.append(th)
	[th.start() for th in threads]
	threading.Timer(25, after_timeout, [threads, pill2kill]).start()
	[th.join(3) for th in threads]
	if COMBI_OUTPUT:
		debug_MS("+++++++++++++++++++++++++")
		debug_MS("(navigator.listSubstances) Ergebnis XXXXX COMBI_OUTPUT = {0} XXXXX".format(str(COMBI_OUTPUT)))
	return COMBI_OUTPUT

def after_timeout(threads, pill2kill):
	counter = 0
	for th in threads:
		if th.is_alive() and counter == 0:
			counter += 1
			failing("(navigator.getMultiData) ##### TIMEOUT FOR RUNNING THREADS IS REACHED - KILLING THEM ALL !!! #####")
			pill2kill.set()
	return

def playVideo(url, TYPE):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL = {0} ### TYPE = {1} ###".format(url, TYPE))
	action = TYPE.split('@@')[0] if '@@' in TYPE else TYPE
	log("(navigator.playVideo) StreamURL : {0} || TYPE : {1}".format(url, action))
	if xbmc.Player().isPlaying():
		xbmc.Player().stop()
	if action == 'YTstream':
		finalURL = 'plugin://plugin.video.youtube/play/?video_id='+url
		listitem = xbmcgui.ListItem(path=finalURL)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	elif action == 'DIRECTstream':
		field = TYPE.split('@@')
		listitem = xbmcgui.ListItem(field[1])
		listitem.setArt({'icon': field[2], 'thumb': field[2], 'poster': field[2], 'fanart': defaultFanart})
		xbmc.Player().play(item=url, listitem=listitem)
	else:
		listitem = xbmcgui.ListItem(path=url)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)

def addDir(name, image, params={}, plot=None):
	exclusion = (artpic+'podcast.jpg', artpic+'radio.jpg', artpic+'video.jpg', artpic+'ytcom.jpg')
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and (not artpic in image or image.endswith(exclusion)):
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=True)

def addLink(name, image, params={}, plot=None, duration=None, rating=None, votes=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Duration': duration, 'Rating': rating, 'Votes': votes})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	if not 'DIRECTstream' in params.get('extras'):
		liz.setProperty('IsPlayable', 'true')
		liz.setContentLookup(False)
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
