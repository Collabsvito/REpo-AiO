﻿# -*- coding: utf-8 -*-

from .common import *
from .provider import Client
config = traversing.get_config()


def mainMenu():
	for TITLE, IMG, STORY, PATH in [(30601, 'radio', 32101, {'mode': 'listRadios'}), (30602, 'podcast', 32102, {'mode': 'listNews'}),
		(30603, 'podcast', 32103, {'mode': 'listFeeds', 'link': config['BESTE_GE']}), (30604, 'podcast', 32104, {'mode': 'listFeeds', 'link': config['STARS_ZG']}),
		(30605, 'podcast', 32105, {'mode': 'listFeeds', 'link': config['EXPERTEN']}), (30606, 'podcast', 32106, {'mode': 'listFeeds', 'link': config['COMEDY']}),
		(30607, 'podcast', 32107, {'mode': 'listFeeds', 'link': config['ATZE_KWNW']}), (30608, 'podcast', 32108, {'mode': 'listFeeds', 'link': config['NULL_POTT']}),
		(30609, 'podcast', 32109, {'mode': 'listFeeds', 'link': config['LISA_FELLER']}), (30610, 'podcast', 32110, {'mode': 'listFeeds', 'link': config['NELSON_MK']}),
		(30611, 'podcast', 32111, {'mode': 'listFeeds', 'link': config['WELT_IN30S']})]:
		addDir(PATH, create_entries({'Title': translation(TITLE), 'Plot': translation(STORY), 'Image': f"{artpic}{IMG}.jpg"}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30612), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listRadios():
	debug_MS("(navigator.listRadios) -------------------------------------------------- START = listRadios --------------------------------------------------")
	for pick in config['picks']:
		ident, name, plot = pick['rpID'], cleaning(pick['label']), cleaning(pick['description'])
		audio_url, thumb = pick['urltable_url'], stapic+pick['thumb']
		addition = f"RADIOstream@@{name}@@{thumb}@@"
		debug_MS(f"(navigator.listRadios[1]) ##### TITLE : {name} || CID : {ident} || AUDIO_LINK : {audio_url} #####")
		addDir({'mode': 'playMedia', 'link': audio_url, 'extras': addition}, create_entries({'Title': name, 'Plot': plot, 'Mediatype': 'episode', 'Image': thumb}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listNews():
	debug_MS("(navigator.listNews) -------------------------------------------------- START = listNews --------------------------------------------------")
	for TITLE, IMG, STORY, SLUG in [(30621, 'news_kompakt', 32121, config['NEWS_KOMPAKT']), (30622, 'news_lokal', 32122, config['NEWS_LOKAL']),
		(30623, 'news_world', 32123, config['NEWS_WORLD'])]:
		name = re.sub(r'\[/?B\]', '', translation(TITLE))
		addition = f"DIRECTstream@@{name}@@{artpic}{IMG}.png@@"
		debug_MS(f"(navigator.listNews[1]) ##### TITLE : {name} || AUDIO_LINK : {SLUG} #####")
		addDir({'mode': 'playMedia', 'link': SLUG, 'extras': addition}, create_entries({'Title': translation(TITLE), 'Plot': translation(STORY), \
			'Mediatype': 'episode', 'Image': f"{artpic}{IMG}.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listFeeds(TARGET):
	debug_MS("(navigator.listFeeds) -------------------------------------------------- START = listFeeds --------------------------------------------------")
	debug_MS(f"(navigator.listFeeds) ### TARGET = {TARGET} ###")
	counter, UNIKAT, (COMBI_FIRST, COMBI_LINKS, COMBI_SECOND) = 0, set(), ([] for _ in range(3))
	INCLUDED, content = ['so weit, so gut', 'zufälligste wissen'], getContent(TARGET)
	for item in content:
		(note_1, note_2), (startTIMES, airdate) = ("" for _ in range(2)), (None for _ in range(2))
		ident = item.get('id', None)
		if ident is None or ident in UNIKAT:
			continue
		UNIKAT.add(ident)
		counter += 1
		debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
		debug_MS(f"(navigator.listFeeds[1]) xxxxx POSITION : {counter} || EPISODE-01 : {item} xxxxx")
		transfer = f"{BASE_URL}/newsroom/news?news_id={ident}" # https://www.lippewelle.de/newsroom/news?news_id=2298878
		part_uno = item['teaser'].get('og_short', None)
		part_due = item['teaser'].get('og_description', None) # part_uno+part_due, wenn id=3923 in Url
		part_tre = item['teaser'].get('push_title', None) # wenn INCLUDED im Titel
		title = f"{part_uno} {part_due.replace('.', '')}" if part_uno and part_due and 'category_id=3923' in TARGET else \
			part_tre.replace('der psychologische Endspurt ', '') if part_tre and any(ice in part_tre.lower() for ice in INCLUDED) else part_uno
		if str(item.get('publish_date'))[:4].isdecimal():
			LOCALstart = get_CentralTime(item['publish_date'])
			startTIMES = LOCALstart.strftime('%a, %d.%m.%Y')
			airdate = LOCALstart.strftime('%d.%m.%Y') # FirstAired
			for av in (('Mon', translation(32201)), ('Tue', translation(32202)), ('Wed', translation(32203)), ('Thu', translation(32204)),\
				('Fri', translation(32205)), ('Sat', translation(32206)), ('Sun', translation(32207))): startTIMES = startTIMES.replace(*av)
		if startTIMES: note_1 = translation(30624).format(startTIMES)
		note_2 = (cleaning(item['teaser'].get('text', '')) or cleaning(item['teaser'].get('text_short', '')))
		COMBI_FIRST.append([int(counter), transfer, title, airdate, note_1, note_2, TARGET])
		COMBI_LINKS.append([int(counter), transfer])
	if COMBI_LINKS:
		COMBI_SECOND = listCompletion(COMBI_LINKS)
	if COMBI_FIRST and COMBI_SECOND: # Zähler NULL ist immer die Nummerierung der Listen 1+2
		SYNOPSIS = [ac + bd for ac in COMBI_FIRST for bd in COMBI_SECOND if ac[0] == bd[0] and ac[1] == bd[1]] # Zusammenführung von Liste1 und Liste2 - wenn die Nummer an erster Stelle(0) und die LINK-ID an zweiter Stelle(1) überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listFeeds[3]) XXXXX SYNOPSIS-03 : {SYNOPSIS} XXXXX")
		for xev in sorted(SYNOPSIS, key=lambda pn: int(pn[0])): # 0-6 = Liste1 || 7-12 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listFeeds[3]) ### Anzahl : {len(xev)} || Eintrag : {xev} ###")
			if len(xev) > 7: ### Liste2 beginnt mit Nummer: 7 ###
				Link1, name, aired, published, Desc1, starturl = xev[1], xev[2], xev[3], xev[4], xev[5], xev[6]
				Link2, Desc2, image, duration, audio = xev[8], xev[9], xev[10], xev[11], xev[12]
			else: continue
			if re.search(r'(Folge #|Folge#)', name): # Folgen-Titel bereinigen für Beste Gäste und Expertenrunde reloaded
				try:
					CLEAR_TITLE = re.findall('Folge(?: #0| #|#0|#)([0-9]+):? (.*)', name, re.S)
					name = f"Folge {CLEAR_TITLE[0][0]}: {CLEAR_TITLE[0][1]}"
				except: pass
			SAME = True if Desc1[:80] == Desc2[:80] else False
			plot = f"{published}{Desc1}" if SAME or 'id=6317' in starturl else f"{published}{Desc1}[CR][CR]{Desc2}"
			debug_MS(f"(navigator.listFeeds[4]) ##### TITLE : {name} || AUDIO_LINK : {audio} || THUMB : {image} #####")
			FETCH_UNO = {'Title': name, 'Plot': plot, 'Duration': duration, 'Aired': aired, 'Year': aired, \
				'Studio': 'Radio-Lippewelle.de', 'Mediatype': 'episode', 'Image': image, 'Reference': 'Single'}
			addDir({'mode': 'playMedia', 'link': audio}, create_entries(FETCH_UNO), False)
	xbmcplugin.setContent(ADDON_HANDLE, 'videos')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listCompletion(MURLS):
	debug_MS("(navigator.listCompletion) -------------------------------------------------- START = listCompletion --------------------------------------------------")
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		DATA_RIDER = json.loads(COMBI_DETAILS)
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.llistCompletion[2]) XXXXX CONTENT-02 : {DATA_RIDER} XXXXX")
		for elem in DATA_RIDER:
			if elem is not None and elem.get('story', '') and len(elem['story']) > 0:
				BODIES = next(filter(lambda au: au.get('type', '') == 'audioplayer' and au.get('data', {}), elem.get('story', [])), None)
				SOCIAL = next(filter(lambda so: so.get('type', '') == 'socialmedia' and so.get('data', {}), elem.get('story', [])), None)
				TEASER = list(filter(lambda pa: pa.get('type', '') == 'paragraphs' and pa.get('value', {}), elem.get('story', [])))[:2]
				POS_2, NAV_2, AUDIO_2 = elem['Position'], elem['NaviLink'], None
				if BODIES or SOCIAL:
					debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
					debug_MS(f"(navigator.listCompletion[2]) xxxxx POSITION : {POS_2} || ELEMENT-02 : {BODIES if BODIES else SOCIAL} xxxxx")
					THUMB_2 = BASE_URL+elem['teaser']['image']['url'] if elem.get('teaser', '') and elem['teaser'].get('image', '') and elem['teaser']['image'].get('url', '') else f"[{artpic}podcast.jpg"
					TIME_2 = get_RunTime(BODIES['data'].get('audiolength', None)) if BODIES else get_RunTime(SOCIAL['data'].get('audiolength', None)) if SOCIAL else None
					STORY_2 = '[CR][CR]'.join([cleaning(tea.get('value', '')) for tea in TEASER]) if TEASER else ""
					if BODIES:
						AUDIO_2 = BASE_URL+BODIES['data']['file']['url'] if BODIES['data'].get('file', '') and BODIES['data']['file'].get('url', '') else BODIES['data']['audioexternal'] if BODIES['data'].get('audioexternal', '') else None
					elif SOCIAL and SOCIAL['data'].get('embedcode', ''): # https://podcasts.podcastmaker.de/23/1/21846
						MP3_UNO = re.compile(r'''document.write\(httpGet\(["'](https://podcasts.+?)/podcast.html["']''', re.S).findall(SOCIAL['data']['embedcode'])
						MP3_DUE = re.compile(r'''<script src=https://podcasts.podcastmaker.de/embeddingCode.php\?podcastID=([0-9]+)&aggID=([0-9]+)&episodeID=([0-9]+) type=text/javascript>''', re.S).findall(SOCIAL['data']['embedcode'])
						AUDIO_2 = MP3_UNO[0] if MP3_UNO else f"https://podcasts.podcastmaker.de/{MP3_DUE[0][0]}/{MP3_DUE[0][1]}/{MP3_DUE[0][2]}" if MP3_DUE else None
					if AUDIO_2:
						COMBI_THIRD.append([int(POS_2), NAV_2, STORY_2, THUMB_2, TIME_2, AUDIO_2])
	return COMBI_THIRD

def playMedia(FINAL_URL, RIDERS):
	debug_MS("(navigator.playMedia) -------------------------------------------------- START = playMedia --------------------------------------------------")
	debug_MS(f"(navigator.playMedia) ### TARGET = {FINAL_URL} || EXTRAS = {RIDERS} ###")
	action = RIDERS.split('@@')[0] if '@@' in RIDERS else RIDERS
	log(f"(navigator.playMedia) StreamURL = {FINAL_URL} || ACTION = {action}")
	if xbmc.Player().isPlaying():
		xbmc.Player().stop()
	xbmc.PlayList(1).clear()
	if action in ['DIRECTstream', 'RADIOstream']:
		LSM = xbmcgui.ListItem(RIDERS.split('@@')[1])
		LSM.setArt({'icon': icon, 'thumb': RIDERS.split('@@')[2], 'poster': RIDERS.split('@@')[2], 'fanart': defaultFanart})
		xbmc.Player().play(item=FINAL_URL, listitem=LSM)
		if action == 'RADIOstream':
			while xbmc.Player().isPlayingRDS():
				rds_tag = xbmc.Player().getRadioRDSInfoTag()
				title, artist, infos = rds_tag.getTitle(), rds_tag.getArtist(), rds_tag.getInfoNews()
				xbmc.Player().updateInfoTag(rds_tag)
				xbmc.sleep(300)
	else:
		LSM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)

def addDir(params, listitem, folder=True):
	uws = build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
