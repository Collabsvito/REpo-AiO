﻿# -*- coding: utf-8 -*-


class Client(object):
	CONFIG_LIPPEWELLE = {
		'BESTE_GE': 'https://www.lippewelle.de/newsroom/category?category_id=3923&from=0&size=100',
		'STARS_ZG': 'https://www.lippewelle.de/newsroom/category?category_id=6247&from=0&size=200',
		'EXPERTEN': 'https://www.lippewelle.de/newsroom/category?category_id=5046&from=0&size=100',
		'COMEDY': 'https://www.lippewelle.de/newsroom/category?category_id=1593&from=0&size=200',
		'ATZE_KWNW': 'https://www.lippewelle.de/newsroom/category?category_id=6490&from=0&size=200',
		'NULL_POTT': 'https://www.lippewelle.de/newsroom/category?category_id=6511&from=0&size=200',
		'LISA_FELLER': 'https://www.lippewelle.de/newsroom/category?category_id=7161&from=0&size=200',
		'NELSON_MK': 'https://www.lippewelle.de/newsroom/category?category_id=6317&from=0&size=200',
		'WELT_IN30S': 'https://www.lippewelle.de/newsroom/category?category_id=6269&from=0&size=200',
		'NEWS_KOMPAKT': 'https://podcasts.podcastmaker.de/14/0/5864/latest',
		'NEWS_LOKAL': 'https://content.lippewelle.de/audio/news/news_lokal.mp3',
		'NEWS_WORLD': 'https://content.lippewelle.de/audio/news/news_welt.mp3',
		'picks': [
		{
			'rpID': '222',
			'label': 'LIVE',
			'description': 'Radio Lippewelle Hamm ist das Lokalradio für Hamm. Bei uns hört ihr 24 Stunden am Tag den besten Mix und die wichtigsten Nachrichten aus Hamm und der Welt.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=ralwh&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/4454253',
			'thumb': 'live.png',
			'route': '1'
		},
		{
			'rpID': '796',
			'label': '80er Radio',
			'description': 'Von Michael Jackson bis Madonna: Die größten Hits der 80er im Lieblingsmix.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-80er&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/445c398',
			'thumb': '80er.png',
			'route': '2'
		},
		{
			'rpID': '921',
			'label': '90er Radio',
			'description': 'Von Backstreet Boys bis Spice Girls: Die besten Hits der 90er - nonstop!',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-90er&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/445c3hg',
			'thumb': '90er.png',
			'route': '3'
		},
		{
			'rpID': '2310',
			'label': '2000er Radio',
			'description': 'Die 2000er Jahre (2000 - 2019) waren musikalisch eine sehr aufregende Zeit: Neue Sängerinnen wie Anastacia, Rihanna oder Lady Gaga mischten die Musikszene gewaltig auf und eroberten die Charts.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-2000er&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/4456wh5',
			'thumb': '2000er.png',
			'route': '4'
		},
		{
			'rpID': '798',
			'label': 'TOP 40 Radio',
			'description': 'Die beliebteste Musik aus den aktuellen Charts.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-top40&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/445c5hd',
			'thumb': 'top40.png',
			'route': '5'
		},
		{
			'rpID': '800',
			'label': 'Urban Radio',
			'description': 'Urbanes Feeling mit den Hits von gestern und heute.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-urban&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/445c5qm',
			'thumb': 'urban.png',
			'route': '6'
		},
		{
			'rpID': '797',
			'label': 'Lounge Radio',
			'description': 'Der beste Mix zum Entspannen und Relaxen.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-lounge&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/444zt53',
			'thumb': 'lounge.png',
			'route': '7'
		},
		{
			'rpID': '923',
			'label': 'LOVE Radio',
			'description': 'Von Bryan Adams bis Céline Dion: Die schönsten Lovesongs für Verliebte und Lieblingsmenschen.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-love&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/445c4mj',
			'thumb': 'love.png',
			'route': '8'
		},
		{
			'rpID': '922',
			'label': 'Deutsch-POP Radio',
			'description': 'Von Mark Forster bis Wincent Weiss: Der Deutsch-Pop Lieblingsmix.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-deutschpop&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/445c3qp',
			'thumb': 'deutschpop.png',
			'route': '9'
		},
		{
			'rpID': '924',
			'label': 'Schlager Radio',
			'description': 'Von Helene Fischer bis Andrea Berg: Alle Hits im besten Schlagermix.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-schlager&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/445c596',
			'thumb': 'schlager.png',
			'route': '10'
		},
		{
			'rpID': '2311',
			'label': 'Dance Radio',
			'description': 'Alles, was gerade in den angesagtesten Clubs läuft, befindet sich auf Dein Dance Radio. Von Calvin Harris bis David Guetta ist hier alles dabei, was aktuell aufgelegt wird.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-dance&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/4456jhh',
			'thumb': 'dance.png',
			'route': '11'
		},
		{
			'rpID': '2550',
			'label': 'Hip Hop Radio',
			'description': 'Von Kendrick Lamar bis Cardi B: Alles was in der Hip Hop - Szene gerade angesagt ist.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-hiphop&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/4458bt3',
			'thumb': 'hiphop.png',
			'route': '12'
		},
		{
			'rpID': '799',
			'label': 'Rock Radio',
			'description': "Von AC/DC bis Guns N' Roses: Der beste Rockmix.",
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-rock&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/444zyw3',
			'thumb': 'rock.png',
			'route': '13'
		},
		{
			'rpID': '2548',
			'label': 'Rock-Classic Radio',
			'description': 'Von Led Zeppelin bis Deep Purple: Der Rockmix in der Classic Variante.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-rockclassic&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/44578gs',
			'thumb': 'classic.png',
			'route': '14'
		},
		{
			'rpID': '1822',
			'label': 'Oldie Radio',
			'description': '60er, 70er & 80er nonstop: Das ist das Radio für alle Dancing Queens und Moviestars. Mit Flowerpower-Garantie, den Discohits für jede Party und den Mega-Stars, die unvergessen bleiben.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-oldie&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/44548bb',
			'thumb': 'oldie.png',
			'route': '15'
		},
		{
			'rpID': '2549',
			'label': 'New-Country Radio',
			'description': 'Von Luke Combs bis Kacey Musgraves: Neue Countrymusik beliebt bei alt und jung.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-newcountry&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/4457ytf',
			'thumb': 'country.png',
			'route': '16'
		},
		{
			'rpID': '2312',
			'label': 'Singer-Songwriter Radio',
			'description': 'Singer/Songwriter stehen hoch im Kurs. Spätestens seit Ed Sheeran sind Musiker, die sich einfach mit der Gitarre auf die Bühne stellen, total angesagt. Handgemachte Musik mit poetischen Texten ist...',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-singer&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/44566hv',
			'thumb': 'singer.png',
			'route': '17'
		},
		{
			'rpID': '2902',
			'label': 'SOMMER Radio',
			'description': 'Von Bob Marley bis Daft Punk: Hier und jetzt im Sommer-Radio.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-sommer&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/4457mgf',
			'thumb': 'sommer.png',
			'route': '18'
		},
		{
			'rpID': '1821',
			'label': 'KARNEVALS Radio',
			'description': 'Das Radio mit Partygarantie: Die fünfte Jahreszeit - rund um die Uhr. Hier gibt es alle jecken Hits und die besten Partykracher. Feiert mit... nicht nur zu Karneval.',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-karneval&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/445c486',
			'thumb': 'karneval.png',
			'route': '19'
		},
		{
			'rpID': '925',
			'label': 'WEIHNACHTS Radio',
			'description': 'Der beste Weihnachtsmix für die schönste Zeit des Jahres. „Driving home for christmas – In der Weihnachtsbäckerei“. Von Wham bis Sinatra, von Mariah Carey bis Elvis!',
			'playlist_url': 'https://api-prod.nrwlokalradios.com/playlist/latest?station=rnrw-xmas&req_station=ralwh&count=3',
			'urltable_url': 'https://stream.lokalradio.nrw/445c3xw',
			'thumb': 'weihnacht.png',
			'route': '20'
		}],
	}

	def __init__(self, config):
		self._config = config

	def get_config(self):
		return self._config
