﻿# -*- coding: utf-8 -*-


class Client(object):
	CONFIG_LIPPEWELLE = {
		'BESTE_GE': 'https://www.lippewelle.de/thema/beste-gaeste-3923.rss',
		'STARS_ZG': 'https://www.lippewelle.de/thema/stars-zu-gast-6247.rss',
		'EXPERTEN': 'https://www.lippewelle.de/thema/die-expertenrunde-reloaded-5046.rss',
		'COMEDY': 'https://www.lippewelle.de/thema/comedy-1593.rss',
		'NELSON_MK': 'https://www.lippewelle.de/thema/nelson-muellers-kitchen-club-6317.rss',
		'ATZES_KALT': 'https://www.lippewelle.de/thema/atzes-kaltstart-6490.rss',
		'WELT_IN30S': 'https://www.lippewelle.de/thema/die-welt-in-30-sekunden-5237.rss',
		'NEWS_KOMPAKT': 'https://podcasts.podcastmaker.de/14/0/5864/latest',
		'NEWS_LOKAL': 'https://content.lippewelle.de/audio/news/news_lokal.mp3',
		'NEWS_WORLD': 'https://content.lippewelle.de/audio/news/news_welt.mp3',
		'picks': [
		{
			'rpID': '222',
			'label': 'LIVE',
			'description': 'Radio Lippewelle Hamm ist das Lokalradio für Hamm. Bei uns hört ihr 24 Stunden am Tag den besten Mix und die wichtigsten Nachrichten aus Hamm und der Welt.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=live',
			'audio_url': 'https://stream.lokalradio.nrw/4454253',
			'thumb': 'live.png',
			'route': '1'
		},
		{
			'rpID': '796',
			'label': '80er Radio',
			'description': 'Von Michael Jackson bis Madonna: Die größten Hits der 80er im Lieblingsmix.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-80er',
			'audio_url': 'https://stream.lokalradio.nrw/444zgn3',
			'thumb': '80er.png',
			'route': '2'
		},
		{
			'rpID': '921',
			'label': '90er Radio',
			'description': 'Von Backstreet Boys bis Spice Girls: Die besten Hits der 90er - nonstop!',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-90er',
			'audio_url': 'https://stream.lokalradio.nrw/444zjzk',
			'thumb': '90er.png',
			'route': '3'
		},
		{
			'rpID': '2310',
			'label': '2000er Radio',
			'description': 'Die 2000er Jahre (2000 - 2019) waren musikalisch eine sehr aufregende Zeit: Neue Sängerinnen wie Anastacia, Rihanna oder Lady Gaga mischten die Musikszene gewaltig auf und eroberten die Charts.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-2000er',
			'audio_url': 'https://stream.lokalradio.nrw/4456wh5',
			'thumb': '2000er.png',
			'route': '4'
		},
		{
			'rpID': '798',
			'label': 'TOP 40 Radio',
			'description': 'Die beliebteste Musik aus den aktuellen Charts.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-top40',
			'audio_url': 'https://stream.lokalradio.nrw/44525n3',
			'thumb': 'top40.png',
			'route': '5'
		},
		{
			'rpID': '800',
			'label': 'Urban Radio',
			'description': 'Urbanes Feeling mit den Hits von gestern und heute.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-urban',
			'audio_url': 'https://stream.lokalradio.nrw/44527zk',
			'thumb': 'urban.png',
			'route': '6'
		},
		{
			'rpID': '797',
			'label': 'Lounge Radio',
			'description': 'Der beste Mix zum Entspannen und Relaxen.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-lounge',
			'audio_url': 'https://stream.lokalradio.nrw/444zt53',
			'thumb': 'lounge.png',
			'route': '7'
		},
		{
			'rpID': '923',
			'label': 'LOVE Radio',
			'description': 'Von Bryan Adams bis Céline Dion: Die schönsten Lovesongs für Verliebte und Lieblingsmenschen.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-love',
			'audio_url': 'https://stream.lokalradio.nrw/444zwhk',
			'thumb': 'love.png',
			'route': '8'
		},
		{
			'rpID': '922',
			'label': 'Deutsch-POP Radio',
			'description': 'Von Mark Forster bis Wincent Weiss: Der Deutsch-Pop Lieblingsmix.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-deutschpop',
			'audio_url': 'https://stream.lokalradio.nrw/444znd3',
			'thumb': 'deutschpop.png',
			'route': '9'
		},
		{
			'rpID': '924',
			'label': 'Schlager Radio',
			'description': 'Von Helene Fischer bis Andrea Berg: Alle Hits im besten Schlagermix.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-schlager',
			'audio_url': 'https://stream.lokalradio.nrw/445238k',
			'thumb': 'schlager.png',
			'route': '10'
		},
		{
			'rpID': '2311',
			'label': 'Dance Radio',
			'description': 'Alles, was gerade in den angesagtesten Clubs läuft, befindet sich auf Dein Dance Radio. Von Calvin Harris bis David Guetta ist hier alles dabei, was aktuell aufgelegt wird.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-dance',
			'audio_url': 'https://stream.lokalradio.nrw/4456jhh',
			'thumb': 'dance.png',
			'route': '11'
		},
		{
			'rpID': '2550',
			'label': 'Hip Hop Radio',
			'description': 'Von Kendrick Lamar bis Cardi B: Alles was in der Hip Hop - Szene gerade angesagt ist.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-hiphop',
			'audio_url': 'https://stream.lokalradio.nrw/4458bt3',
			'thumb': 'hiphop.png',
			'route': '12'
		},
		{
			'rpID': '799',
			'label': 'Rock Radio',
			'description': "Von AC/DC bis Guns N' Roses: Der beste Rockmix.",
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-rock',
			'audio_url': 'https://stream.lokalradio.nrw/444zyw3',
			'thumb': 'rock.png',
			'route': '13'
		},
		{
			'rpID': '2548',
			'label': 'Rock-Classic Radio',
			'description': 'Von Led Zeppelin bis Deep Purple: Der Rockmix in der Classic Variante.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-rockclassic',
			'audio_url': 'https://stream.lokalradio.nrw/44578gs',
			'thumb': 'classic.png',
			'route': '14'
		},
		{
			'rpID': '1822',
			'label': 'Oldie Radio',
			'description': '60er, 70er & 80er nonstop: Das ist das Radio für alle Dancing Queens und Moviestars. Mit Flowerpower-Garantie, den Discohits für jede Party und den Mega-Stars, die unvergessen bleiben.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-oldie',
			'audio_url': 'https://stream.lokalradio.nrw/44548bb',
			'thumb': 'oldie.png',
			'route': '15'
		},
		{
			'rpID': '2549',
			'label': 'New-Country Radio',
			'description': 'Von Luke Combs bis Kacey Musgraves: Neue Countrymusik beliebt bei alt und jung.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-newcountry',
			'audio_url': 'https://stream.lokalradio.nrw/4457ytf',
			'thumb': 'country.png',
			'route': '16'
		},
		{
			'rpID': '2312',
			'label': 'Singer-Songwriter Radio',
			'description': 'Singer/Songwriter stehen hoch im Kurs. Spätestens seit Ed Sheeran sind Musiker, die sich einfach mit der Gitarre auf die Bühne stellen, total angesagt. Handgemachte Musik mit poetischen Texten ist...',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-singer',
			'audio_url': 'https://stream.lokalradio.nrw/44566hv',
			'thumb': 'singer.png',
			'route': '17'
		},
		{
			'rpID': '2902',
			'label': 'SOMMER Radio',
			'description': 'Von Bob Marley bis Daft Punk: Hier und jetzt im Sommer-Radio.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-sommer',
			'audio_url': 'https://stream.lokalradio.nrw/4457mgf',
			'thumb': 'sommer.png',
			'route': '18'
		},
		{
			'rpID': '1821',
			'label': 'KARNEVALS Radio',
			'description': 'Das Radio mit Partygarantie: Die fünfte Jahreszeit - rund um die Uhr. Hier gibt es alle jecken Hits und die besten Partykracher. Feiert mit... nicht nur zu Karneval.',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-karneval',
			'audio_url': 'https://stream.lokalradio.nrw/4454bpt',
			'thumb': 'karneval.png',
			'route': '19'
		},
		{
			'rpID': '925',
			'label': 'WEIHNACHTS Radio',
			'description': 'Der beste Weihnachtsmix für die schönste Zeit des Jahres. „Driving home for christmas – In der Weihnachtsbäckerei“. Von Wham bis Sinatra, von Mariah Carey bis Elvis!',
			'iframe_url': 'https://www.lippewelle.de/service/radioplayer.html?radiochannel=rnrw-xmas',
			'audio_url': 'https://stream.lokalradio.nrw/444zqrk',
			'thumb': 'weihnacht.png',
			'route': '20'
		}],
	}

	def __init__(self, config):
		self._config = config

	def get_config(self):
		return self._config
