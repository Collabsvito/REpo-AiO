﻿# -*- coding: utf-8 -*-

from .common import *
from .provider import Client
config = traversing.get_config()


def mainMenu():
	for TITLE, DESC, IMG, PATH in [(30601, 32101, 'radio', {'mode': 'listRadios'}), (30602, 32102, 'podcast', {'mode': 'listNews'}),
		(30603, 32103, 'podcast', {'mode': 'listFeeds', 'link': config['BESTE_GE']}), (30604, 32104, 'podcast', {'mode': 'listFeeds', 'link': config['STARS_ZG']}),
		(30605, 32105, 'podcast', {'mode': 'listFeeds', 'link': config['EXPERTEN']}), (30606, 32106, 'podcast', {'mode': 'listFeeds', 'link': config['COMEDY']}),
		(30607, 32107, 'podcast', {'mode': 'listFeeds', 'link': config['NELSON_MK']}), (30608, 32108, 'podcast', {'mode': 'listFeeds', 'link': config['ATZES_KALT']}),
		(30609, 32109, 'podcast', {'mode': 'listFeeds', 'link': config['WELT_IN30S']})]:
		addDir(PATH, create_entries({'Title': translation(TITLE), 'Plot': translation(DESC), 'Image': f"{artpic}{IMG}.jpg"}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listRadios():
	debug_MS("(navigator.listRadios) -------------------------------------------------- START = listRadios --------------------------------------------------")
	for pick in config['picks']:
		CID, name, plot = pick['rpID'], cleaning(pick['label']), cleaning(pick['description'])
		audio_url, thumb = pick['audio_url'], stapic+pick['thumb']
		addition = f"RADIOstream@@{name}@@{thumb}@@"
		debug_MS(f"(navigator.listRadios[1]) ##### TITLE : {name} || CID : {CID} || AUDIO_LINK : {audio_url} #####")
		addDir({'mode': 'playMedia', 'link': audio_url, 'extras': addition}, create_entries({'Title': name, 'Plot': plot, 'Mediatype': 'episode', 'Image': thumb}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listNews():
	debug_MS("(navigator.listNews) -------------------------------------------------- START = listNews --------------------------------------------------")
	for TITLE, DESC, IMG, SLUG in [(30621, 32121, 'news_kompakt', config['NEWS_KOMPAKT']), (30622, 32122, 'news_lokal', config['NEWS_LOKAL']),
		(30623, 32123, 'news_world', config['NEWS_WORLD'])]:
		name = re.sub(r'\[/?B\]', '', translation(TITLE))
		addition = f"DIRECTstream@@{name}@@{artpic}{IMG}.png@@"
		debug_MS(f"(navigator.listNews[1]) ##### TITLE : {name} || AUDIO_LINK : {SLUG} #####")
		addDir({'mode': 'playMedia', 'link': SLUG, 'extras': addition}, create_entries({'Title': translation(TITLE), 'Plot': translation(DESC), \
			'Mediatype': 'episode', 'Image': f"{artpic}{IMG}.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listFeeds(TARGET):
	debug_MS("(navigator.listFeeds) -------------------------------------------------- START = listFeeds --------------------------------------------------")
	debug_MS(f"(navigator.listFeeds) ### TARGET = {TARGET} ###")
	counter, UNIKAT, (COMBI_FIRST, COMBI_LINKS, COMBI_SECOND) = 0, set(), ([] for _ in range(3))
	EXCLUDED = ['5046.rss', '6317.rss', '6490.rss', '5237.rss'] # die-expertenrunde-reloaded-5046.rss; nelson-muellers-kitchen-club-6317.rss; atzes-kaltstart-6490.rss; die-welt-in-30-sekunden-5237.rss // Zweite Description ausschliessen
	content = getContent(TARGET)
	results = re.findall(r'<item>(.*?)</item>', content, re.S)
	for chtml in results:
		NOTE_1, startTIMES, AIRED_1 = "", None, None
		debug_MS(f"(navigator.listFeeds[1]) xxxxx EPISODE-01 : {chtml} xxxxx")
		agreeLK = re.compile(r'<link>([^<]+)</link>', re.S).findall(chtml)[0]
		WLINK_1 = agreeLK if agreeLK[:4] == 'http' else BASE_URL+agreeLK
		if WLINK_1 in UNIKAT:
			continue
		UNIKAT.add(WLINK_1)
		counter += 1
		TITLE_1 = cleaning(re.compile(r'<title>([^<]+)</title>', re.S).findall(chtml)[0])
		agreePUB = re.compile(r'<pubDate>([^<]+)</pubDate>', re.S).findall(chtml)[0]
		try:
			available = datetime(*(time.strptime(agreePUB[5:25], '%d %b %Y %H:%M:%S')[0:6])) # Mon, 04 Nov 2019 02:00:00 GMT
			startTIMES = available.strftime('%a, %d.%m.%Y')
			AIRED_1 = available.strftime('%d.%m.%Y')
			for av in (('Mon', translation(32201)), ('Tue', translation(32202)), ('Wed', translation(32203)), ('Thu', translation(32204)),\
				('Fri', translation(32205)), ('Sat', translation(32206)), ('Sun', translation(32207))): startTIMES = startTIMES.replace(*av)
		except: pass
		if startTIMES: NOTE_1 = translation(30624).format(startTIMES)
		agreePLOT = re.compile(r'<description>([^<]+)</description>', re.S).findall(chtml)
		NOTE_2 = cleaning(agreePLOT[0]) if agreePLOT else ""
		COMBI_FIRST.append([int(counter), WLINK_1, TITLE_1, AIRED_1, NOTE_1, NOTE_2, TARGET])
		COMBI_LINKS.append([int(counter), WLINK_1])
	if COMBI_LINKS:
		COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_FIRST and COMBI_SECOND: # Zähler NULL ist immer die Nummerierung der Listen 1+2
		SYNOPSIS = [ac + bd for ac in COMBI_FIRST for bd in COMBI_SECOND if ac[0] == bd[0] and ac[1] == bd[1]] # Zusammenführung von Liste1 und Liste2 - wenn die Nummer an erster Stelle(0) und die LINK-ID an zweiter Stelle(1) überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listFeeds[3]) XXXXX SYNOPSIS-03 : {SYNOPSIS} XXXXX")
		for xev in sorted(SYNOPSIS, key=lambda pn: int(pn[0])): # 0-6 = Liste1 || 7-13 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listFeeds[3]) ### Anzahl : {len(xev)} || Eintrag : {xev} ###")
			if len(xev) > 7: ### Liste2 beginnt mit Nummer:7 ###
				Link1, Title1, aired, Date, Desc1, starturl = xev[1], xev[2], xev[3], xev[4], xev[5], xev[6]
				Link2, Subtitle2, Desc2, image, duration, audio = xev[8], xev[9], xev[10], xev[11], xev[12], xev[13]
			else: continue # stars-zu-gast-6247.rss = Zweiten längeren Titel bevorzugen +++ beste-gaeste-3923.rss = Titel eins und Description eins zusammenfassen
			name = Subtitle2 if Subtitle2 and starturl.endswith('6247.rss') else f"{Title1} {Desc1}" if starturl.endswith('3923.rss') else Title1
			if re.search(r'(Folge #|Folge#)', name):
				try:
					CLEAR_TITLE = re.findall('Folge(?: #0| #|#0|#)([0-9]+):? (.*)', name, re.S)
					name = f"Folge {CLEAR_TITLE[0][0]}: {CLEAR_TITLE[0][1]}"
				except: pass
			SAME = True if Desc1 == Desc2.replace('[CR]', '') else False
			plot = f"{Date}{Desc1}" if SAME or any(ecz in starturl for ecz in EXCLUDED) else f"{Date}{Desc1}[CR][CR]{Desc2}"
			debug_MS(f"(navigator.listFeeds[4]) ##### TITLE : {name} || AUDIO_LINK : {audio} || THUMB : {image} #####")
			FETCH_UNO = create_entries({'Title': name, 'Plot': plot, 'Duration': duration, 'Aired': aired, 'Year': aired, \
				'Studio': 'Radio-Lippewelle.de', 'Mediatype': 'episode', 'Image': image, 'Reference': 'Single'})
			addDir({'mode': 'playMedia', 'link': audio}, FETCH_UNO, False)
	xbmcplugin.setContent(ADDON_HANDLE, 'videos')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSubstances(MURLS):
	debug_MS("(navigator.listSubstances) -------------------------------------------------- START = listSubstances --------------------------------------------------")
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.llistSubstances[2]) XXXXX CONTENT-02 : {COMBI_DETAILS} XXXXX")
		debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
		for number, WLINK_2, elem in COMBI_DETAILS:
			if elem is not None:
				podcast = re.findall(r'''<article class=["']article__details["']>(.*?)</div></article></div>''', elem, re.S)[0]
				articles = re.compile(r'''<div class=["']podlovePlayer["'] data-audio=["']{([^<]+)}["']></div>''', re.S).findall(podcast)
				if articles:
					for item in articles:
						item, DESC_2 = item.replace('&quot;', '"').replace('&amp;', '&').replace('[{', ''), ""
						debug_MS(f"(navigator.listSubstances[2.1]) xxxxx ARTICLE-01 : {item} xxxxx")
						DESC_2 = get_Description(podcast, item)
						if len(articles) == 1 and DESC_2 == "":
							matchPLOT = re.compile(r'podlovePlayer\(this, options\).then\(function\(store\).*?<p[^>]*>(.*?)</p>', re.S).findall(podcast)
							DESC_2 = cleaning(re.sub(r'\<.*?\>', '', matchPLOT[0])) if matchPLOT else ""
						matchIMG = re.compile(r'''["']poster["']:["'](.+?(?:\.png|\.jpg|\.jpeg))["']''', re.S).findall(item)
						THUMB_2 = matchIMG[0].replace(' ', '%20') if matchIMG and matchIMG[0][:4] == 'http' else BASE_URL+matchIMG[0] if matchIMG and matchIMG[0][:6] == '/files' else ""
						if THUMB_2 == "" or 'sendercovers/neutrales' in THUMB_2:
							matchIMG = re.compile(r'''<div class=["']card-image["']><img.*?src=["']([^"']+)["'] data-size''', re.S).findall(podcast)
							THUMB_2 = f"{BASE_URL}/files/{matchIMG[0].split('source=')[1].split('&amp;')[0]}" if matchIMG and 'source=' in matchIMG[0] else f"[{artpic}podcast.jpg"
						matchMP3 = re.compile(r'''["']url["']:["'](https?://.+?)["'],["']mimeType["']''', re.S).findall(item)
						AUDIO_2 = matchMP3[0] if matchMP3 else None
						matchSUB = re.compile(r'''["']title["']:["'](.*?)["'],["']summary["']''', re.S).findall(item)
						SUBTITLE_2 = cleaning(matchSUB[0]) if matchSUB else None
						matchDUR = re.compile(r'''["']duration["']:["']([^"']+)["'],["']alwaysShowHours["']''', re.S).findall(item)
						DURATION_2 = get_RunTime(matchDUR[0]) if matchDUR else None
						COMBI_THIRD.append([int(number), WLINK_2, SUBTITLE_2, DESC_2, THUMB_2, DURATION_2, AUDIO_2])
				else:
					debug_MS(f"(navigator.listSubstances[2.2]) xxxxx PODCAST-02 : {podcast} xxxxx")
					matchIMG = re.compile(r'''<div class=["']card-image["']><img.*?src=["']([^"']+)["'] data-size''', re.S).findall(podcast)
					THUMB_2 = f"{BASE_URL}/files/{matchIMG[0].split('source=')[1].split('&amp;')[0]}" if matchIMG and 'source=' in matchIMG[0] else f"[{artpic}podcast.jpg"
					matchPLOT = re.compile(r'''</header><div class=["']row["']>.*?<p[^>]*>(.*?)</p>''', re.S).findall(podcast)
					DESC_2 = cleaning(re.sub(r'\<.*?\>', '', matchPLOT[0])) if matchPLOT else ""
					matchMP3 = re.compile(r'''document.write\(httpGet\(["'](https://podcasts.+?)/podcast.html["']''', re.S).findall(podcast)
					AUDIO_2 = matchMP3[0] if matchMP3 else None
					matchSUB = re.compile(r'<p>(.*?)</p>', re.S).findall(podcast)
					SUBTITLE_2 = cleaning(re.sub(r'\<.*?\>', '', matchSUB[0])) if matchSUB and matchPLOT else None
					COMBI_THIRD.append([int(number), WLINK_2, SUBTITLE_2, DESC_2, THUMB_2, None, AUDIO_2])
	return COMBI_THIRD

def playMedia(FINAL_URL, TYPE):
	debug_MS("(navigator.playMedia) -------------------------------------------------- START = playMedia --------------------------------------------------")
	debug_MS(f"(navigator.playMedia) ### TARGET = {FINAL_URL} || EXTRAS = {TYPE} ###")
	action = TYPE.split('@@')[0] if '@@' in TYPE else TYPE
	log(f"(navigator.playMedia) StreamURL = {FINAL_URL} || ACTION = {action}")
	if xbmc.Player().isPlaying():
		xbmc.Player().stop()
	xbmc.PlayList(1).clear()
	if action in ['DIRECTstream', 'RADIOstream']:
		LSM = xbmcgui.ListItem(TYPE.split('@@')[1])
		LSM.setArt({'icon': icon, 'thumb': TYPE.split('@@')[2], 'poster': TYPE.split('@@')[2], 'fanart': defaultFanart})
		xbmc.Player().play(item=FINAL_URL, listitem=LSM)
		if action == 'RADIOstream':
			while xbmc.Player().isPlayingRDS():
				rds_tag = xbmc.Player().getRadioRDSInfoTag()
				title, artist, infos = rds_tag.getTitle(), rds_tag.getArtist(), rds_tag.getInfoNews()
				xbmc.Player().updateInfoTag(rds_tag)
				xbmc.sleep(300)
	else:
		LSM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)

def addDir(params, listitem, folder=True):
	uws = build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
