﻿# -*- coding: utf-8 -*-

from .common import *


def ACC_LOGIN(IDD, REF=None, headers=None, allow_redirects=True, verify=verify_ssl_connect, stream=None, data=None, json=None):
	debug_MS("(navigator.ACC_LOGIN) ------------------------------------------------ START = ACC_LOGIN -----------------------------------------------")
	if USER !="" and PASS !="":
		# URLs zur Anmeldung = "https://shop.vfb.de/account/ajax_login"
		# URLs zur Anmeldung = "https://shop.vfb.de/konto/anmeldung"
		# https://vfbtv.vfb.de/ajax.php?contelPageId=167&noCache=1&cmd=login&username=armishath88@gmail.com&password=1011=rilDUT!26
		payload = urlencode({'username': USER, 'password': PASS})
		with requests.Session() as rs:
			LOGIN_QUERY = rs.post(LOGIN_LINK.format(payload), headers=getHeader(REF), allow_redirects=allow_redirects, verify=verify, data=payload, timeout=30).text
			debug_MS(f"(navigator.ACC_LOGIN) ##### LOGIN_QUERY : {LOGIN_LINK.format(payload)} #####")
			debug_MS(f"(navigator.ACC_LOGIN) ##### LOGIN_ANSWER : {LOGIN_QUERY} #####")
			if '"success":true' in LOGIN_QUERY:
				RELAY_URL = rs.get(ACCESS_LINK.format(IDD), headers=getHeader(REF), allow_redirects=allow_redirects, verify=verify, timeout=30).text
				debug_MS(f"(navigator.ACC_LOGIN) ##### RELAY_URL-1 : {RELAY_URL} #####")
				if '"message":"Pay-Access granted"' in RELAY_URL or '"message":"Video has free access"' in RELAY_URL:
					return RELAY_URL
				else:
					failing(f"(navigator.ACC_LOGIN) LOGIN leider NICHT erfolgreich ##### RELAY_URL-2 : {RELAY_URL} #####")
					dialog.ok(addon_id, translation(30503))
			else:
				failing(f"(navigator.ACC_LOGIN) LOGIN leider NICHT erfolgreich ### EMAIL : {USER} ### PASSWORT : {PASS} ### bitte überprüfen Sie Ihre Login-Daten !!!")
				dialog.ok(addon_id, translation(30503))
	else:
		failing("(navigator.ACC_LOGIN) Für dieses Video ist ein 'Bezahl-ABO' erforderlich - Bitte ein 'Bezahl-ABO' unter 'https://shop.vfb.de/registrierung/' einrichten !!!")
		dialog.ok(addon_id, translation(30504))
	return False

def mainMenu():
	debug_MS("(navigator.mainMenu) ------------------------------------------------ START = mainMenu -----------------------------------------------")
	content = getUrl(BASE_LONG)
	selection = re.findall('<a id="([^"]+?)" class="access-key-anchor" data-access-key="[0-9]+" data-access-title="([^"]+?)"', content, re.S)
	for idd, title in selection:
		title = cleaning(title)
		addDir(title, icon, {'mode': 'listOverview', 'category': title})
		debug_MS(f"(navigator.mainMenu[1]) ### TITLE : {title} || IDD : {idd} ###")
	if enableADJUSTMENT:
		addDir(translation(30601), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30602), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listOverview(CAT):
	debug_MS("(navigator.listOverview) -------------------------------------------------- START = listOverview --------------------------------------------------")
	debug_MS(f"(navigator.listOverview) ### CATEGORY = {CAT} ###")
	content = getUrl(BASE_LONG)
	result = content[content.find(f'data-access-title="{CAT}"'):]
	result = result[:result.find('</ul>')]
	match = re.compile('<a href="([^"]+?)" target="_self">([^<]+?)</a>', re.S).findall(result)
	for link, title in match:
		NEW_URL = getComplete(link)
		title = cleaning(title)
		if 'bundesliga' in NEW_URL:
			addDir(title, icon, {'mode': 'listSaisons', 'url': NEW_URL, 'category': 'Bundesliga'})
		elif 'dfb-pokal' in NEW_URL:
			addDir(title, icon, {'mode': 'listSaisons', 'url': NEW_URL, 'category': 'DFB-Pokal'})
		else:
			addDir(title, icon, {'mode': 'listVideos', 'url': NEW_URL, 'category': title})
		debug_MS(f"(navigator.listOverview[1]) ### TITLE : {title} || LINK : {NEW_URL} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSaisons(url, CAT):
	debug_MS("(navigator.listSaisons) -------------------------------------------------- START = listSaisons --------------------------------------------------")
	debug_MS(f"(navigator.listSaisons) ### URL = {url} ### CATEGORY = {CAT} ###")
	START_URL = url
	if CAT == 'Bundesliga':
		content = getUrl(url)
		result = content[content.find('class="meldung-navi dropdown barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"')+1:]
		result = result[:result.find('</ul>')]
		match = re.compile('target="_self" href="([^"]+?)">(.+?)</a>', re.S).findall(result)
		for link, title in match:
			NEW_URL = getComplete(link)
			title = cleaning(title)
			if ('/2--bundesliga/' in START_URL and '/2--bundesliga/' in NEW_URL) or ('/bundesliga/' in START_URL and '/bundesliga/' in NEW_URL):
				addDir(title, icon, {'mode': 'listGamedays', 'url': NEW_URL, 'category': title})
			debug_MS(f"(navigator.listSaisons[1]) ### TITLE : {title} || LINK : {NEW_URL} ###")
	elif CAT == 'DFB-Pokal':
		point = 0 if int(str(datetime.now().month)) > 7 else 1
		for ii in range(date.today().year-point, 2015, -1):
			NEW_URL = f'{BASE_URL}/saison/saisons/saison-{str(ii)}-{str(int(ii)+1)}/dfb-pokal/'
			title = f'Saison {str(ii)}/{str(int(ii)+1)}'
			addDir(title, icon, {'mode': 'listGamedays', 'url': NEW_URL, 'category': title})
			debug_MS(f"(navigator.listSaisons[2]) ### TITLE : {title} || LINK : {NEW_URL} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGamedays(url, CAT):
	debug_MS("(navigator.listGamedays) -------------------------------------------------- START = listGamedays --------------------------------------------------")
	debug_MS(f"(navigator.listGamedays) ### URL = {url} ### CATEGORY = {CAT} ###")
	START = ['<div class="spieltage swiper-container">', 'class="meldung-navi grey barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"', 'class="meldung-navi barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"']
	content = getUrl(url)
	if any(x in content for x in START):
		if START[0] in content:
			result = content[content.find(START[0])+1:]
			part = result.split('class="image swiper-slide"')
			for i in range(1, len(part), 1):
				entry = part[i]
				link = re.compile('href="([^"]+?)"', re.S).findall(entry)[0]
				NEW_URL = getComplete(link)
				photo = re.compile(r'<img src="([^"]+?)" alt=', re.S).findall(entry)[0].replace('x_143x80', 'x_960x540')
				photo = BASE_URL[:-3]+photo if photo.startswith('/tv/') else photo
				title = re.compile('class="spieltag">(.+?)</div>', re.S).findall(entry)[0]
				title = cleaning(title)
				addDir(title, photo, {'mode': 'listVideos', 'url': NEW_URL, 'category': title})
				debug_MS(f"(navigator.listGamedays[1]) ### TITLE : {title} || LINK : {NEW_URL} ###")
				debug_MS(f"(navigator.listGamedays[1]) ### THUMB : {photo} ###")
		elif START[1] in content or START[2] in content:
			if START[1] in content:
				result = content[content.find(START[1])+1:]
			else:
				result = content[content.find(START[2])+1:]
			result = result[:result.find('<div class="clear">')]
			spl = result.split('target="_self"')
			for i in range(1, len(spl), 1):
				elem = spl[i]
				link = re.compile('href="([^"]+?)"', re.S).findall(elem)[0]
				NEW_URL = getComplete(link)
				title = re.compile('<span>(.+?)</span>', re.S).findall(elem)[0]
				title = cleaning(title)
				addDir(title, icon, {'mode': 'listVideos', 'url': NEW_URL, 'category': title})
				debug_MS(f"(navigator.listGamedays[2]) ### TITLE : {title} || LINK : {NEW_URL} ###")
	else:
		debug_MS(f"(navigator.listGamedays) Leider gibt es in der Rubrik : {CAT} - KEINE Einträge !")
		return dialog.notification(translation(30524).format('Einträge'), translation(30525).format(CAT.upper()), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(url, CAT):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS(f"(navigator.listVideos) ### URL = {url} ### CATEGORY = {CAT} ###")
	FOUND = 0
	content = getUrl(url)
	selection = re.findall('<article class="barrierfree-jumplink-anchor"(.+?)</article>', content, re.S)
	for chtml in selection:
		if ('class="zusatz">gratis</div>' in str(chtml) and ONLY_FREE is True) or ONLY_FREE is False:
			Note_1, Note_2 = ("" for _ in range(2))
			FOUND += 1
			link = re.compile('href="([^"]+?)"', re.S).findall(chtml)[0]
			NEW_URL = getComplete(link)
			photo = re.compile(r'<img src="([^"]+?)" alt=', re.S).findall(chtml)[0].replace('f_274x154', 'f')
			photo = BASE_URL[:-3]+photo if photo.startswith('/tv/') else photo
			matchDAT = re.compile('class="date">([^<]+?)</div>', re.S).findall(chtml)
			DATES = matchDAT[0] if matchDAT else None
			title = re.compile('class="title">(.+?)</div>', re.S).findall(chtml)[0]
			title = cleaning(title)
			Note_1 = translation(30621).format(DATES) if DATES else ""
			matchDES = re.compile('class="text">(.+?)</div>', re.S).findall(chtml)
			Note_2 = cleaning(re.sub(r'\<.*?\>', '', matchDES[0])) if matchDES else ""
			plot = Note_1+Note_2
			access = "Free-Video" if 'class="zusatz">gratis</div>' in str(chtml) else "Pay-Video"
			addLink(title, photo, {'mode': 'playVideo', 'url': NEW_URL, 'extras': access}, plot)
			debug_MS(f"(navigator.listVideos[1]) ### TITLE : {title} || LINK : {NEW_URL} ###")
			debug_MS(f"(navigator.listVideos[1]) ### THUMB : {photo} ###")
	if FOUND == 0 and ONLY_FREE is False:
		debug_MS(f"(navigator.listVideos) Leider gibt es in der Rubrik : {CAT} - überhaupt KEINE verfügbaren Videos !")
		return dialog.notification(translation(30524).format('Einträge'), translation(30525).format(CAT.upper()), icon, 8000)
	elif FOUND == 0 and ONLY_FREE is True:
		debug_MS(f"(navigator.listVideos) Leider gibt es in der Rubrik : {CAT} - KEINE 'Gratis Videos' !")
		return dialog.notification(translation(30524).format("'Gratis Videos'"), translation(30525).format(CAT.upper()), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url, GATEWAY):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### URL = {url} ### GATEWAY = {GATEWAY} ###")
	MEDIAS = []
	DATA, STREAM, FINAL_URL = (False for _ in range(3))
	CON_ONE = getUrl(url)
	FIRST_RES = re.compile('data-video="([^"]+?)"', re.S).findall(CON_ONE)[0]
	debug_MS(f"(navigator.playVideo[1]) VIDEO-IDD : {FIRST_RES}")
	if GATEWAY == 'Free-Video': # https://vfbtv.vfb.de/video/streamAccess.php?videoId=35977&target=2&partner=2119&format=iphone
		SECOND = ACCESS_LINK.format(FIRST_RES)
		CON_TWO = getUrl(SECOND)
		debug_MS(f"(navigator.playVideo[2]) CONTENT-Free-Video : {CON_TWO}")
		DATA = json.loads(CON_TWO)
	elif GATEWAY == 'Pay-Video':
		KONTO = ACC_LOGIN(FIRST_RES)
		if KONTO:
			debug_MS(f"(navigator.playVideo[2]) CONTENT-Pay-Video : {KONTO}")
			DATA = json.loads(KONTO)
		else: return
	if DATA and DATA.get('data', '') and DATA.get('data', {}).get('stream-access', '') and not 'error' in DATA.get('status', ''):
		# https://streamaccess.unas.tv/hdflash2/vod/119/production/35977.xml?streamid=35977&partnerid=2119&label=&area=&ident=5550869020230629033053&timestamp=20230629013053&format=iphone&start=&end=&auth=4e6de073d65019cf9abe4e1c4debd6ec
		for video in DATA['data']['stream-access']:
			MEDIAS.append(video)
		if MEDIAS:
			if len(MEDIAS) > 1:
				link = MEDIAS[1].replace('×tamp', '&timestamp')
				log(f"(navigator.playVideo[3]) Wir haben 2 *StreamZugänge* - wähle den Zweiten : {link}")
			else:
				link = MEDIAS[0].replace('×tamp', '&timestamp')
				log(f"(navigator.playVideo[3]) Wir haben 1 *StreamZugang* - wähle Diesen : {link}")
			THIRD = 'https:'+link if link.startswith('//') else link
			CON_THREE = getUrl(THIRD)
			# https://hdvodvfbtv-vh.akamaihd.net/i/hdflash/20202021/news/210624_vfb_rote_tisch_hd_neu_,low,high,hd,.mp4.csmil/master.m3u8?hdnea=exp=1625493098~acl=*~hmac=74d0dd576d46e9a6d56f632a9d16bded8dd92d321714c601ae64ccdcc316bf5c&p=2119&u=&t=hdvideo&l=&a=&c=DE&e=31484&i=1848092120210705154638&k=&q=&custom-mdt=on&b=0-10000
			url_FOUND = re.compile('url="([^"]+?)"', re.S).findall(CON_THREE)[0].replace('&amp;', '&')
			auth_FOUND = re.compile('auth="([^"]+?)"', re.S).findall(CON_THREE)[0].replace('&amp;', '&')
			STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
			FINAL_URL = f'{url_FOUND}?hdnea={auth_FOUND}' #+"&custom-mdt=on&b=0-10000"
	if FINAL_URL and STREAM:
		log(f"(navigator.playVideo) StreamURL : {FINAL_URL}")
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		if ADDON_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD'] and 'master.m3u8' in FINAL_URL:
			LSM.setMimeType('application/vnd.apple.mpegurl')
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			LSM.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
	else:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich #####\n   ##### URL : {url} #####")
		return dialog.notification(translation(30521).format('PLAY'), translation(30526), icon, 8000)

def addDir(name, image, params={}, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setGenres(['Fussball']), vinfo.setStudios(['VfB-Stuttgart TV'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': 'Fussball', 'Studio': 'VfB-Stuttgart TV'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name)
		vinfo.setPlot(plot)
		if str(duration).isdigit(): vinfo.setDuration(int(duration))
		vinfo.setGenres(['Fussball'])
		vinfo.setStudios(['VfB-Stuttgart TV'])
		vinfo.setMediaType('movie')
	else:
		vinfo = {}
		vinfo['Title'] = name
		vinfo['Plot'] = plot
		if str(duration).isdigit(): vinfo['Duration'] = duration
		vinfo['Genre'] = 'Fussball'
		vinfo['Studio'] = 'VfB-Stuttgart TV'
		vinfo['Mediatype'] = 'movie'
		liz.setInfo(type='Video', infoLabels=vinfo)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'Action(Queue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
