﻿# -*- coding: utf-8 -*-

from .common import *
from .external.scrapetube import *


def create_account(success=False):
	debug_MS("(navigator.create_account) ############### START ACCOUNT - REGISTRATION ###############")
	email_adress = dialog.input(translation(30541), type=xbmcgui.INPUT_ALPHANUM)
	hidden_sign = dialog.input(translation(30542), type=xbmcgui.INPUT_ALPHANUM)
	if email_adress is not None and len(email_adress) > 0 and hidden_sign is not None and len(hidden_sign) >= 6:
		success, payload = True, urlencode({'username': email_adress, 'password': hidden_sign})
		ACC_LOGIN = requests.request('POST', LOGIN_LINK.format(payload), headers=head_VBTV, allow_redirects=True, verify=verify_connection, data=payload, timeout=20)
		debug_MS(f"(navigator.create_account[1]) === ACCOUNT_LOGIN === STATUS : {ACC_LOGIN.status_code} || CONTENT : {ACC_LOGIN.text} ===")
		if '"success":true' in ACC_LOGIN.text:
			debug_MS("(navigator.create_account[2]) ##### ALLE DATEN GEFUNDEN - DIE REGISTRIERUNG WAR ERFOLGREICH #####")
			addon.setSetting('emailing', email_adress)
			addon.setSetting('password', hidden_sign)
			addon.setSetting('username', f'[B]{email_adress}[/B]')
			xbmc.sleep(1000)
			return dialog.notification(translation(30543).format('Login'), translation(30544).format(email_adress), icon, 10000)
		else:
			return dialog.ok(addon_id, translation(30503))
	if success is False: return dialog.notification(translation(30545), translation(30546), icon , 10000)

def erase_account():
	debug_MS("(navigator.erase_account) XXXXX VfB-Stuttgart-KONTO ZWANGSWEISE AUS KODI ENTFERNEN - LÖSCHE ACCOUNT-DATEN - ERFOLGREICH XXXXX")
	addon.setSetting('emailing', '')
	addon.setSetting('password', '')
	addon.setSetting('username', '')
	xbmc.sleep(1000)
	return dialog.notification(translation(30543).format('Logout'), translation(30547), icon, 10000)

def mainMenu():
	debug_MS("(navigator.mainMenu) ------------------------------------------------ START = mainMenu -----------------------------------------------")
	content = getContent(BASE_LONG, headers=head_VBTV) # <a class="c-navigation__menu-point-wrapper" id="access-inside" class="access-key-anchor" data-access-key="6"   data-access-title="Inside"
	selection = re.findall(r'''<a class=["']c-navigation__menu-point-wrapper["'] id=["']([^"']+)["'] class=["']access-key-anchor["'] data-access-key=["'][0-9]+["']\s*data-access-title=["']([^"']+)["']''', content, re.S)
	for code, title in selection:
		title = cleaning(title)
		addDir({'mode': 'listOverview', 'category': title}, create_entries({'Title': translation(30601).format(title)}))
		debug_MS(f"(navigator.mainMenu[1]) ### TITLE : {title} || CODE : {code} ###")
	if enableYOUTUBE:
		addDir({'mode': 'listPlaylists'}, create_entries({'Title': translation(30602)}))
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30603), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listOverview(CAT):
	debug_MS("(navigator.listOverview) -------------------------------------------------- START = listOverview --------------------------------------------------")
	debug_MS(f"(navigator.listOverview) ### CATEGORY = {CAT} ###")
	content = getContent(BASE_LONG, headers=head_VBTV)
	result = content[content.find(f'data-access-title="{CAT}"'):]
	result = result[:result.find('</ul>')]
	match = re.compile(r'''<a href=["']([^"']+)["'] target=["']_self["']>([^<]+)</a>''', re.S).findall(result)
	for link, title in match:
		NEW_URL = getComplete(link)
		title = cleaning(title)
		if 'bundesliga' in NEW_URL and not '/frauen' in NEW_URL:
			addDir({'mode': 'listSaisons', 'link': NEW_URL, 'category': 'Bundesliga'}, create_entries({'Title': title}))
		elif 'dfb-pokal' in NEW_URL:
			addDir({'mode': 'listSaisons', 'link': NEW_URL, 'category': 'DFB-Pokal'}, create_entries({'Title': title}))
		elif 'champions-league' in NEW_URL:
			addDir({'mode': 'listGamedays', 'link': NEW_URL, 'category': 'Champions-League'}, create_entries({'Title': title}))
		elif 'supercup' in NEW_URL:
			addDir({'mode': 'listSaisons', 'link': NEW_URL, 'category': 'Supercup'}, create_entries({'Title': title}))
		else:
			addDir({'mode': 'listVideos', 'link': NEW_URL, 'category': title}, create_entries({'Title': title}))
		debug_MS(f"(navigator.listOverview[1]) ### TITLE : {title} || LINK : {NEW_URL} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSaisons(TARGET, CAT):
	debug_MS("(navigator.listSaisons) -------------------------------------------------- START = listSaisons --------------------------------------------------")
	debug_MS(f"(navigator.listSaisons) ### TARGET = {TARGET} ### CATEGORY = {CAT} ###")
	if CAT == 'Bundesliga':
		content = getContent(TARGET, headers=head_VBTV)
		result = content[content.find('class="meldung-navi dropdown barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"')+1:]
		result = result[:result.find('</ul>')]
		match = re.compile(r'''target=["']_self["'] href=["']([^"']+)["']>([^<]+)</a>''', re.S).findall(result)
		for link, title in sorted(match, key=lambda vx: vx[1], reverse=True):
			NEW_URL = getComplete(link)
			title = cleaning(title)
			if ('/2--bundesliga/' in TARGET and '/2--bundesliga/' in NEW_URL) or ('/bundesliga/' in TARGET and '/bundesliga/' in NEW_URL):
				addDir({'mode': 'listGamedays', 'link': NEW_URL, 'category': f'Bundesliga - {title}'}, create_entries({'Title': title}))
			debug_MS(f"(navigator.listSaisons[1]) ### TITLE : {title} || LINK : {NEW_URL} ###")
	elif CAT in ['DFB-Pokal', 'Supercup']:
		available = datetime(*(time.strptime(f"10.08.{str(datetime.now().strftime('%Y'))}", '%d.%m.%Y')[0:6]))
		point = 0 if datetime.now() > available else 1
		if CAT == 'DFB-Pokal':
			for ii in range(date.today().year-point, 2015, -1):
				NEW_URL = f'{BASE_URL}/saison/saisons/saison-{str(ii)}-{str(int(ii)+1)}/dfb-pokal/'
				title = f'Saison {str(ii)}/{str(int(ii)+1)}'
				addDir({'mode': 'listGamedays', 'link': NEW_URL, 'category': f'DFB-Pokal - {title}'}, create_entries({'Title': title}))
				debug_MS(f"(navigator.listSaisons[2]) ### TITLE : {title} || LINK : {NEW_URL} ###")
		elif CAT == 'Supercup':
			for ii in range(date.today().year-point, 2023, -1):
				NEW_URL = f'{BASE_URL}/saison/saisons/saison-{str(ii)}-{str(int(ii)+1)}/supercup/'
				title = f'Saison {str(ii)}/{str(int(ii)+1)}'
				addDir({'mode': 'listVideos', 'link': NEW_URL, 'category': f'Supercup - {title}'}, create_entries({'Title': title}))
				debug_MS(f"(navigator.listSaisons[3]) ### TITLE : {title} || LINK : {NEW_URL} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGamedays(TARGET, CAT):
	debug_MS("(navigator.listGamedays) -------------------------------------------------- START = listGamedays --------------------------------------------------")
	debug_MS(f"(navigator.listGamedays) ### TARGET = {TARGET} ### CATEGORY = {CAT} ###")
	START = ['<div class="spieltage swiper-container">', 'class="meldung-navi grey barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"', 'class="meldung-navi barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"']
	content = getContent(TARGET, headers=head_VBTV)
	if any(xs in content for xs in START):
		if START[0] in content:
			result = content[content.find(START[0])+1:]
			result = result[:result.find('<div class="clear">')]
			part = result.split('class="image swiper-slide"')
			for i in range(1, len(part), 1):
				entry = part[i]
				NEW_URL = getComplete(re.compile(r'''href=["']([^"']+)["']''', re.S).findall(entry)[0])
				title = cleaning(re.compile(r'''class=["']spieltag["']>(.*?)</div>''', re.S).findall(entry)[0])
				photo = re.compile(r'''<img src=["']([^"']+)["'] alt=''', re.S).findall(entry)[0].replace('x_143x80', 'x_960x540')
				photo = f"{BASE_URL[:-3]}{photo}" if photo.startswith('/tv/') else photo
				addDir({'mode': 'listVideos', 'link': NEW_URL, 'category': f'{CAT} - {title}'}, create_entries({'Title': title, 'Image': photo}))
				debug_MS(f"(navigator.listGamedays[1]) ### TITLE : {title} || LINK : {NEW_URL} || THUMB : {photo} ###")
		elif START[1] in content or START[2] in content:
			result = content[content.find(START[1])+1:] if START[1] in content else content[content.find(START[2])+1:]
			result = result[:result.find('<div class="clear">')]
			spl = result.split('target="_self"')
			for i in range(1, len(spl), 1):
				elem = spl[i]
				NEW_URL = getComplete(re.compile(r'''href=["']([^"']+)["']''', re.S).findall(elem)[0])
				title = cleaning(re.compile(r'''<span>(.*?)</span>''', re.S).findall(elem)[0])
				addDir({'mode': 'listVideos', 'link': NEW_URL, 'category': f'{CAT} - {title}'}, create_entries({'Title': title}))
				debug_MS(f"(navigator.listGamedays[2]) ### TITLE : {title} || LINK : {NEW_URL} ###")
	else:
		debug_MS(f'(navigator.listGamedays) In der Rubrik : "{CAT}" ~ gibt es KEINE Einträge !')
		return dialog.notification(translation(30524), translation(30527).format(CAT), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(TARGET, CAT):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS(f"(navigator.listVideos) ### TARGET = {TARGET} ### CATEGORY = {CAT} ###")
	FOUND, content = 0, getContent(TARGET, headers=head_VBTV)
	selection = re.findall('<article class="barrierfree-jumplink-anchor"(.*?)</article>', content, re.S)
	for chtml in selection:
		access, Note_1 = 'PURCHASE' if 'class="zusatz">exklusiv</div>' in chtml else 'FREEMENT', ""
		if access == 'PURCHASE' and ONLY_FREE is True: continue
		elif access == 'PURCHASE' and ONLY_FREE is False: Note_1 = translation(30621)
		FOUND += 1
		NEW_URL = getComplete(re.compile(r'''href=["']([^"']+)["']''', re.S).findall(chtml)[0])
		title = cleaning(re.compile(r'''class=["']title["']>(.*?)</div>''', re.S).findall(chtml)[0])
		photo = re.compile(r'''<img src=["']([^"']+)["'] alt=''', re.S).findall(chtml)[0].replace('f_274x154', 'f')
		photo = f"{BASE_URL[:-3]}{photo}" if photo.startswith('/tv/') else photo
		matchDAT = re.compile(r'''class=["']date["']>([^<]+)</div>''', re.S).findall(chtml)
		if matchDAT:
			DAYS, MONTH, YEAR, Note_2 = matchDAT[0].split(' ')[0], matchDAT[0].split(' ')[1], matchDAT[0].split(' ')[2], translation(30622).format(matchDAT[0])
			for tt in (('Januar', '01'), ('Februar', '02'), ('März', '03'), ('April', '04'), ('Mai', '05'), ('Juni', '06'), ('Juli', '07'), \
				('August', '08'), ('September', '09'), ('Oktober', '10'), ('November', '11'), ('Dezember', '12')):
				MONTH = MONTH.replace(*tt)
			DATE = datetime(*(time.strptime(f"{DAYS.split('.')[0].zfill(2)}.{MONTH}.{YEAR}", '%d.%m.%Y')[0:6])).strftime('%d.%m.%Y')
		else: DATE, Note_2 = None, ""
		matchDESC = re.compile(r'''class=["']text["']>(.*?)</div>''', re.S).findall(chtml)
		Note_3 = cleaning(re.sub(r'\<.*?\>', '', matchDESC[0])) if matchDESC else ""
		FETCH_UNO = {'Title': title, 'Plot': Note_1+Note_2+Note_3, 'Aired': DATE, 'Genre': 'Fußball', 'Mediatype': 'episode', 'Image': photo, 'Reference': 'Single'}
		addDir({'mode': 'playVideo', 'link': NEW_URL, 'extras': access}, create_entries(FETCH_UNO), False)
		debug_MS(f"(navigator.listVideos[1]) ### TITLE : {title} || AIRED : {DATE} || LINK : {NEW_URL} || THUMB : {photo} ###")
	if FOUND == 0 and ONLY_FREE is False:
		debug_MS(f'(navigator.listVideos) In der Rubrik : "{CAT}" ~ gibt es überhaupt KEINE verfügbaren Videos !')
		return dialog.notification(translation(30525), translation(30527).format(CAT), icon, 12000)
	elif FOUND == 0 and ONLY_FREE is True:
		debug_MS(f'(navigator.listVideos) In der Rubrik : "{CAT}" ~ gibt es KEINE verfügbaren "Gratis Videos" !')
		return dialog.notification(translation(30526), translation(30527).format(CAT), icon, 12000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPlaylists(EXTRA):
	debug_MS("(navigator.listPlaylists) ------------------------------------------------ START = listPlaylists -----------------------------------------------")
	if PERS_TOKEN == 'AIzaSy.................................':
		return dialog.ok(addon_id, translation(30351))
	if EXTRA == 'DEFAULT':
		addDir({'mode': 'listPlaylists', 'extras': 'YOUT_STREAMS'}, create_entries({'Title': translation(30631), 'Plot': 'Live-Events und Aktuelles: VfB Stuttgart (VfB-TV)'}))
		addDir({'link': BASE_YOUT.format(CHANNEL_CODE, 'UUNjHTx_URHNiZvjW-uzIf4Q'), 'extras': 'YT_FOLDER'}, create_entries({'Title': translation(30632), 'Plot': 'Neue Uploads: VfB Stuttgart (VfB-TV)'}))
		TARGET = f"https://youtube.googleapis.com/youtube/v3/playlists?part=snippet,contentDetails&channelId={CHANNEL_CODE}&maxResults=50&key={PERS_TOKEN}"
		PAGE_NUMBER, NEXT_PAGE = 1, None
		while PAGE_NUMBER > 0:
			content = getContent(TARGET, 'GET', 'JSON', head_YOUT) if PAGE_NUMBER == 1 else getContent(NEXT_PAGE, 'GET', 'JSON', head_YOUT)
			for item in content.get('items', []):
				if item.get('kind', '') == 'youtube#playlist':
					debug_MS(f"(navigator.listPlaylists[1]) xxxxx ENTRY-01 : {item} xxxxx")
					debug_MS("---------------------------------------------")
					title, PYID = cleaning(item['snippet']['title']), item.get('id', None)
					plot = (cleaning(item['snippet'].get('description', '')) or 'Offizieller YouTube Kanal des VfB Stuttgart (VfB-TV)')
					photo = (item['snippet']['thumbnails'].get('maxres', {}).get('url', '') or item['snippet']['thumbnails'].get('standard', {}).get('url', ''))
					numbers = item['contentDetails']['itemCount'] if item.get('contentDetails', '') and str(item['contentDetails'].get('itemCount')).isdecimal() else None
					name = translation(30633).format(title) if numbers is None else translation(30634).format(title, numbers)
					FETCH_UNO = {'Title': name, 'Plot': f'Playlist: {plot}', 'Image': photo}
					addDir({'link': BASE_YOUT.format(CHANNEL_CODE, PYID), 'extras': 'YT_FOLDER'}, create_entries(FETCH_UNO))
			if content.get('nextPageToken', None):
				NEXT_PAGE, PAGE_NUMBER = f"{TARGET}&pageToken={content['nextPageToken']}", PAGE_NUMBER.__add__(1)
				debug_MS(f"(navigator.listPlaylists[2]) PAGES ### NOW GET NEXTPAGE : {NEXT_PAGE} ###")
			else: break
	else:
		content = get_channel(channel_username=CHANNEL_NAME.split('@')[1], limit=40, sleep=1, content_type='streams') # mit 'get_channel' hier die Streams eines Channels abrufen
		for item in content:
			debug_MS(f"(navigator.listPlaylists[2]) XXXXX ENTRY-02 : {item} XXXXX")
			debug_MS("---------------------------------------------")
			title, plot, running, announced = cleaning(item['title']['runs'][0]['text'], True), "", None, False
			PYID = item.get('videoId', None)
			try: running = item['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['accessibility']['accessibilityData']['label']
			except: pass
			if running and running[:4] == 'LIVE':
				announced, plot = True, plot+translation(30635)
			elif item.get('upcomingEventData', '') and str(item['upcomingEventData'].get('startTime')).isdecimal():
				CIPHER = datetime(1970,1,1) + timedelta(seconds=TGM(time.localtime(int(item['upcomingEventData']['startTime']))))
				startCOMPLETE = CIPHER.strftime('%a{0} %d{0}%m{0}%Y {1} %H{2}%M').format( '.', '•', ':')
				for tt in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), ('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))):
					startCOMPLETE = startCOMPLETE.replace(*tt)
				announced, plot = True, plot+translation(30636).format(startCOMPLETE)
			elif item.get('publishedTimeText', '') and item['publishedTimeText'].get('simpleText', ''):
				plot += translation(30637).format(str(item['publishedTimeText']['simpleText']).replace(' gestreamt', '').replace('Streamed ', '').replace('vor ', 'Vor '))
			plot += cleaning(item['descriptionSnippet']['runs'][0]['text'], True)
			duration = get_RunTime(item['lengthText']['simpleText']) if item.get('lengthText', '') and item['lengthText'].get('simpleText', '') else None
			name = translation(30638).format(title[4:]) if announced is True and title[:4] == 'LIVE' else title[4:] if title[:4] == 'LIVE' else title
			photo = f"https://i.ytimg.com/vi/{PYID}/sddefault.jpg"
			FETCH_DUE = {'Title': name, 'Plot': plot, 'Duration': duration, 'Mediatype': 'episode', 'Image': photo, 'Reference': 'Single'}
			addDir({'mode': 'playVideo', 'link': PYID, 'extras': 'YOUTUBE'}, create_entries(FETCH_DUE), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def playVideo(TARGET, GATEWAY):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS(f"(navigator.playVideo) ### TARGET = {TARGET} ### PAY_TYPE = {GATEWAY} ###")
	MEDIAS, (FINAL_URL, TEST_URL, DATA_DUE, STREAM) = [], (False for _ in range(4))
	if GATEWAY == 'YOUTUBE':
		debug_MS(f"(navigator.playVideo[1]) ***** TESTING - REDIRECTED : https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={TARGET} || (Youtube-Redirect-Test) *****")
		FINAL_URL = f"plugin://plugin.video.youtube/play/?video_id={TARGET}"
		VERIFY = getContent(f"https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={TARGET}", 'GET', 'TRACK', head_YOUT, timeout=15)
		if VERIFY and VERIFY.status_code in [200, 201, 202] and re.search(r'''["']provider_url["']:["']https://www.youtube.com/["']''', VERIFY.text): TEST_URL = True
	else:
		DATA_UNO = getContent(TARGET, headers=head_VBTV)
		VIDEO_CID = re.compile(r'''data-video=["']([^"']+)["']''', re.S).findall(DATA_UNO)[0]
		debug_MS(f"(navigator.playVideo[1]) ##### VIDEO_CID : {VIDEO_CID} #####")
		if GATEWAY == 'FREEMENT': # https://vfbtv.vfb.de/video/streamAccess.php?videoId=35977&target=2&partner=2119&format=iphone
			DATA_DUE = getContent(VIDEO_ACCESS.format(VIDEO_CID), 'POST', 'JSON', head_VBTV)
			debug_MS(f"(navigator.playVideo[2]) XXXXX CONTENT-Free-Video : {DATA_DUE} XXXXX")
		elif GATEWAY == 'PURCHASE' and addon.getSetting('emailing') !="" and addon.getSetting('password') !="":
			# URLs zur Anmeldung = "https://shop.vfb.de/account/ajax_login" oder "https://shop.vfb.de/konto/anmeldung"
			# https://vfbtv.vfb.de/ajax.php?contelPageId=167&noCache=1&cmd=login&username=armishath88@gmail.com&password=1011=rilDUT!26
			payload = urlencode({'username': addon.getSetting('emailing'), 'password': addon.getSetting('password')})
			with requests.Session() as mrs:
				CHECK_LOGIN = mrs.request('POST', LOGIN_LINK.format(payload), headers=head_VBTV, allow_redirects=True, verify=verify_connection, data=payload, timeout=30)
				if '"success":true' in CHECK_LOGIN.text:
					RELAY_URL = mrs.request('POST', VIDEO_ACCESS.format(VIDEO_CID), headers=head_VBTV, allow_redirects=True, verify=verify_connection, timeout=30)
					if '"message":"Pay-Access granted"' in RELAY_URL.text or '"message":"Video has free access"' in RELAY_URL.text:
						DATA_DUE = RELAY_URL.json()
						debug_MS(f"(navigator.playVideo[2]) XXXXX CONTENT-Payed-Video : {DATA_DUE} XXXXX")
					else:
						failing(f"(navigator.playVideo[2]) ERROR - ACCESS - ERROR ##### STATUS : {RELAY_URL.status_code} #####\n ##### DETAILS : {RELAY_URL.text} #####")
						xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem(offscreen=True))
						xbmc.PlayList(1).clear()
						return dialog.ok(addon_id, translation(30504))
				else:
					failing(f"(navigator.playVideo[2]) ERROR - LOGIN - ERROR ##### DETAILS : {CHECK_LOGIN.text} #####\n ##### EMAIL : {addon.getSetting('emailing')} || PASSWORT : {addon.getSetting('password')} >>> bitte überprüfen Sie Ihre Login-Daten !!! #####")
					xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem(offscreen=True))
					xbmc.PlayList(1).clear()
					return dialog.ok(addon_id, translation(30503))
		else:
			failing("(navigator.playVideo[2]) Für dieses Video ist ein 'Kostenpflichtiges-ABO' erforderlich - Bitte ein 'Kostenpflichtiges-ABO' unter 'https://shop.vfb.de/registrierung/' einrichten !!!")
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem(offscreen=True))
			xbmc.PlayList(1).clear()
			return dialog.ok(addon_id, translation(30504))
		if DATA_DUE and DATA_DUE.get('data', '') and DATA_DUE['data'].get('stream-access', '') and not 'error' in DATA_DUE.get('status', ''):
			# https://streamaccess.unas.tv/hdflash2/vod/119/production/35977.xml?streamid=35977&partnerid=2119&label=&area=&ident=5550869020230629033053&timestamp=20230629013053&format=iphone&start=&end=&auth=4e6de073d65019cf9abe4e1c4debd6ec
			MEDIAS = [xev for xev in DATA_DUE['data'].get('stream-access', [])]
			if len(MEDIAS) > 0:
				LINK = MEDIAS[-1].replace('\/', '/').replace('×tamp', '&timestamp')
				debug_MS(f"(navigator.playVideo[3]) Vorhandene Streams ► {len(MEDIAS)} ◄ wähle den letzten verfügbaren Stream : {LINK}")
				DATA_TRE = getContent(f"https:{LINK}" if LINK.startswith('//') else LINK, headers=head_VBTV)
				# https://hdvodvfbtv-vh.akamaihd.net/i/hdflash/20202021/news/210624_vfb_rote_tisch_hd_neu_,low,high,hd,.mp4.csmil/master.m3u8?hdnea=exp=1625493098~acl=*~hmac=74d0dd576d46e9a6d56f632a9d16bded8dd92d321714c601ae64ccdcc316bf5c&p=2119&u=&t=hdvideo&l=&a=&c=DE&e=31484&i=1848092120210705154638&k=&q=&custom-mdt=on&b=0-10000
				HDFLASH = re.compile(r'''url=["']([^"']+)["']''', re.S).findall(DATA_TRE)[0].replace('&amp;', '&')
				HDAUTH = re.compile(r'''auth=["']([^"']+)["']''', re.S).findall(DATA_TRE)[0].replace('&amp;', '&')
				HDAUTH = f"{HDAUTH.split('&k=&q=')[0]}&k=&q=&custom-mdt=on&b=0-10000" if HDAUTH.endswith('&k=&q=') else HDAUTH #+"&custom-mdt=on&b=0-10000"
				STREAM = 'HLS' if enableINPUTSTREAM else 'M3U8'
				FINAL_URL = f'{HDFLASH}?hdnea={HDAUTH}'
	if FINAL_URL and (TEST_URL or STREAM):
		log(f"(navigator.playVideo) StreamURL : {FINAL_URL}")
		LSM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		if FINAL_URL and STREAM:
			if plugin_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD'] and 'master.m3u8' in FINAL_URL:
				IA_NAME = 'inputstream.adaptive'
				IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
				LSM.setMimeType('application/x-mpegURL'), LSM.setContentLookup(False), LSM.setProperty('inputstream', IA_NAME)
				if KODI_un21:
					LSM.setProperty(f"{IA_NAME}.manifest_type", 'hls') # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				if int(IA_VERSION) >= 2150 and STREAM in ['HLS', 'MPD']:
					LSM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey') # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
	else:
		failing(f"(navigator.playVideo) ##### Abspielen des Streams NICHT möglich #####\n ##### TARGET : {TARGET} #####")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem(offscreen=True))
		xbmc.PlayList(1).clear()
		return dialog.notification(translation(30521).format('PLAY'), translation(30528), icon, 10000)

def addDir(params, listitem, folder=True):
	uws = params.get('link') if params.get('extras') == 'YT_FOLDER' else build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
