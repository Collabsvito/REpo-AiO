﻿# -*- coding: utf-8 -*-

from .common import *
from .external.scrapetube import *


def create_account(success=False):
	debug_MS("(navigator.create_account) ############### START ACCOUNT - REGISTRATION ###############")
	email_adress = dialog.input(translation(30541), type=xbmcgui.INPUT_ALPHANUM)
	hidden_sign = dialog.input(translation(30542), type=xbmcgui.INPUT_ALPHANUM)
	if email_adress is not None and len(email_adress) > 0 and hidden_sign is not None and len(hidden_sign) >= 6:
		success, userload = True, urlencode({'username': email_adress, 'password': hidden_sign})
		check_login = requests.request('POST', VBTV_LOGIN.format(userload), headers=VBTV_HEADER, allow_redirects=True, data=userload, timeout=20)
		debug_MS(f"(navigator.create_account[1]) === ACCOUNT_LOGIN === STATUS : {check_login.status_code} || CONTENT : {check_login.text} ===")
		if '"success":true' in check_login.text:
			debug_MS("(navigator.create_account[2]) ##### ALLE DATEN GEFUNDEN - DIE REGISTRIERUNG WAR ERFOLGREICH #####")
			addon.setSetting('emailing', email_adress)
			addon.setSetting('password', hidden_sign)
			addon.setSetting('username', f'[B]{email_adress}[/B]')
			xbmc.sleep(1000)
			return dialog.notification(translation(30543).format('Login'), translation(30544).format(email_adress), icon, 10000)
		else:
			return dialog.ok(addon_id, translation(30504))
	if success is False: return dialog.notification(translation(30545), translation(30546), icon , 10000)

def erase_account():
	debug_MS("(navigator.erase_account) XXXXX VfB-Stuttgart-KONTO ZWANGSWEISE AUS KODI ENTFERNEN - LÖSCHE ACCOUNT-DATEN - ERFOLGREICH XXXXX")
	addon.setSetting('emailing', '')
	addon.setSetting('password', '')
	addon.setSetting('username', '')
	xbmc.sleep(1000)
	return dialog.notification(translation(30543).format('Logout'), translation(30547), icon, 10000)

def main_menu():
	debug_MS("(navigator.main_menu) ------------------------------------------------ START = main_menu -----------------------------------------------")
	content = track_content(BASE_LONG, headers=VBTV_HEADER) # <a class="c-navigation__menu-point-wrapper" id="access-inside" class="access-key-anchor" data-access-key="6"   data-access-title="Inside"
	selection = re.findall(r'''<a class=["']c-navigation__menu-point-wrapper["'] id=["']([^"']+)["'] class=["']access-key-anchor["'] data-access-key=["'][0-9]+["']\s*data-access-title=["']([^"']+)["']''', content, re.S)
	for code, title in selection:
		title = cleaning(title)
		add_views({'mode': 'list_overview', 'phase': title}, create_entries({'Title': translation(30601).format(title)}))
		debug_MS(f"(navigator.main_menu[1]) ### TITLE : {title} || CODE : {code} ###")
	if youtube_seen:
		add_views({'mode': 'list_playlists'}, create_entries({'Title': translation(30602)}))
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30603), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_overview(phase):
	debug_MS("(navigator.list_overview) -------------------------------------------------- START = list_overview --------------------------------------------------")
	debug_MS(f"(navigator.list_overview) ### CATEGORY = {phase} ###")
	content = track_content(BASE_LONG, headers=VBTV_HEADER)
	result = content[content.find(f'data-access-title="{phase}"'):]
	result = result[:result.find('</ul>')]
	match = re.compile(r'''<a href=["']([^"']+)["'] target=["']_self["']>([^<]+)</a>''', re.S).findall(result)
	for link, title in match:
		changes = completing(link)
		title = cleaning(title)
		if 'bundesliga' in changes and not '/frauen' in changes:
			add_views({'mode': 'list_saisons', 'link': changes, 'phase': 'Bundesliga'}, create_entries({'Title': title}))
		elif 'dfb-pokal' in changes:
			add_views({'mode': 'list_saisons', 'link': changes, 'phase': 'DFB-Pokal'}, create_entries({'Title': title}))
		elif 'champions-league' in changes:
			add_views({'mode': 'list_saisons', 'link': changes, 'phase': 'Champions-League'}, create_entries({'Title': 'Champions-League'}))
		else:
			add_views({'mode': 'list_videos', 'link': changes, 'phase': title}, create_entries({'Title': title}))
		debug_MS(f"(navigator.list_overview[1]) ### TITLE : {title} || LINK : {changes} ###")
	if phase == 'Saison':
		track_uno, track_due = 'saison/saisons/saison-2024-2025/supercup/finale/', 'saison/saisons/saison-2025-2026/europa-league/1--spieltag/'
		add_views({'mode': 'list_saisons', 'link': f"{BASE_LONG}{track_uno}", 'phase': 'Supercup'}, create_entries({'Title': 'Supercup'}))
		add_views({'mode': 'list_gamedays', 'link': f"{BASE_LONG}{track_due}", 'phase': 'Europa-League'}, create_entries({'Title': 'Europa-League'}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_saisons(target, phase):
	debug_MS("(navigator.list_saisons) -------------------------------------------------- START = list_saisons --------------------------------------------------")
	debug_MS(f"(navigator.list_saisons) ### TARGET = {target} ### CATEGORY = {phase} ###")
	if phase == 'Bundesliga':
		content = track_content(target, headers=VBTV_HEADER)
		result = content[content.find('class="meldung-navi dropdown barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"')+1:]
		result = result[:result.find('</ul>')]
		match = re.compile(r'''target=["']_self["'] href=["']([^"']+)["']>([^<]+)</a>''', re.S).findall(result)
		for link, title in sorted(match, key=lambda vx: vx[1], reverse=True):
			changes = completing(link)
			title = cleaning(title)
			if ('/2--bundesliga/' in target and '/2--bundesliga/' in changes) or ('/bundesliga/' in target and '/bundesliga/' in changes):
				add_views({'mode': 'list_gamedays', 'link': changes, 'phase': f'Bundesliga - {title}'}, create_entries({'Title': title}))
			debug_MS(f"(navigator.list_saisons[1]) ### TITLE : {title} || LINK : {changes} ###")
	elif phase in ['DFB-Pokal', 'Champions-League', 'Supercup']:
		available = datetime(*(time.strptime(f"10.08.{str(datetime.now().strftime('%Y'))}", '%d.%m.%Y')[0:6]))
		point = 0 if datetime.now() > available else 1
		if phase == 'DFB-Pokal':
			for ii in range(date.today().year-point, 2015, -1):
				changes = f'{BASE_URL}/saison/saisons/saison-{str(ii)}-{str(int(ii)+1)}/dfb-pokal/'
				title = f'Saison {str(ii)}/{str(int(ii)+1)}'
				add_views({'mode': 'list_gamedays', 'link': changes, 'phase': f'DFB-Pokal - {title}'}, create_entries({'Title': title}))
				debug_MS(f"(navigator.list_saisons[2]) ### TITLE : {title} || LINK : {changes} ###")
		elif phase == 'Champions-League':
			for ii in range(date.today().year-point, 2023, -1): # 24/25 und 26/27
				if int(ii) == 2025: continue
				changes = f'{BASE_URL}/saison/saisons/saison-{str(ii)}-{str(int(ii)+1)}/champions-league/'
				title = f'Saison {str(ii)}/{str(int(ii)+1)}'
				add_views({'mode': 'list_gamedays', 'link': changes, 'phase': f'Champions-League - {title}'}, create_entries({'Title': title}))
				debug_MS(f"(navigator.list_saisons[3]) ### TITLE : {title} || LINK : {changes} ###")
		elif phase == 'Supercup':
			for ii in range(2025, 2023, -1): # 24/25 und 25/26
				changes = f'{BASE_URL}/saison/saisons/saison-{str(ii)}-{str(int(ii)+1)}/supercup/'
				title = f'Saison {str(ii)}/{str(int(ii)+1)}'
				add_views({'mode': 'list_videos', 'link': changes, 'phase': f'Supercup - {title}'}, create_entries({'Title': title}))
				debug_MS(f"(navigator.list_saisons[3]) ### TITLE : {title} || LINK : {changes} ###")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_gamedays(target, phase):
	debug_MS("(navigator.list_gamedays) -------------------------------------------------- START = list_gamedays --------------------------------------------------")
	debug_MS(f"(navigator.list_gamedays) ### TARGET = {target} ### CATEGORY = {phase} ###")
	start = ['<div class="spieltage swiper-container">', 'class="meldung-navi grey barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"', 'class="meldung-navi barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"']
	content = track_content(target, headers=VBTV_HEADER)
	if any(xs in content for xs in start):
		if start[0] in content:
			result = content[content.find(start[0])+1:]
			result = result[:result.find('<div class="clear">')]
			part = result.split('class="image swiper-slide"')
			for i in range(1, len(part), 1):
				entry = part[i]
				changes = completing(re.compile(r'''href=["']([^"']+)["']''', re.S).findall(entry)[0])
				title = cleaning(re.compile(r'''class=["']spieltag["']>(.*?)</div>''', re.S).findall(entry)[0])
				photo = re.compile(r'''<img src=["']([^"']+)["'] alt=''', re.S).findall(entry)[0].replace('x_143x80', 'x_960x540')
				photo = f"{BASE_URL[:-3]}{photo}" if photo.startswith('/tv/') else photo
				add_views({'mode': 'list_videos', 'link': changes, 'phase': f'{phase} - {title}'}, create_entries({'Title': title, 'Image': photo}))
				debug_MS(f"(navigator.list_gamedays[1]) ### TITLE : {title} || LINK : {changes} || THUMB : {photo} ###")
		elif start[1] in content or start[2] in content:
			result = content[content.find(start[1])+1:] if start[1] in content else content[content.find(start[2])+1:]
			result = result[:result.find('<div class="clear">')]
			spl = result.split('target="_self"')
			for i in range(1, len(spl), 1):
				elem = spl[i]
				changes = completing(re.compile(r'''href=["']([^"']+)["']''', re.S).findall(elem)[0])
				title = cleaning(re.compile(r'''<span>(.*?)</span>''', re.S).findall(elem)[0])
				add_views({'mode': 'list_videos', 'link': changes, 'phase': f'{phase} - {title}'}, create_entries({'Title': title}))
				debug_MS(f"(navigator.list_gamedays[2]) ### TITLE : {title} || LINK : {changes} ###")
	else:
		debug_MS(f'(navigator.list_gamedays) In der Rubrik : "{phase}" ~ gibt es KEINE Einträge !')
		return dialog.notification(translation(30524), translation(30527).format(phase), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_videos(target, phase):
	debug_MS("(navigator.list_videos) -------------------------------------------------- START = list_videos --------------------------------------------------")
	debug_MS(f"(navigator.list_videos) ### TARGET = {target} ### CATEGORY = {phase} ###")
	found, content = 0, track_content(target, headers=VBTV_HEADER)
	selection = re.findall('<article class="barrierfree-jumplink-anchor"(.*?)</article>', content, re.S)
	for chtml in selection:
		access, note_1 = 'PURCHASE' if 'class="zusatz">exklusiv</div>' in chtml else 'FREEMENT', ""
		if access == 'PURCHASE' and hide_paying is True: continue
		elif access == 'PURCHASE' and hide_paying is False: note_1 = translation(30621)
		found += 1
		changes = completing(re.compile(r'''href=["']([^"']+)["']''', re.S).findall(chtml)[0])
		title = cleaning(re.compile(r'''class=["']title["']>(.*?)</div>''', re.S).findall(chtml)[0])
		photo = re.compile(r'''<img src=["']([^"']+)["'] alt=''', re.S).findall(chtml)[0].replace('f_274x154', 'f')
		photo = f"{BASE_URL[:-3]}{photo}" if photo.startswith('/tv/') else photo
		matchDAT = re.compile(r'''class=["']date["']>([^<]+)</div>''', re.S).findall(chtml)
		if matchDAT:
			DAYS, MONTH, YEAR, note_2 = matchDAT[0].split(' ')[0], matchDAT[0].split(' ')[1], matchDAT[0].split(' ')[2], translation(30622).format(matchDAT[0])
			for tt in (('Januar', '01'), ('Februar', '02'), ('März', '03'), ('April', '04'), ('Mai', '05'), ('Juni', '06'), ('Juli', '07'), \
				('August', '08'), ('September', '09'), ('Oktober', '10'), ('November', '11'), ('Dezember', '12')):
				MONTH = MONTH.replace(*tt)
			DATES = datetime(*(time.strptime(f"{DAYS.split('.')[0].zfill(2)}.{MONTH}.{YEAR}", '%d.%m.%Y')[0:6])).strftime('%d.%m.%Y')
		else: DATES, note_2 = None, ""
		matchDES = re.compile(r'''class=["']text["']>(.*?)</div>''', re.S).findall(chtml)
		note_3 = cleaning(re.sub(r'\<.*?\>', '', matchDES[0])) if matchDES else ""
		fetch_items = {'Title': title, 'Plot': note_1+note_2+note_3, 'Aired': DATES, 'Genre': 'Fußball', 'Mediatype': 'episode', 'Image': photo, 'Reference': 'Single'}
		add_views({'mode': 'play_video', 'link': changes, 'extra': access}, create_entries(fetch_items), False)
		debug_MS(f"(navigator.list_videos[1]) ### TITLE : {title} || AIRED : {DATES} || LINK : {changes} || THUMB : {photo} ###")
	if found == 0 and hide_paying is False:
		debug_MS(f'(navigator.list_videos) In der Rubrik : "{phase}" ~ gibt es überhaupt KEINE verfügbaren Videos !')
		return dialog.notification(translation(30525), translation(30527).format(phase), icon, 12000)
	elif found == 0 and hide_paying is True:
		debug_MS(f'(navigator.list_videos) In der Rubrik : "{phase}" ~ gibt es KEINE verfügbaren "Gratis Videos" !')
		return dialog.notification(translation(30526), translation(30527).format(phase), icon, 12000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_playlists(extra):
	debug_MS("(navigator.list_playlists) ------------------------------------------------ START = list_playlists -----------------------------------------------")
	if pers_token == 'AIzaSy.................................':
		return dialog.ok(addon_id, translation(30351))
	elif pers_token[:6] != 'AIzaSy':
		return dialog.ok(addon_id, translation(30503))
	if extra == 'DEFAULT':
		add_views({'mode': 'list_playlists', 'extra': 'YOUT_STREAMS'}, create_entries({'Title': translation(30631), 'Plot': 'Live-Events und Aktuelles: VfB Stuttgart (VfB-TV)'}))
		add_views({'link': BASE_YOUT.format(CANAL_CODE, f'UU{CANAL_CODE[2:]}'), 'extra': 'YT_FOLDER'}, create_entries({'Title': translation(30632), 'Plot': 'Neue Uploads: VfB Stuttgart (VfB-TV)'}))
		target = f"https://youtube.googleapis.com/youtube/v3/playlists?part=snippet,contentDetails&channelId={CANAL_CODE}&maxResults=50&key={pers_token}"
		scrolling, next_page = 1, None
		while scrolling > 0:
			content = track_content(target if scrolling == 1 else next_page, 'GET', 'JSON', TUBE_HEADER)
			for item in content.get('items', []):
				if item.get('kind') == 'youtube#playlist':
					debug_MS(f"(navigator.list_playlists[1.1]) xxxxx ENTRY-01 : {item} xxxxx")
					debug_MS("---------------------------------------------")
					title, yout_video = cleaning(item['snippet']['title']), item.get('id', None)
					if title.lower().startswith('livestream'): continue # Hide Livestreams here because they are in separate Folder
					plot = (cleaning(item['snippet'].get('description', '')) or 'Offizieller YouTube Kanal des VfB Stuttgart (VfB-TV)')
					photo = (item['snippet']['thumbnails'].get('maxres', {}).get('url', '') or item['snippet']['thumbnails'].get('standard', {}).get('url', '') or item['snippet']['thumbnails'].get('high', {}).get('url', ''))
					numbers = item['contentDetails']['itemCount'] if str(item.get('contentDetails', {}).get('itemCount')).isdecimal() else None
					if isinstance(numbers, int) and int(numbers) == 0: continue
					name = translation(30633).format(title) if numbers is None else translation(30634).format(title, numbers)
					fetch_plays = create_entries({'Title': name, 'Plot': f'Playlist: {plot}', 'Image': photo})
					add_views({'link': BASE_YOUT.format(CANAL_CODE, yout_video), 'extra': 'YT_FOLDER'}, fetch_plays)
			if content.get('nextPageToken', None):
				next_page, scrolling = f"{target}&pageToken={content['nextPageToken']}", scrolling.__add__(1)
				debug_MS(f"(navigator.list_playlists[1.2]) PAGES ### NOW GET NEXTPAGE : {next_page} ###")
			else: break
	else:
		content = get_channel(CANAL_CODE, limit=50, sleep=1, content_type='streams') # mit 'get_channel' hier die Streams eines Channels abrufen
		for item in content:
			plot, (travel_view, duration), (live_stream, soon_stream) = "", (None for _ in range(2)), (False for _ in range(2))
			yout_video = item.get('contentId', None)
			separate = [elem.strip() for elem in cleaning(item['title']['runs'][0]['text']).split('|')]
			debug_MS(f"(navigator.list_playlists[2.1]) XXXXXX ENTRY-02 : {item} XXXXXX")
			debug_MS(f"(navigator.list_playlists[2.2]) ### TITLE-SPLIT : {separate} ###")
			debug_MS("---------------------------------------------")
			travel_date = (item.get('publishedTimeText', {}).get('simpleText', None) or item.get('viewCountText', {}).get('simpleText', None))
			travel_past = item.get('publishedTimeText', {}).get('simpleText')
			if item.get('viewCountText', {}).get('simpleText'):
				travel_view = cleaning(item['viewCountText']['simpleText'], True).replace(' Aufrufe', '').replace('Views ', '').replace(' warten', '').replace('Waiting ', '')
			travel_time = item.get('lengthText', {}).get('simpleText')
			if travel_time and travel_time[:4].upper() == 'LIVE':
				live_stream = True
				plot += translation(30635)
			elif travel_date and re.search(r'\d{2}.\d{2}.\d{2}, \d{2}:\d{2}', travel_date): # Geplant für: 01.06.26, 20:00
				cipher = re.search(r'\d{2}.\d{2}.\d{2}, \d{2}:\d{2}', travel_date) # 01.06.26, 20:00
				available = datetime(*(time.strptime(cipher.group(), '%d.%m.%y, %H:%M')[0:6]))+timedelta(hours=9) # Irgend etwas stimmt mit der Zeit nicht - liegt 9 Stunden zurück !!!
				event_start = available.strftime('%a{0} %d{0}%m{0}%Y {1} %H{2}%M').format( '.', '•', ':')
				for tt in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), ('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))):
					event_start = event_start.replace(*tt)
				soon_stream = True
				if travel_view and not re.search(r'\d{2}.\d{2}.\d{2}, \d{2}:\d{2}', travel_view):
					plot += translation(30636).format(event_start, travel_view)
				else: plot += translation(30637).format(event_start)
			elif travel_past and any(vsx in travel_past.lower() for vsx in ['streamt', 'streamed']): # vor 3 Tagen gestreamt
				duration = get_seconds(travel_time)
				travel_past = cleaning(travel_past, True).replace(' gestreamt', '').replace('Streamed ', '').replace('vor ', 'Vor ')
				if travel_view and not re.search(r'\d{2}.\d{2}.\d{2}, \d{2}:\d{2}', travel_view):
					plot += translation(30638).format(travel_past, travel_view)
				else: plot += translation(30639).format(travel_past)
			if len(separate) > 1:
				title = re.sub(r'(RE-|LIVE: |LIVE )', '', separate[0]) if len(separate[0]) > 10 else f"{re.sub(r'(RE-|LIVE: |LIVE )', '', separate[0])} - {separate[1]}"
				plot += f"[B]{title} | {separate[-2]} | {separate[-1]}[/B]" if len(separate) == 4 and separate[-2] not in title else f"[B]{title} | {separate[-1]}[/B]" if \
					(len(separate) == 4 and separate[-2] in title) or (len(separate) == 2 and separate[0] != 'LIVE:') or len(separate) == 3 else f"[B]{title}[/B]"
			else:
				title, plot = re.sub(r'(RE-|LIVE: |LIVE )', '', separate[0]), f"{plot}[B]{re.sub(r'(RE-|LIVE: |LIVE )', '', separate[0])}[/B]"
			name = translation(30640).format(title) if live_stream is True else title
			photo = f"https://i.ytimg.com/vi/{yout_video}/sddefault.jpg"
			fetch_actual = {'Title': name, 'Plot': plot, 'Duration': duration, 'Mediatype': 'episode', 'Image': photo, 'Reference': 'Single'}
			add_views({'mode': 'play_video', 'link': yout_video, 'extra': 'YOUTUBE'}, create_entries(fetch_actual), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def play_video(target, gateway):
	debug_MS("(navigator.play_video) -------------------------------------------------- START = play_video --------------------------------------------------")
	debug_MS(f"(navigator.play_video) ### TARGET = {target} ### PAY_TYPE = {gateway} ###")
	MEDIAS, (OLDEST, NEWEST, FINAL_URL, TEST_URL, DATA_TRE, STREAM) = [], (False for _ in range(6))
	HEAD_PLAY = f"User-Agent={WEB_AGENT}&Origin={BASE_URL[:-3]}&Referer={BASE_URL[:-2]}"
	if gateway == 'YOUTUBE':
		debug_MS(f"(navigator.play_video[1]) ***** TESTING - REDIRECTED : https://youtu.be/{target} || (Youtube-Redirect-Test) *****")
		FINAL_URL = f"plugin://plugin.video.youtube/play/?video_id={target}"
		verify = track_content(f"https://youtu.be/{target}", 'GET', 'TRACK', TUBE_HEADER, timeout=15)
		if verify and verify.status_code in [200, 201, 202]: TEST_URL = True
	else:
		DATA_UNO = track_content(target, headers=VBTV_HEADER)
		VIDEO_CID = re.compile(r'''data-video=["']([^"']+)["']''', re.S).findall(DATA_UNO)[0]
		payload = urlencode({'videoId': VIDEO_CID, 'width': 1920, 'height': 1080, 'loadTemplates': 'econda_video.tpl'})
		debug_MS(f"(navigator.play_video[1]) ##### PAYLOAD : {VBTV_PLAYER.format(payload)} #####")
		if gateway == 'FREEMENT': # POST = https://vfbtv.vfb.de/ajax.php?contelPageId=45506&noCache=1&videoId=35977&width=1152&height=648&loadTemplates=econda_video.tpl
			DATA_DUE = track_content(VBTV_PLAYER.format(payload), 'POST', 'TEXT', VBTV_HEADER, timeout=10).replace('\/', '/').replace('\\"', '"').replace('\\n', '').replace(' ', '')
			debug_MS(f"(navigator.play_video[2]) XXXXX CONTENT-Free-Video : {DATA_DUE} XXXXX")
			if 'vfbtv.vfb.de/video/streamData.php' in DATA_DUE:
				OLDEST, DATA_TRE = True, track_content(VBTV_ACPHP.format(VIDEO_CID), 'POST', 'JSON', VBTV_HEADER, timeout=10)
			else:
				template = re.compile(r'''playoutId:["']([^"']+)["'],container:["']([^"']+)["'],key:["']([^"']+)["'],timestamp:["']([^"']+)["']''', re.S).findall(DATA_DUE)
				if template:
					new_link = VBTV_3QSDN.format(template[0][0], template[0][2], str(int(template[0][3])+10))
					debug_MS(f"(navigator.play_video[2]) ##### TRANSFER-LINK : {new_link} ##### ")
					NEWEST, DATA_TRE = True, track_content(new_link, 'GET', 'JSON', VBTV_HEADER, timeout=10) # GET = https://playout.3qsdn.com/config/5c725a77-a8df-4f0c-8b41-f7b685e0237e?key=6a12405b7b2f3d09d707d493a2079231&timestamp=1784916558
		elif gateway == 'PURCHASE' and addon.getSetting('emailing') !="" and addon.getSetting('password') !="":
			userload = urlencode({'username': addon.getSetting('emailing'), 'password': addon.getSetting('password')})
			with requests.Session() as mrs: # URLs zur Anmeldung = "https://vfbtv.vfb.de/tv/sonderseiten/abo/" oder "https://shop.vfb.de/login"
				check_login = mrs.request('POST', VBTV_LOGIN.format(userload), headers=VBTV_HEADER, allow_redirects=True, data=userload, timeout=20)
				if '"success":true' in check_login.text:
					DATA_DUE = mrs.request('POST', VBTV_PLAYER.format(payload), headers=VBTV_HEADER, allow_redirects=True, timeout=10)
					substance = DATA_DUE.text.replace('\/', '/').replace('\\"', '"').replace('\\n', '').replace(' ', '')
					if DATA_DUE.status_code in [200, 201, 202, 203] and not 'videoplayerNoAccess' in substance:
						debug_MS(f"(navigator.play_video[2]) XXXXX CONTENT-Payed-Video : {substance} XXXXX")
						if 'vfbtv.vfb.de/video/streamData.php' in substance:
							OLDEST, DATA_TRE = True, mrs.request('POST', VBTV_ACPHP.format(VIDEO_CID), headers=VBTV_HEADER, allow_redirects=True, timeout=10).json()
						else:
							template = re.compile(r'''playoutId:["']([^"']+)["'],container:["']([^"']+)["'],key:["']([^"']+)["'],timestamp:["']([^"']+)["']''', re.S).findall(substance)
							if template:
								new_link = VBTV_3QSDN.format(template[0][0], template[0][2], str(int(template[0][3])+10))
								debug_MS(f"(navigator.play_video[2]) ##### TRANSFER-LINK : {new_link} #####")
								NEWEST, DATA_TRE = True, mrs.request('GET', new_link, headers=VBTV_HEADER, allow_redirects=True, timeout=10).json() # GET = https://playout.3qsdn.com/config/5c725a77-a8df-4f0c-8b41-f7b685e0237e?key=6a12405b7b2f3d09d707d493a2079231&timestamp=1784916558
					else:
						xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
						failing(f"(navigator.play_video[2]) ERROR - ACCESS - ERROR ##### STATUS : {DATA_DUE.status_code} #####\n ##### DETAILS : {substance} #####")
						return dialog.ok(addon_id, translation(30505))
				else:
					xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
					failing(f"(navigator.play_video[2]) ERROR - LOGIN - ERROR ##### DETAILS : {check_login.text} #####\n ##### EMAIL : {addon.getSetting('emailing')} || PASSWORT : {addon.getSetting('password')} >>> bitte überprüfen Sie Ihre Login-Daten !!! #####")
					return dialog.ok(addon_id, translation(30504))
		else:
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
			failing("(navigator.play_video[2]) Für dieses Video ist ein 'Kostenpflichtiges-ABO' erforderlich - Bitte ein 'Kostenpflichtiges-ABO' unter 'https://shop.vfb.de/login' einrichten !!!")
			return dialog.ok(addon_id, translation(30505))
		if OLDEST and DATA_TRE and DATA_TRE.get('data', '') and DATA_TRE['data'].get('stream-access', '') and not 'error' in DATA_TRE.get('status', ''):
			# https://streamaccess.unas.tv/hdflash2/vod/119/production/35977.xml?streamid=35977&partnerid=2119&label=&area=&ident=5550869020230629033053&timestamp=20230629013053&format=iphone&start=&end=&auth=4e6de073d65019cf9abe4e1c4debd6ec
			availables = [xev for xev in DATA_TRE['data'].get('stream-access', [])]
			if len(availables) > 0:
				new_link = availables[-1].replace('\/', '/').replace('×tamp', '&timestamp')
				debug_MS(f"(navigator.play_video[3]) Vorhandene Streams ► {len(availables)} ◄ wähle den letzten verfügbaren Stream : {new_link}")
				DATA_QAD = track_content(f"https:{new_link}" if new_link.startswith('//') else new_link, headers=VBTV_HEADER)
				# https://hdvodvfbtv-vh.akamaihd.net/i/hdflash/20202021/news/210624_vfb_rote_tisch_hd_neu_,low,high,hd,.mp4.csmil/master.m3u8?hdnea=exp=1625493098~acl=*~hmac=74d0dd576d46e9a6d56f632a9d16bded8dd92d321714c601ae64ccdcc316bf5c&p=2119&u=&t=hdvideo&l=&a=&c=DE&e=31484&i=1848092120210705154638&k=&q=&custom-mdt=on&b=0-10000
				hdflash = re.compile(r'''url=["']([^"']+)["']''', re.S).findall(DATA_QAD)[0].replace('&amp;', '&')
				hdauth = re.compile(r'''auth=["']([^"']+)["']''', re.S).findall(DATA_QAD)[0].replace('&amp;', '&')
				hdauth = f"{hdauth.split('&k=&q=')[0]}&k=&q=&custom-mdt=on&b=0-10000" if hdauth.endswith('&k=&q=') else hdauth
				STREAM, FINAL_URL = 'HLS' if enable_adaptive else 'M3U8', f"{hdflash}?hdnea={hdauth}"
		elif NEWEST and DATA_TRE and DATA_TRE.get('streamType') == 'video' and DATA_TRE.get('sources', '') and DATA_TRE['sources'].get('hls', '') and not 'error' in DATA_TRE.get('releaseStatus', ''):
			debug_MS(f"(navigator.play_video[3]) Vorhandene Streams ► {len(DATA_TRE['sources'])} ◄ wähle den gefundenen HLS-Stream : {DATA_TRE['sources']['hls']}")
			STREAM, FINAL_URL = 'HLS' if enable_adaptive else 'M3U8', DATA_TRE['sources']['hls'] # https://sdn-global-streaming-cache.3qsdn.com/s/66df255f18b7971035e32b75700611eb/1785323313/120469/files/26/07/25/13969185/120469-e1124991-1779-4d5b-843b-bf9822c5ba97.ism/manifest.m3u8
	if FINAL_URL and (TEST_URL or STREAM):
		log(f"(navigator.play_video) StreamURL : {FINAL_URL}")
		LSM = xbmcgui.ListItem(path=FINAL_URL, offscreen=True)
		if FINAL_URL and STREAM:
			if plugin_operate('inputstream.adaptive') and STREAM in ['HLS', 'MPD'] and '.m3u8' in FINAL_URL:
				IA_NAME = 'inputstream.adaptive'
				IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
				LSM.setMimeType('application/vnd.apple.mpegurl'); LSM.setContentLookup(False); LSM.setProperty('inputstream', IA_NAME)
				if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", 'hls') # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
				PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
				LSM.setProperty(f"{IA_NAME}.stream_headers", HEAD_PLAY) # 'Without this rejected the Stream and ERROR 403 appears on KODI 21.3
				LSM.setProperty(f"{IA_NAME}.{PHRASE}_headers", HEAD_PLAY) # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
				if int(IA_VERSION) >= 2150:
					LSM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey') # Available from v.21.5.0 / Kodi 21 (Omega) - NEW simple method to configure a single DRM
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
	else:
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		failing(f"(navigator.play_video) ##### Abspielen des Streams NICHT möglich #####\n ##### TARGET : {target} #####")
		return dialog.notification(translation(30521).format('PLAY'), translation(30528), icon, 10000)

def add_views(params, listitem, folder=True):
	uws = params.get('link') if params.get('extra') == 'YT_FOLDER' else build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
