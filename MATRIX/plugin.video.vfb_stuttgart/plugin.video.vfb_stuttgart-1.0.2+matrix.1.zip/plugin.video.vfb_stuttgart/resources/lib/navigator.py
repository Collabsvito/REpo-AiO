﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
import datetime
import requests
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else: 
	from urllib.parse import urlencode  # Python 3.X
	from urllib.request import urlopen  # Python 3.X
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from .common import *


def LOGIN(firstFOUND):
	debug_MS("(navigator.LOGIN) ------------------------------------------------ START = LOGIN -----------------------------------------------")
	if username !="" and password !="":
		# URLs zur Anmeldung = "https://shop.vfb.de/account/ajax_login"
		# URLs zur Anmeldung = "https://shop.vfb.de/konto/anmeldung"
		payload = urlencode({'username': username, 'password': password})
		header = {}
		header['Connection'] = 'keep-alive'
		header['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0'
		header['DNT'] = '1'
		header['Upgrade-Insecure-Requests'] = '1'
		header['Accept-Encoding'] = 'gzip'
		header['Accept-Language'] = 'en-US,en;q=0.8,de;q=0.7'
		'''
		https://vfbtv.vfb.de/ajax.php?contelPageId=167&noCache=1&cmd=login&username=armishath88@gmail.com&password=1011=rilDUT!26
		'''
		ACCOUNT_URL = "https://vfbtv.vfb.de/ajax.php?contelPageId=167&noCache=1&cmd=login&"+payload
		debug_MS("(navigator.LOGIN) ##### PAYLOAD : {0} #####".format(payload))
		with requests.Session() as rs:
			doLogin_URL = rs.post(ACCOUNT_URL, headers=header, allow_redirects=True, verify=verify_ssl_connect, data=payload, timeout=30).text
			doLogin_URL = py2_enc(doLogin_URL)
			debug_MS("(navigator.LOGIN) ##### doLogin_URL : {0} #####".format(doLogin_URL))
			if '"success":true' in doLogin_URL:
				streamAccess_URL = rs.get("https://vfbtv.vfb.de/video/streamAccess.php?videoId="+str(firstFOUND)+"&target=2&partner=2119&format=iphone", allow_redirects=True, verify=verify_ssl_connect, headers=header, timeout=30).text
				streamAccess_URL = py2_enc(streamAccess_URL)
				debug_MS("(navigator.LOGIN) ##### streamAccess_URL-1 : {0} #####".format(streamAccess_URL))
				if '"message":"Pay-Access granted"' in streamAccess_URL or '"message":"Video has free access"' in streamAccess_URL:
					return 1,streamAccess_URL
				else:
					failing("(navigator.LOGIN) LOGIN leider NICHT erfolgreich ##### streamAccess_URL-2 : {0} #####".format(streamAccess_URL))
					dialog.ok(addon_id, translation(30502))
					return 0,"0"
			else:
				failing("(navigator.LOGIN) LOGIN leider NICHT erfolgreich ### EMAIL : {0} ### PASSWORT : {1} ### bitte überprüfen Sie Ihre Login-Daten !!!".format(username, password))
				dialog.ok(addon_id, translation(30502))
				return 0,"0"
	else:
		failing("(LOGIN) Für dieses Video ist ein 'Bezahl-ABO' erforderlich - Bitte ein 'Bezahl-ABO' unter 'https://shop.vfb.de/registrierung/' einrichten !!!")
		dialog.ok(addon_id, translation(30503))
		return 0,"0"

def mainMenu():
	debug_MS("(navigator.mainMenu) ------------------------------------------------ START = mainMenu -----------------------------------------------")
	content = getUrl(BASE_LONG)
	selection = re.findall('<a id="([^"]+?)" class="access-key-anchor" data-access-key="[0-9]+" data-access-title="([^"]+?)"', content, re.DOTALL)
	for id, title in selection:
		debug_MS("(navigator.mainMenu) ### TITLE : {0} || ID : {1} ###".format(title, id))
		title = cleaning(title)
		addDir(title, icon, {'mode': 'listOverview', 'url': title})
	if enableADJUSTMENT:
		addDir(translation(30601), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30602), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listOverview(first_NAME):
	debug_MS("(navigator.listOverview) -------------------------------------------------- START = listOverview --------------------------------------------------")
	debug_MS("(navigator.listOverview) ### first_NAME = {0} ###".format(first_NAME))
	content = getUrl(BASE_LONG)
	result = content[content.find('data-access-title="'+first_NAME+'"'):]
	result = result[:result.find('</ul>')]
	match = re.compile('<a href="([^"]+?)" target="_self">([^<]+?)</a>', re.S).findall(result)
	for link, title in match:
		newURL = link if link.startswith('http') else BASE_URL[:-3]+link if link.startswith('/tv/') else BASE_URL+link
		title = cleaning(title)
		if 'bundesliga' in newURL:
			addDir(title, icon, {'mode': 'listSaisons', 'url': newURL, 'category': 'Bundesliga'})
		elif 'dfb-pokal' in newURL:
			addDir(title, icon, {'mode': 'listSaisons', 'url': newURL, 'category': 'DFB-Pokal'})
		else:
			addDir(title, icon, {'mode': 'listVideos', 'url': newURL, 'category': title})
		debug_MS("(navigator.listOverview) ### TITLE : {0} || LINK : {1} ###".format(title, newURL))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSaisons(url, CAT):
	debug_MS("(navigator.listSaisons) -------------------------------------------------- START = listSaisons --------------------------------------------------")
	debug_MS("(navigator.listSaisons) ### URL = {0} ### CATEGORY = {1} ###".format(url, CAT))
	startURL = url
	if CAT == 'Bundesliga':
		content = getUrl(url)
		result = content[content.find('class="meldung-navi dropdown barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"')+1:]
		result = result[:result.find('</ul>')]
		match = re.compile('target="_self" href="([^"]+?)">(.+?)</a>', re.S).findall(result)
		for link, title in match:
			newURL = link if link.startswith('http') else BASE_URL[:-3]+link if link.startswith('/tv/') else BASE_URL+link
			title = cleaning(title)
			if ('/2--bundesliga/' in startURL and '/2--bundesliga/' in newURL) or ('/bundesliga/' in startURL and '/bundesliga/' in newURL):
				addDir(title, icon, {'mode': 'listGamedays', 'url': newURL, 'category': title})
			debug_MS("(navigator.listSaisons[1]) ### TITLE : {0} || LINK : {1} ###".format(title, newURL))
	elif CAT == 'DFB-Pokal':
		for i in range(datetime.date.today().year, 2015, -1):
			newURL = '{0}/saison/saisons/saison-{1}-{2}/dfb-pokal/'.format(BASE_URL, str(i), str(int(i)+1))
			title = 'Saison {0}/{1}'.format(str(i), str(int(i)+1))
			addDir(title, icon, {'mode': 'listGamedays', 'url': newURL, 'category': title})
			debug_MS("(navigator.listSaisons[2]) ### TITLE : {0} || LINK : {1} ###".format(title, newURL))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listGamedays(url, CAT):
	debug_MS("(navigator.listGamedays) -------------------------------------------------- START = listGamedays --------------------------------------------------")
	debug_MS("(navigator.listGamedays) ### URL = {0} ### CATEGORY = {1} ###".format(url, CAT))
	startSELECTION = ['<div class="spieltage swiper-container">', 'class="meldung-navi grey barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"', 'class="meldung-navi barrierfree-jumplink-anchor" data-barrierfree-jumplink="Content Navigation"']
	content = getUrl(url)
	if any(x in content for x in startSELECTION):
		if startSELECTION[0] in content:
			result = content[content.find(startSELECTION[0])+1:]
			part = result.split('class="image swiper-slide"')
			for i in range(1,len(part),1):
				entry = part[i]
				link = re.compile('href="([^"]+?)"', re.S).findall(entry)[0]
				newURL = link if link.startswith('http') else BASE_URL[:-3]+link if link.startswith('/tv/') else BASE_URL+link
				photo = re.compile(r'<img.+?src="([^"]+?)" alt=', re.S).findall(entry)[0].replace('x_143x80', 'x_960x540')
				photo = BASE_URL[:-3]+photo if photo.startswith('/tv/') else photo
				title = re.compile('class="spieltag">(.+?)</div>', re.S).findall(entry)[0]
				title = cleaning(title)
				addDir(title, photo, {'mode': 'listVideos', 'url': newURL, 'category': title})
				debug_MS("(navigator.listGamedays[1]) ### TITLE : {0} || LINK : {1} ###".format(title, newURL))
				debug_MS("(navigator.listGamedays[1]) ### THUMB : {0} ###".format(photo))
		elif startSELECTION[1] in content or startSELECTION[2] in content:
			if startSELECTION[1] in content:
				result = content[content.find(startSELECTION[1])+1:]
			else:
				result = content[content.find(startSELECTION[2])+1:]
			result = result[:result.find('<div class="clear">')]
			spl = result.split('target="_self"')
			for i in range(1,len(spl),1):
				elem = spl[i]
				link = re.compile('href="([^"]+?)"', re.S).findall(elem)[0]
				newURL = link if link.startswith('http') else BASE_URL[:-3]+link if link.startswith('/tv/') else BASE_URL+link
				title = re.compile('<span>(.+?)</span>', re.S).findall(elem)[0]
				title = cleaning(title)
				addDir(title, icon, {'mode': 'listVideos', 'url': newURL, 'category': title})
				debug_MS("(navigator.listGamedays[2]) ### TITLE : {0} || LINK : {1} ###".format(title, newURL))
	else:
		debug_MS("(navigator.listGamedays) Leider gibt es in der Rubrik : {0} - KEINE Einträge !".format(CAT))
		return dialog.notification(translation(30522).format('Einträge'), translation(30524).format(CAT.upper()), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(url, CAT):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS("(navigator.listVideos) ### URL = {0} ### CATEGORY = {1} ###".format(url, CAT))
	FOUND = False
	content = getUrl(url)
	selection = re.findall('<article class="barrierfree-jumplink-anchor"(.+?)</article>', content, re.S)
	for chtml in selection:
		if ('class="zusatz">gratis</div>' in str(chtml) and enableFreeVids) or not enableFreeVids:
			Note_1, Note_2 = ("" for _ in range(2))
			FOUND = True
			link = re.compile('href="([^"]+?)"', re.S).findall(chtml)[0]
			newURL = link if link.startswith('http') else BASE_URL[:-3]+link if link.startswith('/tv/') else BASE_URL+link
			photo = re.compile(r'<img.+?src="([^"]+?)" alt=', re.S).findall(chtml)[0].replace('f_274x154', 'f')
			photo = BASE_URL[:-3]+photo if photo.startswith('/tv/') else photo
			matchDT = re.compile('class="date">([^<]+?)</div>', re.S).findall(chtml)
			movieDATE = matchDT[0] if matchDT else None
			title = re.compile('class="title">(.+?)</div>', re.S).findall(chtml)[0]
			title = cleaning(title)
			if movieDATE:
				title += "  ("+movieDATE+")"
				Note_1 = translation(30621).format(movieDATE)
			try: 
				desc = re.compile('class="text">(.+?)</div>', re.S).findall(chtml)[0]
				Note_2 = cleaning(re.sub(r'\<.*?\>', '', desc))
			except: pass
			plot = Note_1+Note_2
			access = "Free-Video" if 'class="zusatz">gratis</div>' in str(chtml) else "Pay-Video"
			addLink(title, photo, {'mode': 'playVideo', 'url': newURL, 'extras': access}, plot)
			debug_MS("(navigator.listVideos) ### TITLE : {0} || LINK : {1} ###".format(title, newURL))
			debug_MS("(navigator.listVideos) ### THUMB : {0} ###".format(photo))
	if not FOUND:
		if not enableFreeVids:
			debug_MS("(navigator.listVideos) Leider gibt es in der Rubrik : {0} - überhaupt KEINE verfügbaren Videos !".format(CAT))
			return dialog.notification(translation(30522).format('Einträge'), translation(30524).format(CAT.upper()), icon, 8000)
		else:
			debug_MS("(navigator.listVideos) Leider gibt es in der Rubrik : {0} - KEINE 'Gratis Videos' !".format(CAT))
			return dialog.notification(translation(30522).format("'Gratis Videos'"), translation(30524).format(CAT.upper()), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playVideo(url, GATEWAY):
	debug_MS("(navigator.playVideo) -------------------------------------------------- START = playVideo --------------------------------------------------")
	debug_MS("(navigator.playVideo) ### URL = {0} ### GATEWAY = {1} ###".format(url, GATEWAY))
	MEDIAS = []
	DATA, STREAM, finalURL = (False for _ in range(3))
	content = getUrl(url)
	firstFOUND = re.compile('data-video="([^"]+?)"', re.S).findall(content)[0]
	debug_MS("(navigator.playVideo) firstFOUND : {0}".format(firstFOUND))
	if GATEWAY == 'Free-Video':
		secondURL = "https://vfbtv.vfb.de/video/streamAccess.php?videoId="+str(firstFOUND)+"&target=2&partner=2119&format=iphone"
		content2 = getUrl(secondURL)
		debug_MS("(navigator.playVideo) CONTENT-Free-Video : {0}".format(content2))
		DATA = json.loads(content2)
	elif GATEWAY == 'Pay-Video':
		Status,Konto = LOGIN(firstFOUND)
		if Status == 1:
			debug_MS("(navigator.playVideo) CONTENT-Pay-Video : {0}".format(Konto))
			DATA = json.loads(Konto)
		else: return
	if DATA and DATA.get('data', '') and DATA.get('data', {}).get('stream-access', '') and not 'error' in DATA.get('status', ''):
		# https://streamaccess.unas.tv/hdflash2/vod/119/production/31484.xml?streamid=31484&partnerid=2119&label=&area=&ident=1848092120210705154638&timestamp=20210705134638&format=iphone&start=&end=&auth=f0098fc4e1d9f5ed9083bfa7093395c0
		for video in DATA['data']['stream-access']:
			MEDIAS.append(py2_enc(video))
		if MEDIAS:
			STREAM = 'M3U8'
			if len(MEDIAS) > 1:
				link = MEDIAS[1].replace('×tamp', '&timestamp')
				log("(navigator.playVideo) Wir haben 2 *StreamZugänge* - wähle den Zweiten : {0}".format(link))
			else:
				link = MEDIAS[0].replace('×tamp', '&timestamp')
				log("(navigator.playVideo) Wir haben 1 *StreamZugang* - wähle Diesen : {0}".format(link))
			newURL = "https:"+link if link.startswith('//') else link
			content3 = getUrl(newURL)
			# https://hdvodvfbtv-vh.akamaihd.net/i/hdflash/20202021/news/210624_vfb_rote_tisch_hd_neu_,low,high,hd,.mp4.csmil/master.m3u8?hdnea=exp=1625493098~acl=*~hmac=74d0dd576d46e9a6d56f632a9d16bded8dd92d321714c601ae64ccdcc316bf5c&p=2119&u=&t=hdvideo&l=&a=&c=DE&e=31484&i=1848092120210705154638&k=&q=&custom-mdt=on&b=0-10000
			url_FOUND = re.compile('url="([^"]+?)"', re.S).findall(content3)[0].replace('&amp;', '&')
			auth_FOUND = re.compile('auth="([^"]+?)"', re.S).findall(content3)[0].replace('&amp;', '&')
			finalURL = url_FOUND+"?hdnea="+auth_FOUND#+"&custom-mdt=on&b=0-10000"
			# Möglichkeit Video als -mp4- abzuspielen :
			# streamURL = url_FOUND+"?hdnea="+auth_FOUND#+"&custom-mdt=on&b=0-10000"
			# standardURL = "http://tvstreaming.vfb.de/"+streamURL.split('hdflash/')[1].split('_,low,')[0]+"_low.mp4"
			# finalURL = VideoBEST(standardURL)
	if finalURL and STREAM:
		log("(navigator.playVideo) StreamURL : {0}".format(finalURL))
		listitem = xbmcgui.ListItem(path=finalURL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'master.m3u8' in finalURL:
			listitem.setMimeType('application/vnd.apple.mpegurl')
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
	else:
		failing("(navigator.playVideo) ##### Abspielen des Streams NICHT möglich #####\n   ##### URL : {0} #####".format(url))
		return dialog.notification(translation(30521).format('PLAY'), translation(30525), icon, 8000)

def VideoBEST(best_url):
	# *mp4URL* Qualität nachbessern, überprüfen, danach abspielen
	standards = [best_url, "", "", ""]
	standards[1] = standards[0].replace('_low.mp4', '_high.mp4')
	standards[2] = standards[1].replace('_high.mp4', '_hd.mp4')
	standards[3] = standards[2].replace('_hd.mp4', '_uhd.mp4')
	for element in reversed(standards):
		if len(element) > 0:
			try:
				code = urlopen(element, timeout=6).getcode()
				if str(code) == '200':
					return element
			except: pass
	return best_url

def AddToQueue():
	return xbmc.executebuiltin('Action(Queue)')

def addDir(name, image, params={}, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Duration': duration, 'Studio': 'VfB-Stuttgart TV', 'Genre': 'Fussball', 'Mediatype': 'video'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.addStreamInfo('Video', {'Duration': duration})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'RunPlugin('+HOST_AND_PATH+'?mode=AddToQueue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
