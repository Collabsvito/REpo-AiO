﻿# -*- coding: utf-8 -*-

from common import *


class realvitoMonitor(xbmc.Monitor):
	def __init__(self, *args, **kwargs):
		super(realvitoMonitor, self).__init__()

class UpdateService():
	def __init__(self, *args, **kwargs):
		self._monitor = realvitoMonitor()
		self._debuggin = self.events_setter()
		self._stopping = False
		self._errornote = 0
		self._maximum = 3

	def current_os(self):
		COS = 'Unknown'
		PLATFORMS = ['System.Platform.Android', 'System.Platform.UWP', 'System.Platform.Windows', 'System.Platform.IOS', \
			'System.Platform.Darwin', 'System.Platform.OSX', 'System.Platform.TVOS', 'System.Platform.Linux', 'System.Platform.Linux.RaspberryPi']
		for each in PLATFORMS:
			if xbmc.getCondVisibility(each):
				COS = each.split('.')[-1]
				break
		return COS

	def events_setter(self):
		self._debuggin = (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
		return self._debuggin

	def start_signal(self):
		time.sleep(20)
		announce("########################################################################################################")
		announce(f"########## RUNNING: {addon_id} VERSION: {addon_version} / ON PLATFORM: {self.current_os()} ##########")
		announce("############### Start the Service in nearly 1 minute - wait for other Instances to close ###############")
		announce("########################################################################################################")
		time.sleep(40)
		self.start_timer()

	def start_timer(self):
		while not self._monitor.abortRequested() and not self._stopping:
			self._debuggin = self.events_setter()
			NEXT_START = addon.getSetting('next_process')
			STORE_START = datetime(*(time.strptime(NEXT_START[:19], '%Y-%m-%d %H:%M:%S')[0:6])) # 2025-04-12 14:10:00
			if datetime.now() > STORE_START:
				NEXT_TASK = datetime.now() + timedelta(seconds=3600*int(addon.getSetting('renovate_interval'))) # Current time plus user defined Hours for the next run of the Service
				addon.setSetting('next_process', str(NEXT_TASK)[:19])
				log(f"(service.start_timer[1]) >> SERVICE INIT >> STORED_DATE : {STORE_START} >> (NEXT_START : {str(NEXT_TASK)[:19]})")
				self.load_rebuild()
				self._waiting = 3600*int(addon.getSetting('renovate_interval'))
			else:
				log(f"(service.start_timer[1]) >> SERVICE INIT >> NEXT SCHEDULED EXECUTION AT : ► {STORE_START} ◄ , INTERVAL IS SET TO : ► {addon.getSetting('renovate_interval')} HOURS ◄")
				self._waiting = (round((STORE_START - datetime.now()) / timedelta(seconds=1))) # Stored time minus Current time = Time to wait in Seconds for the next run of the Service
			if self._monitor.waitForAbort(int(self._waiting)):
				break
		else:
			time.sleep(30)
			NEXT_TASK = datetime.now() + timedelta(seconds=3600*8) # Current time plus 8 Hours for the repair run of the Service
			addon.setSetting('next_process', str(NEXT_TASK)[:19])
			failing("▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼")
			failing(f">>>>>>>>>>>>>>>> STOPPING: {addon_id} VERSION: {addon_version} / ON PLATFORM: {self.current_os()} <<<<<<<<<<<<<<<<")
			failing(">>>>>>>>>>>!!! The Service was forcibly terminated by the System or due to the max. Error rate reached !!!<<<<<<<<<<<")
			failing(f">>>>>>>>>>>>>>>>>>>>>>>>>>>> NEXT FORCED SERVICE EXECUTION AT : ► {str(NEXT_TASK)[:19]} ◄ <<<<<<<<<<<<<<<<<<<<<<<<<<<<")
			failing("▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲")

	def load_rebuild(self):
		if not self._stopping:
			debug_MS("(service.load_rebuild[1]) ########## STARTING LOOP ... ##########", self._debuggin)
			dialog.notification(translation(30524), translation(30525), icon, 7000)
			guides_data, channels_data, programs_data = ([] for _ in range(3))
			try:
				for pages in range(1, 9, 1):
					epgtables = fetch_template()
					epgtables.update({'page': str(pages)})
					guides_data.append({'Count_1': int(pages), 'Link_1': f"{GIZMO_START}/live_channels?{urlencode(epgtables)}"})
				package = track_several(guides_data, headers=WEB_HEADER)
				for blocks in json.loads(package):
					for station in sorted(blocks['data'], key=lambda vox: int(vox.get('Count_2', 1))):
						lang_curt, lang_full, artwork = 'en', 'English', None
						name = station['title']
						chan_idd = clear_umlaut(name).replace(':', '').replace('’', '').replace("'", "").replace('!', '').replace('. ', ' ').replace(', ', ' ').replace(' + ', ' ').replace(' & ', ' ').replace(' / ', ' ').replace(' - ', ' ').replace(' ', '-').lower()
						chan_num = station.get('channel_number', '1') # chan_idd = station['id']
						if station.get('labels', '') and station['labels'].get('languages', '') and len(station['labels']['languages']) > 0 and 'name' in str(station['labels']['languages']):
							lang_curt, lang_full = station['labels']['languages'][0]['name'][:2].lower().replace('ke', 'en'), station['labels']['languages'][0]['name'].replace('Englisch', 'English').replace('Deutsch', 'German').replace('Keine Dialoge', 'English')
							if chan_idd in ['deluxe-lounge-hd', 'ducktv', 'graham-norton', 'more-than-sports-tv', 'stingray-remember-the-80s', 'storyzoo-friends', 'tastemade', 'tennis-channel', 'the-reuters-60']: lang_curt, lang_full = 'en', 'English'
							elif chan_idd in ['goldstar-tv-alles-schlager']: lang_curt, lang_full = 'de', 'German'
							elif chan_idd in ['merhaba-tuerkische-serien']: lang_curt, lang_full = 'tr', 'Turkish'
						if station.get('images', ''):
							artwork = (station['images'].get('artwork', '') or station['images'].get('artwork_webp', ''))
						if station.get('labels', '') and station['labels'].get('tags', '') and len(station['labels']['tags']) > 0 and 'name' in str(station['labels']['tags']):
							genre = station['labels']['tags'][-1]['name'].replace('Slow TV', 'Dokumentarfilm')
						else: genre = 'Filme' if chan_idd in ['artflix', 'utopja'] else 'Nachrichten' # artflix=Filme, the-reuters-60=Nachrichten, utopja=Filme
						debug_MS("----------------------------------------------")
						debug_MS(f"(service.load_rebuild[2]) ##### CHANNEL : {name} || CID : {chan_idd} || NUMBER : {chan_num} || GENRE : {genre} #####", self._debuggin)
						debug_MS(f"(service.load_rebuild[2]) ##### LANG_FULL : {lang_full} || LANG_CURT : {lang_curt} || THUMB : {artwork} #####", self._debuggin)
						channels_data.append({'name': name, 'chan_idd': chan_idd, 'chan_num': chan_num, 'lang_curt': lang_curt, 'lang_full': lang_full, 'artwork': artwork})
						for info in station.get('live_programs', []):
							title, season, episode, snapshot = info['title'], "", "", None
							subhead = info['subtitle'] if info.get('subtitle', '') and len(info['subtitle']) > 3 else None
							if subhead:
								matchSE = re.search(r'(Staffel:? |Season:? |S)(\d+)', subhead) # Staffel 12, Folge 04 // Season 14, Episode 6 // S16E08
								season = f"S{matchSE.group(2).zfill(2)}" if matchSE else season
								subhead = re.sub(r'(-?:? ?Staffel:? [0-9]+ ?(:?-|:|$)?|-?:? ?Season:? [0-9]+ ?(:?-|:|$)?|-?:? ?S[0-9]+ ?(:?-|:|$)?)', '', subhead) if season != "" else subhead
								matchEP = re.search(r'(Episode:? |Folge:? |E)(\d+)', subhead) # Staffel 12, Folge 04 // Season 14, Episode 6 // S16E08 // Ep. 2.5
								episode = f"E{matchEP.group(2).zfill(2)}" if matchEP else episode
								subhead = re.sub(r'( ?Episode:? [0-9]+ ?(:?-|:|$)?| ?Folge:? [0-9]+ ?(:?-|:|$)?| ?E[0-9]+ ?(:?-|:|$)?| ?Ep.? (:?[0-9]+.[0-9]+|[0-9]+) ?(:?-|:|$)?)', '', subhead) if episode != "" else subhead
								if season == 'S00' and episode == 'E00': season, episode = ("" for _ in range(2))
								if title in subhead:
									subhead = re.sub(fr"{title} ?-?:?\|?", '', subhead).replace('""', '')
							mpaa = info['classification']['name'] if info.get('classification', '') and info['classification'].get('name', '') else ""
							description = info['description'] if info.get('description', '') and len(info['description']) > 5 and not 'info not available' in info['description'].lower() else None
							if info.get('images', ''):
								snapshot = (info['images'].get('snapshot', '') or info['images'].get('snapshot_webp', ''))
							if not info.get('starts_at', '') or not info.get('ends_at', ''): continue
							starting = datetime(*(time.strptime(info['starts_at'], '%Y-%m-%dT%H:%M:%S.000%z')[0:6])).timestamp()
							ending = datetime(*(time.strptime(info['ends_at'], '%Y-%m-%dT%H:%M:%S.000%z')[0:6])).timestamp()
							programs_data.append({'title': title, 'subhead': subhead, 'season': season, 'episode': episode, 'mpaa': mpaa, 'description': description, 'snapshot': snapshot, \
								'starts_at': starting, 'ends_at': ending, 'chan_idd': chan_idd, 'lang_curt': lang_curt, 'lang_full': lang_full, 'genre': genre, 'screen': season+episode})
					channels_data.sort(key=lambda cns: cns.get('chan_idd', 'zorro'))
					programs_data.sort(key=lambda pms: (pms.get('chan_idd', 'zorro'), pms.get('starts_at', '1767225660.0'))) # 1. Januar 2026 um 00:01:00
				guide_xml = self.build_xmltv(channels_data, programs_data)
				preserve(guide_xml)
				log(f"(service.load_rebuild[1/3]) << SERVICE FINISHED << EPG DATA SUCCESSFULLY CREATED : '{media_path}{xmltv_name}_{market_code.upper()}.xml.gz' <<")
				dialog.notification(translation(30524), translation(30526), icon, 10000)
			except:
				dialog.notification(translation(30521).format('REFRESH'), translation(30522), icon, 12000)
				formatted_lines = '\n'.join(traceback.format_exc().splitlines())
				self._errornote += 1
				if self._errornote >= self._maximum:
					failing(f"(service.load_rebuild[2]) ▼▼▼▼▼ ERROR - ENDING - ERROR ▼▼▼▼▼ {formatted_lines} ...\n▲▲▲▲▲ (now: {self._errornote}/max: {self._maximum}) ...Ending Service ▲▲▲▲▲")
					self._stopping = True
					self.start_timer()
				else:
					failing(f"(service.load_rebuild[2]) ▼▼▼▼▼ ERROR - CONTINUE - ERROR ▼▼▼▼▼ {formatted_lines} ...\n▲▲▲▲▲ (now: {self._errornote}/max: {self._maximum}) ...Continue Service ▲▲▲▲▲")
					time.sleep(300) # Wait 5 Minutes for next try
					self.load_rebuild()
			debug_MS("(service.load_rebuild[3]) ########## ... ENDING LOOP ##########", self._debuggin)

	def stabilizer(self, unsure):
		return "".join(cx for cx in unsure if cx.isprintable())

	def build_xmltv(self, channels, programs):
		CITY = 'Berlin' if int(addon.getSetting('home_country')) == 0 else 'Vienna' if int(addon.getSetting('home_country')) == 1 else 'Zurich'
		TZCT = pytz.timezone(f"Europe/{CITY}")
		section = ETS.Element('tv', attrib={'generator-info-name': 'rakutentv-epg', 'generated-timezone': f'Europe/{CITY}', 'generated-date': time.strftime('%d-%m-%Y %H:%M:%S')})
		for ch in channels:
			canals = ETS.SubElement(section, 'channel', attrib={'id': ch.get('chan_idd')})
			ETS.SubElement(canals, 'display-name', attrib={'lang': ch.get('lang_curt')}).text = ch.get('name').strip()
			ETS.SubElement(canals, 'lcn').text = str(ch.get('chan_num')).strip()
			if ch.get('artwork', ''):
				ETS.SubElement(canals, 'icon', attrib={'src': ch.get('artwork')})
		for pr in programs:
			separate, start_time = "", datetime.fromtimestamp(pr.get('starts_at'), TZCT).strftime('%Y%m%d%H%M%S %z').strip()
			end_time = datetime.fromtimestamp(pr.get('ends_at'), TZCT).strftime('%Y%m%d%H%M%S %z').strip()
			details = ETS.SubElement(section, 'programme', attrib={'channel': pr.get('chan_idd'), 'start': start_time, 'stop': end_time})
			ETS.SubElement(details, 'title', attrib={'lang': pr.get('lang_curt')}).text = self.stabilizer(pr.get('title')).strip()
			if pr.get('subhead', '') and len(self.stabilizer(pr.get('subhead')).strip()) > 3:
				ETS.SubElement(details, 'sub-title', attrib={'lang': pr.get('lang_curt')}).text = self.stabilizer(pr.get('subhead')).strip()
			if pr.get('season', ''): separate += f"{pr.get('season')} "
			if pr.get('episode', ''): separate += f"{pr.get('episode')} "
			if pr.get('mpaa', ''): separate += f"• {pr.get('mpaa')}" if len(separate) > 1 else f"{pr.get('mpaa')}"
			if len(separate) > 1:
				teaser = f"[B]{separate.strip()}[/B]"
				if pr.get('description', '') and len(self.stabilizer(pr.get('description')).strip()) > 3:
					teaser += f"\n{self.stabilizer(pr.get('description')).strip()}"
				ETS.SubElement(details, 'desc', attrib={'lang': pr.get('lang_curt')}).text = teaser
			elif len(separate) < 2 and pr.get('description', '') and len(self.stabilizer(pr.get('description')).strip()) > 3:
				ETS.SubElement(details, 'desc', attrib={'lang': pr.get('lang_curt')}).text = self.stabilizer(pr.get('description')).strip()
			if pr.get('genre', ''):
				ETS.SubElement(details, 'category', attrib={'lang': pr.get('lang_curt')}).text = self.stabilizer(pr.get('genre')).strip()
			ETS.SubElement(details, 'language').text = pr.get('lang_full').strip()
			if pr.get('snapshot', ''):
				ETS.SubElement(details, 'icon', attrib={'src': pr.get('snapshot')})
			if pr.get('screen', ''):
				ETS.SubElement(details, 'episode-num', attrib={'system': 'onscreen'}).text = pr.get('screen')
		outcomes = minidom.parseString(ETS.tostring(section, encoding='utf-8', xml_declaration=True)).toprettyxml(indent=' ' * 4, encoding='utf-8')
		return '\n'.join([sx for sx in outcomes.decode().splitlines() if sx.strip()])

if __name__ == '__main__':
	if addon.getSetting('auto_update') == 'true' or (addon.getSetting('auto_update') == 'false' and len(sys.argv) > 1 and sys.argv[1] == 'manual_update'):
		if plugin_operate('plugin.video.rakuten.de'):
			if addon.getSetting('media_path') == "" or addon.getSetting('xmltv_name') == "":
				dialog.ok(addon_id, translation(30503))
			elif addon.getSetting('media_path') != "" and addon.getSetting('xmltv_name') != "":
				if addon.getSetting('auto_update') == 'true':
					procedure = UpdateService()
					procedure.start_signal()
					del procedure
				elif addon.getSetting('auto_update') == 'false' and len(sys.argv) > 1 and sys.argv[1] == 'manual_update':
					debug_MS(f"(service.main) ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ MANUAL UPDATE HAS BEEN STARTED ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★ ★")
					procedure = UpdateService()
					procedure.load_rebuild()
					del procedure
