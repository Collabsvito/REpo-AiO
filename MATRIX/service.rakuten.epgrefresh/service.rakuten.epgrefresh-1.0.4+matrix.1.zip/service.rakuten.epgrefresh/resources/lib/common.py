﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import gzip
import time
from datetime import datetime, timedelta, timezone
from calendar import timegm as TGM
import xml.etree.ElementTree as ETS
import pytz
from xml.dom import minidom
import traceback
from urllib.parse import parse_qsl, urlencode, quote_plus, unquote_plus
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import psf_requests # psf_requests, psf_requests.HTTPAdapter


dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_desc						= addon.getAddonInfo('description')
addon_folder						= xbmcvfs.translatePath(addon.getAddonInfo('path'))
addon_profile					= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
fanart									= os.path.join(addon_folder, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addon_folder, 'resources', 'media', 'icon.png')
home_country					= int(addon.getSetting('home_country'))
xmltv_name						= addon.getSetting('xmltv_name')
media_path						= addon.getSetting('media_path')
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
BASE_URL							= 'https://www.rakuten.tv/'
GIZMO_START					= 'https://gizmo.rakuten.tv/v3'
classification						= '307' if home_country == 0 else '300' if home_country == 1 else '319'
locale_code						= 'de' if home_country == 0 else 'de-AT' if home_country == 1 else 'de-CH'
market_code						= 'de' if home_country == 0 else 'at' if home_country == 1 else 'ch'
WEB_AGENT						= 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'
WEB_HEADER					= {'User-Agent': WEB_AGENT, 'Origin': BASE_URL[:-1], 'Referer': BASE_URL, 'DNT': '1', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'Accept-Encoding': 'gzip, deflate', 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json; charset=utf-8'}
paras_WEB							= {'classification_id': classification, 'device_identifier': 'web', 'device_stream_audio_quality': '2.0', 'device_stream_hdr_type': 'NONE', 'device_stream_video_quality': 'FHD', 'locale': locale_code, 'market_code': market_code}

def translation(id):
	return addon.getLocalizedString(id)

def announce(msg, worth=xbmc.LOGINFO):
	return xbmc.log(str(msg), worth)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content, phase=DEB_LEVEL):
	log(content, phase)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def track_several(stacks, method='GET', queries='JSON', headers={}, timeout=20, redirects=True, workers=25):
	COMBI_NEW, number, counter, fixation, = [], len(stacks), 0, psf_requests.Session()
	fixation.mount('https://', psf_requests.HTTPAdapter(pool_connections=int(number), pool_maxsize=int(number), pool_block=True)) # Pool-Verbindungen und -Grösse auf tatsächlichen Inhalt festlegen, um Fehlermeldungen zu vermeiden
	def download(pos, link):
		response = fixation.request(method, link, headers=headers, allow_redirects=redirects, timeout=timeout)
		debug_MS(f"(common.track_several[1]) === POS : {pos} || STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
		if not isinstance(response.json(), list) and response.json().get('errors', ''):
			message = (response.json().get('errors', {})[0].get('message', '') or 'NO DETAILS FOUND')
			failing(f"(common.track_content) ERROR - RESPONSE - ERROR ##### URL : {link} === DETAILS : {message} #####")
		response.raise_for_status()
		return f'{{"Count_2":{pos},"Link_2":"{link}",{response.text[1:-1]}}}'
	with ThreadPoolExecutor(max_workers=workers) as executor:
		picker = [executor.submit(download, single['Count_1'], single['Link_1']) for single in stacks]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for future, section in zip(as_completed(picker), stacks):
			COMBI_NEW.append(json.loads(future.result()))
	return json.dumps(COMBI_NEW, indent=2)

def plugin_operate(MARKING):
	check_uno = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
	answer_uno, answer_due = json.loads(check_uno), json.loads(f'{{"error": "{MARKING} NOT FOUND"}}')
	if not "error" in answer_uno.keys() and answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is False:
		try:
			xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{MARKING}","enabled": true}}}}')
			failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####")
		except: pass
		del answer_due
		check_due = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
		answer_due = json.loads(check_due)
	if (answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is True) or (answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is True):
		return True
	if answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is False:
		dialog.ok(addon_id, translation(30501).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Eine automatische Aktivierung ist leider NICHT möglich !!! #####")
	if "error" in answer_uno.keys() or "error" in answer_due.keys():
		dialog.ok(addon_id, translation(30502).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - INSTALLED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT installiert !!! #####")
	return False

def fetch_template():
	rotation = int(addon.getSetting('renovate_interval'))+int(12)
	utc_start = (datetime.utcnow() - timedelta(hours=8)).strftime('%Y-%m-%dT%H:00:00.000Z') # 2025-03-10T07%3A00%3A00.000Z / 7:00
	epoch_start = TGM(time.strptime(utc_start[:19], '%Y-%m-%dT%H:%M:%S')) * 1000 # UTC-EPOCH-STARTTIME (Milliseconds=1741590000000)
	utc_ends = (datetime.utcnow() + timedelta(hours=rotation)).strftime('%Y-%m-%dT%H:00:00.000Z') # 2025-03-10T01%3A00%3A00.000Z / 1:00
	epoch_ends = TGM(time.strptime(utc_ends[:19], '%Y-%m-%dT%H:%M:%S')) * 1000 # UTC-EPOCH-ENDTIME (Milliseconds=1741568400000)
	terms_info = {**paras_WEB, **{'epg_duration_minutes': '360', 'epg_ends_at': utc_ends, 'epg_ends_at_timestamp': epoch_ends, \
		'epg_starts_at': utc_start, 'epg_starts_at_timestamp': epoch_start, 'page': '1', 'per_page': '25'}}
	return terms_info

def preserve(facts):
	if not os.path.exists(media_path):
		os.makedirs(media_path)
	for sample in os.listdir(media_path):
		if sample.endswith(f"{xmltv_name}_{market_code.upper()}.xml.gz"):
			xbmcvfs.delete(os.path.join(media_path, sample))
	with gzip.open(f"{media_path}{xmltv_name}_{market_code.upper()}.xml.gz", 'wt', encoding='utf-8') as topics:
		topics.write(facts)

def clear_umlaut(changes):
	if changes is not None:
		for cm in (('Ä', 'Ae'), ('ä', 'ae'), ('Ö', 'Oe'), ('ö', 'oe'), ('Ü', 'Ue'), ('ü', 'ue'), ('ß', 'ss')):
			changes = changes.replace(*cm)
		changes = changes.strip()
	return changes
