﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import gzip
import time
from datetime import datetime, timedelta, timezone
from calendar import timegm as TGM
import xml.etree.ElementTree as ETS
import pytz
from xml.dom import minidom
import requests
import traceback
from urllib.parse import parse_qsl, urlencode, quote_plus, unquote_plus
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_desc						= addon.getAddonInfo('description')
addonPath							= xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath								= xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
fanart									= os.path.join(addonPath, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addonPath, 'resources', 'media', 'icon.png')
COUNTRY_SITE					= int(addon.getSetting('home_country'))
XMLTV_NAME					= addon.getSetting('xmltv_name')
MEDIA_PATH						= addon.getSetting('media_path')
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
BASE_URL							= 'https://www.rakuten.tv/'
API_GIZMO						= 'https://gizmo.rakuten.tv/v3'
CLASSIFICATION				= '307' if COUNTRY_SITE == 0 else '300' if COUNTRY_SITE == 1 else '319'
LOCALE_CODE					= 'de' if COUNTRY_SITE == 0 else 'de-AT' if COUNTRY_SITE == 1 else 'de-CH'
MARKET_CODE					= 'de' if COUNTRY_SITE == 0 else 'at' if COUNTRY_SITE == 1 else 'ch'
agent_WEB							= 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'
head_WEB							= {'User-Agent': agent_WEB, 'Origin': BASE_URL[:-1], 'Referer': BASE_URL, 'DNT': '1', 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'Accept-Encoding': 'gzip, deflate, br', 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json; charset=utf-8'}
paras_WEB							= {'classification_id': CLASSIFICATION, 'device_identifier': 'web', 'device_stream_audio_quality': '2.0', 'device_stream_hdr_type': 'NONE', 'device_stream_video_quality': 'FHD', 'locale': LOCALE_CODE, 'market_code': MARKET_CODE}

def translation(id):
	return addon.getLocalizedString(id)

def announce(msg, worth=xbmc.LOGINFO):
	return xbmc.log(str(msg), worth)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content, phase=DEB_LEVEL):
	log(content, phase)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def getContent(url, params={}, headers={}, redirects=True, verify=False, timeout=40):
	response = requests.get(url, params=params, headers=headers, allow_redirects=redirects, verify=verify, timeout=timeout)
	debug_MS(f"(common.getContent) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
	if not isinstance(response.json(), list) and response.json().get('errors', ''):
		message = (response.json().get('errors', {})[0].get('message', '') or 'NO DETAILS FOUND')
		failing(f"(common.getContent) ERROR - RESPONSE - ERROR ##### URL : {url} === DETAIL : {message} #####")
	response.raise_for_status()
	return response.json()

def plugin_operate(MARKING):
	check_uno = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
	answer_uno, answer_due = json.loads(check_uno), json.loads(f'{{"error": "{MARKING} NOT FOUND"}}')
	if not "error" in answer_uno.keys() and answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is False:
		try:
			xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{MARKING}","enabled": true}}}}')
			failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####")
		except: pass
		del answer_due
		check_due = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
		answer_due = json.loads(check_due)
	if (answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is True) or (answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is True):
		return True
	if answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is False:
		dialog.ok(addon_id, translation(30501).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Eine automatische Aktivierung ist leider NICHT möglich !!! #####")
	if "error" in answer_uno.keys() or "error" in answer_due.keys():
		dialog.ok(addon_id, translation(30502).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - INSTALLED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT installiert !!! #####")
	return False

def getSpecifications():
	utc_start = (datetime.utcnow() - timedelta(hours=12)).strftime('%Y-%m-%dT%H:00:00.000Z') # 2025-03-10T07%3A00%3A00.000Z / 7:00
	epoch_start = TGM(time.strptime(utc_start[:19], '%Y-%m-%dT%H:%M:%S')) * 1000 # UTC-EPOCH-STARTTIME (Milliseconds=1741590000000)
	utc_ends = (datetime.utcnow() + timedelta(days=2)).strftime('%Y-%m-%dT%H:00:00.000Z') # 2025-03-10T01%3A00%3A00.000Z / 1:00
	epoch_ends = TGM(time.strptime(utc_ends[:19], '%Y-%m-%dT%H:%M:%S')) * 1000 # UTC-EPOCH-ENDTIME (Milliseconds=1741568400000)
	terms_info = {**paras_WEB, **{'epg_duration_minutes': '360', 'epg_ends_at': utc_ends, 'epg_ends_at_timestamp': epoch_ends, \
		'epg_starts_at': utc_start, 'epg_starts_at_timestamp': epoch_start, 'page': '1', 'per_page': '200'}}
	return terms_info

def preserve(facts):
	if not os.path.exists(MEDIA_PATH):
		os.makedirs(MEDIA_PATH)
	for sample in os.listdir(MEDIA_PATH):
		if sample.endswith(f"{XMLTV_NAME}_{MARKET_CODE.upper()}.xml.gz"):
			xbmcvfs.delete(os.path.join(MEDIA_PATH, sample))
	with gzip.open(f"{MEDIA_PATH}{XMLTV_NAME}_{MARKET_CODE.upper()}.xml.gz", 'wt', encoding='utf-8') as topics:
		topics.write(facts)

def cleanUmlaut(wrong):
	if wrong is not None:
		for wg in (('ä', 'ae'), ('Ä', 'Ae'), ('ü', 'ue'), ('Ü', 'Ue'), ('ö', 'oe'), ('Ö', 'Oe'), ('ß', 'ss')):
			wrong = wrong.replace(*wg)
		wrong = wrong.strip()
	return wrong
